Experimental Build: 2007-07-08

WARNING: This is experimental (alpha) code and will have bugs! If you don't
know how to edit step.rc files manually or you don't know how to recover if
the shell crashes, then do not try this build.

We are releasing this experimental build so that Litestep users can test out
the new math parser and other features listed below, which will be part of
Litestep 0.24.8.

-) "appbar" support (-

We have added an implementation to support AppBars.  This is a feature found
in the Explorer shell which some applications use to dock their window to the
edge of a screen (e.g the Explorer taskbar).  Some typical applications that
use this feature are Trillian and various media players.

This release adds support for WorkArea updates when an AppBar is positioned
or removed.  Please test the interaction between AppBars adjusting the WorkArea
and the Desktop modules adjusting the WorkArea.  Hopefully they will interact
nicely.  What you should expect, is if the desktop module has changed the
WorkArea for a specific screen edge, then any AppBar placed on the same screen
edge will be positioned so that it does not overlap the old workarea.  If an
AppBar is already on the screen edge, and the Desktop module tries to change
the WorkArea of that screen edge, it will fail, until the AppBar has been
removed.  This implementation appears to work in practice in the limited
testing we were able to do.  Please let us know if you find any odd or 
undesirable behavior in regards to the WorkArea and AppBars.

-) icon notification tray (systray) service fixes (-

The Icon Notification Tray service has been updated to fix several issues.
The most visible one being where old balloon (info) tips would appear during
a recycle. Please verify that all expected functionality still works.

We plan on further updates to the tray service before 0.24.8 final, which
will hopefully solve some of the remaining disapearing icon issues.

-) the new math parser (-

With the new math parser, both conditional expressions (If, ElseIf) and inline
expressions ($a + b$) now use the same syntax. The new math parser also adds
some new capabilities that were previously unavailable such as strings and
builtin functions.

The new syntax should be backwards compatible with existing files, but this is
new code and there are bound to be bugs. So, we're releasing this experimental
build to allow users to try out the new code and report bugs back to us. Also
be sure to try out some of the new features and provide feedback on those as
well. The new syntax is documented in the file "math.txt". Please post bug
reports and comments to the forums on www.lsdev.org.
