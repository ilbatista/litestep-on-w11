Screenbar 1.2 - a Litestep taskbar and VWM
By Jim Babcock

************
* Contents *
************
* 1. Getting Started
      1.1 Using Screenbar
      1.2 Adding Screenbar to a theme
* 2. Configuration Overview
* 3. Bang commands
* 4. Misc configuration options
      4.1 Global options
      4.2 Default theme options
* 5. Windows
      5.1 Overview
      5.2 Panels
      5.3 Tooltips
      5.4 Drag windows
* 6. Layout options
      6.1 Overview
      6.2 Element Types
      6.3 Element Positioning
      6.4 Branch Elements
      6.5 Flow Elements
      6.6 Group Elements
      6.7 Icon Elements
      6.8 Label Elements
      6.9 Minimap Elements
      6.10 Start Button Elements
      6.11 Texture Elements
      6.12 Snapshot Elements
      6.13 Module Elements
* 7. Child Modules
* 8. Descriptions
      8.1 Overview
      8.2 Desktops
      8.3 Windows
      8.4 Monitors
* 9. Legalities

*********************
* 1.Getting Started *
*********************
1.1 Using Screenbar
Screenbar combines a taskbar with virtual desktop management, allowing you to
manage multiple desktops from the taskbar. Since Screenbar is a LiteStep
module, it is highly configurable and different themes may customize it to
look and behave differently. This section describes how to use Screenbar with
the default configuration and theme, which other themes should try to follow
closely.

Windows on the taskbar will be arranged and grouped according to the desktop
they're on. To switch to a desktop, click on it. This will hide all of the
windows on the current desktop and show the windows on that desktop. To move
windows between desktops, drag and drop them on the taskbar. To create a new
desk, drag a task to an empty area on the taskbar.

Alternatively, you can use hotkeys to manipulate desktops. The file
screenbar_hotkeys.rc defines a set of hotkeys which all themes that use
Screenbar should include. These hotkeys are:
  Win+[1-9]         Switch to the numbered desktop (Win+0 is desk ten).
  Win+Left          Switch to previous desktop.
  Win+Right         Switch to next desktop.
  Win+Down          Merge current desktop with previous desktop.
  Win+Shift+Left    Move current application to previous desktop.
  Win+Shift+Right   Move current application to next desktop.
  Win+Shift+Up      Move current application to a new desktop at the beginning
                    of the list.
  Win+Shift+Down    Move current application to a new desktop at the end of
                    the list.
  Win+Ctrl+Left     Move this desk earlier in the list of desktops
  Win+Ctrl+Right    Move this desk later in the list of desktops
  Win+Ctrl+Down     Combine all desktops into one (gather)

1.2 Adding Screenbar to a theme

To add Screenbar to your Litestep theme, put these lines in your theme.rc
file:
  *NetLoadModule xpaintclass-1.0.dll
  *NetLoadModule screenbar.dll
XPaintClass is a graphics library which is required for Screenbar and for
many other modules, and which you should download separately if you don't
already have it. Be sure to use the newest version, as older versions may have
bugs that could make your theme unstable. Screenbar has a built-in default
configuration, so it should function immediately; by default, it will create a
panel across the bottom of each monitor. Note that since Screenbar manages
virtual desktops, it's a VWM, and you can't have more than one VWM module
loaded at a time; be sure to disable any other VWM modules such as vwm2 or
rabidvwm.

*****************************
* 2. Configuration Overview *
*****************************
When Screenbar loads, it creates top-level windows called panels. Panels may
be either floating windows or appbars. A floating window is defined by
specifying an X and Y position, width, and height; an appbar is defined by a
specifying an edge of the screen (top, bottom, left, or right), and a
thickness. Each panel has a name, which is a prefix for options affecting it.
A panel may be duplicated onto multiple monitors based on the <prefix>Monitors
setting. Screenbar also uses windows for drag windows (which follow the cursor
when performing a drag 'n drop), and for tooltips.

Each Screenbar window has a layout, which is a hierarchy of elements that
define what is shown on the panel and how it looks and behaves. Most
customization of Screenbar is done by adjusting the layout hierarchy and the
options on the elements. Each element has a name, which is used as a prefix
for options affecting it. Flow elements are the main way of positioning
things; they have other elements as children, and arrange them from left to
right or top to bottom. Children of a flow may also be duplicated for each
desk or each task; in that case, the duplicated element and its children know
which desk or task they belong to. This is called element context. Branch
elements switch between one of several children depending on RC variables and
on properties of the desk and task in the element context; this is the way to
make focused, minimized, and hovered elements look different.

Some elements, such as the system tray, may be drawn and managed by other
modules. These are child modules. Modules must specifically support being used
as child modules; modules which don't support being used this way will turn
themselves into top-level windows, and draw things on the wrong part of the
screen.

If there are a lot of tasks and/or desks open, it may happen that there isn't
enough space for the entire layout. In that case, Screenbar uses a size
fallback list, which names smaller substitutes for elements. Themes should
include a size fallback list and test what happens when opening many windows.

Screenbar includes a default configuration, which puts a panel on the bottom
edge of each monitor, and includes a layout with effects for focus, minimized
and hovered windows and desks, mouse actions and a size fallback list. When
creating a theme, you can either make incremental changes to this config, or
define your own from scratch. If you're making incremental changes, simply
define any variables you wish to change in your theme.rc. If you want to start
from scratch, set sbUseDefaultConfig to false.

********************
* 3. Bang Commands *
********************
Some bang commands refer to a desktop, monitor, or window. See the section o
Descriptions for the syntax for specifying these elements.

  !sbCloseWindow <window>
    Closes the indicated window.

  !sbCreate
    Creates a new desk containing the foreground task and switch to it. This is
    equivalent to dragging the foreground task to an unused part of the
    taskbar, or '!vwmMoveApp new'.

  !sbDestroy
    Synonym for '!sbMerge prev'

  !sbDesk <desk>
    Switch to the given desk, where <desk> is either a number (eg "!vwmDesk 1")
    or a description (eg "!vwmDesk next"). See "Desk descriptions".

  !sbGather
    Combine all desktops into one, moving all windows on screen.

  !sbMaximizeWindow <window>
    Maximizes the given window. If no window is specified, affects the
    foreground window.

  !sbMerge <desk>
    Merge the current desktop with the specified desktop, leaving one desktop
    with the windows and tasks of both.

  !sbMinimizeWindow <window>
    Minimizes the given window. If no window is specified, affects the
    foreground window.

  !sbMoveApp <window> <desk>
  !sbMoveApp <desk>
    If both arguments are given, moves the specified window to the given desk.
    If only a desk is given, moves the foreground app. In either case, the
    destination desk becomes focused.

  !sbMoveDesk <desk>
    Reorders desktops so that the current desktop is in the specified position.
    For example, "!sbMoveDesk last" moves the current desktop to the end of
    the list, while "!sbMoveDesk prev" moves the current desktop up one.

  !sbMoveWindow
    Moves the foreground window, as though you had picked 'move' from its
    system menu.

  !sbNext/!sbPrev/!sbUp/!sbDown/!sbLeft/!swnRight/!sbDown
    Switches the current desktop. These are  short for !vwmDesk with different
    parameters. See "Desk Descriptions". Up/left means prev and down/right
    means next.

  !sbOntopToggle
    Toggles whether or not Screenbar is always on top.

  !sbOpen <desk> <command>
    Switches to the given desk and then runs the given command or program.

  !sbRaiseWindow <window>
    Raises the given window to the foreground.
  
  !sbResizeWindow <window>
    Resizes the specified window, as though you had picked 'resize' from its
    system menu.

  !sbSeparate <desk>
  !sbSeparateAll
    Splits up desktops, making one desktop per window.

  !sbShow/!sbHide
    Makes Screenbar visible or invisible.

*********************************
* 4. Misc configuration options *
*********************************
4.1 Global options

  sbUseDefaultConfig [bool]
    Default: true
    Determines whether the builtin default configuration is loaded. This
    includes placement of panels and the layout hierarchy, so if this option
    is disabled, you must define the position of panels and the entire layout
    hierarchy yourself.
  
  sbKeepEmptyDesktops [bool]
  sbKeepEmptyFocusedDesktop [bool]
    Default: false
    Whether desktops with no tasks on them should be kept around (true) or
    deleted (false), depending on whether the desk in question is focused or
    not.

  sbAutoGather [bool]
    Default: true
    If true, Screenbar will gather (merge all desks) on startup. If false, it
    will attempt to preserve information about what desks tasks were on across
    a recycle.

  sbRescueOffScreenWindows [bool]
    Default: true
    If a window ends up completely off-screen for some reason, this controls
    whether Screenbar will move it back. This may cause problems for poorly
    written apps which move windows off-screen as a way to hide them.

  sbPollInterval [int]
    Default: 500
    How often Screenbar should refresh the list of windows/tasks. If set to 0,
    polling is disabled; this is not recommended as it will cause the creation of
    new windows to go unnoticed.

  sbHoverTrackingInterval [int]
    Default: 125
    How often Screenbar should check which window the mouse cursor is over.
    This is used for a highlight effect with the 'windowhovered' branch
    condition.

  sbAltTabMonitor [monitor]
    Default: cursor
    Controls which monitor is used to display a window when it's on a hidden
    desktop and you alt-tab to it.
  
  sbTrackProcesses [bool]
    Default: false
    If set, Screenbar will monitor the CPU and memory usage of running
    processes.

  sbForegroundSnapshotInterval [int]
    Default: 2000
  sbBackgroundSnapshotInterval [int]
    Default: 10000
    The intervals at which tasks will have screenshots taken, in milliseconds,
    if a snapshot layout element is visible. See the section on snapshot
    elements in the layout chapter.
    

4.2 Default theme options

These options are not used by Screenbar directly, but are conditions for
branch elements in the default configuration's layout. If you are not using
the default configuration, then these options have no effect.

  sbShowMinimaps
    Default: false
    If set, each desktop will be shown with a minimap that shows the position
    of windows on it.

  sbShowTitles
    Default: true
    If set, each task will have its title shown.

**************
* 5. Windows *
**************
5.1 Overview

Screenbar has three types of windows: panels, drag windows, and tooltips.
Panels are created on startup based on the sbPanels option. Drag windows are
created by dragging layout elements which have the <prefix>Draggable option
set. Tooltips are created by hovering the mouse over a layout element which
has the <prefix>ToolTip option set. Some options are shared, while others are
specific to one of these types.

Window options common to all window types:

  <prefix>BackgroundColor [color]
    Default: 000000 (black)
    If not transparent, the panel's background fill color.

  <prefix>RootElement [identifier]
    Mandatory setting
    The name of the root layout element which this panel is drawn with.

  <prefix>Transparent [bool]
    Default: false
    If set, areas on this window which aren't covered by elements are
    transparent.

  <prefix>Vertical [bool]
    Default: false
    Whether this window flows vertically. Affects how flow layout elements are
    arranged. Not used if this window is an appbar panel; in that case, it is
    vertical if it is on the left or right edge, and horizontal if it is on the
    top or bottom edge. Also does not apply to drag windows, which inherit this
    setting from the <prefix>Draggable element that created them.

5.2 Panels

  sbPanels [list]
    Default: sbPanel
    A space-separated list of the prefixes of all the panels that will be
    shown.

  <prefix>Monitors [monitor-set]
    Default: all
    The monitor (or monitors) on which this panel appears. Positioning options
    are relative to this monitor. If more than one monitor is specified (as
    with the default), then one panel is created for each monitor specified.

  <prefix>AlwaysOnTop [bool]
    Default: false
    Whether this panel starts out always on top.

  <prefix>X [coord]
  <prefix>Y [coord]
  <prefix>Width [coord]
  <prefix>Height [coord]
    Mandatory setting (if applicable)
    If this panel is not an appbar, sets the location and size of this panel.
    Not used if this panel is an appbar.

  <prefix>Appbar [bool]
    Default: false
    If set, makes this panel into an appbar. Rather than using the rect
    specified by <prefix>X,Y,Width,Height, it spans the edge of the screen
    given by <prefix>Edge, with a thickness of <prefix>Thickness.
  
  <prefix>Edge [left|top|right|bottom]
    Default: bottom
    If this panel is an appbar, the edge of the screen which it is docked to.
  
  <prefix>Thickness [int]
    The thickness of this panel, if it is an appbar. Ignored if it isn't.

  <prefix>AutoHide [bool]
    Default: false
    Makes this panel automatically hide itself when the cursor is not near it.
    Only available if <prefix>Appbar is true.
  
  <prefix>HideDelay [int]
    Default: 1000
    If auto-hide is enabled, the amount of time the panel remains visible
    after the cursor has moved off it, in milliseconds.
  
  <prefix>HiddenThickness [int]
    Default: 1
    The amount of the panel which is visible while it is hidden due to
    auto-hide, in pixels.

5.3 Tooltips

  <prefix>MinLength [int]
  <prefix>MaxLength [int]
    Defaults: 0, 1000
    The minimum and maximum lengths of this window. The actual length is
    determined by the root element, within these constraints.
    
  <prefix>PlacementMethod [panel|cursor]
    Default: panel
    The way in which the position of this window should be determined. If set
    to 'panel', the window is aligned to the edge of the panel which contained
    the element that's hovered over. If set to 'cursor', it is positioned a
    fixed distance above or below the cursor, and may overlap or not touch the
    panel.
    
  <prefix>Thickness [int]
    Default: 16
    The thickness of this window (height if a horizontal layout, width if
    vertical).

5.4 Drag windows

Drag windows inherit their size, root element, and vertical setting from the
element which is being dragged.

*************
* 6. Layout *
*************
6.1 Overview
The layout of Screenbar panels is defined by a hierarchy of widgets, each of
which is identified by a string which is also the prefix of all its options.
Every element must have a type, given as <prefix>Type; this defines what the
element does and looks like and what other options are available, and it is an
error to use an element without defining its type. The following options are
available for all elements, regardless of type:

  <prefix>Type
    Mandatory setting
    The element's type. See below for a listing of allowed types.

  <prefix>On<Button>Press [command]
  <prefix>On<Button>Release [command]
  <prefix>On<Button>Click [command]
    Default: none
    Button is one of "Left", "Middle", or "Right". OnPress commands run when
    the mouse is pressed, and OnRelease commands when it's released. OnPress
    and OnRelease commands run independently of (and in addition to) drag and
    drop. OnClick commands run when the button is released, but only if the
    same thing is under the mouse as when the click started, and no drag/drop
    has taken place. If the command given is a Screenbar bang command,
    'clicked' is a valid desk/task description.

  <prefix>Draggable [bool]
    Default: false
    Whether this element can be picked up and dragged around. In general, it is
    best for draggable elements to be as close to the top of the hierarchy as
    possible; in particular, draggable elements should not be the child of
    branch elements, since if conditions change and the dragged element no
    longer exists, the drag will be cancelled (possibly as soon as it begins!).

  <prefix>DragPlaceholder [element]
    Default: <prefix>
    When this element is picked up and dragged, this is the element which stays
    behind to fill its place.

  <prefix>HoverGroup [bool]
    Default: false
    If set to true, hovering over this element causes all of its children to
    count as being hovered.

  <prefix>OnHover_<element> [command]
    Default: none
    What happens when a dragged <element> is hovered over this element. If this
    is a Screenbar bang command, 'dragged' and 'hovered' are valid desk/task
    descriptions.

  <prefix>OnDrop_<element> [command]
    Default: none
    What happens when a dragged <element> is dropped on this element. If this
    is a Screenbar bang command, 'dragged' and 'hovered' are valid desk/task
    descriptions.
  
  <prefix>IsMinimizeTarget [command]
    Default: false
    If this element corresponds to a task, it will be used as the target for
    Windows' minimize/restore animation.
    
  <prefix>ToolTip [element-name]
    Default: ""
    If set, hovering the mouse cursor over this element will cause the named
    tooltip window to appear.

6.2 Element Types

The element types are
  branch   One of several children depending on a boolean expression

  flow     A series of elements arranged in sequence, optionally with copies
           for each desk or each task within a desk

  group    A set of elements named in <prefix>Elements drawn on top of
           eachother.

  icon     The icon that belongs to the context task.

  label    A text label with either a fixed string, the context desk's number,
           or the context task's window title.

  minimap  A minimap of the context desk with all its windows.
  
  module   A child module (see section 7)

  null     An empty placeholder for an element

  snapshot A scaled screenshot of the window(s) of the context task

  start    A start button

  texture  A button or decoration with an image or draw effect, drawn with
           XPaintClass.

6.3 Element Positioning

Flow, icon, minimap, module, start, and texture elements take options for
position. This can either be an X, Y, Width and Height, or an aspect ratio.

  <prefix>UseAspectRatio [bool]
    Default: false

  <prefix>AspectRatio [float]
    Default: 1.0
    If <prefix>UseAspectRatio is true, this element is positioned with an
    aspect ratio, which is its width divided by height. It will either be
    full-height or full-width, depending on the context in which it appears,
    and its aspect ratio will be as given in <prefix>AspectRatio.

  <prefix>X [coord]
    Default: 0
  <prefix>Y [coord]
    Default: 0
  <prefix>Width [coord]
    Default: -0
  <prefix>Height [coord]
    Default: -0
  
  <prefix>MinLength [int]
  <prefix>PreferredLength [int]
    Default: 0, 0
    Sets minimum and preffered lengths for this element, used to determine how
    much space is allocated for it in a flow element. Note that if width or
    height (depending on whether it's a horizontal or vertical flow) is greater
    than MinLength, that is used instead.

6.4 Branch Elements
  A branch element changes between several elements, depending on the state of
objects (windows, desks, monitors) in the context where it appears, and on
Litestep variables. A branch element is one of the elements listed in
<prefix>Branches. For each of those elements, <element-name>Condition is a
boolean expression which defines when it should be used. If several conditions
are satisfied, the first element whose conditions are satisfied is the one
used. If no condition is specified for an element, that element is always used
unless the conditions are met for an element which appears before it.
  Condition expressions may use the & (and), | (or), and ! (not) operators,
boolean RC variables (which are considered false if not defined), plus the
following keywords:

  minimized
    True if the context task is minimized.
  
  flashing
    True if the context task is flashing for attention.
  
  focused
    True if the context task's main window is focused, or if there is no
    context task and the context desk is focused.

  deskfocused
    True if the context desk is focused on any monitor.

  thismonitor
    True if the context desk is displayed on the same monitor as the panel.

  true, false
    The literal values true and false.

  dragging
    True if any element is currently being dragged
  
  hovered
    True if the cursor is over this element
  
  vertical
    True if this panel is vertical (<prefix>Vertical or an appbar on the left
    or right edge of the screen)
  
  windowhovered
    True if the cursor is over a window belonging to the context task

Litestep variables used in conditions are read once, on initialization, unless
<prefix>UpdateVars [bool] is set to true (default false), in which case they
update every time the layout is checked for changes. Operators in branch
condition expressions are right-associative; & and | have the same precedence,
but may be parenthesized.

6.5 Flow Elements
  A flow element takes a set of elements (including elements that are
duplicated for each task or desk) and arranges them relative to eachother. It
may also resize them to ensure that they all fit.

  <prefix>Elements [element-list]
    Mandatory setting
    Lists the elements to be arranged. Given as a space-separated list of
    their names.

  <prefix>Rows [int or "variable"]
    Default: 1
    The number of rows of elements in this flow. If set to variable, then the
    number of rows is determined based on <prefix>RowThickness and the geometry
    of the context the flow is in.
  
  <prefix>RowThickness [int]
    Default: 16
    If <prefix>Rows is "variable", the thickness (in pixels) of the rows in
    this flow. The number of rows will be automatically adjusted according to
    the total thickness.

  <prefix>LengthFirst [bool]
    Default: false
    If this flow has more than one row, this option indicates whether the first
    row should be filled (made as wide as it can be) before moving onto the
    second and subsequent rows.
  
  <prefix>Vertical [true|false|inherit]
    Default: inherit
    Whether this flow arranges elements vertically. By default, this setting
    is inherited from the flow or window it is nested in.

Elements can be either:

  [element]
    Where [element] is the name of another layout element, which will be
    shown inside the flow element.

  .desks([element])
    Where [element] is the name of another layout element, which will be
    shown inside the flow element and repeated for every desk. These elements
    get a context desk, which is applied recursively to all their children.
  
  .tasks([element])
    Where [element] is the name of another layout element, which will be
    shown inside the flow element and repeated for every task. These elements
    get a context task, which is applied recursively to all their children.

  [N]
    Where [N] is an integer. Inserts N pixels of empty space.

  .[N]
    Where [N] is an integer. Inserts N pixels of optional empty space, which
    may shrink or be omitted if the flow is full or close to full.

  .freeSpace
    If there is extra space left over, controls where it goes. If there is no
    .freeSpace element, leftover space is added to the end. If there is more
    than one .freeSpace element, free space is divided equally between them,
    with odd pixels going to the first ones.

6.6 Group Elements
  A group element is a set of elements listed in <prefix>Elements in order
from bottom to top. Where elements overlap, mouse events go to the topmost
one. <prefix>BaseLength adds to the element's size for flow-layout purposes.

6.7 Icon Elements
  Icon elements show the icon of the root window of the context task.

  <prefix>OffsetX [float]
  <prefix>OffsetY [float]
    Default: 0.0
    Offsets and partially clips the icon by a fraction of its size, from
    -1 (all the way up or to the left) to 1 (all the way down or to the right).
    Used mainly to indicate minimization.
  
  <prefix>UseXPaintClass [bool]
    Default: false
    If set, this icon is drawn using xPaintIcon. This enables additional
    options described in the XPaintClass documentation, at
    http://www.xdocs.ls-universe.info/dokuwiki/xpc/xpainticon

6.8 Label Elements
  A label element displays text, either a configured string or a property of
the context's desk or task. Labels have the following options:

  <prefix>AlignHoriz [left|center|right]
    Default: center
    Whether this text is left, center, or right-aligned. This alignment also
    determines the meaning of <prefix>X; the left side, center, or right side,
    respectively.
  
  <prefix>AlignVert [top|center|bottom]
    Default: center
    Whether this text is top, center, or bottom-aligned. This alignment also
    determines the meaning of <prefix>Y; the top, center, or bottom,
    respectively.

  <prefix>X [coord]
  <prefix>Y [coord]
    Where the edges of the text are. The default depends on alignment.

  <prefix>MinLength [int]
    Default: 0
    The minimum length for this text. If the text is smaller than this, it will
    be expanded and the extra space left blank.
    
  <prefix>MaxLength [int]
    Default: 250
    The maximum length for this text. If the text is larger than this, it will
    be shortened and ellipses ('...') used at the end.

  <prefix>AllowAbbrev [bool]
    Default: false
    Whether this label's text may be truncated to a length shorter than
    MaxLength to make room on the panel.
  
  <prefix>UseXStats [bool]
    Default: false
    If set, the XStatsClass module is loaded and the label's text is handled as
    an XStatsClass expression.

  <prefix>Text [string]
    Default: .auto

The label text can either be an arbitrary string, which is shown as-is, or a
special value starting with a dot.

  .auto     If in the context of a task, the same as .taskname. Otherwise,
            the same as .desknum.
  .desknum  The number of the context's virtual desktop.
  .taskname The window title of the context's task.
  .cpu      The percentage of the CPU that the context task is using. Requires
            the sbTrackProcesses option to be true.
  .mem      The amount of memory (in kb) that the context task is using.
            Requires the sbTrackProcesses option to be true.

Additionally, label elements respect all of the options supported by
XPaintClass's text renderer, which are listed in
  http://www.xdocs.ls-universe.info/dokuwiki/xpc/xPaintText
Some of the more useful of these options are <prefix>Font, <prefix>FontHeight
and <prefix>FontColor.

6.9 Minimap Elements
  A minimap element shows a tiny map of all the elements on the current desk.
This map has no background; use a texture for that. It has the following
options:
  <prefix>TitleBars [bool]
    Default: true
  <prefix>TitleBarThickness [int]
    Default: 4
  <prefix>Icons [bool]
    Default: true
  <prefix>IconSize [int]
    Default: 16
  <prefix>WinColor [color]
    Default: ffffff
  <prefix>TitleBarColor [color]
    Default: 505050
  <prefix>FocusedTitleBarColor [color]
    Default: 0000ff
  <prefix>WinBorderColor [color]
    Default: 000000

6.10 Start Button Elements
  A start button element is a button which opens a menu when clicked, and
changes its appearance depending on whether that menu is still open. The menu
is positioned such that it shares one edge with the button (the edge opposite
the edge which the panel is docked to, if it is an appbar, or which it would
be docked to, if it is not an appbar but is positioned against the edge of the
screen.) There can be more than one start menu button - eg, one on each
monitor - in which case only one of them appears pressed. 
  The !sbPopup command finds a start button element, on the same monitor as
the mouse cursor if possible, and opens its menu.

  <prefix>Command [command]
    Default: !popup
    The command that is used to open the start menu. Parameters are added to
    this for the coordinates at which the menu should open, and the edge to
    which those coordinates are aligned.

  <prefix>Raised [element]
    Mandatory setting
    The element that is drawn when the menu is not open.

  <prefix>Pressed [element]
    Default: [<prefix>Raised]
    The element that is drawn when the menu is open.

6.11 Texture Elements
  A texture element is a static image or other drawn effect. It is drawn
using XPaintClass, so all of the options given in 
  http://www.xdocs.ls-universe.info/dokuwiki/xpc/xpainttexture
apply to it. In particular, you need to set <prefix>PaintingMode, usually
to either ".singlecolor" or ".image" (though others are possible).
Additionally, this respects <prefix>X, <prefix>Y, <prefix>Width and
<prefix>Height.

6.12 Snapshot Elements
  A snapshot element displays a screenshot of a task and all its windows.
Snapshot elements only work on Windows XP or later. The variable sbCanSnapshot
is set to true if snapshots are available, false otherwise.

6.13 Module Elements
  A module element is an item drawn by another module, loaded from a DLL and
treated as a child window. For caveats and options, see the Child Modules
section of this readme.

********************
* 7. Child Modules *
********************
  Other modules can be nested inside Screenbar panels by using the 'module'
element type. Screenbar loads the module, then uses bang commands and
configuration variables to position and control it.
  Since child modules are loaded by Screenbar itself, you should not use
*NetLoadModule to load the module as you normally would. Instead, you can use
*NetInstallModule, which verifies that the module is present and ready to be
loaded, but doesn't actually load it.

  <prefix>DLL [string]
    The DLL which corresponding to the module. This should be an absolute path,
    so include $ModulesDir$ in the definition.

  <prefix>Singleton [bool]
    Default: true
    If set, only one instance of this module can be used, even if it appears
    in the layout more than once or if the layout is used for more than one
    panel.

  <prefix>Prefix [string]
    Default: ""
    The prefix which this module's configuration variables and bang commands
    start with. This is used only to fill in the defaults for the module's
    variable names and bang commands.

  <prefix>VarX [string]
  <prefix>VarY [string]
  <prefix>VarWidth [string]
  <prefix>VarHeight [string]
    Default: ""
    The names of the variables that control the module's placement and
    size. By default, these are created by appending X, Y, Width, and
    Height to the module prefix.

  <prefix>MoveCommand [command]
  <prefix>ResizeCommand [command]
    Default: ""
    The names of bang commands that move and resize the module. The new
    position or size is appended to the command when it is run. By default,
    these are created by appending Move and Resize to the module prefix. If
    the move command is incorrectly set or doesn't work, the module will start
    in the right place but will not be able to move in response to changes in
    the layout. If the resize command is incorrectly set or doesn't work, the
    module will be limited to a fixed size.
  
  <prefix>ResizedEvent [command]
    Default: ""
    The name of a bang command which Screenbar will register and which the
    child module will execute to indicate that it has resized itself, passing
    the new size as parameters.

*******************
* 8. Descriptions *
*******************
8.1 Overview
  Certain bang commands refer to desktops, windows, and monitors, which are
described by identifying some property, and in case nothing matches that
property, a second choice, third choice, and so on. Choices are separated
by slashes, so for example,
    !sbDesk next/first
will switch to the next desk and wrap around to the first desk at the end, but
    !sbDesk next/newnext
will switch to the next desk, but make a new desk rather than wrap around.

8.2 Virtual Desktops
  Wherever a bang command or variable refers to a desktop, you may choose a
desktop using one of the following descriptions. Note that there may not be
such a desktop; for example, if the last desktop is selected, then "next"
doesn't refer to anything. If no parameter is given or if none of the
described desks exists, defaults to clicked/next/prev/current. The available
descriptions are:

    [n]
      The nth desktop. Starts at 1 (there is no 0th desktop). May be any
      positive integer less than or equal to the number of desktops. If
      negative, desk -1 is the last desk, and -n is the Nth to last desk.

    prev(m), next(m)
      Where m is a monitor, or if no monitor is given, the monitor which the
      mouse cursor is on. The desktops before and after the desk which is
      visible on the indicated monitor.

    first, last
      The first and last desktops.
    
    current
      The desktop you are looking at now

    other
      The last desktop you looked at, besides the focused one

    up, left, right, down
      Synonyms for nextwrap and prevwrap provided for compatibility (up/left is
      prevwrap, down/right is nextwrap.)

    newprev(m), newnext(m), newfirst, newlast
      New desktops created in the corresponding positions. Note that empty
      desktops will be automatically deleted, so you must either put something
      on it (eg with !sbMoveApp) or set the sbKeepEmptyDesktops option.
    
    hovered
      The desk defined in the context of the element the mouse is currently
      over, if any. Undefined if the mouse is not over a panel, or if it's
      over a part of a panel which does not correspond to a desk.

    clicked
      If used in a mouse press, release, or click event handler, the desk
      which was clicked on.

    dragged, dropped
      Only meaningful inside a drag 'n drop handler when the dragged (or
      dropped-on) elements have a desk defined in their context.

8.3 Windows
  Whenever a bang command or variable refers to a window, you may choose a
window using one of the following descriptions. (These descriptions are mainly
to support mouse event handling and drag and drop).
  If a task owns more than one window, then layout elements involving it will use
the root window. Most bang commands (like !sbMoveApp) will affect the entire
task, including all its child windows.

    all(m)
      All windows on monitor m. If m is not specified, it is 'all' by default.

    tasks(m)
      All task windows on monitor m. If m is not specified, it is 'all' by
      default. Task windows are windows which would normally appear on the
      taskbar, as opposed to child windows, tool windows, etc.

    focused, foreground
      The current desk's topmost window. Note that this window doesn't have to
      actually have the focus; if a Litestep window has the focus, then the
      topmost window will still be used.
    
    topmost(m)
      The topmost window on the given monitor.

    hovered
      The task defined in the context of the hovered element, if any.
    
    clicked
      If in the context of a mouse click handler, the task which was clicked
      on.
    
    dragged dropped
      If in the context of a drag event handler, the task which is being
      dragged or being dragged onto.

8.4 Monitors
  Whenever a bang command or variable refers to a monitor, you may choose a
monitor using one of the following descriptions. When a monitor is expected
but none is specified, 'cursor' is used as the default.

    1,2,3,...
      The Nth monitor

    clicked
      The monitor that shows the panel that was clicked on

    cursor
      The monitor which the mouse cursor is currently on

    primary
      The primary monitor
    
    secondary
      The second monitor

*****************
* 9. Legalities *
*****************

Screenbar is copyright (C) 2008-2009 James Babcock. It contains code derived from
LiteStep, which is copyright (C) 1997-2009 The LiteStep Development Team.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the file license.txt for details.
