/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenbar.hpp"

/////////////////////////////////////////////////////////////////////////////

FlowChild::FlowChild(LayoutElement *childType)
{
	this->childType = childType;
}

void FlowChild::getChildren(const ElementContext *context, vector<LayoutLocation> &outChildren)
{
	LayoutLocation child;
	child.element = childType;
	child.context = *context;
	outChildren.push_back(child);
}

bool FlowChild::isConstant()
{
	return true;
}

/////////////////////////////////////////////////////////////////////////////

struct TaskListFlowChild
	:public FlowChild
{
	TaskListFlowChild(LayoutElement *element)
		:FlowChild(element)
	{}
	
	void getChildren(const ElementContext *context, vector<LayoutLocation> &outChildren)
	{
		VirtualDesktop *desk = context->desk;
		
		vector<TaskData*> tasks;
		windowTracker->getTasks(desk, tasks);
		
		vector<WindowData*> windows;
		for(unsigned ii=0; ii<tasks.size(); ii++)
			windows.push_back(tasks[ii]->getRepresentativeWindow());
		
		for(unsigned ii=0; ii<tasks.size(); ii++)
		{
			LayoutLocation child;
			child.element = childType;
			child.context = *context;
			child.context.task = windows[ii];
			outChildren.push_back(child);
		}
	}
	
	bool isConstant()
	{
		return false;
	}
};

struct DeskListFlowChild
	:public FlowChild
{
	DeskListFlowChild(LayoutElement *element)
		:FlowChild(element)
	{}
	
	void getChildren(const ElementContext *context, vector<LayoutLocation> &outChildren)
	{
		for(unsigned ii=0; ii<vwm->desktops.size(); ii++)
		{
			LayoutLocation child;
			child.element = childType;
			child.context = *context;
			child.context.desk = vwm->desktops[ii];
			outChildren.push_back(child);
		}
	}

	bool isConstant()
	{
		return false;
	}
};

/////////////////////////////////////////////////////////////////////////////

FlowElement::FlowElement(string prefix)
	:RectLayoutElement(prefix)
{
	parseChildTypes();
	
	for(unsigned ii=0; ii<childTypes.size(); ii++)
	{
		if(!childTypes[ii]->isConstant())
			childrenCanChange = true;
	}
}

FlowElement::~FlowElement()
{
	for(unsigned ii=0; ii<childTypes.size(); ii++)
		delete childTypes[ii];
}

void FlowElement::getChildren(LayoutCacheNode *node, vector<LayoutLocation> &outChildren)
{
	ElementContext childBaseContext = getChildContext(&node->context);
	
	for(unsigned ii=0; ii<childTypes.size(); ii++)
		childTypes[ii]->getChildren(&childBaseContext, outChildren);
}

void FlowElement::parseChildTypes()
{
	string childList = getConfigLine("Elements", "", prefix.c_str());
	vector<string> tokens;
	tokenizeString(childList, tokens, " \t()");
	
	for(unsigned ii=0; ii<tokens.size(); ii++)
	{
		if(tokens[ii]== ".tasks")
		{
			if(++ii >= tokens.size()) {
				string warning = string(".tasks child in ")+prefix+" requires an argument.\n";
				warn(warning.c_str());
				return;
			}
			
			LayoutElement *element = layoutPool->getElement(tokens[ii]);
			if(element)
				childTypes.push_back(new TaskListFlowChild(element));
		}
		else if(tokens[ii]==".desks")
		{
			if(++ii >= tokens.size()) {
				string warning = string(".desks child in ")+prefix+" requires an argument.\n";
				warn(warning.c_str());
				return;
			}
			
			LayoutElement *element = layoutPool->getElement(tokens[ii]);
			if(element)
				childTypes.push_back(new DeskListFlowChild(element));
		}
		else if(tokens[ii]==".freeSpace")
		{
			LayoutElement *spacerElement = layoutPool->getSpacerElement(0, true, true);
			childTypes.push_back(new FlowChild(spacerElement));
		}
		else if(isdigit(tokens[ii][0]))
		{
			int length = atoi(tokens[ii].c_str());
			LayoutElement *spacerElement = layoutPool->getSpacerElement(length, false, false);
			childTypes.push_back(new FlowChild(spacerElement));
		}
		else if(tokens[ii].length()>1 && tokens[ii][0]=='.' && isdigit(tokens[ii][1]))
		{
			int length = atoi(tokens[ii].c_str()+1);
			LayoutElement *spacerElement = layoutPool->getSpacerElement(length, true, false);
			childTypes.push_back(new FlowChild(spacerElement));
		}
		else
		{
			LayoutElement *element = layoutPool->getElement(tokens[ii]);
			if(element)
				childTypes.push_back(new FlowChild(element));
		}
	}
}
