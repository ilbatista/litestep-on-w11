/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenbar.hpp"

static const char *windowClassName = "screenbar";
static const char *windowName = "Screenbar";

#define GWL_CLASSPOINTER 0

struct EventArg
{
	SHORT size;
	ScreenbarWindow *window;
};

static WNDCLASSEX windowClass;

HDC ScreenbarWindow::fakeBackBuffer = NULL;
HBITMAP ScreenbarWindow::placeholderBmp = NULL;
HBITMAP ScreenbarWindow::oldBmp = NULL;

/////////////////////////////////////////////////////////////////////////////

ScreenbarWindow::ScreenbarWindow(string prefix, Monitor *monitor)
{
	this->prefix = prefix;
	this->monitor = monitor;
	this->layout = NULL;
	this->window = NULL;
	
	transparent = getConfigBool("Transparent", false, prefix.c_str());
	if(transparent) {
		fillColor = Gdiplus::Color(255, 255,0,255);
	} else {
		COLORREF backgroundColor = getConfigColor("BackgroundColor", 0,0,0, prefix.c_str());
		int r = 0xFF & (backgroundColor >> 0);
		int g = 0xFF & (backgroundColor >> 8);
		int b = 0xFF & (backgroundColor >> 16);
		fillColor = Gdiplus::Color(r, g, b);
	}
}

ScreenbarWindow::~ScreenbarWindow()
{
	delete layout;
	DestroyWindow(window);
}

HWND ScreenbarWindow::initWindow(DWORD style, HWND parent)
{
	EventArg arg = {sizeof(EventArg), this};
	
	int flags = WS_EX_TOOLWINDOW;
	if(transparent)
		flags |= WS_EX_LAYERED;
	
	window = CreateWindowEx(
		flags,
		windowClassName,
		windowName,
		style,
		visibleRect.left, visibleRect.top, visibleRect.width, visibleRect.height,
		parent,
		NULL, dllInstance, &arg);
	
	if(fakeBackBuffer == NULL)
	{
		HDC windowDC = GetDC(window);
		fakeBackBuffer = CreateCompatibleDC(windowDC);

		placeholderBmp = CreateCompatibleBitmap(windowDC, 1, 1);
		oldBmp = (HBITMAP)SelectObject(fakeBackBuffer, placeholderBmp);

		ReleaseDC(window, windowDC);
	}
	
	if(!window)
		throw std::exception("Failed to create window");
	
	// Mark this window as 'belonging to Litestep' so that we don't try to operate on ourself
	SetWindowLongPtr(window, GWLP_USERDATA, magicDWord);
	
	if(transparent)
	{
		SetLayeredWindowAttributes(window, RGB(255,0,255), 255, LWA_COLORKEY);
	}
	
	return window;
}

void ScreenbarWindow::initLayout(const ElementContext *context)
{
	string rootElementName = getConfigString("RootElement", NULL, prefix.c_str());
	LayoutElement *rootElement = layoutPool->getElement(rootElementName);
	
	if(!rootElement)
		throw std::exception("Invalid or missing root element");
	
	string sizeFallbacks = getConfigLine("SizeFallbacks", "", prefix.c_str());
	
	layout = new Layout(
		rootElement,
		*context,
		visibleRect,
		sizeFallbacks);
}

void ScreenbarWindow::adjustWindowPos()
{
	SetWindowPos(window, 0,
		visibleRect.left, visibleRect.top, visibleRect.width, visibleRect.height,
		SWP_NOZORDER | SWP_NOACTIVATE);
	
	layout->setRect(visibleRect);
	layout->update();
}

void ScreenbarWindow::show()
{
	ShowWindow(window, SW_SHOWNOACTIVATE);
}

LRESULT ScreenbarWindow::handleEvent(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
		case UMSG_REFRESHLAYOUT:
			if(layout->update()) {
				InvalidateRect(window, NULL, FALSE);
				//repaint();
			}
			return 1;
			
		default:
			return vwm->windowProc(window, uMsg, wParam, lParam);
	}
}

/////////////////////////////////////////////////////////////////////////////

void ScreenbarWindow::registerWindowClass()
{
	memset(&windowClass, 0, sizeof(WNDCLASSEX));
	windowClass.cbSize = sizeof(WNDCLASSEX);
	windowClass.cbWndExtra = sizeof(VWM*);
	windowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	windowClass.lpfnWndProc = ScreenbarWindow::eventHandler;
	windowClass.hInstance = dllInstance;
	windowClass.lpszClassName = windowClassName;

	if (!RegisterClassEx(&windowClass)) {
		// Class could not be registered, try to re-register
		UnregisterClass(windowClassName, dllInstance);

		if (!RegisterClassEx(&windowClass)) {
			// Still no luck, error out
			fatal("Unable to register tooltip window class.");
		}
	}
}

void ScreenbarWindow::unregisterWindowClass()
{
	if(fakeBackBuffer != NULL) {
		SelectObject(fakeBackBuffer, oldBmp);
		DeleteObject(placeholderBmp);
		DeleteDC(fakeBackBuffer);
		fakeBackBuffer = NULL;
	}

	UnregisterClass(windowClassName, dllInstance);
}

LRESULT CALLBACK ScreenbarWindow::eventHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(uMsg == WM_NCCREATE)
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	
	if (uMsg == WM_CREATE) {
		LPVOID &createParams = LPCREATESTRUCT(lParam)->lpCreateParams;

		if (createParams) {
			ScreenbarWindow *window = ((EventArg*)createParams)->window;
			SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)window);
		}
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	
	ScreenbarWindow *window = (ScreenbarWindow*)(GetWindowLong(hWnd, GWL_CLASSPOINTER));
	if(!window) return DefWindowProc(hWnd, uMsg, wParam, lParam);
	
	return window->handleEvent(uMsg, wParam, lParam);
}

/////////////////////////////////////////////////////////////////////////////

void ScreenbarWindow::checkForUpdates()
{
	if(!layout)
		return;
	if(layout->update())
		forceRedraw();
}

string ScreenbarWindow::getPrefix()
	{ return prefix; }
Layout *ScreenbarWindow::getLayout()
	{ return layout; }
HWND ScreenbarWindow::getWindow()
	{ return window; }
Rect ScreenbarWindow::getRect()
	{ return visibleRect; }
Point ScreenbarWindow::getTopLeft()
	{ return visibleRect.topLeft(); }
Monitor *ScreenbarWindow::getMonitor()
	{ return monitor; }
