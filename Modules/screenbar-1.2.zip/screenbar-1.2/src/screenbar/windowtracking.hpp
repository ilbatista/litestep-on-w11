/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

/// Cached information about a window which we're keeping track of. Windows
/// can disappear, move, or change properties at any time (they have threads/
/// wills of their own!), sometimes without us noticing, so there's no
/// guarantee that this information isn't stale.
class WindowData
{
public:
	WindowData(HWND handle);
	~WindowData();
	
	bool updateCachedProperties();
	void updateIcon();
	
	void minimize();
	void maximize();
	void restore();
	
	string getTitle();
	bool isFocused();
	bool isFocusedTask();
	bool isMinimized();
	HICON getIcon(int size);
	bool getIsTask();
	
	//
	// Base properties
	//
	HWND handle;   // The handle to this window
	DWORD pid;     // The pid of the process which owns this window
	
	//
	// Cached properties
	//
	Rect lastScreenPos;
	bool minimized;
	/// If this is a popup window, this is its parent (if it has one) or owner
	/// (if it has one). If it's unowned or not a popup, this is NULL.
	HWND parent;
	/// Whether this window should appear on the taskbar. (Either it has
	/// WS_EX_APPWINDOW or no other window could be found which is responsible
	/// for it).
	bool isTask;
	/// Whether this is a popup window; that is, it has WS_POPUP set. Affects
	/// how this window is displayed on the minimap.
	bool isPopup;
	
	//
	// WindowTracker-controlled properties
	//
	/// The virtual desktop this window is currently on
	VirtualDesktop *desk;
	/// The task which this window is part of
	TaskData *task;
	/// Whether this window is flashing for attention
	bool flashing;
	
	//
	// Flags
	//
	/// Keeps this window from being moved
	bool tempSticky;
	/// A flag for temporary use
	bool visited;
	
protected:
	HICON getTaskIconWithSize(HWND window, bool big, int timeout);
	HICON getTaskIcon(HWND window, bool preferBig, int timeout);
	
	HICON bigIcon;
	HICON smallIcon;
};

bool isWindowMinimized(HWND window, const Rect *screenRect);
