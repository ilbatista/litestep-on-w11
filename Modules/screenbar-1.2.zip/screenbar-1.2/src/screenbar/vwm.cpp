/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenbar.hpp"

//=========================================================
// VWM miscellaneous
//=========================================================
VWM::VWM(HWND parentWindow)
{
	updateNextDraw = false;
	lastFocus = NULL;
	this->parentWindow = parentWindow;
	this->hoverTrackingEnabled = false;
	this->hoveredWindow = 0;
}

VWM::~VWM()
{
}

VirtualDesktop *VWM::getDeskFromWnd(HWND handle)
{
	if(!handle)
		return NULL;
	
	WindowData *window = windowTracker->getWindow(handle);
	if(window)
		return window->desk;
	
	RECT screenPos;
	GetWindowRect(handle, &screenPos);
	VirtualDesktop *desk = deskFromLocation(screenPos);
	if(desk)
		return desk;
	else
		return monitors->getPrimaryMonitor()->getDesk();
}

RECT VWM::getGatherTarget(RECT source, Monitor *targetMonitor)
{
	Rect ret = source;
	Rect maximizeArea = targetMonitor->getMaximizeArea();
	
	// If this is inside a VWM's storage area, first bring it in
	VirtualDesktop *desk = deskFromLocation(source);
	if(desk)
		desk->currentSlot()->unstoreRect(ret);
	targetMonitor->storeRect(ret);
	
	int offsetX=0;
	int offsetY=0;
	
	// If a window is wider or taller than the screen, center it. Otherwise,
	// match an edge. (This happens more often than you'd think, because
	// maximized windows are a few pixels bigger than the maximize-area so
	// that their borders fall offscreen.)
	if(ret.width > maximizeArea.width) {
		if(ret.left > maximizeArea.left || ret.getRight() < maximizeArea.getRight())
			ret.left = maximizeArea.left - (ret.width-maximizeArea.width)/2;
	} else if(ret.getRight() > maximizeArea.getRight()) {
		ret.left -= ret.getRight() - maximizeArea.getRight();
	} else if(ret.left < maximizeArea.left) {
		ret.left = maximizeArea.left;
	}
	
	if(ret.height > maximizeArea.height) {
		if(ret.top > maximizeArea.top || ret.getBottom() < maximizeArea.getBottom())
			ret.top = maximizeArea.top - (ret.height-maximizeArea.height)/2;
	} else if(ret.getBottom() > maximizeArea.getBottom()) {
		ret.top += maximizeArea.getBottom() - ret.getBottom();
	} else if(ret.top < maximizeArea.top) {
		ret.top = maximizeArea.top;
	}
	
	return ret;
}

VirtualDesktop *VWM::deskFromLocation(Rect pos)
{
	// If it's on-screen, it's on the focused desk
	vector<Monitor*> monitorsShownOn = monitors->findMonitor(pos);
	if(monitorsShownOn.size())
		return monitorsShownOn[0]->getDesk();
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		Rect storageRect = desk->getOffScreenStorage()->getRect();
		if(storageRect.overlaps(pos)) {
			return desk;
		}
	}
	
	return NULL;
}

void VWM::createDesktop()
{
	VirtualDesktop *newDesk = new VirtualDesktop(desktops.size(), storageManager.getStorageArea());
	desktops.push_back(newDesk);
	
	WindowData *foreground = windowTracker->getForegroundWindow();
	if(!foreground) {
		windowTracker->raiseLocalForeground();
		foreground = windowTracker->getForegroundWindow();
	}
	
	if(foreground)
		moveApp(foreground, newDesk);
}

bool VWM::destroyDesktop(VirtualDesktop *desk)
{
	// If there's only one desktop per monitor left, it can't be destroyed
	if((int)desktops.size()<=monitors->numMonitors())
		return false;
	
	// Pick a desktop to move windows to. Takes the numerically nearest
	// non-visible desk, ties going to the left.
	VirtualDesktop *mergeTarget = NULL;
	int bestDistance = -1;
	
	for(int ii=0; ii<(int)desktops.size(); ii++)
	{
		if(desk->monitor && desktops[ii]->monitor)
			continue;
		if(desktops[ii] == desk)
			continue;
		int distance = abs(desktops[ii]->index - desk->index);
		if(bestDistance==-1 || distance<bestDistance) {
			mergeTarget = desktops[ii];
			bestDistance = distance;
		}
	}
	
	if(!mergeTarget)
		return false;
	
	return mergeDesk(desk, mergeTarget);
}

bool VWM::mergeDesk(VirtualDesktop *deletedDesktop, VirtualDesktop *mergeTarget)
{
	// Can't merge a desk with itself
	if(deletedDesktop == mergeTarget)
		return false;
	
	// Can't merge if the result would be fewer desks than monitors
	if((int)desktops.size() <= monitors->numMonitors())
		return false;
	
	beginMovingWindows();
	
	// If deleting the current desktop, the merge target becomes the current desktop
	vector<WindowData*> windows;
	windowTracker->getWindows(deletedDesktop, windows);
	
	if(deletedDesktop->monitor && !mergeTarget->monitor)
	{
		mergeTarget->show(deletedDesktop->monitor);
		mergeTarget->monitor = deletedDesktop->monitor;
		deletedDesktop->monitor->setDesk(mergeTarget);
	}
	else if(mergeTarget->monitor && !deletedDesktop->monitor)
	{
		deletedDesktop->show(mergeTarget->monitor);
		mergeTarget->monitor->setDesk(mergeTarget);
	}
	else if(mergeTarget->monitor && deletedDesktop->monitor)
	{
		// If both the deleted and target desks are visible, bail.
		// (This could be slightly more graceful.)
		return false;
	}
	else
	{
		for(unsigned ii=0; ii<windows.size(); ii++)
			deletedDesktop->moveWindowTo(windows[ii], mergeTarget);
	}
	
	for(unsigned ii=0; ii<windows.size(); ii++)
		windows[ii]->desk = mergeTarget;
	
	finishMovingWindows();
	
	// Remove the deleted desktop from the desk list and update everyone's indices
	desktops.erase(desktops.begin()+deletedDesktop->index);
	
	delete deletedDesktop;
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
		desktops[ii]->index = ii;
	
	
	// Clean up other possible references to the deleted desk
	if(lastDesktop == deletedDesktop)
		lastDesktop = NULL;
	
	forceTrackerUpdate();
	updateLayouts();
	return true;
}

void VWM::separateDesk(VirtualDesktop *desk)
{
	// If no desk specified, separate *every* desk
	if(!desk)
	{
		vector<VirtualDesktop*> originalDesks;
		originalDesks.insert(originalDesks.begin(), desktops.begin(), desktops.end());
		
		for(unsigned ii=0; ii<originalDesks.size(); ii++)
			separateDesk(originalDesks[ii]);
		return;
	}
	
	// Create new desktops for all but one of the tasks in this desk. The last
	// task stays on the original desktop.
	vector<VirtualDesktop*> newDesks;
	
	// Get the task list
	map<WindowData*, VirtualDesktop*> destinations;
	vector<TaskData*> tasks;
	windowTracker->getTasks(desk, tasks);
	
	// Decide which of the tasks uses the pre-existing desktop, and gets
	// switched to (if the split desk was visible)
	TaskData *foregroundTask = windowTracker->getForegroundTask();
	int foregroundTaskIndex = 0;
	for(unsigned ii=0; ii<tasks.size(); ii++)
	{
		if(tasks[ii] == foregroundTask) {
			foregroundTaskIndex = ii;
			break;
		}
	}
	
	// Create new desktops and decide which windows are going to which desktop
	for(unsigned ii=0; ii<tasks.size(); ii++)
	{
		VirtualDesktop *destination;
		if(ii==foregroundTaskIndex) {
			destination = desk;
		} else {
			destination = new VirtualDesktop(0, storageManager.getStorageArea());
		}
		newDesks.push_back(destination);
		
		vector<WindowData*> windows;
		tasks[ii]->getWindows(windows);
		for(unsigned jj=0; jj<windows.size(); jj++)
			destinations[windows[jj]] = destination;
	}
	
	// Insert desktops and set their indices
	desktops.insert(desktops.begin()+desk->index,
	                newDesks.begin(),
	                newDesks.begin()+foregroundTaskIndex);
	desktops.insert(desktops.begin()+desk->index+foregroundTaskIndex+1,
	                newDesks.begin()+foregroundTaskIndex+1,
	                newDesks.end());
	for(unsigned ii=desk->index; ii<desktops.size(); ii++)
		desktops[ii]->index = ii;
	
	// Move windows to their new destinations
	beginMovingWindows();
	for(map<WindowData*, VirtualDesktop*>::iterator ii=destinations.begin(); ii!=destinations.end(); ii++)
		moveWindow(ii->first, ii->second);
	finishMovingWindows();
	
	forceTrackerUpdate();
	updateLayouts();
}

void VWM::moveDesk(int oldIndex, int newIndex)
{
	if(oldIndex<0 || newIndex<0 || oldIndex>=(int)desktops.size() || newIndex>=(int)desktops.size())
		return;
	
	VirtualDesktop *movingDesk = desktops[oldIndex];
	desktops.erase(desktops.begin()+oldIndex);
	desktops.insert(desktops.begin()+newIndex, movingDesk);
	
	int start = min(oldIndex, newIndex);
	int end = max(oldIndex, newIndex);
	for(int ii=start; ii<=end; ii++)
		desktops[ii]->index = ii;
	
	updateLayouts();
}

void VWM::switchDesk(VirtualDesktop *newDesk, Monitor *switchingMonitor, bool skipFocus)
{
	if(!newDesk)
		return;
	if(!switchingMonitor)
		switchingMonitor = monitors->findMonitor(getCursorPos());
	VirtualDesktop *oldDesk = switchingMonitor->getDesk();
	if(newDesk == oldDesk)
		return;
	
	Monitor *swapMonitor = NULL;
	if(newDesk->monitor)
		swapMonitor = newDesk->monitor;
	
	beginMovingWindows();
	
	if(swapMonitor)
	{
		oldDesk->switchWith(newDesk);
	}
	else
	{
		oldDesk->hide();
		newDesk->show(switchingMonitor);
	}
	
	finishMovingWindows();
	
	lastDesktop = oldDesk;
	
	// Pick the topmost task on this desktop and focus it
	if(!skipFocus)
		windowTracker->raiseLocalForeground();
	
	forceTrackerUpdate();
	updateLayouts();
}

void VWM::moveWindow(WindowData *window, VirtualDesktop *desk)
{
	if(desk == window->desk)
		return;
	
	transferWindow(window, window->desk->currentSlot(), desk->currentSlot());
	window->desk = desk;
}

void VWM::raiseWindow(WindowData *window)
{
	SwitchToThisWindow(window->handle, TRUE);
	vwm->lastFocus = NULL;
	
	forceTrackerUpdate();
	updateLayouts();
}

void VWM::gather()
{
	Monitor *gatherTarget = monitors->getPrimaryMonitor();
	
	beginMovingWindows();
	
	// Move everything onto the current desktop
	vector<WindowData*> windows;
	windowTracker->getWindows(NULL, windows);
	for(unsigned ii=0; ii<windows.size(); ii++)
	{
		WindowData *window= windows[ii];
		
		transferWindow(window, window->desk->currentSlot(), gatherTarget);
		window->desk = gatherTarget->getDesk();
	}
	
	finishMovingWindows();
	
	// Delete all other desktops
	for(unsigned ii=0; ii<desktops.size(); )
	{
		if(!desktops[ii]->monitor) {
			delete desktops[ii];
			desktops.erase(desktops.begin()+ii);
		} else {
			desktops[ii]->index = ii;
			ii++;
		}
	}
	
	forceTrackerUpdate();
	updateLayouts();
}

void VWM::moveApp(WindowData *representative, VirtualDesktop *dest)
{
	if(!dest || !representative)
		return;
	
	TaskData *task = representative->task;
	VirtualDesktop *sourceDesk = representative->desk;
	
	// Find all the windows affected
	vector<WindowData*> movedWindows;
	task->getWindows(sourceDesk, movedWindows);
	
	// If the destination desk is already visible, or the source desk is
	// hidden, then we don't need to switch desk.
	if(dest->monitor || !sourceDesk->monitor)
	{
		beginMovingWindows();
		for(unsigned ii=0; ii<movedWindows.size(); ii++)
			moveWindow(movedWindows[ii], dest);
		finishMovingWindows();
	}
	// Otherwise, we need to switch to showing the destination desk, without
	// moving the moved windows.
	else
	{
		for(unsigned ii=0; ii<movedWindows.size(); ii++)
			movedWindows[ii]->tempSticky = true;
		
		switchDesk(dest, sourceDesk->monitor, true);
		
		for(unsigned ii=0; ii<movedWindows.size(); ii++)
		{
			movedWindows[ii]->desk = dest;
			movedWindows[ii]->tempSticky = false;
		}
	}
}

TaskData *VWM::getHoveredTask()
{
	if(!hoveredWindow) return NULL;
	WindowData *window = windowTracker->getWindow(hoveredWindow);
	if(!window) return NULL;
	return window->task;
}

void VWM::enableHoverTracking()
{
	hoverTrackingEnabled = true;
}

void VWM::updateHover()
{
	if(!hoverTrackingEnabled)
		return;
	Point cursorPos = getCursorPos();
	
	HWND newHoveredWindow = WindowFromPoint(cursorPos);
	while(1) {
		HWND parent = GetParent(newHoveredWindow);
		if(!parent) break;
		newHoveredWindow = parent;
	}
	
	if(newHoveredWindow != hoveredWindow)
	{
		hoveredWindow = newHoveredWindow;
		for(unsigned ii=0; ii<panels.size(); ii++)
			panels[ii]->checkForUpdates();
	}
}

LayoutReference *VWM::findLayoutNodeMatching(Monitor *preferredMonitor, bool (*condition)(LayoutCacheNode*, void*), void *param)
{
	for(unsigned ii=0; ii<panels.size(); ii++)
	{
		ScreenbarPanel *panel = panels[ii];
		if(panel->getMonitor() == preferredMonitor)
		{
			vector<LayoutCacheNode*> layoutNodes;
			Layout *layout = panel->getLayout();
			if(layout)
			{
				LayoutReference *ref = layout->findNodeMatching(condition, param);
				if(ref) return ref;
			}
		}
	}

	for(unsigned ii=0; ii<panels.size(); ii++)
	{
		ScreenbarPanel *panel = panels[ii];
		if(panel->getMonitor() != preferredMonitor) {
			vector<LayoutCacheNode*> layoutNodes;
			Layout *layout = panel->getLayout();
			if(layout)
			{
				LayoutReference *ref = layout->findNodeMatching(condition, param);
				if(ref) return ref;
			}
		}
	}
	
	return NULL;
}
