/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

#define PROJECT_NAME "screenbar"
#define VERSION_STRING PROJECT_NAME " 1.2"

/// This is a basically arbitrary number which identifies this module for
/// purposes of saving/restoring Litestep state; the only requirement is that
/// it be in the range if an unsigned short and not be the same as any other
/// Litestep module. So this was basically chosen at random. And yes, it's
/// entirely possible that there is a collision I don't know about (it should
/// only take 256 modules before E(collisions)=1).
#define MODULE_ID 0xC153

#define _WIN32_WINNT 0x0501
#define WINVER 0x0501

#include "../lib/xpaintclass/lsapi/lsapi.h"

#define LM_REPAINT       8890
#define LM_BRINGTOFRONT  8891
#define LM_SWITCHTON     9355
#define LM_LISTDESKTOPS  9359
#define LM_DESKTOPINFO   9360
#define LM_GETDESKTOPOF  9361

#define magicDWord       0x49474541

typedef struct LSDESKTOPINFO
{
	int size;
	char name[32];
	HICON icon;
	BOOL isCurrent;
	int number;
}
LSDESKTOPINFO;

#define MAX_LINE_LENGTH 4096

#pragma warning (disable: 4800) // Conversion from int to bool
#pragma warning (disable: 4244) // Implicit conversion from int to float

#include <vector>
using std::vector;
#include <map>
using std::map;
using std::pair;
#include <string>
using std::string;
#include <set>
using std::set;
#include <exception>
using std::exception;
#include <assert.h>
#include <sstream>

#include <gdiplus.h>

#include "classproto.hpp"

#include "bangs.hpp"
#include "paintclass.hpp"
#include "wrappingflow.hpp"
#include "util.hpp"
#include "rcsettings.hpp"
#include "windowstorage.hpp"
#include "windowtracking.hpp"
#include "layout.hpp"
#include "branch.hpp"
#include "layoutcache.hpp"
#include "elements.hpp"
#include "childmodule.hpp"
#include "flow.hpp"
#include "trace.hpp"
#include "virtualdesktop.hpp"
#include "sbwindow.hpp"
#include "sbpanel.hpp"
#include "vwm.h"
#include "dragndrop.hpp"
#include "monitor.hpp"
#include "fallbackselector.hpp"
#include "windowtracker.hpp"
#include "sizefallback.hpp"
#include "processtracker.hpp"
#include "snapshot.hpp"
#include "tooltip.hpp"

extern HINSTANCE dllInstance;
extern string modulePath;

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

string statsClassEval(string str, const ElementContext *context);
