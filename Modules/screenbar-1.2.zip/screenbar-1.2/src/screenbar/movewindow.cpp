/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenbar.hpp"


void VWM::setWindowPos(WindowData *window, const Rect &pos)
{
	movedWindows[window] = pos;
}

void VWM::beginMovingWindows()
{
	movedWindows.clear();
}

void VWM::transferWindow(WindowData *window, DeskSlot *source, DeskSlot *dest)
{
	RECT screenRect;
	GetWindowRect(window->handle, &screenRect);
	Rect screenPos = screenRect;
	
	dest->transferFrom(screenPos, source);
	setWindowPos(window, screenPos);
}

void VWM::finishMovingWindows()
{
	if(!movedWindows.size())
		return;
	
	HDWP windowMover = BeginDeferWindowPos(movedWindows.size());

	for(map<WindowData*,Rect>::iterator ii=movedWindows.begin(); ii!=movedWindows.end(); ii++)
	{
		WindowData *window = ii->first;
		Rect newPos = ii->second;
		DeferWindowPos(windowMover, window->handle, NULL,
		               newPos.left, newPos.top,
		               0, 0,
		               SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
	}
	
	for(map<WindowData*,Rect>::iterator ii=movedWindows.begin(); ii!=movedWindows.end(); ii++)
	{
		WindowData *window = ii->first;
		
		WINDOWPLACEMENT placement;
		placement.length = sizeof(placement);
		GetWindowPlacement(window->handle, &placement);
		
		// Maximized windows need some special handling when moving
		if(placement.showCmd == SW_MAXIMIZE)
		{
			VirtualDesktop *desk = getDeskFromWnd(window->handle);
			
			if(desk && desk->monitor) {
				// Set the position the window will go to when restored
				// (unmaximized) to be on the correct monitor
				Rect restoredPos = placement.rcNormalPosition;
				
				vector<Monitor*> overlappingMonitors = monitors->findMonitor(restoredPos);
				if(overlappingMonitors.size())
				{
					Monitor *oldMonitor = overlappingMonitors[0];
					Monitor *newMonitor = desk->monitor;
					newMonitor->transferFrom(restoredPos, oldMonitor);
					placement.rcNormalPosition = restoredPos;
					
					SetWindowPlacement(window->handle, &placement);
				}
			}
			
			// Clear the window's clip region
			// This might break some apps, and it definitely causes window
			// borders to show accross monitors where they shouldn't, but
			// not doing this means that a maximized window which moves between
			// monitors becomes invisible.
			SetWindowRgn(window->handle, NULL, FALSE);
		}
	}

	EndDeferWindowPos(windowMover);

	movedWindows.clear();
}

VirtualDesktop *VWM::rescueOffscreenWindow(WindowData *window, Rect *pos)
{
	Monitor *targetMonitor = monitors->getPrimaryMonitor();
	
	if(!settings->rescueOffScreenWindows)
		return targetMonitor->getDesk();
	if(isWindowMinimized(window->handle, pos))
		return targetMonitor->getDesk();
	
	trace<<"Rescued off-screen window from "<<*pos<<": "<<window->getTitle()<<".\n";
	*pos = getGatherTarget(*pos, targetMonitor);
	
	beginMovingWindows();
		setWindowPos(window, *pos);
	finishMovingWindows();
	
	return targetMonitor->getDesk();
}
