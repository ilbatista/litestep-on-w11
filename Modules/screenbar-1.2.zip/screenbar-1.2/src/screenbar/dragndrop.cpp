/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenbar.hpp"

DragInfo *drag = NULL;
DragWindow *dragWindow = NULL;
LayoutReference *droppedContext = NULL;

DragInfo::DragInfo(LayoutReference *origin, int x, int y, MouseButton button)
{
	this->origin = origin;
	this->lastHover = NULL;
	
	LayoutCacheNode *node = origin->getNode();
	
	this->element = node->element;
	this->elementContext = node->context;
	this->button = button;
	this->mouseOrigin = Point(x, y);
	
	active = false;
	mouseOffset.x = x - node->boundingRect.left;
	mouseOffset.y = y - node->boundingRect.top;
}

DragInfo::~DragInfo()
{
	if(origin)
		delete origin;
	if(lastHover)
		delete lastHover;
}

void ScreenbarPanel::finishDrag()
{
	if(!drag) {
		cancelDrag();
		return;
	}
	
	Point mousePos = getCursorPos();
	ScreenbarPanel *targetPanel = vwm->findPanel(mousePos.x, mousePos.y);
	
	// TODO: Handle drags that don't end on a panel
	if(!targetPanel) {
		cancelDrag();
		return;
	}
	
	mousePos.x -= targetPanel->visibleRect.left;
	mousePos.y -= targetPanel->visibleRect.top;
	
	targetPanel->dropDraggedObject(drag->element->prefix, mousePos.x, mousePos.y);
	
	cancelDrag();
}

void ScreenbarPanel::dropDraggedObject(string droppedObjName, int x, int y)
{
	LayoutReference *ref = layout->elementAtPoint(x, y);
	if(!ref) return;
	
	LayoutCacheNode *node = ref->getNode();
	if(!node)  {
		delete ref;
		return;
	}
	
	string suffix = string("OnDrop_") + droppedObjName;
	node = node->findSuffix(suffix);
	if(!node) return;
	
	string varname = node->element->prefix+suffix;
	string dropCmd = getConfigLine(varname.c_str(), "", "");
	
	droppedContext = ref;
	LSExecute(window, dropCmd.c_str(), SW_SHOWNORMAL);
	delete ref;
	droppedContext = NULL;
}

void ScreenbarPanel::hoverDraggedObject(string hoveredObjName, int x, int y)
{
	LayoutReference *ref = layout->elementAtPoint(x, y);
	if(!ref) return;
	
	LayoutCacheNode *node = ref->getNode();
	delete ref;
	if(!node) return;
	
	string suffix = string("OnHover_") + hoveredObjName;
	node = node->findSuffix(suffix);
	if(!node) return;
	
	if(drag->lastHover && drag->lastHover->getNode()==node)
		return;
	
	delete drag->lastHover;
	drag->lastHover = layout->getReferenceTo(node);
	
	string varname = node->element->prefix+suffix;
	string hoverCmd = getConfigLine(varname.c_str(), "", "");
	
	LSExecute(window, hoverCmd.c_str(), SW_SHOWNORMAL);
}

void ScreenbarPanel::cancelDrag()
{
	SetCapture(NULL);
	if(drag) {
		delete drag;
		drag = NULL;
	}
	if(dragWindow) {
		delete dragWindow;
		dragWindow = NULL;
	}
}

void ScreenbarPanel::beginDrag()
{
	if(!drag || !drag->origin)
		return;
	if(drag->active)
		return;
	
	LayoutCacheNode *node = drag->origin->getNode();
	if(!node) {
		cancelDrag();
		return;
	}
	
	drag->active = true;
	dragWindow = new DragWindow(node, drag->mouseOffset);
	
	vwm->updateLayouts();
}

/////////////////////////////////////////////////////////////////////////////

DragWindow::DragWindow(LayoutCacheNode *sourceNode, Point mouseOffset)
	:ScreenbarWindow(getElementName(sourceNode), sourceNode->context.window->getMonitor())
{
	this->mouseOffset = mouseOffset;
	
	// Bug: if the dragElement has a different size, it will be clipped
	//      to this.
	ElementContext context = sourceNode->context;
	context.window = this;
	Rect boundingRect = sourceNode->boundingRect;
	boundingRect.left = 0;
	boundingRect.top = 0;
	
	// If the element which is being dragged defines a substitute for itself
	// to be used when dragging, use it.
	LayoutElement *rootElement = sourceNode->element->dragElement;
	if(!rootElement)
		rootElement = sourceNode->element;
	
	// Build a layout tree (from scratch).
	// TODO/FIXME: Think about what to do when branch conditions and flow
	// contents change mid-drag. In particular, we can't leave references to
	// closed windows lying around.
	//layout = rootElement->buildLayout(&elementContext, NULL);
	layout = new Layout(rootElement, context, boundingRect, "");
	layout->update();
	
	// Bug: if the dragElement has a different size, it will be clipped
	//      to this.
	width  = boundingRect.width;
	height = boundingRect.height;
	Point mousePos = getCursorPos();
	int x = mousePos.x - mouseOffset.x;
	int y = mousePos.y - mouseOffset.y;
	visibleRect = Rect(x, y, width, height);
	
	HWND parentWindow = GetDesktopWindow();
	initWindow(WS_POPUP, parentWindow);
	
	SetTimer(window, TIMER_DRAGFOLLOW, 50, NULL);
	
	SetWindowPos(window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	show();
}

DragWindow::~DragWindow()
{
	KillTimer(window, TIMER_DRAGFOLLOW);
}

string DragWindow::getElementName(LayoutCacheNode *sourceNode)
{
	string sourceElementPrefix = sourceNode->element->prefix;
	
	string dragWindowName = getConfigString("DragElement", "", sourceElementPrefix.c_str());
	if(dragWindowName=="")
		dragWindowName = sourceElementPrefix;
	
	return dragWindowName;
}

LRESULT DragWindow::handleEvent(UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_TIMER:
			followCursor();
			return 0;
			
		case WM_PAINT: {
			PAINTSTRUCT ps;
			HDC windowDrawContext = BeginPaint(window, &ps);
			repaint(windowDrawContext);
			EndPaint(window, &ps);
			return 0;
		}
			
		default:
			return ScreenbarWindow::handleEvent(msg, wParam, lParam);
	}
	
	return 1;
}

void DragWindow::followCursor()
{
	Point mousePos = getCursorPos();
	int x = mousePos.x - mouseOffset.x;
	int y = mousePos.y - mouseOffset.y;
	MoveWindow(window, x, y, width, height, true);
}
