/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

/// Virtual Window Manager - the widget that this module exists to provide.
class VWM
{
public:
	VWM(HWND parentWindow);
	~VWM();
	
	friend class VirtualDesktop; // FIXME: Shoudln't need to be friends

	void gather();
	RECT getGatherTarget(RECT source, Monitor *target);
	VirtualDesktop *deskFromLocation(Rect pos);
	
	void createDesktop();
	bool destroyDesktop(VirtualDesktop *desk);
	bool mergeDesk(VirtualDesktop *deletedDesktop, VirtualDesktop *mergeTarget);
	void separateDesk(VirtualDesktop *desk);
	void moveDesk(int oldIndex, int newIndex);
	void switchDesk(VirtualDesktop *newDesk, Monitor *switchingMonitor=NULL, bool skipFocus=false);
	void moveApp(WindowData *representative, VirtualDesktop *dest);
	void moveWindow(WindowData *window, VirtualDesktop *desk);
	void raiseWindow(WindowData *window);
	void deleteEmptyDesktops();
	
	// Hover tracking
	TaskData *getHoveredTask();
	void enableHoverTracking();
	void updateHover();
private:
	bool hoverTrackingEnabled;
	HWND hoveredWindow;
	int windowHoverTimer;
	
	// Panels
	// (in vwmpanel.cpp)
public:
	ScreenbarPanel *findPanel(int x, int y);
	ScreenbarPanel *getFirstPanel();
	void getPanels(vector<ScreenbarPanel*> *outPanels);
	void initPanels(HWND parentWindow);
	void destroyPanels();
	void refreshPanels();

	void forceTrackerUpdate();
	void updateLayouts();
	
	LayoutReference *findLayoutNodeMatching(Monitor *preferredMonitor, bool (*condition)(LayoutCacheNode*, void*), void *param);
	
private:
	friend set<ScreenbarPanel*> panelByDescription(string desc, string arg);
	vector<ScreenbarPanel*> panels;
	HWND parentWindow;
	
	// Virtual desktop data structures
	// (getters in vwm.cpp)
public:
	vector<VirtualDesktop*> desktops;
private:
	friend set<VirtualDesktop*> deskByDescription(string keyword, string arg);
	VirtualDesktop *lastDesktop;
	VirtualDesktop *getDeskFromWnd(HWND window);
	
	// windowtracking.cpp
	// Window tracking and moving
public:
	bool updateNextDraw;
	HWND lastFocus;
	VirtualDesktop *rescueOffscreenWindow(WindowData *window, Rect *pos);

	void beginMovingWindows();
	void finishMovingWindows();
	
	StorageManager storageManager;
	
private:
	void setWindowPos(WindowData *window, const Rect &pos);
	void transferWindow(WindowData *window, DeskSlot *source, DeskSlot *dest);
	map<WindowData*, Rect> movedWindows;
	
	// events.cpp
	// Event handlers
public:
	LRESULT windowProc(HWND window, UINT uMsg, WPARAM wParam, LPARAM lParam);
protected:
	LRESULT onSwitchToN(WPARAM wParam, LPARAM lParam);
	LRESULT onListDesktops(WPARAM wParam, LPARAM lParam);
	LRESULT onGetDesktopOf(WPARAM wParam, LPARAM lParam);
	
public:
	void initDesktops();
	void saveState();
	bool restoreState();
};
extern VWM *vwm;

#define TIMER_POLL 1
#define TIMER_HOVERTRACK 2
#define TIMER_AUTOHIDE 3
#define TIMER_DRAGFOLLOW 4

#define UMSG_APPBAR        (WM_USER+0)
#define UMSG_REFRESHLAYOUT (WM_USER+1)
