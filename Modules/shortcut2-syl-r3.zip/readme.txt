I've made some little updates to the shortcut 2 module.
the first little thing is the zorder when the shortcut is created. I have 
shortcuts over others to command winamp and I can toggle the clock/winamp
scroll with a shortcut, the shortcut with 
the clock become a clock with a cross. but without the zorder, this one 
stayed behind the bar. With the zorder, the shortcut works fine, its order 
is in the step.rc .
The other little update is when the mouse click on a shortcut and a program 
appear over the mouse, the shortcut stayed "clicked". I comment a line to 
change that, when you click on a shortcut, this one return to normal state.
bye.

-= Syl =-


===============
readme included by rootrider, FPN <http://floach.pimpin.net/>