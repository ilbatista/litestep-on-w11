/*
This is a part of the LScolor Module Source code.

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.
	  
		You should have received a copy of the GNU General Public License
		along with this program; if not, write to the Free Software
		Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "../../lsapi/lsapi.h"
#include "windows.h"

const char szVersion[] = "lscolor-1.6.3 (pika, gingerfish, ilmcuts, fractal.design)";
const char szAppName[] = "lscolor-1.6.3";

HINSTANCE hInstance;
HWND messageHandler, hwndParent;

int lsMessages[] =
{
    LM_GETREVID,
    LM_REFRESH,
    0
};

char onchange;
void runstarcommands(void);
void setevars(void);
void bang_lscolorupdate(HWND caller, LPCSTR args);

extern "C" {
	__declspec( dllexport ) int initModuleEx(HWND hParent, HINSTANCE hInst, LPCSTR pszPath);
	__declspec( dllexport ) void quitModule(HINSTANCE hInst);
}
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
