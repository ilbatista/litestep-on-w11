/*
This is a part of the LScolor Module Source code.

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.
	  
		You should have received a copy of the GNU General Public License
		along with this program; if not, write to the Free Software
		Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "lscolor.h"

int startup = 0;

// handles all the messages for lscolor.
LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case LM_GETREVID:
		{
			if (wParam == 0 || wParam == 1) 
			{
				LPSTR buf = (LPSTR)lParam;
				strcpy(buf, szVersion);
				return strlen(buf);
			}
			return 0;
		}
		break;
		
		
		case LM_REFRESH: 
		{
			setevars();
			return 0;
		}
		break;
		
		
		case WM_WINDOWPOSCHANGED:// font/metric cheater
		case WM_SYSCOLORCHANGE:// Syscolor
		case WM_SETTINGCHANGE:// Something?
		{
			if (startup > 1)
			{
				setevars();
				runstarcommands();
			}
			startup++;
			return 0;
		}
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}


int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)// modules is loaded
{
	setevars();
	
	AddBangCommand("!lscolorupdate", bang_lscolorupdate);

	WNDCLASSEX wc;

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = MessageHandlerProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = 0;
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "lscolorMessageHandler";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	messageHandler = CreateWindowEx(WS_EX_TOOLWINDOW,
		"lscolorMessageHandler",
		0,
		WS_POPUP,
		0, 0, 0, 0, 
		0,
		0,
		hInstance,
		0);

	if (!messageHandler)
		return 1;

	SendMessage(GetLitestepWnd(),
		LM_REGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	::hInstance = hInstance;

	return 0;
}


void quitModule(HINSTANCE dllInst)// module is unloaded
{
	RemoveBangCommand("!lscolorupdate");
	
	SendMessage(GetLitestepWnd(),
		LM_UNREGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	DestroyWindow(messageHandler);
	UnregisterClass("lscolorMessageHandler", hInstance);

}

void setevars(void)// where all the evars are set
{
	int code=0, i, r, g, b;
	char rgb[8], clrVal[8];
	bool sysBool;
	DWORD color;
   	
	int sysColorIndex[] = {COLOR_3DDKSHADOW, COLOR_3DFACE, COLOR_3DHILIGHT, COLOR_3DLIGHT,
		COLOR_3DSHADOW, COLOR_ACTIVEBORDER, COLOR_ACTIVECAPTION, COLOR_APPWORKSPACE,
		COLOR_BACKGROUND, COLOR_BTNTEXT, COLOR_CAPTIONTEXT,
		COLOR_GRADIENTACTIVECAPTION, COLOR_GRADIENTINACTIVECAPTION,
		COLOR_GRAYTEXT, COLOR_HIGHLIGHT, COLOR_HIGHLIGHTTEXT,
		COLOR_INACTIVEBORDER, COLOR_INACTIVECAPTION, COLOR_INACTIVECAPTIONTEXT,
		COLOR_INFOBK, COLOR_INFOTEXT, COLOR_MENU, COLOR_MENUTEXT, COLOR_SCROLLBAR, COLOR_WINDOW,
		COLOR_WINDOWFRAME, COLOR_WINDOWTEXT};

	char* varNameIndex[] = {"3dDkShadow", "3dFace", "3dHilight", "3dLight",
		"3dShadow", "ActiveBorder", "ActiveCaption", "AppWorkspace",
		"Background", "BtnText", "CaptionText",
		"GradientActiveCaption", "GradientInactiveCaption",
		"GrayText", "Hilight", "HilightText",
		"InactiveBorder", "InactiveCaption", "InactiveCaptionText",
		"InfoBk", "InfoText", "Menu", "MenuText", "Scrollbar", "Window",
		"Windowframe", "WindowText"};

	for ( i=0; i<(sizeof(sysColorIndex)/sizeof(int)); i++ )
	{
		color = GetSysColor(sysColorIndex[i]);
		sprintf(clrVal, "%02X%02X%02X", GetRValue(color), GetGValue(color), GetBValue(color));
		LSSetVariable(varNameIndex[i], clrVal);
	}

	
	// MenuDropAlignment
	SystemParametersInfo(SPI_GETMENUDROPALIGNMENT, 0, &sysBool, 0);
	itoa(sysBool ? 1 : 0, clrVal, 10);
	LSSetVariable("MenuDropAlignment", clrVal);

	
	// NonClientMetric stuff's //////////////////////////////
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, 0);

	char borderwidth[64] = {0};
	char captionwidth[64] = {0};
	char captionheight[64] = {0};
	char menuwidth[64] = {0};
	char menuheight[64] = {0};
	char scrollwidth[64] = {0};
	char scrollheight[64] = {0};
	char smallcaptionwidth[64] = {0};
	char smallcaptionheight[64] = {0};
	
	sprintf(borderwidth, "\"%i\"", ncm.iBorderWidth);
	sprintf(captionwidth, "\"%i\"", ncm.iCaptionWidth);
	sprintf(captionheight, "\"%i\"", ncm.iCaptionHeight);
	sprintf(menuwidth, "\"%i\"", ncm.iMenuWidth);
	sprintf(menuheight, "\"%i\"", ncm.iMenuHeight);
	sprintf(scrollwidth, "\"%i\"", ncm.iScrollWidth);
	sprintf(scrollheight, "\"%i\"", ncm.iScrollHeight);
	sprintf(smallcaptionwidth, "\"%i\"", ncm.iSmCaptionWidth);
	sprintf(smallcaptionheight, "\"%i\"", ncm.iSmCaptionHeight);
	
	LSSetVariable("BorderWidth", borderwidth);
	LSSetVariable("CaptionWidth", captionwidth);
	LSSetVariable("CaptionHeight", captionheight);
	LSSetVariable("MenuWidth", menuwidth);
	LSSetVariable("MenuHeight", menuheight);
	LSSetVariable("ScrollWidth", scrollwidth);
	LSSetVariable("ScrollHeight", scrollheight);
	LSSetVariable("SmallCaptionWidth", smallcaptionwidth);
	LSSetVariable("SmallCaptionHeight", smallcaptionheight);


	// Font names //////////////////////////////
	char captionfont[64] = {0};
	char smcaptionfont[64] = {0};
	char menufont[64] = {0};
	char statusfont[64] = {0};
	char messagefont[64] = {0};
	
	sprintf(captionfont, "\"%s\"", ncm.lfCaptionFont.lfFaceName);
	sprintf(smcaptionfont, "\"%s\"", ncm.lfSmCaptionFont.lfFaceName);
	sprintf(menufont, "\"%s\"", ncm.lfMenuFont.lfFaceName);
	sprintf(statusfont, "\"%s\"", ncm.lfStatusFont.lfFaceName);
	sprintf(messagefont, "\"%s\"", ncm.lfMessageFont.lfFaceName);
	
	LSSetVariable("CaptionFont", captionfont);
	LSSetVariable("SmCaptionFont", smcaptionfont);
	LSSetVariable("MenuFont", menufont);
	LSSetVariable("StatusFont", statusfont);
	LSSetVariable("MessageFont", messagefont);


	// Font Heights //////////////////////////////
	int PointSize = 100;

	char captionfontheight[64] = {0};
	char smcaptionfontheight[64] = {0};
	char menufontheight[64] = {0};
	char statusfontheight[64] = {0};
	char messagefontheight[64] = {0};
	
	sprintf(captionfontheight, "\"%i\"", -MulDiv(PointSize, ncm.lfCaptionFont.lfHeight, 72));
	sprintf(smcaptionfontheight, "\"%i\"", -MulDiv(PointSize, ncm.lfSmCaptionFont.lfHeight, 72));
	sprintf(menufontheight, "\"%i\"", -MulDiv(PointSize, ncm.lfMenuFont.lfHeight, 72));
	sprintf(statusfontheight, "\"%i\"", -MulDiv(PointSize, ncm.lfStatusFont.lfHeight, 72));
	sprintf(messagefontheight, "\"%i\"", -MulDiv(PointSize, ncm.lfMessageFont.lfHeight, 72));
	
	LSSetVariable("CaptionFontHeight", captionfontheight);
	LSSetVariable("SmCaptionFontHeight", smcaptionfontheight);
	LSSetVariable("MenuFontHeight", menufontheight);
	LSSetVariable("StatusFontHeight", statusfontheight);
	LSSetVariable("MessageFontHeight", messagefontheight);

	
	// Font Bold //////////////////////////////
	if (ncm.lfCaptionFont.lfWeight > 400 )
		LSSetVariable("CaptionFontBold", "true");
	else
		LSSetVariable("CaptionFontBold", "false");

	if (ncm.lfSmCaptionFont.lfWeight > 400 )
		LSSetVariable("SmCaptionFontBold", "true");
	else
		LSSetVariable("SmCaptionFontBold", "false");

	if (ncm.lfMenuFont.lfWeight > 400 )
		LSSetVariable("MenuFontBold", "true");
	else
		LSSetVariable("MenuFontBold", "false");

	if (ncm.lfStatusFont.lfWeight > 400 )
		LSSetVariable("StatusFontBold", "true");
	else
		LSSetVariable("StatusFontBold", "false");

	if (ncm.lfMessageFont.lfWeight > 400 )
		LSSetVariable("MessageFontBold", "true");
	else
		LSSetVariable("MessageFontBold", "false");

	
	// Font Italic //////////////////////////////
	if (ncm.lfCaptionFont.lfItalic == TRUE )
		LSSetVariable("CaptionFontItalic", "true");
	else
		LSSetVariable("CaptionFontItalic", "false");

	if (ncm.lfSmCaptionFont.lfItalic == TRUE )
		LSSetVariable("SmCaptionFontItalic", "true");
	else
		LSSetVariable("SmCaptionFontItalic", "false");

	if (ncm.lfMenuFont.lfItalic == TRUE )
		LSSetVariable("MenuFontItalic", "true");
	else
		LSSetVariable("MenuFontItalic", "false");

	if (ncm.lfStatusFont.lfItalic == TRUE )
		LSSetVariable("StatusFontItalic", "true");
	else
		LSSetVariable("StatusFontItalic", "false");

	if (ncm.lfMessageFont.lfItalic == TRUE )
		LSSetVariable("MessageFontItalic", "true");
	else
		LSSetVariable("MessageFontItalic", "false");
	
	
	// Icon evars
	LOGFONT fontInfo;
	SystemParametersInfo(SPI_GETICONTITLELOGFONT, sizeof(LOGFONT), &fontInfo, 0);
	
	char iconfont[64] = {0};
	sprintf(iconfont, "\"%s\"", fontInfo.lfFaceName);
	LSSetVariable("IconFont", iconfont);
	
	char iconfontheight[64] = {0};
	sprintf(iconfontheight, "\"%i\"", -MulDiv(PointSize, fontInfo.lfHeight, 72));
	LSSetVariable("IconFontHeight", iconfontheight);

	if (fontInfo.lfWeight > 400 )
		LSSetVariable("IconFontBold", "true");
	else
		LSSetVariable("IconFontBold", "false");

	if (fontInfo.lfItalic == TRUE )
		LSSetVariable("IconFontItalic", "true");
	else
		LSSetVariable("IconFontItalic", "false");


	ICONMETRICS im;
	im.cbSize = sizeof(ICONMETRICS);
	SystemParametersInfo(SPI_GETICONMETRICS, sizeof(ICONMETRICS ), &im, 0);

	char IconHorzSpacing[64] = {0};
	sprintf(IconHorzSpacing, "\"%i\"", im.iHorzSpacing);
	LSSetVariable("IconHorzSpacing", IconHorzSpacing);
	
	char IconVorzSpacing[64] = {0};
	sprintf(IconVorzSpacing, "\"%i\"", im.iVertSpacing);
	LSSetVariable("IconVorzSpacing", IconVorzSpacing);
	
	char IconTitleWrap[64] = {0};
	sprintf(IconTitleWrap, "\"%i\"", im.iTitleWrap);
	LSSetVariable("IconTitleWrap", IconTitleWrap);

}



void runstarcommands(void)// this funtion reads the rc for *lscoloronchange lines and executes the commands
{
	FILE * fStep = LCOpen(NULL);
	char buffer[4096];

	char token1[4096], command[4096];
	char* tokens[1];
	tokens[0] = token1;

	while ( LCReadNextConfig( fStep, "*lscoloronchange", buffer, sizeof(buffer) ) )
	{
		token1[0] = command[0] = 0;
		LCTokenize (buffer, tokens, 1, command);
		LSExecute(NULL, command, SW_SHOWNORMAL);
	}
	LCClose(fStep);
}


void bang_lscolorupdate(HWND caller, LPCSTR args)// !lscolorupdate, simply runs setevars ();
{
	setevars();
}