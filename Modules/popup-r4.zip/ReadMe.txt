Popup
=====

Popup is a replacement for the popup.dll that is supplied with LiteSTEP.

Johan Redestig, johan@house5.se
http://www.house5.se/litestep

RELEASE 4
=========

* Sorted popup folders
* Support for PopupBottomPix
* Configurable bltstrategy plain/stretch/tile (PopupBlt)
* WindoMakerish close button
* Performace enhancements
* Bugfixes

RELEASE 3
=========

This is a maintenance release. The following issues have been corrected:

* With NoPopupFolderIcon on, the arrow still shows up with the !PopupTasks.
* Separator size
* lnk/LNK case sensitive ...
* Some spelling errors (sorry but you might have to update your step.rc)
* Issues with the task list (like editpad showing twice)

RELEASE 2
=========

* Snap to corner (like winamp)
* A RunItem !PopupRun
* A taskmanager !PopupTasks
* Control the alignment of the text in the time/date (PopupDateTimeAlign 2)
* The !RemoteAmp control now supports apollo as well as winamp
* Define how much overlap you like. (PopupOverlapX and PopupOverlapY)
* Now supporting the standard PopupTextOffset
* Disable the X button (NoPopupCloseButton)
* Configurable height of the title (PopupTitleHeight)
* Smaller .dll size
* Control if you like to see the extensions of files via PopupShowExtension
* Remove the popupwide bevel with NoPopupMenuBevel
* Some bugfixes, probably added some new fresh bugs as well ;)

RELEASE 1
=========

* Compatible with the defult LiteSTEP pupup and your existing step.rc
* Tear off/Pin to desktop
* Mouse/Keyboard control
* Single color/Bitmaps/Transparency
* Manages popup menus that are larger than the screen (partially anyway :)
* Keyboard shortcuts
* Recursive sub folders (folders within folders)
* Uses system default settings (if not specified otherwise in step.rc)
* Supports menu separators
* Icons like the Win start menu
* Gradient popup titles or menu entries (like win98 window captions)
* Lots of new configuration options to explore

CONDITIONS OF USE
=================

This software is licensed under GNU.
The source code of the original popup is available at http://www.litestep.net
Expect this software to be buggy. I take no responsibility of it what so ever!

INSTALL
=======
You need to have Litestep in order to use this software. Litestep is available
at http://www.litestep.net

Place the popup.dll file in a directory of you choice and make sure that your
step.rc is pointing at it. I recommend that you keep the old popup.dll. If you
are not satisfied with this then you can always revert.

PLUGINS
-------

Plugins IN THE POPUP?! yes, almost :)

It is possible to write 'plugins' for the popup menu. Note that 
these plugins must be written as c++ classes and must be compiled
with the rest of the popup menu. It is not possible to load
plugins at runtime (so it is not really plugins, i know..). however 
these are the current supported 'plugins':

* Winamp remote control
* Date and time viewer
* Task manager
* Run item

HOW TO USE THE NEW FEATURES
===========================

TEAR OFF
--------
Use the mouse and drag the caption of a folder away from it parent.
The submenu is now 'pinned' to the desktop. if you wish to remove 
the submenu simply double-click on the X icon in the upper right corner.

How do i pin the root menu to the desktop? - Double click in the upper
right corner if the root menu caption.

KEYBOARD SHORTCUTS
------------------
In you step.rc where you define the title of an menu item you can add an &
(ampersand) char before the char that you wish to be the shortcut.
Example:
			*Popup "R&un" !Run
Whenever the popup is active you can hit 'u' and the !Run command will be
executed.


SETTINGS
========
I have just listed the commands that differ from the standard popup. The others
should be supported as well.

PopupGradientTitle
------------------
Makes the popup menu gradient, like win98 window captions. The popup uses the 
color that you specify with PopupTitleBg color. 


PopupGradientEntry
------------------
Makes popup entries gradient. (like win98 ...). used PopupEntryBg Color.


PopupIcons
----------
Pains icons in the popup menu (this have major impact on performance)


PopupTitleBgColor
-----------------
If you do not specify any title pix this value will be used to paint the 
title with a solid color. if you do not specify this either then the system 
default color for captions will be used.


PopupEntryBgColor
-----------------
If you do not specify any entry pix this value will be used to paint the 
entry with a solid color. if you do not specify this either then the system 
default color for popups will be used.


PopupSelEntryBgColor
--------------------
If you do not specify any sel entry pix this value will be used to paint the 
sel entry with a solid color. if you do not specify this either then the system 
default color for popups will be used.


PopupBevelLightColor
--------------------
The color used for 3d effects on bevels etc.


PopupBevelDarkColor
--------------------
The color used for 3d effects on bevels etc.


NoPopupMenuBevel
----------------
Disables the popup wide bevel


PopupMenuDelay 
--------------
(not supported)


PopupOverlapX|Y
--------------
How much you like child popups to overlap their parents. I you like the 
official popup, just set these values to 
PopupOverlapX 0
PopupOverlapY 0


NoPopupCloseButton
------------------
When a popup menu is torn of its parent it will draw a ugly X icon in
the top right corner. if you do not like this just set the
NoPopupCloseButton in your rc.


PopupShowExtension
------------------
Define if you like to see the extensions of files.

PopupBlt
--------

Controls how bitmaps are painted. 

Normal (default)
 PopupBlt 0
Stretch the images to fill the menuitem (pretty slow)
 PopupBlt 1
Tile the images
 PopupBlt 2

!RemoteAmp
----------
Remotecontrol for winamp in the popup menu! The item gives you basic access to
the play, stop, next, previous buttons. The item need an background image. 
!RemoteAmp will look for Apollo if winamp is not loaded on you computer.
(if you are not familiar with apollo, take a look at http://apollo.grooveclub.com/)

*Popup !RemoteAmp remoteamp.bmp

For an example of a background.bmp take a look at:

http://www.house5.se/litestep/remoteamp.jpg


!PopupImage
-----------
An image for an menu item. The standard popup menu has a command for bottom image 
or something like that. this command makes an image appear anywhere you want in
the popup menu. the image may have the GREAT PINK(TM) color for transparency.

*Popup !PopupImage name_of_image.bmp


!DateTime
--------
The time and date in a popup menu item!
*Popup !DateTime

You can control the alignment of the text in the !DateTime with the 
PopupDateTimeAlign variable.

To left align it
  PopupDateTimeAlign 0
Center it
  PopupDateTimeAlign 1
Right
  PopupDateTimeAlign 2
Vertical center
  PopupDateTimeAlign 4


!Separator
----------
Menu separator.
*Popup !Separator


!PopupTasks
-----------
A simple taskmanager in the popup


!PopupRun
---------
Like the run dialog in explorer. lets you enter a command
and execute it. Litestep bang commands may be executed as
well.


EXAMPLE STEP.RC
---------------
*Popup !DateTime
*Popup "Programs" !PopupFolder:"C:\WINNT\Profiles\jre.000\Start Menu\Programs"
*Popup "All users" !PopupFolder:"C:\WINNT\Profiles\All Users\Start Menu\Programs"
*Popup !Separator
*Popup "Display Properties" control.exe desk.cpl
*Popup "My Computer" explorer /root,,::{20D04FE0-3AEA-1069-A2D8-08002B30309D}
*Popup "Network Neighborhood" explorer /root,,::{208D2C60-3AEA-1069-A2D7-08002B30309D}
*Popup "Control Panel" explorer /root,,::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\::{21EC2020-3AEA-1069-A2DD-08002B30309D}
	*Popup "Shutdown" Folder
	*Popup "Recycle" !Recycle
	*Popup "Logoff" !Logoff
	*Popup "Shutdown Menu" !Shutdown
		*Popup "WinAMP" Folder
		*Popup !RemoteAmp amp_background.bmp
		*Popup ~Folder
	*Popup ~Folder
*Popup !Separator
*Popup "R&un" !Run
*Popup !PopupImage f:\lsb24\images\popupImage.bmp
*Popup !PopupRun
*Popup !PopupTasks
