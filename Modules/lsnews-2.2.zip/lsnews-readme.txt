////////////////////////
// LSNews 2.2
// By: MrJukes
// Released: 3/5/00
////////////////////////

// What's new in 2.2?
- Added Magic Pink (TM) support
	+ Careful! This is real transparency we're dealing with people. It takes whatever area you specify to be transparent and takes it completely out of the window.  I'd recommend only using it around the borders and not behind the text.
- New step.rc commands:
	+ LSNewsHScrollbar
		: Adds a horizontal scrollbar when needed
	+ LSNewsVScrollbar
		: Adds a vertical scrollbar when needed
- Modified step.rc commands:
	+ Changed LSNewsURL to *LSNewsURL
		: *LSNewsURL "Site Name" http://site.com/news.txt
		: This now means you can have as many *LSNewsURL entries as you want.
		: Use the right-click menu to switch between sites.

// What's new in 2.1?
- Added background support
- Added dragging
- Added text wrapping
- New step.rc commands:
	+ LSNewsEditX 3
	+ LSNewsEditY 23
	+ LSNewsEditWidth 220
	+ LSNewsEditHeight 100 
	+ LSNewsWrapText
	+ LSNewsBackground c:\litestep\images\lsnews.bmp

// What's new in 2.0?
- Complete rewrite of the old code.
- It is now a loadmodule, not a wharf module.
- You can't specify a background image (yet?), it just uses transparency

// Operation
- Use the up and down arrows to scroll.  Page Up and Page Down scroll faster.
- Double click on the window to redraw the background
- Right click to bring up the popup menu.

// Step.rc commands
LoadModule h:\Litestep\lsnews.dll

// The X position on the screen
LSNewsX 225
// The Y position on the screen
LSNewsY 3
// The width of the news window
LSNewsWidth 400
// The height of the news window
LSNewsHeight 50
// The font you want to use to display the news
LSNewsFontFace Courier
// The size of the font
LSNewsFontSize 14
// The color of the font
LSNewsFontColor 00FF00
// The interval between updating the news (in minutes)
LSNewsTimer 1

// The URLs of the files you want lsnews to display
// You can have as many as you want
// You switch between sites using the right-click menu
*LSNewsURL "LSNews Home" http://icdweb.cc.purdue.edu/~mrjukes/lsnews.txt
*LSNewsURL litestep.net http://www.litestep.net/news.txt


E-mail at mrjukes@purdue.edu for bug reports and feature requests.

Have Fun,
	MrJukes