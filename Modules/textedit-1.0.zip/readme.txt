Text Edit (v1.0) by WhiteShadow (changty@muohio.edu) on 4-2-00
*******************************************************************

This is a small module that adds two bang command !textadd and
!textdel which can be used to edit text files.  It could be useful
in allowing you to edit your step.rc file on the fly.  However, it
could also be very dangerous if used on the wrong file.

Installation:

	1. Copy textedit.dll into your litestep folder
	2. Add the line 

		LoadModule c:\litestep\textedit.dll

	   to your step.rc (with the appropriate drive letter and 
	   path)
	3. Recycle Litestep

Usage:

	!textadd "filename" text to be added

	   This will add the line "text to be added" to the bottom of
	   the file "filename".  Use quotes around the filename if it
	   contains spaces.  If the file does not exist, nothing
	   happens.


	!textdel "filename" text to be deleted

	   This will delete every line in "filename" that matches
	   "text to be deleted".  This means that if it occurs more
	   than once in the file, every case of it will be removed.
	   

Examples:

	1. !textadd c:\litestep\step.rc *Hotkey CTRL+ALT Q !quit

	   This adds the line "*Hotkey CTRL+ALT Q !quit" to your
	   step.rc file.

	2. !textdel c:\mirc\logs\#litestep.log <someguy> poop

	   This would open up your #litestep log file and remove every 
	   line where someguy says poop.

	3. !textadd "c:\msdos.sys" BootMenu=1
	
	   This would add the line "BootMenu=1" to your msdos.sys
	   file (makes you see a boot menu every time before windows
	   loads).

Anyway, that's all, enjoy!
Feel free to send me comments or bugs.
WhiteShadow