=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    FavApps 1.0 (just another Explorer feature)
    Copyright(c) Sergey Gagarin a.k.a. Seg@
    Ekaterinburg, Russia  2006
    README
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

=========================
The Table of Content
-------------------------
  I. INTRODUCTION
 II. REQUIREMENTS
III. INSTALLATION
 IV. CONFIGURATION
  V. SOURCE CODE
 VI. CONTACTS

=====================
I. INTRODUCTION
---------------------

FavApps  is  a LiteStep  module  that  exports  eVars
containing  information  about favourite user's apps.
Default WinXP start menu have the dynamic application
list, and  this  module  is  intended  for  the  same
purpose.
I'm  too  lazy  to  implement  this  feature  in  any
existing popup module, that's why FavApps do  nothing
except  maintaining  a list of the favourite apps. If
you  want  a dynamic apps menu,  spend  some  time on
scripting.
Also  you may  write a script to build a make dynamic
quick  launch  bar,  or  create  a single  'last app'
button. Just use your fantasy!
Unfortunaly, there are some limitations...
FavApps DOESN'T monitor:
 - applications, launched  from  another applications
   such as TotalCommander or Far Manager.
 - applications, launched  from any  Explorer window,
   including Clickonic desktop =(

=====================
II. REQUIREMENTS
---------------------
The  module  should  work  on  any  Windows  version,
but  I  tested  it  only  on  my  WinXP SP2  machine.

=====================
III. INSTALLATION
---------------------

Just add a line to your theme.rc:
*NetLoadModule FavApps-1.0

Now you may use  dynamic eVars exported by FavApps in
Label,  xLabel or  xPopup module,  bind shortcuts for
them  or make  a quick launch box with  dynamic icons
using *FavAppsOnChange event.

=====================
III. CONFIGURATION
---------------------

You may use OnChange events to execute a bang (bangs)
when the list of favourite apps has been updated.

Syntax:
*FavAppsOnChange !bang

Example
*FavAppsOnChange !RefreshMyQuickLaunchBox
*FavAppsOnChange !alert "Akuna matata"

Exported eVars:

FavAppsNum
   Amount of saved favourite applications. Limited by
   10 (do you really need more?)
   
FavApps[n]
   Most  recent  used  application  # n  (from  1  to
   FavAppsNum).  FavApps1  is  the latest  app  name,
   FavApps10 is the last one.
   
   
=====================
IV. SOURCE CODE
---------------------

Source code  shared under the  GNU GPL 2 license.  It
doesn't  mean  that this feature  cannot  be  used in
shareware products such as  Aston shell or  Talisman.
Just  drop  me  a mail  (see  the  next  section  for
details).

=====================
V. CONTACTS
---------------------

If you want to beat my face  or have any other reason
to contact me, I am available:
 - in the ICQ network: 162261148
 - at the Chuvi's website: http://www.litestep.bip.ru
                                    (only in Russian)
 - or via mail: inform-sega@freemail.ru


Ok, that's all what I needed to say.
Wish you luck with a playing this toy.
