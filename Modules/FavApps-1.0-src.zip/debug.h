#ifndef __DEBUG_HEADER__
#define __DEBUG_HEADER__

//#define DEBUG_OUTPUT

#ifdef DEBUG_OUTPUT
	#define TRACE_LOG(msg)	utils::log(msg);
#else
	#define TRACE_LOG(msg)	;
#endif

#endif
