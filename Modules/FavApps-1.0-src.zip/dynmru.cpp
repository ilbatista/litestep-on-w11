#include "stdafx.h"
#include "utils.h"
#include "dynmru.h"

#define REGKEY_MODULE	"SOFTWARE\\LiteStep\\FavApps\\" 

LPAPPLISTITEM g_pApps = NULL;
LPRECENTLISTITEM g_pEntries = NULL, g_pEntriesEnd = NULL;
int g_nEntries = 0;
bool g_bMRUListChanged = false;

void MRUAdd(const char *szApp)
{
	TRACE_LOG("MRUAdd proc");
	
	// add new entry
	
	// try to find an application in the list
	
	LPAPPLISTITEM pIterator, pLastItem = NULL;
	LPRECENTLISTITEM pEntry = new RecentListItem;
	pEntry->pNext = NULL;
	
	bool bFound = false;
	for (pIterator = g_pApps; pIterator; pIterator = pIterator->pNext)
	{
		if (stricmp(pIterator->szFile, szApp) == 0)
		{
			// we found this application already exists in list	
			bFound = true;
			break;
		}
		pLastItem = pIterator;
	}
	
	// not found in the list, add a new entry to the end of the list
	if (!bFound)
	{
		pIterator = new AppListItem;
		pIterator->nCount = 0;
		utils::CopyString(&(pIterator->szFile), szApp);
		pIterator->pNext = NULL;
		if (g_pApps)
		{
			pIterator->pPrev = pLastItem;
			pLastItem->pNext = pIterator;
		}
		else
		{
			g_pApps = pIterator;
			pIterator->pPrev = NULL;
		}
	}
	
	// increment counter
	pIterator->nCount++;

	// arrange list after increased pointer
	MRUIncrease(pIterator);
	
	// add entry to the recent launched applicaiton list
	
	pEntry->pAppItem = pIterator;
	if (g_pEntriesEnd == NULL)
	{
		g_pEntries = pEntry;
		g_pEntriesEnd = pEntry;
		g_nEntries++;
	}
	else
	{
		g_pEntriesEnd->pNext = pEntry;
		g_pEntriesEnd = pEntry;
		if (g_nEntries == QUEUE_LENGTH)
		{
			LPRECENTLISTITEM pDelItem = g_pEntries;
			g_pEntries = g_pEntries->pNext;
			
			// now we need to decrement the application's counter
			pIterator = pDelItem->pAppItem;
			delete pDelItem;
			
			pIterator->nCount--;
			
			if (pIterator->nCount)
			{
				// descrease counter
				MRUDecrease(pIterator);
			}
			else
			{
				// we need to do extra task to remove item from the list
				
				if (g_pApps == pIterator)
				{
					g_pApps = g_pApps->pNext;
					g_pApps->pPrev = NULL;
				}
				else
				{
					LPAPPLISTITEM pPrevItem = pIterator->pPrev, pNextItem = pIterator->pNext;
					pPrevItem->pNext = pNextItem;
					pNextItem->pPrev = pPrevItem;
				}
				delete pIterator->szFile;
				delete pIterator;
			}
		}
		else
		{
			g_nEntries++;
		}
	}
	
	MRUUpdateEvars();

	TRACE_LOG("MRUAdd endproc");
}

//=============================================================================
// Move a single item in the list, no need  for something complex
//=============================================================================
void MRUIncrease(LPAPPLISTITEM pIterator)
{
	// move app in the list in according to the rating
	while (pIterator->pPrev && pIterator->pPrev->nCount < pIterator->nCount)
	{
		// swap neighbour queue items (pIterator and pIterator->pPrev)
		LPAPPLISTITEM
			pNextItem = pIterator->pNext,
			pPrevItem = pIterator->pPrev,
			pTmp = pPrevItem->pPrev;
		if (pTmp)
			pTmp->pNext = pIterator;
		else
			g_pApps = pIterator;
		pIterator->pPrev = pTmp;
		pIterator->pNext = pPrevItem;
		pPrevItem->pPrev = pIterator;
		pPrevItem->pNext = pNextItem;
		if (pNextItem)
		{
			pNextItem->pPrev = pPrevItem;
		}
	}
}

//=============================================================================
// Move a single item in the list, no need  for something complex
//=============================================================================
void MRUDecrease(LPAPPLISTITEM pIterator)
{
	// move app in the list in according to the rating
	while (pIterator->pNext && pIterator->pNext->nCount > pIterator->nCount)
	{
		// swap neighbour queue items  (pIterator and pIterator->pNext)
		LPAPPLISTITEM pNextItem = pIterator->pNext, pPrevItem = pIterator->pPrev;
		if (pPrevItem)
			pPrevItem->pNext = pNextItem;
		else
			g_pApps = pNextItem;
		LPAPPLISTITEM pTmp = pNextItem->pNext;
		pNextItem->pNext = pIterator;
		pNextItem->pPrev = pPrevItem;
		pIterator->pPrev = pNextItem;
		pIterator->pNext = pTmp;
		if (pTmp)
		{
			pTmp->pPrev = pIterator;
		}
	}	
}

//=============================================================================
// Export eVars
//=============================================================================
void MRUUpdateEvars()
{
	char szVarName[MAX_PATH], szVarValue[MAX_LINE_LENGTH];
	LPAPPLISTITEM pIterator = g_pApps;
	for (int i = 0; i < QUEUE_OUTNUMBER; i++)
	{
		if (pIterator == NULL)
		{
			break;
		}
		StringCchPrintf(szVarName, MAX_PATH, "FavApp%d", i+1);
		GetRCLine(szVarName, szVarValue, MAX_LINE_LENGTH, "");
		LSSetVariable(szVarName, pIterator->szFile);
		if (stricmp(szVarValue, pIterator->szFile) != 0)
		{
#ifdef DEBUG_OUTPUT
			utils::log("'%s' :: '%s'", szVarValue, pIterator->szFile);
#endif
			g_bMRUListChanged = true;
		}
		pIterator = pIterator->pNext;
	}

	char szBuf[16];
	StringCchPrintf(szBuf, 16, "%d", i);
	if (i != GetRCInt("FavAppsNum", -1))
	{
#ifdef DEBUG_OUTPUT
		utils::log("%d :: %d", i, GetRCInt("FavAppsNum", -1));
#endif
		g_bMRUListChanged = true;
	}
	LSSetVariable("FavAppsNum", szBuf);
}


//=============================================================================
// Save MRU applications list to the registry
//=============================================================================

void MRUSave()
{
	HKEY hKey;
	DWORD dwDisposition;
	char szNum[16];
	
	TRACE_LOG("MRUSave proc");

	TRACE_LOG("recreate a key");
	RegDeleteKey(HKEY_CURRENT_USER, REGKEY_MODULE);

	if (ERROR_SUCCESS != RegCreateKeyEx(
		HKEY_CURRENT_USER,
		REGKEY_MODULE,
		0, NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS, NULL, &hKey, &dwDisposition))
	{
		TRACE_LOG("Cannot save MRU apps list in the registry: the key is not accessible");
		return;
	}
	
	TRACE_LOG("save applications' names");
	
	DWORD i = 0;
	for (LPAPPLISTITEM pIterator = g_pApps; pIterator; pIterator = pIterator->pNext)
	{
		StringCchPrintf(szNum, 16, "%d", i);
#ifdef DEBUG_OUTPUT
		utils::log("app%s is '%s'", szNum, pIterator->szFile);
#endif
		RegSetValueEx(hKey, szNum, 0, REG_SZ, (LPBYTE)(pIterator->szFile), strlen(pIterator->szFile) + 1);
		i++;
	}
	
	RegSetValueEx(hKey, "amount", 0, REG_DWORD, (LPBYTE)&i, sizeof(DWORD));
	
#ifdef DEBUG_OUTPUT
	utils::log("amount is '%d'", i);
#endif
	
	TRACE_LOG("save launched applications list");
	
	int *vnEntries = new int[g_nEntries];
	
	i = 0;
	TRACE_LOG("looking for pairs link - app");
	for (LPRECENTLISTITEM pRecentIterator = g_pEntries; pRecentIterator; pRecentIterator = pRecentIterator->pNext)
	{
		int j = 0;
		for (pIterator = g_pApps; pIterator; pIterator = pIterator->pNext)
		{
			if (pRecentIterator->pAppItem == pIterator)
			{
#ifdef DEBUG_OUTPUT
				utils::log("found... processing...");
				utils::log("pIterator is %d, pRecentIterator->pAppItem is %d", pIterator, pRecentIterator->pAppItem);
				utils::log("%s :: %s", pRecentIterator->pAppItem->szFile, pIterator->szFile);
#endif
				break;
			}
			j++;
#ifdef DEBUG_OUTPUT
			utils::log("skipping... j is %d", j);
#endif
		}
#ifdef DEBUG_OUTPUT
		utils::log("link # %d, app # %d: app is '%s'", i, j, pRecentIterator->pAppItem->szFile);
#endif
		vnEntries[i] = j;
		i++;
	}
#ifdef DEBUG_OUTPUT
	utils::log("g_nEntries is %d", g_nEntries);
#endif
	RegSetValueEx(hKey, "launched", 0, REG_BINARY, (LPBYTE)vnEntries, g_nEntries * sizeof(int));

	RegCloseKey(hKey);
	
	TRACE_LOG("MRUSave endproc");
}

//=============================================================================
// Load MRU applications list from the registry
//=============================================================================

void MRULoad()
{
	HKEY hKey;
	DWORD nApps;
	PCHAR *vszApps;
	char szNum[10];
	DWORD dwSize;
	
	TRACE_LOG("MRULoad proc");

	TRACE_LOG("open the registry key");

	if (ERROR_SUCCESS != RegOpenKeyEx(
		HKEY_CURRENT_USER,
		REGKEY_MODULE,
		0,
		KEY_ALL_ACCESS,
		&hKey))
	{
		TRACE_LOG("Cannot load applications list from the registry: the key is not accessible");
		return;
	}

	TRACE_LOG("read the apps count");
	
	if (RegQueryValueEx(hKey, "amount", NULL, NULL, NULL, &dwSize) != ERROR_SUCCESS || dwSize != sizeof(DWORD))
	{
		TRACE_LOG("'amount' key is unavailable (cannot obtain or invalid key size)");
		RegCloseKey(hKey);
		return;
	}
	
	if (RegQueryValueEx(hKey, "amount", NULL, NULL, (LPBYTE)&nApps, &dwSize) != ERROR_SUCCESS)
	{
		TRACE_LOG("'amount' key is unavailable (cannot obtain key value)");
		RegCloseKey(hKey);
		return;
	}
	
#ifdef DEBUG_OUTPUT
	utils::log("nApps is %d", nApps);
#endif
	
	TRACE_LOG("read the apps list");
	
	vszApps = new PCHAR[nApps];
	for (int i = 0; i < nApps; i++)
	{
		StringCchPrintf(szNum, 16, "%d", i);
		if (RegQueryValueEx(hKey, szNum, NULL, NULL, NULL, &dwSize) != ERROR_SUCCESS || dwSize < 2)
		{
			vszApps[i] = NULL;
		}
		else
		{
			vszApps[i] = new char[dwSize];
			if (RegQueryValueEx(hKey, szNum, NULL, NULL, (LPBYTE)(vszApps[i]), &dwSize) != ERROR_SUCCESS)
			{
				vszApps[i][0] = 0;
			}
		}
#ifdef DEBUG_OUTPUT
		utils::log("vszApps[i] is '%s'", vszApps[i]);
#endif
	}
	
	TRACE_LOG("read the launched list");
	
	if (RegQueryValueEx(hKey, "launched", NULL, NULL, NULL, &dwSize) == ERROR_SUCCESS)
	{
		int *vnEntries = reinterpret_cast<int*>(new BYTE[dwSize]);
		if (RegQueryValueEx(hKey, "launched", NULL, NULL, (LPBYTE)vnEntries, &dwSize) == ERROR_SUCCESS)
		{
#ifdef DEBUG_OUTPUT
			utils::log("'launched' list size is %d", dwSize / sizeof(int));
#endif
			for (i = 0; i < dwSize / sizeof(int); i++)
			{
				if (vnEntries[i] < nApps)
				{
#ifdef DEBUG_OUTPUT
					utils::log("adding app %s", vszApps[vnEntries[i]]);
#endif
					MRUAdd(vszApps[vnEntries[i]]);
				}
			}
		}
	}
	
	for (i = 0; i < nApps; i++)
	{
		delete vszApps[i];
	}
	
	RegCloseKey(hKey);
	
	TRACE_LOG("MRULoad endproc");
}
