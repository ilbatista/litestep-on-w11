#ifndef __MAIN_HEADER__
#define __MAIN_HEADER__

typedef struct tagCmdListItem
{
	char *szCmd;
	tagCmdListItem *pNext;
} CmdListItem, *LPCMDLISTITEM;

extern const char g_szAppName[];
extern HINSTANCE g_hInstance;
extern LPCMDLISTITEM g_pCommands;

#endif
