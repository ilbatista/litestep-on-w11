// main.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "grdFunctionHooker.h"
#include "utils.h"

#include "main.h"
#include "dynmru.h"

extern "C" {
    __declspec( dllexport ) int initModuleEx(HWND hwndParent, HINSTANCE hDllInstance, LPCSTR szPath);
    __declspec( dllexport ) void quitModule(HINSTANCE hDllInstance);
}

#define CONFIG_TOKENS_NUM	1

const char g_rcsRevision[]	= "1.0.0";
const char g_szAppName[]	= "FavApps";
const char g_szMsgHandler[]	= "FavAppsManager";
const char g_szAuthor[]		= "Seg@";

HINSTANCE g_hInstance;

int g_lsMessages[] = {LM_GETREVID, 0};
HWND g_hwndMessageHandler;
void CreateMessageHandler(HINSTANCE hInst);
LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

// a list of !bangs executed on favourite list change
LPCMDLISTITEM g_pCommands;

// an instance for funciton hooker
grdFunctionHooker *g_pHooker;

// proxy funcitons for rerouting...
HINSTANCE WINAPI ProxyLoadLibrary(LPCTSTR szLibraryName);
HINSTANCE ProxyShellExecute	(HWND hwnd, LPCTSTR lpOperation, LPCTSTR lpFile, LPCTSTR lpParameters, LPCTSTR lpDirectory, INT nShowCmd);
BOOL ProxyShellExecuteEx	(LPSHELLEXECUTEINFO lpExecInfo);
HINSTANCE ProxyLSExecuteEx	(HWND hOwner, LPCSTR pszOperation, LPCSTR pszCommand, LPCSTR pszArgs, LPCSTR pszDirectory, int nShowCmd);
HINSTANCE ProxyLSExecute	(HWND hOwner, LPCSTR pszCommand, int nShowCmd);

//=============================================================================
// DLL entry point
//=============================================================================
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	if (ul_reason_for_call == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls((HINSTANCE)hModule);
	}
	return TRUE;
}


//=============================================================================
// Module entry point
//=============================================================================
int initModuleEx(HWND hwndParent, HINSTANCE hDllInstance, LPCSTR szPath)
{
	TRACE_LOG("Initializing");

	CreateMessageHandler(hDllInstance);

	MRULoad();

	FILE *f;
	if (!(f = LCOpen(NULL)))
	{
		utils::ErrorBox("Error: Cannot open step.rc for reading");
	}
	else
	{
		char szLine[MAX_LINE_LENGTH];	// current line
		// let's prepare string array for tokens
		char token[CONFIG_TOKENS_NUM][MAX_LINE_LENGTH];
		char* tokens[CONFIG_TOKENS_NUM];
		char szExtra[MAX_LINE_LENGTH];
		int i;
		LPCMDLISTITEM pLast = NULL;

		for (i = 0; i<CONFIG_TOKENS_NUM; i++)
		{
			tokens[i] = token[i];
		}

		char szConfigLine[MAX_RCCOMMAND];
		StringCchPrintf(szConfigLine, MAX_RCCOMMAND, "*%sOnChange", g_szAppName);
		while(LCReadNextConfig(f, szConfigLine, szLine, MAX_LINE_LENGTH))
		{
			LCTokenize(szLine, tokens, CONFIG_TOKENS_NUM, szExtra);
			LPCMDLISTITEM pItem = new CmdListItem;
			int nLen = strlen(szExtra);
			pItem->szCmd = new char[nLen + 1];
			memcpy(pItem->szCmd, szExtra, nLen + 1);
			pItem->pNext = NULL;
			if (g_pCommands == NULL)
			{
				g_pCommands = pItem;
			}
			else
			{
				pLast->pNext = pItem;
			}
			pLast = pItem;
		}
		LCClose(f);
	}
	
	// initialize hooker
	
	g_pHooker = new grdFunctionHooker();
	
	// hook LoadLibrary funciton to process any other module
	if (g_pHooker == NULL)
	{
		TRACE_LOG("cannot initialize grdFunctionHooker...");
		return 1;
	}

	// an instance of the HookFunc for function rerouting
	grdFunctionHooker::HookFunc hf;
	
	hf.fdDescription.hModule = GetModuleHandle("litestep.exe");
	
	// if the applications name is not litestep.exe look it up
	if (hf.fdDescription.hModule == NULL)
	{
		DWORD dwProcessID = GetCurrentProcessId();
		HANDLE hss = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		PROCESSENTRY32 pe;
		pe.dwSize = sizeof(PROCESSENTRY32);
		if (Process32First(hss, &pe))
		{
			do
			{
				if (pe.th32ProcessID == dwProcessID)
				{
					hf.fdDescription.hModule = GetModuleHandle(pe.szExeFile);
					break;
				}
			} while(Process32Next(hss, &pe));
		}
		CloseHandle(hss);
	}
	StringCchCopy(hf.fdDescription.szLibraryName, MAX_PATH, "kernel32.dll");
	StringCchCopy(hf.fdDescription.szFunctionName, MAX_PATH, "LoadLibraryA");

	hf.procReplacement = (PROC)::ProxyLoadLibrary;

	g_pHooker->RerouteFunction(&hf);
	
	TRACE_LOG("Module has been started");
	return 0;
}

//=============================================================================
// Module destructor
//=============================================================================
void quitModule(HINSTANCE hDllInstance)
{
	TRACE_LOG("Destructor called");
	
	MRUSave();
	
	if (g_pHooker)
	{
		// no need to unrote all functions manually
		
		delete g_pHooker;
	}
	
	while (g_pCommands)
	{
		LPCMDLISTITEM pFirst = g_pCommands;
		g_pCommands = g_pCommands->pNext;
		delete pFirst->szCmd;
		delete pFirst;
	}

	if (g_hwndMessageHandler)
	{
		SendMessage(GetLitestepWnd(),LM_UNREGISTERMESSAGE,(WPARAM)g_hwndMessageHandler, (LPARAM)g_lsMessages);
		DestroyWindow(g_hwndMessageHandler);
	}
	UnregisterClass(g_szMsgHandler, hDllInstance);

	TRACE_LOG("Module has been unloaded");
	
}


//=============================================================================
// Create message handler window
//=============================================================================

void CreateMessageHandler(HINSTANCE hInst)
{
	WNDCLASSEX wc;
	ZeroMemory(&wc, sizeof(WNDCLASSEX));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.lpfnWndProc = MessageHandlerProc;
	wc.hInstance = hInst;
	wc.lpszClassName = g_szMsgHandler;
	wc.hIconSm = 0;

	if (!RegisterClassEx(&wc))
	{
		utils::ErrorBox("Error: Cannot register handler window class...");
		return;
	}

	g_hwndMessageHandler = CreateWindowEx(WS_EX_TOOLWINDOW,
		g_szMsgHandler,
		0,
		WS_POPUP,
		0, 0, 0, 0, 
		0,
		0,
		hInst,
		0);

	if (!g_hwndMessageHandler)
	{
		utils::ErrorBox("Error: Cannot create main window...");
		return;
	}	
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)g_hwndMessageHandler, (LPARAM) g_lsMessages);

}


//=============================================================================
// Message handler process the following messages
//	LM_GETREVID				-	Revision ID
//=============================================================================
LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case LM_GETREVID:
		LPSTR buf;
		buf = (LPSTR)lParam;
		switch (wParam)
		{
		case 0:
		case 1:
			StringCchPrintf(buf, lParam, "%s: %s (%s)", g_szAppName, g_rcsRevision, g_szAuthor);
			break;
		default:
			StringCchCopy(buf, lParam, "");
		}
		return strlen(buf);
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


//=============================================================================
// Here we need to process all modules names
//=============================================================================
HINSTANCE WINAPI ProxyLoadLibrary(LPCTSTR szLibraryName)
{
	HINSTANCE hInstance = ::LoadLibraryA(szLibraryName);

	TCHAR szBuffer[MAX_PATH];
	utils::GetModuleShortName(szBuffer, MAX_PATH, szLibraryName);
	// szBuffer now contains the lowercased name of the module without path and without .dll
	
	TRACE_LOG(szBuffer);

	if (g_pHooker)
	{
		grdFunctionHooker::HookFunc hf;

		hf.fdDescription.hModule = hInstance;
		StringCchCopy(hf.fdDescription.szLibraryName, MAX_PATH, "shell32.dll");
		StringCchCopy(hf.fdDescription.szFunctionName, MAX_PATH, "ShellExecuteA");
		hf.procReplacement = (PROC)::ProxyShellExecute;
		g_pHooker->RerouteFunction(&hf);
		
		StringCchCopy(hf.fdDescription.szLibraryName, MAX_PATH, "shell32.dll");
		StringCchCopy(hf.fdDescription.szFunctionName, MAX_PATH, "ShellExecuteExA");
		hf.procReplacement = (PROC)::ProxyShellExecuteEx;
		g_pHooker->RerouteFunction(&hf);
		
		hf.fdDescription.hModule = hInstance;
		StringCchCopy(hf.fdDescription.szLibraryName, MAX_PATH, "shlwapi.dll");
		StringCchCopy(hf.fdDescription.szFunctionName, MAX_PATH, "ShellExecuteA");
		hf.procReplacement = (PROC)::ProxyShellExecute;
		g_pHooker->RerouteFunction(&hf);
		
		StringCchCopy(hf.fdDescription.szLibraryName, MAX_PATH, "shlwapi.dll");
		StringCchCopy(hf.fdDescription.szFunctionName, MAX_PATH, "ShellExecuteExA");
		hf.procReplacement = (PROC)::ProxyShellExecuteEx;
		g_pHooker->RerouteFunction(&hf);
		
		StringCchCopy(hf.fdDescription.szLibraryName, MAX_PATH, "lsapi.dll");
		StringCchCopy(hf.fdDescription.szFunctionName, MAX_PATH, "LSExecute");
		hf.procReplacement = (PROC)::ProxyLSExecute;
		g_pHooker->RerouteFunction(&hf);
		
		StringCchCopy(hf.fdDescription.szLibraryName, MAX_PATH, "lsapi.dll");
		StringCchCopy(hf.fdDescription.szFunctionName, MAX_PATH, "LSExecuteEx");
		hf.procReplacement = (PROC)::ProxyLSExecuteEx;
		g_pHooker->RerouteFunction(&hf);
		
	}
	
	

	return hInstance;
}

//=============================================================================
// Execute all onChange commands
//=============================================================================

void ExecuteActions()
{
	if (g_bMRUListChanged)
	{
		for (LPCMDLISTITEM pIterator = g_pCommands; pIterator; pIterator = pIterator->pNext)
		{
			LSExecute(NULL, pIterator->szCmd, SW_SHOWDEFAULT);
		}
		g_bMRUListChanged = false;
	}
}


//=============================================================================
// Here we shall determine user's favourite applications by processing
// launched applications
//=============================================================================

void AddExecutable(const char *szFile)
{
	TRACE_LOG(szFile);
	
	if (szFile && szFile[0])
	{
		LPWSTR wszCurDir = new WCHAR[MAX_PATH], wszFullName = new WCHAR[MAX_PATH];
		LPCWSTR wszDirs[] = {wszCurDir};
		char szFullName[MAX_PATH];
		
		MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, szFile, -1, wszFullName, MAX_PATH);
		GetCurrentDirectoryW(MAX_PATH, wszCurDir);
		if (!PathResolve(
			wszFullName,
			wszDirs,
			PRF_FIRSTDIRDEF | PRF_TRYPROGRAMEXTENSIONS | PRF_VERIFYEXISTS)
		)
		{
			TRACE_LOG("cannot resolve path");
			return;
		}
		WideCharToMultiByte(CP_ACP, 0, wszFullName, MAX_PATH, szFullName, MAX_PATH, NULL, NULL);
		
		char *pExt = PathFindExtension(szFullName);
		
		if (pExt && strcmp(pExt, ".exe") == 0)
		{
			TRACE_LOG("Ok, it's an executable");
			MRUAdd(szFullName);
			ExecuteActions();
			return;
		}
		
		if (pExt && (strcmp(pExt, ".lnk") == 0 || strcmp(pExt, ".pif") == 0))
		{
			HRESULT hres;
			IShellLink* psl;
			hres = CoCreateInstance(
				CLSID_ShellLink, NULL,
				CLSCTX_INPROC_SERVER, IID_IShellLink, (LPVOID *) &psl
			);
			if (SUCCEEDED(hres))
			{
				IPersistFile* ppf;
				hres = psl->QueryInterface(IID_IPersistFile, (LPVOID *) &ppf);
				if (SUCCEEDED(hres))
				{
					WORD wsz[MAX_PATH];
					MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, szFullName, -1, wsz, MAX_PATH);
					hres = ppf->Load(wsz, 0);
					if (SUCCEEDED(hres))
					{
						char buf[MAX_PATH];
						psl->GetPath(buf, MAX_PATH, NULL, 0);
						if (buf[0])
						{
							TRACE_LOG("Link target extracted");
							pExt = PathFindExtension(buf);
							TRACE_LOG(buf);
							if (pExt && strcmp(pExt, ".exe") == 0)
							{
								TRACE_LOG("Ok, it's an executable");
								MRUAdd(buf);
								ExecuteActions();
							}
						}
					}
					ppf->Release();
				}
				psl->Release();
			}
		}
	}	
}

//=============================================================================
// Proxy functions to capture executables' names
//=============================================================================

HINSTANCE ProxyShellExecute(
	HWND hwnd,
	LPCTSTR lpOperation,
	LPCTSTR lpFile,
	LPCTSTR lpParameters,
	LPCTSTR lpDirectory,
	INT nShowCmd)
{
	HINSTANCE hInstance = ShellExecute(hwnd, lpOperation, lpFile, lpParameters, lpDirectory, nShowCmd);
	
	if (lpOperation == NULL || stricmp(lpOperation, "open") == 0)
	{
		TRACE_LOG("ProxyShellExecute::");
		AddExecutable(lpFile);
	}
	
	return hInstance;
}

BOOL ProxyShellExecuteEx	(LPSHELLEXECUTEINFO lpExecInfo)
{
	BOOL rv = ShellExecuteEx(lpExecInfo);
	if (lpExecInfo->lpVerb == NULL || stricmp(lpExecInfo->lpVerb, "open") == 0)
	{
		TRACE_LOG("ProxyShellExecuteEx::");
		AddExecutable(lpExecInfo->lpFile);
	}
	return rv;
}

HINSTANCE ProxyLSExecute(HWND hOwner, LPCSTR pszCommand, int nShowCmd)
{
	HINSTANCE hResult = LSExecute(hOwner, pszCommand, nShowCmd);

	char szCommand[MAX_LINE_LENGTH];
	char szExpandedCommand[MAX_LINE_LENGTH];
	LPCSTR pszArgs;

	if (pszCommand && pszCommand[0])
	{
		VarExpansionEx(szExpandedCommand, pszCommand, MAX_LINE_LENGTH);

		if (GetToken(szExpandedCommand, szCommand, &pszArgs, true))
		{
			if (szCommand[0] != '!')
			{
				TRACE_LOG("ProxyLSExecute::");
				TRACE_LOG(szCommand);
				AddExecutable (szCommand);
			}
		}
	}

	return hResult;
}

HINSTANCE ProxyLSExecuteEx	(HWND hOwner, LPCSTR pszOperation, LPCSTR pszCommand, LPCSTR pszArgs, LPCSTR pszDirectory, int nShowCmd)
{
	HINSTANCE hInstance = LSExecuteEx(hOwner, pszOperation, pszCommand, pszArgs, pszDirectory, nShowCmd);
	
	if (pszOperation == NULL || stricmp(pszOperation, "open") == 0)
	{		
		TRACE_LOG("ProxyLSExecuteEx::");
		TRACE_LOG(pszCommand);
		AddExecutable(pszCommand);
	}
	
	return hInstance;
}

