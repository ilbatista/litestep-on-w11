#ifndef __DYNAMIC_MRU_HEADER__
#define __DYNAMIC_MRU_HEADER__

// length of the queue where we shall store info
// about launched applications
#define QUEUE_LENGTH	100
// amount of eVars to export
#define QUEUE_OUTNUMBER	10

typedef struct tagAppListItem
{
	char *szFile;
	int nCount;
	tagAppListItem *pPrev, *pNext;
} AppListItem, *LPAPPLISTITEM;

typedef struct tagRecentListItem
{
	LPAPPLISTITEM pAppItem;
	tagRecentListItem *pNext;
} RecentListItem, *LPRECENTLISTITEM;

void MRUAdd(const char *szApp);
void MRUIncrease(LPAPPLISTITEM pIterator);
void MRUDecrease(LPAPPLISTITEM pIterator);
void MRUUpdateEvars();
void MRUSave();
void MRULoad();

extern bool g_bMRUListChanged;

#endif
