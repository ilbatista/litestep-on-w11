#include "stdafx.h"
#include "utils.h"
#include "grdOSVersionInfo.h"

grdOSVersionInfo::grdOSVersionInfo()
{
	memset(&osvi, 0, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if(!GetVersionEx(&osvi))
	{
		TRACE_LOG("GetVersionEx() failed");
	}
}

grdOSVersionInfo::~grdOSVersionInfo()
{
	// nothing to do here...
}

bool grdOSVersionInfo::IsNT()
{
	return (bool)(VER_PLATFORM_WIN32_NT == osvi.dwPlatformId);
}

bool grdOSVersionInfo::Is2K()
{
	return (bool)(IsNT() && osvi.dwMajorVersion >= 5);
}
