// utils.cpp: implementation of the 'utils' namespace
//=============================================================================

#include "stdafx.h"
#include "utils.h"
#include "main.h"

//=============================================================================
// Display simple string in a message box
//=============================================================================
void utils::ErrorBox(const char *szMessage)
{
	MessageBox(NULL, szMessage, "LiteStep :: FavApps", MB_OK | MB_ICONERROR | MB_TOPMOST | MB_SETFOREGROUND);
	LSLogPrintf(LOG_ERROR, g_szAppName, szMessage);
}

//=============================================================================
// Display a string
//=============================================================================
void utils::ErrorBoxPrint(const char *szFormat, ...)
{
	// Format the message
	char szMessage[MAX_LINE_LENGTH];
	va_list argList;

	va_start(argList, szFormat);
	StringCchVPrintf(szMessage, MAX_LINE_LENGTH, szFormat, argList);
	va_end(argList);

	ErrorBox(szMessage);
}

//=============================================================================
// printf() to the litestep.log
//=============================================================================
void utils::log(const char *szFormat, ...)
{
	// Format the message
	char szMessage[MAX_LINE_LENGTH];
	va_list argList;

	va_start(argList, szFormat);
	StringCchVPrintf(szMessage, MAX_LINE_LENGTH, szFormat, argList);
	va_end(argList);

	LSLog(LOG_DEBUG, g_szAppName, szMessage);
}

//=============================================================================
// Allocate string and store a copy of szValue
//=============================================================================
void utils::CopyString(char **pszString, const char *szValue)
{
	int nLen = strlen(szValue) + 1;
	*pszString = (char*)HeapAlloc(GetProcessHeap(), 0, nLen);
	StringCchCopy(*pszString, nLen, szValue);
}


//=============================================================================
// Get the module short name (i.e. "c:\ls\desk-1.0.dll" -> "desk-1.0")
//=============================================================================
HRESULT utils::GetModuleShortName(char *szDest, size_t nMaxLen, const char *szSource)
{
	if (szDest == NULL) return E_POINTER;

	if (szSource==NULL)
	{
		return E_FAIL;
	}

	// remove path...
	char *szStart = StrRChr(szSource, NULL, '\\');
	if (szStart == NULL)
	{
		StringCchCopy(szDest, nMaxLen, szSource);
	}
	else
	{
		StringCchCopy(szDest, nMaxLen, szStart + 1);
	}

	// remove extension
	szStart = StrRChr(szDest, NULL, '.');
	if (szStart != NULL)
	{
		*szStart = '\0';
	}

	// make lowercase
	_tcslwr(szDest);

	return S_OK;
}
