#ifndef __GRD_OS_VERSION_INFO_H__
#define __GRD_OS_VERSION_INFO_H__


class grdOSVersionInfo
{
private:
	OSVERSIONINFO osvi;

public:
	grdOSVersionInfo();
	~grdOSVersionInfo();

public:
	bool IsNT();
	bool Is2K();
};

#endif