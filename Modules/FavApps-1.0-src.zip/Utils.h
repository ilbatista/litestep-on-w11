// Utils.h: interface for the CUtils class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __UTILS_HEADER__
#define __UTILS_HEADER__

#pragma once

#define DIRECTION_RIGHT	0
#define DIRECTION_DOWN	1
#define DIRECTION_LEFT	2
#define DIRECTION_UP	3

#define ISVERTICAL(d)	(d == DIRECTION_UP || d == DIRECTION_DOWN)
#define ISHORIZONTAL(d)	(d == DIRECTION_LEFT || d == DIRECTION_RIGHT)

namespace utils
{
	bool SetWindowAlpha(HWND hWnd, int nAlpha);
	HWND GetLitestepDesktop();
	HRESULT CreateLink(LPCSTR lpszPathObj, LPCSTR lpszPathLink, LPCSTR lpszDesc);
	void GetTooltip(const char *szFile, char *szTip, int bufsize);
	bool IsPointInRect(int xPos, int yPos, const RECT *rect);
	void ErrorBox(const char *szMessage);
	void ErrorBoxPrint(const char *szFormat, ...);
	void log(const char *szFormat, ...);
	int ParseDirection(const char *szDirection);
	void CopyString(char **pszString, const char *szValue);
	void GarbageCollector();
	COLORREF String2Color(const char *szColor);
	bool String2Bool(const char *szBool);
	HRESULT GetModuleShortName(char *szDest, size_t nMaxLen, const char *szSource);
#ifdef DEBUG_OUTPUT
	void ShowIID(REFIID iid);
#endif
};

#endif
