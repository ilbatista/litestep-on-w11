#include "stdafx.h"
#include "..\ils\lsapi\lsapi.h"

#include <string>
using namespace std;

// trim leading and trailing whitespace
string trim(const string &toTrim)
{
	int start = 0;
	int end = toTrim.length() - 1;
	
	while(start <= end && isspace(toTrim[start]))
		start++;
	
	while(start <= end && isspace(toTrim[end]))
		end--;
	
	return toTrim.substr(start, end - start + 1);
}
 

// parse a coordinate specification
int ParseCoordinate(const string &aString, int defaultVal, int maxVal)
{
	string strVal = trim(aString);

	if(strVal.length() == 0)
		return defaultVal;

	boolean negative = false;
	boolean center = false;
	UINT i = 0;
	int value = 0;

	if(strVal[i] == '-')
	{
		negative = true;
		i++;
	}
	else if(strVal[i] == '+')
	{
		i++;
	}

	while(i < strVal.length())
	{
		if(strVal[i] >= '0' && strVal[i] <= '9')
		{
			value = (value * 10) + (strVal[i] - '0');
		}
		else
		{
			if(strVal[i] == 'c' || strVal[i] == 'C')
				center = true;

			break;
		}

		i++;
	}

	if(center)
	{
		if(negative)
			value = (maxVal / 2) - value;
		else
			value = (maxVal / 2) + value;
	}
	else if(negative)
	{
		value = maxVal - value;
	}

	return value;
}

// retrieve a coordinate from step.rc, accounting for negative values and centering
LSAPI int GetRCCoordinate(LPCSTR property, int defaultVal, int maxVal)
{
	char buf[1024];
	GetRCString(property, buf, "",1024);
	string strVal = buf;
	return ParseCoordinate(strVal, defaultVal, maxVal);
}

// retrieve handle of the desktop window
HWND GetLitestepDesktop()
{
	HWND hWnd = FindWindow("DesktopBackgroundClass", 0);

	if(hWnd != 0)
		return hWnd;

	return GetDesktopWindow();
}
