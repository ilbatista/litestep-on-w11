#ifndef __UTILITY_HEADER__
#define __UTILITY_HEADER__

HWND GetLitestepDesktop();

#endif