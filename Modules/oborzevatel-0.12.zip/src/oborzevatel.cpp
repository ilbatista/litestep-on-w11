// oborzevatel.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "oborzevatel.h"

// Any common LiteStep module (i.e. LoadModule) must export 2 functions:
//   initModuleEx - it must be used for initialization: settings reading, windows creation, etc.
//     quitModule - when LiteStep want to unload the module, it called this procedure first
extern "C" {
    __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
    __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

// Revision ID support
int lsMessages[] = {
	LM_GETREVID,
	0
};
HWND messageHandler;
LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
const char rcsRevision[] = "0.1.2"; 

// Exported !bangs
void bangShowWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangHideWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangToggleVisibility(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangRefreshWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangRefreshIfExpired(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangRefreshCompletely(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);

//Brandon Goldsworthy 2003-11-08
void bangGoToURL(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
//--

// Main application class variable
COborzevatelApp theApp;

BEGIN_MESSAGE_MAP(COborzevatelApp, CWinApp)
	//{{AFX_MSG_MAP(COborzevatelApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//Initialization... is empty :)
COborzevatelApp::COborzevatelApp()
{
}

// Just enable OLE containers usage. It isn't necessary to do it here,
// but in the first versions there was a usefull code and I was too lazy
// to delete the function :)
BOOL COborzevatelApp::InitInstance() 
{
	AfxEnableControlContainer();
	return CWinApp::InitInstance();
}

// Each time we read new Oborzevatel window name from step.rc, this function called
// It reads the window config from the step.rc, calls initialization and, if successfull,
// exports some !bangs
bool COborzevatelApp::CreateBrowserWindow(char *wname)
{
	RECT r;
	char s[1024];
	char buf[1024];
	int lb;
	sprintf(s,"%sX",wname);
	r.left = GetRCCoordinate(s, 0, GetSystemMetrics(SM_CXSCREEN));
	sprintf(s,"%sY",wname);
	r.top  = GetRCCoordinate(s, 0, GetSystemMetrics(SM_CYSCREEN));
	sprintf(s,"%sWidth",wname);
	//
	// RECT is only a convenient structure for sending coords as one parameter,
	// r.right is width, r.bottom is height of the window... I was too lazy to
	// create a new structure and mistaken last time with the implemetation -
	// added r.left to width and r.top to height :)
	// Thanks to Ego for bug report :)
	//
	r.right = GetRCInt(s, 100);
	sprintf(s,"%sHeight",wname);
	r.bottom = GetRCInt(s, 100);
	sprintf(s,"%sHidden",wname);
	bool bVisible = !GetRCBoolDef(s,false);
	sprintf(s,"%sOnDesktop",wname);
	bool bChild = GetRCBoolDef(s,true);

	HWND hParent = bChild ? DesktopWnd : LitestepWnd;

	MyHTMLView *w = new MyHTMLView;
	if(NULL != w)
	{
		if (w->CreateMe(hParent,wname,r,bVisible,bChild))
		{
			sprintf(s,"%sURL",wname);
			GetRCLine(s,buf,1024,"http://www.litestep.net/");
			lb = strlen(buf);
			if (lb>0 && buf[lb-1] == '"') buf[lb-1] = 0;
			if (buf[0] == '"')
				w->Navigate2(_T(buf+1),NULL,NULL);
			else
				w->Navigate2(_T(buf),NULL,NULL);
			wlist.insert(wlist.end(),w);
			sprintf(s,"!%sShow",wname);
			AddBangCommandEx(s,bangShowWindow);
			sprintf(s,"!%sHide",wname);
			AddBangCommandEx(s,bangHideWindow);
			sprintf(s,"!%sToggleVisibility",wname);
			AddBangCommandEx(s,bangToggleVisibility);
			sprintf(s,"!%sRefresh",wname);
			AddBangCommandEx(s,bangRefreshWindow);
			sprintf(s,"!%sRefreshIfExpired",wname);
			AddBangCommandEx(s,bangRefreshIfExpired);
			sprintf(s,"!%sRefreshCompletely",wname);
			AddBangCommandEx(s,bangRefreshCompletely);
			sprintf(s,"!%sGoToURL",wname); //BG
			AddBangCommandEx(s,bangGoToURL); //BG
			return true;
		}
		else
			MessageBox(0,"Errr... Cannot create IE window...","Oborzevatel: Fatal Error :((",0);
	}
	else
		MessageBox(0,"Errr... Cannot create a CWnd... suppose that not enough system resources","Oborzevatel.dll: Fatal Error :((",0);
	return false;
}

// ShowHTMLWindow calls all initialization routines
// Only one thing is missed - RevID was moved to initModuleEx directly,
// because it is class-independent, but everything else is a work with the
// WndList list, which is a part of COborzevatelApp class.
int COborzevatelApp::ShowHMTLWindows()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// Find LiteStep and Desktop windows.
	// First will be used for WS_POPUP, latter - for the WS_CHILD windows...
	LitestepWnd = GetLitestepWnd();
	DesktopWnd  = GetLitestepDesktop();

	//looking for the OborzevatelWindows line in step.rc
	FILE *f;
	int crs;
	int i;
	char curname[1024];
	if(f = LCOpen(NULL))
	{
		char lineBuffer[MAX_LINE_LENGTH];
		while(LCReadNextConfig(f, "OborzevatelWindows", lineBuffer, MAX_LINE_LENGTH))
		{
			char* buffers[1];
			char commandName[64] = { 0 };
			buffers[0] = commandName;
			char value[MAX_LINE_LENGTH];
			LCTokenize(lineBuffer, buffers, 1, value);
			if(value[0] && _stricmp("OborzevatelWindows",commandName) == 0)
			{
				// parse OborzevatelWindows line: read names of the windows from it
				crs = 0;
				while(value[crs])
				{
					curname[crs] = 0;
					i = 0;
					while (isalnum(value[crs]) || value[crs] == '.' || value[crs] == '_')
					{
						curname[i] = value[crs];
						crs++;
						i++;
					}
					curname[i] = 0;
					CreateBrowserWindow(curname);
					while (value[crs] && !isalnum(value[crs]) && value[crs] != '.' && value[crs] != '_')	crs++;
				}
			}
		}

		LCClose(f);
	} else MessageBox(NULL,"Oooops!!!","Oborzevatel",MB_OK);
	return true;
}

void COborzevatelApp::QuitModule()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	for(WndListIterator wi = wlist.begin(); wi != wlist.end(); wi++)
		delete *wi;
	wlist.clear();
}

int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
	// First we shall create a window for message handling
	// There is only one message in this version - REVID :)
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = MessageHandlerProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = dll;
	wc.hbrBackground = NULL;
	wc.hCursor = NULL;
	wc.hIcon = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = "OborzevatelMessageHandlerLS";
	wc.hIconSm = 0;

	if (!RegisterClassEx(&wc))
	{
		MessageBox(0,"Cannot register main window class...","Oborzevatel: Error :((",0);
		return 1;
	}

	messageHandler = CreateWindowEx(WS_EX_TOOLWINDOW,
		"OborzevatelMessageHandlerLS",
		0,
		WS_POPUP,
		0, 0, 0, 0, 
		0,
		0,
		dll,
		0);

	if (!messageHandler)
	{
		MessageBox(0,"Cannot create main window...","Oborzevatel: Error :((",0);
		return 1;
	}	
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM) messageHandler, (LPARAM) lsMessages);
	return !(theApp.ShowHMTLWindows());
}


void quitModule(HINSTANCE dllInst)
{
	theApp.QuitModule();
	SendMessage(GetLitestepWnd(),LM_UNREGISTERMESSAGE,(WPARAM) messageHandler,(LPARAM) lsMessages);
	DestroyWindow(messageHandler);
	UnregisterClass("OborzevatelMessageHandlerLS", dllInst);
}

LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case LM_GETREVID:
		LPSTR buf = (LPSTR)lParam;
		switch (wParam)
		{
		case 0:
		case 1:
			sprintf(buf, "oborzevatel.dll: %s", rcsRevision);
			break;
		default:
			strcpy(buf, "");
		}
		return strlen(buf);
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}



MyHTMLView * COborzevatelApp::LookupWnd(const char *name)
{
	for(WndListIterator wi = wlist.begin(); wi != wlist.end(); wi++)
	{
		if(_stricmp(name, (*wi)->wname) == 0)
			return *wi;
	}
	return NULL;
}

void COborzevatelApp::BangShowWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 5).c_str());
	if(w != 0)
	{
		w->ShowWindow(SW_SHOW);
		w->visible = true;
	}
}

void COborzevatelApp::BangHideWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 5).c_str());
	if(w != 0)
	{
		w->ShowWindow(SW_HIDE);
		w->visible = false;
	}
}

void COborzevatelApp::BangToggleVisibility(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 17).c_str());
	if(w != 0)
	{
		if (w->visible)
			w->ShowWindow(SW_HIDE);
		else
			w->ShowWindow(SW_SHOW);
		w->visible = !w->visible;
	}
}

void COborzevatelApp::BangRefreshWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	VARIANT rlevel;
	rlevel.intVal = REFRESH_NORMAL;
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 8).c_str());
	if(w != 0)
		w->Refresh2(&rlevel);
}

void COborzevatelApp::BangRefreshIfExpired(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	VARIANT rlevel;
	rlevel.intVal = REFRESH_IFEXPIRED;
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 17).c_str());
	if(w != 0)
		w->Refresh2(&rlevel);
}

void COborzevatelApp::BangRefreshCompletely(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	VARIANT rlevel;
	rlevel.intVal = REFRESH_COMPLETELY;
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 22).c_str());
	if(w != 0)
		w->Refresh2(&rlevel);
}

//Brandon Goldsworthy 2003-11-08
void COborzevatelApp::BangGoToURL(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	string wname = string(szCommand);
	
	char buf[1024];
	strcpy(buf, szArgs);
	int lb = strlen(buf);
	if (lb>0 && buf[lb-1] == '"') buf[lb-1] = 0;
	
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 8).c_str());
	if (buf[0] == '"')
		w->Navigate2(_T(buf+1),NULL,NULL);
	else
		w->Navigate2(_T(buf),NULL,NULL);
}
//--


void bangShowWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangShowWindow(hSender,szCommand,szArgs);
}

void bangHideWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangHideWindow(hSender,szCommand,szArgs);
}

void bangToggleVisibility(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangToggleVisibility(hSender,szCommand,szArgs);
}

void bangRefreshWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangRefreshWindow(hSender,szCommand,szArgs);
}

void bangRefreshIfExpired(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangRefreshIfExpired(hSender,szCommand,szArgs);
}

void bangRefreshCompletely(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangRefreshCompletely(hSender,szCommand,szArgs);
}

//BG
void bangGoToURL(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangGoToURL(hSender,szCommand,szArgs);
}
//--
