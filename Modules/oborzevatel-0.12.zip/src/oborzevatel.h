// oborzevatel.h : main header file for the OBORZEVATEL DLL
//

#if !defined(AFX_OBORZEVATEL_H__5C39BAF3_C3BB_4749_9D92_F1787D443C8C__INCLUDED_)
#define AFX_OBORZEVATEL_H__5C39BAF3_C3BB_4749_9D92_F1787D443C8C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "..\ils\lsapi\lsapi.h"
#include "utility.h"
#include "MyHTMLView.h"	// Added by ClassView

/////////////////////////////////////////////////////////////////////////////
// COborzevatelApp
// See oborzevatel.cpp for the implementation of this class
//

#include <list>
using namespace std;

typedef list<MyHTMLView*> WndList;
typedef list<MyHTMLView*>::iterator WndListIterator;

class COborzevatelApp : public CWinApp
{
	HWND LitestepWnd, DesktopWnd;
public:
	void BangGoToURL(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
	void BangToggleVisibility(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
	void BangRefreshCompletely(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
	void BangRefreshIfExpired(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
	void BangRefreshWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
	void BangShowWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
	void BangHideWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
	MyHTMLView * LookupWnd(const char *name);
	bool CreateBrowserWindow(char *wname);
	int ShowHMTLWindows();
	void QuitModule();
	WndList wlist;
	COborzevatelApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COborzevatelApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(COborzevatelApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OBORZEVATEL_H__5C39BAF3_C3BB_4749_9D92_F1787D443C8C__INCLUDED_)
