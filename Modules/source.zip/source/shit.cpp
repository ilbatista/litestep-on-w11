//(C)2002 Mike Edward Moras / e-sushi@gmx.net
// GNU GPL sourcecode! USE AT OWN RISK
/*
10.10.2002 e-sushi
   - expanded testing to 3-part test
     including logfile io, rc io and recycle
   - implemented yes-no boxes (ayamame's idea)
08.10.2002 e-sushi
   - first release with a 100 x recycle test
*/
#include "shit.h"
const char szAppName[] = "SushiTest"; // Our window class, etc

const char rcsId[] = " SushiTest.dll v1.1 by e-sushi "; // The Full RCS ID.
Shit *shit; // The module


//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  int code;
  Window::init(dllInst);
  shit = new Shit(ParentWnd, code);
  return code;
}

void quitModule(HINSTANCE dllInst)
{
  delete shit;
}


//=========================================================
// Bang commands
//=========================================================
void BangShitFunction(HWND caller, LPCSTR args) {
  shit->BangShit(caller, args);
}


//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Shit::Shit(HWND parentWnd, int& code):
Window(szAppName)
{

  int msgs[] = {LM_GETREVID, 0};


  if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
                    0, 0, 0, 0, parentWnd))
  {
    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
    code = 1;
    return;
  }

  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
  SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
  AddBangCommand("!SushiTest",BangShitFunction);
  code = 0;
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
Shit::~Shit()
{
  int msgs[] = {LM_GETREVID, 0};
  SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
  RemoveBangCommand("!SushiTest");
  destroyWindow();
}


//=========================================================
// Registered messages
//=========================================================

void Shit::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,          LM_GETREVID)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void Shit::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void Shit::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


void Shit::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}



//=========================================================
// Bang command handling
//=========================================================
void Shit::BangShit(HWND caller, LPCSTR args) {
	
	LSLog(LOG_NOTICE, szAppName, "starting ***");

	char memmessage[MAX_PATH]="",memdummy[MAX_PATH]="";

	strcpy(memmessage,"Part 1\n\nTest: Recycle stability (100 commands: Recycle)\n\nStart?");
	if (MessageBox(caller, memmessage, szAppName, MB_YESNO | MB_SETFOREGROUND) == IDYES)
	{
		HWND ls = GetLitestepWnd();
		if (ls)
		{
			for (int i=0;i<100;i++)
			{
				PostMessage(ls, LM_RECYCLE, 0, 0);
			}
			LSLog(LOG_NOTICE, szAppName, "part 1 completed ***");
			MessageBox(caller,"Part 1: finished...","SushiTest.dll",MB_OK);
		}
	} else {
		LSLog(LOG_NOTICE, szAppName, "part 2 skipped ***");
	};
	

	strcpy(memmessage,"Part 2\n\nTest: IO access stability (200 commands: RC-IO, RECYCLE)\n\nStart?");
	if (MessageBox(caller, memmessage, szAppName, MB_YESNO | MB_SETFOREGROUND) == IDYES)
	{
		HWND ls = GetLitestepWnd();
		if (ls)
		{
			for (int i=0;i<200;i++)
			{
				GetRCString("dummy", memdummy, "", MAX_PATH);
				PostMessage(ls, LM_RECYCLE, 0, 0);
			}
			LSLog(LOG_NOTICE, szAppName, "part 2 completed ***");
			MessageBox(caller,"Part 2: finished...","SushiTest.dll",MB_OK);
		}
	} else {
		LSLog(LOG_NOTICE, szAppName, "part 2 skipped ***");
	};
	


	strcpy(memmessage,"Part 3\n\nTest: Stess (2010 commands: RC-IO, LOGFILE, RECYCLE)\n\nStart?");
	if (MessageBox(caller, memmessage, szAppName, MB_YESNO | MB_SETFOREGROUND) == IDYES)
	{
		HWND ls = GetLitestepWnd();
		if (ls)
		{
			for (int i=0;i<10;i++)
			{
				for (int i=0;i<50;i++)
				{
					GetRCString("dummy", memdummy, "", MAX_PATH);
					LSLog(LOG_NOTICE, szAppName, "stess testing ***");
					GetRCBool("dummy", true);
					LSLog(LOG_NOTICE, szAppName, "stess testing ***");
				}
				PostMessage(ls, LM_RECYCLE, 0, 0);
			}
			LSLog(LOG_NOTICE, szAppName, "part 3 completed");
			MessageBox(caller,"Part 3: finished...\n\nLitestep still up and running stable?","SushiTest.dll",MB_OK);	
		}
	} else {
		LSLog(LOG_NOTICE, szAppName, "part 2 skipped ***");
	};

	LSLog(LOG_NOTICE, szAppName, "finished ***");
}


//(C)2002 Mike Edward Moras / e-sushi@gmx.net
// GNU GPL sourcecode! USE AT OWN RISK
