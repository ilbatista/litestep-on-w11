//(C)2002 Mike Edward Moras / e-sushi@gmx.net
// GNU GPL sourcecode! USE AT OWN RISK


#ifndef __shit_H
#define __shit_H

#include <windows.h>
#include "C:\_development\CURRENT\LSAPI\lsapi.h"
#include "C:\_development\CURRENT\LSAPI\lswinbase.h"

#define MAX_LINE_LENGTH 4096

class Shit : public Window
{
private:

public:
  Shit(HWND parentWnd, int& code);
  ~Shit();

  void BangShit(HWND, LPCSTR);


private:
  virtual void windowProc(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onSysCommand(Message& message);

};

void BangShitFunction(HWND, LPCSTR);


extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
//(C)2002 Mike Edward Moras / e-sushi@gmx.net
// GNU GPL sourcecode! USE AT OWN RISK
