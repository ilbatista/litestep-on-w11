/*
This is a part of the One LiteStep module source code.

Copyright (C) 2002 Erik Christiansson, aka Sci
erik@alphafish.com
www.alphafish.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "one.h"

int initModuleEx(HWND hParent, HINSTANCE hInstance, LPCSTR szPath)
{
	AddBangCommand("!One", bangOne);

	return 0;
}

void quitModule(HINSTANCE hInstance)
{
	RemoveBangCommand("!One");
}

void bangOne(HWND hCaller, LPCSTR szArgs)
{
	BOOL (WINAPI *SwitchToThisWindow)(HWND, BOOL) = (BOOL (WINAPI *)(HWND, BOOL)) GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");
	char szClass[1024] = "", szTitle[1024] = "", szOpen[1024] = "", szClosed[1024] = "";
	HWND hWnd = NULL;

	GetToken(szArgs, szClass, &szArgs, true);
	GetToken(szArgs, szTitle, &szArgs, true);
	GetToken(szArgs, szClosed, &szArgs, true);
	GetToken(szArgs, szOpen, &szArgs, true);

	if(!strlen(szTitle)) {
		if(strlen(szClass)) {
			hWnd = FindWindow(szClass, NULL);
		}
	}
	else {
		if(!strlen(szClass)) {
			hWnd = FindWindow(NULL, szTitle);
		}
		else {
			hWnd = FindWindow(szClass, szTitle);
		}
	}

	if(!hWnd) {
		LSExecute(hCaller, szClosed, NULL);
	}
	else {
		if(!stricmp(szOpen, ".focus") || !strlen(szOpen)) {
			SwitchToThisWindow(hWnd, TRUE);
		}
		else if(!stricmp(szOpen, ".minimize")) {
			SendMessage(hWnd, WM_SYSCOMMAND, SC_MINIMIZE, NULL);
		}
		else if(!stricmp(szOpen, ".maximize")) {
			SendMessage(hWnd, WM_SYSCOMMAND, SC_MAXIMIZE, NULL);
		}
		else if(!stricmp(szOpen, ".restore")) {
			SendMessage(hWnd, WM_SYSCOMMAND, SC_RESTORE, NULL);
		}
		else if(!stricmp(szOpen, ".close")) {
			SendMessage(hWnd, WM_SYSCOMMAND, SC_CLOSE, NULL);
		}
		else if(!stricmp(szOpen, ".show")) {
			ShowWindow(hWnd,SW_SHOW);
		}
		else if(!stricmp(szOpen, ".hide")) {
			ShowWindow(hWnd,SW_HIDE);
		}
		else {
			LSExecute(hCaller, szOpen, NULL);
		}
	}
}
