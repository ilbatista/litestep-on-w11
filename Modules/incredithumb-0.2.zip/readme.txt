IncrediThumb readme

//===========================================================================
//  Intro
//

IncrediThumb is a simple module I created to test DWM thumbnail features in
litestep. Currently it displays the thumbnail of a single window whose name
is passed in via !IncrediThumbChangeThumb <windowname>.

//===========================================================================
//  RC Configuration
//

There are some basic settings that can be specified in RC files:

IncrediThumbAlwaysOnTop     <true or false> (default = false)
IncrediThumbStartHidden     <true or false> (default = true)
IncrediThumbX               <screen x position> 
IncrediThumbY               <screen y position>

IncrediThumbWidth           <any number> (default = 32)
IncrediTHumbHeight          <any number> (default = 32)

    -- Setting the width/height only affects the starting size of the 
       thumbnail window. The window will be resized as soon as a source 
       window is set.


IncrediThumbThumbnailSize   <any number> (default = 128)

    -- Sets the maximum size the thumbnail should be.

IncrediThumbDestinationWindow   <windowname>

    -- Sets the destination window the thumbnail will be rendered to by 
       the window's name. If there are multiple windows with the same name it
       will use the first one it finds. If this value isn't set the thumb
       will be rendered to the module's own window.
       
//===========================================================================
//  Bangs
//

!IncrediThumbAlwaysOnTop

    -- Sets incredithumb to try to stay on top.
    
!IncrediThumbChangeThumb <sourcename>

    -- Sets the source window for the thumbnail to display. This uses the
       name of the window and will display the FIRST window found with the
       name provided.
       
!IncrediThumbHide

    -- Hides the module window.
    
!IncrediThumbMoveTo <xposition> <yposition>

    -- Moves the module window to the passed position.
    
!IncrediThumbResizeTo <width> <height>

    -- Resizes the module window to the passed size. Useless since the module
       resizes itself anyway.
       
!IncrediThumbShow

    -- Shows the module window.
    
!IncrediThumbToggle

    -- Toggles the module windows' visiblity to the opposite state that it is
       currently set to.
    
!IncrediThumbToggleAlwaysOnTop

    -- Toggles module windows' alwaysOnTop setting to the opposite state that
       it is currently set to.
       
       
//===========================================================================
//  Changes
//

0.1     Initial release.
0.2     Added the ability to set the destination window.