#ifndef __GUIWINDOW_H
#define __GUIWINDOW_H

#include "window.h"

#define CHILDWINDOWS

// want support for childwindows?
#ifdef CHILDWINDOWS
#include <list>
using namespace std;
#endif

class GuiWindow : public Window
{
protected:
	int nXPos;
	int nYPos;

	int nWidth;
	int nHeight;

	// save screen width
	int nScreenWidth;
	int nScreenHeight;

	bool bInWharf;
	bool bLsBoxed;
	bool bVisible;
	bool bOnTop;

	HWND hwndParent;
#ifdef CHILDWINDOWS
	list<HWND> childwindows;
#endif

public:
	GuiWindow(LPCSTR szAppName, HWND parentWnd, bool Wharfed);
	~GuiWindow();

#ifdef CHILDWINDOWS
	bool RegisterChildWindow(HWND child);
	bool DeRegisterChildWindow(HWND child);
#endif

	// set settings
	void SetPosition(int x_pos, int y_pos);
	void SetSize(int x_size, int y_size);

	void Move(int x_pos, int y_pos);
	void Size(int x_size, int y_size);
	void Show(void);
	void Hide(void);
	void ToggleVisibility(void);
	void SetOnTop(bool fAlwaysOnTop);
	void ToggleOnTop(void);
	void BoxHook(LPCSTR szArgs);

	// re-set positions, just in case
	void FixPosition();

	int GetHeight(void);
	int GetWidth(void);
	int GetX(void);
	int GetY(void);
	HWND GetHWND(void);
	HWND GetParentHWND(void);

	void SetLsBoxed(bool);
	void SetTop(bool);
	void SetVisible(bool);
	void SetInWharf(bool);

	bool IsInWharf(void);
	bool IsOnTop(void);
	bool IsVisible(void);
	bool IsLsBoxed(void);

};

#endif