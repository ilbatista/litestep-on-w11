DeskTasks - by Remco de Jong (rdj@telekabel.nl)

This module shows all current tasks as bitmaps in the bottom left of the screen, like the task manager in WindowMaker.

changes since 0.2:

- it supports .extract for determining appicons, you should thank to Killarny for this :)
- configuration has moved from the tasks.rc to step.rc
- minor bugfixes and other changes, as usual :)

Options in step.rc:

TasksDirection right
(This can be up / down / right / left, be sure to use TasksX when you set the directon to left.)
TasksSize 64
TasksX 0
TasksY 534
TasksBackPix <bitmap>
DefaultAppIcon <bitmap>
AutoArrangeTasks
(TaskBackPix and DefaultAppIcon _MUST_ be in your step.rc)

TasksTitlesAlways
TasksTitlesWhenMinimized
TasksFont "Arial"
TasksFontSize 12
TasksTextColor FFFFFF
TasksBackColor 000000
(not using any of the last 6 will result in never having titles)

LoadModule C:\litestep\tasks.dll

Always put the LoadModule AFTER you loaded desktop.dll etc, so as the last module in the list.

To configure a bitmap for a task you would need the following entry in your step.rc:

*Task "Netscape" netscape.bmp

This line would give all windows with "Netscape" in the _title_ the icon netscape.bmp.

To do list:

- tooltips
- right button menu (Wouldn't it be nice if the new popups had entries to make this easier? I don't want those windows style popups)
- option to make icons stay on top
- bang command for hiding/unhiding the icons

Please e-mail any suggestions / bugs / complaints to rdj@telekabel.nl, or message [rDJ] in #litestep...