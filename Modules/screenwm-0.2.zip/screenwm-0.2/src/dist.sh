#!/bin/bash

VERSION=0.2
DISTDIR=dist
PACKAGEDIR=$DISTDIR/screenwm-$VERSION

if [ -d "$PACKAGEDIR" ]; then
	rm -rf "$PACKAGEDIR"
fi

mkdir -p "$PACKAGEDIR/src"

cp screenvwm/Release/screenvwm.dll "$PACKAGEDIR"
cp screenhk/Release/screenhk.dll "$PACKAGEDIR"

cp -R screenhk screenvwm "$PACKAGEDIR/src"
cp dist.sh Doxyfile *.txt *.sln "$PACKAGEDIR/src"
cp README* license.txt "$PACKAGEDIR"

# Remove intermediate files
(
	cd "$PACKAGEDIR/src"
	rm -rf Release Debug screenhk/Release screenhk/Debug
)

# Zip it all up
(
	cd $DISTDIR
	zip -r screenwm-$VERSION.zip "screenwm-$VERSION"
)

