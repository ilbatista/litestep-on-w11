#pragma once

enum FlowDirection
{
	directionLeftDown=1,
	directionLeftUp,
	directionRightDown,
	directionRightUp,
	directionDownRight,
	directionDownLeft,
	directionUpRight,
	directionUpLeft,
};

void directionStart(FlowDirection dir, int &x, int &y, int minX, int minY, int maxX, int maxY);
bool directionNext(FlowDirection dir, int &x, int &y, int minX, int minY, int maxX, int maxY, int stepX, int stepY);
int directionCountSteps(FlowDirection dir, int x, int y, int minX, int minY, int maxX, int maxY, int stepX, int stepY);
FlowDirection directionFromString(const char *str);

struct RCSettings
{
public:
	~RCSettings();
	void refresh(bool inWharf);
	
	// Position
	int vwmX;
	int vwmY;
	int vwmWidth;
	int vwmHeight;
	bool movable;
	int snapDistance;
	
	// Internal layout
	int vwmLeftSpacing;
	int vwmRightSpacing;
	int panelSpacing;
	
	// Focus settings
	bool switchOnFocus;
	bool focusCenter;

	// Window tracking settings
	int pollInterval;

	// VWM display settings
	int vwmTitleBarsThickness;
	int vwmIconSize;
	
	// Task display settings
	int tasksIconSize;
	int tasksBorderThickness;
	FlowDirection taskFlowDirection;
	int tasksOffsetX;
	int tasksOffsetY;
	int tasksOffsetXMin;
	int tasksOffsetYMin;
	int tasksOffsetXFocused;
	int tasksOffsetYFocused;
	
	// Visibility settings
	bool visible;
	bool onTop;
	int autoHideDistance;
	
	// Colors
	COLORREF panelBackgroundColor;
	COLORREF panelBorderColor;
	COLORREF vwmBackgroundColor;
	COLORREF vwmWindowColor;
	COLORREF vwmTitleBarColor;
	COLORREF vwmFocusedTitleBarColor;
	COLORREF vwmBorderColor;
	COLORREF vwmWindowBorderColor;
	COLORREF tasksBackColor;
	COLORREF tasksBackColorMin;
	COLORREF tasksBackColorFocused;
	COLORREF tasksBorderColor;
	COLORREF tasksBorderColorMin;
	COLORREF tasksBorderColorFocused;
	COLORREF labelColor;
	COLORREF labelBackColor;
	COLORREF labelColorFocused;
	COLORREF labelBackColorFocused;
};

static RCSettings settings;