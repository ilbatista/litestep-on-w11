#ifndef TRACE_HPP
#define TRACE_HPP
#include <stdio.h>

class TraceStream
{
public:
	template<class T>
	TraceStream &operator<<(T x);
	
	void close();
	
private:
	bool initIfNeeded();
	FILE *fout;
};
extern TraceStream trace;

#endif //TRACE_HPP