#include <litestep/lsapi/lsapi.h>
#include "rcsettings.hpp"
#include "trace.hpp"
#pragma warning (disable: 4800)

void directionStart(FlowDirection dir, int &x, int &y, int minX, int minY, int maxX, int maxY)
{
	switch(dir)
	{
		default:
		case directionRightDown: x = minX; y = minY; break;
		case directionRightUp:   x = minX; y = maxY; break;
		case directionLeftDown:  x = maxX; y = minY; break;
		case directionLeftUp:    x = maxX; y = maxY; break;
		case directionUpLeft:    x = maxX; y = maxY; break;
		case directionUpRight:   x = minX; y = maxY; break;
		case directionDownLeft:  x = maxX; y = minY; break;
		case directionDownRight: x = minX; y = minY; break;
	}
}

FlowDirection directionFromString(const char *str)
{
	if(!stricmp(str, "left"))       return directionLeftDown;
	if(!stricmp(str, "right"))      return directionRightDown;
	if(!stricmp(str, "up"))         return directionUpRight;
	if(!stricmp(str, "down"))       return directionDownRight;
	if(!stricmp(str, "left up"))    return directionLeftUp;
	if(!stricmp(str, "left down"))  return directionLeftDown;
	if(!stricmp(str, "right down")) return directionRightDown;
	if(!stricmp(str, "right up"))   return directionRightUp;
	if(!stricmp(str, "up left"))    return directionUpLeft;
	if(!stricmp(str, "up right"))   return directionUpRight;
	if(!stricmp(str, "down left"))  return directionDownLeft;
	if(!stricmp(str, "down right")) return directionDownRight;
	
	// Default
	return directionRightDown;
}

bool directionNext(FlowDirection dir, int &x, int &y, int minX, int minY, int maxX, int maxY, int stepX, int stepY)
{
	switch(dir)
	{
		default:
		case directionRightDown:
		case directionRightUp:
			if(x+stepX <= maxX) {
				x += stepX;
				return true;
			} else {
				x = minX;
				if(dir == directionRightUp) {
					y -= stepY;
					return (y>=minY);
				} else { //dir==directionRightDown or default
					y += stepY;
					return (y<=maxY);
				}
			}
			break;
		case directionLeftDown:
		case directionLeftUp:
			if(x-stepX >= minX) {
				x -= stepX;
				return true;
			} else {
				x = maxX;
				if(dir == directionLeftDown) {
					y += stepY;
					return (y<=maxY);
				} else { //dir==directionLeftUp
					y -= stepY;
					return (y>=minY);
				}
			}
		case directionUpLeft:
		case directionUpRight:
			if(y-stepY >= minY) {
				y -= stepY;
				return true;
			} else {
				y = maxY;
				if(dir == directionUpRight) {
					x += stepX;
					return (x<=maxX);
				} else { //dir==directionUpLeft
					x -= stepX;
					return (x>=minX);
				}
			}
		case directionDownLeft:
		case directionDownRight:
			if(y+stepY <= maxY) {
				y += stepY;
				return true;
			} else {
				y = minY;;
				if(dir == directionDownRight) {
					x += stepX;
					return (x<=maxX);
				} else { //dir==directionUpLeft
					x -= stepX;
					return (x>=minX);
				}
			}
	}
}

int directionCountSteps(FlowDirection dir, int x, int y, int minX, int minY, int maxX, int maxY, int stepX, int stepY)
{
	// TODO: Do this more efficiently (can be O(1) instead of this O(n) crap)
	int posX, posY;
	int ii=0;
	directionStart(dir, posX, posY, minX, minY, maxX, maxY);
	do {
		if(posX==x && posY==y)
			return ii;
		ii++;
	} while(directionNext(dir, posX, posY, minX, minY, maxX, maxY, stepX, stepY));
	
	return -1;
}

RCSettings::~RCSettings()
{
}

void RCSettings::refresh(bool inWharf)
{
	char buf[512];
	
	// Position
	vwmX = GetRCCoordinate("vwmX", 0, GetSystemMetrics(SM_CXSCREEN));
	vwmY = GetRCCoordinate("vwmY", 0, GetSystemMetrics(SM_CYSCREEN));
	vwmWidth = GetRCInt( "vwmWidth", 64 );
	vwmHeight = GetRCInt( "vwmHeight", 320 );
	
	movable = inWharf && GetRCBool("vwmNoMove", FALSE);
	if(!movable)
		snapDistance = 0;
	else 
		snapDistance = GetRCInt("vwmSnapDistance", 10);
	
	// Internal layout settings
	vwmLeftSpacing = GetRCInt("vwmViewLeftSpacing", 3);
	vwmRightSpacing = GetRCInt("vwmViewRightSpacing", 3);
	panelSpacing = GetRCInt("vwmPanelSpacing", 10);
	
	// Focus settings
	switchOnFocus = GetRCBool("vwmNoSwitchOnFocus", FALSE);
	focusCenter = GetRCBool("vwmFocusCenter", TRUE);
	
	// Window tracking settings
	pollInterval = GetRCInt("vwmPollInterval", 500);
	if(pollInterval && pollInterval < 10) pollInterval = 10;
	
	// VWM display settings
	if(GetRCBool("vwmNoTitleBars", FALSE))
		vwmTitleBarsThickness = GetRCInt("vwmTitleBarThickness", 4);
	else
		vwmTitleBarsThickness = 0;
	
	vwmIconSize = (GetRCBool("vwmNoIcons", FALSE)) ? GetRCInt("vwmIconSize", 16) : 0;
	
	// Task display settings
	tasksIconSize = GetRCInt("tasksIconSize", 32);
	tasksBorderThickness = GetRCInt("tasksBorderThickness", 1);
	GetRCLine("tasksFlowDirection", buf, 512, "default");
	taskFlowDirection = directionFromString(buf);
	trace << "tasksFlowDirection is '"<<buf<<"'\n";
	
	tasksOffsetX = GetRCInt("tasksOffsetX", 0);
	tasksOffsetY = GetRCInt("tasksOffsetY", 0);
	tasksOffsetXMin = GetRCInt("tasksOffsetXMin", 0);
	tasksOffsetYMin = GetRCInt("tasksOffsetYMin", 12);
	tasksOffsetXFocused = GetRCInt("tasksOffsetXFocused", 0);
	tasksOffsetYFocused = GetRCInt("tasksOffsetYFocused", 0);
	
	// Visibility settings
	visible = inWharf || GetRCBool("vwmHidden", FALSE); // renamed from vwmNoShow
	onTop = !inWharf && GetRCBool("vwmNotAlwaysOnTop", FALSE);
	if(inWharf && GetRCBool("vwmAutoHide", TRUE))
		autoHideDistance = GetRCInt("vwmAutoHideDistance", 10);
	else
		autoHideDistance = 0;
	
	// Color settings
	panelBackgroundColor    = GetRCColor("vwmPanelColor",           0xaaaaaa);
	vwmBackgroundColor      = GetRCColor("vwmBackColor",            0x808080);
	vwmWindowColor          = GetRCColor("vwmWinColor",             0xffffff);
	vwmTitleBarColor        = GetRCColor("vwmTitleBarColor",        0x505050);
	vwmFocusedTitleBarColor = GetRCColor("vwmFocusedTitleBarColor", 0xff0000);
	vwmBorderColor          = GetRCColor("vwmBorderColor",          0x000000);
	vwmWindowBorderColor    = GetRCColor("vwmWinBorderColor",       0x000000);
	tasksBackColor          = GetRCColor("tasksBackColor",          panelBackgroundColor);
	tasksBackColorMin       = GetRCColor("tasksBackColorMin",       panelBackgroundColor);
	tasksBackColorFocused   = GetRCColor("tasksBackColorFocused",   0x555555);
	tasksBorderColor        = GetRCColor("tasksBorderColor",        panelBackgroundColor);
	tasksBorderColorMin     = GetRCColor("tasksBorderColorMin",     panelBackgroundColor);
	tasksBorderColorFocused = GetRCColor("tasksBorderColorFocused", 0x000000);
	labelColor              = GetRCColor("vwmLabelColor",           0x000000);
	labelBackColor          = GetRCColor("vwmLabelBackColor",       panelBackgroundColor);
	labelColorFocused       = GetRCColor("vwmLabelColorFocused",    0xffffff);
	labelBackColorFocused   = GetRCColor("vwmLabelBackColorFocused",0xaa0000);
}
