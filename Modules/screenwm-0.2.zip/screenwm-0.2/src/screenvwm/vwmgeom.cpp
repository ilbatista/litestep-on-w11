#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include <math.h>
#include "vwm.h"
#include "trace.hpp"

void VWM::initDesktops()
{
	// get the position and size of the main window
	// using different method if it's docked in the wharf
	if(inWharf)
	{
		RECT rc;
		int wharfBorder = GetRCInt("WharfBevelWidth", 1);

		// get the wharf window size
		GetClientRect(parentWindow, &rc); // FIXME: Possible order-of-initialization problem here
		
		windowX = wharfBorder;
		windowY = wharfBorder;
		windowWidth = rc.right - 2 * wharfBorder;
		windowHeight = rc.bottom - 2 * wharfBorder;
	}
	else
	{
		windowX = settings->vwmX;
		windowY = settings->vwmY;
		windowWidth = settings->vwmWidth;
		windowHeight = settings->vwmHeight;
	}
	
	int storageBaseX = screenWidth*2 + 100;
	int storageBaseY = 0;
	int storageSepX = screenWidth*2;
	int storageSepY = screenHeight*2;
	
	int panelX = 0;
	int panelY = 0;
	
	// Start with only one desktop
	desktops.push_back(new VirtualDesktop(0, &storageManager));
	
	currentDesktop = desktops[0];
	lastDesktop = currentDesktop;
	desktops[0]->focused = true;
	
	vwmDoLayout();
}

VirtualDesktop::VirtualDesktop(int index, StorageManager *storageManager)
{
	char buf[32];
	sprintf(buf, "Desktop %i", index);
	
	name = buf;
	this->index = index;
	focused = false;
	storage = storageManager->getStorageArea();
	numTasks = 0;
}

VirtualDesktop::~VirtualDesktop()
{
	delete storage;
}

void VWM::vwmDoLayout()
{
	// Match tasks up to VWMs
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		desktops[ii]->tasks.clear();
	}
	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
	{
		WindowData *window = ii->second;
		
		if(!window->desk)
			continue;
		if(window->parent || window->isToolWindow)
			continue;
		
		window->desk->tasks.push_back(window);
	}
	
	float aspect = (float)screenWidth / screenHeight;
	bool layoutValid = false;
	int rows = 1;
	
	// Start with a single-row layout. If that works (everything fits), stop
	// there. Otherwise, try a two-row layout, then a three-row layout, and
	// so on until we find one with enough space to fit everything.
	while(!layoutValid)
	{
		layoutValid = true;
		int rowHeight = settings->vwmHeight / rows;
		int panelWidth = floor(rowHeight*aspect + 0.5);
		int row = 0;
		int x = 1;
		int y = 0;
		
		for(unsigned ii=0; ii<desktops.size(); ii++)
		{
			VirtualDesktop *desk = desktops[ii];
			
			char buf[32];
			sprintf(buf, "%i", desk->index+1);
			desk->label = buf;
			desk->labelWidth = getLabelWidth(desk->label.c_str());
			desk->labelHeight = rowHeight;
			
			desk->vwmWidth = panelWidth;
			desk->vwmHeight = rowHeight;
			
			desk->tasksIconArea = min(settings->tasksIconSize + 2*settings->tasksBorderThickness, rowHeight);
			desk->tasksIconSize = desk->tasksIconArea - 2*settings->tasksBorderThickness;
			desk->tasksNumRows = rowHeight / desk->tasksIconArea;
			desk->tasksNumCols = (desk->tasks.size() + desk->tasksNumRows - 1) / desk->tasksNumRows;
			
			desk->tasksWidth = desk->tasksNumCols * desk->tasksIconArea;
			desk->tasksHeight = desk->tasksNumRows * desk->tasksIconArea;
			
			// Calculate the width of this desktop's display
			int totalWidth = desk->labelWidth + settings->vwmLeftSpacing
			               + desk->vwmWidth + settings->vwmRightSpacing + desk->tasksWidth;
			
			// If this goes off the right edge, wrap to the next line; If
			// that's not possible, we have to start over with different
			// settings.
			if(x + totalWidth >= settings->vwmWidth) {
				x = 0;
				row++;
				if(row >= rows) {
					layoutValid = false;
					break;
				}
			}
			
			// Place everything
			desk->labelX = x;
			desk->vwmX = x + desk->labelWidth + settings->vwmLeftSpacing;
			desk->tasksX = desk->vwmX + settings->vwmRightSpacing + desk->vwmWidth;
			
			y = row * rowHeight;
			desk->labelY = y;
			desk->vwmY = y;
			desk->tasksY = y + (rowHeight-desk->tasksHeight)/2;
			
			x += totalWidth + settings->panelSpacing;
		}
		
		rows++;
	}
}

WindowData *VWM::taskFromPoint(int x, int y)
{
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		if(x<desk->tasksX || x>=desk->tasksX+desk->tasksWidth)
			continue;
		//if(y<desk->tasksY || y>=desk->tasksY+desk->tasksHeight)
		//	continue;
		
		int row = (y-desk->tasksY) / desk->tasksIconArea;
		int col = (x-desk->tasksX) / desk->tasksIconArea;
		int taskNum = directionCountSteps(settings->taskFlowDirection, col, row, 0, 0,
			desk->tasksNumCols-1, desk->tasksNumRows-1, 1, 1);
		
		if(taskNum < (int)desk->tasks.size())
			return desk->tasks[taskNum];
		else
			return NULL;
	}
	
	return NULL;
}

WindowData *VWM::vwmWindowClick(VirtualDesktop *desk, int x, int y)
{
	POINT pt = {x, y};
	
	for(vector<HWND>::iterator it = zOrder.begin(); it != zOrder.end(); it++)
	{
		if(windowsByHandle.find(*it) == windowsByHandle.end())
			continue;
		WindowData *windowData = windowsByHandle[*it];
		if(windowData->desk != desk)
			continue;
		RECT vwmRect;
		screenToVWMPos(desk, windowData->screenPos, &vwmRect, NULL);
		
		if(PtInRect(&vwmRect, pt))
			return windowData;
	}
	return NULL;
}

void VWM::setScreenSize( int cx, int cy )
{
	screenWidth = cx;
	screenHeight = cy;
}

RECT VWM::getMaximizeArea()
{
	// TODO: Get maximize-area properly
	RECT ret;
		ret.left = GetRCCoordinate("SDALeft", 0, screenWidth);
		ret.top = GetRCCoordinate("SDATop", 0, screenHeight);
		ret.right = GetRCCoordinate("SDARight", screenWidth, screenWidth);
		ret.bottom = GetRCCoordinate("SDABottom", screenHeight, screenHeight);
		
		if(ret.right <= ret.left)
			ret.right = screenWidth;
		if(ret.bottom <= ret.top)
			ret.bottom = screenHeight;
	return ret;
}

pair<RECT,VirtualDesktop*> VWM::getDragDestination(
	WindowData *window, POINT clickOffset, int mouseX, int mouseY)
{
	VirtualDesktop *desk;
	RECT rect;
	bool maximized = GetWindowLong(window->handle, GWL_STYLE) & WS_MAXIMIZE;
	
	desk = vwmPointToDesk(mouseX, mouseY);
	
	if(maximized)
	{
		rect = window->screenPos;
		if(!window->desk->focused) {
			window->desk->storage->unstoreRect(rect);
		}
	} else {
		int width = window->screenPos.right - window->screenPos.left;
		int height = window->screenPos.bottom - window->screenPos.top;
		RECT maximizeArea = getMaximizeArea();
		
		POINT topLeft = vwmToScreenPos(desk, mouseX-clickOffset.x, mouseY-clickOffset.y);
		if(topLeft.x < maximizeArea.left)
			topLeft.x = maximizeArea.left;
		if(topLeft.y < maximizeArea.top)
			topLeft.y = maximizeArea.top;
		if(topLeft.x + width > maximizeArea.right)
			topLeft.x = maximizeArea.right - width;
		if(topLeft.y + height > maximizeArea.bottom)
			topLeft.y = maximizeArea.bottom - height;
		rect.left = topLeft.x;
		rect.top = topLeft.y;
		rect.right = rect.left + width;
		rect.bottom = rect.top + height;
	}

	return pair<RECT,VirtualDesktop*>(rect, desk);
}

RECT VWM::getGatherTarget(RECT source)
{
	RECT ret = source;
		RECT maximizeArea = getMaximizeArea();
	int maximizeWidth = maximizeArea.right - maximizeArea.left;
	int maximizeHeight = maximizeArea.bottom - maximizeArea.top;
	
	// If this is inside a VWM's storage area, first bring it in
	VirtualDesktop *desk = deskFromLocation(source);
	if(desk && !desk->focused)
		desk->storage->unstoreRect(ret);
	
	// TODO: Get the window-maximize region, rather than using (0,0,w,h).
	
	int width  = source.right  - source.left;
	int height = source.bottom - source.top;
	int offsetX=0;
	int offsetY=0;
	
	// If a window is wider or taller than the screen, center it. Otherwise,
	// match an edge. (This happens more often than you'd think, because
	// maximized windows are a few pixels bigger than the maximize-area so
	// that their borders fall offscreen.)
	if(width > maximizeWidth) {
		if(ret.left > maximizeArea.left || ret.right < maximizeArea.right)
			ret.left = maximizeArea.left - (width-maximizeWidth)/2;
	} else if(ret.right > maximizeWidth) {
		ret.left += maximizeWidth-ret.right;
	} else if(ret.left < maximizeArea.left) {
		ret.left = maximizeArea.left;
	}
	
	if(height > maximizeHeight) {
		if(ret.top > maximizeArea.top || ret.bottom < maximizeArea.bottom)
			ret.top = maximizeArea.top - (height-maximizeHeight)/2;
	} else if(ret.bottom > maximizeArea.bottom) {
		ret.top += maximizeArea.bottom - ret.bottom;
	} else if(ret.top < maximizeArea.top) {
		ret.top = maximizeArea.top;
	}
	
	ret.right = ret.left + width;
	ret.bottom = ret.top + height;
	return ret;
}

void VWM::screenToVWMPos(VirtualDesktop *desk, RECT screenPos, RECT *vwmPos, POINT *iconPos)
{
	if(!desk)
		desk = currentDesktop;
	
	// Translate it so it's placed as if it was the focused desktop
	if(!desk->focused)
		desk->storage->unstoreRect(screenPos);
	
	RECT maximizeArea = getMaximizeArea();
	
	// Promote to float for intermediate calculations;
	float left, right, top, bottom;
	left   = (float)screenPos.left - maximizeArea.left;
	right  = (float)screenPos.right - maximizeArea.left;
	top    = (float)screenPos.top - maximizeArea.top;
	bottom = (float)screenPos.bottom - maximizeArea.top;
	
	// Scale it to VWM-window size
	left   *= (float)desk->vwmWidth  / (maximizeArea.right-maximizeArea.left);
	right  *= (float)desk->vwmWidth  / (maximizeArea.right-maximizeArea.left);
	top    *= (float)desk->vwmHeight / (maximizeArea.bottom-maximizeArea.top);
	bottom *= (float)desk->vwmHeight / (maximizeArea.bottom-maximizeArea.top);
	
	if(left < 0)
		left = 0;
	if(top < 0)
		top = 0;
	if(right > desk->vwmWidth)
		right = desk->vwmWidth;
	if(bottom > desk->vwmHeight)
		bottom = desk->vwmHeight;
	
	if(vwmPos)
	{
		vwmPos->left   = (long)left;
		vwmPos->right  = (long)right;
		vwmPos->top    = (long)top;
		vwmPos->bottom = (long)bottom;
	}
	
	if(iconPos)
	{
		iconPos->x = (left+right)/2 - settings->vwmIconSize/2;
		iconPos->y = (top+bottom)/2 - settings->vwmIconSize/2;
	}
}

POINT VWM::vwmToScreenPos(VirtualDesktop *desk, int x, int y)
{
	POINT ret;
	RECT maximizeArea = getMaximizeArea();
	
	ret.x = (x - desk->vwmX) * ((float)(maximizeArea.right-maximizeArea.left) / desk->vwmWidth);
	ret.y = (y - desk->vwmY) * ((float)(maximizeArea.bottom-maximizeArea.top) / desk->vwmHeight);
	ret.x += maximizeArea.left;
	ret.y += maximizeArea.top;
	return ret;
}

bool RectOverlap(RECT a, RECT b)
{
	return b.left <= a.right && a.left <= b.right
	     && a.top <= b.bottom && b.top <= a.bottom;
}

VirtualDesktop *VWM::deskFromLocation(RECT pos)
{
	int centerX = (pos.left+pos.right)/2;
	int centerY = (pos.top+pos.bottom)/2;
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		if(desk->focused) {
			RECT screenRect;
				screenRect.left = 0;
				screenRect.top = 0;
				screenRect.right = screenWidth;
				screenRect.bottom = screenHeight;
			if(RectOverlap(screenRect, pos))
				return desk;
		} else {
			if(RectOverlap(desk->storage->getRect(), pos))
				return desk;
		}
	}
	
	return NULL;
}

VirtualDesktop *VWM::vwmPointToDesk(int x, int y)
{
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		RECT vwmRect = desk->getVwmRect();
		POINT pt = {x, y};
		if(PtInRect(&vwmRect, pt))
			return desk;
	}
	
	return NULL;
}

VirtualDesktop *VWM::labelPointToDesk(int x, int y)
{
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		if(x>=desk->labelX && x<desk->labelX+desk->labelWidth
		 &&y>=desk->labelY && y<desk->labelY+desk->labelHeight)
		{
			return desk;
		}
	}
	
	return NULL;
}

RECT VirtualDesktop::getVwmRect()
{
	RECT ret;
		ret.left = vwmX;
		ret.top = vwmY;
		ret.right = vwmX + vwmWidth;
		ret.bottom = vwmY + vwmHeight;
	return ret;
}