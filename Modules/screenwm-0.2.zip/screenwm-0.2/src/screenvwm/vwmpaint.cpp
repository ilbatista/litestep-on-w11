#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include "vwm.h"
#include "trace.hpp"

void VWM::initDrawContext()
{
	HDC windowDrawContext = GetDC(vwmWindow);
	if(!windowDrawContext)
		MessageBox(NULL, "Failed to get a draw context for VWM window.", "ScreenVWM", MB_TOPMOST);
	backBuffer = CreateCompatibleDC(windowDrawContext);
	backBufferMem = CreateCompatibleBitmap(windowDrawContext, windowWidth, windowHeight);
	ReleaseDC(vwmWindow, windowDrawContext);
	
	int pointSize = 26;
	int height = -MulDiv(pointSize, GetDeviceCaps(backBuffer, LOGPIXELSY), 72);
	labelFont = CreateFont(height, 0, 0, 0, FW_DONTCARE,
		0,0,0, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
		FF_SWISS|DEFAULT_PITCH, "Microsoft Sans Serif");
	SelectObject(backBuffer, labelFont);
	
	HBITMAP oldBackBufferMem = (HBITMAP)SelectObject(backBuffer, backBufferMem);
	DeleteObject(oldBackBufferMem);
}

void VWM::destroyDrawContext()
{
	DeleteDC(backBuffer);
	DeleteObject(backBufferMem);
	
	if(labelFont)
		DeleteObject(labelFont);
}

int VWM::getLabelWidth(const char *text)
{
	SIZE size;
	GetTextExtentPoint32(backBuffer, text, strlen(text), &size);
	return size.cx;
}

void VWM::forceRedraw(bool forceUpdate)
{
	if(forceUpdate)
		updateNextDraw = true;
	InvalidateRect(vwmWindow, NULL, FALSE);
}

void VWM::onPaint(Message& message)
{
	if(updateNextDraw)
		updateWindowList();
	
	PAINTSTRUCT ps;
	HDC windowDrawContext = BeginPaint(vwmWindow, &ps);
	
	// Don't update window if currently in a drag/drop
	if(!selectedWindow)
		vwmDoLayout();
	
	paintBackground();
	paintVWMWindows();
	paintTasks();
	
	// Flip the back buffer onto the screen
	BitBlt(windowDrawContext, 0, 0, windowWidth, windowHeight, backBuffer, 0, 0, SRCCOPY);
	EndPaint(vwmWindow, &ps);
}

void VWM::paintBackground()
{
	HBRUSH panelBackgroundBrush = CreateSolidBrush(settings->panelBackgroundColor);
	HBRUSH oldBrush = (HBRUSH)SelectObject(backBuffer, panelBackgroundBrush);
	HPEN panelBorderPen = CreatePen(PS_SOLID, 1, settings->panelBorderColor);
	HPEN oldPen = (HPEN)SelectObject(backBuffer, panelBorderPen);
		// Draw the shared background
		Rectangle(backBuffer, 0, 0, windowWidth, windowHeight);
	SelectObject(backBuffer, oldBrush);
	SelectObject(backBuffer, oldPen);
	DeleteObject(panelBackgroundBrush);
	DeleteObject(panelBorderPen);
	
	SetBkColor(backBuffer, settings->panelBackgroundColor);
	
	HBRUSH vwmBackgroundBrush = CreateSolidBrush(settings->vwmBackgroundColor);
	HPEN vwmBorderPen = CreatePen(PS_SOLID, 1, settings->vwmBorderColor);
	
	HBRUSH labelBackgroundBrush = CreateSolidBrush(settings->labelBackColor);
	HBRUSH focusedLabelBackgroundBrush = CreateSolidBrush(settings->labelBackColorFocused);
	HPEN labelBackgroundPen = CreatePen(PS_NULL, 0, settings->labelBackColor);
	
	oldBrush = (HBRUSH)SelectObject(backBuffer, vwmBackgroundBrush);
	oldPen = (HPEN)SelectObject(backBuffer, vwmBorderPen);
	
	// Draw the label, background and border for the VWM display for each desktop
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		
		// Draw label
		char labelText[32];
			sprintf(labelText, "%i", desk->index+1);
		SIZE labelSize;
		GetTextExtentPoint32(backBuffer, labelText, strlen(labelText), &labelSize);
		
		RECT labelRect;
			labelRect.left = desk->labelX + desk->labelWidth/2 - labelSize.cx/2;
			labelRect.top = desk->labelY + desk->labelHeight/2 - labelSize.cy/2;
			labelRect.right = labelRect.left + labelSize.cx;
			labelRect.bottom = labelRect.top + labelSize.cy;
		
		if(desk->focused) {
			SelectObject(backBuffer, focusedLabelBackgroundBrush);
			SelectObject(backBuffer, labelBackgroundPen);
			SetBkColor(backBuffer, settings->labelBackColorFocused);
			SetTextColor(backBuffer, settings->labelColorFocused);
		} else {
			SelectObject(backBuffer, labelBackgroundBrush);
			SelectObject(backBuffer, labelBackgroundPen);
			SetBkColor(backBuffer, settings->labelBackColor);
			SetTextColor(backBuffer, settings->labelColor);
		}
		
		Rectangle(backBuffer, labelRect.left, labelRect.top, labelRect.right, labelRect.bottom);
		
		DrawText(backBuffer, labelText, -1, &labelRect, DT_NOCLIP);
		
		SelectObject(backBuffer, vwmBackgroundBrush);
		SelectObject(backBuffer, vwmBorderPen);
		
		// Draw VWM background
		Rectangle(backBuffer,
			desk->vwmX,                desk->vwmY,
			desk->vwmX+desk->vwmWidth, desk->vwmY+desk->vwmHeight);
	}
	
	SelectObject(backBuffer, oldBrush);
	SelectObject(backBuffer, oldPen);
	DeleteObject(vwmBackgroundBrush);
	DeleteObject(vwmBorderPen);
	DeleteObject(labelBackgroundBrush);
	DeleteObject(focusedLabelBackgroundBrush);
	DeleteObject(labelBackgroundPen);
}

struct WindowPainter
{
	HBRUSH windowBrush;
	HPEN pen;
	HBRUSH titleBarBrush;
	HBRUSH focusedTitleBarBrush;
	HBRUSH oldBrush;
	HPEN oldPen;
	RCSettings *settings;
	HDC backBuffer;
	
	WindowPainter(RCSettings *settings, HDC backBuffer)
		:settings(settings), backBuffer(backBuffer)
	{
		windowBrush = CreateSolidBrush(settings->vwmWindowColor);
		titleBarBrush = CreateSolidBrush(settings->vwmTitleBarColor);
		focusedTitleBarBrush = CreateSolidBrush(settings->vwmFocusedTitleBarColor);
		pen = CreatePen(PS_SOLID, 1, settings->vwmWindowBorderColor);
		oldBrush = (HBRUSH)SelectObject(backBuffer, windowBrush);
		oldPen = (HPEN)SelectObject(backBuffer, pen);
	}
	
	~WindowPainter()
	{
		SelectObject(backBuffer, oldBrush);
		SelectObject(backBuffer, oldPen);
		DeleteObject(windowBrush);
		DeleteObject(titleBarBrush);
		DeleteObject(focusedTitleBarBrush);
		DeleteObject(pen);
	}
	
	void paintWindow(bool focused, RECT r, HICON icon, POINT iconPos)
	{
		Rectangle(backBuffer, r.left, r.top, r.right, r.bottom);
		
		RECT rtitle;
		if(settings->vwmTitleBarsThickness)
		{
			if(focused)
				SelectObject(backBuffer, focusedTitleBarBrush);
			else
				SelectObject(backBuffer, titleBarBrush);
			
			rtitle.left = r.left;
			rtitle.top = r.top;
			rtitle.right = r.right;
			rtitle.bottom = r.top + settings->vwmTitleBarsThickness;
			// save the bottom of the titlebar as the top of the rest of the window
			r.top = rtitle.bottom;
			
			Rectangle(backBuffer,
				rtitle.left, rtitle.top, rtitle.right, rtitle.bottom);
			SelectObject(backBuffer, windowBrush);
		}
		
		int iconSize = settings->vwmIconSize;
		if(icon && iconSize)
			DrawIconEx(backBuffer, iconPos.x, iconPos.y, icon, iconSize, iconSize, 0, NULL, DI_NORMAL);
	}
};

void VWM::paintVWMWindows()
{
	WindowPainter painter(settings, backBuffer);
	
	for(vector<HWND>::reverse_iterator it = zOrder.rbegin(); it != zOrder.rend(); it++)
	{
		HWND handle = *it;
		if(windowsByHandle.find(handle) == windowsByHandle.end())
			continue;
		WindowData *windowData = windowsByHandle[handle];
		
		if(windowData->minimized)
			continue;
		
		VirtualDesktop *desk = windowData->desk;
		if(!desk)
			desk = currentDesktop;
		RECT r;
		POINT iconPos;
		screenToVWMPos(desk, windowData->screenPos, &r, &iconPos);
			r.left += desk->vwmX;
			r.right += desk->vwmX;
			r.top += desk->vwmY;
			r.bottom += desk->vwmY;
			iconPos.x += desk->vwmX;
			iconPos.y += desk->vwmY;
		
		if(!windowData->parent && !windowData->isToolWindow)
			painter.paintWindow(windowData->focused, r, windowData->smallIcon, iconPos);
		else
			painter.paintWindow(windowData->focused, r, NULL, iconPos);
	}
}

void VWM::paintTasks()
{
	HBRUSH normalBrush = CreateSolidBrush(settings->tasksBackColor);
	HBRUSH minimizedBrush = CreateSolidBrush(settings->tasksBackColorMin);
	HBRUSH focusedBrush = CreateSolidBrush(settings->tasksBackColorFocused);
	
	HPEN normalPen = CreatePen(PS_SOLID, settings->tasksBorderThickness, settings->tasksBorderColor);
	HPEN minimizedPen = CreatePen(PS_SOLID, settings->tasksBorderThickness, settings->tasksBorderColorMin);
	HPEN focusedPen = CreatePen(PS_SOLID, settings->tasksBorderThickness, settings->tasksBorderColorFocused);
	
	HBRUSH oldBrush = (HBRUSH)SelectObject(backBuffer, normalBrush);
	HPEN oldPen = (HPEN)SelectObject(backBuffer, normalPen);
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		int row;
		int col;
		
		directionStart(settings->taskFlowDirection, col, row, 0, 0, desk->tasksNumCols-1, desk->tasksNumRows-1);
		
		for(unsigned jj=0; jj<desk->tasks.size(); jj++)
		{
			WindowData *task = desk->tasks[jj];
			
			int x = desk->tasksX + desk->tasksIconArea * col;
			int y = desk->tasksY + desk->tasksIconArea * row;
			int offsetX, offsetY;
			
			IntersectClipRect(backBuffer, x, y, x+desk->tasksIconArea, y+desk->tasksIconArea);
			
			if(task->minimized) {
				SelectObject(backBuffer, minimizedBrush);
				SelectObject(backBuffer, minimizedPen);
				offsetX = settings->tasksOffsetXMin;
				offsetY = settings->tasksOffsetYMin;
			}
			else if(task->focused || task->dragSourceDesk || task->handle==pendingMinimize)
			{
				SelectObject(backBuffer, focusedBrush);
				SelectObject(backBuffer, focusedPen);
				offsetX = settings->tasksOffsetXFocused;
				offsetY = settings->tasksOffsetYFocused;
			}
			else
			{
				SelectObject(backBuffer, normalBrush);
				SelectObject(backBuffer, normalPen);
				offsetX = settings->tasksOffsetX;
				offsetY = settings->tasksOffsetY;
			}
			
			Rectangle(backBuffer, x, y, x+desk->tasksIconArea, y+desk->tasksIconArea);
			
			// Don't draw the icon for a task which is being dragged
			if(!task->dragSourceDesk)
			{
				HICON icon = task->bigIcon;
				
				DrawIconEx(backBuffer,
					x+settings->tasksBorderThickness+offsetX, y+settings->tasksBorderThickness+offsetY,
					icon,
					desk->tasksIconSize, desk->tasksIconSize,
					0, NULL, DI_NORMAL);
			}
			
			SelectClipRgn(backBuffer, NULL);
			
			directionNext(settings->taskFlowDirection,
				col, row,
				0, 0,
				desk->tasksNumCols-1, desk->tasksNumRows-1,
				1, 1);
		}
	}
	
	SelectObject(backBuffer, oldPen);
	SelectObject(backBuffer, oldBrush);
	
	DeleteObject(normalBrush);
	DeleteObject(minimizedBrush);
	DeleteObject(focusedBrush);
	DeleteObject(normalPen);
	DeleteObject(minimizedPen);
	DeleteObject(focusedPen);
}