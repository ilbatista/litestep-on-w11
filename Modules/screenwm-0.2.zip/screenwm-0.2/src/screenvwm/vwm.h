/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __VWM2_H
#define __VWM2_H

#include <litestep/lsapi/lsapi.h>
#include "rcsettings.hpp"
#include "windowstorage.hpp"
#include "windowtracking.hpp"

#include <vector>
using std::vector;
#include <map>
using std::map;
using std::pair;
#include <string>
using std::string;
#include <set>
using std::set;

#define VERSION_STRING "screenvwm 0.1"

#define MAX_LINE_LENGTH 4096
#pragma warning (disable: 4800) // Conversion from int to bool
#pragma warning (disable: 4244) // Implicit conversion from int to float

struct Message
{
	UINT uMsg;
	union 
	{
		struct
		{
			WPARAM wParam;
			LPARAM lParam;
			LRESULT lResult;
		};
		struct
		{
			WORD wParamLo;
			WORD wParamHi;
			WORD lParamLo;
			WORD lParamHi;
			WORD lResultLo;
			WORD lResultHi;
		};
	};
};

struct VirtualDesktop;
struct WindowData;

/// A virtual desktop within the VWM.
struct VirtualDesktop
{
	VirtualDesktop(int index, StorageManager *storageManager);
	~VirtualDesktop();
	
	int index;
	string name;
	
	string label;
	int labelX, labelY;
	int labelWidth, labelHeight;
	
	int vwmX, vwmY;
	int vwmWidth, vwmHeight;
	
	int tasksIconSize;
	int tasksIconArea;
	int tasksNumRows;
	int tasksNumCols;
	int tasksX, tasksY;
	int tasksWidth, tasksHeight;
	
	bool focused;
	StorageArea *storage;
	
	/// List of windows that're on this desktop. Only updated when
	/// VWM::doLayout is called;
	std::vector<WindowData*> tasks;
	/// Number of windows that're on this desktop. Unlike tasks, this is
	/// updated immediately as soon as we notice that a new window has appeared
	/// or disappeared.
	int numTasks;
	
	RECT VirtualDesktop::getVwmRect();
};

/// Virtual Window Manager - the widget that this module exists to provide.
class VWM
{
public:
	VWM(HWND parentWnd, int& code, HINSTANCE dllInstance);
	~VWM();
	int finalize();

	void ontopToggle();
	void gather();
	void toggle();
	void show();
	void hide();
	
	void createDesktop();
	void destroyDesktop();
	void switchDesk(VirtualDesktop *newDesk);
	void moveApp(VirtualDesktop *dest);
	void moveWindow(WindowData *window, RECT pos, VirtualDesktop *desk);
	void raiseWindow(WindowData *window);
	void minimizeWindow(WindowData *window);
	void maximizeWindow(WindowData *window);
	void restoreWindow(WindowData *window);
	WindowData *getForegroundWindow();
	
	const RCSettings *getSettings() { return settings; }
	int getScreenWidth() { return screenWidth; }
	int getScreenHeight() { return screenHeight; }
	
	VirtualDesktop *findDesk(const char *deskName, VirtualDesktop *relativeTo=NULL);
	
private:
	RCSettings *settings;
	int screenWidth;
	int screenHeight;
	
	// VWM window management
	// (in vwmwindow.cpp) @{
	HINSTANCE dllInstance;
	HWND vwmWindow;
	HWND parentWindow;
	bool inWharf;
	bool createWindow();
	void destroyWindow();
	void registerWindowClass();
	void unregisterWindowClass();
	static LRESULT CALLBACK VWM::wndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	//@}
	
	// Sticky windows handling
	// (in vwm.cpp) @{
	void initStickyWindows();
	bool isSticky(HWND window);
	set<string> stickyWindows;
	//@}
	
	// Virtual desktop data structures
	// (getters in vwm.cpp) @{
	VirtualDesktop *currentDesktop;
	VirtualDesktop *lastDesktop;
	vector<VirtualDesktop*> desktops;
	VirtualDesktop *getDeskByIndex(int index);
	VirtualDesktop *getDeskFromWnd(HWND window);
	//@}
	
	// windowtracking.cpp
	// Window tracking @{
	vector<HWND> zOrder;
	map<HWND, WindowData*> windowsByHandle;
	StorageManager storageManager;
	HWND foregroundHandle;
	bool updateNextDraw;
	bool updateWindowList();
	bool updateWindow(WindowData *window);
	VirtualDesktop *rescueOffscreenWindow(HWND handle, RECT *pos);
	WindowData *noticeWindowCreation(HWND handle);
	void noticeWindowDisappearance(WindowData *window);
	bool shouldIgnoreWindow(HWND window);
	void initTrackingHooks();
	void cleanupTrackingHooks();
	void interceptWindowPosChange(HWND window, WINDOWPOS *pos);
	friend void hookWindowPosChangedProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	//@}
	
	// vwmevents.cpp
	// Event handlers @{
	void registerEventHandlers();
	void unregisterEventHandlers();
	virtual void windowProc(Message& message);
	void onCreate(Message& message);
	void onDestroy(Message& message);
	void onGetRevId(Message& message);
	void onMouseButtonDown(Message& message);
	void onMouseButtonUp(Message& message);
	void onMouseMove(Message& message);
	void onSysCommand(Message& message);
	void onWindowActivated(Message& message);
	void onTimer(Message& message);
	void onDropFiles(Message& message);
	void onVWMPosChanging(Message& message);
	void onBringToFront(Message& message);
	void onSwitchToN(Message& message);
	void onListDesktops(Message& message);
	void onGetDesktopOf(Message& message);
	//@}
	
	// Window dragging and minimizing
	// (in vwm.cpp) @{
	HWND pendingMinimize;
	HWND selectedWindow;
	POINT diffPt;
	void beginWindowDrag(WindowData *window, POINT clickOffset);
	void continueWindowDrag(int mouseX, int mouseY);
	void endDrag();
	//@}
	
	// vwmgeom.cpp
	// Geometry calculations @{
	int windowX;
	int windowY;
	int windowWidth;
	int windowHeight;
	void initDesktops();
	void vwmDoLayout();
	WindowData *taskFromPoint(int x, int y);
	WindowData *vwmWindowClick(VirtualDesktop *desk, int x, int y);
	void setScreenSize(int cx, int cy);
	RECT getMaximizeArea();
	pair<RECT,VirtualDesktop*> getDragDestination(WindowData *window, POINT clickOffset, int mouseX, int mouseY);
	RECT getGatherTarget(RECT source);
	void screenToVWMPos(VirtualDesktop *desk, RECT screenPos, RECT *vwmPos, POINT *iconPos);
	POINT vwmToScreenPos(VirtualDesktop *desk, int x, int y);
	VirtualDesktop *deskFromLocation(RECT pos);
	VirtualDesktop *vwmPointToDesk(int x, int y);
	VirtualDesktop *labelPointToDesk(int x, int y);
	//@}
	
	// vwmpaint.cpp
	// Rendering @{
	HDC backBuffer;
	HBITMAP backBufferMem;
	HFONT labelFont;
	void initDrawContext();
	void destroyDrawContext();
	int getLabelWidth(const char *label);
	void forceRedraw(bool updateWindows);
	void onPaint(Message& message);
	void paintBackground();
	void paintVWMWindows();
	void paintTasks();
	//@}
};
extern VWM *vwm;

void initBangs();
void cleanupBangs();

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
	__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, void *wharfData);
	__declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);
}

#endif
