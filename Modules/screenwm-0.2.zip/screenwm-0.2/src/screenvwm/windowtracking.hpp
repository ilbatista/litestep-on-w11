#ifndef WINDOWTRACKING_HPP
#define WINDOWTRACKING_HPP
struct VirtualDesktop;

/// Cached information about a window which we're keeping track of. Windows
/// can disappear, move, or change properties at any time (they have threads/
/// wills of their own!), sometimes without us noticing, so there's no
/// guarantee that this information isn't stale.
struct WindowData
{
	HWND handle;
	RECT screenPos;
	int z;
	
	bool focused;
	bool minimized;
	bool isToolWindow;
	
	/// If this is a popup window, this is its parent (if it has one) or owner
	/// (if it has one). If it's unowned or not a popup, this is NULL.
	HWND parent;
	
	/// The virtual desktop this window is currently on
	VirtualDesktop *desk;
	/// If this window is currently being dragged, the desktop it started on.
	/// Null otherwise.
	VirtualDesktop *dragSourceDesk;
	
	HICON bigIcon;
	HICON smallIcon;
	
	bool visited;
};

#endif