
/********************************************/
/*											*/
/*	bgcolors.cpp							*/
/*											*/
/*	Version	1.01							*/
/*											*/
/*	4 nov 2003								*/
/*											*/
/*	This file is the main file for 			*/
/*	the BGColors module for LiteStep.		*/
/*											*/
/*	This module should work on most 		*/
/*	LiteStep versions and on any version	*/
/*	of Windows.								*/
/*											*/
/*	This module should use less than 5%		*/
/*	of your cpu time even on old computers	*/
/*	and with really high resolutions.		*/
/*											*/
/*	Made by Antoine Wells Campagna			*/
/*	aka AntAgna								*/
/*	send questions, comments, etc... to :	*/
/*	AntoineW@Campagna.org					*/
/*											*/
/********************************************/


//Includes

#include "bgcolors.h"


//Functions

void Draw()		//This calculate colors and draw the color on the background
{
	int i;
	HBRUSH hbr;
	for (i=0; i<3; i++)		//Calcutale new color
	{
		gwnd.Change[i] += gwnd.speed;
		if (gwnd.Change[i] >= 6.28)		//greater or eqals to 2 * pi - experimental
		{
			gwnd.Change[i] = 0;
		}

		gwnd.Couleur[i] = (unsigned char) (sin(gwnd.Change[i]) * 120 + 128);
	}

	hbr = CreateSolidBrush(RGB(gwnd.Couleur[0], gwnd.Couleur[1],
		gwnd.Couleur[2]));		//Create the new brush
	if (gwnd.nbhbrs >= MAXHBRS || !hbr)	//Can't create anymore brushes
	{
		for (i=0; i<gwnd.nbhbrs; i++)	//Clean all brushes
		{
			DeleteObject(gwnd.hbrs[i]);
		}

		gwnd.nbhbrs = 0;		//Reset counter
	}

	if (hbr != 0)
	{
		FillRect(gwnd.hdc, &gwnd.rect, hbr);	//Draws to the screen
		gwnd.hbrs[gwnd.nbhbrs++] = hbr;		//Save brush for cleaning
	}

	if (gwnd.cnt++ > 300)	//After a few seconds
	{	//Check the config again
		gwnd.cnt = 0;
		gwnd.bgWin = FindWindow("DesktopBackgroundClass","");
		ReleaseDC(gwnd.bgWin, gwnd.hdc);		//Clean up
		GetWindowRect(gwnd.bgWin, &gwnd.rect);	//If screen res changed
		gwnd.hdc = GetDC(gwnd.bgWin);	//Makes sure the hdc stays correct
	}

}

void init()
{
	//Read Config
	gwnd.refint = GetRCInt("BGColorsRefreshInterval", 50);
	if (gwnd.refint < 1)
	{
		gwnd.refint = 1;
	}

	if (gwnd.refint > 1000)
	{
		gwnd.refint = 1000;
	}

	gwnd.speed = GetRCInt("BGColorsChangeSpeed", 5);
	if (gwnd.speed < 1)
	{
		gwnd.speed = 1;
	}

	if (gwnd.speed > 1000)
	{
		gwnd.speed = 1000;
	}

	gwnd.speed = gwnd.speed / 500.;
	gwnd.Change[0] = GetRCInt("BGColorsStartValueR", 0);
	if (gwnd.Change[0] < 0 || gwnd.Change[0] > 62)
	{
		gwnd.Change[0] = 0;
	}

	gwnd.Change[0] /= 10.;
	gwnd.Change[1] = GetRCInt("BGColorsStartValueG", 15);
	if (gwnd.Change[1] < 0 || gwnd.Change[1] > 62)
	{
		gwnd.Change[1] = 0;
	}

	gwnd.Change[1] /= 10.;
	gwnd.Change[2] = GetRCInt("BGColorsStartValueB", 45);
	if (gwnd.Change[2] < 0 || gwnd.Change[2] > 62)
	{
		gwnd.Change[2] = 0;
	}

	gwnd.Change[2] /= 10.;

	//Init the rest of the struct
	gwnd.bgWin = FindWindow("DesktopBackgroundClass", "");
	gwnd.hdc = GetDC(gwnd.bgWin);
	GetWindowRect(gwnd.bgWin, &gwnd.rect);
	gwnd.nbhbrs = 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case LM_GETREVID:
		{
			char * buf = (char * ) lParam;
			strcpy(buf, aboutStr);
			return strlen(buf);
		}
		
		case WM_TIMER:
		{
			Draw();
			return 0;
		}
	}

	return DefWindowProc(hwnd,message,wParam,lParam);
}

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	WNDCLASS wc;
	UINT Msgs[2];
	lsWin = hParent;

	init();

	//Create Window
	memset(&wc,0,sizeof(wc));
	wc.hInstance = hInstance;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = szAppName;
	if (!RegisterClass(&wc))
	{
		MessageBox(lsWin,
			"Error registering window class",
			szAppName, MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		return 1;
	}

	timerWin = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, "Timer", WS_CHILD,
		0,0,0,0, hParent, NULL, hInstance, NULL);
	//Set the refresh timer
	if (!SetTimer(timerWin, REFRESH_TIMER, gwnd.refint, NULL))
	{
		MessageBox(lsWin,
			"Error creating update Timer!\nCan not continue to load.",
			szAppName, MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		quitModule(hInstance);
		return 1;
	}

	//To be able to react to the GetRevID msg
	Msgs[0] = LM_GETREVID;
	Msgs[1] = 0;
	SendMessage(lsWin, LM_REGISTERMESSAGE, (WPARAM)timerWin, (LPARAM)Msgs);
	return 0;
}

void quitModule(HINSTANCE hInstance)
{
	UINT Msgs[2];
	//Unregister the litestep version info message.
	Msgs[0] = LM_GETREVID;
	Msgs[1] = 0;
	SendMessage(lsWin, LM_UNREGISTERMESSAGE, (WPARAM) timerWin, (LPARAM) Msgs);
	//Destroy the window
	KillTimer(timerWin, REFRESH_TIMER);
	DestroyWindow(timerWin);
	UnregisterClass(szAppName, hInstance);
}

BOOL APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	return TRUE;
}
