

/********************************************/
/*											*/
/*	bgcolors.h								*/
/*											*/
/*	Version	1.01							*/
/*											*/
/*	4 nov 2003								*/
/*											*/
/*	This file is the header file for		*/
/*	the BGColors module for LiteStep.		*/
/*											*/
/*	Made by Antoine Wells Campagna			*/
/*	aka AntAgna								*/
/*	send questions, comments, etc... to :	*/
/*	AntoineW@Campagna.org					*/
/*											*/
/********************************************/


//Includes

#include "lsapi.h"
#include <math.h>


//Defines

#define MAXHBRS			2000	//Size of brushes buffer
#define REFRESH_TIMER	1


//The Struct Used

struct WNDINFO
{
	HDC hdc;					//Device context of the background
	double Change[3];			//Numbers on which the color will be calculated
	unsigned char Couleur[3];	//Colors
	int nbhbrs;					//Nunber of brushes waiting to be cleaned
	HBRUSH hbrs[MAXHBRS];		//Brushes buffer
	RECT rect;					//Screen coordinates
	int cnt;					//Iterator
	HWND bgWin;					//Handle to background window
	int refint;					//Refresh interval (Timer Value)
	double speed;				//Incrementation of the color
};


//Consts

const char szAppName[] = "BGColors";
const char aboutStr[] = "BGColors v1.01 by AntAgna";


//Global vars

HWND timerWin;
HWND lsWin;
WNDINFO gwnd;


//Functions

void Draw(void);
void init(void);
void quitModule(HINSTANCE hInstance);
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath);
void quitModule(HINSTANCE hInstance);
BOOL APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved);
