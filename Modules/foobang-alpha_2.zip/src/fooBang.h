#ifndef __FOOBANG_H
#define __FOOBANG_H

#include <windows.h>
#include "..\..\lsapi\lsapi.h"
#include "..\..\utility\lswinbase.cpp"
#include "foobar2000.h"

#define WIN32_LEAN_AND_MEAN
#define MAX_LINE_LENGTH 4096


class fooBang : public Window {
private:
	char names[MAX_LINE_LENGTH];
	char command[MAX_LINE_LENGTH];
	char szAmpPath[MAX_LINE_LENGTH];
	char buffer[MAX_LINE_LENGTH];
	BOOL fooUseOldV;
	BOOL FoobarStartNormal;
	BOOL PlayNotOpen, PlayPauseNotOpen, PlaylistNotOpen, PrefsNotOpen, LoadFileNotOpen, ShowNotOpen;
public:
	fooBang(HWND parentWnd, int& code);
	~fooBang();
	HWND GetFoobarWnd(void);
	void FoobarMessage(const int);
	void FoobarOpen(void);
	void BangFoo_Hide();
	void BangFoo_Display();
	void BangFoo_PlayPause();
	void BangFoo_Fwd();
	void BangFoo_Rew();
	void BangFoo_Stop();
	void BangFoo_About();
	void BangFoo_LoadFile();
	void BangFoo_Next();
	void BangFoo_OnTop();
	void BangFoo_Pause();
	void BangFoo_Play();
	void BangFoo_Power();
	void BangFoo_Prefs();
	void BangFoo_Prev();
	void BangFoo_Repeat();
	void BangFoo_Rewd5s();
	void BangFoo_Show();
	void BangFoo_Shuffle();
	void BangFoo_VolumeDown();
	void BangFoo_VolumeUp();
	void BangFoo_PowerOn();
	void BangFoo_PowerOff();
	void BangFoo_Restart();
	void BangFoo_RepeatOne();
	void BangFoo_StopAfterCurrent();
	
private:
	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
};

void BangFoo_HideFunction(HWND, LPCSTR);
void BangFoo_DisplayFunction(HWND, LPCSTR);
void BangFoo_PlayPauseFunction(HWND, LPCSTR);
void BangFoo_FwdFunction(HWND, LPCSTR);
void BangFoo_RewFunction(HWND, LPCSTR);
void BangFoo_PowerOnFunction(HWND, LPCSTR);
void BangFoo_PowerOffFunction(HWND, LPCSTR);
void BangFoo_AboutFunction(HWND, LPCSTR);
void BangFoo_LoadFileFunction(HWND, LPCSTR);
void BangFoo_NextFunction(HWND, LPCSTR);
void BangFoo_OnTopFunction(HWND, LPCSTR);
void BangFoo_PauseFunction(HWND, LPCSTR);
void BangFoo_PlayFunction(HWND, LPCSTR);
void BangFoo_PowerFunction(HWND, LPCSTR);
void BangFoo_PrefsFunction(HWND, LPCSTR);
void BangFoo_PrevFunction(HWND, LPCSTR);
void BangFoo_RepeatFunction(HWND, LPCSTR);
void BangFoo_ShowFunction(HWND, LPCSTR);
void BangFoo_ShuffleFunction(HWND, LPCSTR);
void BangFoo_VolumeDownFunction(HWND, LPCSTR);
void BangFoo_VolumeUpFunction(HWND, LPCSTR);
void BangFoo_StopFunction(HWND, LPCSTR);
void BangFoo_RestartFunction(HWND, LPCSTR);
void BangFoo_RepeatOneFunction(HWND, LPCSTR);
void BangFoo_StopAfterCurrentFunction(HWND, LPCSTR);

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
