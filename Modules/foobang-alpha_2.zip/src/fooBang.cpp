/**********************************************************************************************

  fooBang alpha 1 source code. Based on source from Azathoth's Geekamp v1.9.666.
  
  Written by Russell Norberg (aka ranor)
  ranor@subdimension.com
  http://ranor.darkbase.org
  
  Thanks to musicmusic for helping with the WM_COMMAND codes.

  Updated to support the new version of foobar2000 by 
  Tobbe Lundberg
  tobbesweden@hotmail.com
  2004-05-09
	  
***********************************************************************************************/

#include "fooBang.h"
const char szAppName[] = "fooBang"; // Our window class, etc
const char rcsRevision[] = "$Revision: alpha 2"; // Our Version
const char rcsId[] = "$Id: fooBang.cpp,alpha 2 00:00:00 Tobbe Exp $"; // The Full RCS ID.
fooBang *foobang; // The module


//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath) {
   int code;
   Window::init(dllInst);
   foobang = new fooBang(ParentWnd, code);
   return code;
}

void quitModule(HINSTANCE dllInst) {
   delete foobang;
}

//=========================================================
// Bang commands
//=========================================================
void BangFoo_AboutFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_About();
}

void BangFoo_FwdFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Fwd();
}

void BangFoo_RewFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Rew();
}

void BangFoo_LoadFileFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_LoadFile();
}

void BangFoo_NextFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Next();
}

void BangFoo_OnTopFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_OnTop();
}

void BangFoo_PauseFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Pause();
}

void BangFoo_PlayFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Play();
}

void BangFoo_PowerFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Power();
}

void BangFoo_PrefsFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Prefs();
}

void BangFoo_PrevFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Prev();
}

void BangFoo_RepeatFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Repeat();
}

void BangFoo_RepeatOneFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_RepeatOne();
}

void BangFoo_StopAfterCurrentFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_StopAfterCurrent();
}

void BangFoo_ShowFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Show();
}

void BangFoo_ShuffleFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Shuffle();
}

void BangFoo_VolumeDownFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_VolumeDown();
}

void BangFoo_VolumeUpFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_VolumeUp();
}

void BangFoo_StopFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Stop();
}

void BangFoo_PowerOnFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_PowerOn();
}

void BangFoo_PowerOffFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_PowerOff();
}

void BangFoo_RestartFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Restart();
}

void BangFoo_PlayPauseFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_PlayPause();
}

void BangFoo_HideFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Hide();
}

void BangFoo_DisplayFunction(HWND caller, LPCSTR args) {
   foobang->BangFoo_Display();
}

//=========================================================
// Module code
//=========================================================

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
fooBang::fooBang(HWND parentWnd, int& code):
Window(szAppName)
{
   int msgs[] = {LM_GETREVID, 0};
   
   if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
	  0, 0, 0, 0, parentWnd))
   {
	  MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
	  code = 1;
	  return;
   }
   
   SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
   
   fooUseOldV = GetRCBoolDef("fooUseOldV", false);
   FoobarStartNormal = GetRCBoolDef("FoobarStartNormal", FALSE);
   PlayNotOpen = GetRCBoolDef("PlayNotOpen", FALSE);
   PlayPauseNotOpen = GetRCBoolDef("PlayPauseNotOpen", FALSE);
   PrefsNotOpen = GetRCBoolDef("PrefsNotOpen", FALSE);
   LoadFileNotOpen = GetRCBoolDef("LoadFileNotOpen", FALSE);
   ShowNotOpen = GetRCBoolDef("ShowNotOpen", FALSE);
   GetRCString("FoobarPath", szAmpPath, "c:\\progra~1\\foobar~1\\foobar~1.exe", MAX_LINE_LENGTH);
   
   SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
   AddBangCommand("!foo_About",BangFoo_AboutFunction);
   AddBangCommand("!foo_Fwd",BangFoo_FwdFunction);
   AddBangCommand("!foo_Rew",BangFoo_RewFunction);
   AddBangCommand("!foo_LoadFile",BangFoo_LoadFileFunction);
   AddBangCommand("!foo_Next",BangFoo_NextFunction);
   AddBangCommand("!foo_OnTop",BangFoo_OnTopFunction);
   AddBangCommand("!foo_Pause",BangFoo_PauseFunction);
   AddBangCommand("!foo_Play",BangFoo_PlayFunction);
   AddBangCommand("!foo_Power",BangFoo_PowerFunction);
   AddBangCommand("!foo_Prefs",BangFoo_PrefsFunction);
   AddBangCommand("!foo_Prev",BangFoo_PrevFunction);
   AddBangCommand("!foo_Repeat",BangFoo_RepeatFunction);
   AddBangCommand("!foo_Show",BangFoo_ShowFunction);
   AddBangCommand("!foo_Shuffle",BangFoo_ShuffleFunction);
   AddBangCommand("!foo_VolumeDown",BangFoo_VolumeDownFunction);
   AddBangCommand("!foo_VolumeUp",BangFoo_VolumeUpFunction);
   AddBangCommand("!foo_Stop",BangFoo_StopFunction);
   AddBangCommand("!foo_PowerOn",BangFoo_PowerOnFunction);
   AddBangCommand("!foo_PowerOff",BangFoo_PowerOffFunction);
   AddBangCommand("!foo_Restart",BangFoo_RestartFunction);
   AddBangCommand("!foo_PlayPause",BangFoo_PlayPauseFunction);
   AddBangCommand("!foo_Hide",BangFoo_HideFunction);
   AddBangCommand("!foo_Display",BangFoo_DisplayFunction);
   AddBangCommand("!foo_RepeatOne",BangFoo_RepeatOneFunction);
   AddBangCommand("!foo_StopAfterCurrent",BangFoo_StopAfterCurrentFunction);
   code = 0;
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
fooBang::~fooBang()
{
   int msgs[] = {LM_GETREVID, 0};
   
   SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
   RemoveBangCommand("!foo_PlayPause");
   RemoveBangCommand("!foo_Rew");
   RemoveBangCommand("!foo_Fwd");
   RemoveBangCommand("!foo_About");
   RemoveBangCommand("!foo_LoadFile");
   RemoveBangCommand("!foo_Next");
   RemoveBangCommand("!foo_OnTop");
   RemoveBangCommand("!foo_Pause");
   RemoveBangCommand("!foo_Play");
   RemoveBangCommand("!foo_Power");
   RemoveBangCommand("!foo_Prefs");
   RemoveBangCommand("!foo_Prev");
   RemoveBangCommand("!foo_Repeat");
   RemoveBangCommand("!foo_Show");
   RemoveBangCommand("!foo_Shuffle");
   RemoveBangCommand("!foo_VolumeDown");
   RemoveBangCommand("!foo_VolumeUp");
   RemoveBangCommand("!foo_PowerOn");
   RemoveBangCommand("!foo_PowerOff");
   RemoveBangCommand("!foo_Restart");
   RemoveBangCommand("!foo_Hide");
   RemoveBangCommand("!foo_Display");
   RemoveBangCommand("!foo_RepeatOne");
   RemoveBangCommand("!foo_StopAfterCurrent");
   destroyWindow();
}

//=========================================================
// Registered messages
//=========================================================

void fooBang::windowProc(Message& message)
{
   BEGIN_MESSAGEPROC
	  MESSAGE(onEndSession,        WM_ENDSESSION)
	  MESSAGE(onEndSession,        WM_QUERYENDSESSION)
	  MESSAGE(onGetRevId,          LM_GETREVID)
	  MESSAGE(onSysCommand,        WM_SYSCOMMAND)
	  END_MESSAGEPROC
}

//=========================================================
// Message handlers
//=========================================================
void fooBang::onEndSession(Message& message)
{
   message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void fooBang::onGetRevId(Message& message)
{
   char* buf = (char*)(message.lParam);
   
   switch (message.wParam)
   {
   case 0:
	  sprintf(buf, "fooBang %s (ranor) ", &rcsRevision[11]);
	  buf[strlen(buf) - 1] = '\0';
	  break;
   case 1:
	  strcpy(buf, &rcsId[1]);
	  buf[strlen(buf) - 1] = '\0';
	  break;
   default:
	  strcpy(buf, "");
   }
   message.lResult = strlen(buf);
}

void fooBang::onSysCommand(Message& message)
{
   if (message.wParam == SC_CLOSE)
	  PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
   else
	  message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

//=========================================================
// Bang command handling
//=========================================================
void fooBang::BangFoo_Hide() {
   PostMessage(GetFoobarWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
}

void fooBang::BangFoo_Display() {
   PostMessage(GetFoobarWnd(), WM_SYSCOMMAND, SC_RESTORE, 0);
}

void fooBang::BangFoo_About() {
   SetForegroundWindow(GetFoobarWnd());
   FoobarMessage(FOOBAR_ABOUT);
}

void fooBang::BangFoo_Fwd() {
   FoobarMessage(FOOBAR_FWD);
}

void fooBang::BangFoo_Rew() {
   FoobarMessage(FOOBAR_REW);
}

void fooBang::BangFoo_LoadFile() {
   if (!LoadFileNotOpen) { // Check for bool option
	  if (!GetFoobarWnd()) // Check to see if foobar is already there
		 FoobarOpen();
   }
   SetForegroundWindow(GetFoobarWnd());
   FoobarMessage(FOOBAR_OPENFILE); 
}

void fooBang::BangFoo_Next() {
   FoobarMessage(FOOBAR_NEXT);
}

void fooBang::BangFoo_OnTop() {
   FoobarMessage(FOOBAR_ALWAYSONTOP);
}

void fooBang::BangFoo_Pause() {
   FoobarMessage(FOOBAR_PAUSE);
}

void fooBang::BangFoo_Play() {
   if (!PlayNotOpen) {
	  if (!GetFoobarWnd())
		 FoobarOpen();
   }
   FoobarMessage(FOOBAR_PLAY);
}

void fooBang::BangFoo_Power() {
   (!GetFoobarWnd()) ? FoobarOpen() : FoobarMessage(FOOBAR_EXIT);
}

void fooBang::BangFoo_Prefs() {
   if (!PrefsNotOpen) {
	  if (!GetFoobarWnd())
		 FoobarOpen();
   }
   SetForegroundWindow(GetFoobarWnd());
   FoobarMessage(FOOBAR_PREFERENCES);
}

void fooBang::BangFoo_Prev() {
   FoobarMessage(FOOBAR_PREV);
}

void fooBang::BangFoo_Repeat() {
   FoobarMessage(FOOBAR_REPEAT);
}

// checks to see if foobar is minimized, if it is it restores it, if its not it minimizes it
void fooBang::BangFoo_Show() {
   if (!ShowNotOpen) {
	  if (!GetFoobarWnd())
		 FoobarOpen();
   }
   if (!IsIconic(GetFoobarWnd()))
   {
	  SetForegroundWindow(GetFoobarWnd());
	  PostMessage(GetFoobarWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
   }
   else {
	  PostMessage(GetFoobarWnd(), WM_SYSCOMMAND, SC_RESTORE, 0);
	  SetForegroundWindow(GetFoobarWnd());
   }
}

void fooBang::BangFoo_Shuffle() {
   FoobarMessage(FOOBAR_SHUFFLE);
}

void fooBang::BangFoo_VolumeDown() {
   FoobarMessage(FOOBAR_VOLUMEDOWN);
}

void fooBang::BangFoo_VolumeUp() {
   FoobarMessage(FOOBAR_VOLUMEUP);
}

void fooBang::BangFoo_Stop() {
   FoobarMessage(FOOBAR_STOP);
}

void fooBang::BangFoo_PowerOn() {
   if (!GetFoobarWnd())
   {
   FoobarOpen();
   }
   else
   {
   SetForegroundWindow(GetFoobarWnd());
   }
}

void fooBang::BangFoo_PowerOff() {
   FoobarMessage(FOOBAR_EXIT);
}

void fooBang::BangFoo_PlayPause() {
   if (!PlayPauseNotOpen) {
	  if (!GetFoobarWnd())
		 FoobarOpen();
   }
   FoobarMessage(FOOBAR_PLAYPAUSE);
}

void fooBang::BangFoo_Restart() {
   FoobarMessage(FOOBAR_EXIT);
   FoobarOpen();
}

void fooBang::BangFoo_RepeatOne() {
   FoobarMessage(FOOBAR_REPEATONE);
}

void fooBang::BangFoo_StopAfterCurrent() {
   FoobarMessage(FOOBAR_STOPAFTERCURRENT);
}

// This is our main message handler where all foobar message are passed to
void fooBang::FoobarMessage(const int messages) {
   SendMessage(GetFoobarWnd(), WM_COMMAND, messages, 0);
}

// Our simple foobar opener checks to run in minimised or normal modes
void fooBang::FoobarOpen() {
   if (FoobarStartNormal)
   {
	  WinExec(szAmpPath, SW_NORMAL);
	  SetForegroundWindow(GetFoobarWnd());
   }
   else
   {
	  WinExec(szAmpPath, SW_NORMAL);
	  if (!IsIconic(GetFoobarWnd()))
	  {
		 PostMessage(GetFoobarWnd(), WM_SYSCOMMAND, SC_RESTORE, 0);
	  }
	  PostMessage(GetFoobarWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
   }
}

HWND fooBang::GetFoobarWnd() {
   if (fooUseOldV)
	  return FindWindow("FOOBAR2000_CLASS", NULL);
   else
	  return FindWindow("{DA7CD0DE-1602-45e6-89A1-C2CA151E008E}", NULL);
}
