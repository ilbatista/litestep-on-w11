                    *************************
                    *      LSWallpaper      *
                    *      by Visigoth      *
                    *    ==============     *
                    *     Version: 1.5      *
                    *************************

Table of Contents
=================
I.    About LSWallpaper
II.   Change Log
III.  How to Use LSWallpaper

      III.1 Installation
      III.2 RC Commands
            - WallpaperBitmapPath
            - WallpaperTimeDelay
            - WallpaperListPath
            - WallpaperSequenced
            - WallpaperStartup
      III.3 !Bang Commands
            - !WallpaperManager
            - !NextWallpaper
            - !PreviousWallpaper
            - !RescanWallpaperList
            - !ChangeWallpaper
            - !AboutLSWallpaper
      III.4 The wallpapers.list File
      III.5 LSWallpaper Manager

IV.   Known Bugs/Limitations

      IV.1 Bitmaps ONLY
      IV.2 LSWallpaper doesn't Check Existance
      IV.3 Random doesn't always work

V.    Future Enhancements

      V.1 Wharf Bar Integration

VI.   Comments/Questions/Flames/Bug Reports
VII.  Source Code
VIII. Source Code License


I. About LSWallpaper
====================
   LSWallpaper is a Litestep module which changes, sequentially or
   randomly, your desktop wallpaper.  It was originally created by
   Visigoth (aka Shaheen Gandhi) because I had a program that did
   this for me, but I just wanted to get rid of another system
   tray icon!  Just a quick note: I'd really like to know if
   people are using this thing.  Just drop me an e-mail at
   gandhimail@worldnet.att.net  or  sgandhi@andrew.cmu.edu


II. Change Log
==============

   Version 1.5.1
   -------------
   Just one bug fix... At least some people will be happy.
   
      - Now compatible with newer Litestep builds

   Version 1.5
   -----------
   Features Features Features.
   
      - Holding Shift during startup stops the wallpaper from being
        changed (if WallpaperStartup is set).
      - GUI Configuration Tool (see section III.5 for details)

   Version 1.1
   -----------
   Mainly just a bug fix release.  Here's the list of bugs it fixes:

      - PreviousWallPaper now works as it should (ie. actually goes
        back)
      - A new !Bang Command - ChangeWallPaper - now allows you to
        change to a specific wallpaper.  For instance,
        !ChangeWallPaper myfavorite.bmp

        If no argument exists for ChangeWallPaper, it will be just
        like the timer had expired.  NOTE: The specified wallpaper
        must be in the list of wallpapers.


III. How to Use LSWallpaper
==========================

   III.1 Installation
   ------------------
   There's actually a lot to do for installing this thing, so pay
   attention!

   First, extract lswallpaper.dll to your modules directory.

   Second, your step.rc must be edited to load the module.  Add the
   following line to your step.rc.  To be safe, I added it after
   the desktop.dll, because, well, without a desktop, there's no
   wallpaper.

     LoadModule <ModuleDirectory>\lswallpaper.dll     ; LSWallpaper
     
   Recycle Litestep with !Recycle, and wait for lswallpaper to tell you
   that the wallpapers.list file doesn't exist.  Click Yes, and use the
   Wallpaper Manager to create a wallpapers.list.  For more control over
   LSWallpaper, see the RC Commands section below.

   The next few sections detail the commands and !bang commands
   available to you.  I would recommend at least using WallpaperTimeDelay
   since, otherwise, there wouldn't be *too* much of a point to using
   this module.
   
   With the new GUI Configuration tool, you don't have to go through
   writing the entire wallpaper.list yourself.  It's quite
   self-explanatory, but section III.5 discusses it in detail anyway.


   III.2 RC Commands
   -----------------
   The following is a list of RCCommands you may add to your step.rc
   to control certain LSWallpaper properties.

     WallPaperBitmapPath
     ```````````````````
     Description: The path LSWallpaper uses as the place to find
     wallpapers.  ie. C:\Litestep\Wallpapers...

     Default: PixmapPath

     Note: If PixmapPath is not available, LSWallpaper will not be
     able to use any of your wallpapers, unless you specify all
     of your wallpapers with absolute paths in your wallpapers.list
     (see below for more information about wallpapers.list).
     IMPORTANT: This path must be absolute.

     Example: WallPaperBitmapPath   C:\Litestep\Wallpapers


     WallPaperTimeDelay
     ``````````````````
     Description: The time interval used between wallpaper changes.

     Default: 00:00:00  (hours:minutes:seconds)

     Note: The default time interval (00:00:00) means the wallpaper
     stays constant.  There is no change of wallpaper after
     LSWallpaper has initialized.  IMPORTANT: I strongly recommend
     keeping this above 30 seconds (00:00:30).  It gets annoying
     and potentially dangerous to Windows.

     Example: WallPaperTimeDelay    6:00:00   ; Change every 6 hours


     WallPaperListPath
     `````````````````
     Description: The path to your list of wallpapers.

     Default: <ModulesDirectory>\wallpapers.list

     Note: The default occurs because LSWallpaper assumes the list of
     wallpapers is in its own directory.  This file does not have to
     be wallpapers.list.  It may be wallpapers.txt, for instance.
     IMPORTANT: This path must be absolute.

     Example: WallPaperListPath     C:\Litestep\wallpapers.list


     WallPaperSequenced
     ``````````````````
     Description: Turns on In-Sequence processing of the wallpaper
     list.  If left off, your wallpapers will change randomly with
     respect to the list of wallpapers.  If on, your wallpaper list
     will be followed line by line.

     Default: 0 (If it is left out of step.rc, it is considered off)

     Example: WallPaperSequenced


     WallPaperStartup
     ````````````````
     Description: Change the wallpaper at startup.

     Default: 0 (If it is left out of step.rc, it is considered off)

     Note: If WallPaperTimeDelay is left to be 00:00:00, you will
     probably want to use this.  Otherwise, the module would do
     nothing.

     Example: WallPaperStartup


   III.3 !Bang Commands
   --------------------
   !Bang Commands can be bound to keys, shortcuts, wharf items, etc.
   The following is a description of all the !Bang Commands
   LSWallpaper can handle.
   
     !WallpaperManager
     `````````````````
     Description: Launches the GUI configuration tool for LSWallpaper.
     The internal wallpaper list is updated automatically.  Should you
     decide to undo your changes, click Close and select No when asked to
     save your changes.

     !NextWallPaper
     ``````````````
     Description: Change to the Next WallPaper and resets the Timer.

     Note: If you have not specified WallPaperSequenced in your
     step.rc, this will use a random wallpaper from the list of
     wallpapers.


     !PreviousWallPaper
     ``````````````````
     Description: Change to the Previous Wallpaper and resets the
     Timer.


     !ChangeWallPaper <path>
     ```````````````````````
     Description: Changes to the wallpaper pointed to by <path>.
     If no path is supplied, it acts the same as if the timer
     had expired.  This also resets the Timer.


     !RescanWallPaperList
     ````````````````````
     Description: Rescans the list of wallpapers.

     Note: This does not change the wallpaper, but only retrieves
     the path and tile information about wallpapers. 


     !AboutLSWallpaper
     `````````````````
     Description: Brings up a message box with a little information
     about LSWallpaper.  Nothing special, for now :)


   III.4 The wallpapers.list File
   ------------------------------
   Note: This file does not have to be named wallpapers.list.  It may
   be called anything else, this is just descriptive.

   This file tells LSWallpaper how to use each file in your
   BitmapPath.  Also, each wallpaper you want to use must be listed
   in this file.

   Comments: Comments may be done in the C++ fashion: by starting the
   comment with '//'.  The rest of the line is ignored.

   File Setup: Basically, each line is a new wallpaper.  And each
   line is structured like this:

     [Path to Wallpaper]       [Tiled]

   Note: [Path to Wallpaper] may be an absolute or relative path. So,
   if you have one wallpaper that is not in your BitmapPath, you can
   just specify the entire path here instead of a relative one.

     Sample wallpapers.list File
     ```````````````````````````
     The following is a small list file.

       //This is a comment, and the beginning of the file
       Wallpaper1.bmp      0  //Relative path, no tiling.
       C:\Windows\tileable.bmp     1  //Absolute path, tiled.
   
   
   III.5 LSWallpaper Manager
   -------------------------
   The LSWallpaper Manager can be launched by using the !WallpaperManager
   !Bang Command.  There are very few functions involved in the manager,
   so everything should be pretty self-explanatory.  The following
   functions are available:
   
     Tile - check this to tile the selected wallpaper(s).
     Add / Remove - use these to add more wallpapers to the end of the
     list or remove the currently selected ones.
     Save / Close - self-explanatory
     Set Wallpaper - Set the selected wallpaper as the current wallpaper.
     
   Note: You can also double-click a wallpaper in the list to set it as
   the current wallpaper.


IV. Known Bugs/Limitations
===========================

   IV.1 Bitmaps ONLY
   -----------------
   LSWallpaper can only accept bitmap files at this point.  This is
   because the file is passed directly to windows, which only
   understands bitmap files, unless Active Desktop is on.  And we all
   hate Active Desktop, right?


   IV.2 LSWallpaper Doesn't Check Existance
   ----------------------------------------
   If you specify, in wallpapers.list, a file that does not exist,
   your desktop will become the background color.  This is because
   of two reasons:  1) Windows doesn't check that the wallpaper
   exists, and 2) LSWallpaper doesn't check that the wallpaper
   exists.  I plan to add this in future revisions.


   IV.3 Switching from Random to Sequenced doesn't work
   ----------------------------------------------------
   If you switch from Random to Sequenced, it will not work the first
   time around that you recycle/reboot.  I don't know why yet, but am
   working on it.  The second time, however, it will continue normal
   operation under the mode you selected (sequenced or random).


V. Future Enhancements
======================

   V.1 Wharf Bar Integration
   -------------------------
   I'm looking for a way to integrate this into the Wharf Bar.
   If any of you who know good UI development and such want to do
   something like this, here's an idea I've had:  The module could
   be something like LSCDPlay (or other skinnable wharf cd players).

   Basically, there would be an area for the time left until the next
   wallpaper change.  Also, there would be three buttons attached to
   the !Bang Commands: Next, Previous, and About Box.  That's all
   there really is, but more might come up...

   If you decide to do something like this, READ SECTIONS VI AND VII
   of this readme.


VI. Comments/Questions/Flames/Bug Reports
=========================================
   All of these should be sent directly to me, visigoth.  My e-mail
   address is:  gandhimail@worldnet.att.net

   Seriously, though, I really would like to know if people are using
   this thing.  It'll help me determine whether it's worth continuing
   the development of it.


VII. Source Code
===============
   Yes, source code is available.  All you have to do is send me an
   e-mail for it.  My e-mail is gandhimail@worldnet.att.net
   However, if you are going to edit the code, *please* read the
   Source Code License below.  There are certain restrictions.


VIII. Source Code License
=========================

   Article I. Sure, Have the Code!
   -------------------------------
   I don't want to stop progress on this module.  So, I'm going to
   let anyone who wants to edit the code, do so at his/her free will.
   However, there are restrictions, as noted by the rest of the
   license.

   Article II. Redistribution
   --------------------------
   This file *must* be redistributed with the source code, with duly
   noted changes to sections I, II, III, IV, and V.  However, I
   request that my name be left in Section I as the original author
   of the module.

   Article III. Leave Credit where It's Due!
   -----------------------------------------
   All I ask is that Section I still have my name in it as the
   original author.  And, that the !AboutLSWallpaper be renamed
   if it must, but the original about box should still be in the
   module and associated with a !Bang command.

   Article IV. Send Me Your Cool Stuff
   -----------------------------------
   I'd like to know about your ideas for LSWallpaper!  If you are
   working on an idea, I would like to know what it is.  I'm not like
   Microsoft (ie. I'm going to steal your idea, throw my time at it,
   and come out with a shoddier version first).  I'd just like to
   know what people are doing with my original code base.  So, if you
   do edit code for a purpose, please drop me a line as to what you
   are doing.

   Article V. Have Fun
   -------------------
   Remember, I'm not going to stop progress on this module, so go
   ahead and do what you want to it.  Just don't take credit for
   what I've already done.