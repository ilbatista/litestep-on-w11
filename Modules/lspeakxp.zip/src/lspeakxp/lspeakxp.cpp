/*
    This file is a part of lspeakxp.dll source code.

	Copyright (C) 2003 Mario Cruz

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


/* begin lspeakxp.cpp */

#include <string>
using namespace std;
#include <windows.h>
#include <sapi.h>
#include <sphelper.h>
#include "lspeakxp.h"
#include "..\current\lsapi\lsapi.h"

// Voice class object
Voice* lspeak;


// Module init
int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	lspeak = new Voice;
	if(lspeak->NotStarted()) quitModule(dllInst);
	return 0;
}


// Module end
void quitModule(HINSTANCE dllInst)
{
	delete lspeak;
}


// Bangs
// !Speak
void Speak(HWND current, LPCSTR args)
{
	lspeak->Say(args);
}

// !SpeakFile
void SpeakFile(HWND current, LPCSTR args)
{
	lspeak->Say(args, SPF_IS_FILENAME | SPF_IS_XML | SPF_ASYNC);
}

// !SpeakSetVolume
void SpeakVolume(HWND current, LPCSTR args)
{
	lspeak->SetVolume(StrToInt(args));
}

// !SpeakSetRate
void SpeakRate(HWND current, LPCSTR args)
{
	lspeak->SetRate(StrToInt(args));
}

// !SpeakSetVoice
void SpeakVoice(HWND current, LPCSTR args)
{
	lspeak->SetVoice(args);
}

// !SpeakSetXML
void SpeakXML(HWND current, LPCSTR args)
{
	lspeak->Say(args, SPF_PERSIST_XML | SPF_IS_XML | SPF_ASYNC);
}


// Voice class functions
Voice::Voice()
{
	// Create ISpVoice object
	pVoice = NULL;
	init=CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void **)&pVoice);
	
	// Load Configuration from step.rc
	ReadConfig();

	// Add Bang Commands
	AddBangCommand("!Speak", Speak);
	AddBangCommand("!SpeakFile", SpeakFile);
	AddBangCommand("!SpeakSetVol", SpeakVolume);
	AddBangCommand("!SpeakSetVoice", SpeakVoice);
	AddBangCommand("!SpeakSetRate", SpeakRate);
	AddBangCommand("!SpeakSetXML", SpeakXML);

}


Voice::~Voice()
{
	// Clean Bang Commands
	RemoveBangCommand("!Speak");
	RemoveBangCommand("!SpeakFile");
	RemoveBangCommand("!SpeakSetVol");
	RemoveBangCommand("!SpeakSetVoice");
	RemoveBangCommand("!SpeakSetRate");
	RemoveBangCommand("!SpeakSetXML");
	
	// Destroy ISpVoice object
	pVoice->Release();
	delete pVoice;
}


void Voice::Say(LPCSTR args, DWORD flags)
{
	// WCHAR needed for ISpVoice.Speak
	WCHAR* phrase = StrToWstr(args);
	
	if(pVoice != NULL)
	{
		// Speak! :)
		pVoice->Speak(phrase, flags, NULL);
	}

	// StrToWstr leaves cleaning to the caller
	delete phrase;
}

void Voice::SetRate(int rate)
{
	pVoice->SetRate(rate);
}

void Voice::SetVolume(int vol)
{
	pVoice->SetVolume(vol);
}

void Voice::SetVoice(LPCSTR args)
{
	// Token Objects
	ISpObjectToken *pToken, *pOldToken;

	// Turn name into argument
	string reqs(args);
	reqs = "Name=" + reqs;
	WCHAR* lReqs = StrToWstr(reqs.c_str());

	/* Alternatively one could just call Say with SPF_PERSIST_XML and an XML format
	 * This way we learn how to use SpFindBestToken */
	pVoice->GetVoice(&pOldToken);
	if(SpFindBestToken(SPCAT_VOICES, lReqs, NULL, &pToken) == S_OK)
	{
		pVoice->SetVoice(pToken);
		delete pOldToken;
	}
	
	// StrToWstr leaves cleaning to the caller
	delete lReqs;
}

void Voice::ReadConfig()
{
	char buff[1024];
	
	// Read Volume info from step.rc
	SetVolume(GetRCInt("LSpeakVolume", 100));

	// Read Rate info from step.rc
	SetRate(GetRCInt("LSpeakRate", 0));
		
	// Read Voice info from step.rc
	if(GetRCLine("LSpeakVoice", buff, 1023, ""))
		SetVoice(buff);

	// Read OnLoad info from step.rc
	if(GetRCLine("LSpeakOnLoad", buff, 1023, ""))
		Say(buff);
	
}

int Voice::NotStarted()
{
	return init;
}

// Convert a LPCSTR to a WCHAR string
WCHAR* Voice::StrToWstr(LPCSTR str)
{
	WCHAR *phrase;
	int str_size = strlen(str)+1;
	phrase = new WCHAR[str_size];

	MultiByteToWideChar(CP_ACP, MB_COMPOSITE, str, str_size, phrase, str_size);
	return phrase;
}

