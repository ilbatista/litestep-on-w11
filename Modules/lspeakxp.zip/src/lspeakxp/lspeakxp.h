/*
    This file is a part of lspeakxp.dll source code.

	Copyright (C) 2003 Mario Cruz

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* begin lspeakxp.h */

#ifndef LSPEAKXP_MOD
#define LSPEAKXP_MOD

#include <SAPI.h>

// bang commands
void Speak(HWND current, LPCSTR args);
void SpeakVolume(HWND current, LPCSTR args);
void SpeakRate(HWND current, LPCSTR args);
void SpeakVoice(HWND current, LPCSTR args);
void SpeakFile(HWND current, LPCSTR args);

// module object
class Voice
{
public:
	Voice();
	~Voice();
	
	void Say(LPCSTR args, DWORD flags = (SPF_IS_XML | SPF_ASYNC));
	void ReadConfig();
	void SetVolume(int vol);
	void SetRate(int rate);
	void SetVoice(LPCSTR args);
	int NotStarted();
	WCHAR* StrToWstr(LPCSTR str);

private:
	int init;
	ISpVoice* pVoice;
};

//* exported init and quit functions
extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}


#endif
