[Changelog]

1.85 : Changed the maximum decimals to prevent som problems. (still >6 decimals available)

1.84 : Ah, well.. the hackish solution below was annoying, so I wrote a simple string->float function and use that instead of the library.
	Size back down to 29kb. Both comma and dot will work regardless of location.
	Example : !SliderSetVolume 0 25,46
	Example : !SliderSetVolume 0 25.46

1.83 : SliderSetVolume now accepts decimals for the volume, this allows you to access the full word(65536 values) that is available in windows.
	Unfortunately I had to include the sysutils library, which almost doubled the size of the dll(now 54kb).
	I needed the StringToFloat function, I'll see if I just hack up my own function some time, but for now this works fine(and was easy to do:P).
	Example : !SliderSetVolume 0 25,46
	I think the comma/dot depends on your current os-settings, I live in Norway so I use comma.

1.82 : bug where the [AMPVOLUME] bar would not show fixed - big thanks to muh-Kuh for bugreport:)

1.81 : [AMPVOLUME] replaces the W stuff - big thanks to muh-Kuh for idea:)

1.8 : Version 1.8 is built on LsSlider 1.71 so it has support for all the new stuff.
	In addition this version does not replace the winamp functionality, 
	instead it just adds the [FOOBAR2000] slidermode

1.1 : Major fix, 1.0 was an old testversion, not functional, 1.1 should work;)
1.0 : Initial Release

Just a small mod of the lsslider source, 
basically adds the ability to conreol foobar2000 with the foo_remote plugin.

by thegeek @ efnet.


I don't know how all this works, so if anyone has any objections to me
releasing this, please let me know. I just thought someone(like me)
would really like to use this. I really suck at programming, so the code is probably terrible.
However, it does work, just make sure to replace your slider line

from (example): 
*Slider "Track"  $SlidersX$ 12 1 "SliderTrack.png" "SliderHandleT.png" #1HIT [WINAMP] 0
to:
*Slider "Track"  $SlidersX$ 12 1 "SliderTrack.png" "SliderHandleT.png" #1HIT [FOOBAR2000] 0 