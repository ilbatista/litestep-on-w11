///////////////////////////////////////////////////////////
//
//           LSLIVE! version 2.0.1.0 Alpha
//            Animated gifs for Litestep
//                   09/08/2005
//                written by Mercutio
//
///////////////////////////////////////////////////////////

ABOUT:

LSLIVE! is a module to allow use of animated .gif's in Litestep.
I started this project in 1998, and the first releases were stand-
alone .exe files that provided similar functionality.  This version
(finally) is as it was originally intended to be... a Litestep
module.  This release is a bit "stripped down" feature-wise 
but more features are planned for later versions.


FUNCTIONS:

As of this release, LSLIVE! (still) does exactly two things:
1. display animated gifs on the Litestep desktop
2. Launch .exe files

True transparency is currently in the works.  Additional features
will be added as I think of them/have time to work on them.  Feature
lists, To Do's, and bug lists will be up on my website(www.theeclectic.net)
when I have time to set them up.


SETUP:

  Unzip the .zip file into your Litestep/Modules folder.  Add the
path to lslive.dll to your step.rc.  Unlike previous versions, user
settings are now located in Modules.ini.

SETTINGS:
Note that any settings starting with "lslive1_" are individual settings for the
first instance.  The second instance will be "lslive2_" and so on.

maxSC=             <---  This determines the number of instances you are running
lslive1_GifPath=   <---  path to the gif file
lslive1_ExePath=   <---  Path to the executable you want to launch
lslive1_AniSpeed=  <---  Speed of the animation.  Lower is faster.
lslive1_MMode=     <---  "Move Mode" 1=draggable, 0=not

CHANGES:

1. Added support for multiple instances.
2. User settings now in Modules.ini


Disclaimer:

This software is currently in ALPHA...  while it is working properly
to the best of my knowledge, it has only been tested on one computer
under one environment.  I am not responsible for anything it might
do to you, your computer, your cat, ferret, or other small domestic 
animal, etc., etc...

License:

This software is free to use other than in commercial/government applications.
You may redistribute this software freely as long as the original documentation
is included.  You MAY NOT sell, reverse engineer, take credit for, etc. this
program without my written consent.  If you intend to use this software for
any purpose not listed above, please contact me with details.


Contact:

Questions and concerns can be sent to mercutio@theeclectic.net.
My nick on Litestep.net is lslive_mercutio.
On IRC, I'm usually in #litestep on freenode. My handle is lslive_mercutio
or DesktopMojo.
Website is www.theeclectic.net