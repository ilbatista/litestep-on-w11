// DO NOT DELETE NEXT LINE
// LMA1.0 
/*
LiteStep Module AppWizard
*/

#ifndef __BangLogger_H
#define __BangLogger_H

#include <windows.h>
#include "window.h"
#include "..\current\lsapi\lsapi.h"

#include <deque>
using namespace std;

#define MAX_LINE_LENGTH 4096

class LogMsg
{
public:
	char* date;
	char* level;
	char* module;
	char* text;
};

class BangLogger : public Window
{
private:
	deque<LogMsg> MessageList;

	bool bInitialized;
	int nLogLevel;
	int nLogItems;
	char* szLogDivider;
	char* szBang;

public:
	BangLogger(HWND parentWnd, int& code);
	~BangLogger();

	void EnterMessage(LogMsg* msg, int nLevel, LPCSTR pszModule, LPCSTR pszMessage);
	void RemoveMessages();
	BOOL Log(int nLevel, LPCSTR pszModule, LPCSTR pszMessage);

private:
	void ReadSettings();

	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onNotify(Message& message);
	void onCreate(Message& message);
	void onPaint(Message& message);
	void onSysCommand(Message& message);
	void onLMRecycle(Message& message);
};

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
