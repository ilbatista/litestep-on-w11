/****************************************************************************

BangLogger 0.1
by Vendicator (http://pimpin.info/vendicator | vendicator@mail.com)

BangLogger is for use with a indiestep build dated 2002-11-15 or later
(which is when the log code could accept third party listeners).
This module is intended when you want to redirect log messages to
some other output through the use of a bang.


Step.rc Settings:

	BangLoggerBang
	!Bang, default: !None
	Bang to receive the output

	BangLoggerLogItems
	Int, default: 1
	How many log items to merge in output, separated by new lines

	BangLoggerItemSeparator
	String, default: '\n' (new line char)
	Separator between items, specify other for label interaction (specify \n)

	BangLoggerLogLevel 1-4
	Int, default: 4  (1: errors, 2: warnings, 3: notices, 4: debug)
	- Sets which levels that should be logged, this level and below is logged.


Changelog:
	Added [Vendicator, 2002-11-24]
	  - Started work


Todo:


****************************************************************************/

#include "winutils.h"
#include "lsutils.h"
#include "BangLogger.h"
#include <commctrl.h>

const char SettingsPrefix[] = "BangLogger"; // Prefix for settings
const char szAppName[] = "BangLogger"; // Our window class, etc
const char rcsRevision[] = "$Revision: 0.1 $"; // Our Version
const char rcsId[] = "$Id: BangLogger.cpp,v 0.1 12:16:4 Vendicator Exp $"; // The Full RCS ID.
BangLogger* banglogger; // The module


//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	banglogger = new BangLogger(ParentWnd, code);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete banglogger;
}

//=========================================================
// Bang commands
//=========================================================

BOOL //WINAPI
LogMessage(int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	return banglogger->Log(nLevel, pszModule, pszMessage);
}

//=========================================================
// Module code
//=========================================================

// make a copy of this message
void BangLogger::EnterMessage(LogMsg* msg, int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	SYSTEMTIME time;
	GetLocalTime(&time);

	char date[60];
	char level[10];
	sprintf(level, "%d", nLevel);
	sprintf(date, "%d-%02d-%02d %02d:%02d:%02d", time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute, time.wSecond);

	msg->date = new char[strlen(date)+1];
	strcpy(msg->date, date);

	msg->level = new char[strlen(level)+1];
	strcpy(msg->level, level);

	msg->module = new char[strlen(pszModule)+1];
	strcpy(msg->module, pszModule);

	msg->text = new char[strlen(pszMessage)+1];
	strcpy(msg->text, pszMessage);

	MessageList.push_back(*msg);
}

void BangLogger::RemoveMessages()
{
	for (deque<LogMsg>::iterator i = MessageList.begin(); i != MessageList.end(); i++)
	{
		delete [] ((LogMsg) (*i)).date;
		delete [] ((LogMsg) (*i)).level;
		delete [] ((LogMsg) (*i)).module;
		delete [] ((LogMsg) (*i)).text;
	}
	MessageList.clear();
}

BOOL BangLogger::Log(int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	if (nLogLevel <= nLevel && bInitialized)
	{
		LogMsg msg;
		EnterMessage(&msg, nLevel, pszModule, pszMessage);

		int size = MessageList.size();

		// if the we're past the limit, remove first
		if (size > nLogItems)
			MessageList.pop_front();
	
		// start calculating command length
		int length = strlen(szBang) + 1;

		deque<LogMsg>::iterator i;
		for (i = MessageList.begin(); i != MessageList.end(); i++)
		{
			length += strlen( ((LogMsg) (*i)).date );
			length += strlen( ((LogMsg) (*i)).level );
			length += strlen( ((LogMsg) (*i)).module );
			length += strlen( ((LogMsg) (*i)).text );

			length += 3; // 3 spaces between
			length += strlen(szLogDivider);
			length++; // extra
		}
		length += 2;


		// copy in bang
		char* temp = new char[length];
		memset(temp, 0, length);
		strcpy(temp, szBang);
		strcat(temp, " ");
		strcat(temp, "\"");

		for (i = MessageList.begin(); i != MessageList.end(); i++)
		{
			strcat(temp, ((LogMsg) (*i)).date );
			strcat(temp, " ");
			strcat(temp, ((LogMsg) (*i)).level);
			strcat(temp, " ");
			strcat(temp, ((LogMsg) (*i)).module);
			strcat(temp, " ");
			strcat(temp, ((LogMsg) (*i)).text);
			strcat(temp, szLogDivider);
		}
		strcat(temp, "\"");

		//MessageBox(NULL, temp, "Test bang", MB_OK);
		
		LSExecute(GetLitestepWnd(), temp, NULL);

		delete [] temp;
		return TRUE;
	}
	else
		return FALSE;
}


//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
BangLogger::BangLogger(HWND parentWnd, int& code):
Window(szAppName),
nLogLevel(LOG_DEBUG),
bInitialized(false)
{

	int msgs[] = {LM_GETREVID, LM_RECYCLE, 0};

	HWND desktop = WinUtils::GetDesktopHWND();

	if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
                    0, 0, 0, 0, desktop))
	{
		MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
		code = 1;
		return;
	}

	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	ReadSettings();

	bInitialized = true;
	AddLogListener(LogMessage);
	
	code = 0;
}

void BangLogger::ReadSettings()
{
	char szTemp[256];

	// !Bang
	LSUtils::PrefixedGetRCLine(SettingsPrefix, "Bang", szTemp, MAX_LINE_LENGTH, "!NONE");
	szBang = new char[strlen(szTemp)+1];
	strcpy(szBang, szTemp);

	// separator
	LSUtils::PrefixedGetRCLine(SettingsPrefix, "ItemSeparator", szTemp, MAX_LINE_LENGTH, "\n");
	szLogDivider = new char[strlen(szTemp)+1];
	strcpy(szLogDivider, szTemp);

	nLogLevel = LSUtils::PrefixedGetRCInt(SettingsPrefix, "LogLevel", LOG_DEBUG);
	nLogItems = LSUtils::PrefixedGetRCInt(SettingsPrefix, "LogItems", LOG_DEBUG);
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
BangLogger::~BangLogger()
{
	int msgs[] = {LM_GETREVID, LM_RECYCLE, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	RemoveLogListener(LogMessage);

	RemoveMessages();
	delete [] szLogDivider;
	delete [] szBang;

	destroyWindow();
}


//=========================================================
// Registered messages
//=========================================================

void BangLogger::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onEndSession,       WM_ENDSESSION)
		MESSAGE(onEndSession,       WM_QUERYENDSESSION)
		MESSAGE(onGetRevId,         LM_GETREVID)
		//MESSAGE(onPaint,			WM_PAINT)
		MESSAGE(onNotify,			WM_NOTIFY)
		MESSAGE(onCreate,		WM_CREATE)
		MESSAGE(onSysCommand,       WM_SYSCOMMAND)
		MESSAGE(onLMRecycle,		LM_RECYCLE)
	END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void BangLogger::onNotify(Message& message)
{
}

void BangLogger::onPaint(Message& message)
{
}

void BangLogger::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void BangLogger::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
	case 0:
		sprintf(buf, "LogConsole.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
	break;
	case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
	break;
	default:
		strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


void BangLogger::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void BangLogger::onLMRecycle(Message& message)
{
}

void BangLogger::onCreate(Message& message)
{
}

//=========================================================
// Bang command handling
//=========================================================
