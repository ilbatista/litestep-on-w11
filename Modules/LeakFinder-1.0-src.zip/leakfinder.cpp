#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <lsapi.h>
#pragma comment(lib,"lsapi.lib")
#include "..\AggressiveOptimize.h"

#ifdef LS_AUTHORIZATION_UNAVAILABLE
#error Wrong LSAPI.H.  Make sure the path is right.
#endif

extern "C" {
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);
}

extern bool InitHooker(void);
extern void QuitHooker(void);
extern void DumpAndCleanup(void);

int initModuleEx(HWND ParentWnd, HINSTANCE dll, LPCSTR szPath)
{
  InitHooker();
  return 0;
}

int quitModule(HINSTANCE dll)
{
  QuitHooker();
  DumpAndCleanup();
  return 0;
}

