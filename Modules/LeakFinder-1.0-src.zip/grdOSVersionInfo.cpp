#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "grdOSVersionInfo.h"

grdOSVersionInfo::grdOSVersionInfo() {
  memset(&osvi, 0, sizeof(OSVERSIONINFO));
  osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  if(!GetVersionEx(&osvi)) {
    OutputDebugString("GetVersionEx() failed\n");
  }
}

grdOSVersionInfo::~grdOSVersionInfo() {
  // nothing to do here...
}

bool grdOSVersionInfo::IsNT() {
  return (bool)(VER_PLATFORM_WIN32_NT == osvi.dwPlatformId);
}

bool grdOSVersionInfo::Is2K() {
  return (bool)(IsNT() && osvi.dwMajorVersion >= 5);
}
