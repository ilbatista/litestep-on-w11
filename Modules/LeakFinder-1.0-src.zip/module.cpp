#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include <lsapi.h>
#include "tracker.h"
#include "module.h"
#include "grdFunctionHooker.h"

ModuleMap g_Modules;
grdFunctionHooker *g_pHooker=NULL; /* global hooker, available to all ;) */ 

HMODULE (WINAPI *g_LoadLibrary)(LPCTSTR lpLibFileName);

void Trace(LPCTSTR TraceFileName,LPCTSTR a,LPCTSTR b,LPCTSTR c)
{
  HANDLE hFile;
  TCHAR buf[4096];

  if (!TraceFileName) return;

  hFile = CreateFile(TraceFileName,FILE_WRITE_DATA,FILE_SHARE_READ,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_ARCHIVE,NULL);

  SetFilePointer(hFile,0,0,FILE_END);

  _tcscpy(buf,a);
  if (b) _tcscat(buf,b);
  if (c) _tcscat(buf,c);
  _tcscat(buf,_T("\x0d\x0a"));

  DWORD bWritten;
  WriteFile(hFile,buf,_tcslen(buf)/sizeof(TCHAR),&bWritten,NULL);

  CloseHandle(hFile);
}

void ModuleTracker::Trace(LPCTSTR a,LPCTSTR b,LPCTSTR c)
{
  ::Trace(TraceFileName,a,b,c);
}

void AnonTrace(LPCTSTR a,LPCTSTR b,LPCTSTR c)
{
  HMODULE hMod = GetModuleHandle(NULL);
  TCHAR name[MAX_PATH_LENGTH];
  TCHAR logfile[MAX_PATH_LENGTH];
  TCHAR *ptr,*slash,*dot = NULL;
  if (GetModuleFileName(hMod,name,MAX_PATH_LENGTH))
  {
    slash = ptr = name;
    while (*ptr)
    {
      if (*ptr == _T('/') || *ptr == _T('\\')) slash = ptr;
      if (*ptr == _T('.')) dot = ptr;
      //_tcsinc(ptr);
      ++ptr;
    }
    if (dot) *dot = 0;
  }
  else
    slash = "LeakFinder";

  VarExpansion(logfile,"$LiteStepDir$logs");
  _tcscat(logfile,slash);
  _tcscat(logfile,".lf.txt");

  ::Trace(logfile,a,b,c);
}

void ModuleTracker::SetModuleName(TCHAR *name)
{
  TCHAR *ptr,*slash,*dot = NULL;
  slash = ptr = name;
  while (*ptr)
  {
    if (*ptr == _T('/') || *ptr == _T('\\')) slash = ptr+1;
    if (*ptr == _T('.')) dot = ptr;
    //_tcsinc(ptr);
    ++ptr;
  }
  if (dot) *dot = 0;

  ModuleName = new TCHAR[_tcslen(slash)+1];
  _tcscpy(ModuleName,slash);
}

HMODULE WINAPI PatchAndLoadModule(LPCTSTR szLibraryName)
{ /* adapted from grdMagick::MagicLoadLibrary */ 
  HMODULE hMod = g_LoadLibrary(szLibraryName);
  PatchFuncRec *pFunc = g_PatchList;
  ModuleTracker *mt;

  if (!hMod) return NULL;

  /* get module short name and trace file name */ 
  TCHAR name[MAX_PATH_LENGTH];
  if (!GetModuleFileName(hMod,name,MAX_PATH_LENGTH))
    return hMod;

  mt = new ModuleTracker;
  mt->ModuleName = mt->TraceFileName = NULL;

  mt->SetModuleName(name);
  VarExpansion(name,_T("$LiteStepDir$Logs\\"));
  _tcscat(name,mt->ModuleName);
  _tcscat(name,_T(".lf.txt"));
  mt->TraceFileName = new TCHAR[_tcslen(name)+1];
  _tcscpy(mt->TraceFileName,name);

  grdFunctionHooker::HookFunc hf;
  hf.fdDescription.hModule = hMod;
  _tcscpy(hf.fdDescription.szLibraryName, _T("GDI32.DLL"));

  g_Modules[hMod] = mt;

  while (pFunc->Name)
  {
    _tcscpy(hf.fdDescription.szFunctionName, pFunc->Name);
    hf.procReplacement = (PROC)pFunc->Stub;

    g_pHooker->RerouteFunction(&hf);
    ++pFunc;
  }

  return hMod;
}

bool InitHooker(void)
{ /* mostly copied from grdMagick::StartFunctionHooks */ 
  g_pHooker = new grdFunctionHooker();
  if (!g_pHooker) return false;

  grdFunctionHooker::HookFunc hf;

  hf.fdDescription.hModule = GetModuleHandle(_T("dllmgr.dll"));
  if(hf.fdDescription.hModule==NULL) {
    /* older versions of litestep don't utilize dllmgr.dll */ 
    hf.fdDescription.hModule = GetModuleHandle(_T("litestep.exe"));

    /* if the applications name is not "litestep.exe" look it up */ 
/* screw dat
    if(hf.fdDescription.hModule==NULL) {
      DWORD dwProcessID = GetCurrentProcessId();
      HANDLE hss = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
      PROCESSENTRY32 pe;
      pe.dwSize = sizeof(PROCESSENTRY32);
      if(Process32First(hss, &pe)) {
        do {
          if(pe.th32ProcessID == dwProcessID) {
            hf.fdDescription.hModule = GetModuleHandle(pe.szExeFile);
            break;
          }
        } while(Process32Next(hss, &pe));
      }
      CloseHandle(hss);
    }
    */

  }
  _tcscpy(hf.fdDescription.szLibraryName, _T("kernel32.dll"));

#ifdef _UNICODE
  _tcscpy(hf.fdDescription.szFunctionName, _T("LoadLibraryW"));
#else
  _tcscpy(hf.fdDescription.szFunctionName, _T("LoadLibraryA"));
#endif

  hf.procReplacement = (PROC)PatchAndLoadModule;

  if(SUCCEEDED(g_pHooker->RerouteFunction(&hf))) {
    g_LoadLibrary = (HMODULE (WINAPI *)(LPCTSTR lpLibFileName))hf.procOriginal;
    return true;
  }
  return false;
}

void QuitHooker(void)
{
  if (!g_pHooker) return;

  delete g_pHooker;
  g_pHooker = NULL;
}


HMODULE GetModuleHandleFromAddr(DWORD addr)
{
  MEMORY_BASIC_INFORMATION mbi;
  VirtualQuery((void*)addr, &mbi, sizeof(mbi) );
  return (HMODULE)mbi.AllocationBase;
}