
void AnonTrace(LPCTSTR a,LPCTSTR b,LPCTSTR c);

class ModuleTracker
{
public:
  TCHAR *ModuleName;
  TCHAR *TraceFileName;

  void SetModuleName(TCHAR *);
  void Trace(LPCTSTR,LPCTSTR=NULL,LPCTSTR=NULL);
};

typedef std::map<HMODULE,ModuleTracker *> ModuleMap;

extern ModuleMap g_Modules;
extern ResTracker g_Tracker;

HMODULE GetModuleHandleFromAddr(DWORD addr);

inline ModuleTracker *GetTracker(DWORD addr)
{
  ModuleMap::iterator item = g_Modules.find(GetModuleHandleFromAddr(addr));
  if (item!=g_Modules.end()) return (*item).second;
  return NULL;
}

