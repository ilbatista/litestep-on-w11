

struct PatchFuncRec
{
  TCHAR *Name;
  void (__stdcall *Stub)(void);
};

extern PatchFuncRec g_PatchList[];

#pragma warning(disable: 4786)
#include <map>
#include <algorithm>

class ModuleTracker;

struct CodeAddr
{
  DWORD Addr;
  ModuleTracker *Base;
  DWORD ResType;

  CodeAddr(DWORD A,ModuleTracker *B,DWORD R) : Addr(A), Base(B), ResType(R) { }
  CodeAddr(void) : Addr(0), Base(0), ResType(0) { }
};

void TraceRes(ModuleTracker *mt,char io,HANDLE h,DWORD addr,DWORD type);

class ResTracker
{
public:
  typedef std::map<HANDLE,CodeAddr> ResMap;
  ResMap ResList;

  void Add(HANDLE h,DWORD AA,ModuleTracker *base)
  {
    DWORD t = GetObjectType(h);
    ResList[h] = CodeAddr(AA,base,t);
    TraceRes(base,'+',h,AA,t);
  }
  void Del(HANDLE h)
  {
    ResMap::iterator item;
    if (!(ResList.empty() || (item=ResList.find(h))==ResList.end()))
    {
      TraceRes(
        (*item).second.Base,'-',h,
        (*item).second.Addr,
        (*item).second.ResType);
      ResList.erase(item);
    }
  }
};

class Patcher
{
protected:
//  static HINSTANCE WINAPI StubLoadLibrary(LPCTSTR szLibraryName);
//  static HINSTANCE WINAPI (*pLoadLibrary)(LPCTSTR);
public:
};


