#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include "tracker.h"
#include "module.h"

#define ROOTTRACEFILE "C:\\LiteStep\\logs\\LeakFinder.txt"

extern const char *GetTypeString(int i);
extern LPCTSTR DumpH(HANDLE h,DWORD type);

void TraceRes(ModuleTracker *mt,char io,HANDLE h,DWORD addr,DWORD type)
{
  char b[256];
  sprintf(b,"%c @%08X: %s",io,addr,DumpH(h,type));
  if (mt) mt->Trace(b);
  else ::AnonTrace(b,NULL,NULL);
}

void AddResource(HANDLE h,DWORD addr)
{
  ModuleTracker *mt = GetTracker(addr);

  g_Tracker.Add(h,addr,mt);
}

// call function at ecx and add returned handle to tracker for module
// needs to be naked so stack is right for hooked proc
// Actually it doesn't, but I don't want to have to write stubs for every
// function to copy the parameters properly, so it's easier to just use the
// ones already on the stack, and only 2 instructions are repeated for each.
void __declspec(naked) StubProc(void)
{
  static DWORD rets[16];
  static DWORD retv[16];
  static int i=0;

  __asm {
    pop eax
    pop eax /* return address */ 
    push edi
    mov edi,i
    lea edx,rets
    mov [edx+edi],eax
    inc edi
    mov i,edi
    pop edi
    call ecx /* call real function */ 
    mov ecx,i
    mov edx,offset retv
    dec ecx
    mov [edx+ecx],eax /* returned handle */ 
    push ecx
    mov i,ecx
  }

  /* would be better off as inline asm as well, but this is easier */ 
  /* (because the handle and i we just wrote don't need to be read */ 
  /* again, but the compiler probably doesn't know that)           */ 
  if (retv[i]) AddResource((HANDLE)retv[i],(DWORD)rets[i]);

  __asm {
    pop ecx
    lea edx,rets
    mov eax,[edx+ecx] /* return address */ 
    mov edx,offset retv
    push eax
    mov eax,[edx+ecx] /* returned handle */ 
    ret
  }
}

// needs to be naked so stack is right for hooked proc
#define DEF_STUB(syscall) \
void __declspec(naked) Stub##syscall(void) { __asm { mov ecx,dword ptr syscall } StubProc(); }

DEF_STUB(CreateBitmap)
DEF_STUB(CreateBitmapIndirect)
DEF_STUB(CreateBrushIndirect)
DEF_STUB(CreateCompatibleBitmap)
DEF_STUB(CreateCompatibleDC)
DEF_STUB(CreateDCA)
DEF_STUB(CreateDCW)
DEF_STUB(CreateDIBPatternBrush)
DEF_STUB(CreateDIBPatternBrushPt)
DEF_STUB(CreateDIBSection)
DEF_STUB(CreateDIBitmap)
DEF_STUB(CreateDiscardableBitmap)
DEF_STUB(CreateEllipticRgn)
DEF_STUB(CreateEllipticRgnIndirect)
DEF_STUB(CreateEnhMetaFileA)
DEF_STUB(CreateEnhMetaFileW)
DEF_STUB(CreateFontA)
DEF_STUB(CreateFontIndirectA)
DEF_STUB(CreateFontIndirectW)
DEF_STUB(CreateFontW)
DEF_STUB(CreateHatchBrush)
DEF_STUB(CreateMetaFileA)
DEF_STUB(CreateMetaFileW)
DEF_STUB(CreatePatternBrush)
DEF_STUB(CreatePen)
DEF_STUB(CreatePenIndirect)
DEF_STUB(CreatePolyPolygonRgn)
DEF_STUB(CreatePolygonRgn)
DEF_STUB(CreateRectRgn)
DEF_STUB(CreateRectRgnIndirect)
DEF_STUB(CreateRoundRectRgn)
DEF_STUB(CreateSolidBrush)

// for the rest we know the exact parameter list, so we don't care about preserving the stack
// they do need to be WINAPI tho, because that's what the caller is expecting

#define GET_RET_ADDR(a) \
_asm mov eax,[esp+4] \
_asm mov a,eax

BOOL WINAPI StubDeleteObject(HGDIOBJ handle)
{
  int addr;
  GET_RET_ADDR(addr);
  ModuleTracker *mt = GetTracker(addr);
  int i;

  i = GetObjectType(handle);
  switch (i)
  {
  case 0:
    {
      char b[16];
      sprintf(b,"%08X",handle);
      if (mt) mt->Trace("DeleteObject"," unable to get type for ",b);
      else ::AnonTrace("DeleteObject"," unable to get type for ",b);
    }
    break;
  case OBJ_DC:
  case OBJ_MEMDC:
  case OBJ_METADC:
  case OBJ_ENHMETADC:
  case OBJ_METAFILE:
  case OBJ_ENHMETAFILE:
    if (mt) mt->Trace("DeleteObject"," called with ",GetTypeString(i));
    else ::AnonTrace("DeleteObject"," called with ",GetTypeString(i));
    break;
  }

  if (DeleteObject(handle))
  {
    g_Tracker.Del(handle);
    return TRUE;
  }
  return FALSE;
}

BOOL WINAPI StubDeleteDC(HDC handle)
{
  int addr;
  GET_RET_ADDR(addr);
  ModuleTracker *mt = GetTracker(addr);
  int i;

  i = GetObjectType(handle);
  switch (i)
  {
  case 0:
    {
      char b[16];
      sprintf(b,"%08X",handle);
      if (mt) mt->Trace("DeleteDC"," unable to get type for ",b);
      else ::AnonTrace("DeleteDC"," unable to get type for ",b);
    }
    break;
  case OBJ_MEMDC:
  case OBJ_METADC:
  case OBJ_ENHMETADC:
  case OBJ_DC: break;
  default:
    if (mt) mt->Trace("DeleteDC"," called with ",GetTypeString(i));
    else ::AnonTrace("DeleteDC"," called with ",GetTypeString(i));
  }

  if (DeleteDC(handle))
  {
    g_Tracker.Del(handle);
    return TRUE;
  }
  return FALSE;
}

BOOL WINAPI StubDeleteMetaFile(HMETAFILE handle)
{
  int addr;
  GET_RET_ADDR(addr);
  ModuleTracker *mt = GetTracker(addr);
  int i;

  i = GetObjectType(handle);
  switch (i)
  {
  case OBJ_METAFILE:
  case OBJ_ENHMETAFILE: break;
  default:
    if (mt) mt->Trace("DeleteMetaFile"," called with ",GetTypeString(i));
    else ::AnonTrace("DeleteMetaFile"," called with ",GetTypeString(i));
  }

  if (DeleteMetaFile(handle))
  {
    g_Tracker.Del(handle);
    return TRUE;
  }
  return FALSE;
}

BOOL WINAPI StubDeleteEnhMetaFile(HENHMETAFILE handle)
{
  int addr;
  GET_RET_ADDR(addr);
  ModuleTracker *mt = GetTracker(addr);
  int i;

  i = GetObjectType(handle);
  switch (i)
  {
  case OBJ_METAFILE:
  case OBJ_ENHMETAFILE: break;
  default:
    if (mt) mt->Trace("DeleteEnhMetaFile"," called with ",GetTypeString(i));
    else ::AnonTrace("DeleteEnhMetaFile"," called with ",GetTypeString(i));
  }

  if (DeleteEnhMetaFile(handle))
  {
    g_Tracker.Del(handle);
    return TRUE;
  }
  return FALSE;
}


#define PATCH_FUNC_ENTRY(name) { _T(#name), (void (__stdcall*)(void))&Stub##name },
//#define PATCH_DLL_ENTRY(name) { #name, NULL },

PatchFuncRec g_PatchList[] =
{
  PATCH_FUNC_ENTRY(CreateBitmap)
  PATCH_FUNC_ENTRY(CreateBitmapIndirect)
  PATCH_FUNC_ENTRY(CreateBrushIndirect)
  PATCH_FUNC_ENTRY(CreateCompatibleBitmap)
  PATCH_FUNC_ENTRY(CreateCompatibleDC)
  PATCH_FUNC_ENTRY(CreateDCA)
  PATCH_FUNC_ENTRY(CreateDCW)
  PATCH_FUNC_ENTRY(CreateDIBPatternBrush)
  PATCH_FUNC_ENTRY(CreateDIBPatternBrushPt)
  PATCH_FUNC_ENTRY(CreateDIBSection)
  PATCH_FUNC_ENTRY(CreateDIBitmap)
  PATCH_FUNC_ENTRY(CreateDiscardableBitmap)
  PATCH_FUNC_ENTRY(CreateEllipticRgn)
  PATCH_FUNC_ENTRY(CreateEllipticRgnIndirect)
  PATCH_FUNC_ENTRY(CreateEnhMetaFileA)
  PATCH_FUNC_ENTRY(CreateEnhMetaFileW)
  PATCH_FUNC_ENTRY(CreateFontA)
  PATCH_FUNC_ENTRY(CreateFontIndirectA)
  PATCH_FUNC_ENTRY(CreateFontIndirectW)
  PATCH_FUNC_ENTRY(CreateFontW)
  PATCH_FUNC_ENTRY(CreateHatchBrush)
  PATCH_FUNC_ENTRY(CreateMetaFileA)
  PATCH_FUNC_ENTRY(CreateMetaFileW)
  PATCH_FUNC_ENTRY(CreatePatternBrush)
  PATCH_FUNC_ENTRY(CreatePen)
  PATCH_FUNC_ENTRY(CreatePenIndirect)
  PATCH_FUNC_ENTRY(CreatePolyPolygonRgn)
  PATCH_FUNC_ENTRY(CreatePolygonRgn)
  PATCH_FUNC_ENTRY(CreateRectRgn)
  PATCH_FUNC_ENTRY(CreateRectRgnIndirect)
  PATCH_FUNC_ENTRY(CreateRoundRectRgn)
  PATCH_FUNC_ENTRY(CreateSolidBrush)
  PATCH_FUNC_ENTRY(DeleteDC)
  PATCH_FUNC_ENTRY(DeleteEnhMetaFile)
  PATCH_FUNC_ENTRY(DeleteMetaFile)
  PATCH_FUNC_ENTRY(DeleteObject)
  { 0 }
};
