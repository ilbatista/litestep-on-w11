#ifndef __GRD_FUNCTION_HOOKER_H__
#define __GRD_FUNCTION_HOOKER_H__

#include <windows.h>
#include <stdlib.h>
#include <tchar.h>
#include <vector>

#include "grdOSVersionInfo.h"

/***********************************************************************
 * This piece of code is a heavily modified version of something from
 * the lstransparent sources. lstransparent specifies :
 *
 * John Robbins - Microsoft Systems Journal Bugslayer Column
 *
 * As the original source of information. So for all parts of this who
 * actually work, thank John Robbins. And for all that don't work
 * blame me.
 ***********************************************************************
 */
class grdFunctionHooker {
public:
  // This descripes a certain function, that you want to hook...
  struct FuncDesc {
    // The module containing the function.
    HMODULE hModule;
    // The library which contains the function.
    TCHAR szLibraryName[256];
    // The name of the function to hook.
    TCHAR szFunctionName[256];
  };

  struct HookFunc {
    // Description of the function chosen for hooking
    FuncDesc fdDescription;
    // Procedure address of the replacement function
    PROC procReplacement;
    // Original procedure address...
    PROC procOriginal;
  };

  typedef std::vector<HookFunc> HFVector;

protected:
  grdOSVersionInfo osvi;
  HFVector functions;

public:
  grdFunctionHooker();
  ~grdFunctionHooker();

  HRESULT RerouteFunction(HookFunc *phf);
  HRESULT UnrouteFunction(HookFunc *phf);

protected:
  PIMAGE_IMPORT_DESCRIPTOR GetImportDescriptor(HMODULE hModule, LPCTSTR szLibraryName);
  HFVector::iterator grdFunctionHooker::FindIterator(HookFunc *phf);
};

#endif // !defined(__GRD_FUNCTION_HOOKER_H__)