#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "tracker.h"
#include "module.h"

ResTracker g_Tracker;


const char *ResTypeStrings[] =
{
  "resource",
  "PEN",
  "BRUSH",
  "DC",
  "METADC",
  "PAL",
  "FONT",
  "BITMAP",
  "REGION",
  "METAFILE",
  "MEMDC",
  "EXTPEN",
  "ENHMETADC",
  "ENHMETAFILE",
  "COLORSPACE",
};

const char *GetTypeString(int i)
{
  static char errbuf[26];
  if (i>(sizeof(ResTypeStrings)/sizeof(const char *)))
  {
    sprintf(errbuf,"(%d)",i);
    return errbuf;
  }
  else return ResTypeStrings[i];
}

const char *GetObjTypeString(HGDIOBJ h)
{
  static char errbuf[26];

  int i = GetObjectType(h);
  if (i!=0)
    return GetTypeString(i);

  /* try again */ 
  i = GetObjectType(h);
  if (i!=0)
    return GetTypeString(i);

  i = GetLastError();
  if (i==ERROR_SUCCESS)
    return "something";
  if (i==ERROR_INVALID_HANDLE)
    return "(invalid handle)";
  if (i==ERROR_ACCESS_DENIED)
    return "(access denied)";
  sprintf(errbuf,"(Error:%d)",i);
  return errbuf;
}

LPCTSTR DumpH(HANDLE h,DWORD type)
{
  static char b[256];
  static char data[256];
  int i = GetObjectType(h);
  int n;

  if (i==0) i = type;

  n = GetObject(h,256,NULL);
  GetObject(h,(n>256)?256:n,data);
  switch (i)
  {
  case OBJ_BITMAP:
    sprintf(b,"%s %08X (%dx%d)",GetTypeString(i),h,
      ((BITMAP*)data)->bmWidth,((BITMAP*)data)->bmHeight);
    break;
  case OBJ_PEN:
    if (n==sizeof(LOGPEN))
    {
      sprintf(b,"%s %08X (%d,#%06X)",
        GetTypeString(i),h,
        ((LOGPEN*)data)->lopnWidth,((LOGPEN*)data)->lopnColor);
    }
    else
    {
      sprintf(b,"%s %08X (%d,#%06X)",
        GetTypeString(i),h,
        ((EXTLOGPEN*)data)->elpWidth,((LOGPEN*)data)->lopnColor);
    }
    break;
  case OBJ_BRUSH:
    sprintf(b,"%s %08X (#%06X)",
      GetTypeString(i),h,
      ((LOGBRUSH*)data)->lbColor);
    break;
  case OBJ_FONT:
    sprintf(b,"%s %08X (%s %d)",
      GetTypeString(i),h,
      ((LOGFONT*)data)->lfFaceName,((LOGFONT*)data)->lfHeight);
    break;
  case OBJ_DC:
  case OBJ_MEMDC:
  case OBJ_METADC:
  case OBJ_ENHMETADC:
    {
      HANDLE bm = GetCurrentObject((HDC)h,OBJ_BITMAP);
      HANDLE br = GetCurrentObject((HDC)h,OBJ_BRUSH);
      HANDLE f = GetCurrentObject((HDC)h,OBJ_FONT);
      HANDLE p = GetCurrentObject((HDC)h,OBJ_PEN);
      sprintf(b,"%s %08X (bm:%08X,br:%08X,f:%08X,p:%08X)",
        GetTypeString(i),h,bm,br,f,p);
    }
    break;
  default:
    sprintf(b,"%s %08X",GetTypeString(i),h);
  }

  return b;
}

class _DumpLeaks
{
public:
  char buf[1024];

  void operator()(ResTracker::ResMap::value_type item)
  {
    sprintf(buf,"%s %08X created at %08X never deleted.",
      GetTypeString(item.second.ResType),item.first,item.second.Addr);
    item.second.Base->Trace(buf);
  }

  _DumpLeaks(void) { buf[0] = 0; }
};
class _CleanTrackers
{
public:
  void operator()(ModuleMap::value_type item)
  {
    delete item.second;
  }
};
void DumpAndCleanup(void)
{
  _DumpLeaks dlProc;
  _CleanTrackers ctProc;
  std::for_each(g_Tracker.ResList.begin(),g_Tracker.ResList.end(),dlProc);
  std::for_each(g_Modules.begin(),g_Modules.end(),ctProc);
}

