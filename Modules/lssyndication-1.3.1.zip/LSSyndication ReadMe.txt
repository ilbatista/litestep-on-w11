===============================================================================
LSSyndication.dll - LiteStepSyndication, created by Xjill (xjill.IV@gmail.com)
===============================================================================

Feature list:
=============
 +	Supports an unlimited number of RSS feeds (in theory, but currently limited to 200)
 +	Complies to the W3C XML 1.0 standards, and the RSS 2.0 standards (should also support
	RSS ver. 0.91 and 0.92, but not guaranteed)
 +	The only thing limiting how many items you can have is your system memory!
 +	You can customize what RSS elements you want to display
 +	Background images (with magicpink)
 +	Can check if there's been released a newer version of the module
 +	Doesn't update the news locally if the file on the server hasn't changed
 +	Has a MaxAge setting, removing all news older than the specified period (for the feeds
	which include the publication date)
 +	Can also gradiently colour your news according to age, or highlight newly published
	news.
 +	LSBox support
 +	Can strip HTML ( e.g. strip any text between < and > )
 +	You can customize what actions to perform on the various mouse events
 +	Click-and-drag scrolling, with loop function (loops to other edge of screen if you
 	drag through the edge of the screen)
+	Multiline support
 

What's ahead?
=============
This release (1.3) is most likely the last release I will do on this code base, as I know
feel I have all the features I would have. There are other features which have been
limited by the code architecture, but I'm now in the process of rewriting big parts of 
the code. Key features in progress are using another xml-parser than my own (most likely
eXpat), allowing for more fully use the features of the RSS standard; a stand-alone 
version, e.g. not dependant on LiteStep, though it will also be supplied as a LS module
(which I feel gives more control, through bang commands); open sourced (probably GPL); 
restructured code, taking into account portabillity for other OS and possible future
change in the LiteStep API.


Default button actions:
=======================
These are the default actions for the various mouse button events. You can customize the
actions by using the LssRssMButton*X* where *X* is the number 1-3 (left, right and middle
button respectively, see further info later in this readme). Please also not that one up
and one down action is executed before the double-click action

Left:	Single-click to open link of item under pointer.
Right:	Click-and-drag scrolling, double-click toggles the scrolling (identical to 
	!LssRssToggleScrolling)
Middle:	Single-click to jump from next source (identical to !LssRssNextSource)




Available Bang! Commands:
=========================
!LssRssUpdate			Re-fetches the news (Does not reload any .rc arguments)
!LssRssBoxHook			Let's LSBox hook LSSyndication (if hooked, you can't use the
				mouse wheel, as LSBox currently doesn't support this)

!LssRssAlwaysOnTop		Sets window to be topmost
!LssRssNormalZOrder		Sets the window to be non-topmost

!LssRssStopScrolling		Stops the scrolling of the news
!LssRssStartScrolling		Starts the scrolling
!LssRssToggleScrolling		Toggles the scrolling (right-clicking the window will also
				perform this)

!LssRssScroll	5		Scrolls the number of pixels you supply (can be negative)
!LssRssNextItem			Jumps forward one item
!LssRssPrevItem			Jumps backwards one item
!LssRssNextSource		Jumps forward to the beginning of the next source

!LssRssShow			Shows the module
!LssRssHide	[1]		Hides the module, optional argument to continue scrolling (use
					any non-zero value), otherwise it stops scrolling.
!LssRssToggle	[1]		Toggles the visibility of the module, same argument as !LssRssHide




Available .rc arguments:
========================

Adding a source:
----------------
*LssRssURL			"yourLinkToRssFileHere"		[10]
*LssRssURL			"anotherRssFile"		[5]

You can add as many entries like this as you want (though I have limited this to 200 sources
at the moment, if anybody feels this is too low, just send me an email). The number on the
end is an optional argument specifying the maximum number of items to display from this
source (this setting overrides the LssRssMaxItems setting).


Window visuals:
---------------
LssRssX				0		The position of the LSSyndication window on
						the X axis. A negative value is relative to
						the right of the screen, an ending 'C' from
						the center. To obtain true negative values
						use '~' in front.
						
LssRssY				0		Same as LssRssX, but for the Y axis instead.
LssRssWidth			1280		The width of the window
LssRssHeight			20		The height of the window

LssRssBackgroundColor		CC2222			The background color (in hex)
LssRssBackgroundImage		"FullPath\Image.png"	The background image (stretches if
							smaller than window)
							
LssRssAlwaysOnTop		If this is set the window will be above all other windows
LssRssTransparency		If defined then all parts of the background image that are
				MagicPink (#FF00FF) are transparent (fake transparency)
LssRssStartHidden		Allows the module to start hidden. To later display it, use
				the bang commands !LssRssShow or !LssRssToggle.


Text formatting:
----------------
LssRssMultiline			If defined the text will be shown in multiline and scroll
				vertically instead of horizontally
				
LssRssVAlign			Top		The vertical alignment of the text, can be
						either Top (default), Center or Bottom.

LssRssFontFace			"verdana"	The font to use (Defaults to "Arial")
LssRssFontSize			14		The size of the text
LssRssFontColor			FFFFFF		The color of the text
LssRssFontBold


Rss formatting:
---------------
LssRssDelimiter			" :: "		The delimiter between the different items
						(Default: " :: "), (if "" (empty), a single
						space is used)

LssRssTitleFormat		"-<title>: "	The data around the title. This is not used if
						LssRssNoDescriptions is defined! If only one
						argument supplied, it uses that on both sides.
						(Default: "<title>: "), can be empty ( "" )
						(equals "<title>")
						
LssRssNoDescriptions		If defined the <description> of an item is ignored (uses
				only the title)
				
LssRssStripHtml			If defined the module will strip everything in the data
				between < and >	brackets (including brackets defined in
				CDATA sections). This is meant to help remove HTML code
				but won't distinguish between real HTML and other uses
				of these brackets. There really shouldn't be HTML in RSS,
				but since some people still use it, I've included this.


Scroll settings:
----------------
LssRssNoDragScrollLoop		Define this to prevent the mouse cursor loop from one edge of
				the screen to another when drag-scrolling

LssRssScrollInterval		30		The scrolling update interval (in milliseconds).
						Default: 50

LssRssScrollSpeed		2		The number of pixels to move each scroll update.
						Default: 1


Other settings:
---------------
LssRssNoMessageBoxes		If this is set, no message boxes will pop up (you can still
				see the error messages in the LSSyndication window).

LssRssCheckForNewVersion	If this is set LSSyndication will check whether a new version
				of LSSyndication has been released. (If a new version is
				found this will pop up a message box regardless of
				LssRssNoMessageBoxes)

LssRssLoadingMessage		"Loading..."	If specified, this is what will be shown when
						loading the files, if not, the current status will
						be shown (like, "Connecting to <server>..." or
						"Processing File...").

LssRssNoDataMessage		"No items to show"	If specified this is what will be shown if
						there's no valid items to display.

LssRssUpdateInterval		0		The number of minutes to pass before to
						automatically update the news. Never updates
						automatically if set to 0 (which is the default).
						NOTE: Some sites (like slashdot.org) ban your IP
						if you update too often! (slashdot.org sets the
						limit to 30 min, but this can vary from site to
						site)

LssRssMaxAge			0		The maximum age of a news item in hours. Set to
						0 (default) to disable this feature.

LssRssMaxItems			0		The maximum number of items per URL (global number,
						also see *LssRssURL). Set to 0 for unlimited (Default)

LssRssUseProxy			If specified LSSyndication will connect to the server through the
				proxy specified in your Internet Explorer settings (read more below)


Customizing buttons:
--------------------
LssRssMButton1			[!UpAction;!DownAction;$DoubleClickAction$]

This setting allows you to define custom actions to perform on the various mouse events.
LssRssMButton1 is for the left button, 2 is for the right and 3 for the middle mouse button.

You can set the action to either:
	- A bang command
	- A path to an executable
	- .none or !none to specify that no action is to be performed
	- Leave it blank to perform the default action (which is hard-coded -> faster than
	  specifying the identical !bang command)
	- Use one of the escapes:
		* Use "%link" to execute the link of the item which is under the cursor.
		  This escape can also be used in combination with a bang or executable
		  (see examples below).
		* Use "%DragScroll" in the up and down action fields to assign this button
		  for click-and-drag scrolling. You should still supply a double-click
		  action for this button (i.e.. blank, .none, or an action), see examples
		  below.

Examples:
This example switches the default behavior of the right and middle mouse button:

LssRssMButton2			[.none;!LssRssNextSource;!none]
LssRssMButton3			[%DragScroll;%DragScroll;!LssRssToggleScrolling]

In the following example left-clicking opens with the default browser


Connecting through a proxy:
---------------------------
LSSyndication uses the manually set proxy address from your Internet Explorer settings. To
edit this address goto the IE menu "Tools" -> "Internet Options" -> "Connections" tab ->
"Settings..." (or "LAN Settings..." if connected over the LAN).



Known Issues:
=============
All version are released without any know issues, unfortunately I don't have the possibility to
test the module too much before some releases, so some issues might still exist. Please
report any issues you find! In the cases where the issue is hindering normal functionality
a quickfix is normally released as soon as I've got the problem sorted out.




Version History:
================
- 1.3:
*Now also works if no <title> tag in the item
*Added item highlighting by either single or gradient coloring
*Further fixed drag-scrolling on multi monitor systems (now also works with monitors left
 of the primary screen)
*Improved multiline support
  - .1:
	*Fixed default highlighting behaviour (now it doesn't highlight anything if not
	 LssRssHighlightAge is defined, or this is 0 or below.

- 1.2:
*Fixed problem with a solid-color background when position was non-zero
*Added multiline support
*Rewrote some old parts of the code to reduce CPU usage and make it less error-prone
*Fixed drag-scrolling on multi monitor systems
*Fixed it so that if a source now contains now valid items (all too old), the source title is not
 displayed either
*Added proxy support
*Added LssRssNoDataMessage

- 1.1:
*Fixed module sometimes crashing when trying to open more than one link at the same time
*Added LssRssMButton to allow specifying custom actions on mouse events
*Added click-and-drag scrolling functionality
*Added LssRssNoDragScrollLoop to disable looping functionality when using drag-scrolling
*Added !LssRssScroll to allow scrolling of specified number of pixels
*Added ability to customize the mouse button event actions (LssRssOnMButtonX)
*Fixed delimiter disappearing on recycle (bug since ver 1.0.1)
*Added LssRssFontBold
*Optimized some code, mainly with focus on CPU usage

- 1.0:
*Fixed bug when LssRssMaxAge where set to 0
*Added LssRssStartHidden
  - .1:
	*Added LssRssVAlign
	*Added LssRssStripHtml
	*Fixed the version checking, which were broken
	*Added optional argument for !LssRssHide and !LssRssToggle to keep scrolling when hidden
  - .2:
	*Fixed problem with certain sources when checking to see if the file is a valid RSS file
  - .3:
  	*Quickfix to sort the ugly businesses which made the module freeze when updating the news,
  	 sorry, my bad!

- b0.9:
*Added background images (with magic pink, though not real transparency)
*Fixed a problem with !LssRssNextSource when the first file wasn't valid
*Fixed the network code to use the "If-Modified-Since" header, so it won't update the local news if
 the file hasn't been modified. This feature eases the load on both the server and you! (For servers
 supporting this feature of course)
  - .1:
	*Quickfix for some bugs
  - .2:
	*Added LssRssMaxAge
	*Added support for ASCII numeral text escapes (like &#039; = ' ) and the most common HTML
	 escapes (like &quest; = ? )
  - .3:
	*Added LssRssCheckForNewVersion
	*Added !LssRssHide, !LssRssShow and !LssRssToggle
	*Added !LssRssNextItem and !LssRssPrevItem
	*Small performance and bug fixes
  - .4:
	*Bug fixes and tweaking
	*Changed LssRssX and LssRssY handling
	*Removed LssRssHugBottom
	*Added LssRssLoadingMessage
	*Added LSBox hook: !LssRssBoxHook


- b0.8:
*Fixed some things which gave (heavy) crashes
  - .1: *Fixed further crashes
  - .2: *Fixed some problems regarding libraries
	*Fixed LssRssMaxItems
	*Added !LssRssNextSource
	*Did some minor performance improvements

- b0.7:
Completely new network code, and some small fixes all around

- b0.6:
First release, don't know how many had it, probably none :D


------------------------------------------------------------

Please contact me (xjill.IV@gmail.com) if there's anything you would like improved or you find any bugs!

============================================================
Xjill
xjill.IV@gmail.com
============================================================
"Everything you perceive, is only the result of your abstraction of the movements of particles"

