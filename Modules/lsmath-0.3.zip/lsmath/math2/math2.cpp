#define WIN32_LEAN_AND_MEAN
#include <iostream>
#include <fstream>

#define DEBUGOUTPUT
#include "math2.h"


using namespace std;
/*
the most complex statement I have currently tested, it checks out just fine
(1-((3-3?1:10-4==1?1:5==5?3-3?1:10:50)))/2.3+1
(
1
-
(
(
3
-
3
?
1
:
10
-
4
==
1
?
1
:
5
==
5
?
3
-
3
?
1
:
10
:
50
)
)
)
/
2.3
+
1


(
(
(
?
 3
 3
-

 10
 4
-

?
modified 6
 1
==

?
 5
 5
==

?
 3
 3
-

:
)
)
)
 1
 10
-

modified -9
 2.3
/

modified -3.91304
 1
+

Answer is -2.91304
No error occurred


//*/
void main() {
	list<data> l;
	ifstream fin;
	data answer;
	string s,file;
	while (s!="quit") {
		getline(cin,s);cin.ignore();
		if (s=="help") {
			cout<<"commands\n--------\n\nfile - opens a file\nsave - saves a file\nhelp - prints this menu\n"
				<<"output - outputs the file\nquit - quits\nanything else is considered to be an equation and"
				<<" is attempted to be solved\n";
		} else if (s=="file") {
			cout<<"Enter filename: ";
			getline(cin,file);cin.ignore();
			readlist(file.c_str());
		} else if (s=="save") {
			savelist(file.c_str());
		} else if (s=="output") {
			ifstream fin(file.c_str());
			getline(fin,s);
			fin.ignore();
			while(fin) {
				cout<<s<<endl;
				getline(fin,s);
				fin.ignore();
			}
			fin.close();
		} else if (s!="quit") {
			l=tokenize(s);
			for (list<data>::const_iterator lci = l.begin(); lci!=l.end(); lci++) {
				if(lci->var!="") cout<<lci->var<<' ';
				if(lci->isop) cout<<tostr(lci->op)<<' '<<(lci->unary? "unary": " " )<<endl;
				else if (lci->isint) cout<<int(lci->value)<<endl;
				else cout<<double(lci->value)<<endl;
			}
			cout<<"\n\n";
			answer=equation(l);
			if(answer.isint) cout<<"Answer is "<<int(answer.value)<<endl;
			else cout<<"Answer is "<<answer.value<<endl;
			cout<<(equation.error ? "There was an error" : "No error occurred")<<endl;
		}
	}
}