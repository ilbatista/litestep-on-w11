//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#ifndef __BUTTONMGR_H
#define __BUTTONMGR_H

#include "Window.h"
class Button;

class ButtonMgr : public Window
{
public:
	ButtonMgr();
	virtual ~ButtonMgr();
	virtual void AlwaysOnTop(LPCTSTR pszName);
	virtual BOOL Create(HINSTANCE hinstModule);
	virtual void CreateButton(LPCTSTR pszName, HWND hwndParent = NULL);
	virtual void Destroy();
	virtual void DestroyButton(LPCTSTR pszName);
	virtual void Hide(LPCTSTR pszName);
	virtual void MoveBy(LPCTSTR pszName, int dx, int dy);
	virtual void MoveTo(LPCTSTR pszName, int x, int y);
	virtual void PinToDesktop(LPCTSTR pszName);
	virtual void ResizeBy(LPCTSTR pszName, int dx, int dy);
	virtual void ResizeTo(LPCTSTR pszName, int nWidth, int nHeight);
	virtual void SetAlpha(LPCTSTR pszName, int nAlpha);
	virtual void SetIcon(LPCTSTR pszName, LPCTSTR pszIcon, int nIconSize);
	virtual void SetText(LPCTSTR pszName, LPCTSTR pszText);
	virtual void SetToolTipText(LPCTSTR pszName, LPCTSTR pszToolTipText);
	virtual void Show(LPCTSTR pszName);
	virtual void Toggle(LPCTSTR pszName);
	virtual void ToggleAlwaysOnTop(LPCTSTR pszName);

private:
	HINSTANCE m_hinstModule;
	HWND m_hwndToolTips;
	Button **m_rgButtons;
	int m_cButtons;
	
	virtual void CreateButtons();
	virtual int FindButton(LPCTSTR pszName) const;
	virtual int OnGetRevID(LPTSTR pszBuffer);
	virtual LRESULT OnNotify(int idCtrl, LPNMHDR pnmh);
	virtual LRESULT WindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam);
};

#endif
