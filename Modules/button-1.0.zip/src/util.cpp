//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#include "common.h"

// Adds a backslash to a path if it doesn't already have one
void AddBackslash(LPTSTR pszPath, int cchBuffer)
{
	// FIXME: This implementation is not multibyte safe
	if (pszPath[StrLen(pszPath) - 1] != '\\')
	{
		StrCat(pszPath, cchBuffer, _T("\\"));
	}
}

// Returns TRUE if any mouse button flags are set
BOOL AnyButtonsDown(UINT fuFlags)
{
	return ((fuFlags & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON)) != 0);
}

// Converts an icon into a bitmap
HBITMAP ConvIconToBitmap(HICON hIcon, int nIconSize)
{
	HDC hdcScreen = GetDC(NULL);
	HDC hdcIcon = CreateCompatibleDC(hdcScreen);
	HBITMAP hbmIcon = CreateCompatibleBitmap(hdcScreen, nIconSize, nIconSize);
	hbmIcon = SelectBitmap(hdcIcon, hbmIcon);

	RECT rcIcon;

	HBRUSH hbrPink = CreateSolidBrush(RGB(255, 0, 255));
	SetRect(&rcIcon, 0, 0, nIconSize, nIconSize);
	FillRect(hdcIcon, &rcIcon, hbrPink);
	DeleteBrush(hbrPink);

	DrawIconEx(hdcIcon, 0, 0, hIcon, nIconSize, nIconSize, 0, NULL, DI_NORMAL);

	hbmIcon = SelectBitmap(hdcIcon, hbmIcon);
	DeleteDC(hdcIcon);
	ReleaseDC(NULL, hdcScreen);

	return hbmIcon;
}

// Creates a font using reasonable defaults for most parameters
HFONT CreateFontEZ(LPCTSTR pszName, int nHeight, BOOL fBold, BOOL fItalic, BOOL fUnderline)
{
	LOGFONT lf;

	lf.lfHeight = nHeight;
	lf.lfWidth = 0;
	lf.lfEscapement = 0;
	lf.lfOrientation = 0;
	lf.lfWeight = fBold ? FW_BOLD : FW_NORMAL;
	lf.lfItalic = fItalic;
	lf.lfUnderline = fUnderline;
	lf.lfStrikeOut = FALSE;
	lf.lfCharSet = DEFAULT_CHARSET;
	lf.lfOutPrecision = OUT_DEFAULT_PRECIS;
	lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
	lf.lfQuality = DEFAULT_QUALITY;
	lf.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;

	StrCopy(lf.lfFaceName, LF_FACESIZE, pszName);
	return CreateFontIndirect(&lf);
}

// Retrieves the size of a bitmap
void GetImageSize(HBITMAP hbmImage, LPINT pnWidth, LPINT pnHeight)
{
	if (hbmImage)
	{
		BITMAP bm;
		GetObject(hbmImage, sizeof(BITMAP), &bm);

		*pnWidth = bm.bmWidth;
		*pnHeight = bm.bmHeight;
	}
}

// Returns a handle to the shell's desktop window
HWND GetShellDesktopWindow()
{
	HWND hwndDesktop = FindWindow(_T("DesktopBackgroundClass"), NULL);

	if (!hwndDesktop)
	{
		hwndDesktop = GetDesktopWindow();
	}

	return hwndDesktop;
}

// Loads an icon file
HICON LoadIcon(LPCTSTR pszFile, int nIconSize)
{
	// Try the path as is
	HICON hIcon = (HICON) LoadImage(NULL, pszFile, IMAGE_ICON, nIconSize, nIconSize, LR_LOADFROMFILE);

	if (!hIcon)
	{
		// If that fails, add LS image path to it
		TCHAR szPath[MAX_PATH];

		LSGetImagePath(szPath, MAX_PATH);
		AddBackslash(szPath, MAX_PATH);
		StrCat(szPath, MAX_PATH, pszFile);
		hIcon = (HICON) LoadImage(NULL, pszFile, IMAGE_ICON, nIconSize, nIconSize, LR_LOADFROMFILE);
	}

	return hIcon;
}

// Loads a bitmap file or an icon file
HBITMAP LoadImageOrIcon(LPCTSTR pszFile, int nIconSize, LPINT pnWidth, LPINT pnHeight)
{
	// Try to load it as a bitmap first
	HBITMAP hbmImage = LoadLSImage(pszFile, NULL);

	if (!hbmImage)
	{
		// If that fails, try it as an icon
		HICON hIcon = LoadIcon(pszFile, nIconSize);

		if (hIcon)
		{
			// and then convert it into an bitmap
			hbmImage = ConvIconToBitmap(hIcon, nIconSize);
			DestroyIcon(hIcon);
		}
	}

	GetImageSize(hbmImage, pnWidth, pnHeight);
	return hbmImage;
}

#ifndef WS_EX_LAYERED
#define LWA_ALPHA 2
#define WS_EX_LAYERED 0x80000
#endif

typedef BOOL (WINAPI *PFN_SETLAYEREDWINDOWATTRIBUTES)(HWND, COLORREF, BYTE, DWORD);

// Sets the opacity (alpha channel) of a window
BOOL SetWindowAlpha(HWND hWnd, int nAlpha)
{
	HINSTANCE hinstUser = LoadLibrary(_T("USER32.DLL"));
	PFN_SETLAYEREDWINDOWATTRIBUTES pfnSetLayeredWindowAttributes = (PFN_SETLAYEREDWINDOWATTRIBUTES) GetProcAddress(hinstUser, _T("SetLayeredWindowAttributes"));
	BOOL fResult = FALSE;

	if (pfnSetLayeredWindowAttributes)
	{
		if (nAlpha >= 0)
		{
			// Enable transparency and set the alpha level
			SetWindowLong(hWnd, GWL_EXSTYLE, GetWindowLong(hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
			fResult = (*pfnSetLayeredWindowAttributes)(hWnd, 0, (BYTE) nAlpha, LWA_ALPHA);
		}
		else
		{
			// Disable transparency
			SetWindowLong(hWnd, GWL_EXSTYLE, GetWindowLong(hWnd, GWL_EXSTYLE) & ~WS_EX_LAYERED);
			fResult = RedrawWindow(hWnd, NULL, NULL, RDW_ALLCHILDREN | RDW_ERASE | RDW_FRAME | RDW_INVALIDATE);
		}
	}

	FreeLibrary(hinstUser);
	return fResult;
}
