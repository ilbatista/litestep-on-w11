//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#include "common.h"
#include "ButtonMgr.h"

void BangAlwaysOnTop(HWND hwndCaller, LPCTSTR pszArgs);
void BangCreate(HWND hwndCaller, LPCTSTR pszArgs);
void BangDestroy(HWND hwndCaller, LPCTSTR pszArgs);
void BangHide(HWND hwndCaller, LPCTSTR pszArgs);
void BangLSBoxHook(HWND hwndCaller, LPCTSTR pszArgs);
void BangMoveBy(HWND hwndCaller, LPCTSTR pszArgs);
void BangMoveTo(HWND hwndCaller, LPCTSTR pszArgs);
void BangPinToDesktop(HWND hwndCaller, LPCTSTR pszArgs);
void BangResizeBy(HWND hwndCaller, LPCTSTR pszArgs);
void BangResizeTo(HWND hwndCaller, LPCTSTR pszArgs);
void BangSetAlpha(HWND hwndCaller, LPCTSTR pszArgs);
void BangSetIcon(HWND hwndCaller, LPCTSTR pszArgs);
void BangSetText(HWND hwndCaller, LPCTSTR pszArgs);
void BangSetToolTipText(HWND hwndCaller, LPCTSTR pszArgs);
void BangShow(HWND hwndCaller, LPCTSTR pszArgs);
void BangToggle(HWND hwndCaller, LPCTSTR pszArgs);
void BangToggleAlwaysOnTop(HWND hwndCaller, LPCTSTR pszArgs);

ButtonMgr *g_pButtonMgr;

//----------------------------------------------------------------------------
// initModuleEx
//----------------------------------------------------------------------------

int
initModuleEx(HWND hwndParent, HINSTANCE hInstance, LPCTSTR pszPath)
{
	InitCommonControls();

	if (g_pButtonMgr)
	{
		return 1;
	}
	
	g_pButtonMgr = new ButtonMgr;
	
	if (!g_pButtonMgr->Create(hInstance))
	{
		delete g_pButtonMgr;
		g_pButtonMgr = NULL;
		return 1;
	}
	
	AddBangCommand(_T("!ButtonAlwaysOnTop"), BangAlwaysOnTop);
	AddBangCommand(_T("!ButtonCreate"), BangCreate);
	AddBangCommand(_T("!ButtonDestroy"), BangDestroy);
	AddBangCommand(_T("!ButtonHide"), BangHide);
	AddBangCommand(_T("!ButtonLSBoxHook"), BangLSBoxHook);
	AddBangCommand(_T("!ButtonMoveBy"), BangMoveBy);
	AddBangCommand(_T("!ButtonMoveTo"), BangMoveTo);
	AddBangCommand(_T("!ButtonPinToDesktop"), BangPinToDesktop);
	AddBangCommand(_T("!ButtonResizeBy"), BangResizeBy);
	AddBangCommand(_T("!ButtonResizeTo"), BangResizeTo);
	AddBangCommand(_T("!ButtonSetAlpha"), BangSetAlpha);
	AddBangCommand(_T("!ButtonSetIcon"), BangSetIcon);
	AddBangCommand(_T("!ButtonSetText"), BangSetText);
	AddBangCommand(_T("!ButtonSetToolTipText"), BangSetToolTipText);
	AddBangCommand(_T("!ButtonShow"), BangShow);
	AddBangCommand(_T("!ButtonToggle"), BangToggle);
	AddBangCommand(_T("!ButtonToggleAlwaysOnTop"), BangToggleAlwaysOnTop);
	
	return 0;
}

//----------------------------------------------------------------------------
// quitModule
//----------------------------------------------------------------------------

void
quitModule(HINSTANCE hInstance)
{
	if (!g_pButtonMgr)
	{
		return;
	}
	
	RemoveBangCommand(_T("!ButtonAlwaysOnTop"));
	RemoveBangCommand(_T("!ButtonCreate"));
	RemoveBangCommand(_T("!ButtonDestroy"));
	RemoveBangCommand(_T("!ButtonHide"));
	RemoveBangCommand(_T("!ButtonLSBoxHook"));
	RemoveBangCommand(_T("!ButtonMoveBy"));
	RemoveBangCommand(_T("!ButtonMoveTo"));
	RemoveBangCommand(_T("!ButtonPinToDesktop"));
	RemoveBangCommand(_T("!ButtonResizeBy"));
	RemoveBangCommand(_T("!ButtonResizeTo"));
	RemoveBangCommand(_T("!ButtonSetAlpha"));
	RemoveBangCommand(_T("!ButtonSetIcon"));
	RemoveBangCommand(_T("!ButtonSetText"));
	RemoveBangCommand(_T("!ButtonSetToolTipText"));
	RemoveBangCommand(_T("!ButtonShow"));
	RemoveBangCommand(_T("!ButtonToggle"));
	RemoveBangCommand(_T("!ButtonToggleAlwaysOnTop"));
	
	g_pButtonMgr->Destroy();
	delete g_pButtonMgr;
	g_pButtonMgr = NULL;
	
	UnregisterClass(WC_LSBUTTON, hInstance);
}

//----------------------------------------------------------------------------
// BangAlwaysOnTop
//----------------------------------------------------------------------------

void
BangAlwaysOnTop(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	LPTSTR aszBuffers[1];
	int cTokens;

	aszBuffers[0] = szName;

	cTokens = LCTokenize(pszArgs, aszBuffers, 1, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->AlwaysOnTop(szName);
	}
}

//----------------------------------------------------------------------------
// BangCreate
//----------------------------------------------------------------------------

void
BangCreate(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	LPTSTR aszBuffers[1];
	int cTokens;

	aszBuffers[0] = szName;

	cTokens = LCTokenize(pszArgs, aszBuffers, 1, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->CreateButton(szName);
	}
}

//----------------------------------------------------------------------------
// BangDestroy
//----------------------------------------------------------------------------

void
BangDestroy(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	LPTSTR aszBuffers[1];
	int cTokens;

	aszBuffers[0] = szName;

	cTokens = LCTokenize(pszArgs, aszBuffers, 1, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->DestroyButton(szName);
	}
}

//----------------------------------------------------------------------------
// BangHide
//----------------------------------------------------------------------------

void
BangHide(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	LPTSTR aszBuffers[1];
	int cTokens;

	aszBuffers[0] = szName;

	cTokens = LCTokenize(pszArgs, aszBuffers, 1, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->Hide(szName);
	}
}

//----------------------------------------------------------------------------
// BangLSBoxHook
//----------------------------------------------------------------------------

void
BangLSBoxHook(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	TCHAR szHandle[MAX_STRINT];
	LPTSTR aszBuffers[2];
	int cTokens;

	aszBuffers[0] = szName;
	aszBuffers[1] = szHandle;

	cTokens = LCTokenize(pszArgs, aszBuffers, 1, NULL);

	if (cTokens >= 2)
	{
		g_pButtonMgr->CreateButton(szName, (HWND) _ttoi(szHandle));
	}
}

//----------------------------------------------------------------------------
// BangMoveBy
//----------------------------------------------------------------------------

void
BangMoveBy(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	TCHAR szX[MAX_STRINT];
	TCHAR szY[MAX_STRINT];
	LPTSTR aszBuffers[3];
	int cTokens;

	aszBuffers[0] = szName;
	aszBuffers[1] = szX;
	aszBuffers[2] = szY;

	cTokens = LCTokenize(pszArgs, aszBuffers, 3, NULL);

	if (cTokens >= 3)
	{
		g_pButtonMgr->MoveBy(szName, _ttoi(szX), _ttoi(szY));
	}
}

//----------------------------------------------------------------------------
// BangMoveTo
//----------------------------------------------------------------------------

void
BangMoveTo(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	TCHAR szX[MAX_STRINT];
	TCHAR szY[MAX_STRINT];
	LPTSTR aszBuffers[3];
	int cTokens;

	aszBuffers[0] = szName;
	aszBuffers[1] = szX;
	aszBuffers[2] = szY;

	cTokens = LCTokenize(pszArgs, aszBuffers, 3, NULL);

	if (cTokens >= 3)
	{
		g_pButtonMgr->MoveTo(szName, _ttoi(szX), _ttoi(szY));
	}
}

//----------------------------------------------------------------------------
// BangPinToDesktop
//----------------------------------------------------------------------------

void
BangPinToDesktop(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	LPTSTR aszBuffers[1];
	int cTokens;

	aszBuffers[0] = szName;

	cTokens = LCTokenize(pszArgs, aszBuffers, 1, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->PinToDesktop(szName);
	}
}

//----------------------------------------------------------------------------
// BangResizeBy
//----------------------------------------------------------------------------

void
BangResizeBy(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	TCHAR szX[MAX_STRINT];
	TCHAR szY[MAX_STRINT];
	LPTSTR aszBuffers[3];
	int cTokens;

	aszBuffers[0] = szName;
	aszBuffers[1] = szX;
	aszBuffers[2] = szY;

	cTokens = LCTokenize(pszArgs, aszBuffers, 3, NULL);

	if (cTokens >= 3)
	{
		g_pButtonMgr->ResizeBy(szName, _ttoi(szX), _ttoi(szY));
	}
}

//----------------------------------------------------------------------------
// BangResizeTo
//----------------------------------------------------------------------------

void
BangResizeTo(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	TCHAR szX[MAX_STRINT];
	TCHAR szY[MAX_STRINT];
	LPTSTR aszBuffers[3];
	int cTokens;

	aszBuffers[0] = szName;
	aszBuffers[1] = szX;
	aszBuffers[2] = szY;

	cTokens = LCTokenize(pszArgs, aszBuffers, 3, NULL);

	if (cTokens >= 3)
	{
		g_pButtonMgr->ResizeTo(szName, _ttoi(szX), _ttoi(szY));
	}
}

//----------------------------------------------------------------------------
// BangSetAlpha
//----------------------------------------------------------------------------

void
BangSetAlpha(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	TCHAR szAlpha[MAX_STRINT];
	LPTSTR aszBuffers[2];
	int cTokens;

	aszBuffers[0] = szName;
	aszBuffers[1] = szAlpha;

	cTokens = LCTokenize(pszArgs, aszBuffers, 2, NULL);

	if (cTokens >= 2)
	{
		g_pButtonMgr->SetAlpha(szName, _ttoi(szAlpha));
	}
}

//----------------------------------------------------------------------------
// BangSetIcon
//----------------------------------------------------------------------------

void
BangSetIcon(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	TCHAR szIcon[MAX_PATH];
	TCHAR szIconSize[MAX_STRINT];
	LPTSTR aszBuffers[3];
	int cTokens;

	aszBuffers[0] = szName;
	aszBuffers[1] = szIcon;
	aszBuffers[2] = szIconSize;

	cTokens = LCTokenize(pszArgs, aszBuffers, 3, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->SetIcon(szName, (cTokens >= 2) ? szIcon : NULL, (cTokens >= 3) ? _ttoi(szIconSize) : 0);
	}
}

//----------------------------------------------------------------------------
// BangSetText
//----------------------------------------------------------------------------

void
BangSetText(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	TCHAR szText[MAX_TOOLTIPTEXT];
	LPTSTR aszBuffers[2];
	int cTokens;

	aszBuffers[0] = szName;
	aszBuffers[1] = szText;

	cTokens = LCTokenize(pszArgs, aszBuffers, 2, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->SetText(szName, (cTokens >= 2) ? szText : NULL);
	}
}

//----------------------------------------------------------------------------
// BangSetToolTipText
//----------------------------------------------------------------------------

void
BangSetToolTipText(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	TCHAR szToolTipText[MAX_TOOLTIPTEXT];
	LPTSTR aszBuffers[2];
	int cTokens;

	aszBuffers[0] = szName;
	aszBuffers[1] = szToolTipText;

	cTokens = LCTokenize(pszArgs, aszBuffers, 2, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->SetToolTipText(szName, (cTokens >= 2) ? szToolTipText : NULL);
	}
}

//----------------------------------------------------------------------------
// BangShow
//----------------------------------------------------------------------------

void
BangShow(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	LPTSTR aszBuffers[1];
	int cTokens;

	aszBuffers[0] = szName;

	cTokens = LCTokenize(pszArgs, aszBuffers, 1, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->Show(szName);
	}
}

//----------------------------------------------------------------------------
// BangToggle
//----------------------------------------------------------------------------

void
BangToggle(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	LPTSTR aszBuffers[1];
	int cTokens;

	aszBuffers[0] = szName;

	cTokens = LCTokenize(pszArgs, aszBuffers, 1, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->Toggle(szName);
	}
}

//----------------------------------------------------------------------------
// BangToggleAlwaysOnTop
//----------------------------------------------------------------------------

void
BangToggleAlwaysOnTop(HWND hwndCaller, LPCTSTR pszArgs)
{
	TCHAR szName[MAX_NAME];
	LPTSTR aszBuffers[1];
	int cTokens;

	aszBuffers[0] = szName;

	cTokens = LCTokenize(pszArgs, aszBuffers, 1, NULL);

	if (cTokens >= 1)
	{
		g_pButtonMgr->ToggleAlwaysOnTop(szName);
	}
}
