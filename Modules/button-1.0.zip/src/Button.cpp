//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#include "common.h"
#include "Button.h"
#include "Window.h"

ENUM g_enumAlign[] = {
	{ _T("Left"), ALIGN_LEFT },
	{ _T("Center"), ALIGN_CENTER },
	{ _T("Right"), ALIGN_RIGHT },
	{ NULL, 0 }
};

ENUM g_enumIconPosition[] = {
	{ _T("Left"), ICON_POSITION_LEFT },
	{ _T("Top"), ICON_POSITION_TOP },
	{ _T("Right"), ICON_POSITION_RIGHT },
	{ _T("Bottom"), ICON_POSITION_BOTTOM },
	{ NULL, 0 }
};

ENUM g_enumSkinMode[] = {
	{ _T("Stretch"), SCALE_STRETCH },
	{ _T("Tile"), SCALE_TILE },
	{ _T("HorizontalTile"), SCALE_HORIZONTALTILE },
	{ _T("VerticalTile"), SCALE_VERTICALTILE },
	{ NULL, 0 }
};

ENUM g_enumVertAlign[] = {
	{ _T("Top"), ALIGN_TOP },
	{ _T("Center"), ALIGN_CENTER },
	{ _T("Bottom"), ALIGN_BOTTOM },
	{ NULL, 0 }
};

int Button::m_cInstances = 0;

//----------------------------------------------------------------------------
// Constructor
//----------------------------------------------------------------------------

Button::Button(LPCTSTR pszName)
{
	m_pszName = StrAlloc(pszName);
	m_hbmIcon = NULL;
	m_pszText = NULL;
	m_pszToolTipText = NULL;

	m_hfnFont = NULL;
	m_hfnPressedFont = NULL;
	m_hfnHoverFont = NULL;
	m_hbmOrigSkin = NULL;
	m_hbmOrigPressedSkin = NULL;
	m_hbmOrigHoverSkin = NULL;
	m_hbmSkin = NULL;
	m_hbmPressedSkin = NULL;
	m_hbmHoverSkin = NULL;
	m_hrgnSkin = NULL;
	m_hrgnPressedSkin = NULL;
	m_hrgnHoverSkin = NULL;

	m_pszOnEnter = NULL;
	m_pszOnLeave = NULL;
	m_pszOnLeftClick = NULL;
	m_pszOnLeftDoubleClick = NULL;
	m_pszOnMiddleClick = NULL;
	m_pszOnMiddleDoubleClick = NULL;
	m_pszOnRightClick = NULL;
	m_pszOnRightDoubleClick = NULL;

	m_nState = STATE_NORMAL;
	m_fMouseDown = FALSE;
	m_fMouseInside = FALSE;
}

//----------------------------------------------------------------------------
// Destructor
//----------------------------------------------------------------------------

Button::~Button()
{
	StrFree(m_pszName);
	StrFree(m_pszText);
	StrFree(m_pszToolTipText);

	StrFree(m_pszOnEnter);
	StrFree(m_pszOnLeave);
	StrFree(m_pszOnLeftClick);
	StrFree(m_pszOnLeftDoubleClick);
	StrFree(m_pszOnMiddleClick);
	StrFree(m_pszOnMiddleDoubleClick);
	StrFree(m_pszOnRightClick);
	StrFree(m_pszOnRightDoubleClick);
}

//----------------------------------------------------------------------------
// AlwaysOnTop
//----------------------------------------------------------------------------

void
Button::AlwaysOnTop()
{
	SetAlwaysOnTop(TRUE);
}

//----------------------------------------------------------------------------
// ChangeState
//----------------------------------------------------------------------------

void
Button::ChangeState(int nState)
{
	// Set the state
	m_nState = nState;

	// Set the window region
	HRGN hrgnSkin = GetCurrentSkinRegion();
	HRGN hrgnWindow = CreateRectRgn(0, 0, m_nWidth, m_nHeight);

	if (hrgnSkin)
	{
		CopyRgn(hrgnWindow, hrgnSkin);
	}

	SetWindowRgn(m_hWnd, hrgnWindow, FALSE);

	// Update layout and repaint
	DoLayout();
}

//----------------------------------------------------------------------------
// Create
//----------------------------------------------------------------------------

BOOL
Button::Create(HINSTANCE hinstModule, HWND hwndParent)
{
	ReadConfig();
	
	m_hinstModule = hinstModule;
	m_hwndParent = hwndParent;
	
	if (++m_cInstances == 1)
	{
		// First instance registers the window class
		WNDCLASSEX wc;
		
		wc.cbSize = sizeof(WNDCLASSEX);
		wc.style = CS_DBLCLKS | CS_GLOBALCLASS;
		wc.lpfnWndProc = ExternalWindowProc;
		wc.cbClsExtra = 0;
		wc.cbWndExtra = sizeof(Window *);
		wc.hInstance = m_hinstModule;
		wc.hIcon = NULL;
		wc.hCursor = LoadCursor(NULL, IDC_ARROW);
		wc.hbrBackground = NULL;
		wc.lpszMenuName = NULL;
		wc.lpszClassName = WC_LSBUTTON;
		wc.hIconSm = NULL;
		
		RegisterClassEx(&wc);
	}
	
	m_hWnd = CreateWindowEx(WS_EX_TOOLWINDOW, WC_LSBUTTON, NULL, WS_POPUP,
		m_x, m_y, m_nWidth, m_nHeight,
		m_hwndParent ? m_hwndParent : GetLitestepWnd(), NULL,
		m_hinstModule, this);

	if (!m_hWnd)
	{
		if (--m_cInstances == 0)
		{
			// If window creation failed and there are no other instances, unregister the window class
			UnregisterClass(WC_LSBUTTON, m_hinstModule);
		}

		return FALSE;
	}
	
	if (!m_hwndParent)
	{
		SetAlwaysOnTop(m_fAlwaysOnTop);
		SetWindowLong(m_hWnd, GWL_USERDATA, 0x49474541);
	}
	
	SetAlpha(m_nAlpha);

	if (m_fVisible)
	{
		Show();
	}
	
	return TRUE;
}

//----------------------------------------------------------------------------
// Destroy
//----------------------------------------------------------------------------

void
Button::Destroy()
{
	if (m_hWnd)
	{
		DestroyWindow(m_hWnd);
		m_hWnd = NULL;
		
		if (--m_cInstances == 0)
		{
			// Last instance unregisters the window class
			UnregisterClass(WC_LSBUTTON, m_hinstModule);
		}
	}
}

//----------------------------------------------------------------------------
// DoLayout
//----------------------------------------------------------------------------

void
Button::DoLayout()
{
	// Figure out how much space we have to work with
	int cxAvail = m_nWidth - m_nLeftBorder - m_nRightBorder;
	int cyAvail = m_nHeight - m_nTopBorder - m_nBottomBorder;

	// Compute the size of the icon
	int cxIcon = 0;
	int cyIcon = 0;

	if (m_hbmIcon)
	{
		cxIcon = m_cxIcon;
		cyIcon = m_cyIcon;
	}

	// Compute the amount of space between the icon and text
	int nGap = 0;

	if (m_hbmIcon && m_pszText)
	{
		nGap = m_nIconTextGap;
	}

	// Compute the size of the text
	int cxText = 0;
	int cyText = 0;

	if (m_pszText)
	{
	    HDC hDC = GetDC(m_hWnd);
		HFONT hfnPrevFont = SelectFont(hDC, GetCurrentFont());

		SIZE s;
		GetTextExtentPoint32(hDC, m_pszText, StrLen(m_pszText), &s);

		SelectFont(hDC, hfnPrevFont);
		ReleaseDC(m_hWnd, hDC);

		cxText = s.cx;
		cyText = s.cy;
	}

	// Compute the size of the content area (icon and text)
	int cxContent = 0;
	int cyContent = 0;

	if (m_nIconPosition == ICON_POSITION_LEFT || m_nIconPosition == ICON_POSITION_RIGHT)
	{
		cxContent = cxIcon + nGap + cxText;
		cyContent = max(cyIcon, cyText);
	}
	else
	{
		cxContent = max(cxIcon, cxText);
		cyContent = cyIcon + nGap + cyText;
	}

	// Align it horizontally
	int xContent;

	switch (m_nAlign)
	{
	case ALIGN_LEFT:
		xContent = m_nLeftBorder;
		break;

	case ALIGN_CENTER:
		xContent = m_nLeftBorder + (cxAvail - cxContent) / 2;
		break;

	case ALIGN_RIGHT:
		xContent = m_nLeftBorder + (cxAvail - cxContent);
		break;
	}

	// Align it vertically
	int yContent;

	switch (m_nVertAlign)
	{
	case ALIGN_TOP:
		yContent = m_nTopBorder;
		break;

	case ALIGN_CENTER:
		yContent = m_nTopBorder + (cyAvail - cyContent) / 2;
		break;

	case ALIGN_RIGHT:
		yContent = m_nTopBorder + (cyAvail - cyContent);
		break;
	}

	// Place the icon and text
	switch (m_nIconPosition)
	{
	case ICON_POSITION_LEFT:
		m_xIcon = xContent;
		m_yIcon = yContent + (cyContent - cyIcon) / 2;
		m_xText = xContent + cxIcon + nGap;
		m_yText = yContent + (cyContent - cyText) / 2;
		break;

	case ICON_POSITION_TOP:
		m_xIcon = xContent + (cxContent - cxIcon) / 2;
		m_yIcon = yContent;
		m_xText = xContent + (cxContent - cxText) / 2;
		m_yText = yContent + cyIcon + nGap;
		break;

	case ICON_POSITION_RIGHT:
		m_xIcon = xContent + cxText + nGap;
		m_yIcon = yContent + (cyContent - cyIcon) / 2;
		m_xText = xContent;
		m_yText = yContent + (cyContent - cyText) / 2;
		break;

	case ICON_POSITION_BOTTOM:
		m_xIcon = xContent + (cxContent - cxIcon) / 2;
		m_yIcon = yContent + cyText + nGap;
		m_xText = xContent + (cxContent - cxText) / 2;
		m_yText = yContent;
		break;
	}

	// Adjust position based on state
	int dx = 0;
	int dy = 0;

	switch (m_nState)
	{
	case STATE_PRESSED:
		dx = m_nPressedOffsetX;
		dy = m_nPressedOffsetY;
		break;

	case STATE_HOVER:
		dx = m_nHoverOffsetX;
		dy = m_nHoverOffsetY;
		break;
	}

	m_xIcon = m_xIcon + dx;
	m_yIcon = m_yIcon + dy;
	m_xText = m_xText + dx;
	m_yText = m_yText + dy;

	// Repaint with new layout
	InvalidateRect(m_hWnd, NULL, FALSE);
}

//----------------------------------------------------------------------------
// GetConfigBoolean
//----------------------------------------------------------------------------

BOOL
Button::GetConfigBoolean(LPCTSTR pszKey, BOOL fDefault)
{
	TCHAR szFullKey[MAX_KEY];
	StrPrintf(szFullKey, MAX_KEY, _T("%s%s"), m_pszName ? m_pszName : _T(""), pszKey ? pszKey : _T(""));
	return GetRCBoolDef(szFullKey, fDefault);
}

//----------------------------------------------------------------------------
// GetConfigColor
//----------------------------------------------------------------------------

COLORREF
Button::GetConfigColor(LPCTSTR pszKey, COLORREF crDefault)
{
	TCHAR szFullKey[MAX_KEY];
	StrPrintf(szFullKey, MAX_KEY, _T("%s%s"), m_pszName ? m_pszName : _T(""), pszKey ? pszKey : _T(""));
	return GetRCColor(szFullKey, crDefault);
}

//----------------------------------------------------------------------------
// GetConfigEnum
//----------------------------------------------------------------------------

int
Button::GetConfigEnum(LPCTSTR pszKey, LPENUM pEnum, int nDefault)
{
	LPTSTR pszValue = GetConfigString(pszKey);

	while (pEnum && pEnum->pszName)
	{
		if (StrCompareIgnoreCase(pEnum->pszName, pszValue) == 0)
		{
			StrFree(pszValue);
			return pEnum->nValue;
		}

		pEnum++;
	}

	StrFree(pszValue);
	return nDefault;
}

//----------------------------------------------------------------------------
// GetConfigImage
//----------------------------------------------------------------------------

HBITMAP
Button::GetConfigImage(LPCTSTR pszKey, LPINT pnWidth, LPINT pnHeight)
{
	LPTSTR pszPath = GetConfigString(pszKey);
	HBITMAP hbmImage = NULL;

	if (pszPath)
	{
		hbmImage = LoadLSImage(pszPath, NULL);
		StrFree(pszPath);
	}

	GetImageSize(hbmImage, pnWidth, pnHeight);
	return hbmImage;
}

//----------------------------------------------------------------------------
// GetConfigImageOrIcon
//----------------------------------------------------------------------------

HBITMAP
Button::GetConfigImageOrIcon(LPCTSTR pszKey, int nIconSize, LPINT pnWidth, LPINT pnHeight)
{
	LPTSTR pszPath = GetConfigString(pszKey);
	HBITMAP hbmImage = NULL;

	if (pszPath)
	{
		hbmImage = LoadImageOrIcon(pszPath, nIconSize, pnWidth, pnHeight);
		StrFree(pszPath);
	}

	return hbmImage;
}

//----------------------------------------------------------------------------
// GetConfigInt
//----------------------------------------------------------------------------

int
Button::GetConfigInt(LPCTSTR pszKey, int nDefault)
{
	TCHAR szFullKey[MAX_KEY];
	StrPrintf(szFullKey, MAX_KEY, _T("%s%s"), m_pszName ? m_pszName : _T(""), pszKey ? pszKey : _T(""));
	return GetRCInt(szFullKey, nDefault);
}

//----------------------------------------------------------------------------
// GetConfigLine
//----------------------------------------------------------------------------

LPTSTR
Button::GetConfigLine(LPCTSTR pszKey, LPCTSTR pszDefault)
{
	TCHAR szFullKey[MAX_KEY];
	StrPrintf(szFullKey, MAX_KEY, _T("%s%s"), m_pszName ? m_pszName : _T(""), pszKey ? pszKey : _T(""));

	TCHAR szBuffer[MAX_STRRESULT];
	GetRCLine(szFullKey, szBuffer, MAX_STRRESULT, pszDefault);
	return StrAlloc(szBuffer);
}

//----------------------------------------------------------------------------
// GetConfigString
//----------------------------------------------------------------------------

LPTSTR
Button::GetConfigString(LPCTSTR pszKey, LPCTSTR pszDefault)
{
	TCHAR szFullKey[MAX_KEY];
	StrPrintf(szFullKey, MAX_KEY, _T("%s%s"), m_pszName ? m_pszName : _T(""), pszKey ? pszKey : _T(""));

	TCHAR szBuffer[MAX_STRRESULT];
	GetRCString(szFullKey, szBuffer, pszDefault, MAX_STRRESULT);
	return StrAlloc(szBuffer);
}

//----------------------------------------------------------------------------
// GetCurrentFont
//----------------------------------------------------------------------------

HFONT
Button::GetCurrentFont() const
{
	switch (m_nState)
	{
	case STATE_NORMAL:
		return m_hfnFont;

	case STATE_PRESSED:
		return m_hfnPressedFont;

	case STATE_HOVER:
		return m_hfnHoverFont;
	}

	return NULL;
}

//----------------------------------------------------------------------------
// GetCurrentSkin
//----------------------------------------------------------------------------

HBITMAP
Button::GetCurrentSkin() const
{
	if (m_nState == STATE_PRESSED && m_hbmPressedSkin)
	{
		return m_hbmPressedSkin;
	}
	else if (m_nState == STATE_HOVER && m_hbmHoverSkin)
	{
		return m_hbmHoverSkin;
	}
	else
	{
		return m_hbmSkin;
	}
}

//----------------------------------------------------------------------------
// GetCurrentSkinRegion
//----------------------------------------------------------------------------

HRGN
Button::GetCurrentSkinRegion() const
{
	if (m_nState == STATE_PRESSED && m_hbmPressedSkin)
	{
		return m_hrgnPressedSkin;
	}
	else if (m_nState == STATE_HOVER && m_hbmHoverSkin)
	{
		return m_hrgnHoverSkin;
	}
	else
	{
		return m_hrgnSkin;
	}
}

//----------------------------------------------------------------------------
// GetName
//----------------------------------------------------------------------------

LPCTSTR
Button::GetName() const
{
	return m_pszName;
}

//----------------------------------------------------------------------------
// GetToolTipText
//----------------------------------------------------------------------------

LPCTSTR
Button::GetToolTipText() const
{
	return m_pszToolTipText;
}

//----------------------------------------------------------------------------
// GetWindow
//----------------------------------------------------------------------------

HWND
Button::GetWindow() const
{
	return m_hWnd;
}

//----------------------------------------------------------------------------
// Hide
//----------------------------------------------------------------------------

void
Button::Hide()
{
	ShowWindow(m_hWnd, SW_HIDE);
	m_fVisible = FALSE;
}

//----------------------------------------------------------------------------
// MoveBy
//----------------------------------------------------------------------------

void
Button::MoveBy(int dx, int dy)
{
	SetWindowPos(m_hWnd, NULL, m_x + dx, m_y + dy, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOZORDER);
}

//----------------------------------------------------------------------------
// MoveTo
//----------------------------------------------------------------------------

void
Button::MoveTo(int x, int y)
{
	SetWindowPos(m_hWnd, NULL, x, y, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOZORDER);
}

//----------------------------------------------------------------------------
// OnDestroy
//----------------------------------------------------------------------------

void
Button::OnDestroy()
{
	if (m_hbmIcon)
	{
		DeleteBitmap(m_hbmIcon);
		m_hbmIcon = NULL;
	}

	if (m_hfnFont)
	{
		DeleteFont(m_hfnFont);
		m_hfnFont = NULL;
	}

	if (m_hfnPressedFont)
	{
		DeleteFont(m_hfnPressedFont);
		m_hfnPressedFont = NULL;
	}

	if (m_hfnHoverFont)
	{
		DeleteFont(m_hfnHoverFont);
		m_hfnHoverFont = NULL;
	}

	if (m_hbmOrigSkin)
	{
		DeleteBitmap(m_hbmOrigSkin);
		m_hbmOrigSkin = NULL;
	}

	if (m_hbmOrigPressedSkin)
	{
		DeleteBitmap(m_hbmOrigPressedSkin);
		m_hbmOrigPressedSkin = NULL;
	}

	if (m_hbmOrigHoverSkin)
	{
		DeleteBitmap(m_hbmOrigHoverSkin);
		m_hbmOrigHoverSkin = NULL;
	}

	if (m_hbmSkin)
	{
		DeleteBitmap(m_hbmSkin);
		m_hbmSkin = NULL;
	}

	if (m_hbmPressedSkin)
	{
		DeleteBitmap(m_hbmPressedSkin);
		m_hbmPressedSkin = NULL;
	}

	if (m_hbmHoverSkin)
	{
		DeleteBitmap(m_hbmHoverSkin);
		m_hbmHoverSkin = NULL;
	}

	if (m_hrgnSkin)
	{
		DeleteRgn(m_hrgnSkin);
		m_hrgnSkin = NULL;
	}

	if (m_hrgnPressedSkin)
	{
		DeleteRgn(m_hrgnPressedSkin);
		m_hrgnPressedSkin = NULL;
	}

	if (m_hrgnHoverSkin)
	{
		DeleteRgn(m_hrgnHoverSkin);
		m_hrgnHoverSkin = NULL;
	}
}

//----------------------------------------------------------------------------
// OnLButtonDblClk
//----------------------------------------------------------------------------

void
Button::OnLButtonDblClk(UINT fuFlags, int x, int y)
{
	ChangeState(STATE_PRESSED);
	m_fMouseDown = TRUE;

	if (m_pszOnLeftDoubleClick)
	{
		LSExecute(m_hWnd, m_pszOnLeftDoubleClick, SW_SHOWNORMAL);
	}
}

//----------------------------------------------------------------------------
// OnLButtonDown
//----------------------------------------------------------------------------

void
Button::OnLButtonDown(UINT fuFlags, int x, int y)
{
	ChangeState(STATE_PRESSED);
	m_fMouseDown = TRUE;
}

//----------------------------------------------------------------------------
// OnLButtonUp
//----------------------------------------------------------------------------

void
Button::OnLButtonUp(UINT fuFlags, int x, int y)
{
	if (m_fMouseDown && !AnyButtonsDown(fuFlags))
	{
		ChangeState(m_fMouseInside ? STATE_HOVER : STATE_NORMAL);
		m_fMouseDown = FALSE;

		if (m_pszOnLeftClick)
		{
			LSExecute(m_hWnd, m_pszOnLeftClick, SW_SHOWNORMAL);
		}
	}
}

//----------------------------------------------------------------------------
// OnMButtonDblClk
//----------------------------------------------------------------------------

void
Button::OnMButtonDblClk(UINT fuFlags, int x, int y)
{
	ChangeState(STATE_PRESSED);
	m_fMouseDown = TRUE;

	if (m_pszOnMiddleDoubleClick)
	{
		LSExecute(m_hWnd, m_pszOnMiddleDoubleClick, SW_SHOWNORMAL);
	}
}

//----------------------------------------------------------------------------
// OnMButtonDown
//----------------------------------------------------------------------------

void
Button::OnMButtonDown(UINT fuFlags, int x, int y)
{
	ChangeState(STATE_PRESSED);
	m_fMouseDown = TRUE;
}

//----------------------------------------------------------------------------
// OnMButtonUp
//----------------------------------------------------------------------------

void
Button::OnMButtonUp(UINT fuFlags, int x, int y)
{
	if (m_fMouseDown && !AnyButtonsDown(fuFlags))
	{
		ChangeState(m_fMouseInside ? STATE_HOVER : STATE_NORMAL);
		m_fMouseDown = FALSE;

		if (m_pszOnMiddleClick)
		{
			LSExecute(m_hWnd, m_pszOnMiddleClick, SW_SHOWNORMAL);
		}
	}
}

//----------------------------------------------------------------------------
// OnMouseEnter
//----------------------------------------------------------------------------

void
Button::OnMouseEnter(UINT fuFlags)
{
	if (!AnyButtonsDown(fuFlags))
	{
		m_fMouseDown = FALSE;
	}

	ChangeState(m_fMouseDown ? STATE_PRESSED : STATE_HOVER);

	TRACKMOUSEEVENT tme;

	tme.cbSize = sizeof(TRACKMOUSEEVENT);
	tme.dwFlags = TME_LEAVE;
	tme.hwndTrack = m_hWnd;

	_TrackMouseEvent(&tme);

	if (m_pszOnEnter)
	{
		LSExecute(m_hWnd, m_pszOnEnter, SW_SHOWNORMAL);
	}
}

//----------------------------------------------------------------------------
// OnMouseLeave
//----------------------------------------------------------------------------

void
Button::OnMouseLeave()
{
	ChangeState(STATE_NORMAL);
	m_fMouseInside = FALSE;

	if (m_pszOnLeave)
	{
		LSExecute(m_hWnd, m_pszOnLeave, SW_SHOWNORMAL);
	}
}

//----------------------------------------------------------------------------
// OnMouseMove
//----------------------------------------------------------------------------

void
Button::OnMouseMove(UINT fuFlags, int x, int y)
{
	if (!m_fMouseInside)
	{
		m_fMouseInside = TRUE;
		OnMouseEnter(fuFlags);
	}
}

//----------------------------------------------------------------------------
// OnMove
//----------------------------------------------------------------------------

void
Button::OnMove(int x, int y)
{
	m_x = x;
	m_y = y;
}

//----------------------------------------------------------------------------
// OnPaint
//----------------------------------------------------------------------------

void
Button::OnPaint()
{
	PAINTSTRUCT ps;
	HDC hDC;

	hDC = BeginPaint(m_hWnd, &ps);
	Paint(hDC);
	EndPaint(m_hWnd, &ps);
}

//----------------------------------------------------------------------------
// OnPrintClient
//----------------------------------------------------------------------------

void
Button::OnPrintClient(HDC hDC, UINT fuFlags)
{
	Paint(hDC);
}

//----------------------------------------------------------------------------
// OnRButtonDblClk
//----------------------------------------------------------------------------

void
Button::OnRButtonDblClk(UINT fuFlags, int x, int y)
{
	ChangeState(STATE_PRESSED);
	m_fMouseDown = TRUE;

	if (m_pszOnRightDoubleClick)
	{
		LSExecute(m_hWnd, m_pszOnRightDoubleClick, SW_SHOWNORMAL);
	}
}

//----------------------------------------------------------------------------
// OnRButtonDown
//----------------------------------------------------------------------------

void
Button::OnRButtonDown(UINT fuFlags, int x, int y)
{
	ChangeState(STATE_PRESSED);
	m_fMouseDown = TRUE;
}

//----------------------------------------------------------------------------
// OnRButtonUp
//----------------------------------------------------------------------------

void
Button::OnRButtonUp(UINT fuFlags, int x, int y)
{
	if (m_fMouseDown && !AnyButtonsDown(fuFlags))
	{
		ChangeState(m_fMouseInside ? STATE_HOVER : STATE_NORMAL);
		m_fMouseDown = FALSE;

		if (m_pszOnRightClick)
		{
			LSExecute(m_hWnd, m_pszOnRightClick, SW_SHOWNORMAL);
		}
	}
}

//----------------------------------------------------------------------------
// OnSize
//----------------------------------------------------------------------------

void
Button::OnSize(UINT uState, int nWidth, int nHeight)
{
	m_nWidth = nWidth;
	m_nHeight = nHeight;

	// Render skins at our new size
	RenderSkins();

	// Update layout and repaint
	ChangeState(m_nState);
}

//----------------------------------------------------------------------------
// Paint
//----------------------------------------------------------------------------

void
Button::Paint(HDC hDC)
{
	// Double buffer for flicker-free paint
	HDC hdcBuffer = CreateCompatibleDC(hDC);
	HBITMAP hbmBuffer = CreateCompatibleBitmap(hDC, m_nWidth, m_nHeight);
	HBITMAP hbmPrevBuffer = SelectBitmap(hdcBuffer, hbmBuffer);

	// Paint the skin
	HBITMAP hbmSkin = GetCurrentSkin();

	if (hbmSkin)
	{
		HDC hdcSkin = CreateCompatibleDC(hDC);
		HBITMAP hbmPrevSkin = SelectBitmap(hdcSkin, hbmSkin);

		BitBlt(hdcBuffer, 0, 0, m_nWidth, m_nHeight, hdcSkin, 0, 0, SRCCOPY);

		SelectBitmap(hdcSkin, hbmPrevSkin);
		DeleteDC(hdcSkin);
	}
	else
	{
		RECT rc;
		GetClientRect(m_hWnd, &rc);

		HBRUSH hbrWhite = CreateSolidBrush(RGB(255, 255, 255));
		FillRect(hdcBuffer, &rc, hbrWhite);
		DeleteBrush(hbrWhite);
	}

	// Paint the icon
	if (m_hbmIcon)
	{
		HDC hdcIcon = CreateCompatibleDC(hDC);
		HBITMAP hbmPrevIcon = SelectBitmap(hdcIcon, m_hbmIcon);

		TransparentBltLS(hdcBuffer, m_xIcon, m_yIcon, m_cxIcon, m_cyIcon, hdcIcon, 0, 0, RGB(255, 0, 255));

		SelectBitmap(hdcIcon, hbmPrevIcon);
		DeleteDC(hdcIcon);
	}

	// Paint the text
	if (m_pszText)
	{
		HFONT hfnFont;
		COLORREF crFontColor;
		BOOL fFontShadow;
		COLORREF crFontShadowColor;
		int xFontShadowOffset;
		int yFontShadowOffset;

		switch (m_nState)
		{
		case STATE_NORMAL:
			hfnFont = m_hfnFont;
			crFontColor = m_crFontColor;
			fFontShadow = m_fFontShadow;
			crFontShadowColor = m_crFontShadowColor;
			xFontShadowOffset = m_xFontShadowOffset;
			yFontShadowOffset = m_yFontShadowOffset;
			break;

		case STATE_PRESSED:
			hfnFont = m_hfnPressedFont;
			crFontColor = m_crPressedFontColor;
			fFontShadow = m_fPressedFontShadow;
			crFontShadowColor = m_crPressedFontShadowColor;
			xFontShadowOffset = m_xPressedFontShadowOffset;
			yFontShadowOffset = m_yPressedFontShadowOffset;
			break;

		case STATE_HOVER:
			hfnFont = m_hfnHoverFont;
			crFontColor = m_crHoverFontColor;
			fFontShadow = m_fHoverFontShadow;
			crFontShadowColor = m_crHoverFontShadowColor;
			xFontShadowOffset = m_xHoverFontShadowOffset;
			yFontShadowOffset = m_yHoverFontShadowOffset;
			break;
		}

		HFONT hfnPrevFont = SelectFont(hdcBuffer, hfnFont);
		COLORREF crPrevFontColor = SetTextColor(hdcBuffer, crFontColor);
		int nPrevBkMode = SetBkMode(hdcBuffer, TRANSPARENT);

		int x = m_xText;
		int y = m_yText;

		if (fFontShadow)
		{
			x = x + (xFontShadowOffset + 1) / 2;
			y = y + (yFontShadowOffset + 1) / 2;

			SetTextColor(hdcBuffer, crFontShadowColor);
			ExtTextOut(hdcBuffer, x, y, 0, NULL, m_pszText, StrLen(m_pszText), NULL);
			SetTextColor(hdcBuffer, crFontColor);

			x = x - xFontShadowOffset;
			y = y - yFontShadowOffset;
		}

		ExtTextOut(hdcBuffer, x, y, 0, NULL, m_pszText, StrLen(m_pszText), NULL);

		SelectFont(hdcBuffer, hfnPrevFont);
		SetTextColor(hdcBuffer, crPrevFontColor);
		SetBkMode(hdcBuffer, nPrevBkMode);
	}

	// Copy the buffer to the display
	BitBlt(hDC, 0, 0, m_nWidth, m_nHeight, hdcBuffer, 0, 0, SRCCOPY);

	SelectBitmap(hdcBuffer, hbmPrevBuffer);
	DeleteBitmap(hbmBuffer);
	DeleteDC(hdcBuffer);
}

//----------------------------------------------------------------------------
// PinToDesktop
//----------------------------------------------------------------------------

void
Button::PinToDesktop()
{
	SetAlwaysOnTop(FALSE);
}

//----------------------------------------------------------------------------
// ReadConfig
//----------------------------------------------------------------------------

void
Button::ReadConfig()
{
	// Content
	m_nIconSize = GetConfigInt(_T("IconSize"), 16);
	m_hbmIcon = GetConfigImageOrIcon(_T("Icon"), m_nIconSize, &m_cxIcon, &m_cyIcon);
	m_pszText = GetConfigString(_T("Text"));
	m_pszToolTipText = GetConfigString(_T("ToolTipText"));

	// Position and size
	m_fAlwaysOnTop = GetConfigBoolean(_T("AlwaysOnTop"));
	m_fVisible = !GetConfigBoolean(_T("StartHidden"));
	m_x = GetConfigInt(_T("X"));
	m_y = GetConfigInt(_T("Y"));
	m_nWidth = GetConfigInt(_T("Width"));
	m_nHeight = GetConfigInt(_T("Height"));

	// Layout
	m_nAlign = GetConfigEnum(_T("Align"), g_enumAlign, ALIGN_CENTER);
	m_nVertAlign = GetConfigEnum(_T("VertAlign"), g_enumVertAlign, ALIGN_CENTER);
	m_nIconPosition = GetConfigEnum(_T("IconPosition"), g_enumIconPosition, ICON_POSITION_LEFT);
	m_nIconTextGap = GetConfigInt(_T("IconTextGap"), 4);
	m_nLeftBorder = GetConfigInt(_T("LeftBorder"));
	m_nRightBorder = GetConfigInt(_T("RightBorder"));
	m_nTopBorder = GetConfigInt(_T("TopBorder"));
	m_nBottomBorder = GetConfigInt(_T("BottomBorder"));

	// Fonts
	LPTSTR pszFont = GetConfigString(_T("Font"), _T("Arial"));
	int nFontHeight = GetConfigInt(_T("FontHeight"), 15);
	BOOL fFontBold = GetConfigBoolean(_T("FontBold"));
	BOOL fFontItalic = GetConfigBoolean(_T("FontItalic"));
	BOOL fFontUnderline = GetConfigBoolean(_T("FontUnderline"));
	m_crFontColor = GetConfigColor(_T("FontColor"));
	m_fFontShadow = GetConfigBoolean(_T("FontShadow"));
	m_crFontShadowColor = GetConfigColor(_T("FontShadowColor"), RGB(128, 128, 128));
	m_xFontShadowOffset = GetConfigInt(_T("FontShadowOffsetX"), 1);
	m_yFontShadowOffset = GetConfigInt(_T("FontShadowOffsetY"), 1);
	m_hfnFont = CreateFontEZ(pszFont, nFontHeight, fFontBold, fFontItalic, fFontUnderline);

	LPTSTR pszPressedFont = GetConfigString(_T("PressedFont"), pszFont);
	int nPressedFontHeight = GetConfigInt(_T("PressedFontHeight"), nFontHeight);
	BOOL fPressedFontBold = GetConfigBoolean(_T("PressedFontBold"), fFontBold);
	BOOL fPressedFontItalic = GetConfigBoolean(_T("PressedFontItalic"), fFontItalic);
	BOOL fPressedFontUnderline = GetConfigBoolean(_T("PressedFontUnderline"), fFontUnderline);
	m_crPressedFontColor = GetConfigColor(_T("PressedFontColor"), m_crFontColor);
	m_fPressedFontShadow = GetConfigBoolean(_T("PressedFontShadow"), m_fFontShadow);
	m_crPressedFontShadowColor = GetConfigColor(_T("PressedFontShadowColor"), m_crFontShadowColor);
	m_xPressedFontShadowOffset = GetConfigInt(_T("PressedFontShadowOffsetX"), m_xFontShadowOffset);
	m_yPressedFontShadowOffset = GetConfigInt(_T("PressedFontShadowOffsetY"), m_yFontShadowOffset);
	m_hfnPressedFont = CreateFontEZ(pszPressedFont, nPressedFontHeight, fPressedFontBold, fPressedFontItalic, fPressedFontUnderline);

	LPTSTR pszHoverFont = GetConfigString(_T("HoverFont"), pszFont);
	int nHoverFontHeight = GetConfigInt(_T("HoverFontHeight"), nFontHeight);
	BOOL fHoverFontBold = GetConfigBoolean(_T("HoverFontBold"), fFontBold);
	BOOL fHoverFontItalic = GetConfigBoolean(_T("HoverFontItalic"), fFontItalic);
	BOOL fHoverFontUnderline = GetConfigBoolean(_T("HoverFontUnderline"), fFontUnderline);
	m_crHoverFontColor = GetConfigColor(_T("HoverFontColor"), m_crFontColor);
	m_fHoverFontShadow = GetConfigBoolean(_T("HoverFontShadow"), m_fFontShadow);
	m_crHoverFontShadowColor = GetConfigColor(_T("HoverFontShadowColor"), m_crFontShadowColor);
	m_xHoverFontShadowOffset = GetConfigInt(_T("HoverFontShadowOffsetX"), m_xFontShadowOffset);
	m_yHoverFontShadowOffset = GetConfigInt(_T("HoverFontShadowOffsetY"), m_yFontShadowOffset);
	m_hfnHoverFont = CreateFontEZ(pszHoverFont, nHoverFontHeight, fHoverFontBold, fHoverFontItalic, fHoverFontUnderline);

	// Skins
	m_hbmOrigSkin = GetConfigImage(_T("Skin"), &m_cxSkin, &m_cySkin);
	m_nSkinLeftEdge = GetConfigInt(_T("SkinLeftEdge"));
	m_nSkinRightEdge = GetConfigInt(_T("SkinRightEdge"));
	m_nSkinTopEdge = GetConfigInt(_T("SkinTopEdge"));
	m_nSkinBottomEdge = GetConfigInt(_T("SkinBottomEdge"));
	m_nSkinMode = GetConfigEnum(_T("SkinMode"), g_enumSkinMode, SCALE_STRETCH);
	m_fSkinTransparent = GetConfigBoolean(_T("SkinTransparent"));

	m_hbmOrigPressedSkin = GetConfigImage(_T("PressedSkin"), &m_cxPressedSkin, &m_cyPressedSkin);
	m_nPressedSkinLeftEdge = GetConfigInt(_T("PressedSkinLeftEdge"), m_nSkinLeftEdge);
	m_nPressedSkinRightEdge = GetConfigInt(_T("PressedSkinRightEdge"), m_nSkinRightEdge);
	m_nPressedSkinTopEdge = GetConfigInt(_T("PressedSkinTopEdge"), m_nSkinTopEdge);
	m_nPressedSkinBottomEdge = GetConfigInt(_T("PressedSkinBottomEdge"), m_nSkinBottomEdge);
	m_nPressedSkinMode = GetConfigEnum(_T("PressedSkinMode"), g_enumSkinMode, m_nSkinMode);
	m_fPressedSkinTransparent = GetConfigBoolean(_T("PressedSkinTransparent"), m_fSkinTransparent);

	m_hbmOrigHoverSkin = GetConfigImage(_T("HoverSkin"), &m_cxHoverSkin, &m_cyHoverSkin);
	m_nHoverSkinLeftEdge = GetConfigInt(_T("HoverSkinLeftEdge"), m_nSkinLeftEdge);
	m_nHoverSkinRightEdge = GetConfigInt(_T("HoverSkinRightEdge"), m_nSkinRightEdge);
	m_nHoverSkinTopEdge = GetConfigInt(_T("HoverSkinTopEdge"), m_nSkinTopEdge);
	m_nHoverSkinBottomEdge = GetConfigInt(_T("HoverSkinBottomEdge"), m_nSkinBottomEdge);
	m_nHoverSkinMode = GetConfigEnum(_T("HoverSkinMode"), g_enumSkinMode, m_nSkinMode);
	m_fHoverSkinTransparent = GetConfigBoolean(_T("HoverSkinTransparent"), m_fSkinTransparent);

	// Offsets
	m_nPressedOffsetX = GetConfigInt(_T("PressedOffsetX"), 1);
	m_nPressedOffsetY = GetConfigInt(_T("PressedOffsetY"), 1);
	m_nHoverOffsetX = GetConfigInt(_T("HoverOffsetX"), 0);
	m_nHoverOffsetY = GetConfigInt(_T("HoverOffsetY"), 0);

	// Events
	m_pszOnEnter = GetConfigLine(_T("OnEnter"));
	m_pszOnLeave = GetConfigLine(_T("OnLeave"));
	m_pszOnLeftClick = GetConfigLine(_T("OnLeftClick"));
	m_pszOnLeftDoubleClick = GetConfigLine(_T("OnLeftDoubleClick"));
	m_pszOnMiddleClick = GetConfigLine(_T("OnMiddleClick"));
	m_pszOnMiddleDoubleClick = GetConfigLine(_T("OnMiddleDoubleClick"));
	m_pszOnRightClick = GetConfigLine(_T("OnRightClick"));
	m_pszOnRightDoubleClick = GetConfigLine(_T("OnRightDoubleClick"));

	// Miscellaneous
	m_nAlpha = GetConfigInt(_T("Alpha"), -1);

	// Clean up
	StrFree(pszFont);
	StrFree(pszPressedFont);
	StrFree(pszHoverFont);
}

//----------------------------------------------------------------------------
// RenderSkins
//----------------------------------------------------------------------------

void
Button::RenderSkins()
{
	HDC hdcWindow = GetDC(m_hWnd);
	HDC hdcOrigSkin = CreateCompatibleDC(hdcWindow);
	HDC hdcSkin = CreateCompatibleDC(hdcWindow);
	int nPrevMode = SetStretchBltMode(hdcSkin, STRETCH_DELETESCANS);

	// Normal Skin
	if (m_hbmSkin)
	{
		DeleteBitmap(m_hbmSkin);
		m_hbmSkin = NULL;
	}

	if (m_hrgnSkin)
	{
		DeleteRgn(m_hrgnSkin);
		m_hrgnSkin = NULL;
	}

	if (m_hbmOrigSkin)
	{
		m_hbmSkin = CreateCompatibleBitmap(hdcWindow, m_nWidth, m_nHeight);

		HBITMAP hbmPrevOrigSkin = SelectBitmap(hdcOrigSkin, m_hbmOrigSkin);
		HBITMAP hbmPrevSkin = SelectBitmap(hdcSkin, m_hbmSkin);

		ScaleEdgeBlt(hdcSkin, 0, 0, m_nWidth, m_nHeight, hdcOrigSkin, 0, 0, m_cxSkin, m_cySkin,
			m_nSkinLeftEdge, m_nSkinTopEdge, m_nSkinRightEdge, m_nSkinBottomEdge, m_nSkinMode, SRCCOPY);

		SelectBitmap(hdcOrigSkin, hbmPrevOrigSkin);
		SelectBitmap(hdcSkin, hbmPrevSkin);

		if (m_fSkinTransparent)
		{
			m_hrgnSkin = BitmapToRegion(m_hbmSkin, COLOR_TRANSPARENT, 0, 0, 0);
		}
	}

	// Pressed Skin
	if (m_hbmPressedSkin)
	{
		DeleteBitmap(m_hbmPressedSkin);
		m_hbmPressedSkin = NULL;
	}

	if (m_hrgnPressedSkin)
	{
		DeleteRgn(m_hrgnPressedSkin);
		m_hrgnPressedSkin = NULL;
	}

	if (m_hbmOrigPressedSkin)
	{
		m_hbmPressedSkin = CreateCompatibleBitmap(hdcWindow, m_nWidth, m_nHeight);

		HBITMAP hbmPrevOrigSkin = SelectBitmap(hdcOrigSkin, m_hbmOrigPressedSkin);
		HBITMAP hbmPrevSkin = SelectBitmap(hdcSkin, m_hbmPressedSkin);

		ScaleEdgeBlt(hdcSkin, 0, 0, m_nWidth, m_nHeight, hdcOrigSkin, 0, 0, m_cxPressedSkin, m_cyPressedSkin,
			m_nPressedSkinLeftEdge, m_nPressedSkinTopEdge, m_nPressedSkinRightEdge, m_nPressedSkinBottomEdge, m_nPressedSkinMode, SRCCOPY);

		SelectBitmap(hdcOrigSkin, hbmPrevOrigSkin);
		SelectBitmap(hdcSkin, hbmPrevSkin);

		if (m_fPressedSkinTransparent)
		{
			m_hrgnPressedSkin = BitmapToRegion(m_hbmPressedSkin, COLOR_TRANSPARENT, 0, 0, 0);
		}
	}

	// Hover Skin
	if (m_hbmHoverSkin)
	{
		DeleteBitmap(m_hbmHoverSkin);
		m_hbmHoverSkin = NULL;
	}

	if (m_hrgnHoverSkin)
	{
		DeleteRgn(m_hrgnHoverSkin);
		m_hrgnHoverSkin = NULL;
	}

	if (m_hbmOrigHoverSkin)
	{
		m_hbmHoverSkin = CreateCompatibleBitmap(hdcWindow, m_nWidth, m_nHeight);

		HBITMAP hbmPrevOrigSkin = SelectBitmap(hdcOrigSkin, m_hbmOrigHoverSkin);
		HBITMAP hbmPrevSkin = SelectBitmap(hdcSkin, m_hbmHoverSkin);

		ScaleEdgeBlt(hdcSkin, 0, 0, m_nWidth, m_nHeight, hdcOrigSkin, 0, 0, m_cxHoverSkin, m_cyHoverSkin,
			m_nHoverSkinLeftEdge, m_nHoverSkinTopEdge, m_nHoverSkinRightEdge, m_nHoverSkinBottomEdge, m_nHoverSkinMode, SRCCOPY);

		SelectBitmap(hdcOrigSkin, hbmPrevOrigSkin);
		SelectBitmap(hdcSkin, hbmPrevSkin);

		if (m_fHoverSkinTransparent)
		{
			m_hrgnHoverSkin = BitmapToRegion(m_hbmHoverSkin, COLOR_TRANSPARENT, 0, 0, 0);
		}
	}

	SetStretchBltMode(hdcSkin, nPrevMode);
	ReleaseDC(m_hWnd, hdcWindow);
	DeleteDC(hdcOrigSkin);
	DeleteDC(hdcSkin);
}

//----------------------------------------------------------------------------
// ResizeBy
//----------------------------------------------------------------------------

void
Button::ResizeBy(int dx, int dy)
{
	SetWindowPos(m_hWnd, NULL, 0, 0, m_nWidth + dx, m_nHeight + dy, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOZORDER);
}

//----------------------------------------------------------------------------
// ResizeTo
//----------------------------------------------------------------------------

void
Button::ResizeTo(int nWidth, int nHeight)
{
	SetWindowPos(m_hWnd, NULL, 0, 0, nWidth, nHeight, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOZORDER);
}

//----------------------------------------------------------------------------
// SetAlpha
//----------------------------------------------------------------------------

void
Button::SetAlpha(int nAlpha)
{
	SetWindowAlpha(m_hWnd, nAlpha);
	m_nAlpha = nAlpha;
}

//----------------------------------------------------------------------------
// SetAlwaysOnTop
//----------------------------------------------------------------------------

void
Button::SetAlwaysOnTop(BOOL fAlwaysOnTop)
{
	if (m_hwndParent)
	{
		return;
	}
	
	ModifyStyle(WS_POPUP, WS_CHILD);
	SetParent(m_hWnd, fAlwaysOnTop ? NULL : GetShellDesktopWindow());
	ModifyStyle(WS_CHILD, WS_POPUP);

	SetWindowPos(m_hWnd, fAlwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
	m_fAlwaysOnTop = fAlwaysOnTop;
}

//----------------------------------------------------------------------------
// SetIcon
//----------------------------------------------------------------------------

void
Button::SetIcon(LPCTSTR pszIcon, int nIconSize)
{
	if (m_hbmIcon)
	{
		DeleteBitmap(m_hbmIcon);
		m_hbmIcon = NULL;
	}

	if (pszIcon)
	{
		if (nIconSize > 0)
		{
			m_nIconSize = nIconSize;
		}

		m_hbmIcon = LoadImageOrIcon(pszIcon, m_nIconSize, &m_cxIcon, &m_cyIcon);
	}

	DoLayout();
}

//----------------------------------------------------------------------------
// SetText
//----------------------------------------------------------------------------

void
Button::SetText(LPCTSTR pszText)
{
	StrFree(m_pszText);
	m_pszText = StrAlloc(pszText);
	DoLayout();
}

//----------------------------------------------------------------------------
// SetToolTipText
//----------------------------------------------------------------------------

void
Button::SetToolTipText(LPCTSTR pszToolTipText)
{
	StrFree(m_pszToolTipText);
	m_pszToolTipText = StrAlloc(pszToolTipText);
}

//----------------------------------------------------------------------------
// Show
//----------------------------------------------------------------------------

void
Button::Show()
{
	ShowWindow(m_hWnd, SW_SHOWNOACTIVATE);
	m_fVisible = TRUE;
}

//----------------------------------------------------------------------------
// Toggle
//----------------------------------------------------------------------------

void
Button::Toggle()
{
	if (m_fVisible)
	{
		Hide();
	}
	else
	{
		Show();
	}
}

//----------------------------------------------------------------------------
// ToggleAlwaysOnTop
//----------------------------------------------------------------------------

void
Button::ToggleAlwaysOnTop()
{
	SetAlwaysOnTop(!m_fAlwaysOnTop);
}

//----------------------------------------------------------------------------
// WindowProc
//----------------------------------------------------------------------------

LRESULT
Button::WindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		DISPATCH_MSG(WM_DESTROY, wParam, lParam, OnDestroy);
		DISPATCH_MSG(WM_LBUTTONDBLCLK, wParam, lParam, OnLButtonDblClk);
		DISPATCH_MSG(WM_LBUTTONDOWN, wParam, lParam, OnLButtonDown);
		DISPATCH_MSG(WM_LBUTTONUP, wParam, lParam, OnLButtonUp);
		DISPATCH_MSG(WM_MBUTTONDBLCLK, wParam, lParam, OnMButtonDblClk);
		DISPATCH_MSG(WM_MBUTTONDOWN, wParam, lParam, OnMButtonDown);
		DISPATCH_MSG(WM_MBUTTONUP, wParam, lParam, OnMButtonUp);
		DISPATCH_MSG(WM_MOUSELEAVE, wParam, lParam, OnMouseLeave);
		DISPATCH_MSG(WM_MOUSEMOVE, wParam, lParam, OnMouseMove);
		DISPATCH_MSG(WM_MOVE, wParam, lParam, OnMove);
		DISPATCH_MSG(WM_PAINT, wParam, lParam, OnPaint);
		DISPATCH_MSG(WM_PRINTCLIENT, wParam, lParam, OnPrintClient);
		DISPATCH_MSG(WM_RBUTTONDBLCLK, wParam, lParam, OnRButtonDblClk);
		DISPATCH_MSG(WM_RBUTTONDOWN, wParam, lParam, OnRButtonDown);
		DISPATCH_MSG(WM_RBUTTONUP, wParam, lParam, OnRButtonUp);
		DISPATCH_MSG(WM_SIZE, wParam, lParam, OnSize);
	}

	return DefWindowProc(m_hWnd, uMsg, wParam, lParam);
}
