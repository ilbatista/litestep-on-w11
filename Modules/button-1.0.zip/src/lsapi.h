//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#ifndef __LSAPI_H
#define __LSAPI_H

#ifdef __cplusplus
extern "C" {
#endif

#define LM_REGISTERMESSAGE 9263
#define LM_UNREGISTERMESSAGE 9264
#define LM_GETREVID 9265

typedef void (*PFN_BANGCOMMAND)(HWND, LPCSTR);

BOOL AddBangCommand(LPCSTR pszName, PFN_BANGCOMMAND pfnCallback);
BOOL ParseBangCommand(HWND hwndCaller, LPCSTR pszName, LPCSTR pszArgs);
BOOL RemoveBangCommand(LPCSTR pszName);

BOOL GetRCBoolDef(LPCSTR pszKey, BOOL fDefault);
COLORREF GetRCColor(LPCSTR pszKey, COLORREF crDefault);
int GetRCInt(LPCSTR pszKey, int nDefault);
BOOL GetRCLine(LPCSTR pszKey, LPSTR pszBuffer, int cchBuffer, LPCSTR pszDefault);
BOOL GetRCString(LPCSTR pszKey, LPSTR pszBuffer, LPCSTR pszDefault, int cchBuffer);
BOOL LCClose(LPVOID pvFile);
LPVOID LCOpen(LPCSTR pszFile);
BOOL LCReadNextConfig(LPVOID pvFile, LPCSTR pszPrefix, LPSTR pszBuffer, UINT cchBuffer);
int LCTokenize(LPCSTR pszInput, LPSTR *ppszBuffers, int cBuffers, LPSTR pszExtraBuffer);

HRGN BitmapToRegion(HBITMAP hbmBitmap, COLORREF crTransparent, COLORREF crTolerance, int xOffset, int yOffset);
HBITMAP LoadLSImage(LPCSTR pszFile, LPCSTR pszReserved);
HICON LoadLSIcon(LPCSTR pszFile, LPCSTR pszReserved);
void TransparentBltLS(HDC hdcDest, int xDest, int yDest, int cx, int cy, HDC hdcSrc, int xSrc, int ySrc, COLORREF crTransparent);

HWND GetLitestepWnd();
BOOL WINAPI LSGetImagePath(LPTSTR pszBuffer, UINT cchBuffer);
HINSTANCE LSExecute(HWND hwndCaller, LPCSTR pszCommand, int nShowCmd);

#ifdef __cplusplus
}
#endif

#endif
