This is the official shortcut2.dll from the LSDev .24.6 build of 2000.12.10 (from FPN). This is the last .24.6 build before the z-Order/OnTop changes were made. I was asked by ceeslans to separate this module and make it available on the ShellFront Module List as it is used in some of his themes.

This module was coded by NeXTer, released by the LSDev team (http://www.lsdev.org/), and was compiled by rootrider for the FPN/ShellFront LSDev site.
--
readme date: 2003.10.07
rootrider