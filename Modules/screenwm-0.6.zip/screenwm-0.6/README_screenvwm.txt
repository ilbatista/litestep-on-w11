ScreenVWM 0.6 - a Litestep taskbar and VWM
By Jim Babcock

************
* Contents *
************
* 1. Using ScreenVWM
* 2. Adding ScreenVWM to your theme
* 3. Bang commands
* 4. Desktop descriptions
* 5. Legalities

**********************
* 1. Using ScreenVWM *
**********************
Initially, there will be one virtual desktop shown with all of your tasks in
it. To create a new desktop, drag one of your tasks' icons to an empty part of
the taskbar. You can also switch desktop and move windows between desktops
this way.

The file screenvwm_hotkeys.rc defines a set of hotkeys which all themes that
use ScreenVWM should include. These hotkeys are:
  Win+[1-9]         Switch to the numbered desktop (Win+0 is desk ten).
  Win+Left          Switch to previous desktop.
  Win+Right         Switch to next desktop.
  Win+Down          Merge current desktop with previous desktop.
  Win+Shift+Left    Move current application to previous desktop.
  Win+Shift+Right   Move current application to next desktop.
  Win+Shift+Up      Move current application to a new desktop at the beginning
                    of the list.
  Win+Shift+Down    Move current application to a new desktop at the end of
                    the list.
  Win+Ctrl+Left     Move this desk earlier in the list of desktops
  Win+Ctrl+Right    Move this desk later in the list of desktops
  Win+Ctrl+Down     Combine all desktops into one (gather)
  
*************************************
* 2. Adding ScreenVWM to Your Theme *
*************************************

To add ScreenVWM to your Litestep theme, put
  *NetLoadModule screenvwm.dll
in your theme.rc file. You will then want to configure it; take a look at
defaultSettings.txt for a list of options. In particular, you will at least
want to choose a size and position (the default is a 32-pixel thick bar across
the top of the screen).

IMPORTANT: You cannot use ScreenVWM and another VWM module, such as vwm2 or
rabidvwm, at the same time. When you add the option to load ScreenVWM to your
theme.rc, make sure to disable loading of all other VWMs.

********************
* 3. Bang Commands *
********************

  !swmCreate
    Creates a new desk containing the foreground task and switch to it. This is
    equivalent to dragging the foreground task to an unused part of the
    taskbar, or '!vwmMoveApp new'.

  !swmDesk <desk>
    Switch to the given desk, where <desk> is either a number (eg "!vwmDesk 1")
    or a description (eg "!vwmDesk next"). See "Desk descriptions".

  !swmDestroy        
    Synonym for '!swmMerge prev'

  !swmGather
    Combine all desktops into one, moving all windows on screen.

  !swmMaximizeWindow
    Maximizes the foreground window.

  !swmMerge <desk>
    Merge the current desktop with the specified desktop, leaving one desktop
    with the windows and tasks of both.

  !swmMinimizeWindow
    Minimizes the foreground window.

  !swmMoveApp <desk>
    Moves the foreground app to the given desk, and focuses on that desk.

  !swmMoveDesk <desk>
    Reorders desktops so that the current desktop is in the specified position.
    For example, "!swmMoveDesk last" moves the current desktop to the end of
    the list, while "!swmMoveDesk prev" moves the current desktop up one.

  !swmMoveWindow
    Moves the foreground window, as though you had picked 'move' from its
    system menu.

  !swmNext/!swmPrev/!swmUp/!swmDown/!swmLeft/!swnRight/!swmDown
    Switches the current desktop. These are  short for !vwmDesk with different
    parameters. See "Desk Descriptions". Up/left means prev and down/right
    means next.

  !swmOntopToggle
    Toggles whether or not ScreenVWM is always on top.

  !swmOpen <desk> <command>
    Switches to the given desk and then runs the given command or program.

  !swmResizeWindow
    Resizes the foreground window, as though you had picked 'resize' from its
    system menu.

  !swmSeparate <desk>
  !swmSeparateAll
    CURRENTLY BROKEN (as of 0.6)
    Splits up desktops, making one desktop per window.

  !swmShow/!swmHide
    Makes ScreenVWM visible or invisible.


************************
* 4. Desk Descriptions *
************************

Wherever a bang command or variable refers to a desktop, you may choose a
desktop using one of the following descriptions. Note that there may not be
such a desktop; for example, if the last desktop is selected, then "next"
doesn't refer to anything. You may provide a slash-separated list of fallbacks;
for example, the command
    !swmDesk next/first
will switch to the next desk, wrapping around at the end. If no parameter is
given or if none of the described desks exists, defaults to next/prev/current.
The available desk descriptions are:

    [n]
      The nth desktop. There is no 0th desktop. May be any positive integer
      less than or equal to the number of desktops.

    prev, next
      The desktops before and after the focused desktop. If there is no such
      desk, the one opposite (ie when the first desk is focused, 'prev' goes to
      next)

    first, last
      The first and last desktops.
    
    current
      The desktop you are looking at now

    other
      The last desktop you looked at, besides the focused one

    up, left, right, down
      Synonyms for nextwrap and prevwrap provided for compatibility (up/left is
      prevwrap, down/right is nextwrap.)

    newprev, newnext, newfirst, newlast
      New desktops created in the corresponding positions. Note that empty
      desktops will be automatically deleted, so you must either put something
      on it (eg with !swmMoveApp) or set swmKeepEmptyDesktops to true.


*****************
* 5. Legalities *
*****************

ScreenVWM is copyright (C) 2008 James Babcock. It contains code derived from
LiteStep, which is copyright (C) 1997-2008 The LiteStep Development Team.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
file license.txt for details.
