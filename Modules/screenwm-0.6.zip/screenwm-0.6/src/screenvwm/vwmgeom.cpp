/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include <math.h>
#include <utility>
using std::swap;
#include "vwm.h"
#include "trace.hpp"
#include "layout.hpp"

void VWM::initDesktops()
{
	windowX = settings->panelX;
	windowY = settings->panelY;
	windowWidth = settings->panelWidth;
	windowHeight = settings->panelHeight;
	
	if(!settings->autoGather) {
		if(restoreDesktops())
			return;
	}
	
	// Start with only one desktop
	desktops.push_back(new VirtualDesktop(0, storageManager.getStorageArea()));
	
	currentDesktop = desktops[0];
	lastDesktop = currentDesktop;
	desktops[0]->focused = true;
	
	updateTaskLists();
	tryLayouts();
}

#define MODULE_ID 0xC153

bool VWM::restoreDesktops()
{
	char buf[4096];
	
	if(!SendMessage(GetLitestepWnd(), LM_RESTOREDATA, MAKEWPARAM(sizeof(buf), MODULE_ID), (LPARAM)buf)) {
		trace << "No restorable desktops found.\n";
		return false;
	}
	
	vector<StorageArea*> deskAreas;
	int focus = storageManager.restore((void*)buf, deskAreas);
	
	trace << "Restored "<<deskAreas.size()<<" desktops.\n";
	for(unsigned ii=0; ii<deskAreas.size(); ii++)
	{
		desktops.push_back(new VirtualDesktop(ii, deskAreas[ii]));
	}
	
	currentDesktop = desktops[focus];
	lastDesktop = currentDesktop;
	desktops[focus]->focused = true;
	
	updateTaskLists();
	tryLayouts();
	
	return true;
}

void VWM::saveDesktops()
{
	vector<StorageArea*> deskAreas;
	int focus = 0;
	for(unsigned ii=0; ii<desktops.size(); ii++) {
		deskAreas.push_back(desktops[ii]->storage);
		if(desktops[ii]->focused)
			focus = ii;
	}
	
	int len;
	void *data = storageManager.save(&len, focus, deskAreas);
	SendMessage(GetLitestepWnd(), LM_SAVEDATA, MAKEWPARAM(len, MODULE_ID), (LPARAM)data);
	free(data);
}

VirtualDesktop::VirtualDesktop(int index, StorageArea *storage)
{
	layoutDone = false;
	this->index = index;
	focused = false;
	this->storage = storage;
	numTasks = 0;
}

VirtualDesktop::~VirtualDesktop()
{
	delete storage;
}

string VirtualDesktop::getName()
{
	char buf[32];
	sprintf(buf, "Desktop %i", index+1);
	return buf;
}

string VirtualDesktop::getLabel()
{
	char buf[16];
	itoa(index+1, buf, 10);
	return buf;
}

void VWM::tryLayouts()
{
	bool layoutValid = false;
	layoutIndex = 0;
	
	// Start with a single-row layout. If that works (everything fits), stop
	// there. Otherwise, try a two-row layout, then a three-row layout, and
	// so on until we find one with enough space to fit everything.
	while(!layoutValid)
	{
		if(layoutIndex >= (int)settings->layoutSettings.size()) {
			LayoutSettings nextLayout = impliedLayoutFallback(*layoutSettings);
			settings->layoutSettings.push_back(nextLayout);
		}
		layoutSettings = &settings->layoutSettings[layoutIndex];
		
		layoutValid = doLayout();
		
		if(!layoutValid)
			layoutIndex++;
	}
	
	// Mark all desktops as having had their layout done
	for(unsigned ii=0; ii<desktops.size(); ii++)
		desktops[ii]->layoutDone = true;
}

bool VWM::doLayout()
{
	WrappingFlow flow(settings->flowDirection, 0, 0, settings->panelWidth, settings->panelHeight);
	
	float aspect = (float)screenWidth / screenHeight;
	
	int rowThickness;
	if(directionIsVertical(settings->flowDirection))
		rowThickness = settings->panelWidth / layoutSettings->panelRows;
	else
		rowThickness = settings->panelHeight / layoutSettings->panelRows;
	
	// Minimap dimensions - either use those given in LayoutSettings, or scale
	// down in an aspect-preserving way.
	float minimapMaxWidth, minimapMaxHeight;
	if(directionIsVertical(settings->flowDirection)) {
		minimapMaxWidth = rowThickness;
		minimapMaxHeight = rowThickness/aspect;
	} else {
		minimapMaxHeight = rowThickness;
		minimapMaxWidth = rowThickness*aspect;
	}
	
	int x, y;
	flow.start(x, y);
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		
		// Set base size
		POINT size;
		if(directionIsVertical(settings->flowDirection)) {
			size.x = rowThickness;
			size.y = layoutSettings->deskBaseSize;
		} else {
			size.x = layoutSettings->deskBaseSize;
			size.y = rowThickness;
		}
		
		// If any widgets request a size extension for this desk (particularly,
		// task icons), set the size accordingly
		for(unsigned jj=0; jj<settings->deskLayout.size(); jj++) {
			POINT sizeExtension = settings->deskLayout[jj]->updateSize(desk, directionIsVertical(settings->flowDirection), rowThickness);
			size.x += sizeExtension.x;
			size.y += sizeExtension.y;
		}
		
		// Calculate the size of the panel as a whole
		if(directionIsVertical(settings->flowDirection)) {
			desk->panelWidth = rowThickness;
			desk->panelHeight = size.y;
		} else {
			desk->panelHeight = rowThickness;
			desk->panelWidth = size.x;
		}
		
		// Determine the location of the panel
		if(!flow.fit(x, y, desk->panelWidth, desk->panelHeight)) {
			// But if the panel didn't fit, return failure so tryLayouts()
			// will move on to the next set of layout settings.
			return false;
		}
		
		desk->panelX = x;
		desk->panelY = y;
		
		// Advance to the position of the next panel
		flow.next(x, y, desk->panelWidth, desk->panelHeight);
	}
	
	return true;
}

void VWM::updateTaskLists()
{
	// Match tasks up to VWMs
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		desktops[ii]->tasks.clear();
	}
	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
	{
		WindowData *window = ii->second;
		
		if(!window->desk)
			continue;
		if(!window->isTask)
			continue;
		
		window->desk->tasks.push_back(window);
	}
	
	// If any desk has no tasks on it, delete it
	// But don't delete desks while dragging/dropping
	if(!draggingTask && !settings->keepEmptyDesktops)
	{
		for(unsigned ii=0; ii<desktops.size(); ii++)
		{
			if(desktops[ii]->tasks.size())
				continue;
			if(desktops[ii]->focused && settings->keepEmptyFocusedDesktop)
				continue;
			
			if(destroyDesktop(desktops[ii]))
				ii--;
		}
	}
}

POINT VWM::taskToPoint(WindowData *task)
{
	/*if(!task || !task->desk) {
		POINT ret;
			ret.x = windowX;
			ret.y = windowY;
		return ret;
	}
	
	VirtualDesktop *desk = task->desk;
	int taskIndex = -1;
	for(unsigned ii=0; ii<desk->tasks.size(); ii++) {
		if(desk->tasks[ii] == task) {
			taskIndex = ii;
			break;
		}
	}
	if(taskIndex == -1) {
		POINT ret;
			ret.x = desk->panelX;
			ret.y = desk->panelY;
		return ret;
	}
	
	WrappingFlow flow(settings->flowDirection, 0, 0, desk->tasksNumCols-1, desk->tasksNumRows-1);
	int x, y;
	flow.start(x, y);
	for(int ii=0; ii<taskIndex; ii++)
		flow.next(x, y, 1, 1);
	
	POINT ret;
	ret.x = desk->tasksX + x*desk->tasksIconArea;
	ret.y = desk->tasksY + y*desk->tasksIconArea;
	return ret;*/
	
	// FIXME TODO STUB: Just returns (0,0)
	POINT ret = {0,0};
	return ret;
}

void VWM::setScreenSize( int cx, int cy )
{
	screenWidth = cx;
	screenHeight = cy;
}

RECT VWM::getMaximizeArea()
{
	// TODO: Get maximize-area properly
	RECT ret;
		ret.left = GetRCCoordinate("SDALeft", 0, screenWidth);
		ret.top = GetRCCoordinate("SDATop", 0, screenHeight);
		ret.right = GetRCCoordinate("SDARight", screenWidth, screenWidth);
		ret.bottom = GetRCCoordinate("SDABottom", screenHeight, screenHeight);
		
		if(ret.right <= ret.left)
			ret.right = screenWidth;
		if(ret.bottom <= ret.top)
			ret.bottom = screenHeight;
	return ret;
}

void VWM::getDragDestination(
	RECT *outRect, VirtualDesktop **outDesk,
	WindowData *window, POINT clickOffset, int mouseX, int mouseY)
{
	VirtualDesktop *desk;
	bool maximized = GetWindowLong(window->handle, GWL_STYLE) & WS_MAXIMIZE;
	
	desk = panelPointToDesk(mouseX, mouseY);
	if(!desk) {
		// If drag is into new (non-desk) area where a desk panel could be,
		// and there has not already been a new desk created as a result of
		// this drag, create a new desktop and drag onto it.
		if(!settings->dragCreatesDesks) {
			return;
		}
		if(mouseX < 0 || mouseY < 0 || mouseX >= settings->panelWidth || mouseY >= settings->panelHeight) {
			return;
		}
		if(dragCreatedDesk)
			return;
		desk = dragCreatedDesk = new VirtualDesktop(desktops.size(), storageManager.getStorageArea());
		desktops.push_back(desk);
	}
	*outDesk = desk;
	
	LayoutLocation layoutPos = elementAtPoint(mouseX, mouseY);
	LayoutElement *element = layoutPos.element;
	
	if(maximized)
	{
		*outRect = window->screenPos;
		if(!window->desk->focused)
			window->desk->storage->unstoreRect(*outRect);
	}
	else if(dynamic_cast<MinimapElement*>(element))
	{
		MinimapElement *minimap = dynamic_cast<MinimapElement*>(element);
		int width = window->screenPos.right - window->screenPos.left;
		int height = window->screenPos.bottom - window->screenPos.top;
		RECT maximizeArea = getMaximizeArea();
		
		POINT topLeft = minimapToScreenPos(desk, minimap, mouseX-clickOffset.x, mouseY-clickOffset.y);
		if(topLeft.x < maximizeArea.left)
			topLeft.x = maximizeArea.left;
		if(topLeft.y < maximizeArea.top)
			topLeft.y = maximizeArea.top;
		if(topLeft.x + width > maximizeArea.right)
			topLeft.x = maximizeArea.right - width;
		if(topLeft.y + height > maximizeArea.bottom)
			topLeft.y = maximizeArea.bottom - height;
		outRect->left = topLeft.x;
		outRect->top = topLeft.y;
		outRect->right = outRect->left + width;
		outRect->bottom = outRect->top + height;
	}
}

RECT VWM::getGatherTarget(RECT source)
{
	RECT ret = source;
		RECT maximizeArea = getMaximizeArea();
	int maximizeWidth = maximizeArea.right - maximizeArea.left;
	int maximizeHeight = maximizeArea.bottom - maximizeArea.top;
	
	// If this is inside a VWM's storage area, first bring it in
	VirtualDesktop *desk = deskFromLocation(source);
	if(desk && !desk->focused)
		desk->storage->unstoreRect(ret);
	
	// TODO: Get the window-maximize region, rather than using (0,0,w,h).
	
	int width  = source.right  - source.left;
	int height = source.bottom - source.top;
	int offsetX=0;
	int offsetY=0;
	
	// If a window is wider or taller than the screen, center it. Otherwise,
	// match an edge. (This happens more often than you'd think, because
	// maximized windows are a few pixels bigger than the maximize-area so
	// that their borders fall offscreen.)
	if(width > maximizeWidth) {
		if(ret.left > maximizeArea.left || ret.right < maximizeArea.right)
			ret.left = maximizeArea.left - (width-maximizeWidth)/2;
	} else if(ret.right > maximizeWidth) {
		ret.left += maximizeWidth-ret.right;
	} else if(ret.left < maximizeArea.left) {
		ret.left = maximizeArea.left;
	}
	
	if(height > maximizeHeight) {
		if(ret.top > maximizeArea.top || ret.bottom < maximizeArea.bottom)
			ret.top = maximizeArea.top - (height-maximizeHeight)/2;
	} else if(ret.bottom > maximizeArea.bottom) {
		ret.top += maximizeArea.bottom - ret.bottom;
	} else if(ret.top < maximizeArea.top) {
		ret.top = maximizeArea.top;
	}
	
	ret.right = ret.left + width;
	ret.bottom = ret.top + height;
	return ret;
}

POINT VWM::minimapToScreenPos(VirtualDesktop *desk, MinimapElement *minimap, int x, int y)
{
	POINT ret;
	RECT maximizeArea = getMaximizeArea();
	
	RECT minimapArea;
	minimap->getRect(desk, &minimapArea);
	
	ret.x = (x - minimapArea.left) * ((float)(maximizeArea.right-maximizeArea.left) / (minimapArea.right-minimapArea.left));
	ret.y = (y - minimapArea.top ) * ((float)(maximizeArea.bottom-maximizeArea.top) / (minimapArea.bottom-minimapArea.top));
	ret.x += maximizeArea.left;
	ret.y += maximizeArea.top;
	return ret;
}

bool RectOverlap(RECT a, RECT b)
{
	return b.left <= a.right && a.left <= b.right
	     && a.top <= b.bottom && b.top <= a.bottom;
}

VirtualDesktop *VWM::deskFromLocation(RECT pos)
{
	int centerX = (pos.left+pos.right)/2;
	int centerY = (pos.top+pos.bottom)/2;
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		if(desk->focused) {
			RECT screenRect;
				screenRect.left = 0;
				screenRect.top = 0;
				screenRect.right = screenWidth;
				screenRect.bottom = screenHeight;
			if(RectOverlap(screenRect, pos))
				return desk;
		} else {
			if(RectOverlap(desk->storage->getRect(), pos))
				return desk;
		}
	}
	
	return NULL;
}

VirtualDesktop *VWM::panelPointToDesk(int x, int y)
{
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		if(x >= desk->panelX && y >= desk->panelY
		   && x <= desk->panelX+desk->panelWidth
		   && y <= desk->panelY+desk->panelHeight)
			return desk;
	}
	
	return NULL;
}
