/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "vwm.h"
#include "util.hpp"
#include "trace.hpp"

TextLabelElement::TextLabelElement(string prefix)
	:LayoutElement(prefix)
{
	x = getConfigString("X", "10", prefix.c_str());
	y = getConfigString("Y", "50%", prefix.c_str());
	
	PaintTextDefaults textDefaults;
	textDefaults.m_iFontHeight = 8;
	font = Create_xTextClass();
	font->configure(prefix.c_str(), "", 0, NULL, &textDefaults);
	
	alignHoriz = parseAlign(getConfigString("AlignHoriz", "center", prefix.c_str()));
	alignVert  = parseAlign(getConfigString("AlignVert", "center", prefix.c_str()));
}

void TextLabelElement::draw(HDC drawContext, VirtualDesktop *desk)
{
	string text = desk->getLabel();
	RECT rect;
	getRect(desk, &rect);
	
	font->apply(drawContext,
		desk->panelX + rect.left, desk->panelY + rect.top,
		rect.right-rect.left, rect.bottom-rect.top,
		text.c_str());
}

void TextLabelElement::getRect(VirtualDesktop *desk, RECT *rect)
{
	string text = desk->getLabel();
	rect->left = ParseCoordinate(x.c_str(), 0, desk->panelWidth);
	rect->top = ParseCoordinate(y.c_str(), 0, desk->panelHeight);
	POINT textSize = font->measure(vwm->backBuffer, 0, 0, text.c_str());
	
	switch(alignHoriz) {
		case alignLeft: break;
		case alignCenter: rect->left-= textSize.x/2; break;
		case alignRight: rect->left -= textSize.x; break;
	}
	switch(alignVert) {
		case alignTop: break;
		case alignCenter: rect->top -= textSize.y/2; break;
		case alignBottom: rect->top -= textSize.y; break;
	}
	
	rect->right = rect->left + textSize.x;
	rect->bottom = rect->top + textSize.y;
}

