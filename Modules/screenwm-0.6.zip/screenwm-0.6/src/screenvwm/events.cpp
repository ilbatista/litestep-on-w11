/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <windows.h>
#include <CommCtrl.h>
#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include "vwm.h"
#include "trace.hpp"
#include "layout.hpp"

static const int litestepMessageTypes[] = {
	LM_GETREVID,
	LM_BRINGTOFRONT,
	LM_SWITCHTON,
	LM_WINDOWACTIVATED,
	LM_LISTDESKTOPS,
	LM_GETDESKTOPOF,
	LM_WINDOWCREATED,
	LM_WINDOWDESTROYED,
	LM_REPAINT,
	0
};

//=========================================================
// Message handling
//=========================================================
void VWM::registerEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)litestepMessageTypes);
}

void VWM::unregisterEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)litestepMessageTypes);
}

void VWM::windowProc(Message& message)
{
	switch (message.uMsg)
	{
		case WM_CREATE:            onCreate         (message); break;
		case WM_DESTROY:           onDestroy        (message); break;
		case WM_LBUTTONDOWN:       onMouseButtonDown(message); break;
		case WM_MBUTTONDOWN:       onMouseButtonDown(message); break;
		case WM_RBUTTONDOWN:       onMouseButtonDown(message); break;
		
		case WM_LBUTTONUP: //FALLTHRU
		case WM_MBUTTONUP: //FALLTHRU
		case WM_RBUTTONUP:
			onMouseButtonUp(message);
			break;
		
		case WM_MOUSEMOVE:
			onMouseMove(message.lParamLo+windowX, message.lParamHi+windowY);
			
			TRACKMOUSEEVENT ev;
			ev.cbSize = sizeof(ev);
			ev.dwFlags = TME_LEAVE;
			ev.hwndTrack = vwmWindow;
			ev.dwHoverTime = 100;
			_TrackMouseEvent(&ev);
			
			break;
		
		case WM_MOUSELEAVE:
			onMouseLeave();
			break;
		
		case WM_PAINT:             onPaint          (message); break;
		case WM_SYSCOMMAND:        onSysCommand     (message); break;
		case WM_TIMER:             onTimer          (message); break;
		case WM_DROPFILES:         onDropFiles      (message); break;
		case WM_WINDOWPOSCHANGING: onVWMPosChanging (message); break;
		
		case WM_DISPLAYCHANGE:
			setScreenSize(message.lParamLo, message.lParamHi);
			break;
		
		case WM_KEYDOWN:
		case WM_KEYUP:
		case WM_HOTKEY:
			PostMessage(parentWindow, message.uMsg, message.wParam, message.lParam);
			break;
			
		case WM_ENDSESSION:
		case WM_QUERYENDSESSION:
			message.lResult = SendMessage(parentWindow, message.uMsg, message.wParam, message.lParam);
			break;
		
		case LM_GETREVID:          onGetRevId       (message); break;
		case LM_REPAINT:           onPaint          (message); break;
		case LM_WINDOWACTIVATED:   onWindowActivated(message); break;
		case LM_BRINGTOFRONT:      onBringToFront   (message); break;
		case LM_SWITCHTON:         onSwitchToN      (message); break;
		case LM_LISTDESKTOPS:      onListDesktops   (message); break;
		case LM_GETDESKTOPOF:      onGetDesktopOf   (message); break;
		
		// TODO: Observe window *movement*, too
		case LM_WINDOWCREATED:
		case LM_WINDOWDESTROYED:
			if(updateWindowList())
				forceRedraw(false);
			break;
		
		default:
			message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);
			break;
	}
}

void VWM::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_BRINGTOFRONT, LM_SWITCHTON, LM_WINDOWACTIVATED, LM_LISTDESKTOPS, LM_GETDESKTOPOF, 0};

	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)msgs);

	// Unregister window hook
	HWND hookManager = FindWindow("HookMgrClass", NULL);
	SendMessage(hookManager, LM_UNREGISTERMESSAGE, (WPARAM)WM_WINDOWPOSCHANGED, (LPARAM)NULL);

	cleanupBangs();

	// Switch to desk 1 on exit
	// FIXME: This should be something considerably more elaborate
	switchDesk(0, true);
	
	//destroyWindow();

	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
		delete ii->second;
}

void VWM::onCreate(Message& message)
{
	//finalize();
}

void VWM::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);
	sprintf(buf, VERSION_STRING);
	message.lResult = strlen(buf);
}

void VWM::onMouseButtonDown(Message& message)
{
	int x = message.lParamLo;
	int y = message.lParamHi;
	
	/*VirtualDesktop *desk = panelPointToDesk(x, y);
	LayoutElement *clickedElement = NULL;
	
	if(desk)
	{
		if(desk->focused)
		{
			for(unsigned ii=0; ii<settings->focusedLayout.size(); ii++) {
				if(settings->focusedLayout[ii]->containsPoint(desk, x, y))
					clickedElement = settings->focusedLayout[ii];
			}
		} else {
			for(unsigned ii=0; ii<settings->deskLayout.size(); ii++) {
				if(settings->deskLayout[ii]->containsPoint(desk, x, y))
					clickedElement = settings->deskLayout[ii];
			}
		}
	} else {
		return;
	}
	
	WindowData *task = NULL;
	
	if(clickedElement && dynamic_cast<TasksElement*>(clickedElement)) {
		TasksElement *taskElement = dynamic_cast<TasksElement*>(clickedElement);
		task = taskElement->getTask(desk, x, y);
	}*/
	
	LayoutLocation layoutPos = elementAtPoint(x, y);
	VirtualDesktop *desk = layoutPos.desk;
	LayoutElement *element = layoutPos.element;
	WindowData *task = layoutPos.task;
	
	switch(message.uMsg)
	{
		case WM_RBUTTONDOWN:
		case WM_MBUTTONDOWN:
			// If a task was right-clicked on, open its system menu
			if(task)
			{
				POINT pos = taskToPoint(task);
				
				int xOffset=0, yOffset=0;
				// TODO: Put this back
				/*switch(settings->menuOpenDirection) {
					case directionUpLeft:    xOffset = task->desk->tasksIconArea; yOffset = 0;                         break;
					case directionUpRight:   xOffset = 0;                         yOffset = 0;                         break;
					case directionRightUp:   xOffset = task->desk->tasksIconArea; yOffset = 0;                         break;
					case directionRightDown: xOffset = task->desk->tasksIconArea; yOffset = task->desk->tasksIconArea; break;
					case directionDownLeft:  xOffset = task->desk->tasksIconArea; yOffset = task->desk->tasksIconArea; break;
					case directionDownRight: xOffset = 0;                         yOffset = task->desk->tasksIconArea; break;
					case directionLeftUp:    xOffset = 0;                         yOffset = 0;                         break;
					case directionLeftDown:  xOffset = 0;                         yOffset = task->desk->tasksIconArea; break;
				}*/
				
				pos.x += windowX + xOffset;
				pos.y += windowY + yOffset;
				
				DWORD msgPos = MAKELONG(pos.x, pos.y);
				raiseWindow(task);
				PostMessage(task->handle, 0x313, 0, msgPos);
			}
			// Switch to clicked-on desktop
			else if(desk)
				switchDesk(desk);
			break;
		
		case WM_LBUTTONDOWN: {
			bool startDrag = false;
			
			// Left button: If clicking on a window in a VWM, start dragging
			// that window. If clicking on a window in a task tray, switch to
			// that desktop, raise that window, and start dragging.
			
			if(task) {
				if(task->focused && !task->minimized)
				{
					// Clicking on the foreground task minimizes it unless you
					// move the mouse first
					pendingMinimize = task->handle;
					draggingTask = NULL;
					
					POINT taskIconPos = taskToPoint(task);
					diffPt.x = diffPt.y = layoutSettings->tasksIconSize/2;
					
					createDragIcon(x+windowX, y+windowY,
						task->getIcon(layoutSettings->tasksIconSize));
					break;
				}
				else
				{
					// Clicking on a task which isn't the foreground task focuses it
					// If it isn't minimized, it also starts a drag
					if(!task->minimized) {
						POINT clickPos = {x, y};
						POINT taskIconPos = taskToPoint(task);
						POINT dragOffset;
						dragOffset.x = dragOffset.y = layoutSettings->tasksIconSize/2;
						beginWindowDrag(task, false, clickPos, dragOffset);
					}
					switchDesk(task->desk, true);
					raiseWindow(task);
				}
			}
			else if(dynamic_cast<MinimapElement*>(element))
			{
				MinimapElement *minimap = dynamic_cast<MinimapElement*>(element);
				
				RECT minimapRect;
				minimap->getRect(desk, &minimapRect);
				
				task = minimap->getWindow(desk, x, y);
				
				if(task) {
					POINT dragOffset;
					POINT clickPos = {x, y};
					RECT windowRect = minimap->screenToMinimapPos(desk, task->screenPos);
					dragOffset.x = x - windowRect.left - minimapRect.left;
					dragOffset.y = y - windowRect.top - minimapRect.top;
					beginWindowDrag(task, true, clickPos, dragOffset);
				} else {
					switchDesk(desk, false);
				}
			}
			else if(desk)
			{
				switchDesk(desk, false);
			}
			
			break;
		}
	}
}

void VWM::onMouseButtonUp(Message& message)
{
	switch(message.uMsg)
	{
		case WM_RBUTTONUP:
			break;
		case WM_MBUTTONDOWN:  // Select desktop
			break;
		case WM_LBUTTONUP:  // Window dragging
			if(pendingMinimize) {
				if(windowsByHandle.find(pendingMinimize)!=windowsByHandle.end()) {
					WindowData *window = windowsByHandle[pendingMinimize];
					minimizeWindow(window);
					forceRedraw(true);
				}
				pendingMinimize = NULL;
			}
			else if(draggingTask)
				endDrag();
			break;
	}
}

/// Because we sometimes need to coordinate multiple windows, (x,y) is in
/// SCREEN coordinates, not window coordinates.
void VWM::onMouseMove(int x, int y)
{
	VirtualDesktop *hoveredDesk = panelPointToDesk(x, y);
	LayoutElement *hoveredElement = NULL;
	
	if(hoveredDesk)
	{
		if(hoveredDesk ->focused) {
			for(unsigned ii=0; ii<settings->focusedLayout.size(); ii++) {
				if(settings->focusedLayout[ii]->containsPoint(hoveredDesk, x, y))
					hoveredElement = settings->focusedLayout[ii];
			}
		} else {
			for(unsigned ii=0; ii<settings->deskLayout.size(); ii++) {
				if(settings->deskLayout[ii]->containsPoint(hoveredDesk, x, y))
					hoveredElement = settings->deskLayout[ii];
			}
		}
	}
	
	WindowData *hoveredTask = NULL;
	if(hoveredElement && dynamic_cast<TasksElement*>(hoveredElement)) {
		TasksElement *tasksElement = dynamic_cast<TasksElement*>(hoveredElement);
		hoveredTask = tasksElement->getTask(hoveredDesk, x-windowX, y-windowY);
	}
	
	// Display task-description tooltip
	if(!draggingTask && settings->showTaskWindow) {
		updateTaskWindow(hoveredTask);
	}
	
	// If you drag an icon off its foreground area, it goes from 'maybe
	// minimize this' to 'drag this'.
	if(pendingMinimize)
	{
		if(windowsByHandle.find(pendingMinimize) == windowsByHandle.end()) {
			// The window has disappeared/closed since we started!
			pendingMinimize = NULL;
		} else {
			// If we drag it off its original icon area, it becomes a drag/drop
			// instead of a click
			WindowData *window = windowsByHandle[pendingMinimize];
			if(window != hoveredTask) {
				POINT clickPos = {x-windowX, y-windowY};
				pendingMinimize = NULL;
				// This type of drag goes to desktops only; it doesn't affect
				// position within a desktop.
				beginWindowDrag(window, false, clickPos, diffPt);
			}
		}
	}
	
	if(draggingTask)
		continueWindowDrag(x-windowX, y-windowY);
}

void VWM::onMouseLeave()
{
	updateTaskWindow(NULL);
}

void VWM::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(parentWindow, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);
}

void VWM::onWindowActivated(Message& message)
{
}

void VWM::onTimer(Message& message)
{
	// Update the window list, checking what the foreground window is before
	// and after.
	HWND oldTopWindow = foregroundHandle;
	bool changed = updateWindowList();
	
	if(oldTopWindow!=foregroundHandle) {
		VirtualDesktop *newDesk = getDeskFromWnd(foregroundHandle);
		switchDesk(newDesk, true);
	}
	
	// Dirty the VWM display to force it to redraw
	// TODO: Only redraw when there are changes
	if(changed)
		forceRedraw(false);
}

// TODO: Test and rewrite this
void VWM::onDropFiles(Message& message)
{
	POINT pt;
	DragQueryPoint( (HDROP)message.wParam, &pt );
	
	VirtualDesktop *newDesk = panelPointToDesk(pt.x, pt.y);
	if(!newDesk) return;
	switchDesk(newDesk);

	int numFiles = DragQueryFile( (HDROP)message.wParam, 0xFFFFFFFF, NULL, 0 );
	for(int i=0; i<numFiles; i++)
	{
		char filename[_MAX_PATH];
		DragQueryFile( (HDROP)message.wParam, i, filename, _MAX_PATH);
		if (filename && *filename)
			LSExecute(NULL, filename, SW_SHOWNORMAL);
	}
	DragFinish( (HDROP)message.wParam );
	forceRedraw(true);
}

// TODO: Rewrite this
void VWM::onVWMPosChanging(Message& message)
{
	LPWINDOWPOS windowPos = (LPWINDOWPOS)message.lParam;

	if ( !( windowPos->flags & SWP_NOSIZE ) )
	{
		windowWidth = windowPos->cx;
		windowHeight = windowPos->cy;
	}

	if ( !( windowPos->flags & SWP_NOMOVE ) )
	{
		windowX = windowPos->x;
		windowY = windowPos->y;
	}
	message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);
}

void VWM::onBringToFront(Message &message)
{
	HWND hWnd = (HWND) message.lParam;
	VirtualDesktop *desk = getDeskFromWnd(hWnd);

	if (currentDesktop != desk)
		switchDesk(desk, true);

	SwitchToThisWindow(hWnd, TRUE);
	message.lResult = TRUE;
}

void VWM::onSwitchToN(Message &message)
{
	message.lResult = TRUE;
	int desk = (int) message.wParam;
	if(desk < 0 || desk >= (int)desktops.size())
		return;
	
	VirtualDesktop *newDesk = desktops[desk];
	switchDesk(newDesk, true);
}

void VWM::onListDesktops(Message &message)
{
	LSDESKTOPINFO deskInfo;

	for (unsigned ii = 0; ii < desktops.size(); ii++)
	{
		deskInfo.size = sizeof(LSDESKTOPINFO);
		deskInfo.icon = 0;
		deskInfo.isCurrent = desktops[ii]->focused;
		deskInfo.number = ii;
		
		string deskname = desktops[ii]->getName();
		strcpy(deskInfo.name, deskname.c_str());

		SendMessage((HWND) message.wParam, LM_DESKTOPINFO, 0, (LPARAM) &deskInfo);
	}

	message.lResult = TRUE;
}

void VWM::onGetDesktopOf(Message &message)
{
	VirtualDesktop *desk = getDeskFromWnd((HWND) message.wParam);
	message.lResult = desk->index;
}
