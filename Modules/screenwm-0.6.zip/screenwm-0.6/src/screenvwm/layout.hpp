/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once
#include <string>
using std::string;

struct VirtualDesktop;
struct WindowData;

enum Alignment
{
	alignCenter,
	alignLeft,
	alignRight,
	alignTop,
	alignBottom,
};
Alignment parseAlign(const string &str);

/////////////////////////////////////////////////////////////////////////////

class LayoutElement
{
public:
	LayoutElement(string prefix);
	virtual ~LayoutElement();
	virtual void draw(HDC drawContext, VirtualDesktop *desk);
	virtual bool containsPoint(VirtualDesktop *desk, int x, int y);
	virtual POINT updateSize(VirtualDesktop *desk, bool verticalLayout, int maxThickness);
	virtual void getRect(VirtualDesktop *desk, RECT *rect)=0;
	string toString() const;
	
	string prefix;
};

void parseElementList(const string &elements, vector<LayoutElement*> *elementList);
LayoutElement *getElement(string prefix);

/////////////////////////////////////////////////////////////////////////////

class TextLabelElement
	:public LayoutElement
{
public:
	TextLabelElement(string prefix);
	void draw(HDC drawContext, VirtualDesktop *desk);
	void getRect(VirtualDesktop *desk, RECT *rect);
	
protected:
	Alignment alignHoriz;
	Alignment alignVert;
	string x;
	string y;
	PaintText *font;
};

/////////////////////////////////////////////////////////////////////////////

class MinimapElement
	:public LayoutElement
{
public:
	MinimapElement(string prefix);
	void draw(HDC drawContext, VirtualDesktop *desk);
	bool containsPoint(VirtualDesktop *desk, int px, int py);
	WindowData *getWindow(VirtualDesktop *desk, int px, int py);
	void getRect(VirtualDesktop *desk, RECT *rect);
	RECT screenToMinimapPos(VirtualDesktop *desk, RECT screenPos, POINT *iconPos=NULL);
	
protected:
	string x, y, width, height;
};

/////////////////////////////////////////////////////////////////////////////

class TasksElement
	:public LayoutElement
{
public:
	TasksElement(string prefix);
	void draw(HDC drawContext, VirtualDesktop *desk);
	POINT updateSize(VirtualDesktop *desk, bool verticalLayout, int maxThickness);
	void getRect(VirtualDesktop *desk, RECT *rect);
	WindowData *getTask(VirtualDesktop *desk, int x, int y);
	bool containsPoint(VirtualDesktop *desk, int px, int py);
	
protected:
	pair<int,int> getDimensions(VirtualDesktop *desk);
	
	string configX, configY, configWidth, configHeight;
	int iconSize, iconArea;
	
	//int width, height;
	//int numRows, numCols;
};

/////////////////////////////////////////////////////////////////////////////

class TextureElement
	:public LayoutElement
{
public:
	TextureElement(string prefix);
	void draw(HDC drawContext, VirtualDesktop *desk);
	bool containsPoint(VirtualDesktop *desk, int px, int py);
	void getRect(VirtualDesktop *desk, RECT *rect);
	
protected:
	string x, y, width, height;
	PaintTexture *texture;
};

/////////////////////////////////////////////////////////////////////////////

struct LayoutLocation
{
	LayoutElement *element;
	VirtualDesktop *desk;
	WindowData *task;
};
