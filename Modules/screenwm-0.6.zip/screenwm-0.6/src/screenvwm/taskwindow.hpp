#pragma once

class TaskWindow
{
public:
	TaskWindow();
	~TaskWindow();
	
	void hide();
	void show(int x, int y);
	void setTask(WindowData *task);
	bool isHidden();
	
	int getWidth();
	int getHeight();
	
	void windowProc(unsigned msg, WPARAM wParam, LPARAM lParam, LRESULT *result);
	
private:
	void onPaint(unsigned msg, WPARAM wParam, LPARAM lParam);

	void createWindow();
	void destroyWindow();
	static void registerWindowClass();
	static void unregisterWindowClass();
	
	friend LRESULT CALLBACK taskWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	
	int width, height;
	WindowData *task;
	HWND window;
	bool hidden;
};

