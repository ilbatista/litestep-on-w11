/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "vwm.h"

VirtualDesktop *VWM::findDeskNoFallback(const char *deskName, VirtualDesktop *relativeTo)
{
	if(!deskName || !*deskName)
		return NULL;
	
		if(isdigit(*deskName)) {
		int index = atoi(deskName) - 1;
		if(index < 0 || index >= (int)desktops.size())
			return NULL;
		else
			return desktops[index];
	}
	
	if(!stricmp(deskName, "current"))
	{
		return currentDesktop;
	}
	else if(!stricmp(deskName, "next")
	     || !stricmp(deskName, "down")
	     || !stricmp(deskName, "right"))
	{
		if(relativeTo->index+1 < (int)desktops.size())
			return desktops[relativeTo->index+1];
		else
			return NULL;
	}
	else if(!stricmp(deskName, "prev")
	     || !stricmp(deskName, "up")
	     || !stricmp(deskName, "left"))
	{
		if(relativeTo->index > 0)
			return desktops[relativeTo->index-1];
		else
			return NULL;
	}
	else if(!stricmp(deskName, "first"))
	{
		return desktops[0];
	}
	else if(!stricmp(deskName, "last"))
	{
		return desktops[desktops.size()-1];
	}
	else if(!stricmp(deskName, "other"))
	{
		if(lastDesktop != currentDesktop)
			return lastDesktop;
		else
			return NULL;
	}
	else if(!stricmp(deskName, "newfirst"))
	{
		VirtualDesktop *newDesk = new VirtualDesktop(0, storageManager.getStorageArea());
		desktops.insert(desktops.begin(), newDesk);
		for(int ii=1; ii<(int)desktops.size(); ii++)
			desktops[ii]->index = ii;
		return newDesk;
	}
	else if(!stricmp(deskName, "newlast"))
	{
		VirtualDesktop *newDesk = new VirtualDesktop(desktops.size(), storageManager.getStorageArea());
		desktops.push_back(newDesk);
		return newDesk;
	}
	else if(!stricmp(deskName, "newnext"))
	{
		VirtualDesktop *newDesk = new VirtualDesktop(currentDesktop->index+1, storageManager.getStorageArea());
		desktops.insert(desktops.begin()+currentDesktop->index+1, newDesk);
		for(int ii=currentDesktop->index; ii<(int)desktops.size(); ii++)
			desktops[ii]->index = ii;
		return newDesk;
	}
	else if(!stricmp(deskName, "newprev"))
	{
		VirtualDesktop *newDesk = new VirtualDesktop(currentDesktop->index, storageManager.getStorageArea());
		desktops.insert(desktops.begin()+currentDesktop->index, newDesk);
		for(int ii=currentDesktop->index; ii<(int)desktops.size(); ii++)
			desktops[ii]->index = ii;
		return newDesk;
	}
	
	for(unsigned ii = 0; ii < desktops.size(); ii++)
	{
		if (!stricmp(deskName, desktops[ii]->getName().c_str()))
			return desktops[ii];
	}

	return NULL;
}

/// Find a desktop given a string description of it. The string can be a
/// name, number, or direction (the directions are: left, right, up, down,
/// next, prev). Directions are relative to relativeTo, which is the
/// current desktop if not specified.
VirtualDesktop *VWM::findDesk(const char *deskName, VirtualDesktop *relativeTo)
{
	VirtualDesktop *ret = NULL;
	
	if(!deskName || !*deskName)
		deskName = "";
	if(!relativeTo)
		relativeTo = currentDesktop;
		
	char *tokenizedString = strdup(deskName);
	char *token = strtok(tokenizedString, "/");
	do {
		VirtualDesktop *desk = findDeskNoFallback(token, relativeTo);
		if(desk) {
			ret = desk;
			break;
		}
	} while((token = strtok(NULL, "/")));
	
	if(!ret)
	{
		// Specified options didn't work
		// Fallback is next/prev/current
		if(relativeTo->index+1 < (int)desktops.size())
			ret = desktops[relativeTo->index+1];
		else if(relativeTo->index > 0)
			ret = desktops[relativeTo->index-1];
		else
			ret = currentDesktop;
	}
	
	free(tokenizedString);
	return ret;
}
