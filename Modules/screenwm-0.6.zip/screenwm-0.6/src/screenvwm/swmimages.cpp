/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <litestep/lsapi/lsapi.h>
#include "vwm.h"
#include "swmimages.hpp"
#include "trace.hpp"

RelCoord::RelCoord()
	: val("") {}
RelCoord::RelCoord(string str)
	: val(str) {}

int RelCoord::get(int maxVal)
{
	return ParseCoordinate(val.c_str(), 0, maxVal);
}

SWMImage::~SWMImage()
{
	DeleteObject(image);
}

void SWMImageManager::loadImages()
{
	FILE *f = LCOpen(NULL);
	if(f) {
		char buffer[4096];
		buffer[0] = 0;

		while(LCReadNextConfig(f, "*SWMImage", buffer, sizeof (buffer)))
			parseLine(buffer);
		
		LCClose(f);
	}
}

int SWMImageManager::parseMode(const char *mode)
{
	// TODO: Image modes
	return 0;
}

void SWMImageManager::parseLine(const char *buf)
{
	// *SWMImage group mode left top right bottom filename
	char commandToken[4096] = "",
	     groupToken  [4096] = "",
	     modeToken   [4096] = "",
	     leftToken   [4096] = "",
	     topToken    [4096] = "",
	     rightToken  [4096] = "",
	     bottomToken [4096] = "",
	     filenameToken[4096]= "",
	     extraText   [4096] = "";
	char *format[8] = {commandToken, groupToken, modeToken, leftToken,
	                   topToken, rightToken, bottomToken, filenameToken};
	
	int tokens = LCTokenize(buf, format, 8, extraText);
	if(tokens != 8) {
		trace << "*SWMImage has wrong number of parameters.\n";
		return;
	}
	
	HBITMAP bitmap = LoadLSImage(filenameToken, NULL);
	
	if(!bitmap) {
		trace << "Failed to load image '"<<filenameToken<<"'.\n";
		return;
	}
	
	int width, height;
	GetLSBitmapSize(bitmap, &width, &height);
	
	SWMImage *img = new SWMImage();
	img->image = bitmap;
	img->filename = filenameToken;
	img->width = width;
	img->height = height;
	img->mode = parseMode(modeToken);
	img->left = RelCoord(leftToken);
	img->top = RelCoord(topToken);
	img->right = RelCoord(rightToken);
	img->bottom = RelCoord(bottomToken);
	
	
	string group = groupToken;
	if(imageSets.find(group)==imageSets.end())
		imageSets[group] = new vector<SWMImage*>();
	vector<SWMImage*> *imageSet = imageSets[group];
	
	imageSet->push_back(img);
}

void SWMImageManager::destroyImages()
{
	for(map<string, vector<SWMImage*>*>::iterator ii=imageSets.begin(); ii!=imageSets.end(); ii++)
	{
		for(vector<SWMImage*>::iterator jj=ii->second->begin(); jj!=ii->second->end(); jj++)
			delete *jj;
		
		delete ii->second;
	}
	
	imageSets.clear();
}

bool SWMImageManager::drawImages(HDC drawContext, RECT area, string areaName)
{
	if(imageSets.find(areaName) == imageSets.end())
		return false;
	vector<SWMImage*> *images = imageSets[areaName];
	
	int areaWidth = area.right - area.left;
	int areaHeight = area.bottom - area.top;
	
	HDC blitter = CreateCompatibleDC(drawContext);
	
	BLENDFUNCTION alphaFunc;
		alphaFunc.BlendOp = AC_SRC_OVER;
		alphaFunc.BlendFlags = 0;
		alphaFunc.AlphaFormat = AC_SRC_ALPHA;
		alphaFunc.SourceConstantAlpha = 255;
	
	for(unsigned ii=0; ii<images->size(); ii++)
	{
		SWMImage *img = (*images)[ii];
		
		int left   = area.left + img->left  .get(areaWidth);
		int right  = area.left + img->right .get(areaWidth);
		int top    = area.top  + img->top   .get(areaHeight);
		int bottom = area.top  + img->bottom.get(areaHeight);
		
		int width = right-left;
		int height = bottom-top;
		
		SelectObject(blitter, img->image);
		
		//AlphaBlend(drawContext,left,top, width, height, blitter, 0, 0, img->width, img->height, alphaFunc);
		TransparentBlt(drawContext,left,top, width, height, blitter, 0, 0, img->width, img->height, 0xff00ff);
	}
	
	DeleteObject(blitter);
	return true;
}
