/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once
#include <vector>
using std::vector;
#include <string>
using std::string;
#include "wrappingflow.hpp"
#include "xExports.h"
#include "layout.hpp"

const char *const defaultSettingPrefix = "swm";

struct LayoutSettings;
struct RCSettings;

struct LayoutSettings
{
public:
	// Initialize to defaults
	LayoutSettings(RCSettings *baseSettings);
	// Initialize from variables. defaults is a LayoutSettings that will be
	// copied for any variables not provided. fallbackIndex is a suffix added
	// to each variable name (no suffix if fallbackIndex<=1);
	LayoutSettings(LayoutSettings *defaults, int fallbackIndex);
	bool hasNonDefault;
	
	// Internal layout
	int panelRows;
	int tasksIconSize;
	int tasksBorderThickness;
	
	int deskBaseSize;
	
private:
	char *suffix;
	int getInt(const char *name, int defaultValue);
	string getString(const char *name, const string &defaultValue);
	bool getBool(const char *title, BOOL valueIfFound, bool defaultValue);
};
LayoutSettings impliedLayoutFallback(const LayoutSettings &last);

void loadDefaultSettings();
bool rcIsDefined(const char *name);
bool rcIsDefined(const char *name, const char *prefix);

// There are two settings of config-getting functions here, one with default
// values and one without. If no default value is provided, the setting must
// be defined (otherwise, an error dialog will pop up). Base settings may be
// defined in the default-config file, so undefined-config errors should only
// pop up in vars with calculated names.
int getConfigInt(const char *name, const char *prefix=defaultSettingPrefix);
float getConfigFloat(const char *name, const char *prefix=defaultSettingPrefix);
COLORREF getConfigColor(const char *name, const char *prefix=defaultSettingPrefix);
int getConfigCoord(const char *name, int limit, const char *prefix=defaultSettingPrefix);
bool getConfigBool(const char *name, const char *prefix=defaultSettingPrefix);

int getConfigInt(const char *name, int defaultValue, const char *prefix=defaultSettingPrefix);
float getConfigFloat(const char *name, float defaultValue, const char *prefix=defaultSettingPrefix);
COLORREF getConfigColor(const char *name, int r, int g, int b, const char *prefix=defaultSettingPrefix);
string getConfigString(const char *name, const char *defaultValue=NULL, const char *prefix=defaultSettingPrefix);
string getConfigLine(const char *name, const char *defaultValue=NULL, const char *prefix=defaultSettingPrefix);
int getConfigCoord(const char *name, int defaultValue, int limit, const char *prefix=defaultSettingPrefix);
bool getConfigBool(const char *name, bool defaultValue, const char *prefix=defaultSettingPrefix);

void setConfigInt(const char *varname, int value, const char *prefix=defaultSettingPrefix);
void setConfigLine(const char *varname, const char *value, const char *prefix=defaultSettingPrefix);
void setConfigBool(const char *varname, bool value, const char *prefix=defaultSettingPrefix);


struct RCSettings
{
public:
	~RCSettings();
	void refresh(bool inWharf);
	
	vector<LayoutSettings> layoutSettings;
	
	// Position
	int panelX;
	int panelY;
	int panelWidth;
	int panelHeight;
	int reservedSize;
	
	// Behavior settings
	bool switchDeskWithDrag;
	bool keepEmptyDesktops;
	bool keepEmptyFocusedDesktop;
	bool dragCreatesDesks;
	bool minimizeOnClick;
	bool autoGather;
	FlowDirection menuOpenDirection;
	bool showTaskWindow;
	int pollInterval;
	
	// Layout settings
	vector<LayoutElement*> deskLayout;
	vector<LayoutElement*> focusedLayout;
	
	// Minimap settings
	int minimapTitleBarsThickness;
	int minimapIconSize;
	
	// Task display settings
	FlowDirection flowDirection;
	float tasksOffsetX;
	float tasksOffsetY;
	float tasksOffsetXMin;
	float tasksOffsetYMin;
	float tasksOffsetXFocused;
	float tasksOffsetYFocused;
	bool tasksIconTransparent;
	bool tasksIconTransparentFocused;
	bool tasksIconTransparentMin;
	
	// Visibility settings
	bool visible;
	bool onTop;
	int autoHideDistance;
	
	// XPaintClass painting options
	PaintTexture *panelBackground;
	
	// Colors
	COLORREF vwmWindowColor;
	COLORREF vwmTitleBarColor;
	COLORREF vwmFocusedTitleBarColor;
	COLORREF vwmWindowBorderColor;
	COLORREF tasksBackColor;
	COLORREF tasksBackColorMin;
	COLORREF tasksBackColorFocused;
	COLORREF tasksBorderColor;
	COLORREF tasksBorderColorMin;
	COLORREF tasksBorderColorFocused;
};

extern RCSettings *settings;

