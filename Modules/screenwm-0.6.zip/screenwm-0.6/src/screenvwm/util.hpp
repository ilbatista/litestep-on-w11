#pragma once
#include <string>
using std::string;

void warn(const char *warning);
