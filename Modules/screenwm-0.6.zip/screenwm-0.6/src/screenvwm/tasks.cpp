/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "vwm.h"
#include "util.hpp"
#include "trace.hpp"

TasksElement::TasksElement(string prefix)
	:LayoutElement(prefix)
{
	configX = getConfigString("X", "68", prefix.c_str());
	configY = getConfigString("Y", "0", prefix.c_str());
	configWidth = getConfigString("Width", "32", prefix.c_str());
	configHeight = getConfigString("Height", "32", prefix.c_str());
	
	updateSize(NULL, directionIsVertical(settings->flowDirection), 256);
}

void TasksElement::draw(HDC backBuffer, VirtualDesktop *desk)
{
	HBRUSH normalBrush = CreateSolidBrush(settings->tasksBackColor);
	HBRUSH minimizedBrush = CreateSolidBrush(settings->tasksBackColorMin);
	HBRUSH focusedBrush = CreateSolidBrush(settings->tasksBackColorFocused);
	
	HPEN normalPen = CreatePen(PS_SOLID, vwm->layoutSettings->tasksBorderThickness, settings->tasksBorderColor);
	HPEN minimizedPen = CreatePen(PS_SOLID, vwm->layoutSettings->tasksBorderThickness, settings->tasksBorderColorMin);
	HPEN focusedPen = CreatePen(PS_SOLID, vwm->layoutSettings->tasksBorderThickness, settings->tasksBorderColorFocused);
	
	HBRUSH oldBrush = (HBRUSH)SelectObject(backBuffer, normalBrush);
	HPEN oldPen = (HPEN)SelectObject(backBuffer, normalPen);
	
	int row;
	int col;
	
	pair<int,int> dimensions = getDimensions(desk);
	int numCols = dimensions.first;
	int numRows = dimensions.second;
	
	WrappingFlow flow(settings->flowDirection, 0, 0, numCols-1, numRows-1);
	flow.start(col, row);
	
	for(unsigned jj=0; jj<desk->tasks.size(); jj++)
	{
		WindowData *task = desk->tasks[jj];
		
		int drawX = desk->panelX + ParseCoordinate(configX.c_str(), 0, desk->panelWidth) + iconArea * col;
		int drawY = desk->panelY + ParseCoordinate(configY.c_str(), 0, desk->panelHeight) + iconArea * row;
		float offsetX, offsetY;
		bool transparent;
		
		IntersectClipRect(backBuffer, drawX, drawY, drawX+iconArea, drawY+iconArea);
		
		if(task->minimized) {
			SelectObject(backBuffer, minimizedBrush);
			SelectObject(backBuffer, minimizedPen);
			offsetX = settings->tasksOffsetXMin;
			offsetY = settings->tasksOffsetYMin;
			transparent = settings->tasksIconTransparentMin;
		}
		else if(task->focused || task->handle==vwm->draggingTask || task->handle==vwm->pendingMinimize)
		{
			SelectObject(backBuffer, focusedBrush);
			SelectObject(backBuffer, focusedPen);
			offsetX = settings->tasksOffsetXFocused;
			offsetY = settings->tasksOffsetYFocused;
			transparent = settings->tasksIconTransparentFocused;
		}
		else
		{
			SelectObject(backBuffer, normalBrush);
			SelectObject(backBuffer, normalPen);
			offsetX = settings->tasksOffsetX;
			offsetY = settings->tasksOffsetY;
			transparent = settings->tasksIconTransparent;
		}
		
		if(transparent)
			SetBkMode(backBuffer, TRANSPARENT);
		else
			Rectangle(backBuffer, drawX, drawY, drawX+iconArea, drawY+iconArea);
		
		// Don't draw the icon for a task which is being dragged
		if(task->handle != vwm->draggingTask && task->handle != vwm->pendingMinimize)
		{
			HICON icon = task->getIcon(iconSize);
			
			DrawIconEx(backBuffer,
				drawX + vwm->layoutSettings->tasksBorderThickness + offsetX*vwm->layoutSettings->tasksIconSize,
				drawY + vwm->layoutSettings->tasksBorderThickness + offsetY*vwm->layoutSettings->tasksIconSize,
				icon,
				iconSize, iconSize,
				0, NULL, DI_NORMAL);
		}
		
		SelectClipRgn(backBuffer, NULL);
		
		flow.next(col, row, 1, 1);
	}
	
	SelectObject(backBuffer, oldPen);
	SelectObject(backBuffer, oldBrush);
	
	DeleteObject(normalBrush);
	DeleteObject(minimizedBrush);
	DeleteObject(focusedBrush);
	DeleteObject(normalPen);
	DeleteObject(minimizedPen);
	DeleteObject(focusedPen);
}

POINT TasksElement::updateSize(VirtualDesktop *desk, bool verticalLayout, int maxThickness)
{
	LayoutSettings *layoutSettings = vwm->layoutSettings;
	if(!layoutSettings && settings->layoutSettings.size() > 0)
		layoutSettings = &settings->layoutSettings[0];
	
	int borderThickness = layoutSettings->tasksBorderThickness;
	
	iconArea = min(layoutSettings->tasksIconSize + 2*borderThickness, maxThickness);
	iconSize = iconArea - 2*borderThickness;
	
	if(!desk) {
		POINT ret={0,0};
		return ret;
	}
	
	pair<int,int> dimensions = getDimensions(desk);
	int width = iconArea * dimensions.first;
	int height = iconArea * dimensions.second;
	
	if(verticalLayout) {
		POINT ret = {0, height};
		return ret;
	} else {
		POINT ret = {width, 0};
		return ret;
	}
}

bool TasksElement::containsPoint(VirtualDesktop *desk, int x, int y)
{
	RECT rect;
	getRect(desk, &rect);
	POINT pt = {x, y};
	return PtInRect(&rect, pt);
}

void TasksElement::getRect(VirtualDesktop *desk, RECT *rect)
{
	pair<int,int> dimensions = getDimensions(desk);
	int width = iconArea * dimensions.first;
	int height = iconArea * dimensions.second;
	
	rect->left = desk->panelX + ParseCoordinate(configX.c_str(), 0, desk->panelWidth);
	rect->top = desk->panelY + ParseCoordinate(configY.c_str(), 0, desk->panelHeight);
	rect->right = rect->left + width;
	rect->bottom = rect->top + height;
}

WindowData *TasksElement::getTask(VirtualDesktop *desk, int px, int py)
{
	pair<int,int> dimensions = getDimensions(desk);
	int numCols = dimensions.first;
	int numRows = dimensions.second;
	int width = iconArea * dimensions.first;
	int height = iconArea * dimensions.second;
	
	px -= desk->panelX + ParseCoordinate(configX.c_str(), 0, desk->panelWidth);
	py -= desk->panelY + ParseCoordinate(configY.c_str(), 0, desk->panelHeight);
	if(px<0 || px>width || py<0 || py>height)
		return NULL;
	
	int row = py / iconArea;
	int col = px / iconArea;
	int taskNum = directionCountSteps(settings->flowDirection, col, row, 0, 0,
		numCols-1, numRows-1, 1, 1);
	
	if(taskNum >= 0 && taskNum < (int)desk->tasks.size())
		return desk->tasks[taskNum];
	else
		return NULL;
	
	return NULL;
}

pair<int,int> TasksElement::getDimensions(VirtualDesktop *desk)
{
	int maxThickness;
	if(desk->panelWidth > desk->panelHeight)
		maxThickness = desk->panelHeight;
	else
		maxThickness = desk->panelWidth;
	
	int numRows = maxThickness / iconArea;
	int numCols = (desk->tasks.size() + numRows - 1) / numRows;
	
	if(directionIsVertical(settings->flowDirection))
		swap(numRows, numCols);
	
	return pair<int,int>(numCols, numRows);
}

