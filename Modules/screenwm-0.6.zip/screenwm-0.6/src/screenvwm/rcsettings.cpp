/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include <math.h>
#include "vwm.h"
#include "rcsettings.hpp"
#include "trace.hpp"
#include "paintclass.hpp"
#include "util.hpp"
#pragma warning (disable: 4800)

static vector<LayoutSettings> layoutSettings;
RCSettings *settings;

extern const char *defaultSettings;

void loadDefaultSettings()
{
	char *copy = strdup(defaultSettings);
	char *pos = strtok(copy, "\n");
	
	do {
		char *line = strdup(pos);
		
		// Separate the line into a varname portion and a value portion
		char *varname = line;
		while(isspace(*varname))
			varname++;
		if(!*varname)
			continue;
		
		char *linepos = line;
		while(*linepos && !isspace(*linepos))
			linepos++;
		if(*linepos) {
			*linepos = 0;
			linepos++;
		}
		while(*linepos && isspace(*linepos))
			linepos++;
		char *value = linepos;
		
		if(!rcIsDefined(varname))
			LSSetVariable(varname, value);
		
		free(line);
	} while(pos = strtok(NULL, "\n"));
	
	free(copy);
}

bool rcIsDefined(const char *name)
{
	if(GetRCLine(name, NULL, 0, NULL))
		return true;
	else
		return false;
}

bool rcIsDefined(const char *name, const char *prefix)
{
	string varname = string(prefix) + name;
	if(GetRCLine(varname.c_str(), NULL, 0, NULL))
		return true;
	else
		return false;
}

static string findRCSetting(const char *name, const char *prefix)
{
	string ret = string(prefix) + name;
	if(!rcIsDefined(ret.c_str())) {
		string warning = string("Undefined configuration option: ") + ret;
		warn(warning.c_str());
	}
	return ret;
}
static string findDefaultableRCSetting(const char *name, const char *prefix)
{
	string ret = string(prefix) + name;
	return ret;
}

int getConfigInt(const char *name, const char *prefix)
{
	string fullName = findRCSetting(name, prefix);
	return GetRCInt(fullName.c_str(), 0);
}
int getConfigInt(const char *name, int defaultValue, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	return GetRCInt(fullName.c_str(), defaultValue);
}
float getConfigFloat(const char *name, const char *prefix)
{
	string val = getConfigString(name, NULL, prefix);
	return atof(val.c_str());
}
float getConfigFloat(const char *name, float defaultValue, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	if(rcIsDefined(fullName.c_str())) {
		string val = getConfigString(fullName.c_str());
		return atof(val.c_str());
	} else {
		return defaultValue;
	}
}
COLORREF getConfigColor(const char *name, const char *prefix)
{
	string fullName = findRCSetting(name, prefix);
	return GetRCColor(fullName.c_str(), 0);
}
COLORREF getConfigColor(const char *name, int r, int g, int b, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	COLORREF defaultVal = ((r<<16) + (g<<8) + b);
	return GetRCColor(fullName.c_str(), defaultVal);
}
string getConfigString(const char *name, const char *defaultValue, const char *prefix)
{
	string fullName;
	if(defaultValue)
		fullName = findDefaultableRCSetting(name, prefix);
	else
		fullName = findRCSetting(name, prefix);
	
	char buf[4096];
	GetRCString(fullName.c_str(), buf, defaultValue, 4096);
	return buf;
}
string getConfigLine(const char *name, const char *defaultValue, const char *prefix)
{
	string fullName;
	if(defaultValue)
		fullName = findDefaultableRCSetting(name, prefix);
	else
		fullName = findRCSetting(name, prefix);
	
	char buf[4096];
	GetRCLine(fullName.c_str(), buf, 4096, defaultValue);
	return buf;
}
int getConfigCoord(const char *name, int limit, const char *prefix)
{
	string fullName = findRCSetting(name, prefix);
	return GetRCCoordinate(fullName.c_str(), 0, limit);
}
int getConfigCoord(const char *name, int defaultValue, int limit, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	return GetRCCoordinate(fullName.c_str(), defaultValue, limit);
}
bool getConfigBool(const char *name, const char *prefix)
{
	string fullName = findRCSetting(name, prefix);
	return GetRCBoolDef(fullName.c_str(), FALSE);
}
bool getConfigBool(const char *name, bool defaultValue, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	return GetRCBoolDef(fullName.c_str(), defaultValue);
}

void setConfigInt(const char *varname, int value, const char *prefix)
{
	string varFullName = string(prefix)+varname;
	char valueStr[32];
	sprintf(valueStr, "%i", value);
	LSSetVariable(varFullName.c_str(), valueStr);
}
void setConfigLine(const char *varname, const char *value, const char *prefix)
{
	string varFullName = string(prefix)+varname;
	LSSetVariable(varFullName.c_str(), value);
}
void setConfigBool(const char *varname, bool value, const char *prefix)
{
	string varFullName = string(prefix)+varname;
	LSSetVariable(varFullName.c_str(), value?"true":"false");
}



LayoutSettings::LayoutSettings(RCSettings *baseSettings)
{
	// Defaults
	panelRows = 1;
	tasksIconSize = 32;
	tasksBorderThickness = 0;
	deskBaseSize = 40;
}

LayoutSettings::LayoutSettings(LayoutSettings *defaults, int fallbackIndex)
{
	char suffixBuf[64];
	if(fallbackIndex > 1)
		sprintf(suffixBuf, "%i", fallbackIndex);
	else
		*suffixBuf = 0;
	suffix = suffixBuf;
	hasNonDefault = false;
	
	panelRows            = getInt("swmPanelNumRows",         defaults->panelRows);
	tasksIconSize        = getInt("swmTasksIconSize",        defaults->tasksIconSize);
	tasksBorderThickness = getInt("swmTasksBorderThickness", defaults->tasksBorderThickness);
	deskBaseSize         = getInt("swmDeskBaseSize",         defaults->deskBaseSize);
}

int LayoutSettings::getInt(const char *title, int defaultValue)
{
	if(rcIsDefined(suffix, title))
		hasNonDefault = true;
	return getConfigInt(suffix, defaultValue, title);
}

string LayoutSettings::getString(const char *title, const string &defaultValue)
{
	if(rcIsDefined(suffix, title))
		hasNonDefault = true;
	return getConfigString(suffix, defaultValue.c_str(), title);
}

bool LayoutSettings::getBool(const char *title, BOOL valueIfFound, bool defaultValue)
{
	if(rcIsDefined(suffix, title))
		hasNonDefault = true;
	return getConfigBool(suffix, defaultValue, title);
}

LayoutSettings impliedLayoutFallback(const LayoutSettings &last)
{
	LayoutSettings ret(last);
	ret.panelRows++;
	return ret;
}

RCSettings::~RCSettings()
{
}

void RCSettings::refresh(bool inWharf)
{
	char buf[512];
	
	// Position
	panelX = getConfigCoord("X", GetSystemMetrics(SM_CXSCREEN));
	panelY = getConfigCoord("Y", GetSystemMetrics(SM_CYSCREEN));
	panelWidth  = getConfigCoord("Width",  GetSystemMetrics(SM_CXSCREEN));
	panelHeight = getConfigCoord("Height", GetSystemMetrics(SM_CYSCREEN));
	
	// Behavior settings
	switchDeskWithDrag      = getConfigBool("SwitchDeskWithDrag");
	keepEmptyDesktops       = getConfigBool("KeepEmptyDesktops");
	keepEmptyFocusedDesktop = getConfigBool("KeepEmptyFocusedDesktop");
	dragCreatesDesks        = getConfigBool("DragCreatesDesks");
	minimizeOnClick         = getConfigBool("MinimizeOnClick");
	autoGather              = getConfigBool("AutoGather");
	showTaskWindow          = getConfigBool("ShowTaskWindow");
	menuOpenDirection = directionFromString(getConfigString("MenuDirection").c_str());
	
	pollInterval = getConfigInt("PollInterval");
	if(pollInterval && pollInterval < 10) pollInterval = 10;
	
	// Layout settings
	layoutSettings.clear();
	LayoutSettings defaults(this);;
	for(int ii=0; ; ii++) {
		LayoutSettings *prev = (ii>0) ? &layoutSettings[ii-1] : &defaults;
		LayoutSettings next(prev, ii+1);
		if(ii && !next.hasNonDefault)
			break;
		layoutSettings.push_back(next);
	}
	
	// Desk display settings
	parseElementList(getConfigLine("DeskElements"), &deskLayout);
	parseElementList(getConfigLine("FocusedElements"), &focusedLayout);
	
	// Minimap display settings
	minimapTitleBarsThickness = getConfigBool("MinimapTitleBars") ? getConfigInt("MinimapTitleBarThickness") : 0;
	minimapIconSize = getConfigInt("MinimapIconSize");
	if(!getConfigBool("MinimapTitleBars"))
		minimapTitleBarsThickness = 0;
	if(!getConfigBool("MinimapIcons"))
		minimapIconSize = 0;
	
	// Task display settings
	const char *defaultFlowDirection = (panelWidth >= panelHeight) ? "right" : "down";
	GetRCLine("swmTasksFlowDirection", buf, 512, defaultFlowDirection);
	flowDirection = directionFromString(buf);
	
	tasksOffsetX = getConfigFloat("TasksIconOffsetX");
	tasksOffsetY = getConfigFloat("TasksIconOffsetY");
	tasksOffsetXMin = getConfigFloat("TasksIconOffsetXMin");
	tasksOffsetYMin = getConfigFloat("TasksIconOffsetYMin");
	tasksOffsetXFocused = getConfigFloat("TasksIconOffsetXFocused");
	tasksOffsetYFocused = getConfigFloat("TasksIconOffsetYFocused");
	
	tasksIconTransparent = getConfigBool("TasksIconTransparent");
	tasksIconTransparentFocused = getConfigBool("TasksIconTransparentFocused");
	tasksIconTransparentMin = getConfigBool("TasksIconTransparentMin");
	
	// Visibility settings
	visible = inWharf || GetRCBool("swmHidden", FALSE);
	onTop = !inWharf && GetRCBool("swmAlwaysOnTop", TRUE);
	if(inWharf && GetRCBool("swmAutoHide", TRUE))
		autoHideDistance = GetRCInt("swmAutoHideDistance", 10);
	else
		autoHideDistance = 0;
	
	// Draw settings
	PaintTextureDefaults panelBackgroundDefault;
		panelBackgroundDefault.m_iPaintingMode = PAINTMODE_COLOR;
		panelBackgroundDefault.m_strColors = "d4d0c8";
	panelBackground = Create_xTextureClass();
	panelBackground->configure("swm", "Panel", 0, NULL, &panelBackgroundDefault);
	
	// Color settings
	vwmWindowColor          = getConfigColor("MinimapWinColor");
	vwmTitleBarColor        = getConfigColor("MinimapTitleBarColor");
	vwmFocusedTitleBarColor = getConfigColor("MinimapFocusedTitleBarColor");
	vwmWindowBorderColor    = getConfigColor("MinimapWinBorderColor");
	tasksBackColor          = getConfigColor("TasksBackColor");
	tasksBackColorMin       = getConfigColor("TasksBackColorMin");
	tasksBackColorFocused   = getConfigColor("TasksBackColorFocused");
	tasksBorderColor        = getConfigColor("TasksBorderColor");
	tasksBorderColorMin     = getConfigColor("TasksBorderColorMin");
	tasksBorderColorFocused = getConfigColor("TasksBorderColorFocused");
}
