/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "vwm.h"
#include "taskwindow.hpp"

void VWM::updateTaskWindow(WindowData *task)
{
	if(!task) {
		if(taskWindow && !taskWindow->isHidden())
			taskWindow->hide();
		return;
	}
	
	if(!taskWindow)
		taskWindow = new TaskWindow();
	
	taskWindow->setTask(task);
	
	POINT pos = taskToPoint(task);
		pos.x += windowX;
		pos.y += windowY;
	int width = taskWindow->getWidth();
	int height = taskWindow->getHeight();
	int buttonWidth = layoutSettings->tasksIconSize;
	int buttonHeight = layoutSettings->tasksIconSize;
	
	// Push off of wharf area
	switch(settings->menuOpenDirection) {
		case directionRightUp:
			pos.y += buttonHeight - height;
			// FALLTHRU
		case directionRightDown:
			if(pos.x+width >= windowX && pos.x < windowX+windowWidth)
				pos.x = windowX + windowWidth;
			break;
			
		case directionLeftUp:
			pos.y += buttonHeight - height;
			// FALLTHRU
		case directionLeftDown:
			if(pos.x+width >= windowX && pos.x < windowX+windowWidth)
				pos.x = windowX - width;
			break;
			
		case directionUpLeft:
			pos.x += buttonWidth - width;
			// FALLTHRU
		case directionUpRight:
			if(pos.y+height >= windowY && pos.y < windowY+windowHeight)
				pos.y = windowY - height;
			break;
			
		case directionDownLeft:
			pos.x += buttonWidth - width;
			// FALLTHRU
		case directionDownRight:
			if(pos.y+height >= windowY && pos.y < windowY+windowHeight)
				pos.y = windowY + windowHeight;
			break;
	}
	
	// Push into screen area
	if(pos.x+width > screenWidth)
		pos.x = screenWidth - width;
	if(pos.y+height > screenHeight)
		pos.y = screenHeight - height;
	if(pos.x < 0)
		pos.x = 0;
	if(pos.y < 0)
		pos.y = 0;
	
	taskWindow->show(pos.x, pos.y);
}


static const char *taskWindowClassname = "screenvwm_TaskWindow";
static const char *taskWindowName = "Task View";
static WNDCLASSEX windowClass;
bool classRegistered = false;

struct TaskWindowCreationData
{
	SHORT cbExtra;
	TaskWindow *window;
};
typedef UNALIGNED TaskWindowCreationData UATaskWindowCreationData;

const unsigned int GWL_CLASSPOINTER = 0;

TaskWindow::TaskWindow()
{
	width = GetRCInt("swmTaskWindowWidth", 200);
	height = GetRCInt("swmTaskWindowHeight", 200);
	hidden = true;
	
	registerWindowClass();
	createWindow();
}

TaskWindow::~TaskWindow()
{
	destroyWindow();
	unregisterWindowClass();
}

void TaskWindow::createWindow()
{
	registerWindowClass();
	
	UATaskWindowCreationData creationData = {sizeof(UATaskWindowCreationData), this};
	HWND parentWindow = GetDesktopWindow();
	
	window = CreateWindowEx(
		WS_EX_TOOLWINDOW | WS_EX_TRANSPARENT | WS_EX_TOPMOST,
		taskWindowClassname,
		taskWindowName,
		WS_POPUP,
		0, 0, width, height,
		parentWindow,
		NULL, dllInstance, &creationData);
	if (!window)
	{
		MessageBox(NULL, "Unable to create task view window.", taskWindowName, MB_TOPMOST);
		return;
	}
	
	// Mark this window as 'belonging to Litestep' so that we don't try to operate on ourself
	SetWindowLong(window, GWL_USERDATA, magicDWord);
}

void TaskWindow::destroyWindow()
{
	if(window)
		DestroyWindow(window);
	unregisterWindowClass();
}

void TaskWindow::registerWindowClass()
{
	if(classRegistered)
		return;
	classRegistered = true;
	
	memset(&windowClass, 0, sizeof(WNDCLASSEX));
	windowClass.cbSize = sizeof(WNDCLASSEX);
	windowClass.cbWndExtra = sizeof(TaskWindow*);
	windowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	windowClass.lpfnWndProc = taskWndProc;
	windowClass.hInstance = dllInstance;
	windowClass.lpszClassName = taskWindowClassname;

	if (!RegisterClassEx(&windowClass))
	{
		// Class could not be registered, try to re-register
		UnregisterClass(taskWindowClassname, dllInstance);

		if (!RegisterClassEx(&windowClass))
		{
			// Still no luck, error out
			MessageBox(NULL, "Unable to register window class.", taskWindowClassname,
			           MB_ICONEXCLAMATION | MB_TOPMOST);
			throw;
		}
	}
}

void TaskWindow::unregisterWindowClass()
{
	if(!classRegistered)
		return;
	classRegistered = false;
	
	UnregisterClass(taskWindowClassname, dllInstance);
}

LRESULT CALLBACK taskWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message = { 0 };
	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	
	TaskWindow *window = NULL;

	if (uMsg == WM_CREATE)
	{
		LPVOID & createParams = LPCREATESTRUCT(lParam)->lpCreateParams;

		if (createParams)
		{
			window = ((UATaskWindowCreationData*)(createParams))->window;
			SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)window);
		}
	}
	else
		window = (TaskWindow*)(GetWindowLong(hWnd, GWL_CLASSPOINTER));

	if (window)
	{
		if (uMsg == WM_CREATE)
			window->window = hWnd;
		window->windowProc(uMsg, wParam, lParam, &message.lResult);
		if (uMsg == WM_NCDESTROY)
			window->window = NULL;
		return message.lResult;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void TaskWindow::windowProc(unsigned msg, WPARAM wParam, LPARAM lParam, LRESULT *result)
{
	switch(msg)
	{
		case WM_PAINT:
			onPaint(msg, wParam, lParam);
			break;
		
		default:
			*result = DefWindowProc(window, msg, wParam, lParam);
			break;
	}
}

void TaskWindow::onPaint(unsigned msg, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC windowDrawContext = BeginPaint(window, &ps);
	
	// Gather up the information which should appear on the task window
	HICON icon = task->bigIcon;
	string windowTitle = getWindowTitle(task->handle);
	
	// For now, just draw a big rectangle
	Rectangle(windowDrawContext, 0, 0, width, height);
	
	EndPaint(window, &ps);
}

void TaskWindow::setTask(WindowData *task)
{
	this->task = task;
}

void TaskWindow::hide()
{
	hidden = true;
	ShowWindow(window, SW_HIDE);
}

void TaskWindow::show(int x, int y)
{
	hidden = false;
	SetWindowPos(window, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
	ShowWindow(window, SW_SHOWNOACTIVATE);
}

bool TaskWindow::isHidden()
	{ return hidden; }
int TaskWindow::getWidth()
	{ return width; }
int TaskWindow::getHeight()
	{ return height; }
