/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "vwm.h"
#include "util.hpp"
#include "trace.hpp"

MinimapElement::MinimapElement(string prefix)
	:LayoutElement(prefix)
{
	x = getConfigString("X", "2", prefix.c_str());
	y = getConfigString("Y", "0", prefix.c_str());
	width = getConfigString("Width", "32", prefix.c_str());
	height = getConfigString("Height", "32", prefix.c_str());
}

void MinimapElement::getRect(VirtualDesktop *desk, RECT *rect)
{
	rect->left   = desk->panelX + ParseCoordinate(x.c_str(), 0, desk->panelWidth);
	rect->top    = desk->panelY + ParseCoordinate(y.c_str(), 0, desk->panelHeight);
	rect->right  = rect->left + ParseCoordinate(width.c_str(), 0, desk->panelHeight);
	rect->bottom = rect->top + ParseCoordinate(height.c_str(), 0, desk->panelHeight);
}

bool MinimapElement::containsPoint(VirtualDesktop *desk, int px, int py)
{
	RECT rect;
	getRect(desk, &rect);
	
	return px>=rect.left && py>=rect.top && px<rect.right && py<rect.bottom;
}

WindowData *MinimapElement::getWindow(VirtualDesktop *desk, int px, int py)
{
	// Convert to minimap-space coordinates
	RECT rect;
	getRect(desk, &rect);
	
	POINT pt = {px-rect.left, py-rect.top};
	
	for(vector<HWND>::iterator it = vwm->zOrder.begin(); it != vwm->zOrder.end(); it++)
	{
		if(vwm->windowsByHandle.find(*it) == vwm->windowsByHandle.end())
			continue;
		WindowData *windowData = vwm->windowsByHandle[*it];
		if(windowData->desk != desk)
			continue;
		RECT vwmRect = screenToMinimapPos(desk, windowData->screenPos);
		
		if(PtInRect(&vwmRect, pt))
			return windowData;
	}
	
	return NULL;
}

struct MinimapWindowPainter
{
	HBRUSH windowBrush;
	HPEN pen;
	HBRUSH titleBarBrush;
	HBRUSH focusedTitleBarBrush;
	HBRUSH oldBrush;
	HPEN oldPen;
	RCSettings *settings;
	HDC backBuffer;
	
	MinimapWindowPainter(RCSettings *settings, HDC backBuffer)
		:settings(settings), backBuffer(backBuffer)
	{
		windowBrush = CreateSolidBrush(settings->vwmWindowColor);
		titleBarBrush = CreateSolidBrush(settings->vwmTitleBarColor);
		focusedTitleBarBrush = CreateSolidBrush(settings->vwmFocusedTitleBarColor);
		pen = CreatePen(PS_SOLID, 1, settings->vwmWindowBorderColor);
		oldBrush = (HBRUSH)SelectObject(backBuffer, windowBrush);
		oldPen = (HPEN)SelectObject(backBuffer, pen);
	}
	
	~MinimapWindowPainter()
	{
		SelectObject(backBuffer, oldBrush);
		SelectObject(backBuffer, oldPen);
		DeleteObject(windowBrush);
		DeleteObject(titleBarBrush);
		DeleteObject(focusedTitleBarBrush);
		DeleteObject(pen);
	}
	
	void paintWindow(WindowData *window, RECT r, HICON icon, POINT iconPos)
	{
		Rectangle(backBuffer, r.left, r.top, r.right, r.bottom);
		
		RECT rtitle;
		if(settings->minimapTitleBarsThickness && !window->isPopup)
		{
			if(window->focused)
				SelectObject(backBuffer, focusedTitleBarBrush);
			else
				SelectObject(backBuffer, titleBarBrush);
			
			rtitle.left = r.left;
			rtitle.top = r.top;
			rtitle.right = r.right;
			rtitle.bottom = r.top + settings->minimapTitleBarsThickness;
			// save the bottom of the titlebar as the top of the rest of the window
			r.top = rtitle.bottom;
			
			Rectangle(backBuffer,
				rtitle.left, rtitle.top, rtitle.right, rtitle.bottom);
			SelectObject(backBuffer, windowBrush);
		}
		
		int iconSize = settings->minimapIconSize;
		if(icon && iconSize)
			DrawIconEx(backBuffer, iconPos.x, iconPos.y, icon, iconSize, iconSize, 0, NULL, DI_NORMAL);
	}
};

void MinimapElement::draw(HDC drawContext, VirtualDesktop *desk)
{
	MinimapWindowPainter painter(settings, drawContext);
	RECT rect;
	getRect(desk, &rect);
	
	for(vector<HWND>::reverse_iterator it = vwm->zOrder.rbegin(); it != vwm->zOrder.rend(); it++)
	{
		HWND handle = *it;
		if(vwm->windowsByHandle.find(handle) == vwm->windowsByHandle.end())
			continue;
		WindowData *windowData = vwm->windowsByHandle[handle];
		
		if(windowData->desk != desk)
			continue;
		if(windowData->minimized)
			continue;
		
		POINT iconPos;
		RECT r = screenToMinimapPos(desk, windowData->screenPos, &iconPos);
			r.left += rect.left;
			r.right += rect.left;
			r.top += rect.top;
			r.bottom += rect.top;
			iconPos.x += rect.left;
			iconPos.y += rect.top;
		
		if(!windowData->parent && !windowData->isPopup)
			painter.paintWindow(windowData, r, windowData->getIcon(settings->minimapIconSize), iconPos);
		else
			painter.paintWindow(windowData, r, NULL, iconPos);
	}
}

RECT MinimapElement::screenToMinimapPos(VirtualDesktop *desk, RECT screenPos, POINT *iconPos)
{
	// Translate it so it's placed as if it was the focused desktop
	if(!desk->focused)
		desk->storage->unstoreRect(screenPos);
	
	RECT maximizeArea = vwm->getMaximizeArea();
	
	// Promote to float for intermediate calculations;
	float left, right, top, bottom;
	left   = (float)screenPos.left - maximizeArea.left;
	right  = (float)screenPos.right - maximizeArea.left;
	top    = (float)screenPos.top - maximizeArea.top;
	bottom = (float)screenPos.bottom - maximizeArea.top;
	
	RECT minimapRect;
	getRect(desk, &minimapRect);
	int minimapWidth = minimapRect.right - minimapRect.left;
	int minimapHeight = minimapRect.bottom - minimapRect.top;
	
	// Scale it to minimap size
	//  +1 and -2 because the minimap's borders don't count
	left   *= (float)(minimapWidth-2)  / (maximizeArea.right-maximizeArea.left);
	right  *= (float)(minimapWidth-2)  / (maximizeArea.right-maximizeArea.left);
	top    *= (float)(minimapHeight-2) / (maximizeArea.bottom-maximizeArea.top);
	bottom *= (float)(minimapHeight-2) / (maximizeArea.bottom-maximizeArea.top);
		left++;
		right++;
		top++;
		bottom++;
	
	if(left < 0)
		left = 0;
	if(top < 0)
		top = 0;
	if(right > minimapWidth)
		right = minimapWidth;
	if(bottom > minimapHeight)
		bottom = minimapHeight;
	
	if(iconPos)
	{
		iconPos->x = (left+right)/2 - settings->minimapIconSize/2;
		iconPos->y = (top+bottom)/2 - settings->minimapIconSize/2;
	}
	
	RECT ret;
		ret.left   = (long)left;
		ret.right  = (long)right;
		ret.top    = (long)top;
		ret.bottom = (long)bottom;
	return ret;
}

