/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

#define _WIN32_WINNT 0x0501
#define WINVER 0x0501
#include <litestep/lsapi/lsapi.h>
#include "rcsettings.hpp"
#include "windowstorage.hpp"
#include "windowtracking.hpp"

#include <vector>
using std::vector;
#include <map>
using std::map;
using std::pair;
#include <string>
using std::string;
#include <set>
using std::set;

#define VERSION_STRING "screenvwm 0.6"

#define MAX_LINE_LENGTH 4096
#pragma warning (disable: 4800) // Conversion from int to bool
#pragma warning (disable: 4244) // Implicit conversion from int to float

struct Message
{
	UINT uMsg;
	union 
	{
		struct
		{
			WPARAM wParam;
			LPARAM lParam;
			LRESULT lResult;
		};
		struct
		{
			WORD wParamLo;
			WORD wParamHi;
			WORD lParamLo;
			WORD lParamHi;
			WORD lResultLo;
			WORD lResultHi;
		};
	};
};

#include "taskwindow.hpp"

struct VirtualDesktop;
struct WindowData;

/// A virtual desktop within the VWM.
struct VirtualDesktop
{
	VirtualDesktop(int index, StorageArea *storage);
	~VirtualDesktop();
	
	bool layoutDone;
	
	int index;
	string getName();
	string getLabel();
	
	// Position and size for the entire display of this VWM (including
	// label, minimap, tasks, and area in between them)
	int panelX, panelY;
	int panelWidth, panelHeight;
	
	/*int minimapX, minimapY;
	int minimapWidth, minimapHeight;*/
	
	bool focused;
	StorageArea *storage;
	
	/// List of windows that're on this desktop. Only updated when
	/// VWM::doLayout is called;
	std::vector<WindowData*> tasks;
	/// Number of windows that're on this desktop. Unlike tasks, this is
	/// updated immediately as soon as we notice that a new window has appeared
	/// or disappeared.
	int numTasks;
};

/// Virtual Window Manager - the widget that this module exists to provide.
class VWM
{
public:
	VWM(HWND parentWnd, int& code);
	~VWM();
	int finalize();
	
	// FIXME: These shouldn't need to be friends
	friend class MinimapElement;
	friend class TasksElement;
	friend class TextLabelElement;

	void gather();
	
	void createDesktop();
	bool destroyDesktop(VirtualDesktop *desk);
	void mergeDesk(VirtualDesktop *deletedDesktop, VirtualDesktop *mergeTarget);
	void separateDesk(VirtualDesktop *desk);
	void moveDesk(int oldIndex, int newIndex);
	void switchDesk(VirtualDesktop *newDesk, bool skipFocus=false);
	void moveApp(VirtualDesktop *dest);
	void moveWindow(WindowData *window, VirtualDesktop *desk);
	void moveWindow(WindowData *window, RECT pos, VirtualDesktop *desk);
	void raiseWindow(WindowData *window);
	void minimizeWindow(WindowData *window);
	void maximizeWindow(WindowData *window);
	void restoreWindow(WindowData *window);
	void saveDesktops();
	
	WindowData *getForegroundWindow();
	void raiseLocalForeground();
	
	int getScreenWidth() { return screenWidth; }
	int getScreenHeight() { return screenHeight; }
	
	// Desktop searching
	// (in finddesk.cpp) @{
	/// Find the named virtual desktop, or return NULL if there is no such
	/// desk. (eg, if relativeTo is the last desk and deskName=="next", returns
	/// null.)
	VirtualDesktop *findDeskNoFallback(const char *deskName, VirtualDesktop *relativeTo);
	/// Find the named virtual desktop. May be a string naming multiple desks,
	/// separated by slashes, eg "next/prev/newlast". Tries possibilities in
	/// order until one is found which works. If it runs out of fallbacks, uses
	/// "next/prev/current" as a fallback.
	VirtualDesktop *findDesk(const char *deskName, VirtualDesktop *relativeTo=NULL);
	//@}
	
	LayoutLocation elementAtPoint(int x, int y);
	
private:
	int screenWidth;
	int screenHeight;
	
	// VWM window management
	// (in vwmwindow.cpp) @{
	HWND vwmWindow;
	HWND parentWindow;
	bool inWharf;
	bool createWindow();
	void destroyWindow();
	void registerWindowClass();
	void unregisterWindowClass();
	static LRESULT CALLBACK VWM::wndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
public:
	void ontopToggle();
	void toggle();
	void show();
	void hide();
private:
	//@}
	
	// Sticky windows handling
	// (in vwm.cpp) @{
	void initStickyWindows();
	bool isSticky(HWND window);
	set<string> stickyWindows;
	//@}
	
	// Virtual desktop data structures
	// (getters in vwm.cpp) @{
	VirtualDesktop *currentDesktop;
	VirtualDesktop *lastDesktop;
	vector<VirtualDesktop*> desktops;
	VirtualDesktop *getDeskFromWnd(HWND window);
	//@}
	
	// windowtracking.cpp
	// Window tracking and moving @{
	vector<HWND> zOrder;
	map<HWND, WindowData*> windowsByHandle;
	StorageManager storageManager;
	HWND foregroundHandle;
	bool updateNextDraw;

	bool updateWindowList();
	bool updateWindow(WindowData *window);
	WindowData *noticeWindowCreation(HWND handle);
	void noticeWindowDisappearance(WindowData *window);
	VirtualDesktop *rescueOffscreenWindow(HWND handle, RECT *pos);
	
	HDWP windowMover;
	void beginMovingWindows();
	void setWindowPos(HWND handle, const RECT *pos);
	void finishMovingWindows();
	
	void getTaskGroup(WindowData *member, set<WindowData*> *group);
	bool shouldIgnoreWindow(HWND window);
	
	void initTrackingHooks();
	void cleanupTrackingHooks();
	void interceptWindowPosChange(HWND window, WINDOWPOS *pos);
	friend void hookWindowPosChangedProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	//@}
	
	// vwmevents.cpp
	// Event handlers @{
	void registerEventHandlers();
	void unregisterEventHandlers();
	virtual void windowProc(Message& message);
	void onCreate(Message& message);
	void onDestroy(Message& message);
	void onGetRevId(Message& message);
	void onMouseButtonDown(Message& message);
	void onMouseButtonUp(Message& message);
	void onMouseMove(int x, int y);
	void onMouseLeave();
	void onSysCommand(Message& message);
	void onWindowActivated(Message& message);
	void onTimer(Message& message);
	void onDropFiles(Message& message);
	void onVWMPosChanging(Message& message);
	void onBringToFront(Message& message);
	void onSwitchToN(Message& message);
	void onListDesktops(Message& message);
	void onGetDesktopOf(Message& message);
	//@}
	
	// dragndrop.cpp
	// Drag, drop, and pending-minimization @{
	HWND pendingMinimize;
	HWND draggingTask;
	/// If dragging a task, whether the drag affects location (otherwise it
	/// only affects which desktop)
	bool draggingLocation;
	VirtualDesktop *dragCreatedDesk;
	POINT diffPt;
	VirtualDesktop *dragSourceDesk;
	RECT dragSourceRect;
	HWND dragIconWnd;
	HICON dragIcon;
	int dragIconSize;
	void beginWindowDrag(WindowData *window, bool draggingLocation, POINT click, POINT clickOffset);
	void continueWindowDrag(int mouseX, int mouseY);
	void endDrag();
	void createDragIconClass();
	void destroyDragIconClass();
	void createDragIcon(int centerX, int centerY, HICON icon);
	void destroyDragIcon();
	friend LRESULT CALLBACK dragIconWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	//@}
	
	// taskwindow.cpp
	// Task details window
	TaskWindow *taskWindow;
	void updateTaskWindow(WindowData *task);
	
	// vwmgeom.cpp
	// Geometry calculations @{
	int windowX;
	int windowY;
	int windowWidth;
	int windowHeight;
	
	int layoutIndex;
	LayoutSettings *layoutSettings;
	
	void initDesktops();
	bool restoreDesktops();
	void tryLayouts();
	bool doLayout();
	void updateTaskLists();
	//WindowData *taskFromPoint(int x, int y);
	POINT taskToPoint(WindowData *task);
	void setScreenSize(int cx, int cy);
	RECT getMaximizeArea();
	void getDragDestination(RECT *rect, VirtualDesktop **desk, WindowData *window, POINT clickOffset, int mouseX, int mouseY);
	RECT getGatherTarget(RECT source);
	POINT minimapToScreenPos(VirtualDesktop *desk, MinimapElement *minimap, int x, int y);
	VirtualDesktop *deskFromLocation(RECT pos);
	VirtualDesktop *panelPointToDesk(int x, int y);
	//@}
	
	// vwmpaint.cpp
	// Rendering @{
	HDC backBuffer;
	HBITMAP backBufferMem;
	void initDrawContext();
	void destroyDrawContext();
	void forceRedraw(bool updateWindows);
	void onPaint(Message& message);
	//@}
};
extern VWM *vwm;
extern HINSTANCE dllInstance;

void initBangs();
void cleanupBangs();

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
	__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, void *wharfData);
	__declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);
}
