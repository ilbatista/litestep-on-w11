/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "vwm.h"
#include "util.hpp"
#include "trace.hpp"

LayoutElement::LayoutElement(string prefix)
	:prefix(prefix)
{ }

string LayoutElement::toString() const
{
	return prefix;
}

LayoutElement::~LayoutElement() { }
void LayoutElement::draw(HDC drawContext, VirtualDesktop *desk) { }
bool LayoutElement::containsPoint(VirtualDesktop *desk, int x, int y) { return false; }

POINT LayoutElement::updateSize(VirtualDesktop *desk, bool verticalLayout, int rowThickness)
{
	POINT ret = {0,0};
	return ret;
}

Alignment parseAlign(const string &str)
{
	if(!stricmp(str.c_str(), "center"))
		return alignCenter;
	else if(!stricmp(str.c_str(), "left"))
		return alignLeft;
	else if(!stricmp(str.c_str(), "right"))
		return alignRight;
	else if(!stricmp(str.c_str(), "top"))
		return alignTop;
	else if(!stricmp(str.c_str(), "bottom") || !stricmp(str.c_str(), "bot"))
		return alignBottom;
	else
		return alignCenter;
}

TextureElement::TextureElement(string prefix)
	:LayoutElement(prefix)
{
	x = getConfigString("X", "0", prefix.c_str());
	y = getConfigString("Y", "0", prefix.c_str());
	width = getConfigString("Width", "-0", prefix.c_str());
	height = getConfigString("Height", "-0", prefix.c_str());
	
	texture = Create_xTextureClass();
	texture->configure("", prefix.c_str());
}

void TextureElement::getRect(VirtualDesktop *desk, RECT *rect)
{
	rect->left = ParseCoordinate(x.c_str(), 0, desk->panelWidth);
	rect->top = ParseCoordinate(y.c_str(), 0, desk->panelHeight);
	rect->right = rect->left + ParseCoordinate(width.c_str(), desk->panelWidth, desk->panelWidth);
	rect->bottom = rect->top + ParseCoordinate(height.c_str(), desk->panelHeight, desk->panelHeight);
}

void TextureElement::draw(HDC drawContext, VirtualDesktop *desk)
{
	RECT rect;
	getRect(desk, &rect);
	texture->apply(drawContext,
		desk->panelX+rect.left, desk->panelY+rect.top,
		rect.right-rect.left, rect.bottom-rect.top);
}

bool TextureElement::containsPoint(VirtualDesktop *desk, int px, int py)
{
	int rectX = ParseCoordinate(x.c_str(), 0, desk->panelWidth);
	int rectY = ParseCoordinate(y.c_str(), 0, desk->panelHeight);
	int rectWidth = ParseCoordinate(width.c_str(), desk->panelWidth, desk->panelWidth);
	int rectHeight = ParseCoordinate(height.c_str(), desk->panelHeight, desk->panelHeight);
	return px>=rectX && py>=rectY && px<(rectX+rectWidth) && py<(rectY+rectHeight);
}

void parseElementList(const string &elements, vector<LayoutElement*> *elementList)
{
	char *tokenizedString = strdup(elements.c_str());
	elementList->clear();
	
	const char *delim = " ;\t\'\"";
	const char *prefix = strtok(tokenizedString, delim);
	do {
		if(prefix && *prefix)
			elementList->push_back(getElement(prefix));
	} while((prefix = strtok(NULL, delim)));
	
	free(tokenizedString);
}

LayoutElement *getElement(string prefix)
{
	string type = getConfigString("Type", NULL, prefix.c_str());
	
	if(!stricmp(type.c_str(), "label"))
		return new TextLabelElement(prefix);
	else if(!stricmp(type.c_str(), "texture"))
		return new TextureElement(prefix);
	else if(!stricmp(type.c_str(), "minimap"))
		return new MinimapElement(prefix);
	else if(!stricmp(type.c_str(), "tasks"))
		return new TasksElement(prefix);
	else
		return NULL;
}

LayoutLocation VWM::elementAtPoint(int x, int y)
{
	LayoutLocation ret = {NULL,NULL,NULL};
	
	ret.desk = panelPointToDesk(x, y);
	
	if(ret.desk)
	{
		vector<LayoutElement*> *elements;
		
		if(ret.desk->focused)
			elements = &settings->focusedLayout;
		else
			elements = &settings->deskLayout;
		
		for(int ii=elements->size()-1; ii>=0; ii--) {
			if((*elements)[ii]->containsPoint(ret.desk, x, y)) {
				ret.element = (*elements)[ii];
				break;
			}
		}
	}
	
	if(dynamic_cast<TasksElement*>(ret.element))
	{
		TasksElement *tasks = dynamic_cast<TasksElement*>(ret.element);
		ret.task = tasks->getTask(ret.desk, x, y);
	}
	
	return ret;
}
