/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include "vwm.h"
#include "trace.hpp"
#include "xExports.h"

void VWM::initDrawContext()
{
	HDC windowDrawContext = GetDC(vwmWindow);
	if(!windowDrawContext)
		MessageBox(NULL, "Failed to get a draw context for VWM window.", "ScreenVWM", MB_TOPMOST);
	backBuffer = CreateCompatibleDC(windowDrawContext);
	backBufferMem = CreateCompatibleBitmap(windowDrawContext, windowWidth, windowHeight);
	ReleaseDC(vwmWindow, windowDrawContext);
	
	HBITMAP oldBackBufferMem = (HBITMAP)SelectObject(backBuffer, backBufferMem);
	DeleteObject(oldBackBufferMem);
}

void VWM::destroyDrawContext()
{
	DeleteDC(backBuffer);
	DeleteObject(backBufferMem);
}

void VWM::forceRedraw(bool forceUpdate)
{
	if(forceUpdate)
		updateNextDraw = true;
	InvalidateRect(vwmWindow, NULL, FALSE);
}

void VWM::onPaint(Message& message)
{
	if(updateNextDraw)
		updateWindowList();
	
	PAINTSTRUCT ps;
	HDC windowDrawContext = BeginPaint(vwmWindow, &ps);
	
	// Don't update window if currently in a drag/drop
	if(!draggingTask)
		updateTaskLists();
	if(!draggingTask || (dragCreatedDesk && !dragCreatedDesk->layoutDone))
		tryLayouts();
	
	settings->panelBackground->apply(backBuffer, 0, 0, windowWidth, windowHeight);
	
	// Draw per-desk elements
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		
		if(desk->focused) {
			for(unsigned jj=0; jj<settings->focusedLayout.size(); jj++)
				settings->focusedLayout[jj]->draw(backBuffer, desk);
		} else {
			for(unsigned jj=0; jj<settings->deskLayout.size(); jj++)
				settings->deskLayout[jj]->draw(backBuffer, desk);
		}
	}
	
	// Flip the back buffer onto the screen
	BitBlt(windowDrawContext, 0, 0, windowWidth, windowHeight, backBuffer, 0, 0, SRCCOPY);
	EndPaint(vwmWindow, &ps);
}
