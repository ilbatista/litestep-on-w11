*** LPopup v 1.0
** by _TAG_ <dream.king@iol.it>
Looking around on the mailing list I found someone (me included) felt the need
for a left-click popup which, at least, would show the active tasks.
So I made this.
WARNING: to make it work you need to replace desktop.dll (which poses no probs)
	 and popup.dll; the latter will replece your popup with the new LS popup
	 (from build 180399), which has still some minor bugs (I only made the
	 popup show its name) :-(
	 This is because I had to change it too, to better handle mouse clicks
	 on the desktop (hope Fahim won't get angry).


*** installation
You nedd (at least that's what I have, so I'm sure it works with it) the 20/02/99
build of LS (or a more recent one).
- unzip lpopup.dll in your LS direectory (e.g. c:\litestep\)
- overwrite desktop.dll and popup.dll with those in the zip file
- add this line to your step.rc
	LoadModule C:\LITESTEP\lpopup.dll
  where (of course) C:\litestep\ is the directory in which lpopup.dll is.

NOTE: to overwrite your desktop and popup dlls, LS need not be running!


*** settings
The left popup gets its settings from the step.rc, like the normal one, and will
look like it in every aspect (bitmaps, stretching, etc.), so you need not add
anything to your step.rc (besides the LoadModule).


*** usage
It's pretty obvious:
left clicking on the desktop opens my popup, while right clicking opens the normal
popup.
If the left popup is open, right clicking on the desktop just closes it, while left
clicking just does nothing (and the other way around).


*** hardcore tech infos (for LSDevs and whoever is curious enough)
To make it work well, I:
- added 2 new messages to LSAPI: LM_POPUPHIDDEN and LM_LPOPUP
- made the desktop unfocusable
- made every popup send a LM_POPUPHIDDEN message whenever it closes

LM_LPOPUP is sent from the desktop whenever it wants the left popup to open.
LM_POPUPHIDDEN is sent from the popups when they close, so the desktop knows which
popup is open and can act accordingly (send the right messages).
i.e.	a left-click on the desktop makes it send a LM_LPOPUP message and set a
	variable (iPopupState) to WM_LBUTTONDOWN (so the desktop remembers the
	left popup is open).
	Left-clicking on the desktop again does nothing, cause the desktop knows
	the left popup's open; right-clicking, instead, closes the popup.
I changed the normal popup because the desktop couldn't know if it closed due to 
another window getting the focus. Now when a popup is closed it sends a 
LM_POPUPHIDDEN message, which lets the desktop know no popup is open (and set 
iPopupState to 0).

[Hope I explained everythign and that you understand my bad english and my confused
 ideas]


*** sources
The sources are all hacked from the LS sources for the 20/02/99 build.
Changes in popup, desktop and lsapi are documented in the sources for they are
preceded by     /* _TAG_	<comments> */
and followed by /* _TAG_ END */
Changes in lpopup (i.e. the changes I made to the new popup to get the left one) are
not documented (they are too many).


*** known bugs
- the width of the popup tends to be very big, cause it shows the title of opened
  windows. This is not a bug, but can get annoying if there are windows with very 
  long names (like Netscape and VisualC++)


*** thanks
AnTI_MTtr and cbjcyber on #ls_help and #litestep (EFNet)
Fahim for his popup and everyone in the LS Dev Team!


*** contacts
write me (comments, bugs, ideas, money, girls):  dream.king@iol.it
[ flames > /dev/null ]
the 'official' site should be	http://aula6.cjb.net/
				http://users.iol.it/dream.king
ICQ UIN #1584291


*** other
- future: may add some XWindows like commands (kill, move, etc)


*** history
v 1.0	24/03/99
- changed the code base so it uses the new popup code by Fahim (from LS build 180399)
- fixed the bug which caused the bottom picture and some tasks not to show;
  did this by changing the window properties (height and width) every time the popup
  is opened (using SetWindowPos())

v 0.1	01/03/99
- first release with many bugs