#ifndef __GUIWINDOW_H
#define __GUIWINDOW_H

#include "window.h"

class GuiWindow : public Window
{
private:
	int nXPos;
	int nYPos;

	int nWidth;
	int nHeight;

	bool bInWharf;
	bool bLsBoxed;
	bool bVisible;
	bool bOnTop;

	HWND hwndParent;

public:
	GuiWindow(LPCSTR szAppName, HWND parentWnd, bool Wharfed);
	~GuiWindow();

	void SetPosition(int x_pos, int y_pos);
	void SetSize(int x_size, int y_size);

	void Move(int x_pos, int y_pos);
	void Size(int x_size, int y_size);
	void Show(void);
	void Hide(void);
	void ToggleVisibility(void);
	void SetOnTop(bool fAlwaysOnTop);
	void ToggleOnTop(void);
	void BoxHook(LPCSTR szArgs);

	int GetHeight(void);
	int GetWidth(void);
	int GetX(void);
	int GetY(void);
	HWND GetHWND(void);
	HWND GetParentHWND(void);

	void SetLsBoxed(bool);
	void SetTop(bool);
	void SetVisible(bool);
	void SetInWharf(bool);

	bool IsInWharf(void);
	bool IsOnTop(void);
	bool IsVisible(void);
	bool IsLsBoxed(void);

};

#endif