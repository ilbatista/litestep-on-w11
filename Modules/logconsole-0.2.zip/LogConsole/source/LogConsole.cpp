/****************************************************************************

LogConsole 0.2
by Vendicator (http://pimpin.info/vendicator | vendicator@mail.com)

LogConsole is for use with a indiestep build dated 2002-11-15 or later
(which is when the log code could accept third party listeners).
This module is intended to use when you want to quickly see what's
going on in LS without using the standard logfile...
(perhaps only logging important things in file, and more in this window).


Step.rc Settings:

Placement:
	LogConsoleX
	Int, default: 0
	- Determines the X position of the window

	LogConsoleY
	Int, default: 0
	- Determines the Y position of the window

	LogConsoleWidth
	Int, default: 300
	- Determines the width of the window

	LogConsoleHeight
	Int, default: 200
	- Determines the height of the window

	LogConsoleAlwaysOnTop
	Bool, default: false
	- Sets whether the window should be on top of all other windows

	LogConsoleHidden
	Bool, default: false
	- Sets whether the window should be hidden initially

Colors:
	LogConsoleUseColors
	Bool, default: false
	- Sets whether the window should use defined colors or standard windows colors

	LogConsoleBGColor
	Color, default: FFFFFF
	- Sets background color of window

	LogConsoleTextColor
	Color, default: 000000
	- Sets text color of window

View:
	LogConsoleUseTextLevels
	Bool, default: false
	- Display loglevels as text instead of nrs

	LogConsoleAutoScroll
	Bool, default: false
	- Automatically moves to the last inserted items in logview

	LogConsoleAutoSize
	Bool, default: false
	- Automatically resize columns to the largest items in logview

Logging:
	LogConsoleLogLevel 1-4
	Int, default: 4  (1: errors, 2: warnings, 3: notices, 4: debug)
	- Sets which levels that should be logged, this level and below is logged.

	LogConsoleLogFile
	Filename, default: (no file)
	- Filename to output logged messages to for saving, trying to use
	the normal LS log file isn't tested...


Bang Commands:
	!LogConsoleHook
	Hooks LogConsole to LsBox

	!LogConsoleSetOnTop on/off
	Sets LogConsoles window to be ontop or not, if no argument specified it's turned on.

	!LogConsoleToggleOnTop
	Toggles the on top status

	!LogConsoleShow
	Shows LogConsoles window if hidden

	!LogConsoleHide
	Hides LogConsoles window

	!LogConsoleToggle
	Toggles visible/hidden status of LogConsole

	!LogConsoleMove x y
	Move LogConsole to the given position

	!LogConsoleSize x y
	Change the size of LogConsole

	!LogConsoleClear
	Deletes all messages from console

	!LogConsoleClear
	Saves all messages in console to file, needs to be specified


Changelog:
	Added [Vendicator, 2002-11-26]
	  - Color settings, LogConsoleUseColors, LogConsoleBGColor, LogConsoleTextColor
	  - Autoscrolling to last item, autosizing to largest item in column
	  - Added textlabels for log level, use LogConsoleUseTextLevels
	  - Implemented !LogConsoleClear, !LogConsoleSave

	Added [Vendicator, 2002-11-24]
	  - Fixed item_nr when adding items
	  - Added buffer which saves messages for temporary storage
	  - Fixed visibility bug thanks to RabidCow
	  - Added reading of size settings

	Added [Vendicator, 2002-11-23]
	  - Inherited from guiwindow class for more window functionality
	  - Found cpu usage bug, can't show window?
	  - Listed bugs/what to do

	Added [Vendicator, 2002-11-22]
	  - Formated listview text

	Added [Vendicator, 2002-11-21]
	  - Added listview frame stolen from aboutbox

	Added [Vendicator, 2002-11-18]
	  - Started work


Todo:
	- Column sorting
	- "Real" window to allow resizing etc?
	- bitmap / transparency?


Bugs:
	- Isn't painted correctly at startup using LogConsoleAutoSize,
	LogConsoleAutoScroll, tho autosize seems to be the bigger villain
	- Sometime memory could not be read?


****************************************************************************/

#include "winutils.h"
#include "lsutils.h"
#include "LogConsole.h"
#include <commctrl.h>

const char SettingsPrefix[] = "LogConsole"; // Prefix for settings
const char szAppName[] = "LogConsole"; // Our window class, etc
const char rcsRevision[] = "$Revision: 0.2 $"; // Our Version
const char rcsId[] = "$Id: LogConsole.cpp,v 0.2 12:16:4 Vendicator Exp $"; // The Full RCS ID.
LogConsole *logconsole; // The module


// register these bangs
const Bang BangList[] =
{
	{"!LogConsoleHook", &BangHook},
	{"!LogConsoleSetOnTop", &BangSetOnTop},
	{"!LogConsoleToggleOnTop", &BangToggleOnTop},
	{"!LogConsoleShow", &BangShow},
	{"!LogConsoleHide", &BangHide},
	{"!LogConsoleToggle", &BangToggle},
	{"!LogConsoleMove", &BangMove},
	{"!LogConsoleSize", &BangSize},
	{"!LogConsoleClear", &BangClear},
	{"!LogConsoleSave", &BangSave}
};

// calculate how many bangs there are
const int NrOfBangs = sizeof(BangList) / sizeof(BangList[0]);

// text labels for loglevels
const char* LogLevels[] =
{
	"Error",
	"Warning",
	"Notice",
	"Debug",
	"Bang"
};

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	logconsole = new LogConsole(ParentWnd, code);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete logconsole;
}

//=========================================================
// Bang commands
//=========================================================

void BangHook(HWND caller, LPCTSTR szArgs)
{
	logconsole->BoxHook(szArgs);
}

void BangSetOnTop(HWND caller, LPCSTR args)
{
	if (stricmp(args, "off") == 0)
		logconsole->SetOnTop(false);
	else
		logconsole->SetOnTop(true);
}

void BangToggleOnTop(HWND caller, LPCSTR args)
{
	logconsole->ToggleOnTop();
}

void BangShow(HWND caller, LPCSTR args)
{
	logconsole->Show();
}

void BangHide(HWND caller, LPCSTR args)
{
	logconsole->Hide();
}

void BangToggle(HWND caller, LPCSTR args)
{
	logconsole->ToggleVisibility();
}

void BangMove(HWND caller, LPCSTR args)
{
	char szX[MAX_LINE_LENGTH], szY[MAX_LINE_LENGTH];
	char *tokens[2] = {szX, szY};
	LCTokenize( args, tokens, 2, NULL );
	logconsole->Move(atoi(szX), atoi(szY));
}

void BangSize(HWND caller, LPCSTR args)
{
	char szCX[MAX_LINE_LENGTH], szCY[MAX_LINE_LENGTH];
	char *tokens[2] = {szCX, szCY};
	LCTokenize( args, tokens, 2, NULL );
	logconsole->Size(atoi(szCX), atoi(szCY));
}

void BangClear(HWND caller, LPCSTR args)
{
	logconsole->ClearList(caller, args);
}


void BangSave(HWND caller, LPCSTR args)
{
	logconsole->SaveList(caller, args);
}


BOOL //WINAPI
LogMessage(int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	return logconsole->Log(nLevel, pszModule, pszMessage);
}

//=========================================================
// Module code
//=========================================================

// make a copy of this message
void LogConsole::EnterMessage(LogMsg* msg, int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	SYSTEMTIME time;
	GetLocalTime(&time);

	char date[60];
	sprintf(date, "%d-%02d-%02d %02d:%02d:%02d", time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute, time.wSecond);

	msg->date = new char[strlen(date)+1];
	strcpy(msg->date, date);

	if (bUseTextLevels)
	{
		msg->level = new char[strlen(LogLevels[nLevel])+1];
		strcpy(msg->level, LogLevels[nLevel-1]);
	}
	else
	{
		char level[10];
		sprintf(level, "%d", nLevel);
		msg->level = new char[strlen(level)+1];
		strcpy(msg->level, level);
	}

	msg->module = new char[strlen(pszModule)+1];
	strcpy(msg->module, pszModule);

	msg->text = new char[strlen(pszMessage)+1];
	strcpy(msg->text, pszMessage);

	MessageList.push_back(*msg);
}

void LogConsole::RemoveMessages()
{
	for (deque<LogMsg>::iterator i = MessageList.begin(); i != MessageList.end(); i++)
	{
		delete [] ((LogMsg) (*i)).date;
		delete [] ((LogMsg) (*i)).level;
		delete [] ((LogMsg) (*i)).module;
		delete [] ((LogMsg) (*i)).text;
	}
	MessageList.clear();
}

BOOL LogConsole::Log(int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	if (nLogLevel <= nLevel && bListViewStarted)
	{
		LogMsg msg;
		EnterMessage(&msg, nLevel, pszModule, pszMessage);

		// enter new item each time
		int item_nr = ListView_GetItemCount(hListView) + 1;

		LVITEM itemInfo;

		itemInfo.mask = LVIF_TEXT;
		itemInfo.iItem = item_nr;
		itemInfo.pszText = msg.date;
		itemInfo.iSubItem = 0;

		item_nr = ListView_InsertItem( hListView, &itemInfo );

		// error adding item
		if (item_nr == -1)
			return FALSE;

		// add other data columns
		ListView_SetItemText( hListView, item_nr, 1, msg.level );
		ListView_SetItemText( hListView, item_nr, 2, msg.module );
		ListView_SetItemText( hListView, item_nr, 3, msg.text );
		
		// adapt all columns to their items size
		if (bAutoSize)
		{
			ListView_SetColumnWidth(hListView, 0, LVSCW_AUTOSIZE);
			ListView_SetColumnWidth(hListView, 1, LVSCW_AUTOSIZE);
			ListView_SetColumnWidth(hListView, 2, LVSCW_AUTOSIZE);
			ListView_SetColumnWidth(hListView, 3, LVSCW_AUTOSIZE);
		}

		// autoscroll to ensure that this new items is visible
		if (bAutoScroll)
		{
			ListView_EnsureVisible(hListView, item_nr, FALSE);
		}

		return TRUE;
	}
	else
		return FALSE;
}

HWND LogConsole::GetList()
{
	return hListView;
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
LogConsole::LogConsole(HWND parentWnd, int& code):
GuiWindow(szAppName, parentWnd, false),
bListViewStarted(false),
nLogLevel(LOG_DEBUG),
bUseColors(false),
bAutoSize(false),
bAutoScroll(false),
bUseTextLevels(false),
clrBack(NULL),
clrText(NULL)
{

	int msgs[] = {LM_GETREVID, LM_RECYCLE, 0};

	HWND desktop = WinUtils::GetDesktopHWND();

	ReadSizeAndPos();
	ReadGUIProps();


	if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
                    GetX(), GetY(), GetWidth(), GetHeight(), desktop))
	{
		MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
		code = 1;
		return;
	}

	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	INITCOMMONCONTROLSEX cc;
	cc.dwSize = sizeof(cc);
	cc.dwICC = ICC_LISTVIEW_CLASSES;
	InitCommonControlsEx(&cc);

	RECT rc;
	GetClientRect(hWnd, &rc); 
	hListView = CreateWindow (WC_LISTVIEW, "", 
        WS_CHILD | LVS_REPORT, 
        0, 0, rc.right - rc.left, rc.bottom -
        rc.top, 
        hWnd, (HMENU) NULL, hInstance, NULL); // ID_LISTVIEW

	// set up columns in list view
	LVCOLUMN columnInfo;
	int width = GetWidth() - GetSystemMetrics( SM_CXVSCROLL );

	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	columnInfo.fmt = LVCFMT_LEFT;
	columnInfo.cx = width / 4;
	columnInfo.pszText = "Time";
	columnInfo.iSubItem = 0;

	ListView_InsertColumn( hListView, 0, &columnInfo );

	columnInfo.cx = width / 4;
	columnInfo.pszText = "Level";
	columnInfo.iSubItem = 1;

	ListView_InsertColumn( hListView, 1, &columnInfo );

	columnInfo.cx = width / 4;
	columnInfo.pszText = "Module";
	columnInfo.iSubItem = 2;

	ListView_InsertColumn( hListView, 2, &columnInfo );

	columnInfo.cx = width / 4;
	columnInfo.pszText = "Message";
	columnInfo.iSubItem = 3;

	ListView_InsertColumn( hListView, 3, &columnInfo );

	// Set full row selection
	ListView_SetExtendedListViewStyle(hListView, LVS_EX_FULLROWSELECT);

	if (bUseColors)
	{
		ListView_SetTextBkColor(hListView, clrBack);
		ListView_SetTextColor(hListView, clrText);
	}

	// show windows
	ShowWindow( hWnd, IsVisible() ? SW_SHOWNORMAL : SW_HIDE );
	ShowWindow(hListView, IsVisible() ? SW_SHOWNORMAL : SW_HIDE);

	bListViewStarted = true;

	if ( !IsInWharf() )
	{
		LSLogPrintf(LOG_DEBUG, szAppName, "Entering %d bang commands", NrOfBangs);
		for (int i = 0; i < NrOfBangs; i++)
			AddBangCommand(BangList[i].bangName, *BangList[i].bangFunc);
	}

	AddLogListener(LogMessage);

	code = 0;
}

// logging settings
void LogConsole::ReadConsoleSettings()
{
	nLogLevel = LSUtils::PrefixedGetRCInt(SettingsPrefix, "LogLevel", LOG_DEBUG);
}

// get the position and size of the main window
// using different method if it's docked in the wharf
void LogConsole::ReadSizeAndPos()
{
	int defaultX = 300, defaultY = 200;

	SetPosition(LSUtils::PrefixedGetRCCoordinate(SettingsPrefix, "X", 0, GetSystemMetrics(SM_CXSCREEN)), LSUtils::PrefixedGetRCCoordinate(SettingsPrefix, "Y", 0, GetSystemMetrics(SM_CYSCREEN)));
	SetSize(LSUtils::PrefixedGetRCInt(SettingsPrefix, "Width", defaultX), LSUtils::PrefixedGetRCInt(SettingsPrefix, "Height", defaultY));

	LSLog(LOG_DEBUG, szAppName, "Done reading size settings");
}

void LogConsole::ReadGUIProps()
{
	int tmpInteger = 0;

	// load settings here
	// ===========================================
	BOOL hidden = LSUtils::PrefixedGetRCBool(SettingsPrefix, "Hidden", TRUE);
	SetVisible(IsInWharf() || !hidden);

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "Hidden: %d, Visible: %d", hidden, visible);
#endif

	SetTop(!IsInWharf() && LSUtils::PrefixedGetRCBool(SettingsPrefix, "AlwaysOnTop", TRUE));

	/*tmpInteger = LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderSize", 0);
	borderTop = max(LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderTop", tmpInteger), 0);
	borderLeft = max(LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderLeft", tmpInteger), 0);
	borderRight = max(LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderRight", tmpInteger), 0);
	borderBottom = max(LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderBottom", tmpInteger), 0);
	borderDrag = !IsInWharf() && LSUtils::PrefixedGetRCBool(SettingsPrefix, "BorderDrag", TRUE);
	bDoNotAlignUsingBorders = LSUtils::PrefixedGetRCBool(SettingsPrefix, "DoNotAlignUsingBorders", TRUE);

	*/
	
	char szTemp[MAX_LINE_LENGTH];
	LSUtils::PrefixedGetRCString(SettingsPrefix, "LogFile", szTemp, "", MAX_LINE_LENGTH);
	szLogFile = new char[strlen(szTemp)+1];
	strcpy(szLogFile, szTemp);

	bUseTextLevels = LSUtils::PrefixedGetRCBool(SettingsPrefix, "UseTextLevels", TRUE);
	bAutoScroll = LSUtils::PrefixedGetRCBool(SettingsPrefix, "AutoScroll", TRUE);
	bAutoSize = LSUtils::PrefixedGetRCBool(SettingsPrefix, "AutoSize", TRUE);

	// colors
	bUseColors = LSUtils::PrefixedGetRCBool(SettingsPrefix, "UseColors", TRUE);
	clrBack = LSUtils::PrefixedGetRCColor(SettingsPrefix, "BGColor", RGB(255, 255, 255));
	clrText = LSUtils::PrefixedGetRCColor(SettingsPrefix, "TextColor", RGB(0, 0, 0));
	
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
LogConsole::~LogConsole()
{
	int msgs[] = {LM_GETREVID, LM_RECYCLE, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	if ( !IsInWharf() )
	{
		for (int i = 0; i < NrOfBangs; i++)
			RemoveBangCommand(BangList[i].bangName);
	}

	bListViewStarted = false;
	RemoveLogListener(LogMessage);

	DestroyWindow(hListView);

	RemoveMessages();

	destroyWindow();
}


//=========================================================
// Registered messages
//=========================================================

void LogConsole::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onEndSession,       WM_ENDSESSION)
		MESSAGE(onEndSession,       WM_QUERYENDSESSION)
		MESSAGE(onGetRevId,         LM_GETREVID)
		//MESSAGE(onPaint,			WM_PAINT)
		MESSAGE(onNotify,			WM_NOTIFY)
		MESSAGE(onCreate,		WM_CREATE)
		MESSAGE(onSysCommand,       WM_SYSCOMMAND)
		MESSAGE(onLMRecycle,		LM_RECYCLE)
	END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void LogConsole::onNotify(Message& message)
{
	/*switch ( ((LPNMHDR) message.lParam)->code )
	{
	case LVN_GETDISPINFO:
		switch ( ((LPNMLVDISPINFO)message.lParam)->item.iSubItem )
		{
		case 0:
			plvdi->item.pszText = MessageList[plvdi->item.iItem].date;
		break;
	  
		case 1:
			plvdi->item.pszText = MessageList[plvdi->item.iItem].level;
		break;

		case 2:
			plvdi->item.pszText = MessageList[plvdi->item.iItem].module;
		break;

		case 3:
			plvdi->item.pszText = MessageList[plvdi->item.iItem].text;
		break;

		default:
		break;
	}*/
}

void LogConsole::onPaint(Message& message)
{
}

void LogConsole::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void LogConsole::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
	case 0:
		sprintf(buf, "LogConsole.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
	break;
	case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
	break;
	default:
		strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


void LogConsole::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void LogConsole::onLMRecycle(Message& message)
{
}

void LogConsole::onCreate(Message& message)
{
	// set always on top
	if (IsOnTop())
		SetOnTop(true);
	else
		SetOnTop(false);

	//InvalidateRect( hWnd, NULL, TRUE );	

}

//=========================================================
// Bang command handling
//=========================================================

void LogConsole::ClearList(HWND caller, LPCSTR args)
{
	bListViewStarted = false;
	ListView_DeleteAllItems(hListView);
	RemoveMessages();
	bListViewStarted = true;
}


void LogConsole::SaveList(HWND caller, LPCSTR args)
{
	if (szLogFile[0] != '\0')
	{
		FILE* out;
		out = fopen(szLogFile, "a");
		if (out)
		{
			for (deque<LogMsg>::iterator i = MessageList.begin(); i != MessageList.end(); i++)
			{
				fprintf(out, "%s %s %s %s\n", ((LogMsg) (*i)).date, ((LogMsg) (*i)).level, ((LogMsg) (*i)).module, ((LogMsg) (*i)).text);
			}
			fclose(out);
		}
	}
}