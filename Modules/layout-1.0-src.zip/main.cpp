// main.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

extern "C" {
    __declspec( dllexport ) int initModuleEx(HWND hwndParent, HINSTANCE hDllInstance, LPCSTR szPath);
    __declspec( dllexport ) void quitModule(HINSTANCE hDllInstance);
}

void RegisterBangs();
void UnregisterBangs();

typedef struct BangItem
{
	char szName[10];
	BangCommand *pCommand;
} BangItem;

void bangNext	(HWND caller, LPCSTR szArgs);
void bangPrev	(HWND caller, LPCSTR szArgs);
//void bangSet	(HWND caller, LPCSTR szArgs);

// it is possible to end the list with something like
// {NULL,NULL}, but for what?
#define BANGS_NUM		2

BangItem g_Bangs[BANGS_NUM] =
{
	{	"Next",		bangNext	},
	{	"Prev",		bangPrev	}/*,
	{	"Set",		bangSet		}*/
};

const char g_rcsRevision[]	= "0.1";
const char g_szAppName[]	= "Layout";
const char g_szMsgHandler[]	= "LSLayoutManager";
const char g_szAuthor[]		= "Seg@";

HINSTANCE g_hInstance;

int g_lsMessages[] = {LM_WINDOWACTIVATED, LM_GETREVID, 0};
HWND g_hwndMessageHandler;
void CreateMessageHandler(HINSTANCE hInst);
LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

HWND g_hwndLastActiveWindow = NULL;

///////////////////////////////////////////////////////////////////////////////
//
// Error Box
//
void ErrorBox(const char *szMessage)
{
	MessageBox(NULL, szMessage, "LiteStep :: Layout", MB_OK | MB_ICONERROR | MB_TOPMOST | MB_SETFOREGROUND);
	LSLogPrintf(LOG_ERROR, g_szAppName, szMessage);
}

///////////////////////////////////////////////////////////////////////////////
//
// DLL entry point
//
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	if (ul_reason_for_call == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls((HINSTANCE)hModule);
	}
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
// Module entry point
//
int initModuleEx(HWND hwndParent, HINSTANCE hDllInstance, LPCSTR szPath)
{
	g_hwndLastActiveWindow = GetActiveWindow();
	CreateMessageHandler(hDllInstance);
	RegisterBangs();
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// Module destructor
//
void quitModule(HINSTANCE hDllInstance)
{
	UnregisterBangs();
}


////////////////////////////////////////////////////////////////////////////
//
// Create message handler window
//

void CreateMessageHandler(HINSTANCE hInst)
{
	WNDCLASSEX wc;
	ZeroMemory(&wc, sizeof(WNDCLASSEX));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.lpfnWndProc = MessageHandlerProc;
	wc.hInstance = hInst;
	wc.lpszClassName = g_szMsgHandler;
	wc.hIconSm = 0;

	if (!RegisterClassEx(&wc))
	{
		ErrorBox("Error: Cannot register handler window class...");
		return;
	}

	g_hwndMessageHandler = CreateWindowEx(WS_EX_TOOLWINDOW,
		g_szMsgHandler,
		0,
		WS_POPUP,
		0, 0, 0, 0, 
		0,
		0,
		hInst,
		0);

	if (!g_hwndMessageHandler)
	{
		ErrorBox("Error: Cannot create main window...");
		return;
	}	
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)g_hwndMessageHandler, (LPARAM) g_lsMessages);

}


////////////////////////////////////////////////////////////////////////////
//
// Message handler process the following messages
//	LM_GETREVID				-	Revision ID
//
LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case LM_WINDOWACTIVATED:
	{
		HWND hwndActive = reinterpret_cast<HWND>(wParam);
		if (GetWindowLong(hwndActive, GWL_USERDATA) != magicDWord)
		{
			g_hwndLastActiveWindow = hwndActive;
		}
		break;
	}
	case LM_GETREVID:
		LPSTR buf;
		buf = (LPSTR)lParam;
		switch (wParam)
		{
		case 0:
		case 1:
			StringCchPrintf(buf, lParam, "%s: %s (%s)", g_szAppName, g_rcsRevision, g_szAuthor);
			break;
		default:
			StringCchCopy(buf, lParam, "");
		}
		return strlen(buf);
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void RegisterBangs()
{
	for (int i = 0; i < BANGS_NUM; i++)
	{
		char szBangName[MAX_BANGCOMMAND];;
		StringCchPrintf(szBangName, MAX_BANGCOMMAND, "!%s%s", g_szAppName, g_Bangs[i].szName);
		AddBangCommand(szBangName, g_Bangs[i].pCommand);
	}
}


void UnregisterBangs()
{
	for (int i = 0; i < BANGS_NUM; i++)
	{
		char szBangName[MAX_BANGCOMMAND];;
		StringCchPrintf(szBangName, MAX_BANGCOMMAND, "!%s%s", g_szAppName, g_Bangs[i].szName);
		RemoveBangCommand(szBangName);
	}
}

void bangNext(HWND caller, LPCSTR szArgs)
{
	DWORD hActiveThread = GetWindowThreadProcessId(g_hwndLastActiveWindow, NULL);
	DWORD hThisThread = GetCurrentThreadId();
	if (AttachThreadInput(hThisThread, hActiveThread, TRUE) == NULL)
	{
		return;
	}
	SetForegroundWindow(g_hwndLastActiveWindow);
	UINT nLayoutsInstalled = GetKeyboardLayoutList(0, NULL);
	HKL *vhLayouts = (HKL*)HeapAlloc(GetProcessHeap(), 0, sizeof(HKL)*nLayoutsInstalled);
	HKL hklCurrent = GetKeyboardLayout(hActiveThread);
	GetKeyboardLayoutList(nLayoutsInstalled, vhLayouts);
	int i;
	for (i = 0; i < nLayoutsInstalled; i++)
	{
		if (vhLayouts[i] == hklCurrent) break;
	}
	if (i != nLayoutsInstalled)
	{
		i ++;
		i %= nLayoutsInstalled;
		PostMessage(g_hwndLastActiveWindow, WM_INPUTLANGCHANGEREQUEST, 0, (LPARAM)(vhLayouts[i]));
	}
	delete vhLayouts;
	AttachThreadInput(hThisThread, hActiveThread, FALSE);
}

void bangPrev(HWND caller, LPCSTR szArgs)
{
	DWORD hActiveThread = GetWindowThreadProcessId(g_hwndLastActiveWindow, NULL);
	DWORD hThisThread = GetCurrentThreadId();
	if (AttachThreadInput(hThisThread, hActiveThread, TRUE) == NULL)
	{
		return;
	}
	SetForegroundWindow(g_hwndLastActiveWindow);
	UINT nLayoutsInstalled = GetKeyboardLayoutList(0, NULL);
	HKL *vhLayouts = (HKL*)HeapAlloc(GetProcessHeap(), 0, sizeof(HKL)*nLayoutsInstalled);
	HKL hklCurrent = GetKeyboardLayout(hActiveThread);
	GetKeyboardLayoutList(nLayoutsInstalled, vhLayouts);
	int i;
	for (i = 0; i < nLayoutsInstalled; i++)
	{
		if (vhLayouts[i] == hklCurrent) break;
	}
	if (i != nLayoutsInstalled)
	{
		i --;
		i %= nLayoutsInstalled;
		PostMessage(g_hwndLastActiveWindow, WM_INPUTLANGCHANGEREQUEST, 0, (LPARAM)(vhLayouts[i]));
	}
	delete vhLayouts;
	AttachThreadInput(hThisThread, hActiveThread, FALSE);
}

/*
void bangSet	(HWND caller, LPCSTR szArgs)
{
	ActivateKeyboardLayout(, 0);
}
*/

