#include "common.h"
#include "LabelSettings.h"
#include "Font.h"
#include "Texture.h"

NameValuePair alignValues[] = {
	{ "left", DT_LEFT },
	{ "center", DT_CENTER },
	{ "right", DT_RIGHT },
	{ 0, 0 }
};

NameValuePair vertAlignValues[] = {
	{ "top", ALIGN_TOP },
	{ "center", ALIGN_CENTER },
	{ "bottom", ALIGN_BOTTOM },
	{ 0, 0 }
};

LabelSettings::LabelSettings()
{
	const char *name = "AllLabels";
	isDefault = true;

	alwaysOnTop = GetRCBoolean(name, "AlwaysOnTop");
	startHidden = GetRCBoolean(name, "StartHidden");
	bUseFahrenheit = GetRCBoolean(name, "UseFahrenheit");

	skin = GetRCTexture(name, "");
	font = GetRCFont(name);
	
	leftBorder = GetRCInt(name, "LeftBorder", 0);
	topBorder = GetRCInt(name, "TopBorder", 0);
	rightBorder = GetRCInt(name, "RightBorder", 0);
	bottomBorder = GetRCInt(name, "BottomBorder", 0);

	align = GetRCNamedValue(name, "Align", alignValues, DT_CENTER);
	vertAlign = GetRCNamedValue(name, "VertAlign", vertAlignValues, ALIGN_CENTER);
	updateInterval = GetRCInt(name, "UpdateInterval", 1000);

	int screenX = GetSystemMetrics(SM_CXSCREEN);
	int screenY = GetSystemMetrics(SM_CYSCREEN);

	width = GetRCDimen(name, "Width", 64, screenX);
	height = GetRCDimen(name, "Height", 64, screenY);
	x = GetRCCoord(name, "X", 0, screenX);
	y = GetRCCoord(name, "Y", 0, screenY);

	text = GetRCString(name, "Text", "");

	leftClickCommand = GetRCLine(name, "OnLeftClick", "");
	leftDoubleClickCommand = GetRCLine(name, "OnLeftDoubleClick", "");
	middleClickCommand = GetRCLine(name, "OnMiddleClick", "");
	middleDoubleClickCommand = GetRCLine(name, "OnMiddleDoubleClick", "");
	rightClickCommand = GetRCLine(name, "OnRightClick", "");
	rightDoubleClickCommand = GetRCLine(name, "OnRightDoubleClick", "");
	wheelDownCommand = GetRCLine(name, "OnWheelDown", "");
	wheelUpCommand = GetRCLine(name, "OnWheelUp", "");
	enterCommand = GetRCLine(name, "OnEnter", "");
	leaveCommand = GetRCLine(name, "OnLeave", "");
	dropCommand = GetRCLine(name, "OnDrop", "");

	scrollPadLength = GetRCInt(name, "scrollPad", 10); 
	scrollInterval = GetRCInt(name, "scrollInterval", 100);
	scrollSpeed = GetRCInt(name, "scrollSpeed", 1);
	scroll = GetRCBoolean(name, "scroll", false);

//	trueTransparency = GetRCBoolean(name, "TrueTransparency", false);
}

LabelSettings::LabelSettings(const char *name)
{
	isDefault = false;

	alwaysOnTop = GetRCBoolean(name, "AlwaysOnTop", defaultSettings->alwaysOnTop);
	startHidden = GetRCBoolean(name, "StartHidden", defaultSettings->startHidden);
	bUseFahrenheit = GetRCBoolean(name, "UseFahrenheit", defaultSettings->bUseFahrenheit);

	skin = GetRCTexture(name, "", defaultSettings->skin);

	font = GetRCFont(name, defaultSettings->font);
	
	leftBorder = GetRCInt(name, "LeftBorder", defaultSettings->leftBorder);
	topBorder = GetRCInt(name, "TopBorder", defaultSettings->topBorder);
	rightBorder = GetRCInt(name, "RightBorder", defaultSettings->rightBorder);
	bottomBorder = GetRCInt(name, "BottomBorder", defaultSettings->bottomBorder);

	align = GetRCNamedValue(name, "Align", alignValues, defaultSettings->align);
	vertAlign = GetRCNamedValue(name, "VertAlign", vertAlignValues, defaultSettings->vertAlign);
	updateInterval = GetRCInt(name, "UpdateInterval", defaultSettings->updateInterval);

	int screenX = GetSystemMetrics(SM_CXSCREEN);
	int screenY = GetSystemMetrics(SM_CYSCREEN);

	width = GetRCDimen(name, "Width", defaultSettings->width, screenX);
	height = GetRCDimen(name, "Height", defaultSettings->height, screenY);
	x = GetRCCoord(name, "X", defaultSettings->x, screenX);
	y = GetRCCoord(name, "Y", defaultSettings->y, screenY);

	text = GetRCString(name, "Text", defaultSettings->text);

	leftClickCommand = GetRCLine(name, "OnLeftClick", defaultSettings->leftClickCommand);
	leftDoubleClickCommand = GetRCLine(name, "OnLeftDoubleClick", defaultSettings->leftDoubleClickCommand);
	middleClickCommand = GetRCLine(name, "OnMiddleClick", defaultSettings->middleClickCommand);
	middleDoubleClickCommand = GetRCLine(name, "OnMiddleDoubleClick", defaultSettings->middleDoubleClickCommand);
	rightClickCommand = GetRCLine(name, "OnRightClick", defaultSettings->rightClickCommand);
	rightDoubleClickCommand = GetRCLine(name, "OnRightDoubleClick", defaultSettings->rightDoubleClickCommand);
	wheelDownCommand = GetRCLine(name, "OnWheelDown", defaultSettings->wheelDownCommand);
	wheelUpCommand = GetRCLine(name, "OnWheelUp", defaultSettings->wheelUpCommand);
	enterCommand = GetRCLine(name, "OnEnter", defaultSettings->enterCommand);
	leaveCommand = GetRCLine(name, "OnLeave", defaultSettings->leaveCommand);
	dropCommand = GetRCLine(name, "OnDrop", defaultSettings->dropCommand);

	scrollPadLength = GetRCInt(name, "scrollPad", defaultSettings->scrollPadLength);
	scrollInterval = GetRCInt(name, "scrollInterval", defaultSettings->scrollInterval);
	scrollSpeed = GetRCInt(name, "scrollSpeed", defaultSettings->scrollSpeed);
	scroll = GetRCBoolean(name, "scroll", defaultSettings->scroll);

//	trueTransparency = GetRCBoolean(name, "TrueTransparency", defaultSettings->trueTransparency);
}

LabelSettings::~LabelSettings()
{
	if(isDefault)
	{
		delete skin;
		delete font;
	}
}

LabelSettings* defaultSettings = NULL;
