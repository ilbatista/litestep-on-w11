#include "common.h"
#include "Label.h"
#include "SystemInfo.h"
#include "LabelSettings.h"
#include "Font.h"

// Bang commands
void BangAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs);
void BangClipboardCopy(HWND hwndCaller, LPCSTR pszArgs);
void BangClipboardPaste(HWND hwndCaller, LPCSTR pszArgs);
void BangCreate(HWND hwndCaller, LPCSTR pszArgs);
void BangDestroy(HWND hwndCaller, LPCSTR pszArgs);
void BangHide(HWND hwndCaller, LPCSTR pszArgs);
void BangLSBoxHook(HWND hwndCaller, LPCSTR pszArgs);
void BangMove(HWND hwndCaller, LPCSTR pszArgs);
void BangNext(HWND hwndCaller, LPCSTR pszArgs);
void BangPinToDesktop(HWND hwndCaller, LPCSTR pszArgs);
void BangPrevious(HWND hwndCaller, LPCSTR pszArgs);
void BangRefresh(HWND hwndCaller, LPCSTR pszArgs);
void BangReposition(HWND hwndCaller, LPCSTR pszArgs);
void BangResize(HWND hwndCaller, LPCSTR pszArgs);
void BangScroll(HWND hwndCaller, LPCSTR pszArgs);
void BangSetFontColor(HWND hwndCaller, LPCSTR pszArgs);
void BangSetText(HWND hwndCaller, LPCSTR pszArgs);
void BangShow(HWND hwndCaller, LPCSTR pszArgs);
void BangToggleAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs);
void BangToggle(HWND hwndCaller, LPCSTR pszArgs);
void BangUpdate(HWND hwndCaller, LPCSTR pszArgs);

HINSTANCE hInstance;
HWND messageHandler;
LabelList labelList;

int lsMessages[] = {
	LM_GETREVID,
	LM_REFRESH,
	0
};

#define LM_UPDATEBG (WM_USER + 1)

Label *lookupLabel(const string &name);

LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case LM_GETREVID:
		{
			UINT uLength;
			StringCchPrintf((char*)lParam, 64, "%s %s", V_NAME, V_VERSION);
			
			if (SUCCEEDED(StringCchLength((char*)lParam, 64, &uLength)))
				return uLength;

			lParam = NULL;
			return 0;
		}
		
		case LM_REFRESH:
		{
			StringList labelNames = GetRCNameList("*Label");

			// refresh the "AllLabels" configuration
			delete defaultSettings;
			defaultSettings = new LabelSettings();

			for(LabelListIterator iter = labelList.begin(); iter != labelList.end(); iter++)
			{
				if(!(*iter)->getBox())
				{
					// destroy all labels that no longer exist and that are not in a box
					for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
					{
						if(_stricmp((*it).c_str(), (*iter)->getName().c_str()) == 0)
							break;
					}
					if (it == labelNames.end())
					{
						labelList.remove(*iter);
						delete *iter;
						continue;
					}
				}

				// we can reconfigure all other labels, even if they are "boxed"
				(*iter)->reconfigure();
			}

			// create the rest
			for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
			{
				Label *label = lookupLabel(*it);
				
				if (!label) 
				{
					label = new Label(*it);
					label->load(hInstance);
					labelList.insert(labelList.end(), label);
				}
			}
			return 0;
		}

		case LM_UPDATEBG:
		{
			PaintDesktopEx(0, 0, 0, 0, 0, 0, 0, TRUE);

			for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
			{
				Label *label = *i;

				if(label->getBox() == 0)
					label->repaint(true);
			}

			return 0;
		}

		case WM_DISPLAYCHANGE:
		case WM_SETTINGCHANGE:
		{
			PostMessage(hWnd, LM_UPDATEBG, 0, 0);
			return 0;
		}
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	WNDCLASSEX wc;

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS | CS_DBLCLKS;
	wc.lpfnWndProc = Label::windowProcedure;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = sizeof(Label *);
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = LoadCursor(0, IDC_ARROW);
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "xLabel";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = MessageHandlerProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = 0;
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "xLabelMessageHandler";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	messageHandler = CreateWindowEx(WS_EX_TOOLWINDOW,
		"xLabelMessageHandler",
		0,
		WS_POPUP,
		0, 0, 0, 0, 
		0,
		0,
		hInstance,
		0);

	if (!messageHandler)
		return 1;
	
	SendMessage(GetLitestepWnd(),
		LM_REGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	::hInstance = hInstance;
	defaultSettings = new LabelSettings();
	systemInfo = new SystemInfo();

	StringList labelNames = GetRCNameList("*Label");
	// labelNames.merge(GetRCNameList("Label"));
//	if(labelNames.empty()) labelNames.insert(labelNames.end(), "Label");

	for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
	{
		if(GetRCBoolean(*it, "LSBoxName"))
			continue;

		Label *label = new Label(*it);
		label->load(hInstance);
		labelList.insert(labelList.end(), label);
	}

	AddBangCommand("!LabelAlwaysOnTop", BangAlwaysOnTop);
	AddBangCommand("!LabelClipboardCopy", BangClipboardCopy);
	AddBangCommand("!LabelClipboardPaste", BangClipboardPaste);
	AddBangCommand("!LabelCreate", BangCreate);
	AddBangCommand("!LabelDestroy", BangDestroy);
	AddBangCommand("!LabelHide", BangHide);
	AddBangCommand("!LabelLSBoxHook", BangLSBoxHook);
	AddBangCommand("!LabelMove", BangMove);
	AddBangCommand("!LabelNext", BangNext);
	AddBangCommand("!LabelPinToDesktop", BangPinToDesktop);
	AddBangCommand("!LabelPrevious", BangPrevious);
	AddBangCommand("!LabelRefresh", BangRefresh);
	AddBangCommand("!LabelReposition", BangReposition);
	AddBangCommand("!LabelResize", BangResize);
	AddBangCommand("!LabelScroll", BangScroll);
	AddBangCommand("!LabelSetFontColor", BangSetFontColor);
	AddBangCommand("!LabelSetText", BangSetText);
	AddBangCommand("!LabelShow", BangShow);
	AddBangCommand("!LabelToggleAlwaysOnTop", BangToggleAlwaysOnTop);
	AddBangCommand("!LabelToggle", BangToggle);
	AddBangCommand("!LabelUpdate", BangUpdate);

	return 0;
}

extern HDC hdcDesktop;
extern HBITMAP hbmDesktop;

void quitModule(HINSTANCE hInstance)
{
	RemoveBangCommand("!LabelAlwaysOnTop");
	RemoveBangCommand("!LabelClipboardCopy");
	RemoveBangCommand("!LabelClipboardPaste");
	RemoveBangCommand("!LabelCreate");
	RemoveBangCommand("!LabelDestroy");
	RemoveBangCommand("!LabelHide");
	RemoveBangCommand("!LabelLSBoxHook");
	RemoveBangCommand("!LabelMove");
	RemoveBangCommand("!LabelNext");
	RemoveBangCommand("!LabelPinToDesktop");
	RemoveBangCommand("!LabelPrevious");
	RemoveBangCommand("!LabelRefresh");
	RemoveBangCommand("!LabelReposition");
	RemoveBangCommand("!LabelResize");
	RemoveBangCommand("!LabelScroll");
	RemoveBangCommand("!LabelSetFontColor");
	RemoveBangCommand("!LabelSetText");
	RemoveBangCommand("!LabelShow");
	RemoveBangCommand("!LabelToggleAlwaysOnTop");
	RemoveBangCommand("!LabelToggle");
	RemoveBangCommand("!LabelUpdate");

	for(LabelListIterator it = labelList.begin(); it != labelList.end(); it++)
		delete *it;

	labelList.clear();
	
	SendMessage(GetLitestepWnd(),
		LM_UNREGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	DestroyWindow(messageHandler);

	UnregisterClass("xLabel", hInstance);
	UnregisterClass("xLabelMessageHandler", hInstance);

	delete systemInfo;
	delete defaultSettings;

	hbmDesktop = (HBITMAP) SelectObject(hdcDesktop, hbmDesktop);
	DeleteDC(hdcDesktop);
	DeleteObject(hbmDesktop);
}

Label *lookupLabel(const string &name)
{
	for(LabelListIterator it = labelList.begin(); it != labelList.end(); it++)
	{
		if(_stricmp(name.c_str(), (*it)->getName().c_str()) == 0)
			return *it;
	}

	return 0;
}

BOOL APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	if(dwReason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hInstance);
	}

	return TRUE;
}

// !LabelAlwaysOnTop <label>
void BangAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label) label->setAlwaysOnTop(true);
}

// !LabelClipboardCopy <label> <prefix>
void BangClipboardCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], prefix[256];
	char *buffers[] = {name, prefix};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->clipboardCopy((numTokens >= 2) ? prefix : "");
		}
	}
}

// !LabelClipboardPaste <label> <prefix>
void BangClipboardPaste(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], prefix[256];
	char *buffers[] = {name, prefix};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->clipboardPaste((numTokens >= 2) ? prefix : "");
		}
	}
}

// !LabelCreate <label>
void BangCreate(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = new Label(pszArgs);
	label->load(hInstance);
	labelList.insert(labelList.end(), label);
}

// !LabelDestroy <label>
void BangDestroy(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);

	if(label)
	{
		labelList.remove(label);
		delete label;
	}
}

// !LabelHide <label>
void BangHide(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label) label->hide();
}

// !LabelLSBoxHook <label> <box-window-handle>
void BangLSBoxHook(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], handle[16];
	char *buffers[] = {name, handle};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 2)
	{
		HWND hwndBox = (HWND) atoi(handle);
		Label *label = lookupLabel(name);

		if(label)
		{
			label->setBox(hwndBox);
			label->update();
		}
		else
		{
			label = new Label(name);
			label->load(hInstance, hwndBox);
			labelList.insert(labelList.end(), label);
		}
	}
}

// !LabelMove <label> <x> <y>
void BangMove(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16];
	char *buffers[] = {name, A, B};

	if(LCTokenize(pszArgs, buffers, 3, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int x = ParseCoord(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int y = ParseCoord(B, 0, GetSystemMetrics(SM_CYSCREEN));

			label->move(x, y);
		}
	}
}

// !LabelNext <label>
void BangNext(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label) label->next();
}

// !LabelPinToDesktop <label>
void BangPinToDesktop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label) label->setAlwaysOnTop(false);
}

// !LabelPrevious <label>
void BangPrevious(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label) label->previous();
}

// !LabelRefresh <label>
void BangRefresh(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label) label->reconfigure();
}

// !LabelReposition <label> <x> <y> <width> <height>
void BangReposition(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16];
	char *buffers[] = {name, A, B, C, D};

	if(LCTokenize(pszArgs, buffers, 5, NULL) >= 5)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int x = ParseCoord(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int y = ParseCoord(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int w = ParseDimen(C, 0, GetSystemMetrics(SM_CXSCREEN));
			int h = ParseDimen(D, 0, GetSystemMetrics(SM_CYSCREEN));

			label->reposition(x, y, w, h);
		}
	}
}

// !LabelResize <label> <width> <height>
void BangResize(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16];
	char *buffers[] = {name, A, B};

	if(LCTokenize(pszArgs, buffers, 3, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int w = ParseDimen(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int h = ParseDimen(B, 0, GetSystemMetrics(SM_CYSCREEN));

			label->resize(w, h);
		}
	}
}

// !LabelScroll <label> <'on', 'off', 'toggle', limit>
void BangScroll(HWND hwndCaller, LPCSTR pszArgs)
{
	// FIXME: This should be split into multiple bang commands
	char name[64], option[16];
	char *buffers[] = {name, option};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 2)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			if(stricmp(option, "off") == 0)
			{
				label->setScrolling(false);
			}
			else if(stricmp(option, "on") == 0)
			{
				label->setScrolling(true);
			}
			else if(stricmp(option, "toggle") == 0)
			{
				label->setScrolling(!label->isScrolling());
			}
			else
			{
				int limit = atoi(option);
				if(limit >= 0) label->setScrollLimit(limit);
			}
		}
	}
}

// !LabelSetFontColor <label> <red> <green> <blue> OR !LabelSetFontColor <label> <hexcolor>
void BangSetFontColor(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);

	if(label)
	{
		char name[64], A[16], B[16], C[16];
		char *buffers[] = {name, A, B, C};
		int numTokens = LCTokenize(pszArgs, buffers, 4, NULL);
		int color;

		if(numTokens >= 2)
		{
			Label *label = lookupLabel(name);

			if(numTokens >= 4)
			{
				int r = atoi(A);
				int g = atoi(B);
				int b = atoi(C);

				color = RGB(r, g, b);
			}
			else
			{
				color = strtol(A, NULL, 16);
				color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
			}

			label->getFont()->setColor(color);
			label->repaint();
		}
	}
}

// !LabelSetText <label> <text>
void BangSetText(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], text[1024];
	char *buffers[] = {name, text};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 2)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->setText(text);
		}
	}
}

// !LabelShow <label>
void BangShow(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label) label->show();
}

// !LabelToggleAlwaysOnTop <label>
void BangToggleAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label) label->setAlwaysOnTop(!label->isAlwaysOnTop());
}

// !LabelToggle <label>
void BangToggle(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);

	if(label)
	{
		if(label->isVisible())
			label->hide();
		else
			label->show();
	}
}

// !LabelUpdate <label>
void BangUpdate(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label) label->update();
}
