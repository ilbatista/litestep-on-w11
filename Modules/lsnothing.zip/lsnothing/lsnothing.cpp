#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <lsapi.h>
#pragma comment(lib,"lsapi.lib")
#include "..\AggressiveOptimize.h"
#pragma comment(linker,"/nodefaultlib")
#pragma comment(linker,"-entry:DllMain")

#ifdef LS_AUTHORIZATION_UNAVAILABLE
#error Wrong LSAPI.H.  Make sure the path is right.
#endif

extern "C" {
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);
__declspec( dllexport ) BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpReserved );
}

int initModuleEx(HWND ParentWnd, HINSTANCE dll, LPCSTR szPath)
{
   return 0;
}

int quitModule(HINSTANCE dll)
{
   return 0;
}


BOOL WINAPI DllMain(
    HINSTANCE hinstDLL,  /* handle to DLL module        */ 
    DWORD fdwReason,     /* reason for calling function */ 
    LPVOID lpReserved )  /* reserved                    */ 
{
	return TRUE;
}
