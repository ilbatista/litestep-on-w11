/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"
#include <CommCtrl.h>

static const int litestepMessageTypes[] = {
	LM_GETREVID,
	LM_BRINGTOFRONT,
	LM_SWITCHTON,
	LM_WINDOWACTIVATED,
	LM_LISTDESKTOPS,
	LM_GETDESKTOPOF,
	LM_WINDOWCREATED,
	LM_WINDOWDESTROYED,
	LM_REPAINT,
	0
};

//=========================================================
// Message handling
//=========================================================
void VWMFirstPanel::registerEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)window, (LPARAM)litestepMessageTypes);
}

void VWMFirstPanel::unregisterEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)window, (LPARAM)litestepMessageTypes);
}

void VWM::windowProc(Message& message, HWND window)
{
	switch (message.uMsg)
	{
		case WM_CREATE:
			onCreate(message);
			break;
		case WM_DESTROY:
			onDestroy(message);
			break;
			
		case WM_SYSCOMMAND:        onSysCommand     (message); break;
		case WM_TIMER:             onTimer          (message); break;
		case WM_DROPFILES:         onDropFiles      (message); break;
		
		case WM_DISPLAYCHANGE:
			// TODO: Refresh and update storage rects
			break;
		
		case WM_KEYDOWN:
		case WM_KEYUP:
		case WM_HOTKEY:
			PostMessage(getDesktopWindow(), message.uMsg, message.wParam, message.lParam);
			break;
			
		case LM_GETREVID:          onGetRevId       (message); break;
		case LM_WINDOWACTIVATED:   onWindowActivated(message); break;
		
		case LM_BRINGTOFRONT:
			onBringToFront(message);
			break;
			
		case LM_SWITCHTON:         onSwitchToN      (message); break;
		case LM_LISTDESKTOPS:      onListDesktops   (message); break;
		case LM_GETDESKTOPOF:      onGetDesktopOf   (message); break;
		
		// TODO: Observe window *movement*, too
		case LM_WINDOWCREATED:
		case LM_WINDOWDESTROYED:
			if(updateWindowList())
				forceRedraw(false);
			break;
		
		default:
			message.lResult = DefWindowProc(window, message.uMsg, message.wParam, message.lParam);
			break;
	}
}

void VWM::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_BRINGTOFRONT, LM_SWITCHTON, LM_WINDOWACTIVATED, LM_LISTDESKTOPS, LM_GETDESKTOPOF, 0};

	// TODO FIXME
	//SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)msgs);

	// Unregister window hook
	HWND hookManager = FindWindow("HookMgrClass", NULL);
	SendMessage(hookManager, LM_UNREGISTERMESSAGE, (WPARAM)WM_WINDOWPOSCHANGED, (LPARAM)NULL);

	cleanupBangs();

	// Switch to desk 1 on exit
	// FIXME: This should be something considerably more elaborate
	switchDesk(0, true);
	
	//destroyWindow();

	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
		delete ii->second;
}

void VWM::onCreate(Message& message)
{
}

void VWM::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);
	sprintf(buf, VERSION_STRING);
	message.lResult = strlen(buf);
}

/*
Saved snippet: How to show a task's system menu
	DWORD msgPos = MAKELONG(pos.x, pos.y);
	raiseWindow(task);
	PostMessage(task->handle, 0x313, 0, msgPos);
*/

void VWM::onSysCommand(Message& message)
{
	/*if (message.wParam == SC_CLOSE)
		PostMessage(getDesktopWindow(), WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);*/
}

void VWM::onWindowActivated(Message& message)
{
}

void VWM::onTimer(Message& message)
{
	// Update the window list, checking what the foreground window is before
	// and after.
	HWND oldTopWindow = foregroundHandle;
	bool changed = updateWindowList();
	
	if(oldTopWindow!=foregroundHandle) {
		VirtualDesktop *newDesk = getDeskFromWnd(foregroundHandle);
		switchDesk(newDesk, true);
	}
	
	// Dirty the VWM display to force it to redraw
	// TODO: Only redraw when there are changes
	if(changed)
		forceRedraw(false);
}

// TODO: Test and rewrite this
void VWM::onDropFiles(Message& message)
{
	/*POINT pt;
	DragQueryPoint( (HDROP)message.wParam, &pt );
	
	VirtualDesktop *newDesk = panelPointToDesk(pt.x, pt.y);
	if(!newDesk) return;
	switchDesk(newDesk);

	int numFiles = DragQueryFile( (HDROP)message.wParam, 0xFFFFFFFF, NULL, 0 );
	for(int i=0; i<numFiles; i++)
	{
		char filename[_MAX_PATH];
		DragQueryFile( (HDROP)message.wParam, i, filename, _MAX_PATH);
		if (filename && *filename)
			LSExecute(NULL, filename, SW_SHOWNORMAL);
	}
	DragFinish( (HDROP)message.wParam );
	forceRedraw(true);*/
}

void VWM::onBringToFront(Message &message)
{
	HWND hWnd = (HWND) message.lParam;
	VirtualDesktop *desk = getDeskFromWnd(hWnd);

	if (currentDesktop != desk)
		switchDesk(desk, true);

	SwitchToThisWindow(hWnd, TRUE);
	message.lResult = TRUE;
}

void VWM::onSwitchToN(Message &message)
{
	message.lResult = TRUE;
	int desk = (int) message.wParam;
	if(desk < 0 || desk >= (int)desktops.size())
		return;
	
	VirtualDesktop *newDesk = desktops[desk];
	switchDesk(newDesk, true);
}

void VWM::onListDesktops(Message &message)
{
	LSDESKTOPINFO deskInfo;

	for (unsigned ii = 0; ii < desktops.size(); ii++)
	{
		deskInfo.size = sizeof(LSDESKTOPINFO);
		deskInfo.icon = 0;
		deskInfo.isCurrent = desktops[ii]->focused;
		deskInfo.number = ii;
		
		string deskname = desktops[ii]->getName();
		strcpy(deskInfo.name, deskname.c_str());

		SendMessage((HWND) message.wParam, LM_DESKTOPINFO, 0, (LPARAM) &deskInfo);
	}

	message.lResult = TRUE;
}

void VWM::onGetDesktopOf(Message &message)
{
	VirtualDesktop *desk = getDeskFromWnd((HWND) message.wParam);
	message.lResult = desk->index;
}
