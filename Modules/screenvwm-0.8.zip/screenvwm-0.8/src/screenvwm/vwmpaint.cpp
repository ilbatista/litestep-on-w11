/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

void VWMPanel::initDrawContext()
{
	HDC windowDrawContext = GetDC(window);
	if(!windowDrawContext)
		MessageBox(NULL, "Failed to get a draw context for VWM window.", "ScreenVWM", MB_TOPMOST);
	backBuffer = CreateCompatibleDC(windowDrawContext);
	backBufferMem = CreateCompatibleBitmap(windowDrawContext, width, height);
	ReleaseDC(window, windowDrawContext);
	
	HBITMAP oldBackBufferMem = (HBITMAP)SelectObject(backBuffer, backBufferMem);
	DeleteObject(oldBackBufferMem);
}

void VWMPanel::destroyDrawContext()
{
	DeleteDC(backBuffer);
	DeleteObject(backBufferMem);
}

void VWM::forceRedraw(bool forceUpdate)
{
	if(forceUpdate)
		updateNextDraw = true;
	for(unsigned ii=0; ii<panels.size(); ii++)
		panels[ii]->forceRedraw();
}

void VWMPanel::forceRedraw()
{
	InvalidateRect(window, NULL, FALSE);
}

void VWMPanel::onPaint()
{
	if(vwm->updateNextDraw)
		vwm->updateWindowList();
	vwm->updateTaskLists(false);
	
	PAINTSTRUCT ps;
	HDC windowDrawContext = BeginPaint(window, &ps);
	
	// Draw the widget hierarchy
	updateLayout();
	layout->element->draw(backBuffer, layout);
	
	// Flip the back buffer onto the screen
	BitBlt(windowDrawContext, 0, 0, width, height, backBuffer, 0, 0, SRCCOPY);
	EndPaint(window, &ps);
}
