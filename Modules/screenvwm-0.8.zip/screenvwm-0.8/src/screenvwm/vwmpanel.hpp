/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

class VWMPanel
{
public:
	VWMPanel(string prefix);
	~VWMPanel();
	static void registerWindowClass();
	static void unregisterWindowClass();
	
	void setVisible(bool visible);
	void setAlwaysOnTop(bool onTop);
	bool getVisible();
	bool getAlwaysOnTop();
	HWND getWindow();
	
	string prefix;
	
	void updateLayout();
	
	static LRESULT CALLBACK eventHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	int handleEvent(UINT uMsg, WPARAM wParam, LPARAM lParam);
	int mouseButtonEvent(MouseButton button, MouseAction action, int x, int y);
	int mouseMoveEvent(int x, int y);
	int onPosChanging(UINT uMsg, WPARAM wParam, LPARAM lParam);
	
	void beginDrag();
	void cancelDrag();
	void finishDrag();
	void dropDraggedObject(string droppedObjName, int x, int y);
	void hoverDraggedObject(string hoveredObjName, int x, int y);

	HDC backBuffer;
	HBITMAP backBufferMem;
	void initDrawContext();
	void destroyDrawContext();
	void forceRedraw();
	void onPaint();
	
	LayoutLocation elementAtPoint(int x, int y);
	
	int x, y;
	int width, height;
	
protected:
	LayoutElement *rootElement;
	LayoutCacheNode *layout;
	LayoutLocation lastClickLocation;
	
	bool visible;
	bool alwaysOnTop;
	HWND window;
	HWND parentWindow;
};

class VWMFirstPanel
	:public VWMPanel
{
public:
	VWMFirstPanel(string prefix);
	~VWMFirstPanel();
	void registerEventHandlers();
	void unregisterEventHandlers();
};
