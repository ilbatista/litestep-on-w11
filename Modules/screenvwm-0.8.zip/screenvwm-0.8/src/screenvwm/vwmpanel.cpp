/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

static const char *vwmWindowClassname = "screenvwm_VWMWindow";
static const char *vwmWindowName = "ScreenVWM";

#define GWL_CLASSPOINTER 0

struct PanelEventArg
{
	SHORT size;
	VWMPanel *panel;
};

VWMPanel::VWMPanel(string prefix)
	:prefix(prefix)
{
	layout = NULL;
	
	visible = getConfigBool("Visible", true, prefix.c_str());
	alwaysOnTop = getConfigBool("AlwaysOnTop", false, prefix.c_str());
	x = getConfigCoord("X", SCREEN_WIDTH, prefix.c_str());
	y = getConfigCoord("Y", SCREEN_HEIGHT, prefix.c_str()),
	width = getConfigCoord("Width", SCREEN_LEFT+SCREEN_WIDTH, prefix.c_str());
	height = getConfigCoord("Height", SCREEN_TOP+SCREEN_HEIGHT, prefix.c_str());
	
	string rootElementName = getConfigString("RootElement", NULL, prefix.c_str());
	rootElement = layoutPool->getElement(rootElementName);

	parentWindow = GetDesktopWindow();
	PanelEventArg arg = {sizeof(PanelEventArg), this};
	window = CreateWindowEx(
		WS_EX_TOOLWINDOW,
		vwmWindowClassname,
		vwmWindowName,
		WS_POPUP,
		x, y, width, height,
		parentWindow,
		NULL, dllInstance, &arg);
	if (!window)
		fatal("Unable to create VWM window.");
	
	if (alwaysOnTop)
		SetWindowPos(window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	ShowWindow(window, visible?SW_SHOWNORMAL:SW_HIDE);
	
	DragAcceptFiles(window, TRUE);
	
	// Mark this window as 'belonging to Litestep' so that we don't try to operate on ourself
	SetWindowLong(window, GWL_USERDATA, magicDWord);
	
	initDrawContext();
}

VWMPanel::~VWMPanel()
{
	if(layout) {
		delete layout;
		layout = NULL;
	}
	destroyDrawContext();
	
	DestroyWindow(window);
}

VWMFirstPanel::VWMFirstPanel(string prefix)
	:VWMPanel(prefix)
{
	// Set a timer to update the VWM display (would like to replace this with a hook...)
	if(settings->pollInterval)
		SetTimer(window, 1, settings->pollInterval, NULL);
	registerEventHandlers();
}

VWMFirstPanel::~VWMFirstPanel()
{
	unregisterEventHandlers();
}

void VWM::initPanels()
{
	VWMPanel::registerWindowClass();
	
	// Parse swmExtraPanels, creating panelPrefixes, a list of prefixes each
	// of which corresponds to a VWMPanel and has suffixes for window position
	// and settings. There is always a panel prefixes with 'swm', even if
	// swmExtraPanels is "".
	vector<string> panelPrefixes;
	char *panelList = strdup(getConfigLine("ExtraPanels", "").c_str());
	const char *separators = " \t,;";
	char *panelName = strtok(panelList, separators);
	while(panelName) {
		panelPrefixes.push_back(panelName);
		panelName = strtok(NULL, separators);
	}
	free(panelList);
	
	// Create a window for each panel
	panels.push_back(new VWMFirstPanel("swm"));
	
	for(unsigned ii=0; ii<panelPrefixes.size(); ii++)
	{
		VWMPanel *panel = new VWMPanel(panelPrefixes[ii]);
		panels.push_back(panel);
	}
}

void VWM::findPanels(const char *description, vector<VWMPanel*> *p)
{
	p->clear();
	if(!stricmp(description, "") || !stricmp(description, "all")) {
		p->insert(p->begin(), panels.begin(), panels.end());
	} else {
		for(unsigned ii=0; ii<panels.size(); ii++) {
			if(!stricmp(panels[ii]->prefix.c_str(), description)) {
				p->push_back(panels[ii]);
				return;
			}
		}
		string warning = string("Panel not found: '")+description+"'.'";
		warn(warning.c_str());
	}
}

VWMPanel *VWM::findPanel(int x, int y)
{
	for(unsigned ii=0; ii<panels.size(); ii++)
	{
		VWMPanel *panel = panels[ii];
		if(x >= panel->x && y >= panel->y && x < panel->x+panel->width && y < panel->y+panel->height)
			return panel;
	}
	return NULL;
}

VWMPanel *VWM::getFirstPanel()
{
	return panels[0];
}

void VWM::destroyPanels()
{
	for(unsigned ii=0; ii<panels.size(); ii++)
		delete panels[ii];
	VWMPanel::unregisterWindowClass();
}

static WNDCLASSEX panelWindowClass;

void VWMPanel::registerWindowClass()
{
	memset(&panelWindowClass, 0, sizeof(WNDCLASSEX));
	panelWindowClass.cbSize = sizeof(WNDCLASSEX);
	panelWindowClass.cbWndExtra = sizeof(VWM*);
	panelWindowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	panelWindowClass.lpfnWndProc = VWMPanel::eventHandler;
	panelWindowClass.hInstance = dllInstance;
	panelWindowClass.lpszClassName = vwmWindowClassname;

	if (!RegisterClassEx(&panelWindowClass)) {
		// Class could not be registered, try to re-register
		UnregisterClass(vwmWindowClassname, dllInstance);

		if (!RegisterClassEx(&panelWindowClass)) {
			// Still no luck, error out
			fatal("Unable to register window class.");
		}
	}
}

void VWMPanel::unregisterWindowClass()
{
	UnregisterClass(vwmWindowClassname, dllInstance);
}

void VWMPanel::updateLayout()
{
	vector<LayoutCacheNode*> oldNodes;
	if(layout) layout->traverse(oldNodes);
	
	ElementContext drawContext(this, vwm, NULL, NULL, Rect(0,0, width, height));
	layout = rootElement->buildLayout(&drawContext, layout);
	
	vector<LayoutCacheNode*> newNodes;
	layout->traverse(newNodes);
	
	for(unsigned ii=0; ii<oldNodes.size(); ii++)
		oldNodes[ii]->visited = false;
	for(unsigned ii=0; ii<newNodes.size(); ii++)
		newNodes[ii]->visited = true;
	for(unsigned ii=0; ii<oldNodes.size(); ii++) {
		LayoutCacheNode *node = oldNodes[ii];
		if(!node->visited) {
			if(drag && drag->node == node) {
				drag->node = NULL;
			}
			delete oldNodes[ii];
		}
	}
	
	//printLayout(layout, 0);
}

LRESULT CALLBACK VWMPanel::eventHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(uMsg == WM_NCCREATE)
		return 1;
	
	if (uMsg == WM_CREATE) {
		LPVOID &createParams = LPCREATESTRUCT(lParam)->lpCreateParams;

		if (createParams) {
			VWMPanel *panel = ((PanelEventArg*)(createParams))->panel;
			SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)panel);
		}
		return 1;
	}
	
	VWMPanel *panel = (VWMPanel*)(GetWindowLong(hWnd, GWL_CLASSPOINTER));
	if(!panel) return DefWindowProc(hWnd, uMsg, wParam, lParam);
	
	return panel->handleEvent(uMsg, wParam, lParam);
}

int VWMPanel::handleEvent(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
		case WM_LBUTTONDOWN: return mouseButtonEvent(mouseLeft,   mouseDown, LOWORD(lParam), HIWORD(lParam));
		case WM_RBUTTONDOWN: return mouseButtonEvent(mouseRight,  mouseDown, LOWORD(lParam), HIWORD(lParam));
		case WM_MBUTTONDOWN: return mouseButtonEvent(mouseMiddle, mouseDown, LOWORD(lParam), HIWORD(lParam));
		case WM_LBUTTONUP:   return mouseButtonEvent(mouseLeft,   mouseUp,   LOWORD(lParam), HIWORD(lParam));
		case WM_RBUTTONUP:   return mouseButtonEvent(mouseRight,  mouseUp,   LOWORD(lParam), HIWORD(lParam));
		case WM_MBUTTONUP:   return mouseButtonEvent(mouseMiddle, mouseUp,   LOWORD(lParam), HIWORD(lParam));
		
		case WM_MOUSEACTIVATE: {
			WindowData *foregroundWindow = vwm->getForegroundWindow();
			if(foregroundWindow)
				vwm->lastFocus = vwm->getForegroundWindow()->handle;
			else
				vwm->lastFocus = NULL;
			return MA_ACTIVATE;
		}
		
		case WM_MOUSEMOVE: {
			// In window coordinates
			int mouseX = LOWORD(lParam);
			int mouseY = HIWORD(lParam);
			mouseMoveEvent(mouseX, mouseY);
			return 0;
		}
		case WM_MOUSELEAVE: {
			if(layout->element->changed(layout)) {
				updateLayout();
				forceRedraw();
			}
			return 0;
		}
		
		case WM_PAINT:
			onPaint();
			return 0;
			
		case WM_WINDOWPOSCHANGING:
			return onPosChanging(uMsg, wParam, lParam);
			
		default:
			Message message(uMsg, wParam, lParam);
			vwm->windowProc(message, window);
			return message.lResult;
	}
}

ElementContext *clickContext = NULL;

/// Called when a mouse button is pressed over this panel or released anywhere
/// after having been pressed on the panel. x and y are in window coordinates.
int VWMPanel::mouseButtonEvent(MouseButton button, MouseAction action, int x, int y)
{
	updateLayout();
	
	LayoutCacheNode *clickedPos = layout->elementAtPoint(x, y);
	if(!clickedPos) return 0;
	
	LayoutCacheNode *pressNode, *releaseNode, *clickNode;
	for(pressNode=clickedPos; pressNode; pressNode=pressNode->parent)
		if(pressNode->element->onPress[button]!="")
			break;
	for(releaseNode=clickedPos; releaseNode; releaseNode=releaseNode->parent)
		if(releaseNode->element->onRelease[button]!="")
			break;
	for(clickNode=clickedPos; clickNode; clickNode=clickNode->parent)
		if(clickNode->element->onClick[button]!="")
			break;
	
	string clickAction = "";
	
	bool commandsRun = false;
	if(action==mouseDown && pressNode)
	{
		clickContext = &pressNode->context;
		LSExecute(window, pressNode->element->onPress[button].c_str(), SW_SHOWNORMAL);
		clickContext = NULL;
		commandsRun = true;
	}
	else if(action==mouseUp && releaseNode)
	{
		clickContext = &releaseNode->context;
		LSExecute(window, releaseNode->element->onRelease[button].c_str(), SW_SHOWNORMAL);
		clickContext = NULL;
		commandsRun = true;
	}
	
	if(clickNode)
	{
		clickContext = &clickNode->context;
		if(action==mouseDown)
		{
			lastClickLocation.context = clickNode->context;
			lastClickLocation.element = clickNode->element;
		}
		else if(action==mouseUp)
		{
			if(lastClickLocation.context.match(*clickContext)
			   && lastClickLocation.element == clickNode->element
			   && clickNode->element != NULL
			   && (!drag || !drag->active))
			{
				LSExecute(window, clickNode->element->onClick[button].c_str(), SW_SHOWNORMAL);
				commandsRun = true;
			}
			lastClickLocation.element = NULL;
		}
		
		clickContext = NULL;
	}
	
	if(commandsRun)
	{
		// Running commands may have changed the layout
		updateLayout();
		clickedPos = layout->elementAtPoint(x, y);
	}
	
	if(action == mouseDown)
	{
		LayoutCacheNode *draggedNode = clickedPos;
		while(draggedNode && !draggedNode->element->draggable) {
			draggedNode = draggedNode->parent;
		}
		if(draggedNode) {
			drag = new DragInfo(draggedNode, x, y, button);
			forceRedraw();
		}
	}
	else if(action == mouseUp)
	{
		finishDrag();
	}
	
	return 0;
}

/// Called when the mouse moves over the panel, or moves anywhere while
/// dragging on a click that started inside the panel. Given in window
/// coordinates, but may outside the window and may be negative.
int VWMPanel::mouseMoveEvent(int x, int y)
{
	// Request notification when the mouse leaves the window
	TRACKMOUSEEVENT args;
		memset(&args, 0, sizeof(args));
		args.cbSize = sizeof(TRACKMOUSEEVENT);
		args.dwFlags = TME_LEAVE;
		args.hwndTrack = window;
	TrackMouseEvent(&args);

	// Sometimes receive this event while unprepared for it
	if(!layout)
		return 1;
	
	if(layout->element->changed(layout)) {
		updateLayout();
		forceRedraw();
	}
	
	if(drag)
	{
		if(drag->active)
		{
			hoverDraggedObject(drag->element->prefix, x, y);
		}
		else
		{
			int dx = drag->mouseOrigin.x - x;
			int dy = drag->mouseOrigin.y - y;
			if(dx*dx + dy*dy > 25) {
				SetCapture(window);
				beginDrag();
			}
		}
	}
	return 0;
}

void VWMPanel::setVisible(bool visible)
{
	this->visible = visible;
	if(visible)
		ShowWindow(window, SW_SHOWNOACTIVATE);
	else
		ShowWindow(window, SW_HIDE);
}

void VWMPanel::setAlwaysOnTop(bool onTop)
{
	this->alwaysOnTop = onTop;
	
	DWORD oldStyle = GetWindowLong(window, GWL_STYLE);
	DWORD tempStyle = (oldStyle & ~WS_POPUP) | WS_CHILD;
	DWORD newStyle = (oldStyle & ~WS_CHILD) | WS_POPUP;
	
	SetWindowLong(window, GWL_STYLE, tempStyle);
	SetParent(window, onTop?NULL:getDesktopWindow());
	SetWindowLong(window, GWL_STYLE, newStyle);
	
	SetWindowPos(window, onTop?HWND_TOPMOST:HWND_NOTOPMOST,
        0, 0, 0, 0,
        SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
}

/// This handles WM_WINDOWPOSCHANGING, which is sent when the panel is moved,
/// either by choice or by some other program forcibly moving it. Update
/// internals to reflect the new size.
int VWMPanel::onPosChanging(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LPWINDOWPOS windowPos = (LPWINDOWPOS)lParam;

	if ( !( windowPos->flags & SWP_NOSIZE ) )
	{
		width = windowPos->cx;
		height = windowPos->cy;
	}

	if ( !( windowPos->flags & SWP_NOMOVE ) )
	{
		x = windowPos->x;
		y = windowPos->y;
	}
	return DefWindowProc(window, uMsg, wParam, lParam);
}

bool VWMPanel::getVisible()
	{ return visible; }
bool VWMPanel::getAlwaysOnTop()
	{ return alwaysOnTop; }
HWND VWMPanel::getWindow()
	{ return window; }