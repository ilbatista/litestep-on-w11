/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <litestep/lsapi/lsapi.h>
#include <string>
#include "trace.hpp"
#include "screenvwm.hpp"

TraceStream trace;

extern const char *traceFilename;

TraceStream::TraceStream()
{
	disabled = true;
}

void TraceStream::enable()
{
	disabled = false;
}

template<> TraceStream &TraceStream::operator<<(int x) {
	if(initIfNeeded()) {
		fprintf(fout, "%i", x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(float x) {
	if(initIfNeeded()) {
		fprintf(fout, "%f", x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(unsigned x) {
	if(initIfNeeded()) {
		fprintf(fout, "%u", x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(bool x) {
	if(initIfNeeded()) {
		fprintf(fout, "%s", x?"true":"false");
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(long x) {
	if(initIfNeeded()) {
		fprintf(fout, "%i", (int)x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(std::string x) {
	if(initIfNeeded()) {
		fprintf(fout, "%s", x.c_str());
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(char *x) {
	if(initIfNeeded()) {
		fprintf(fout, "%s", x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(const char *x) {
	if(initIfNeeded()) {
		fprintf(fout, "%s", x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(RECT rect) {
	if(initIfNeeded()) {
		fprintf(fout, "(l=%i,t=%i,r=%i,b=%i)", rect.left, rect.top, rect.right, rect.bottom);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(Rect rect) {
	(*this) << rect.toString();
	return *this;
}
bool TraceStream::initIfNeeded()
{
	if(disabled)
		return false;
	if(!fout)
		fout = fopen(traceFilename, "w");
	return(fout != NULL);
}

void TraceStream::close()
{
	if(fout) {
		fclose(fout);
		fout = NULL;
	}
}
