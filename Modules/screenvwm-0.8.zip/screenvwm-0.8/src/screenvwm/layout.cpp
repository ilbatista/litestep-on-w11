/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

LayoutPool *layoutPool = NULL;

ElementContext::ElementContext()
{ }
ElementContext::ElementContext(VWMPanel *panel, VWM *vwm, VirtualDesktop *desk, WindowData *task, const Rect &rect)
	:panel(panel), vwm(vwm), desk(desk), task(task), boundingRect(rect)
{ }

bool ElementContext::match(const ElementContext &rhs) const
{
	return panel==rhs.panel && vwm==rhs.vwm && desk==rhs.desk && task==rhs.task;
}

/////////////////////////////////////////////////////////////////////////////

LayoutCacheNode::LayoutCacheNode(LayoutElement *element, ElementContext *context)
	:element(element), origElement(NULL), context(*context), parent(NULL), visited(false)
{
}

LayoutCacheNode::~LayoutCacheNode()
{
}

/////////////////////////////////////////////////////////////////////////////

LayoutElement::LayoutElement(string prefix)
	:prefix(prefix)
{
	onPress[mouseLeft]   = getConfigLine("OnLeftPress", "", prefix.c_str());
	onPress[mouseRight]  = getConfigLine("OnRightPress", "", prefix.c_str());
	onPress[mouseMiddle] = getConfigLine("OnMiddlePress", "", prefix.c_str());
	onRelease[mouseLeft]  = getConfigLine("OnLeftRelease", "", prefix.c_str());
	onRelease[mouseRight]  = getConfigLine("OnRightRelease", "", prefix.c_str());
	onRelease[mouseMiddle] = getConfigLine("OnMiddleRelease", "", prefix.c_str());
	onClick[mouseLeft]   = getConfigLine("OnLeftClick",  "", prefix.c_str());
	onClick[mouseRight]  = getConfigLine("OnRightClick", "", prefix.c_str());
	onClick[mouseMiddle] = getConfigLine("OnMiddleClick", "", prefix.c_str());
	draggable = getConfigBool("Draggable", false, prefix.c_str());
	
	string placeholderName = getConfigLine("DragPlaceholder", "", prefix.c_str());
	if(placeholderName != "")
		dragPlaceholder = layoutPool->getElement(placeholderName);
	else
		dragPlaceholder = NULL;
}

LayoutElement::~LayoutElement()
	{ }

string LayoutElement::toString() const
{
	return prefix;
}

void LayoutElement::draw(HDC drawContext, LayoutCacheNode *layout)
{
	for(unsigned ii=0; ii<layout->children.size(); ii++)
	{
		LayoutCacheNode *child = layout->children[ii];
		child->element->draw(drawContext, child);
	}
}

bool LayoutElement::changed(LayoutCacheNode *node)
{
	for(unsigned ii=0; ii<node->children.size(); ii++)
	{
		LayoutCacheNode *child = node->children[ii];
		if(child->element->changed(child))
			return true;
	}
	return false;
}

LayoutCacheNode *LayoutElement::buildLayout(ElementContext *context, LayoutCacheNode *prevLayout)
{
	if(prevLayout && prevLayout->element == this) {
		prevLayout->context = *context;
		return prevLayout;
	} else {
		return new LayoutCacheNode(this, context);
	}
}

/////////////////////////////////////////////////////////////////////////////

NullElement::NullElement()
	:LayoutElement("__swm_NullElement")
	{}
LayoutCacheNode *NullElement::buildLayout(ElementContext *context, LayoutCacheNode *prev)
{
	return new LayoutCacheNode(this, context);
}
pair<int,int> NullElement::getLength(ElementContext *context, bool vertical)
{
	return pair<int,int>(0, 0);
}
void NullElement::draw(HDC drawContext, LayoutCacheNode *layout)
	{ }

static NullElement *nullElement = NULL;
NullElement *getNullElement()
{
	if(!nullElement)
		nullElement = new NullElement();
	return nullElement;
}

/////////////////////////////////////////////////////////////////////////////

RectLayoutElement::RectLayoutElement(string prefix)
	:LayoutElement(prefix)
{
	x = getConfigString("X", "0", prefix.c_str());
	y = getConfigString("Y", "0", prefix.c_str());
	width = getConfigString("Width", "-0", prefix.c_str());
	height = getConfigString("Height", "-0", prefix.c_str());
}

LayoutCacheNode *RectLayoutElement::buildLayout(ElementContext *context, LayoutCacheNode *prev)
{
	LayoutCacheNode *ret = LayoutElement::buildLayout(context, prev);
	ret->element = this;
	
	int contextWidth = context->boundingRect.width;
	int contextHeight = context->boundingRect.height;
	ret->context.boundingRect.left   = context->boundingRect.left + ParseCoordinate(x.c_str(), 0, contextWidth);
	ret->context.boundingRect.top    = context->boundingRect.top + ParseCoordinate(y.c_str(), 0, contextHeight);
	ret->context.boundingRect.width  = ParseCoordinate(width.c_str(), contextWidth, contextWidth);
	ret->context.boundingRect.height = ParseCoordinate(height.c_str(), contextHeight, contextHeight);

	return ret;
}

pair<int,int> RectLayoutElement::getLength(ElementContext *context, bool vertical)
{
	int ret;
	if(vertical)
		ret = ParseCoordinate(height.c_str(), 0, 0);
	else
		ret = ParseCoordinate(width.c_str(), 0, 0);
	return pair<int,int>(ret, ret);
}

/////////////////////////////////////////////////////////////////////////////

Alignment parseAlign(const string &str)
{
	if(!stricmp(str.c_str(), "center"))
		return alignCenter;
	else if(!stricmp(str.c_str(), "left"))
		return alignLeft;
	else if(!stricmp(str.c_str(), "right"))
		return alignRight;
	else if(!stricmp(str.c_str(), "top"))
		return alignTop;
	else if(!stricmp(str.c_str(), "bottom") || !stricmp(str.c_str(), "bot"))
		return alignBottom;
	else
		return alignCenter;
}

LayoutPool::~LayoutPool()
{
	for(map<string, LayoutElement*>::iterator ii=elements.begin(); ii!=elements.end(); ii++)
		delete ii->second;
	elements.clear();
}

void LayoutPool::parseElementList(const string &elements, vector<LayoutElement*> *elementList)
{
	char *tokenizedString = strdup(elements.c_str());
	elementList->clear();
	
	vector<string> tokens;
	const char *delim = " ;\t\'\"\n\r";
	const char *prefix = strtok(tokenizedString, delim);
	do {
		if(prefix && *prefix) {
			tokens.push_back(prefix);
		}
	} while((prefix = strtok(NULL, delim)));
	
	for(unsigned ii=0; ii<tokens.size(); ii++)
	{
		string prefix = tokens[ii];
		LayoutElement *element = getElement(prefix);
		if(element)
			elementList->push_back(element);
	}
	
	free(tokenizedString);
}

LayoutElement *LayoutPool::getElement(string prefix)
{
	if(prefix=="null")
		return getNullElement();
	if(elements.find(prefix) != elements.end())
		return elements[prefix];
	
	string type = getConfigString("Type", NULL, prefix.c_str());
	
	if(!stricmp(type.c_str(), "group"))
		return new GroupElement(prefix);
	else if(!stricmp(type.c_str(), "flow"))
		return new LinearFlow(prefix);
	else if(!stricmp(type.c_str(), "label"))
		return new TextLabelElement(prefix);
	else if(!stricmp(type.c_str(), "module"))
		try {
			return new ChildModuleElement(prefix);
		} catch(ModuleLoadException) {
			return getNullElement();
		}
	else if(!stricmp(type.c_str(), "texture"))
		return new TextureElement(prefix);
	else if(!stricmp(type.c_str(), "minimap"))
		return new MinimapElement(prefix);
	else if(!stricmp(type.c_str(), "icon"))
		return new TaskIconElement(prefix);
	else if(!stricmp(type.c_str(), "branch"))
		return new BranchElement(prefix);
	else if(!stricmp(type.c_str(), "null"))
		return new NullElement();
	else if(!stricmp(type.c_str(), "")) {
		string warning = "No element type specified for element "+prefix+"; using null element.";
		warn(warning.c_str());
		return getNullElement();
	}
	else {
		string err = string("Invalid element type: \"")+type+"\" for element "+prefix+".";
		fatal(err.c_str());
		return NULL;
	}
}

LayoutLocation VWMPanel::elementAtPoint(int x, int y)
{
	LayoutLocation ret;
	
	updateLayout();
	
	LayoutCacheNode *pos = layout->elementAtPoint(x, y);
	ret.context = pos->context;
	ret.element = pos->element;
	
	return ret;
}

LayoutCacheNode *LayoutCacheNode::elementAtPoint(int x, int y)
{
	LayoutCacheNode *pos = this;
	LayoutCacheNode *next;
	
	do {
		next = NULL;
		for(int ii=pos->children.size()-1; ii>=0; ii--)
		{
			LayoutCacheNode *child = pos->children[ii];
			if(child->context.boundingRect.containsPoint(x, y)) {
				next = child;
				break;
			}
		}
		if(next)
			pos = next;
	} while(next);
	
	return pos;
}

void LayoutCacheNode::traverse(vector<LayoutCacheNode*> &visitedNodes)
{
	visitedNodes.push_back(this);
	for(unsigned ii=0; ii<children.size(); ii++)
		children[ii]->traverse(visitedNodes);
}

LayoutCacheNode *LayoutCacheNode::findSuffix(string suffix)
{
	LayoutCacheNode *pos = this;
	
	while(pos)
	{
		string varname = pos->element->prefix + suffix;
		if(rcIsDefined(varname.c_str())) {
			string var = getConfigLine(varname.c_str(), "", "");
			if(var != "")
				return pos;
		}
		
		pos = pos->parent;
	}
	
	return NULL;
}

/////////////////////////////////////////////////////////////////////////////

void printLayout(LayoutCacheNode *node, int indentLevel)
{
	for(int ii=0; ii<indentLevel; ii++)
		trace << "    ";
	
	trace << node->element->prefix << " (" << (int)node << ") "<<node->context.boundingRect.toString()<<"\n";
	
	for(unsigned ii=0; ii<node->children.size(); ii++)
		printLayout(node->children[ii], indentLevel+1);
}

