#if defined(__BORLANDC__)
#include <condefs.h>
USERC(".\mzscript.rc");
USEFILE("vctobpr.log");
#endif // defined(__BORLANDC__)
/*
 ============================================================================
 mzscript - an advanced script module for LiteStep/PureLS
 ============================================================================

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 ============================================================================
 mzscript 0.8.6l (2002-11-20) / banjo
    - added open text file and read bang.
    - added read next bang.
    - added tidy file details bang.
    - added tidy file details routine.
 mzscript 0.8.6l (2002-03-12) / Phil@leaf
    - New syntax to workaround possible conflicts with ckDialog, etc.
    - Added support for new syntax/old syntax.
        - Defaults to new syntax support.

 mzscript 0.8.5l (2002-03-07) / Phil@leaf
    - Added a function to turn variables from floats to integers.
	- Call !VarInt with the name of the variable.
    - Added code to correctly round up/down the integers based on float values.

 mzscript 0.8l (2001-10-23) / Phil@leaf
    - Project settings changed to produce a multithreaded DLL.
	  - Size of compiled DLL has been halved with this change.
	- Compiled against most recent CVS of LiteStep 0.24.6.

 mzscript 0.8 (2001-09-24) / qwilk
	- Now works with PureLS! (thanks to jugg)
	- Added !Refresh support
	- Added !Pause (courtesy of Maduin's pause.dll)
	- Made changes to make mzscript compile with current LSAPI
	- Cleaned up the source code

 mzscript 0.7.2 (2000-05-22) / Maze
	- First open source release (see readme for previous history)

 ============================================================================ */
 
#include "mzscript.h"

//#ifndef _DEBUG
#pragma warning ( disable : 4100 )
//#endif

//===========================================================================

char* szAppName = "mzscript";
char* szVersion = "mzscript 0.8.71 (maze/qwilk/phil@leaf/Banjo)";
char* szDetailed = "mzscript.dll version 0.8.71 date 2002-11-20 (maze/qwilk/phil@leaf/banjo)";

BOOL SYNTAX;

//===========================================================================
// Module initialization and cleanup
//===========================================================================

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;
	strcpy(LSdir, szPath);
	hwndParent = parent;
	hInstance = dllInst;
	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_CHILD, 0, 0, 0, 0, parent, NULL, dllInst, NULL);
	if (!hwndMain) return 1;
	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);
	SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);

	AddBangCmds();
	LoadSetup();

    return 0;
}

//--------------------

void quitModule(HINSTANCE dll)
{
	AutoSave();
	RemoveBangCmds();
    removeAllScriptBangs();
    varRemoveAll();

	SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, dll);
}

//===========================================================================
// Module initialization, cleanup & !refresh / Support functions
//===========================================================================

void AddBangCmds()
{
    AddBangCommand("!varSet", bangSetVar);
    AddBangCommand("!varRemove", bangRemoveVar);
    AddBangCommand("!varShow", bangShowVar);
    AddBangCommand("!varRun", bangRunVar);
    AddBangCommand("!varAdd", bangAddVar);
    AddBangCommand("!varMul", bangMulVar);
    AddBangCommand("!varInt", bangIntVar);

    AddBangCommand("!varSave", bangSaveVar);
    AddBangCommand("!varReplace", bangReplaceVar);
    AddBangCommand("!varSaveAll", bangSaveAllVars);

    AddBangCommand("!setlistsep", bangSetListSep);

    AddBangCommand("!ifExist", bangIfExist);
    AddBangCommand("!ifNExist", bangIfNExist);
    AddBangCommand("!ifEq", bangIfEq);
    AddBangCommand("!ifNEq", bangIfNEq);
    AddBangCommand("!ifEval", bangIfEval);

    AddBangCommand("!exec", bangExec);
    AddBangCommand("!msgbox", bangMsgBox);

    AddBangCommand("!openuserfile", bangOpenUFile);
    AddBangCommand("!nextuserrec", bangNextUserRec);
    AddBangCommand("!userfinish", bangUserFinish);

    AddBangCommand("!scriptload", readScriptFile);
    AddBangCommand("!scriptremove", bangRemoveScript);
    AddBangCommand("!pause", pause);


}

//--------------------

void RemoveBangCmds()
{
    RemoveBangCommand("!varSet");
    RemoveBangCommand("!varRemove");
    RemoveBangCommand("!varShow");
    RemoveBangCommand("!varRun");
    RemoveBangCommand("!varAdd");
    RemoveBangCommand("!varMul");
    RemoveBangCommand("!varInt");

    RemoveBangCommand("!varSave");
    RemoveBangCommand("!varReplace");
    RemoveBangCommand("!varSaveAll");

    RemoveBangCommand("!setlistsep");

    RemoveBangCommand("!ifExist");
    RemoveBangCommand("!ifNExist");
    RemoveBangCommand("!ifEq");
    RemoveBangCommand("!ifNEq");
    RemoveBangCommand("!ifEval");

    RemoveBangCommand("!exec");
    RemoveBangCommand("!msgbox");

    RemoveBangCommand("!scriptload");
    RemoveBangCommand("!scriptremove");
    RemoveBangCommand("!pause");

   RemoveBangCommand("!openuserfile");
    RemoveBangCommand("!nextuserrec");
    RemoveBangCommand("!userfinish");

}

//--------------------

void LoadSetup()
{
    char buffer[MAX_STR];

	if (LSdir[(strlen(LSdir)-1)] != '\\')
		sprintf(buffer,"%s\\step.rc",LSdir);
	else
		sprintf(buffer,"%sstep.rc", LSdir);


	GetRCString("mzScriptFile",scriptFile,buffer,MAX_STR);

    varSetFunc("xresolution",xRes);
    varSetFunc("yresolution",yRes);

    varSetFunc("year",yearF);
    varSetFunc("month",monthF);
    varSetFunc("day",dayF);
    varSetFunc("weekday",weekdayF);
    varSetFunc("hour",hourF);
    varSetFunc("minute",minF);
    varSetFunc("second",secF);

    varSetFunc("mousex",mousexF);
    varSetFunc("mousey",mouseyF);

    SYNTAX = GetRCBool("mzScriptNewSyntax", TRUE);

    GetRCString("mzBangChar",buffer,"|",MAX_STR);

    if (strlen(buffer)>0)
        bangChar = buffer[0];

    GetRCString("mzListSeparator",buffer,":",MAX_STR);
    if (strlen(buffer)>0)
        listSep = buffer[0];

    GetRCString("mzAutosaveVars",buffer,":",MAX_STR);
    strtok(buffer," \t");
    autosave=0;
    if (!nstrcmp(buffer,"replace")) autosave=1;
    else if (!nstrcmp(buffer,"save")) autosave=2;

    readScriptFile(hwndParent,scriptFile);
}

//--------------------

void AutoSave()
{
    if (autosave==1) {
        bangSaveAllVars(NULL,"replace");
    } else if (autosave==2) {
        bangSaveAllVars(NULL,"save");
    }
}

//===========================================================================

void errorMsg(char *msg)
{
    MessageBox(NULL, msg, szAppName, MB_OK | MB_ICONERROR | MB_APPLMODAL);
}

//--------------------

//Converts char c from lowercase to uppercase
char upcase(char c)
{
    if (c>='a' && c<='z') return c+'A'-'a';
    if (c=='�') return '�';
    if (c=='�') return '�';
    if (c=='�') return '�';
    return c;
}

//--------------------

int nstrcmp(char *a,char *b)
{
    int i=0;
    while ((*a)&&(*b)&&(!i)) {
        if (upcase(*a)<upcase(*b)) i=-1;
        if (upcase(*a)>upcase(*b)) i=1;
        a++;
        b++;
    }

    if (i) return i;

    if ((!(*a)) && (*b))
        return -1;

    if ((*a) && (!(*b)))
        return 1;

    return 0;
}


//===========================================================================
// Variable routines
//===========================================================================

// Does var exist?
int varExist(char *name)
{
    t_varlist *tmp=vars;
    while (tmp) {
        if (!nstrcmp(tmp->name,name))
            return 1;
        tmp=tmp->next;
    }
    return 0;
}

//--------------------

// Remove var from var list
void varRemove(char *name)
{
    t_varlist **tmp=&vars,*t2;

    while (*tmp) {
        if (!nstrcmp((*tmp)->name,name)) {
            free((*tmp)->name);
            if ((*tmp)->value)
                free((*tmp)->value);
            t2 = *tmp;
            *tmp = (*tmp)->next;
            free(t2);
            return;
        }
        tmp=&((*tmp)->next);
    }
    return;
}

//--------------------

// Sets value to var
void varSet(char *name,char *val)
{
    t_varlist *tmp=(t_varlist*)malloc(sizeof(t_varlist));
    varRemove(name);

    if (!tmp) //Out of memory
        return;

    tmp->name = (char*)malloc(strlen(name)+1);
    if (!tmp->name) {
        free(tmp);
        return;
    }
    strcpy(tmp->name,name);
    if (val) {
        if ((tmp->value = strdup(val)) == NULL)
            return;
    } else
        tmp->value = NULL;

    tmp->func = NULL;

    tmp->next = vars;
    vars = tmp;

    return;
}

//--------------------

// Set var to function
void varSetFunc(char *name,void (*f)(char *,int))
{
    t_varlist *tmp=(t_varlist*)malloc(sizeof(t_varlist));
    varRemove(name);

    if (!tmp) //Out of memory
        return;

    tmp->name = (char*)malloc(strlen(name)+1);
    if (!tmp->name) {
        free(tmp);
        return;
    }
    strcpy(tmp->name,name);
    tmp->value = NULL;
    tmp->func = f;

    tmp->next = vars;
    vars = tmp;

    return;
}

//--------------------

// Get value from var
char *varGet(char *name)
{
    t_varlist *tmp=vars;
    while (tmp) {
        if (!nstrcmp(tmp->name,name)) {
            if (tmp->func) {
                tmp->func(returnBuffer,MAX_STR);
                return returnBuffer;
            } else
                return tmp->value;
        }
        tmp=tmp->next;
    }
    return NULL;
}

//--------------------

// Clear all vars
void varRemoveAll(void)
{
    t_varlist *tmp=vars,*t2;
    vars = NULL;

    while (tmp) {
        t2=tmp->next;
        free(tmp->name);
        if (tmp->value)
            free(tmp->value);
        free(tmp);
        tmp=t2;
    }

    return;
}

//--------------------

// Expanding parser function
void varExpand(char *dest, const char *firstSrc, int n)
{
    char varName[256];
	char *tmp;
    char buffer[MAX_STR];
	char *src;
    int i;
	int type;
	
    char ENCAP1;
    char ENCAP2;

	src = buffer;

    VarExpansion(src, firstSrc);

    if (SYNTAX == FALSE)
	{
        ENCAP1 = '[';
        ENCAP2 = ']';
	}
    else
	{
        ENCAP1 = '{';
        ENCAP2 = '}';
	}

    while (*src && n>1)
        if (*src=='%' && *(src+1)==ENCAP1) {
            i=0;
            src+=2;
            while (*src!=ENCAP2 && *src!=':' && *src && i<255)
                varName[i++] = *src++;
            varName[i]=0;

            if (*src) {
                type=0;
                if (*src==':') {
                    src++;
                    if (*src=='_') {
                        type=2;
                        src++;
                    } else
                        type=1;
                }
                if (*src==ENCAP2) src++;

                tmp=varGet(varName);
                if (tmp) {
                    if (type==1) {
                        while (*tmp && *tmp!=listSep && n>1) {
                            n--;
                            *dest++=*tmp++;
                        }
                    } else {
                        if (type==2) {
                            while (*tmp && *tmp!=listSep && n>1) tmp++;
                            if (*tmp==listSep) tmp++;
                        }
                        while (*tmp && n>1) {
                            n--;
                            *dest++=*tmp++;
                        }
                    }
                }
            }
        } else if (*src=='?' && *(src+1)==ENCAP1) {
            i=0;
            while (*src && *src!='\"') src++;
            if (!*src) continue;
            src++;
            tmp=src;
            while (*src && *src!='\"') src++;
            if (!*src) continue;
            *src++=0;
            if (MessageBox(NULL, tmp, szAppName, MB_OKCANCEL | MB_ICONQUESTION | MB_APPLMODAL)==IDOK) {
                while (*src && *src!='\"') src++;
                if (!*src) continue;
                tmp=++src;
                while (*src && *src!='\"') src++;
                if (!*src) continue;
                *src++=0;
                while(*tmp && n>1) {
                    n--;
                    *dest++=*tmp++;
                }
            } else {
                i=0;
                while (*src && i<3) if (*src++=='\"') i++;
                if (!*src) continue;
                tmp=src;
                while (*src && *src!='\"') src++;
                if (!*src) continue;
                *src++=0;
                while(*tmp && n>1) {
                    n--;
                    *dest++=*tmp++;
                }
            }
            while (*src && *src!=ENCAP2) src++;
            if (*src) src++;
        } else {
            n--;
            *dest++=*src++;
        }

    if (n!=0) *dest=0;
}

//===========================================================================
// Functions for saving vars
//===========================================================================

void freeRC(void)
{
    t_linelist *tmp=rcBuffer,*tmp2;
    rcBuffer=NULL;

    while(tmp) {
        tmp2=tmp->next;
        free(tmp->line);
        free(tmp);
        tmp=tmp2;
    }
}

//--------------------

void readRC(char *name)
{
    char buffer[MAX_STR];
    t_linelist *tmp,**ptmp=&rcBuffer;
    FILE *f;

    freeRC();
    if ((f=fopen(name,"r")) == NULL) {
        errorMsg("Could not open file.");
        return;
    }

    fgets(buffer,MAX_STR,f);
    while(!feof(f)) {
        if ((tmp=(t_linelist*)malloc(sizeof(t_linelist))) == NULL) {
            fclose(f);
            return;
        }
        if ((tmp->line=strdup(buffer)) == NULL) {
            free(tmp);
            fclose(f);
            return;
        }
        tmp->next=*ptmp;
        *ptmp=tmp;
        ptmp=&(tmp->next);

        fgets(buffer,MAX_STR,f);
    }

    fclose(f);
}

//--------------------

void writeRC(char *name)
{
    t_linelist *tmp=rcBuffer;
    FILE *f;

    if ((f=fopen(name,"w")) == NULL) {
        errorMsg("Could not open file.");
        return;
    }

    while(tmp) {
        if (tmp->line) fputs(tmp->line,f);
        tmp=tmp->next;
    }

    fclose(f);
}

//--------------------

void setRCVar(char *name,char *what,int add)
{
    char buffer[MAX_STR],buffer2[MAX_STR],*cp,*var;
    t_linelist *tmp=rcBuffer,**ptmp=&rcBuffer;

    while(tmp) {
        if (!(tmp->line)) {
            tmp=tmp->next;
            continue;
        }
        strcpy(buffer,tmp->line);
        cp=buffer;
        while(*cp==' ' || *cp=='\t') cp++;
        if (strstr(cp,"*Script var")==cp ||
                strstr(cp,"*script var")==cp ||
                strstr(cp,"*SCRIPT var")==cp) {

            cp+=strlen("*Script v");
            if (!strtok(cp," \t")) continue;
            if ((var=strtok(NULL," \t")) == NULL) continue;

            if (!nstrcmp(var,name)) {
                sprintf(buffer2,"%s %s \"%s\"\n",buffer,name,what);
                if (tmp->line) free(tmp->line);
                tmp->line = strdup(buffer2);
                return;
            }

            ptmp=&(tmp->next);
        }
        tmp=tmp->next;
    }

    if (add) {
        sprintf(buffer2,"*Script var %s \"%s\"\n",name,what);
        if ((tmp=(t_linelist*)malloc(sizeof(t_linelist))) == NULL) return;
        if ((tmp->line=strdup(buffer2)) == NULL) {
            free(tmp);
            return;
        }
        tmp->next=*ptmp;
        *ptmp=tmp;
    }
}
//---removes stored user values------------
void freeUserBuffer(void)
{
	t_linelist *tmp1=userBuffer;
	t_linelist	*tmp2;
	userBuffer=NULL;
	while(tmp1){
		tmp2=tmp1->next;
		free(tmp1->line);
		free(tmp1);
		tmp1=tmp2;
	}
}

//===========================================================================
// Script routines
//===========================================================================

void addBangExec(char *bang,char *exec,LINETYPE l)
{
    t_banglist **tmp=&bangs,*tmp2;
    t_execlist **exectmp;

    while(*tmp) {
        if (!nstrcmp((*tmp)->name,bang)) {
            exectmp = &((*tmp)->toexec);

            while(*exectmp)
                exectmp = &((*exectmp)->next);
            *exectmp = (t_execlist*)malloc(sizeof(t_execlist));
            if(!(*exectmp))
                return;
            (*exectmp)->next = NULL;
            (*exectmp)->line = l;
            if (exec) {
                (*exectmp)->exec = strdup(exec);
                if (!((*exectmp)->exec)) {
                    free(*exectmp);
                    *exectmp = NULL;
                    return;
                }
            } else
                (*exectmp)->exec = NULL;

            return;
        }
        tmp=&((*tmp)->next);
    }

    //Bang not present already
    tmp2 = (t_banglist*)malloc(sizeof(t_banglist));
    if (!tmp2)
        return;

    tmp2->next=bangs;
    tmp2->refcount=0;
    tmp2->todelete=0;
    tmp2->next=bangs;

    tmp2->name=strdup(bang);
    if (!(tmp2->name)) {
        free(tmp2);
        return;
    }
    tmp2->toexec = (t_execlist*)malloc(sizeof(t_execlist));
    if (!(tmp2->toexec)) {
        free(tmp2->name);
        free(tmp2);
        return;
    }
    tmp2->toexec->next=NULL;
    tmp2->toexec->line=l;
    if (exec) {
        tmp2->toexec->exec = strdup(exec);
        if (!(tmp2->toexec->exec)){
            free(tmp2->toexec);
            free(tmp2->name);
            free(tmp2);
            return;
        }
    } else
        tmp2->toexec->exec = NULL;
    bangs = tmp2;
}

//--------------------

int existScriptBang(char *name)
{
    t_banglist *bangtmp=bangs;
    while(bangtmp) {
        if (!nstrcmp(bangtmp->name,name)) return 1;
        bangtmp = bangtmp->next;
    }
    return 0;
}

//--------------------

void freeScriptBang(t_banglist *bangtmp)
{
    t_execlist *exectmp,*exectmp2;

    exectmp = bangtmp->toexec;

    while(exectmp) {
        exectmp2 = exectmp->next;
        if (exectmp->exec) free(exectmp->exec);
        free(exectmp);
        exectmp = exectmp2;
    }

    RemoveBangCommand(bangtmp->name);
    free(bangtmp->name);
    free(bangtmp);
}

//--------------------

void removeScriptBang(char *name)
{
    t_banglist **bangtmp=&bangs,*bangtmp2;

    while(*bangtmp) {
        if (!nstrcmp((*bangtmp)->name,name)) {
            bangtmp2=(*bangtmp);
            (*bangtmp)=(*bangtmp)->next;

            if (bangtmp2->refcount) {
                bangtmp2->todelete=1;
                return;
            }

            freeScriptBang(bangtmp2);

            return;
        }
        bangtmp = &((*bangtmp)->next);
    }
}

//--------------------

void removeAllScriptBangs(void)
{
    t_banglist *bangtmp=bangs,*bangtmp2;
    t_execlist *exectmp,*exectmp2;

    bangs = NULL;

    while(bangtmp) {
        bangtmp2=bangtmp->next;
        exectmp = bangtmp->toexec;
        while(exectmp) {
            exectmp2 = exectmp->next;
            if (exectmp->exec) free(exectmp->exec);
            free(exectmp);
            exectmp = exectmp2;
        }
        RemoveBangCommand(bangtmp->name);
        free(bangtmp->name);
        free(bangtmp);
        bangtmp = bangtmp2;
    }
}

//===========================================================================
// Internal functions (to return things like screen width)
//===========================================================================

void xRes(char *place,int max) {
    sprintf(place,"%d",GetSystemMetrics(SM_CXSCREEN));
}

void yRes(char *place,int max) {
    sprintf(place,"%d",GetSystemMetrics(SM_CYSCREEN));
}

void yearF(char *place,int max) {
    SYSTEMTIME systemTime;
    GetLocalTime(&systemTime);
    sprintf(place,"%d",systemTime.wYear);
}

void monthF(char *place,int max) {
    SYSTEMTIME systemTime;
    GetLocalTime(&systemTime);
    sprintf(place,"%d",systemTime.wMonth);
}

void dayF(char *place,int max) {
    SYSTEMTIME systemTime;
    GetLocalTime(&systemTime);
    sprintf(place,"%d",systemTime.wDay);
}

void weekdayF(char *place,int max) {
    SYSTEMTIME systemTime;
    GetLocalTime(&systemTime);
    sprintf(place,"%d",systemTime.wDayOfWeek);
}

void hourF(char *place,int max) {
    SYSTEMTIME systemTime;
    GetLocalTime(&systemTime);
    sprintf(place,"%d",systemTime.wHour);
}


void minF(char *place,int max) {
    SYSTEMTIME systemTime;
    GetLocalTime(&systemTime);
    sprintf(place,"%d",systemTime.wMinute);
}

void secF(char *place,int max) {
    SYSTEMTIME systemTime;
    GetLocalTime(&systemTime);
    sprintf(place,"%d",systemTime.wSecond);
}

void mousexF(char *place,int max) {
    POINT p;
    GetCursorPos(&p);
    sprintf(place,"%d",p.x);
}

void mouseyF(char *place,int max) {
    POINT p;
    GetCursorPos(&p);
    sprintf(place,"%d",p.y);
}

//===========================================================================

void ExecCommand(HWND caller,char *szSample)
{
    char *newcmd, *args, *p;
    char command[MAX_STR];
    char dir[MAX_STR], full_dir[MAX_STR];
    SHELLEXECUTEINFO si;

    if(!szSample || strlen(szSample)<1)
        return;

    strcpy(command,szSample);

    if(*command == '\"') {
        newcmd = command + sizeof(char);
        newcmd = strtok(newcmd, "\"");
        args = strtok(NULL, "\0");

        if(!newcmd) {
            errorMsg("Missing closing quote.");
            return;
        }
    } else {
        newcmd = strtok(command, "\t ");
        if(!newcmd) {
            newcmd = command;
            args = NULL;
        } else {
            args = strtok(NULL, "\0");
        }
    }

    if (*newcmd==bangChar) *newcmd='!';

    p = newcmd + (strlen(newcmd) - 1)*sizeof(char);
    while(*newcmd == ' ' || *newcmd == '\t')
        ++newcmd;
    while(*p == ' ' || *p == '\t') {
        *p = '\0';
        --p;
    }

    if(*newcmd != '!') {
        if(args) {
            p = args + (strlen(args) - 1)*sizeof(char);
            while(*args == ' ' || *args == '\t' || *args == '\"')
                ++args;
            while(*p == ' ' || *p == '\t' || *p == '\"') {
                *p = '\0';
                --p;
            }
        }
    } else {
        if(args) {
            p = args + (strlen(args) - 1)*sizeof(char);
            while(*args == ' ' || *args == '\t')
                ++args;
            while(*p == ' ' || *p == '\t') {
                *p = '\0';
                --p;
            }
        }
    }

    if(*newcmd == '!') {
        ParseBangCommand(caller, newcmd, args);
    } else {
        memset(&si, 0, sizeof(si));
        si.cbSize = sizeof(SHELLEXECUTEINFO);
        si.hwnd = caller;
        si.lpFile = newcmd;
        si.lpParameters = args;
        si.nShow = SW_SHOWNORMAL;
        si.fMask = SEE_MASK_DOENVSUBST;
        _splitpath(newcmd, full_dir, dir, NULL, NULL);
        si.lpVerb = NULL;
        si.lpDirectory = full_dir;
        strcat(full_dir, dir);
        ShellExecuteEx(&si);
    }
}

//===========================================================================
// The bangs...
//===========================================================================

void execFirst(HWND caller,char *expr)
{
    int count;
    char *tmp;
    if (!expr) return;
    if (*expr=='\'') {
        expr++;
        expr = strtok(expr, "\'");
        if(!expr) {
            errorMsg("Missing closing \'.");
            return;
        }
        ExecCommand(caller,expr);
    } else if (*expr=='{') {
        expr++;
        tmp=expr;
        count=1;
        while (count) {
            if (*tmp=='{') count++;
            if (*tmp=='}') count--;
            if (!*tmp) {
                errorMsg("Missing closing }.");
                return;
            }
            if (count) tmp++;
        }
        *tmp=0;

        ExecCommand(caller,expr);
    } else
        ExecCommand(caller,expr);
}

//--------------------

void execSecond(HWND caller,char *expr)
{
    char *tmp;
    int count;
    if (!expr) return;
    if (*expr=='\'') {
        expr++;
        expr = strtok(expr, "\'");
        if(!expr) {
            errorMsg("Missing closing quote \'.");
            return;
        }
        expr = strtok(NULL, "\'");
        if (!expr) return;
        expr = strtok(NULL, "\'");
        if(!expr) {
            errorMsg("Missing else closing quote \'.");
            return;
        }
        ExecCommand(caller,expr);
    } else if (*expr=='{') {
        expr++;

        tmp=expr;
        count=1;
        while (count) {
            if (*tmp=='{') count++;
            if (*tmp=='}') count--;
            if (!*tmp) {
                errorMsg("Missing closing }.");
                return;
            }
            tmp++;
        }
        while (*tmp && *tmp!='{') tmp++;
        if (!*tmp) return;

        expr=++tmp;
        count=1;
        while (count) {
            if (*tmp=='{') count++;
            if (*tmp=='}') count--;
            if (!*tmp) {
                errorMsg("Missing closing }.");
                return;
            }
            if (count) tmp++;
        }

        *tmp=0;
        ExecCommand(caller,expr);
    }
}

//--------------------

void bangSetVar(HWND caller, const char *args)
{
    char *newvar, *val, command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    newvar = strtok(command, "\t ");
    if(!newvar) {
        newvar = command;
        val = NULL;
    } else {
        if ((val = strtok(NULL, "\0")) == NULL) {
            varSet(newvar,"");
            return;
        }
        while (*val==' ' || *val=='\t') val++;
        if (*val=='\"') {
            val++;
            if (*val!='\"')
                val = strtok(val, "\"");
            else
                *val=0;
            if (!val) {
                errorMsg("Missing closing quote.");
                return;
            }
        }
    }
    varSet(newvar,val);

    return;
}

//--------------------

void bangAddVar(HWND caller, const char *args)
{
    char *newvar, *val, *tmp, command[MAX_STR];
    int i,j,sign;
    double f,d;

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    newvar = strtok(command, "\t ");

    if(!newvar) return;

    if ((val = strtok(NULL, "\0")) == NULL) return;
    while (*val==' ' || *val=='\t') val++;
    if (*val=='\"') {
        val++;
        if (*val!='\"')
            val = strtok(val, "\"");
        else
            *val=0;
        if (!val) {
            errorMsg("Missing closing quote.");
            return;
        }
    }

    tmp = varGet(newvar);
    if (!tmp)
        return;

// Rounding up check.

    i = atoi(tmp);
    f = atof(tmp);
    d = f-i;
    if(d >= 0.5)
        i=i+1;

    j = atoi(val);
    f = atof(val);
    d = f-j;
    if(d >= 0.5)
        j=j+1;

//    

    i = i+j;
    sign = i<0;
    if (sign) i=-i;

    tmp=command+MAX_STR-1;
    *tmp=0;
    if (!i) *--tmp='0';
    while (i && tmp>command) {
        *--tmp='0'+(i%10);
        i/=10;
    }
    if (sign) *--tmp='-';

    varSet(newvar,tmp);

    return;
}

//--------------------

void bangMulVar(HWND caller, const char *args)
{
    char *newvar, *val, *tmp, command[MAX_STR];
    int i,sign;
    float f;

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    newvar = strtok(command, "\t ");

    if(!newvar) return;

    if ((val = strtok(NULL, "\0")) == NULL) return;
    while (*val==' ' || *val=='\t') val++;
    if (*val=='\"') {
        val++;
        if (*val!='\"')
            val = strtok(val, "\"");
        else
            *val=0;
        if (!val) {
            errorMsg("Missing closing quote.");
            return;
        }
    }

    tmp = varGet(newvar);
    if (!tmp)
        return;

    sscanf(val,"%f",&f);

    i = (int)((atoi(tmp))*f);
    sign = i<0;
    if (sign) i=-i;

    tmp=command+MAX_STR-1;
    *tmp=0;
    if (!i) *--tmp='0';
    while (i && tmp>command) {
        *--tmp='0'+(i%10);
        i/=10;
    }
    if (sign) *--tmp='-';

    varSet(newvar,tmp);

    return;
}

//--------------------

void bangIntVar(HWND caller, const char *args)
{
    char *newvar, *tmp, command[MAX_STR];
    double f,d;
    int i,sign;

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    newvar = strtok(command, "\t ");

    if(!newvar) return;

    tmp = varGet(newvar);
    if (!tmp)
        return;

// Rounding up check.

    i = atoi(tmp);
    f = atof(tmp);
    d = f-i;
    if(d >= 0.5)
        i=i+1;

//    

//  i = atoi(tmp);
    sign = i<0;
    if (sign) i=-i;

    tmp=command+MAX_STR-1;
    *tmp=0;
    if (!i) *--tmp='0';
    while (i && tmp>command) {
        *--tmp='0'+(i%10);
        i/=10;
    }
    if (sign) *--tmp='-';

    varSet(newvar,tmp);
}

//--------------------

void bangShowVar(HWND caller, const char *args)
{
    char *var, command[MAX_STR], val[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    var = strtok(command, "\t ");
    if(!var) {
        var = command;
    }
    if (varExist(var)) {
        sprintf(val,"Exist: value = %s",varGet(var));
    } else {
        sprintf(val,"Doesnt exist");
    }
    MessageBox(NULL, val, szAppName, MB_OK | MB_APPLMODAL);
    return;
}

//--------------------

void bangMsgBox(HWND caller, const char *args)
{

    char command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    MessageBox(NULL, command, szAppName, MB_OK | MB_APPLMODAL);
    return;
}

//--------------------

void bangRemoveVar(HWND caller, const char *args)
{
    char *var, command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);

    var = strtok(command, "\t ");
    if(!var) {
        var = command;
    }
    varRemove(var);
    return;
}

//--------------------

void bangRunVar(HWND caller, const char *args)
{
    char *var, command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);

    var = strtok(command, "\t ");
    if(!var) {
        var = command;
    }
    ExecCommand(caller,varGet(var));

    return;

}

//--------------------

void bangSaveVar(HWND caller, const char *args)
{
    char *var,*tmp, command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    var = strtok(command, "\t ");
    if(!var) var = command;

    if (varExist(var)) {
        readRC(scriptFile);
        tmp=varGet(var);
        setRCVar(var,tmp,1);
        writeRC(scriptFile);
        freeRC();
    }
    return;
}

//--------------------

void bangReplaceVar(HWND caller, const char *args)
{

    char *var,*tmp, command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    var = strtok(command, "\t ");
    if(!var) var = command;

    if (varExist(var)) {
        readRC(scriptFile);
        tmp=varGet(var);
        setRCVar(var,tmp,1);
        writeRC(scriptFile);
        freeRC();
    }
    return;
}

//--------------------

void bangSaveAllVars(HWND caller, const char *args)
{
    char *var,command[MAX_STR];
    t_varlist *tmp=vars;
    int replace=0;

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    var = strtok(command, "\t ");
    if(!var) var = command;

    replace=nstrcmp(var,"replace");

    readRC(scriptFile);
    while(tmp) {
        setRCVar(tmp->name,tmp->value,replace);
        tmp=tmp->next;
    }
    writeRC(scriptFile);
    freeRC();
    return;
}

//--------------------

void bangIfExist(HWND caller, const char *args)
{

    char *var, *val, command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);

    var = strtok(command, "\t ");
    if(!var) {
        var = command;
        val = NULL;
    } else {
        val = strtok(NULL, "\0");
    }

    if (varExist(var))
        execFirst(caller,val);
    else
        execSecond(caller,val);

    return;
}

//--------------------

void bangIfNExist(HWND caller, const char *args)
{
    char *var, *val, command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);

    var = strtok(command, "\t ");
    if(!var) {
        var = command;
        val = NULL;
    } else {
        val = strtok(NULL, "\0");
    }

    if (!varExist(var))
        execFirst(caller,val);
    else
        execSecond(caller,val);

    return;
}

//--------------------

void bangIfEq(HWND caller, const char *args)
{
    char *var, *comp, *exec, command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);

    var = strtok(command, "\t ");
    if (var) {
        if ((comp = strtok(NULL, "\"")) == NULL) {
            errorMsg("Missing quote");
            return;
        }
        if ((exec = strtok(NULL, "\"")) == NULL) {
            errorMsg("Missing closing quote");
            return;
        }
        while ((*exec == ' ') || (*exec == '\t')) exec++;

        if (!nstrcmp(comp,varGet(var)))
            execFirst(caller,exec);
        else
            execSecond(caller,exec);
    }
    return;
}

//--------------------

void bangIfNEq(HWND caller, const char *args)
{

    char *var, *comp, *exec, command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);

    var = strtok(command, "\t ");
    if (var) {
        if ((comp = strtok(NULL, "\"")) == NULL) {
            errorMsg("Missing quote");
            return;
        }
        if ((exec = strtok(NULL, "\"")) == NULL) {
            errorMsg("Missing closing quote");
            return;
        }
        while ((*exec == ' ') || (*exec == '\t')) exec++;

        if (nstrcmp(comp,varGet(var)))
            execFirst(caller,exec);
        else
            execSecond(caller,exec);
    }
    return;
}

//--------------------

int evalIf(char *e,char **theRet)
{
    char *first,*second,*cmp,*tmp,*tmp2,*ret;

    if (!e) return 0;
    *theRet=e;

    tmp = e;
    while (*tmp && *tmp!='\"') tmp++;
    if (!*tmp) {
        errorMsg("Missing quote.");
        return 0;
    }
    first=++tmp;
    while (*tmp && *tmp!='\"') tmp++;
    if (!*tmp) {
        errorMsg("Missing quote.");
        return 0;
    }
    *tmp++=0;
    cmp=tmp;
    while (*tmp && *tmp!='\"') tmp++;
    if (!*tmp) {
        errorMsg("Missing quote.");
        return 0;
    }
    *tmp++=0;
    while (*cmp==' ' || *cmp=='\t') cmp++;
    tmp2 = cmp;
    while (*tmp2!=' ' && *tmp2!='\t') tmp2++;
    *tmp2=0;

    second = tmp;
    while (*tmp && *tmp!='\"') tmp++;
    if (!*tmp) {
        errorMsg("Missing quote.");
        return 0;
    }
    *tmp++=0;
    ret=tmp;
    while (*ret==' ' || *ret=='\t'  || *ret==')') ret++;
    *theRet = ret;

    if (!nstrcmp(cmp,"=")) {
        if (!nstrcmp(first,second))
            return 1;
    } else if (!nstrcmp(cmp,"<=")) {
        if (nstrcmp(first,second)<=0)
            return 1;
    } else if (!nstrcmp(cmp,">=")) {
        if (nstrcmp(first,second)>=0)
            return 1;
    } else if (!nstrcmp(cmp,"<")) {
        if (nstrcmp(first,second)<0)
            return 1;
    } else if (!nstrcmp(cmp,">")) {
        if (nstrcmp(first,second)>0)
            return 1;
    } else if (!nstrcmp(cmp,"<>")) {
        if (nstrcmp(first,second))
            return 1;
    }

    return 0;
}

//--------------------

void bangIfEval(HWND caller, const char *args)
{

    char *command, buffer[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(buffer,args,MAX_STR);

    if (evalIf(buffer,&command))
        execFirst(caller,command);
    else
        execSecond(caller,command);

    return;
}

//--------------------

void bangScript(HWND caller, LPCSTR args, LPCSTR command)
{
    t_banglist *bangtmp=bangs;
    t_execlist *exectmp,*exectmp2;
    char *label,buffer[MAX_STR];

    while(bangtmp) {
		if (!nstrcmp(bangtmp->name,(char *)args)) {
            (bangtmp->refcount)++;
            exectmp = bangtmp->toexec;
            while(exectmp && exectmp->line!=EXIT) {
                label = buffer;
                varExpand(buffer,exectmp->exec,MAX_STR);
                switch (exectmp->line) {
                    case EXEC:
                        ExecCommand(caller,buffer);
                        break;
                    case GOTOIF:
                        if (!evalIf(buffer,&label))
                            break;
                    case GOTO:
                        exectmp2 = bangtmp->toexec;
                        while (exectmp2 && !(exectmp2->line==LABEL &&
                                    !nstrcmp(exectmp2->exec,label)))
                            exectmp2 = exectmp2->next;
                        exectmp = exectmp2;
                        break;

                }
                if (exectmp) exectmp = exectmp->next;
            }
            (bangtmp->refcount)--;
            if ((!(bangtmp->refcount)) && (bangtmp->todelete))
                freeScriptBang(bangtmp);

            return;
        }
        bangtmp =bangtmp->next;
    }
}

//--------------------

//Execute command
void bangExec(HWND caller, const char *args)
{

    char command[MAX_STR];

    if(!args || strlen(args)<1)
        return;

    varExpand(command, args,MAX_STR);
    ExecCommand(caller,command);
    return;
}

//--------------------

// Remove bang script
void bangRemoveScript(HWND parent, const char *scriptname)
{
    char buffer[MAX_STR];
    varExpand(buffer+1, scriptname,MAX_STR-1);
    *buffer='!';
    removeScriptBang(buffer);
}

//--------------------

// Read script definition file
void readScriptFile(HWND parent, const char *scriptFile)
{
    char buffer[MAX_STR];
    char *tmp,*var, *exec, command[MAX_STR],currentBang[MAX_STR];
    FILE *f;
    int i;

    varExpand(buffer, scriptFile, MAX_STR);
    f = LCOpen (buffer);

    if (f) {
        buffer[0] = 0;
        currentBang[0] = 0;
        while (LCReadNextConfig (f, "*Script", buffer, sizeof (buffer)))
        {

            if(strlen(buffer)<1)
                continue;

            tmp=buffer;
            while (tmp>=buffer && (*tmp==' ' || *tmp=='\t')) *tmp--=0;

            VarExpansion(command, buffer);

            if ((var = strtok(command, "\t ")) == NULL)
                continue;

            var = strtok(NULL, "\t ");
            if(!var) {
                var = command;
                exec = NULL;
            } else {
                exec = strtok(NULL, "\0");
            }
            if (exec) while (*exec==' ' || *exec=='\t') exec++;

            if (!nstrcmp(var,"start"))
                ExecCommand(parent,exec);

            if (!nstrcmp(var,"var"))
                bangSetVar(parent,exec);

            if ((!nstrcmp(var,"bang")) && (currentBang[0] == 0)) {
                strcpy(currentBang,exec);
                if (existScriptBang(currentBang))
                    removeScriptBang(currentBang);
            }

            for(i=0;i<5;i++) {
                if ((!nstrcmp(var,par[i].command)) && (currentBang[0] != 0))
                    addBangExec(currentBang,exec,par[i].type);
            }

            if ((!nstrcmp(var,"~bang")) && (currentBang[0] != 0)) {
				AddBangCommandEx(currentBang,bangScript);
                currentBang[0] = 0;
            }
		}
		LCClose(f);
	} else
		errorMsg("No file");

}

//--------------------

void bangSetListSep(HWND parent, const char *arg)
{
	if (arg)
		if (*arg) listSep = *arg;

}

//--------------------

void pause(HWND parent, LPCTSTR pszArgs )
{
	LONG lInterval = atoi( pszArgs );
	LONG lTime = GetTickCount();
	MSG msg;
	
	if( lInterval > 0 )
	{
		while( (GetTickCount() - lTime) < lInterval )
		{
			if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
			{
				TranslateMessage( &msg );
				DispatchMessage( &msg );
			}
		}
	}
}
//--------------------
void bangOpenUFile(HWND parent, const char *args)
{
	char command[MAX_STR];
	char buffer[MAX_STR];
	char *filnam;
	char *savnam;
	t_linelist *tmp=NULL;
	int count=0;

        if(rdUserCount!=0){
 	    errorMsg("old file details still present");
	    return;
        }
	if (!args || strlen(args)<1) return;
	varExpand(command,args,MAX_STR);
	filnam=strtok(command,"\t ");
	if (!filnam){
		errorMsg("no filename found");
		return;
	}
	if (*filnam != '\"'){
		errorMsg("Missing opening quotes");
		return;
	}
	savnam=filnam;
	count=(strlen(filnam) -1);
        savnam+=count;
	if(*savnam != '\"'){
		errorMsg("Missing closing quotes");
		return;
	}
        *savnam='\0';
	filnam++;

	FILE *f;
        if ((f=fopen(filnam,"r")) == NULL) {
        errorMsg("Could not open file.");
        return;
        }
	fgets(buffer,MAX_STR,f);
	while(!feof(f)) {
		if((userBuffer=(t_linelist*)malloc(sizeof(t_linelist)))==NULL){
			fclose(f);
                        errorMsg("out of memory");
			return;
		}
		if(buffer==NULL){
			fclose(f);
			return;
		}
		userBuffer->line=strdup(buffer);
            varExpand(command,buffer,MAX_STR);
 		rdUserCount++;
		userBuffer->next=tmp;
		tmp=userBuffer;
		fgets(buffer,MAX_STR,f);
	}
	rdUserCurrent=rdUserCount;
	rdUserCurrent+=1;
	fclose(f);
 	return;
}
//--------------------------------
void bangNextUserRec(HWND parent, const char *args)
{
	int count=1;
	int i;
	int j;
	int k;
	char buffer[MAX_STR];
	char *loc1;
	char *loc2;
      char v;
	t_linelist *tmp=userBuffer;
	int saveVal=0;
	char val[MAX_STR];
	rdUserCurrent--;
	if(rdUserCurrent==0){
	   	freeUserBuffer();
		varSet("UserVal1","EOF");		
		varSet("UserVal2","EOF");		
		varSet("UserVal3","EOF");		
		return;
	}

	while(count<rdUserCurrent) {
		tmp=tmp->next;
		count++;
	}
	strcpy(buffer,tmp->line);
	loc1=buffer;
        for(i=1;i<4;i++){
		while(*loc1==' ' || *loc1=='\t' || *loc1=='\n'){
                loc1++;
                }
		if(*loc1=='\0' || (!*loc1) || (*loc1==NULL)){
			varSet("UserVal3","VOID");
			if(i<3){
				varSet("UserVal2","VOID");
			}
			if(i<2){
				varSet("UserVal1","VOID");
			}
			return;
		}
		loc2=loc1;
		for(k=0;k<MAX_STR;k++){
            	val[k]=NULL;
		}
		if(i<3){
			while((*loc2!=listSep) && (*loc2!='\n'))loc2++;
		} else
			{
			while(*loc2!='\n' && *loc2!='\0' && (*loc2) && (*loc2!=listSep))loc2++;
			}
		for(j=0;loc1<loc2;j++){
			val[j]=*loc1;
			loc1++;
			saveVal=j;
		}
		saveVal+=1;
		val[saveVal]='\0';
		if(i==1){
			varSet("UserVal1",val);
		}
		if(i==2){
			varSet("UserVal2",val);
		}
		if(i==3){
			varSet("UserVal3",val);
		}
		loc1++;
        }
return;
}
//----------------------
void bangUserFinish(HWND parent, const char *args)
{
	freeUserBuffer();
	varRemove("UserVal1");
	varRemove("UserVal2");
	varRemove("UserVal3");
	rdUserCount=0;
	rdUserCurrent=0;
	return;
}
//===========================================================================
// Message handling
//===========================================================================

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{

		case LM_GETREVID:
		{
			char *buf = (char *) lParam;

			if (wParam == 0)
			{
				strcpy(buf, szVersion);
			}
			else if (wParam == 1)
			{
				strcpy(buf, szDetailed);
			} else
			{
				strcpy(buf, "");
			}
			return strlen(buf);
		}
		break;

		case LM_REFRESH:
		{
			AutoSave();
		    removeAllScriptBangs();
			varRemoveAll();
			LoadSetup();
		}
		break;

	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

//===========================================================================

#define DllEntryPoint
