/*
 ============================================================================
 mzscript - an advanced script module for LiteStep/PureLS
 ============================================================================

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 ============================================================================ */

#ifndef __MZSCRIPT_H
#define __MZSCRIPT_H

#include <stdio.h>
#include <windows.h>
#include <shellapi.h>
#include "../lsapi/lsapi.h"
#include "wharfdata.h"

//===========================================================================
// Variables
//===========================================================================

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
HINSTANCE hInstance;
HWND hwndMain, hwndParent;
int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

#define MAX_STR 2048

//--------------------

typedef struct _t_varlist {
	char *name,*value;
	void (*func)(char *,int);
	struct _t_varlist *next;
} t_varlist;


typedef enum {EXEC,LABEL,GOTO,GOTOIF,EXIT} LINETYPE;

typedef struct _t_execlist {
	char *exec;
	LINETYPE line;
	struct _t_execlist *next;
} t_execlist;


typedef struct _t_banglist {
	char *name;
	int refcount;
	int todelete;
	t_execlist *toexec;
	struct _t_banglist *next;
} t_banglist;

typedef struct {
	char *command;
	LINETYPE type;
} t_par;


typedef struct _t_linelist {
	char *line;
	struct _t_linelist *next;
} t_linelist;

//--------------------

char LSdir[256] = "";
char bangChar='|';
char listSep=':';
char scriptFile[MAX_STR];
t_varlist *vars=NULL;
t_banglist *bangs=NULL;
t_linelist *rcBuffer=NULL;
int autosave=0;
char returnBuffer[MAX_STR];
int rdUserCount=0;
int rdUserCurrent=0;
t_linelist *userBuffer=NULL;
t_par par[5] = {{"exec",EXEC},{"label",LABEL},{"goto",GOTO},
    {"gotoif",GOTOIF},{"exit",EXIT}};


//===========================================================================
// Declarations
//===========================================================================

void AddBangCmds();
void RemoveBangCmds();
void LoadSetup();
void AutoSave();

void errorMsg(char *msg);
char upcase(char c);
int nstrcmp(char *a,char *b);

int varExist(char *name);
void varRemove(char *name);
void varSet(char *name,char *val);
void varSetFunc(char *name,void (*f)(char *,int));
char *varGet(char *name);
void varRemoveAll(void);
void varExpand(char *dest,const char *firstSrc,int n);

void freeRC(void);
void readRC(char *name);
void writeRC(char *name);
void setRCVar(char *name,char *what,int add);

void addBangExec(char *bang,char *exec,LINETYPE l);
int existScriptBang(char *name);
void freeScriptBang(t_banglist *bangtmp);
void removeScriptBang(char *name);
void removeAllScriptBangs(void);

void xRes(char *place,int max);
void yRes(char *place,int max);
void yearF(char *place,int max);
void monthF(char *place,int max);
void dayF(char *place,int max);
void weekdayF(char *place,int max);
void hourF(char *place,int max);
void minF(char *place,int max);
void secF(char *place,int max);
void mousexF(char *place,int max);
void mouseyF(char *place,int max);

void ExecCommand(HWND caller,char *szSample);

void execFirst(HWND caller,char *expr);
void execSecond(HWND caller,char *expr);

void bangSetVar(HWND caller, const char *args);
void bangAddVar(HWND caller, const char *args);
void bangMulVar(HWND caller, const char *args);
void bangIntVar(HWND caller, const char *args);
void bangShowVar(HWND caller, const char *args);
void bangMsgBox(HWND caller, const char *args);
void bangRemoveVar(HWND caller, const char *args);
void bangRunVar(HWND caller, const char *args);
void bangSaveVar(HWND caller, const char *args);
void bangReplaceVar(HWND caller, const char *args);
void bangSaveAllVars(HWND caller, const char *args);
void bangIfExist(HWND caller, const char *args);
void bangIfNExist(HWND caller, const char *args);
void bangIfEq(HWND caller, const char *args);
void bangIfNEq(HWND caller, const char *args);
int evalIf(char *e,char **theRet);
void bangIfEval(HWND caller, const char *args);
void bangScript(HWND caller, LPCSTR args, LPCSTR command);
void bangExec(HWND caller, const char *args);
void bangRemoveScript(HWND parent, const char *scriptname);
void readScriptFile(HWND parent, const char *scriptFile);
void bangSetListSep(HWND parent, const char *arg);
void pause(HWND parent, LPCTSTR pszArgs );
void bangOpenUFile(HWND caller, const char *args);
void bangNextUserRec(HWND caller, const char *args);
void bangUserFinish(HWND caller, const char *args);


//===========================================================================
// External
//===========================================================================

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dll);
}

#endif
