09.11.2002
----------

Update: based on indiestep core popup2.dll 1.13,
pattern match filtering has been fixed.

----------

do you want to have different looking popups?
This is a little hack - bPopup2.dll is a copy of Popup2.dll
with all the .rc commands starting with "b", so you can have
two different looking popups.


Load
----
Load it like usual: LoadModule $moduledir$bPopup2.dll

Configuration
-------------
Like Popup2, but commands must start with "b":

bPopupTitleHeight
bPopupTitlePix
bPopupNoBevel
bPopupEntryColor
etc.

You can call it with !bpopup bang:

example
------- 
*bPopup "bPopup Test" !New !bpopup
*bPopup "test 1" "!popupfolder:c:\yourpath"
*bPopup "test 2" "!popuptasks"
*bPopup "test 3" "notepad"
*bPopup ~New

note
----
the "internal" bangs (!popupfolder, !popuptasks, etc.)
does not start with "b"

the following bangs (that can be called from outside the popup)
does start with "b":
!bPopup
!bPopuptasks
!bPopupdesktops
