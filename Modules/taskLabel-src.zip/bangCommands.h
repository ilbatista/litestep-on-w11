#if !defined(__BANGCOMMANDS_H)
#define __BANGCOMMANDS_H

void AddBangCommands(const string &labelName);
void RemoveBangCommands(const string &labelName);

#endif
