#include "common.h"
#include "bangCommands.h"
#include "TaskLabel.h"
#include "Font.h"
#include "Texture.h"

#define TIMER_MOUSETRACK 1
#define TIMER_UPDATE 2

int lsMessages[] = {
	LM_WINDOWACTIVATED,
	0
};

TaskLabel::TaskLabel(const string &name)
{
	this->name = name;

	mousePressed = false;
	mouseInside = false;

	hWnd = 0;
	hInstance = 0;
	visible = false;

	hCurrentTask = 0;

	backgroundDC = 0;
	bufferDC = 0;
	backgroundBitmap = 0;
	bufferBitmap = 0;

	background = 0;
	font = 0;

	AddBangCommands(name);
}

TaskLabel::~TaskLabel()
{
	RemoveBangCommands(name);

	if(hWnd != 0)
		DestroyWindow(hWnd);

	if(--instanceCount == 0)
		UnregisterClass("TaskLabelLS", hInstance);

	if(backgroundBitmap != 0)
	{
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
		DeleteDC(backgroundDC);
		DeleteObject(backgroundBitmap);
	}

	if(bufferBitmap != 0)
	{
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
		DeleteDC(bufferDC);
		DeleteObject(bufferBitmap);
	}

	delete background;
	delete font;
}

void TaskLabel::load(HINSTANCE hInstance)
{
	this->hInstance = hInstance;
	reconfigure();
}

NameValuePair justifyValues[] = {
	{ "left", DT_LEFT },
	{ "center", DT_CENTER },
	{ "right", DT_RIGHT },
	{ 0, 0 }
};

void TaskLabel::reconfigure()
{
	int screenX = GetSystemMetrics(SM_CXSCREEN);
	int screenY = GetSystemMetrics(SM_CYSCREEN);

	setAlwaysOnTop(GetRCBoolean(name, "AlwaysOnTop"));
	setBackground(GetRCTexture(name, ""));
	setFont(GetRCFont(name, "Font"));
	setJustify(GetRCNamedValue(name, "Justify", justifyValues, DT_CENTER));
	setLeftBorder(GetRCInt(name, "LeftBorder", 0));
	setTopBorder(GetRCInt(name, "TopBorder", 0));
	setRightBorder(GetRCInt(name, "RightBorder", 0));
	setBottomBorder(GetRCInt(name, "BottomBorder", 0));

	reposition(GetRCCoordinate(name, "X", 0, screenX),
		GetRCCoordinate(name, "Y", 0, screenY),
		GetRCDimension(name, "Width", 64, screenX),
		GetRCDimension(name, "Height", 64, screenY));

	leftClickCommand = GetRCLine(name, "OnLeftClick", "");
	leftDoubleClickCommand = GetRCLine(name, "OnLeftDoubleClick", "");
	middleClickCommand = GetRCLine(name, "OnMiddleClick", "");
	middleDoubleClickCommand = GetRCLine(name, "OnMiddleDoubleClick", "");
	rightClickCommand = GetRCLine(name, "OnRightClick", "");
	rightDoubleClickCommand = GetRCLine(name, "OnRightDoubleClick", "");
	enterCommand = GetRCLine(name, "OnMouseEnter", "");
	leaveCommand = GetRCLine(name, "OnMouseLeave", "");

	if(!GetRCBoolean(name, "StartHidden"))
		show();
}

void TaskLabel::setAlwaysOnTop(boolean alwaysOnTop)
{
	this->alwaysOnTop = alwaysOnTop;

	if(hWnd != 0)
	{
		ModifyStyle(hWnd, WS_POPUP, WS_CHILD);
		SetParent(hWnd, alwaysOnTop ? 0 : GetLitestepDesktop());
		ModifyStyle(hWnd, WS_CHILD, WS_POPUP);

		SetWindowPos(hWnd, alwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
			0, 0, 0, 0,
			SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
	}
}

void TaskLabel::setBackground(Texture *background)
{
	delete this->background;
	this->background = background;
	repaint(true);
}

void TaskLabel::setFont(Font *font)
{
	delete this->font;
	this->font = font;
	repaint();
}

void TaskLabel::setJustify(int justify)
{
	this->justify = justify;
	repaint();
}

void TaskLabel::setLeftBorder(int leftBorder)
{
	this->leftBorder = leftBorder;
	repaint();
}

void TaskLabel::setTopBorder(int topBorder)
{
	this->topBorder = topBorder;
	repaint();
}

void TaskLabel::setRightBorder(int rightBorder)
{
	this->rightBorder = rightBorder;
	repaint();
}

void TaskLabel::setBottomBorder(int bottomBorder)
{
	this->bottomBorder = bottomBorder;
	repaint();
}

void TaskLabel::repaint(boolean invalidateCache)
{
	if(hWnd != 0)
	{
		if(invalidateCache)
		{
			if(backgroundDC != 0 && backgroundBitmap != 0)
			{
				backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
				DeleteObject(backgroundBitmap);
				backgroundBitmap = 0;
			}
		}

		InvalidateRect(hWnd, 0, FALSE);
	}
}

void TaskLabel::move(int x, int y)
{
	this->x = x;
	this->y = y;

	if(hWnd != 0)
	{
		SetWindowPos(hWnd, 0, x, y, width, height,
			SWP_NOACTIVATE | SWP_NOZORDER);
	}
}

void TaskLabel::reposition(int x, int y, int width, int height)
{
	this->x = x;
	this->y = y;
	this->height = height;
	this->width = width;

	if(hWnd != 0)
	{
		SetWindowPos(hWnd, 0, x, y, width, height,
			SWP_NOACTIVATE | SWP_NOZORDER);
	}
}

void TaskLabel::resize(int width, int height)
{
	this->height = height;
	this->width = width;

	if(hWnd != 0)
	{
		SetWindowPos(hWnd, 0, x, y, width, height,
			SWP_NOACTIVATE | SWP_NOZORDER);
	}
}

void TaskLabel::hide()
{
	visible = false;

	if(hWnd != 0)
		ShowWindow(hWnd, SW_HIDE);
}

void TaskLabel::show()
{
	if(hWnd == 0)
	{
		if(++instanceCount == 1)
		{
			WNDCLASSEX wc;

			wc.cbSize = sizeof(WNDCLASSEX);
			wc.style = CS_GLOBALCLASS | CS_DBLCLKS;
			wc.lpfnWndProc = TaskLabel::windowProcedure;
			wc.cbClsExtra = 0;
			wc.cbWndExtra = sizeof(TaskLabel *);
			wc.hInstance = hInstance;
			wc.hbrBackground = 0;
			wc.hCursor = LoadCursor(0, IDC_ARROW);
			wc.hIcon = 0;
			wc.lpszMenuName = 0;
			wc.lpszClassName = "TaskLabelLS";
			wc.hIconSm = 0;

			RegisterClassEx(&wc);
		}

		hWnd = CreateWindowEx(WS_EX_TOOLWINDOW,
			"TaskLabelLS",
			0,
			WS_POPUP,
			x, y,
			width, height,
			0,
			0,
			hInstance,
			this);

		setAlwaysOnTop(alwaysOnTop);

		SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE,
			(WPARAM) hWnd, (LPARAM) lsMessages);

		updateTaskInfo();
		SetTimer(hWnd, TIMER_UPDATE, 1000, 0);
	}

	visible = true;
	ShowWindow(hWnd, SW_SHOW);
}

void TaskLabel::updateTaskInfo()
{
	HWND hCurrentTask = GetForegroundWindow();
	boolean changed = false;
	char buffer[256];

	if(hCurrentTask != this->hCurrentTask)
	{
		this->hCurrentTask = hCurrentTask;
		GetWindowText(hCurrentTask, buffer, 256);
		changed = true;
	}
	else
	{
		GetWindowText(hCurrentTask, buffer, 256);

		if(strcmp(text.c_str(), buffer) != 0)
			changed = true;
	}

	if(changed)
	{
		if(IsAppWindow(hCurrentTask))
			text = buffer;
		else
			text = "";

		repaint();
	}
}

void TaskLabel::onLButtonDblClk(int x, int y)
{
	if(leftDoubleClickCommand.length() > 0)
		LSExecute(hWnd, leftDoubleClickCommand.c_str(), SW_SHOWNORMAL);
}

void TaskLabel::onLButtonDown(int x, int y)
{
	if(!mousePressed)
		mousePressed = true;
}

void TaskLabel::onLButtonUp(int x, int y)
{
	if(mousePressed)
	{
		POINT pt;
		pt.x = x;
		pt.y = y;

		RECT rc;
		GetClientRect(hWnd, &rc);

		if(PtInRect(&rc, pt))
		{
			if(leftClickCommand.length() > 0)
				LSExecute(hWnd, leftClickCommand.c_str(), SW_SHOWNORMAL);
		}

		mousePressed = false;
	}
}

void TaskLabel::onMButtonDblClk(int x, int y)
{
	if(middleDoubleClickCommand.length() > 0)
		LSExecute(hWnd, middleDoubleClickCommand.c_str(), SW_SHOWNORMAL);
}

void TaskLabel::onMButtonDown(int x, int y)
{
	if(!mousePressed)
		mousePressed = true;
}

void TaskLabel::onMButtonUp(int x, int y)
{
	if(mousePressed)
	{
		POINT pt;
		pt.x = x;
		pt.y = y;

		RECT rc;
		GetClientRect(hWnd, &rc);

		if(PtInRect(&rc, pt))
		{
			if(middleClickCommand.length() > 0)
				LSExecute(hWnd, middleClickCommand.c_str(), SW_SHOWNORMAL);
		}

		mousePressed = false;
	}
}

void TaskLabel::onRButtonDblClk(int x, int y)
{
	if(rightDoubleClickCommand.length() > 0)
		LSExecute(hWnd, rightDoubleClickCommand.c_str(), SW_SHOWNORMAL);
}

void TaskLabel::onRButtonDown(int x, int y)
{
	if(!mousePressed)
		mousePressed = true;
}

void TaskLabel::onRButtonUp(int x, int y)
{
	if(mousePressed)
	{
		POINT pt;
		pt.x = x;
		pt.y = y;

		RECT rc;
		GetClientRect(hWnd, &rc);

		if(PtInRect(&rc, pt))
		{
			if(rightClickCommand.length() > 0)
				LSExecute(hWnd, rightClickCommand.c_str(), SW_SHOWNORMAL);
		}

		mousePressed = false;
	}
}

void TaskLabel::onMouseEnter()
{
	if(enterCommand.length() > 0)
		LSExecute(hWnd, enterCommand.c_str(), SW_SHOWNORMAL);
}

void TaskLabel::onMouseLeave()
{
	if(leaveCommand.length() > 0)
		LSExecute(hWnd, leaveCommand.c_str(), SW_SHOWNORMAL);
}

void TaskLabel::onMouseMove(int x, int y)
{
	if(!mouseInside)
	{
		mouseInside = true;
		onMouseEnter();
	}

	SetTimer(hWnd, TIMER_MOUSETRACK, 100, 0);
}

void TaskLabel::onPaint(HDC hDC)
{
	RECT r;
	GetClientRect(hWnd, &r);

	int width = r.right - r.left;
	int height = r.bottom - r.top;

	// keep a cached rendering of the background
	if(backgroundBitmap == 0)
	{
		if(backgroundDC == 0)
			backgroundDC = CreateCompatibleDC(hDC);

		backgroundBitmap = CreateCompatibleBitmap(hDC, width, height);
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
		
		if(background->isTransparent())
		{
			// paint desktop on display DC and then into background buffer
			PaintDesktop(hDC);
			BitBlt(backgroundDC, 0, 0, width, height, hDC, 0, 0, SRCCOPY);
		}
		
		background->apply(backgroundDC, 0, 0, width, height);
	}

	// double buffer for flicker-free paint
	if(bufferBitmap == 0)
	{
		if(bufferDC == 0)
			bufferDC = CreateCompatibleDC(hDC);

		bufferBitmap = CreateCompatibleBitmap(hDC, width, height);
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
	}

	// blt background into double buffer
	BitBlt(bufferDC, 0, 0, width, height, backgroundDC, 0, 0, SRCCOPY);

	// render text
	font->apply(bufferDC,
		leftBorder,
		topBorder,
		width - leftBorder - rightBorder,
		height - topBorder - bottomBorder,
		text,
		justify | DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS);

	// blt the double buffer to the display
	BitBlt(hDC, 0, 0, width, height, bufferDC, 0, 0, SRCCOPY);
}

void TaskLabel::onSize(int width, int height)
{
	this->height = height;
	this->width = width;

	if(backgroundDC != 0 && backgroundBitmap != 0)
	{
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
		DeleteObject(backgroundBitmap);
		backgroundBitmap = 0;
	}

	if(bufferDC != 0 && bufferBitmap != 0)
	{
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
		DeleteObject(bufferBitmap);
		bufferBitmap = 0;
	}

	InvalidateRect(hWnd, 0, FALSE);
}

void TaskLabel::onTimer(int timerID)
{
	if(timerID == TIMER_MOUSETRACK)
	{
		POINT pt;
		GetCursorPos(&pt);

		RECT rc;
		GetWindowRect(hWnd, &rc);

		if(!PtInRect(&rc, pt))
		{
			KillTimer(hWnd, TIMER_MOUSETRACK);
			mouseInside = false;
			onMouseLeave();
		}
	}
	else if(timerID == TIMER_UPDATE)
	{
		updateTaskInfo();
	}
}

boolean TaskLabel::onWindowMessage(UINT message, WPARAM wParam, LPARAM lParam, LRESULT &lResult)
{
	switch(message)
	{
		case LM_WINDOWACTIVATED:
		{
			updateTaskInfo();
			return true;
		}

		case WM_LBUTTONDBLCLK:
		{
			onLButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_LBUTTONDOWN:
		{
			onLButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_LBUTTONUP:
		{
			onLButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONDBLCLK:
		{
			onMButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONDOWN:
		{
			onMButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONUP:
		{
			onMButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONDBLCLK:
		{
			onRButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONDOWN:
		{
			onRButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONUP:
		{
			onRButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MOUSEMOVE:
		{
			onMouseMove((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hDC;

			if(wParam == 0)
				hDC = BeginPaint(hWnd, &ps);
			else
				hDC = (HDC) wParam;

			onPaint(hDC);

			if(wParam == 0)
				EndPaint(hWnd, &ps);

			return true;
		}

		case WM_SIZE:
		{
			onSize((int) (short) LOWORD(lParam), (int) (short) HIWORD(height));
			return true;
		}

		case WM_TIMER:
		{
			onTimer((int) wParam);
			return true;
		}
	}

	return false;
}

LRESULT TaskLabel::windowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	TaskLabel *label = (TaskLabel *) GetWindowLong(hWnd, 0);

	if(message == WM_NCCREATE)
	{
		label = (TaskLabel *) ((CREATESTRUCT *) lParam)->lpCreateParams;
		label->hWnd = hWnd;
		SetWindowLong(hWnd, 0, (LONG) label);
	}

	if(label)
	{
		LRESULT lResult = 0;

		if(label->onWindowMessage(message, wParam, lParam, lResult))
			return lResult;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

int TaskLabel::instanceCount = 0;
