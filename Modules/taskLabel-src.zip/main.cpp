#include "common.h"
#include "bangCommands.h"
#include "TaskLabel.h"

TaskLabel *label;

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	label = new TaskLabel("TaskLabel");
	label->load(hInstance);

	return 0;
}

void quitModule(HINSTANCE hInstance)
{
	delete label;
}
