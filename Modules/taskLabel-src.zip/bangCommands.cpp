#include "common.h"
#include "bangCommands.h"
#include "TaskLabel.h"

extern TaskLabel *label;

// forwards declarations
void AlwaysOnTopBangCommand(HWND caller, const char *bangCommandName, const char *arguments);
void HideBangCommand(HWND caller, const char *bangCommandName, const char *arguments);
void PinToDesktopBangCommand(HWND caller, const char *bangCommandName, const char *arguments);
void ShowBangCommand(HWND caller, const char *bangCommandName, const char *arguments);
void ToggleAlwaysOnTopBangCommand(HWND caller, const char *bangCommandName, const char *arguments);
void ToggleBangCommand(HWND caller, const char *bangCommandName, const char *arguments);

// bang commands implemented by this module
struct { const char *name; BangCommandEx *function; } bangCommands[] = {
	{ "!%sAlwaysOnTop", AlwaysOnTopBangCommand },
	{ "!%sHide", HideBangCommand },
	{ "!%sPinToDesktop", PinToDesktopBangCommand },
	{ "!%sShow", ShowBangCommand },
	{ "!%sToggleAlwaysOnTop", ToggleAlwaysOnTopBangCommand },
	{ "!%sToggle", ToggleBangCommand }
};

const int bangCommandCount = sizeof(bangCommands) / sizeof(bangCommands[0]);

// add bang commands for the label identified by 'labelName'
void AddBangCommands(const string &labelName)
{
	for(int i = 0; i < bangCommandCount; i++)
	{
		char name[64];
		wsprintf(name, bangCommands[i].name, labelName.c_str());

		AddBangCommandEx(name, bangCommands[i].function);
	}
}

// remove bang commands for a label
void RemoveBangCommands(const string &labelName)
{
	for(int i = 0; i < bangCommandCount; i++)
	{
		char name[64];
		wsprintf(name, bangCommands[i].name, labelName.c_str());

		RemoveBangCommand(name);
	}
}

// make a label always on top
void AlwaysOnTopBangCommand(HWND caller, const char *bangCommandName, const char *arguments)
{
	if(label != 0) label->setAlwaysOnTop(true);
}

// hide a label
void HideBangCommand(HWND caller, const char *bangCommandName, const char *arguments)
{
	if(label != 0) label->hide();
}

// pin a label to the desktop (opposite of always on top)
void PinToDesktopBangCommand(HWND caller, const char *bangCommandName, const char *arguments)
{
	if(label != 0) label->setAlwaysOnTop(false);
}

// show a label
void ShowBangCommand(HWND caller, const char *bangCommandName, const char *arguments)
{
	if(label != 0) label->show();
}

// toggle the always on top state of a label
void ToggleAlwaysOnTopBangCommand(HWND caller, const char *bangCommandName, const char *arguments)
{
	if(label != 0) label->setAlwaysOnTop(!label->isAlwaysOnTop());
}

// toggle the visibility of a label
void ToggleBangCommand(HWND caller, const char *bangCommandName, const char *arguments)
{
	if(label != 0) label->isVisible() ? label->hide() : label->show();
}
