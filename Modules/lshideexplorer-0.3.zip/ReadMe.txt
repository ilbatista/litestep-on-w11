/****************************************************************************
* LSHideExplorer                                                            *
* Brian Hartvigsen                                                          *
* (c) 2002 Brian Hartvigsen (tresni@coreshell.info)                         *
*                                                                           *
* This module does nothing more then hide the appearance of Explorer while  *
* Litestep is running and the module is loaded..                            *
*                                                                           *
* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- *
* To Use:                                                                   *
*  LoadModule $ModulesDir$LSHideExplorer.exe                                *
*                                                                           *
* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- *
* Step.rc Settings (only apply to hiding on startup)                        *
*  NoHideTaskbar                                                            *
*  NoHideToolbars                                                           *
*  NoHideDesktop                                                            *
*                                                                           *
* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- *
* Bang Commands:                                                            *
*  !hideTaskbar                                                             *
*  !hideDesktop                                                             *
*  !hideToolbars                                                            *
*  !showAll                                                                 *
*  !showTaskbar                                                             *
*  !showDesktop                                                             *
*  !showToolbars                                                            *
*  !showAll                                                                 *
*                                                                           *
* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- *
* Change Log:                                                               *
*                                                                           *
* 0.1 (28 JUNE 2002) [BAH]                                                  *
*  * Initial Release                                                        *
* 0.1b (28 JUNE 2002) [BAH]                                                 *
*  ! Missing Toolbar problem fixed                                          *
* 0.2 (28 JUNE 2002) [BAH]                                                  *
*  ! Toolbars are no longer limited to only hiding 10                       *
*  ! Detects Taskbar and Desktop better (or it's suppose to anyway)         *
*  ! Cleaned up the code                                                    *
* 0.3 (04 JULY 2002) [BAH]                                                  *
*  + Bang commands added to hide/show everything                            *
*  + Step.rc settings added to not hide things                              *
*  * Stopped doing changelogs that make much sense                          *
*                                                                           *
****************************************************************************/
