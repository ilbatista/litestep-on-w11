/////////////////////////////
// Module: LSMail 4.06
// Written By: MrJukes
// Modded by: Vendicator, Jesus_mjjg
// Released: 2002-04-18
/////////////////////////////

// what is it?
This is LiteSTEP's longest running third-party module.  It checks for new mail on multiple
POP3 accounts and lets the user know when they have new mail.

// new to 4.06 (Jesus_mjjg)
- Now it is possible to specify the password in the step.rc:
  *LSMailServer X Y "Display Name" host.name.com<:port> login password
  But it seems to be better to use evars to configure lsmail:
  *LSMailServer 5 6 Mail $mailPop1$ $mailLogin1$ $mailPassword1$
  You have been warned! Don't tell me that because of me someone took your password.
  If you don't want to put your password, don't put it, it'll work like before.

// new to 4.05 (Vendicator)
- Can show a separate bitmap when checking mail (LSMailCheckingBmp)
- You can now specify a !band to run when you have new mail/no mail (LSMailNewMailCmd/LSMailNoMailCmd)
- Zero account is removed since it really didn't do anything useful now.

// new to 4.02 (Vendicator)
- Clearing new mail flag made previous left click action abundant, changed to check mail.

// new to 4.01 (Vendicator)
- Centered coordinates support
- Clearing of new mail flag when server reports no mail.

// new to 4.0 (MrJukes)
- Complete rewrite

// usage
Left clicking will check for new mail on server (if 0 found, clear new mail flag)
Right clicking will bring up a menu that is fairly self-explanatory.
  Check Mail will check the mail
  Launch E-Mail Client will launch your e-mail client
  Clear New Mail will clear the new mail flag and switch back to normal mode
  Dispaly Last Error will display the last error that LSMail encountered
    - Include this if you feel the need to e-mail me a trouble report
  

LoadModule c:\litestep\lsmail.dll

step.rc
==========
LSMailX 0			; Can use center coordinates as "70C"
LSMailY -34
LSMailW 125
LSMailH 16
LSMailTimer 1			; How often to check for mail (in minutes)
				; If this is 0 no timer will be set and all checking
				; will have to be done manually

LSMailEMailClient "C:\Program Files\Outlook Express\msimn.exe"

LSMailFont Courier
LSMailFontSize 14
LSMailFontColor FFFFFF		; Normal font color
LSMailNewMailFontColor FF0000	; Font color when there is new mail
LSMailCheckingFontaColor C8C8C8	; Font color when checking mail

; *NOTE*
; If you do not specify a background color or a background image
; LSMail will use the desktop as its background.

LSMailBackColor 00FF00		; Normal background color
LSMailBackNewMailColor FF0000	; Background color when there is new mail
LSMailBackCheckingColor 000000	; Background color when checking mail
LSMailBackBmp lsmail.bmp	; Normal Background image
LSMailNewMailBmp lsmail-newmail.bmp ; Background image when there is new mail
LSMailCheckingBmp lsmail-checking.bmp ; Background image when LsMail is checking

LSMailNewMailCmd !bang		; Bang to be executed when there is new mail
LSMailNoMailCmd !bang		; Bang to be executed when you don't have any mail

; Server Configuration
; You can have as many of these are you would like
; The format is as follows:
;   *LSMailServer X Y "Display Name" host.name.com<:port> login
;  Where:
;    X = x offset for displaying the text inside the main window
;    Y = y offset for displaying the text inside the main window
;    Display Name = What to display for the server name
;    host.name.com = Host to connect to
;    <:port> = This is optional, leave it off and it defaults to 110
;    login = Your login

Examples:
*LSMailServer 0 0 Purdue postoffice.purdue.edu:110 mrjukes
*LSMailServer 0 16 Interaccess mail.interaccess.com mrjukes

bangs
=======
!LSMailShow		; Shows the window
!LSMailHide		; Hides the window
!LSMailToggle		; Toggles visibility
!LSMailCheckMail	; Checks the mail

==================================================================
E-mail mrjukes at mrjukes@purdue.edu with comments/suggestions/bugs.
Alternatively vendicator@mail.com.

Have fun,
	MrJukes