//////////////////////////////////////
// LSWeather B2
// Written By: MrJukes
// Graphics By: [TheBORG]
// Released: 9/12/99
///////////////////////////

// What's New in B2?
- Can be loaded as a LoadModule
- Got rid of messagebox warning that it could not connect to weather.com
- Images can be in any directory

// IMPORTANT!!
If you are going to run LSWeather as a LoadModule follow these steps:
1) Load into litestep as loadmodule
	It could possibly be looking funky right now so,
2) Edit the settings in modules.ini
3) Recycle

LoadModule mode does not allow the dialog boxes to edit the preferences because it did some weird stuff.

// Installation
1) Put all the .bmp's into your litestep images folder (ie c:\litestep\images)
2) Put a line like this in your step.rc:
	*Wharf LSWeather c:\litestep\images\lsweather.bmp @c:\litestep\lsweather.app
   or for a loadmodule
	LoadModule c:\litestep\lsweather.app
3) Save & Recycle

// Usage
- LSWeather can either use your zip code or a specific page located on weather.com
- To find out your specific page, visit weather.com and type in your city.
- Then look at the URL and copy the file and paste it into LSWeather.
- It will be of the form country_state_city.html (ie us_in_lafayette.html)

// Popup
Update - Checks weather.com for the latest temperature and weather conditions
Active - Toggles whether LSWeather checks the current conditions on a timer
Change Settings - Changes your settings
Change Location - Changes your zip code or city
About LSWeather - The about box
Use Zip Code - Uses the specified zip code
Use City - Uses the specified city file
Farenheit / Celcius / Kelvin - Check which one you want your temperature reported in

That's about it. E-mail me at mrjukes@purdue.edu if you have any questions.

Have fun,
	MrJukes