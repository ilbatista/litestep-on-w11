Text Edit (v1.2) by WhiteShadow (changty@muohio.edu) on 4-10-00
*******************************************************************

This is a small module that can be used to edit text files.  It 
could be useful in allowing you to edit your step.rc file on the 
fly.  However, it could also be very dangerous if used on the wrong 
file.

Installation:

	1. Copy textedit.dll into your litestep folder
	2. Add the line 

		LoadModule c:\litestep\textedit.dll

	   to your step.rc (with the appropriate drive letter and 
	   path)
	3. Recycle Litestep

Usage:

	!textadd "filename" text to be added

	   This will add the line "text to be added" to the bottom of
	   the file "filename".  Use quotes around the filename if it
	   contains spaces.  If the file does not exist, nothing
	   happens.


	!textdel "filename" text to be deleted

	   This will delete every line in "filename" that matches
	   "text to be deleted".  This means that if it occurs more
	   than once in the file, every case of it will be removed.

	!textdelsingle "filename" Number text to be deleted

	   This will delete a single occurance of "text to be deleted".
	   Number specifies which occurance to delete (1 = first time
	   it appears in the file, 2 = second time, etc).


	If you want to use exclaimation points, then add the line
		TextSubst
	to your step.rc.  If you have this line in your step.rc,
	all ^ will be replaced with !.  This could be useful for
	scripting since litestep tries to execute anything that has 
	a !.

	Also, you can add a * at the end of the string to delete to
	delete everything begining with the string.  There are 
	examples of this below.

Examples:

	1. !textadd c:\litestep\step.rc *Hotkey CTRL+ALT Q !quit

	   This adds the line "*Hotkey CTRL+ALT Q !quit" to your
	   step.rc file.

	2. !textdel c:\mirc\logs\#litestep.log <someguy> poop

	   This would open up your #litestep log file and remove every 
	   line where someguy says poop.

	3. !textdel c:\litestep\step.rc *shortcut *
	
	   This will delete every shortcut line in your step.rc

	4. !textdel c:\mirc\logs\somechan.log *

	   This will delete every line in somechan.log.

	5. !textdelsingle c:\litestep\step.rc 3 *hotkey *

	   This will delete the third hotkey in your step.rc.

	6. !textdelsingle c:\someotherfile.txt 8 *

	   This will delete the 8th line in someotherfile.txt.

History:

	v1.2 (04-10-00)
	-Added * at end of strings
	-Added !textdelsingle

	v1.1 (04-04-00)
	-Added TextSubst

 	v1.0 (04-02-00)
	-initial release

Anyway, that's all, enjoy!
Feel free to send me comments or bugs.
WhiteShadow
