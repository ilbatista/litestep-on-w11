v2:
- LsBox support, which now seems to handle auto sizing.
- Having reviewed the code once again I can see that wharf support is broken... (someone with insight in it should be able to fix this). - Added the systray2kad hacks for running commands on icon add/del.

v1:
I've made an experimental systray with lsbox support,
source is at pimpin.info/vendicator.
However I couldn't get it to work when autoresize is on,
it appears to be hidden then
(shows if !systraymove is run without args, only to
disappear when the systray resizes again, haven't found
a way to fix it yet)

Vendicator, christoffer.sjoberg@swipnet.se

==
taken from the email Vendicator sent to the LSML on 2002.05.03

This readme created by rootrider (www.shellfront.org)