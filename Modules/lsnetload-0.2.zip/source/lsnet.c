/**
 * Litestep Net Load Meter
 * LsNetLoad.dll
 * 
 * Relies heavily on the code for lscpu...
 * 
 * Peter Grimm
 * pmg23@columbia.edu
 **/

#ifdef UNICODE
#ifndef _UNICODE
#define _UNICODE
#endif
#define tmain wmain
#else
#define tmain main
#endif

#define WIN32_LEAN_AND_MEAN 1

#include <windows.h>
#include <winperf.h>
#include <malloc.h>
#include <stdio.h>
#include <tchar.h>
#include <pdh.h>
#include <string.h>

#include "D:\LiteStep\source\litestep\lsapi\lsapi.h"
#include "C:\Program Files\Microsoft Visual Studio\MyProjects\LsNetLoad\blah.h"

char szAppName[] = "LsNetLoad"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client

DWORD Reserved,dataType,dataLen=8192;
//char dataUp[8192]; // Buffer to communicate with registry. (way bigger than neeeded)
//char dataDown[8192];

HKEY perfKey;		// Registry key to get cpu usage
HKEY startPerfKey;	// Registry key to start cpu usage moinitoring

char upHistory[64];	// history of last n seconds
char downHistory[64];

BOOL init=FALSE;	// Monitor started ?
int width=0;		// Width of monitor (= size of history)

int pointer=0;		// pointer on the rotating history


// Performance Data Helper Variables
PDH_STATUS pdhStatus = ERROR_SUCCESS;
LPTSTR szCounterListBuffer = NULL;
DWORD dwCounterListBuffer = 0;
LPSTR szInstanceListBuffer = NULL;
DWORD dwInstanceListBuffer = 0;
LPSTR szThisInstance = NULL;

HQUERY netLoadDownQuery;
HCOUNTER netLoadDownCounter;
PDH_FMT_COUNTERVALUE netLoadDown;

HQUERY netLoadUpQuery;
HCOUNTER netLoadUpCounter;
PDH_FMT_COUNTERVALUE netLoadUp;

COLORREF gridColor;
COLORREF backColor;
COLORREF upForeColor;
COLORREF downForeColor;
COLORREF northWestBevelColor;
COLORREF southEastBevelColor;

int verticalGridLines;
int horizontalGridLines;
int maxNetSpeed;
int refreshDelay;
int borderSize;
BOOL scrollingGrid;
BOOL isModem;
BOOL isTransparent;
BOOL dontDrawGrid;
BOOL dontDrawBevel;
long tempValue;
CHAR networkAdapterCurrent1[512];
CHAR networkAdapterCurrent2[512];
CHAR networkAdapter[256];

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	memset(networkAdapterCurrent1, 0, 512);
	memset(networkAdapterCurrent2, 0, 512);
	memset(networkAdapter, 0, 256);

	isModem = GetRCBool("LSNetLoadModem", TRUE);
	isTransparent = GetRCBool("LSNetLoadTransparent", TRUE);
	dontDrawGrid = GetRCBool("LSNetLoadNoGrid", TRUE);
	dontDrawBevel = GetRCBool("LSNetLoadNoBevel", TRUE);
	gridColor = GetRCColor("LSNetLoadGridColor", 0x900000);
	backColor = GetRCColor("LSNetLoadBackColor", 0x500000);
	upForeColor = GetRCColor("LSNetLoadUpColor", 0x00FF00);
	downForeColor = GetRCColor("LSNetLoadDownColor", 0xFF0000);
	northWestBevelColor = GetRCColor("LSNetLoadNWBevelColor", 0x000000);
	southEastBevelColor = GetRCColor("LSNetLoadSEBevelColor", 0xFFFFFF);
	scrollingGrid = GetRCBool("LSNetLoadScrollingGrid", TRUE);
	
	maxNetSpeed = GetRCInt("LSNetLoadMaxSpeed",10000);
	if(maxNetSpeed<1) maxNetSpeed = 10000;
	
	refreshDelay = GetRCInt("LSNetLoadRefreshDelay",1000);
	if(refreshDelay<10) refreshDelay = 10;
	
	verticalGridLines = GetRCInt("LSNetLoadVerticalGridLines",4);
	if(verticalGridLines<0)verticalGridLines=0;
	horizontalGridLines = GetRCInt("LSNetLoadHorizontalGridLines",4);
	if(horizontalGridLines<0)horizontalGridLines=0;
	
	borderSize = GetRCInt("LSNetLoadBorderSize",4);

	networkAdapterCurrent1[0] = '\\';
	networkAdapterCurrent2[0] = '\\';
	if(!isModem){
		GetRCString("LSNetLoadInterface",networkAdapter, "PCI Bus Master Adapter", 256);
		strcat(networkAdapterCurrent1,"Network Interface(");
		strcat(networkAdapterCurrent2,"Network Interface(");
		strcat(networkAdapterCurrent1,networkAdapter);
		strcat(networkAdapterCurrent2,networkAdapter);
		strcat(networkAdapterCurrent1,")\\Bytes Sent/sec");
		strcat(networkAdapterCurrent2,")\\Bytes Received/sec");
		}
	else{
		GetRCString("LSNetLoadInterface",networkAdapter, "COM2", 256);
		strcat(networkAdapterCurrent1,"RAS Port(");
		strcat(networkAdapterCurrent2,"RAS Port(");
		strcat(networkAdapterCurrent1,networkAdapter);
		strcat(networkAdapterCurrent2,networkAdapter);
		strcat(networkAdapterCurrent1,")\\Bytes Transmitted/Sec");
		strcat(networkAdapterCurrent2,")\\Bytes Received/Sec");
		}

	//pdhStatus = PdhAddCounter(netLoadUpQuery,"\\Processor(0)\\% Processor Time",0,&netLoadUpCounter);
	pdhStatus = PdhOpenQuery(NULL,0,&netLoadUpQuery);
	pdhStatus = PdhAddCounter(netLoadUpQuery,networkAdapterCurrent1,0,&netLoadUpCounter);

	//pdhStatus = PdhAddCounter(netLoadDownQuery,"\\Processor(1)\\% Processor Time",1,&netLoadDownCounter);
	pdhStatus = PdhOpenQuery(NULL,1,&netLoadDownQuery);
	pdhStatus = PdhAddCounter(netLoadDownQuery,networkAdapterCurrent2,1,&netLoadDownCounter);

	if(pdhStatus!=ERROR_SUCCESS){
		MessageBox(parent,"Please specify the network interface to capture data from.", szAppName,MB_OK);
		return 1;
	}


    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    wndSize = 64-wharfData.borderSize*2;

	memset(upHistory, 0, 64); // initialize history to 0
	memset(downHistory, 0, 64);

    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }


    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

	SetTimer(hMainWnd, 0, refreshDelay, NULL); // Set a timer for cpu monitor
	
	//Find the appropriate 

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	KillTimer(hMainWnd, 0);
	DestroyWindow(hMainWnd);                // delete our window
	
	pdhStatus = PdhCloseQuery(&netLoadUpQuery); // close queries
	pdhStatus = PdhCloseQuery(&netLoadDownQuery);
    
	UnregisterClass(szAppName, dllInst);    // unregister window class
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
			{ 
                PAINTSTRUCT ps;
                RECT r;
                HDC hdc = BeginPaint(hwnd,&ps);
				HBRUSH brush;
				HPEN pen, oldpen;
				int i, j;
                
                //  ********* network module drawing ********


                // Get client rect of our window
				GetClientRect(hwnd,&r);
				r.left++; // adjustment

				
				// contract rect used by 4 pixels
				r.top += (borderSize+1);
				r.bottom -= (borderSize+1);
				r.left += (borderSize+1);
				r.right -= (borderSize+1);

				width = (r.right - r.left)+1; // Width of monitor

				

				// Paint monitor background
				if(!isTransparent){
					brush = CreateSolidBrush(backColor);
					FillRect(hdc, &r, brush);
					DeleteObject(brush);
					}

				// Draw grid
				if(!dontDrawGrid){
					pen = CreatePen(PS_SOLID, 1, gridColor);
					oldpen = SelectObject(hdc, pen);
					
					for (i=1;i<horizontalGridLines;i++)//horizontal grid lines
						{
						MoveToEx(hdc, r.left, r.top + (i*(r.bottom-r.top+1))/(horizontalGridLines), NULL);
						LineTo(hdc, r.right, r.top + (i*(r.bottom-r.top+1))/(horizontalGridLines));
						}

					if(scrollingGrid){//vertical grid lines
							for (i=0;i<verticalGridLines;i++){
								int column = ((i*(r.right-r.left+1)/(verticalGridLines))-pointer)%(r.right-r.left+1);
								if(column<0) column+=r.right-r.left;
								MoveToEx(hdc, r.left+ column, r.top, NULL);
								LineTo(hdc, r.left+ column, r.bottom);
								}
						}

					else{
						for (i=0;i<verticalGridLines;i++)
							{
							MoveToEx(hdc, r.left+ ((i*(r.right-r.left+1)/(verticalGridLines))), r.top, NULL);
							LineTo(hdc, r.left+ ((i*(r.right-r.left+1)/(verticalGridLines))), r.bottom);
							}
						}
					
					SelectObject(hdc, oldpen);
					DeleteObject(pen);
					}

				
                // ---------------------------------------------

				// Draw network monitor history curve

				//upload speed line
				pen = CreatePen(PS_SOLID, 1, upForeColor);
				oldpen = SelectObject(hdc, pen);

				j = (pointer + width) % width;
				MoveToEx(hdc, r.left, r.bottom-1- ((width-1) * upHistory[j]/100), NULL);
				for (i=1;i<width;i++)
					{
					j++;
					j %= width;
					LineTo(hdc, r.left+i, r.bottom-1- ((width-1) * upHistory[j]/100));
					}

				SelectObject(hdc, oldpen);
				DeleteObject(pen);
				
				//download speed line
				pen = CreatePen(PS_SOLID, 1, downForeColor);
				oldpen = SelectObject(hdc, pen);

				j = (pointer + width) % width;
				MoveToEx(hdc, r.left, r.bottom-1- ((width-1) * downHistory[j]/100), NULL);
				for (i=1;i<width;i++)
					{
					j++;
					j %= width;
					LineTo(hdc, r.left+i, r.bottom-1- ((width-1) * downHistory[j]/100));
					}

				SelectObject(hdc, oldpen);
				DeleteObject(pen);
				
				// Draw border
				r.top -= 1;//expand rect by 1 pixel
				r.bottom += 1;
				r.left -= 1;
				r.right += 1;
				
				if(!dontDrawBevel){
					pen = CreatePen(PS_SOLID, 1, northWestBevelColor);
					oldpen = SelectObject(hdc, pen);
					
					MoveToEx(hdc, r.left, r.bottom-1, NULL);
					LineTo(hdc, r.left, r.top);
					LineTo(hdc, r.right-1, r.top);
					
					SelectObject(hdc, oldpen);
					DeleteObject(pen);
					
					pen = CreatePen(PS_SOLID, 1, southEastBevelColor);
					oldpen = SelectObject(hdc, pen);
					
					LineTo(hdc, r.right-1, r.bottom-1);
					LineTo(hdc, r.left, r.bottom-1);
					
					SelectObject(hdc, oldpen);
					DeleteObject(pen);
					}	
					
				init=TRUE;

				EndPaint(hwnd,&ps);
			}
            return 0;
        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
	// Mouse messages are here to ensure we have a good popup menu behaviour. You may insert
        // your own custom actions
        case WM_RBUTTONUP:
                {
                RECT r;
                GetWindowRect(hwnd, &r);
                PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
        case WM_RBUTTONDOWN:
        case WM_LBUTTONDOWN:
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
		case WM_TIMER: // Update network monitor
			{
			RECT r;
			if (!init) return 0;
			// Get last network usage value
			pdhStatus=PdhCollectQueryData(netLoadUpQuery);
			pdhStatus=PdhGetFormattedCounterValue(netLoadUpCounter,PDH_FMT_LONG,NULL,&netLoadUp);
			pdhStatus=PdhCollectQueryData(netLoadDownQuery);
			pdhStatus=PdhGetFormattedCounterValue(netLoadDownCounter,PDH_FMT_LONG,NULL,&netLoadDown);

			// Insert it in the rotating buffer
			tempValue = netLoadUp.longValue;
			if(tempValue>maxNetSpeed || tempValue<0) tempValue = maxNetSpeed;

			upHistory[pointer] = 100 * tempValue/maxNetSpeed;
			
			tempValue = netLoadDown.longValue;
			if(tempValue>maxNetSpeed || tempValue<0) tempValue = maxNetSpeed;
			downHistory[pointer] = 100 * tempValue/maxNetSpeed;
			pointer++;
			pointer %= width;

			// Invalidate client. This causes a WM_PAINT message to be sent to our window
			if(isTransparent){
				GetClientRect(parent, &r);
				InvalidateRect(parent, &r, TRUE);
				}
			GetClientRect(hMainWnd, &r);
			InvalidateRect(hMainWnd, &r, TRUE);
			}
			return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

