
/********************************************/
/*											*/
/*	Message.cpp								*/
/*											*/
/*	Implementation of class CMessage		*/
/*											*/
/*	This class is to handle easely window	*/
/*	messages.								*/
/*											*/
/*	Made by Antoine Wells Campagna			*/
/*	aka AntAgna								*/
/*	send questions, comments, etc... to :	*/
/*	AntoineW@Campagna.org					*/
/*											*/
/********************************************/


//Includes

#include "Message.h"
#include "bgcolors.h"	//Include the handler class definition


//Construction/Destruction

CMessage::CMessage()
{
	m_Msgs = NULL;
	m_NbMsgs = 0;
}

CMessage::~CMessage()
{
	if (m_Msgs != 0)
	{
		delete m_Msgs;
	}

}


//Public functions

BOOL CMessage::AddSt(UINT uMsg,
					 LRESULT (_cdecl * HandlerSt)(WPARAM, LPARAM, void *))
{	//Add static handler for a message
	VerifySize();
	m_Msgs[m_NbMsgs].uMsg = uMsg;
	m_Msgs[m_NbMsgs].HandlerSt = HandlerSt;
	m_Msgs[m_NbMsgs].Handler = NULL;
	m_NbMsgs++;
	return TRUE;
}

BOOL CMessage::Add(UINT uMsg,
				   LRESULT (HANDLER_CLASS:: * Handler)(WPARAM, LPARAM))
{	//Add member handler for a message
	VerifySize();
	m_Msgs[m_NbMsgs].uMsg = uMsg;
	m_Msgs[m_NbMsgs].Handler = Handler;
	m_Msgs[m_NbMsgs].HandlerSt = NULL;
	m_NbMsgs++;
	return TRUE;
}

Message * CMessage::FindMessage(UINT uMsg)
{	//Returns the address of the Message struct
	int i;
	for (i = 0; i < m_NbMsgs; i++)
	{
		if (m_Msgs[i].uMsg == uMsg)
		{
			return m_Msgs + i;
		}

	}

	return NULL;
}

LRESULT CMessage::TreatMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{	//Treat the message
	Message * pMsg = FindMessage(uMsg);
	if (pMsg != NULL)
	{
		if (pMsg->Handler != NULL)
		{	//Call to the member function
			return (((HANDLER_CLASS *) m_ClassPointer)->*(pMsg->Handler))(wParam, lParam);
		}

		if (pMsg->HandlerSt	!= NULL)
		{	//Call to the static function
			return pMsg->HandlerSt(wParam, lParam, m_ClassPointer);
		}

	}

	return MESSAGE_NOT_FOUND;
}


//Private functions

void CMessage::VerifySize()
{
	int i;
	Message * Temp;
	if (!(m_NbMsgs % DY_MEM_INC))	//Resize by increment of DY_MEM_INC
	{
		Temp = m_Msgs;
		m_Msgs=new Message[m_NbMsgs + DY_MEM_INC];//Assume there is enough mem
		if (Temp != NULL)	//Resize
		{
			for (i=0;i<m_NbMsgs;i++)
			{
				m_Msgs[i] = Temp[i];
			}

			delete Temp;
		}

	}

}
