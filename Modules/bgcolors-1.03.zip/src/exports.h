
/********************************************/
/*											*/
/*	exports.h								*/
/*											*/
/*	Version	1.03							*/
/*											*/
/*	12 nov 2003								*/
/*											*/
/*	This is the exported functions			*/
/*	implementation file for the BGColors	*/
/*	module for LiteStep.					*/
/*											*/
/*	Made by Antoine Wells Campagna			*/
/*	aka AntAgna								*/
/*	send questions, comments, etc... to :	*/
/*	AntoineW@Campagna.org					*/
/*											*/
/********************************************/


//Global functions

extern "C" 
{
	__declspec( dllexport ) int initModuleEx(HWND hParent,
		HINSTANCE hInstance, const char *lsPath);

	__declspec( dllexport ) void quitModule(HINSTANCE hInstance);

	__declspec( dllexport ) BOOL APIENTRY DllMain(HINSTANCE hInstance,
		DWORD dwReason, LPVOID pvReserved);

}
