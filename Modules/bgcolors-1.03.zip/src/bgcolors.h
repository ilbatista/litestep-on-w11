
/********************************************/
/*											*/
/*	bgcolors.h								*/
/*											*/
/*	Version	1.03							*/
/*											*/
/*	12 nov 2003								*/
/*											*/
/*	This is the object declaration file for	*/
/*	the BGColors module for LiteStep.		*/
/*											*/
/*	Made by Antoine Wells Campagna			*/
/*	aka AntAgna								*/
/*	send questions, comments, etc... to :	*/
/*	AntoineW@Campagna.org					*/
/*											*/
/********************************************/


#pragma once
#pragma comment( lib, "..\\LSAPI\\lsapi" )


//Includes

#include "LSAPI\lsapi.h"
#include "exports.h"
#include "Message.h"
#include <math.h>


//Defines

#define APP_NAME				"BGColors"
#define ABOUT_STR				"BGColors v1.03 by AntAgna"
#define REFRESH_TIMER			1
#define MAXHBRS					2000	//Size of brushes buffer
#define DESKTOP_WINDOW			"DesktopBackgroundClass"
#define NEW_REF_INTERVAL		"!BGColorsNewInt"
#define NEW_SPEED				"!BGColorsNewSpeed"
#define NEW_START_VALUES		"!BGColorsNewValues"
#define NEW_START_VALUE_R		"!BGColorsNewValueR"
#define NEW_START_VALUE_G		"!BGColorsNewValueG"
#define NEW_START_VALUE_B		"!BGColorsNewValueB"
#define RELOAD_CONFIG			"!BGColorsReload"
#define START					"!BGColorsStart"
#define PAUSE					"!BGColorsPause"
#define LOGO					"!BGColorsLogo"
#define TIMER_ERROR				"Error creating update Timer."
#define BG_WND_ERROR			"Can not find desktop window.\nPlease use this module with a desktop module such as jdesk and load the desktop module first."
#define HDC_ERROR				"Can not use the desktop window to draw."
#define CLASS_ERROR				"Error registering window class"
#define WND_ERROR				"Error creating window"
#define ST_NOTHING				0
#define ST_CLASS				1
#define ST_WINDOW				2
#define ST_NO_ERROR				(ST_CLASS | ST_WINDOW)


//The class

class CBGColors
{
public:

	//Constructor/Destructor
	CBGColors(HWND hParent = NULL, HINSTANCE hInstance = NULL);
	~CBGColors(void);

	//Public functions
	BOOL Status(void);			//Is initialisation OK 

	//Window procedure
	static LRESULT CALLBACK WndProc(
		HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

	//Bang managers
	static void NewRefInterval(HWND sender, LPCSTR args);
	static void NewSpeed(HWND sender, LPCSTR args);
	static void NewStartValues(HWND sender, LPCSTR args);
	static void NewStartValueR(HWND sender, LPCSTR args);
	static void NewStartValueG(HWND sender, LPCSTR args);
	static void NewStartValueB(HWND sender, LPCSTR args);
	static void ReloadConfig(HWND sender, LPCSTR args);
	static void Start(HWND sender, LPCSTR args);
	static void Pause(HWND sender, LPCSTR args);
	static void ShowLogo(HWND sender, LPCSTR args);

	//Window message handlers
	LRESULT GetRevID(WPARAM wParam, LPARAM lParam);
	LRESULT Refresh(WPARAM wParam, LPARAM lParam);
	LRESULT OnTimer(WPARAM wParam, LPARAM lParam);

private:

	//Variables
	int m_Cnt;					//Iterator
	int m_Nbhbrs;				//Nunber of brushes waiting to be cleaned
	int m_LogoState;			//State of the logo
	int m_Refint;				//Refresh interval (Timer Value)
	int m_RefintO;				//Initial value of refresh interval
	int m_SpeedO;				//Initial value of speed
	int m_ChangeRO;				//Initial values of m_ChangeX
	int m_ChangeGO;
	int m_ChangeBO;
	double m_ChangeR;			//Numbers on which the color will be calculated
	double m_ChangeG;
	double m_ChangeB;
	double m_Speed;				//Incrementation of the color
	BOOL m_Status;				//Status indicator TO GO INT
	BOOL m_Running;				//Indicate if module is running or paused
	BOOL m_Interior;			//Indicate to draw interior or exterior
	HWND m_TimerWin;			//Handle to module window
	HWND m_LsWin;				//Hanlde to parent window
	HWND m_BgWin;				//Handle to background window
	HDC m_Hdc;					//Device context of the background
	HDC m_DcMem;				//Device context to memmory
	HBITMAP m_BitMap;			//Bitmap of m_DcMem
	HICON m_LSIcon;				//The litestep icon
	HFONT m_Font;				//A font that looks good
	HBRUSH m_Hbrs[MAXHBRS];		//Brushes buffer
	HINSTANCE m_Instance;		//Instance of the module
	RECT m_Rect;				//Screen coordinates
	RECT m_Region;				//Region to draw
	char * m_AboutString;		//About string
	char * m_AppName;			//Application name
	CMessage m_Msgs;			//CMessage object to handle window messages


	//Private functions
	void InitLogo(void);
	void CleanLogo(void);
	void CleanBrushes(void);
	BOOL FindBGWindow(void);
	BOOL Draw(void);
	void DrawLogo(HBRUSH hbr);
	void DrawExterior(HBRUSH hbr);
	BOOL ReadConfig(void);
	BOOL CreateTheWindow(void);
	BOOL IsGoodForLogo(void);
	void CorrectRegion();

};
