

///---- Read Me for the source of BGColors v1.02 and later ----\\\


//----------------------------------\\
I know what you're thinking right now :
Why so much files and dirs for a simple LS Module ???

I am proposing a file structure for making C++ LS Modules, that's why.
If anyone like it, just use it. Can also be used for most 
project types. Only one condition for using
this : Project has to be open source
(well, at least not commercial)
And I'd like to know it.
\\----------------------------------//


If you don't care about the file structure and
just want to look at the source, use bgcolors.dsw in the VC6
directory or bgcolors.sln in the NET directory.


-( 1 )- The role of the three dirs :

LSAPI :

 Contains the files of the LiteStep SDK 
 (preferably the most recent one, my version is pretty old I think)

 files in this dir :
 requiered : lsapi.h lsapi.lib
 optional  : lsapi.exp lssdk.chm others


VC6 :

 Contains project information for the MS Visual C++ version 6
 required : project.dsp project.dsw project.dep makefile


NET :

 Contains project information for the MS Visual Studio .NET
 required : Compile.NET.bat project.sln project.vcproj


-( 2 )- The role of the files in the main dir :


Compile.bat :

 Simple batch file to compile the project rapidly.

 Usage :

  In a command prompt, type either :
	
	Compile VC6 : to compile with MS Visual C++ version 6 (uses VC6\makefile)
	Compile NET : to compile with MS Visual .NET (uses NET\Compile.NET.bat)

  NOTE : You need the right MS Visual Studio version to be installed 
         on your system for this to work.


Clean.bat :

 Simple batch file to delete unnecessary files that are created when compiling.


project.h :

 Header for the class used by the project


project.cpp :

 Source file of the class used by the project


exports.h :

 Declaration of the exported functions


exports.cpp :

 Source file of the exported functions


Message.h :

 Header of my CMessage class that is useful for easy window messages handling.
 You can use this class if you want, details on what to change for it to
 work with your project are written in this file.


Message.cpp :

 Source file of my CMessage class


Wow, that's all


-( 3 )- What to change for all of this to work with a new project ?

First you need to create the Directories and copy the .bat files.

Then you need to create the .dsw, .dsp, .sln and .vcproj files.
To do this, open VC6 and create an empty DLL (or wathever) project 
anywhere on your hd.
Close VC6 and move the .dsw and .dsp files in the VC6 dir.
Do the same with .NET for the .sln and .vcproj files in the NET dir.
(Note that the other files are not really useful)

Then, for the command line compilation with "Compile NET" to work,
you need to edit NET\Compile.NET.bat. 
Just change this line :

"%VS71COMNTOOLS%..\IDE\devenv.exe" /build debug /out NET\out.txt NET\bgcolors.sln

with 

"%VS71COMNTOOLS%..\IDE\devenv.exe" /build debug /out NET\out.txt NET\yourproject.sln

Now it's time to create your source files. So open the .dsw and .sln files, create 
your .h and .cpp files in the main dir and add them to your project in both
editors.

For "Compile VC6" to work, you need a MakeFile and the .dep file that goes with it.
In the menu of VC6, Project->Settings->Export Makefile, click OK
This created .dep and .mak files. Just rename the .mak file to "makefile".

Note that you will have to remake the makefile each time you add a source file to
your project and stuff like that that change the way project is built.

Note also that Compile.bat and Compile.NET.bat are using the default compile options
and the Debug mode. You can hack these bat files to change these settings.

And if anyone wants to add support for other compilers, it'd be cool.


Well, that should do it, have fun !

//---------------------------------------\\
And I know once again what you're thinking :
Man, this guy really has time to loose !

This is not really true, 
I just love doing things like that.
\\---------------------------------------//


Trying to help,
Antoine Wells Campagna
aka AntAgna
send questions, comments, etc... to :
AntoineW@Campagna.org
