
/********************************************/
/*											*/
/*	bgcolors.cpp							*/
/*											*/
/*	Version	1.03							*/
/*											*/
/*	12 nov 2003								*/
/*											*/
/*	This is the object implementation file	*/
/*	for the BGColors module for LiteStep.	*/
/*											*/
/*	This module should work on most 		*/
/*	LiteStep versions and on any version	*/
/*	of Windows.								*/
/*											*/
/*	This module should use less than 5%		*/
/*	of your cpu time even on old computers	*/
/*	and with really high resolutions.		*/
/*											*/
/*	Made by Antoine Wells Campagna			*/
/*	aka AntAgna								*/
/*	send questions, comments, etc... to :	*/
/*	AntoineW@Campagna.org					*/
/*											*/
/********************************************/


//Includes

#include "bgcolors.h"



//This pointer is for the static functions
//I had to use this second global pointer cause I can't find a way
//to use the same as for the exported functions (in exports.cpp)

CBGColors * g_thisPtr = NULL;


//Construction/Destruction

CBGColors::CBGColors(HWND hParent, HINSTANCE hInstance)
{
	UINT Msgs[3];

	m_LsWin = hParent;
	m_Instance = hInstance;
	m_Nbhbrs = 0;
	m_Cnt = 0;
	m_AppName = APP_NAME;
	m_AboutString = ABOUT_STR;
	m_Msgs.m_ClassPointer = this;

	g_thisPtr = this;

	if (!FindBGWindow())
	{
		m_Status = ST_NOTHING;
		return;
	}

	if (!ReadConfig())
	{
		m_Status = ST_NOTHING;
		return;
	}

	if (m_LogoState != 0)
	{
		InitLogo();
	}

	//Add reaction to window messages
	m_Msgs.Add(LM_GETREVID, GetRevID);
	m_Msgs.Add(LM_REFRESH, Refresh);
	m_Msgs.Add(WM_TIMER, OnTimer);

	if (!CreateTheWindow())
	{
		return;
	}

	//To be able to react to LS messages
	Msgs[0] = LM_GETREVID;
	Msgs[1] = LM_REFRESH;
	Msgs[2] = 0;
	SendMessage(m_LsWin, LM_REGISTERMESSAGE, (WPARAM)m_TimerWin,
		(LPARAM)Msgs);

	//Register bang commands
	AddBangCommand(NEW_REF_INTERVAL, NewRefInterval);
	AddBangCommand(NEW_SPEED, NewSpeed);
	AddBangCommand(NEW_START_VALUES, NewStartValues);
	AddBangCommand(NEW_START_VALUE_R, NewStartValueR);
	AddBangCommand(NEW_START_VALUE_G, NewStartValueG);
	AddBangCommand(NEW_START_VALUE_B, NewStartValueB);
	AddBangCommand(RELOAD_CONFIG, ReloadConfig);
	AddBangCommand(START, Start);
	AddBangCommand(PAUSE, Pause);
	AddBangCommand(LOGO, ShowLogo);
	m_Status = ST_NO_ERROR;
}

CBGColors::~CBGColors()
{
	UINT Msgs[3];

	CleanBrushes();

	ReleaseDC(m_BgWin, m_Hdc);		//Clean up

	if (m_LogoState != 0)
	{
		CleanLogo();
	}

	if (m_Status == ST_NO_ERROR)
	{
		//Unregister the litestep messsages
		Msgs[0] = LM_GETREVID;
		Msgs[1] = LM_REFRESH;
		Msgs[2] = 0;
		SendMessage(m_LsWin, LM_UNREGISTERMESSAGE, (WPARAM) m_TimerWin,
			(LPARAM) Msgs);

		//Unregister bang commands
		RemoveBangCommand(NEW_REF_INTERVAL);
		RemoveBangCommand(NEW_SPEED);
		RemoveBangCommand(NEW_START_VALUES);
		RemoveBangCommand(NEW_START_VALUE_R);
		RemoveBangCommand(NEW_START_VALUE_G);
		RemoveBangCommand(NEW_START_VALUE_B);
		RemoveBangCommand(RELOAD_CONFIG);
		RemoveBangCommand(START);
		RemoveBangCommand(PAUSE);
		RemoveBangCommand(LOGO);
	}

	//Destroy the window
	if (m_Running == TRUE)
	{
		KillTimer(m_TimerWin, REFRESH_TIMER);
	}

	if (m_Status & ST_WINDOW)
	{
		DestroyWindow(m_TimerWin);
	}

	if (m_Status & ST_CLASS)
	{
		UnregisterClass(m_AppName, m_Instance);
	}

	g_thisPtr = NULL;
}


//Private Functions

BOOL CBGColors::CreateTheWindow()
{
	WNDCLASS wc;
	memset(&wc, 0, sizeof(wc));
	wc.hInstance = m_Instance;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = m_AppName;
	if (!RegisterClass(&wc))
	{	//Error (never happened)
		MessageBox(m_LsWin, CLASS_ERROR, m_AppName,
			MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		m_Status = ST_NOTHING;
		return FALSE;
	}

	m_TimerWin = CreateWindowEx(WS_EX_TOOLWINDOW, m_AppName, m_AppName,
		WS_CHILD, 0,0,0,0, m_LsWin, NULL, m_Instance, this);
	if (m_TimerWin == NULL)
	{	//Error (never happened)
		MessageBox(m_LsWin, WND_ERROR, m_AppName,
			MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		m_Status = ST_CLASS;
		return FALSE;
	}

	//Set the refresh timer
	if (m_Running)
	{
		if (!SetTimer(m_TimerWin, REFRESH_TIMER, m_Refint, NULL))
		{	//Error (never happened)
			MessageBox(m_LsWin, TIMER_ERROR, m_AppName, 
				MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
			m_Status = ST_WINDOW | ST_CLASS;
			return FALSE;
		}

	}

	return TRUE;
}

BOOL CBGColors::ReadConfig()
{
	char Buffer[40];
	m_Refint = GetRCInt("BGColorsRefreshInterval", 50);
	if (m_Refint < 1)
	{
		m_Refint = 1;
	}

	if (m_Refint > 1000)
	{
		m_Refint = 1000;
	}

	m_RefintO = m_Refint;

	m_SpeedO = GetRCInt("BGColorsChangeSpeed", 5);
	if (m_SpeedO < 1)
	{
		m_SpeedO = 1;
	}

	if (m_SpeedO > 1000)
	{
		m_SpeedO = 1000;
	}

	m_Speed = m_SpeedO / 500.;

	if (GetRCBool("BGColorsStartValues", TRUE))
	{
		GetRCLine("BGColorsStartValues", Buffer, 40, "0 15 45");
		sscanf(Buffer, "%d %d %d", &m_ChangeRO, &m_ChangeGO, &m_ChangeBO);
	}
	else
	{
		m_ChangeRO = GetRCInt("BGColorsStartValueR", 0);
		m_ChangeGO = GetRCInt("BGColorsStartValueG", 15);
		m_ChangeBO = GetRCInt("BGColorsStartValueB", 45);
	}

	if (m_ChangeRO < 0 || m_ChangeRO > 61)
	{
		m_ChangeRO = 0;
	}

	if (m_ChangeGO < 0 || m_ChangeGO > 61)
	{
		m_ChangeGO = 0;
	}

	if (m_ChangeBO < 0 || m_ChangeBO > 61)
	{
		m_ChangeBO = 0;
	}

	m_Interior = GetRCBool("BGColorsExterior", FALSE);
	m_Region.left = GetRCInt("BGColorsLeft", 0);
	m_Region.top = GetRCInt("BGColorsTop", 0);
	m_Region.right = GetRCInt("BGColorsRight", 0);
	m_Region.bottom = GetRCInt("BGColorsBottom", 0);

	CorrectRegion();

	if (GetRCBool("BGColorsNoLogo", FALSE) && IsGoodForLogo())
	{
		m_LogoState = 60;
	}
	else
	{
		m_LogoState = 0;
	}

	m_Running = GetRCBool("BGColorsStartPaused", FALSE);

	m_ChangeR = m_ChangeRO;
	m_ChangeG = m_ChangeGO;
	m_ChangeB = m_ChangeBO;
	m_ChangeR /= 10.;
	m_ChangeG /= 10.;
	m_ChangeB /= 10.;
	return TRUE;
}

void CBGColors::CorrectRegion()
{
	if (m_Interior)
	{
		m_Rect.left += m_Region.left;
		m_Rect.top +=  m_Region.top;
		if (m_Region.right > 0)
		{
			m_Rect.right = m_Region.right;
		}
		else
		{
			m_Rect.right += m_Region.right;
		}

		if (m_Region.bottom > 0)
		{
			m_Rect.bottom = m_Region.bottom;
		}
		else
		{
			m_Rect.bottom += m_Region.bottom;
		}

	}

}

BOOL CBGColors::IsGoodForLogo()
{	// A  bit complex, I know
	return (m_Interior &&
		(m_Region.right - m_Region.left > 200 ||
		m_Region.right <= 0 &&
		m_Rect.right + m_Region.right - m_Region.left > 200) && 
		(m_Region.bottom - m_Region.top > 60 ||
		m_Region.bottom <= 0 &&
		m_Rect.bottom + m_Region.bottom - m_Region.top > 60));
}

BOOL CBGColors::Draw()	//Calculates color and draw on the background
{
	HBRUSH hbr;		//The newly generated color
	char Rcomp;		//The color componements
	char Gcomp;
	char Bcomp;

	//Some cool math here

	//Red componement
	m_ChangeR += m_Speed;
	if (m_ChangeR >= 6.28)
	{
		m_ChangeR = 0;
	}

	Rcomp = (unsigned char) (sin(m_ChangeR) * 120 + 128);

	//Green componment
	m_ChangeG += m_Speed;
	if (m_ChangeG >= 6.28)
	{
		m_ChangeG = 0;
	}

	Gcomp = (unsigned char) (sin(m_ChangeG) * 120 + 128);

	//Blue componement
	m_ChangeB += m_Speed;
	if (m_ChangeB >= 6.28)
	{
		m_ChangeB = 0;
	}

	Bcomp = (unsigned char) (sin(m_ChangeB) * 120 + 128);

	//Color is now calculated so

	hbr = CreateSolidBrush(RGB(Rcomp, Gcomp, Bcomp));	//Create the new brush

	if (m_Nbhbrs >= MAXHBRS || hbr == NULL)	//Can't create anymore brushes
	{
		CleanBrushes();
	}

	if (hbr != 0)	//If brush is valid
	{
		if (m_Interior)
		{
			if (m_LogoState != 0)	//Do we have to draw the logo
			{
				SetBkColor(m_DcMem, RGB(Rcomp, Gcomp, Bcomp));	//Back of text
				DrawLogo(hbr);
			}
			else
			{	//No logo, only the specified region
				FillRect(m_Hdc, &m_Rect, hbr);	//Draw to the screen
			}

		}
		else
		{	//Exterior
			DrawExterior(hbr);
		}

		m_Hbrs[m_Nbhbrs++] = hbr;	//Save brush for cleaning

	}

	if (m_Cnt++ > 300)	//After a few seconds
	{	//Check the background window again (to make sure)
		m_Cnt = 0;
		if (!FindBGWindow())
		{	//Error occured, quit everything
			return FALSE;
		}

		CorrectRegion();
	}

	return TRUE;
}

void CBGColors::DrawLogo(HBRUSH hbr)
{
	RECT rect;		//The rectangle to specify regions
	//Draw the logo in second buffer
	rect.left = 0;
	rect.top = 0;
	rect.right = 200;
	rect.bottom = 60;
	FillRect(m_DcMem, &rect, hbr);		//Back of logo
	DrawIcon(m_DcMem, 84, 5, m_LSIcon);	//LS Icon
	rect.top = 40;
	rect.bottom = 60;
	DrawText(m_DcMem, m_AboutString, strlen(m_AboutString),
		&rect, DT_CENTER | DT_VCENTER);		//The text
	rect.top = m_Rect.top;
	rect.right = m_Rect.right;
	rect.bottom = m_Rect.bottom;
	if (m_LogoState > 30)	//First anim, goes down
	{
		//Draw single buffer region
		rect.left = m_Rect.left + 200;
		FillRect(m_Hdc, &rect, hbr);	//Right part
		rect.left = m_Rect.left;
		rect.top = m_Rect.top + (60 - m_LogoState) * 2;
		rect.right = m_Rect.left + 200;
		FillRect(m_Hdc, &rect, hbr);	//Left part
		//Draw logo region
		StretchBlt(m_Hdc, m_Rect.left, m_Rect.top,
			200, (60 - m_LogoState) * 2,
			m_DcMem, 0, 0, 200, 60, SRCCOPY);
	}
	else	//Second anim, hides left
	{
		//Draw single buffer region
		rect.left = m_Rect.left + m_LogoState * 200 / 30;
		FillRect(m_Hdc, &rect, hbr);	//Right part
		rect.left = m_Rect.left;
		rect.top = m_Rect.top + 60;
		rect.right = m_Rect.left + m_LogoState * 200 / 30;
		FillRect(m_Hdc, &rect, hbr);	//Left part
		//Draw logo region
		StretchBlt(m_Hdc, m_Rect.left, m_Rect.top,
			m_LogoState * 200 / 30, 60,
			m_DcMem, 0, 0, 200, 60, SRCCOPY);
	}

	m_LogoState--;		//Logo progress
	if (m_LogoState == 0)	//Logo end
	{
		CleanLogo();
	}

}

void CBGColors::DrawExterior(HBRUSH hbr)
{
	RECT rect;		//The rectangle to specify regions
	rect.left = m_Rect.left;
	rect.top = m_Rect.top;
	rect.right = m_Region.left;
	rect.bottom = m_Rect.bottom;
	FillRect(m_Hdc, &rect, hbr);	//Left part

	if (m_Region.right > 0)
	{
		rect.left = m_Region.right;
	}
	else
	{
		rect.left = m_Rect.right + m_Region.right;
	}

	rect.right = m_Rect.right;
	FillRect(m_Hdc, &rect, hbr);	//Right part

	rect.right = rect.left;
	rect.left = m_Region.left;
	rect.top = m_Rect.top;
	rect.bottom = m_Region.top;
	FillRect(m_Hdc, &rect, hbr);	//Top part

	if (m_Region.bottom > 0)
	{
		rect.top = m_Region.bottom;
	}
	else
	{
		rect.top = m_Rect.bottom + m_Region.bottom;
	}

	rect.bottom = m_Rect.bottom;
	FillRect(m_Hdc, &rect, hbr);	//Bottom part
}

void CBGColors::CleanBrushes()
{
	int i;
	for (i=0; i<m_Nbhbrs; i++)	//Clean all brushes
	{
		DeleteObject(m_Hbrs[i]);
	}

	m_Nbhbrs = 0;		//Reset counter
}

BOOL CBGColors::FindBGWindow()
{
	m_BgWin = FindWindow(DESKTOP_WINDOW, NULL);	//Get the background window
	if (m_BgWin == NULL)
	{	//Error
		MessageBox(m_LsWin, BG_WND_ERROR, m_AppName,
			MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		return FALSE;
	}

	ReleaseDC(m_BgWin, m_Hdc);		//Clean up
	GetWindowRect(m_BgWin, &m_Rect);	//If screen res changed
	m_Hdc = GetDC(m_BgWin);			//Get a new HDC
	if (m_Hdc == NULL)
	{	//Error (never happened)
		MessageBox(m_LsWin, HDC_ERROR, m_AppName,
			MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		return FALSE;
	}

	return TRUE;
}

void CBGColors::InitLogo()
{	//Initialisation of logo resources
	char * LSPath = "$LiteStepDir$LiteStep.exe,0";
	char CompletePath[200];
	VarExpansion(CompletePath, LSPath);		//Path to LiteStep.exe
	m_DcMem = CreateCompatibleDC(m_Hdc);	//Memmory DC
	m_BitMap = CreateCompatibleBitmap(m_Hdc, 200, 60);	//Bitmap of m_DcMem
	SelectObject(m_DcMem, m_BitMap);
	m_LSIcon = LoadLSIcon(CompletePath, NULL);	//Load the LS Icon
	m_Font = CreateFont(0, 0, 0, 0, 0, 0, 0, 0, ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_DECORATIVE, "Arial");	//A good looking font
	SelectObject(m_DcMem, m_Font);
}

void CBGColors::CleanLogo()
{	//Clean Logo resources
	DeleteObject(m_BitMap);
	DeleteObject(m_Font);
	DeleteObject(m_LSIcon);
	DeleteDC(m_DcMem);
}


//Public functions

BOOL CBGColors::Status()
{	//Just to avoid accessing member variables from the outside
	return m_Status;
}


//Window messages handlers (Called from my CMessage class)

LRESULT CBGColors::GetRevID(WPARAM wParam, LPARAM lParam)
{	//LM_GETREVID msg (for about box)
	char * buf = (char * ) lParam;
	strcpy(buf, m_AboutString);
	return strlen(buf);
}

LRESULT CBGColors::Refresh(WPARAM wParam, LPARAM lParam)
{	//LM_REFRESH msg (!Refresh)
	CleanLogo();
	
	if (!FindBGWindow())
	{	//Error
		quitModule(m_Instance);
	}

	if (!ReadConfig())
	{	//Error while reading
		quitModule(m_Instance);
	}

	if (m_LogoState != 0)
	{
		InitLogo();
	}

	return 0;
}

LRESULT CBGColors::OnTimer(WPARAM wParam, LPARAM lParam)
{	//WM_TIMER msg (time to draw to the screen)
	if (wParam == REFRESH_TIMER)
	{
		if (!g_thisPtr->Draw())
		{	//Grave error
			quitModule(m_Instance);
		}

	}

	return 0;
}


//Bang managers (static)

void CBGColors::NewRefInterval(HWND sender, LPCSTR args)
{
	int NewRefInt;
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	sscanf(args, "%d", &NewRefInt);
	if (NewRefInt > 0 && NewRefInt <= 1000)
	{
		g_thisPtr->m_Refint = NewRefInt;
		if (g_thisPtr->m_Running)
		{	//Reacts immidiatly
			KillTimer(g_thisPtr->m_TimerWin, REFRESH_TIMER);
			SetTimer(g_thisPtr->m_TimerWin, REFRESH_TIMER, NewRefInt, NULL);
		}

	}

}

void CBGColors::NewSpeed(HWND sender, LPCSTR args)
{
	int NewSpeed;
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	sscanf(args, "%d", &NewSpeed);
	if (NewSpeed > 0 && NewSpeed <= 1000)
	{
		g_thisPtr->m_Speed = NewSpeed / 500.;
	}

}

void CBGColors::NewStartValues(HWND sender, LPCSTR args)
{
	int NewR, NewG, NewB;
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	sscanf(args, "%d %d %d", &NewR, &NewG, &NewB);
	if (NewR < 0 || NewR > 61 ||
		NewG < 0 || NewG > 61 ||
		NewB < 0 || NewB > 61)		//Values are incorrect
	{
		return;
	}

	g_thisPtr->m_ChangeR = NewR / 10.;
	g_thisPtr->m_ChangeG = NewG / 10.;
	g_thisPtr->m_ChangeB = NewB / 10.;
}

void CBGColors::NewStartValueR(HWND sender, LPCSTR args)
{
	int NewValue;
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	sscanf(args, "%d", &NewValue);
	if (NewValue >= 0 && NewValue < 62)
	{
		g_thisPtr->m_ChangeR = NewValue / 10.;
		g_thisPtr->m_ChangeG = g_thisPtr->m_ChangeGO / 10.;
		g_thisPtr->m_ChangeB = g_thisPtr->m_ChangeBO / 10.;
	}

}

void CBGColors::NewStartValueG(HWND sender, LPCSTR args)
{
	int NewValue;
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	sscanf(args, "%d", &NewValue);
	if (NewValue >= 0 && NewValue < 62)
	{
		g_thisPtr->m_ChangeR = g_thisPtr->m_ChangeRO / 10.;
		g_thisPtr->m_ChangeG = NewValue / 10.;
		g_thisPtr->m_ChangeB = g_thisPtr->m_ChangeBO / 10.;
	}

}

void CBGColors::NewStartValueB(HWND sender, LPCSTR args)
{
	int NewValue;
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	sscanf(args, "%d", &NewValue);
	if (NewValue >= 0 && NewValue < 62)
	{
		g_thisPtr->m_ChangeR = g_thisPtr->m_ChangeRO / 10.;
		g_thisPtr->m_ChangeG = g_thisPtr->m_ChangeGO / 10.;
		g_thisPtr->m_ChangeB = NewValue / 10.;
	}

}

void CBGColors::ReloadConfig(HWND sender, LPCSTR args)
{
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	//Get back to values from when module was loaded
	g_thisPtr->m_ChangeR = g_thisPtr->m_ChangeRO;
	g_thisPtr->m_ChangeG = g_thisPtr->m_ChangeGO;
	g_thisPtr->m_ChangeB = g_thisPtr->m_ChangeBO;
	g_thisPtr->m_ChangeR /= 10.;
	g_thisPtr->m_ChangeG /= 10.;
	g_thisPtr->m_ChangeB /= 10.;
	g_thisPtr->m_Speed = g_thisPtr->m_SpeedO / 500.;
	if (g_thisPtr->m_Refint != g_thisPtr->m_RefintO)
	{	//Only if necessary, reset the timer
		g_thisPtr->m_Refint = g_thisPtr->m_RefintO;
		if (g_thisPtr->m_Running)
		{
			KillTimer(g_thisPtr->m_TimerWin, REFRESH_TIMER);
			SetTimer(g_thisPtr->m_TimerWin, REFRESH_TIMER,
				g_thisPtr->m_Refint, NULL);
		}

	}

}

void CBGColors::Start(HWND sender, LPCSTR args)
{
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	if (!g_thisPtr->m_Running)
	{
		SetTimer(g_thisPtr->m_TimerWin, REFRESH_TIMER,
			g_thisPtr->m_Refint, NULL);
		g_thisPtr->m_Running = TRUE;
	}

}

void CBGColors::Pause(HWND sender, LPCSTR args)
{
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	if (g_thisPtr->m_Running)
	{
		KillTimer(g_thisPtr->m_TimerWin, REFRESH_TIMER);
		g_thisPtr->m_Running = FALSE;
	}

}

void CBGColors::ShowLogo(HWND sender, LPCSTR args)
{
	if (g_thisPtr == NULL)	//Prevent crash if error occurs
	{
		return;
	}

	if (!g_thisPtr->IsGoodForLogo())
	{
		return;
	}

	if (g_thisPtr->m_LogoState == 0)
	{
		g_thisPtr->InitLogo();
	}

	g_thisPtr->m_LogoState = 60;
}


//The window procedure	(static)

LRESULT CALLBACK CBGColors::WndProc(HWND hwnd, UINT message, WPARAM wParam,
									LPARAM lParam)
{
	if (g_thisPtr == NULL)	//Should never happed, but just to be sure
	{
		return DefWindowProc(hwnd, message, wParam, lParam);
	}

	//Using my CMessage class
	LRESULT ret = g_thisPtr->m_Msgs.TreatMessage(message, wParam, lParam);
	if (ret == MESSAGE_NOT_FOUND)
	{
		return DefWindowProc(hwnd, message, wParam, lParam);
	}

	return ret;
}
