_______________________________________________________________
chronos 1.0                                         14 aug 1999

                            abstract

chronos is  a Litestep  loadable module  which can  display the
current  date and  time anywhere  on the  desktop.  it supports
background bitmaps, variable font styles, and user-defined date
and time formats.


                          installation

copy chronos.dll to your Litestep directory and add a line like
the following to your step.rc file:

  LoadModule C:\Litestep\chronos.dll

or to load chronos as a wharf module, use:

  *Wharf "Chronos" . @C:\Litestep\chronos.dll

after  recycling Litestep,  chronos should  appear as a desktop
or wharf module with the default settings. however, most likely
you'll want to customize chronos to your liking, which leads us
to...


                         configuration

you can add commands to your  step.rc file to customize chronos
to look and function  any way you like.  none of these commands
need to be present,  in which case appropriate defaults will be
used.  a chronos.rc file is  also provided that  can be used as
template for customizing chronos.

  ChronosAlignH (center | left | right)
   
   specifies the horizontal text alignment. the default value
   is "center".
   
  ChronosAlignV (center | top | bottom)
   
   specifies the vertical text alignment. the default value is
   also "center".
   
  ChronosAlwaysOnTop
   
   if present, chronos will appear above all normal windows;
   else chronos remains below all normal windows. this command
   has no effect when loaded as a wharf module.
   
  ChronosBitmap <bitmap-file>
  
   specifies a bitmap file to use to paint the background. if
   this command is not present a default background based on
   system colors is used.
  
  ChronosBorderX <N>
  
   amount of border space between text and the left and right
   edge of the chronos window. this value is in pixels and the
   default is 0. this is only meaningful when ChronosAlignH is
   "left" or "right".
   
  ChronosBorderY <N>
  
   amount of border space between text and the top and bottom
   edge of the chronos window. this value is in pixels and the
   default is 0. this is only meaningful when ChronosAlignV is
   "top" or "bottom".
  
  ChronosFont <font-name>
  
   sets the name of the font used to display the time and date
   text. the default is "Arial".
   
  ChronosFontBold
  
   if present, the date and time font is bold; else the font is
   displayed with normal weight.
  
  ChronosFontColor <color>
  
   sets the main color of date and time font. if font shadow is
   enabled, the default is white; else the default is black.
  
  ChronosFontItalic
  
   if present, the date and time font is italic; else the font
   is displayed normally.
  
  ChronosFontShadow
  
   if present, this command enables font shadow. a second image
   of the date and time is painted behind and offset from the
   main image in the shadow color; else only a single image of
   the text is displayed.
  
  ChronosFontShadowColor <color>
  
   sets the color of the font shadow if shadow is enabled. the
   default color is black.
  
  ChronosFontSize <N>
  
   sets the size (in points) of the font used to display the
   date and time. the default value is 8.
  
  ChronosFormat <format-text>
  
   this command determines how the date and time are formatted
   on screen. the format text can contain normal characters and
   escape sequences. the escape sequences are formed by a
   percent sign (%) followed by a single character. this method
   is similar to that used by strftime, though the set of
   escape sequences is not exactly the same. the following are
   support by chronos:
   
     %% - inserts a single percent sign (%)
     %a - abbreviated weekday name
     %A - full weekday name
     %b - abbreviated month name
     %B - full month name
     %c - locale-specific date and time
     %d - day of month (01-31)
     %e - day of month, no leading zero (1-31)
     %H - hour, 24-hour format (00-24)
     %I - hour, 12-hour format (01-12)
     %j - day of year (001-366)
     %m - month (01-12)
     %M - minute (00-59)
     %p - locale-specific AM/PM indicator
     %S - second (00-59)
     %w - day of week (0-6), 0 = Sun, 6 = Sat
     %x - locale-specific date
     %X - locale-specific time
     %y - 2-digit year (00-99)
     %Y - full year
     %@ - Swatch internet time (000-999)
   
   for example, if it's January 1, 1999 at midnight (assuming
   English language):
   
     format text: "%a, %d %b %y %H:%M:%S"
     displays: "Fri, 01 Jan 99 00:00:00"
     
     format text: "%B %e, %Y %I:%M %p"
     displays: "January 1, 1999 12:00 AM"
     
     format text: "The time is %I hours and %M minutes, %p."
     displays: "The time is 12 hours and 00 minutes, AM."
   
   the default value is "%I:%M %p".
  
  ChronosHidden
  
   if present, chronos starts hidden. use the !ChronosShow or
   !ChronosToggle commands to make it visible.
  
  ChronosInterval <N>
  
   sets the update interval in milliseconds. the default value
   is 1000 (1 second). a larger value reduces the rate at which
   chronos updates its display; a smaller value increases it.
   in almost all cases the default is fine.
  
  ChronosNoAutoSave
  
   normally if you drag chronos to a new location that location
   is saved and chronos returns there on restart/recycle. if
   this command is present, that behavior is disabled and
   chronos will always appear at the location specified by the
   ChronosX and ChronosY commands.
  
  ChronosNoDrag
  
   normally you can drag chronos to a new location on the
   screen. if this command is present dragging is disabled.
  
  ChronosX <N>
  
   sets the horizontal position in pixels that chronos starts
   at, unless overridden by autosave. the default is 0. this
   command has no effect if loaded as a wharf module.
  
  ChronosY <N>
  
   sets the vertical position in pixels that chronos starts at,
   unless overriden by autosave. the default is 0. this command
   has no effect if loaded as a wharf module.
  
  ChronosWidth <N>
  
   sets the width of the chronos window in pixels. the default
   value is 72. this command has no effect if loaded as a wharf
   module.
  
  ChronosHeight <N>
  
   sets the height of the chronos window in pixels. the default
   value is 24. this command has no effect is loaded as a wharf
   module.


                         bang commands

chronos also defines  the following bang  commands which can be
called in the usual manner:

  !ChronosHide
  
   hides chronos
  
  !ChronosMove <X> <Y>
  
   moves chronos to the position specified by X and Y
  
  !ChronosShow
  
   shows chronos
  
  !ChronosToggle
  
   toggles the show/hide state of chronos


                            feedback

if you have a bug report, feature request, or any kind of feed-
back, feel free to email it to me at maduin@dasoft.org.  I will
read all the mail I receive,  but I don't guarentee  I'll reply
to them all.


                           disclaimer

Copyright (C) 1999, Kevin Schaffer

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY,  FITNESS FOR A  PARTICULAR PURPOSE AND NON-
INFRINGEMENT.  IN  NO  EVENT  SHALL  THE  AUTHORS OR  COPYRIGHT
HOLDERS BE  LIABLE FOR ANY CLAIM,  DAMAGES OR  OTHER LIABILITY,
WHETHER IN AN  ACTION OF CONTRACT,  TORT OR OTHERWISE,  ARISING
FROM,  OUT OF OR IN CONNECTION WITH THE  SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

_______________________________________________________________
maduin                                        maduin@dasoft.org
