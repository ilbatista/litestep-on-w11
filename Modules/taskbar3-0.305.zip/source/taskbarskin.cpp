
#include "bangs.h"
#include "taskbar.h"
#include "taskbarskin.h"
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/macros.h"

TaskbarSkin::TaskbarSkin()
{
	TaskbarSkin(NULL, NULL, NULL);
}


TaskbarSkin::TaskbarSkin( LPCSTR pszLeft, LPCSTR pszMiddle, LPCSTR pszRight )
: stretch(TRUE), backColor(0), hbmLeft(NULL), hbmMiddle(NULL), hbmRight(NULL),
HueColor(RGB(125,125,125)), HueIntensity(0), SaturationIntensity(255)
{
	if ( pszLeft && pszLeft[0] )
	{
		hbmLeft = LoadLSImage( pszLeft, NULL );
		GetLSBitmapSize( hbmLeft, &leftW, &leftH );
	}

	if ( pszMiddle && pszMiddle[0] )
	{
		hbmMiddle = LoadLSImage( pszMiddle, NULL );
		GetLSBitmapSize( hbmMiddle, &middleW, &middleH );
	}

	if ( pszRight && pszRight[0] )
	{
		hbmRight = LoadLSImage( pszRight, NULL );
		GetLSBitmapSize( hbmRight, &rightW, &rightH );
	}
}

TaskbarSkin::~TaskbarSkin()
{
	if ( hbmLeft )
		DeleteObject( hbmLeft );

	if ( hbmMiddle )
		DeleteObject( hbmMiddle );

	if ( hbmRight )
		DeleteObject( hbmRight );
}

void TaskbarSkin::Apply( HDC hDC, int x, int y, int width, int height )
{
	HDC hdcBuffer;
	HDC hdcMem;
	HBITMAP hbmBuffer;
	HGDIOBJ hgoBuffer;
	HGDIOBJ hgoMem;
	int widthLeft = width;

	hdcBuffer = CreateCompatibleDC( hDC );
	hbmBuffer = CreateCompatibleBitmap( hDC, width, height );
	hgoBuffer = SelectObject( hdcBuffer, hbmBuffer );

	hdcMem = CreateCompatibleDC( hDC );

	SetStretchBltMode( hdcBuffer, STRETCH_DELETESCANS );

	if ( IsValid() && width > 0 )
	{
		//20030119
		if(hbmLeft != NULL)
		{
			hgoMem = SelectObject( hdcMem, hbmLeft );

			if (stretch)
			{
				StretchBlt( hdcBuffer, 0, 0, min( widthLeft, leftW ), height,
							hdcMem, 0, 0, leftW, leftH, SRCCOPY );
			}
			else
			{
				BitBlt(hdcBuffer, 0, 0, min(widthLeft, leftW), height, hdcMem, 0, 0, SRCCOPY);
			}

			SelectObject( hdcMem, hgoMem );
			widthLeft = widthLeft - leftW;
		}


		//20030119
		if(hbmRight != NULL)
		{
			hgoMem = SelectObject( hdcMem, hbmRight );

			if (stretch)
			{
				StretchBlt( hdcBuffer, width - rightW, 0, min( widthLeft, rightW ),
							height, hdcMem, 0, 0, rightW, rightH, SRCCOPY );
			}
			else
			{
				BitBlt(hdcBuffer, width - rightW, 0, min(widthLeft, rightW), height, hdcMem, 0, 0, SRCCOPY);
			}

			SelectObject( hdcMem, hgoMem );
			widthLeft = widthLeft - rightW;
		}

		hgoMem = SelectObject( hdcMem, hbmMiddle );

		if (stretch)
		{
			StretchBlt( hdcBuffer, hbmLeft ? leftW : 0, 0, widthLeft, height,
						hdcMem, 0, 0, middleW, middleH, SRCCOPY );
		}
		else
		{
			BitBlt(hdcBuffer, hbmLeft ? leftW : 0, 0, widthLeft, height, hdcMem, 0, 0, SRCCOPY);
			//TransparentBltLS(hdcBuffer, hbmLeft ? leftW : 0, 0, widthLeft, height, hdcMem, 0, 0, RGB( 255, 0, 255 ) );
		}

		SelectObject( hdcMem, hgoMem );
	}
	else if (backColor)
	{
		// simple 3D frame
		RECT r;
		HBRUSH hbrBack;

		r.top = 0;
		r.left = 0;
		r.bottom = height;
		r.right = width;

		hbrBack = CreateSolidBrush( backColor );
		FillRect( hdcMem, &r, hbrBack );
		FillRect( hdcBuffer, &r, hbrBack );
		DeleteObject( hbrBack );
	}

	TransparentBltLS( hDC, x, y, width, height, hdcBuffer, 0, 0, RGB( 255, 0, 255 ) );

	SelectObject( hdcBuffer, hgoBuffer );
	DeleteObject( hbmBuffer );
	DeleteObject( hgoBuffer );
	DeleteObject( hgoMem );
	DeleteDC( hdcBuffer );
	DeleteDC( hdcMem );
}


void TaskbarSkin::SetStretch(BOOL s)
{
	stretch = s;
}

BOOL TaskbarSkin::GetStretch()
{
	return stretch;
}

void TaskbarSkin::SetBackColor(COLORREF color)
{
	backColor = color;
}

COLORREF TaskbarSkin::GetBackColor()
{
	return backColor;
}

TaskbarSkin* TaskbarButton::GetSkin()
{
	return skin;
}

TaskbarSkin* TaskbarButton::GetActiveSkin()
{
	return activeskin;
}

TaskbarSkin* TaskbarButton::GetFlashSkin()
{
	return flashskin;
}

TaskbarSkin* TaskbarButton::GetMinimizedSkin()
{
	return minimizedskin;
}

bool TaskbarSkin::IsValid()
{
	//20030119
	/*if(hbmLeft == NULL)
		return false;*/
	if(hbmMiddle == NULL)
		return false;
	//20030119
	/*if(hbmRight == NULL)
		return false;*/
	return true;
}
