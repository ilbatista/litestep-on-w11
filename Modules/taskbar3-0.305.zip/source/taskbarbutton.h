#ifndef __TASKBARBUTTON_H
#define __TASKBARBUTTON_H

#include <string>
#include <vector>
#include "../current/lsapi/lsapi.h"
#include "taskbar.h"
#include "taskbarskin.h"
#include "utilities.h"
#include "bangs.h"
#include "AggressiveOptimize.h"
#include "CLsFont.h"
using namespace std;

class TaskbarButton
{
	friend class Taskbar;
private:

	//boolean active;
	HICON icon;

	char* otherCaption;
	TaskbarSkin* skin;
	TaskbarSkin* activeskin;
	TaskbarSkin* flashskin;
	TaskbarSkin* minimizedskin;

	HWND hTask;

	LPSTR caption;

	//BOOL mousePressed;
	BOOL mouseOver;
	BOOL taskflash; //current state

	int x;
	int y;
	int height;
	int width;

	Taskbar &container;

	//20021128
	void AdjustTooltip(int, LPSTR);

public:
	int currentState;
	int getCurrentState(bool);
	void SetCaption(LPCSTR cap);
	TaskbarSkin* GetSkin();
	TaskbarSkin* GetActiveSkin();
	TaskbarSkin* GetFlashSkin();
	TaskbarSkin* GetMinimizedSkin();
	void SetSkin(TaskbarSkin *s)
	{
		skin = s;
	}
	void SetActiveSkin(TaskbarSkin *s)
	{
		activeskin = s;
	}
	void SetFlashSkin(TaskbarSkin *s)
	{
		flashskin = s;
	}

	void SetMinimizedSkin(TaskbarSkin *s)
	{
		minimizedskin = s;
	}

	TaskbarButton( Taskbar &, HWND );
	virtual ~TaskbarButton();

	BOOL HasPoint( int, int );
	void Move( int, int, int, int );

	//20021125
	void OnButtonDown( int, int, int);
	void OnButtonUp( int, int, int);
	
	bool isOnTop;

	void Close();
	void Close2();
    void SelectUp();
    void SelectDown();
	void MenuUp();
	void MenuDown();
	void OnMouseMove( int, int );
	void OnPaint( HDC );


	BOOL flashing;
	HWND buttonHandler();

	// redraw == TRUE to force ths button to update
	//			 FALSE to let the button decide whether to update or not
	void OnUpdate(BOOL needRedraw = FALSE);

	/*inline BOOL IsActive() const
	{
		return active ? TRUE : FALSE;
	}*/

	bool flashingFlashSkin;

	void SetFlashing(BOOL flash)
	{
		taskflash = flash;
	}

	BOOL GetFlashing() const
	{
		return taskflash;
	}

	bool windowIsActive(HWND);

private:

	LPSTR GetWindowCaption();
	HICON GetIcon();

}
;

#endif