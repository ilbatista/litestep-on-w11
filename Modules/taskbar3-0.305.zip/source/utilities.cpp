#include <algorithm>
#include "common.h"
#include <commctrl.h>
#include <shellapi.h>
#include "taskbar.h"

extern Taskbar *taskbar;

extern vector<string> NoFlashList;
extern vector<string> RemoveList;
extern vector<string> HideList;
extern vector<string> AddList;
extern vector<string> NoScrollList;

//#define WC_SHELLDESKTOP		"DesktopBackGroundClass"

HWND GetParentSettings(bool bAlwaysOnTop)
{
	HWND hParentWindow;
	if((hParentWindow = GetLitestepWnd()) && bAlwaysOnTop)
		return hParentWindow;
	else
	{
		hParentWindow = FindWindow(WC_SHELLDESKTOP, NULL);
		if (!hParentWindow)
			hParentWindow = GetDesktopWindow();
	}
	return hParentWindow;
}

void StringToInts(const char *args, int *int1, int *int2){
    //code from www.mindjunction.com
    char token1[BUFFER_SIZE], token2[BUFFER_SIZE], extra_text[BUFFER_SIZE];
    char* tokens[11];
    int count;
    tokens[0] = token1;
    tokens[1] = token2; 

    count = LCTokenize (args, tokens, 2, extra_text);

    *int1 = atoi(token1);
    *int2 = atoi(token2);
}

BOOL IsSubString(string big, string small)
{
	string::iterator itBig = big.begin();
	string::iterator itSmall = small.begin();

	while(itBig != big.end() && itSmall != small.end())
	{
		if(*itBig == *itSmall)
			++itSmall;
        ++itBig;
	}
	return(itSmall == small.end());
}

BOOL IsOnTaskbarList(HWND hWnd, vector<string> theList)
{
	char tmpTitle[BUFFER_SIZE], tmpClass[BUFFER_SIZE];

	GetWindowText(hWnd, tmpTitle, 1024);
	GetClassName(hWnd, tmpClass, 1024);
    vector<string>::iterator it;

	for (it = theList.begin();it != theList.end();++it)
	{
		if (IsSubString(tmpTitle,*it) || IsSubString(tmpClass,*it))
			return TRUE;
	}
	return FALSE;
}

BOOL IsAppWindow( HWND hWnd )
{
	if( IsOnTaskbarList(hWnd, RemoveList) )
		return FALSE;

	if( IsOnTaskbarList(hWnd, AddList) )
		return TRUE;

	if ( !IsWindowVisible( hWnd ) )
		return FALSE;

	if ( GetWindow( hWnd, GW_OWNER ) )
		return FALSE;

	LONG styleEx = GetWindowLong( hWnd, GWL_EXSTYLE );

	if ( styleEx & WS_EX_APPWINDOW )
		return TRUE;

	if ( styleEx & WS_EX_TOOLWINDOW )
		return FALSE;

	if ( GetWindowLong( hWnd, GWL_USERDATA ) == magicDWord )
		return FALSE;

	return TRUE;
}

// based on jugg's tasks.dll, based on code from Fahim and re5ource
HICON GetIconFromWindow( HWND hWnd, BOOL bBigIcon )
{
	HICON hIcon = NULL;

	if (hWnd)
	{

		SendMessageTimeout( hWnd, WM_GETICON, bBigIcon ? ICON_BIG : ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		if ( !hIcon )
			hIcon = (HICON) GetClassLong( hWnd, bBigIcon ? GCL_HICON : GCL_HICONSM);
		if ( !hIcon )
			SendMessageTimeout( hWnd, WM_QUERYDRAGICON, 0, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		if ( !hIcon )
			SendMessageTimeout( hWnd, WM_GETICON, bBigIcon ? ICON_SMALL : ICON_BIG, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		    //no icon with acdsee4 => why
			//SendMessageTimeout( hWnd, WM_GETICON, bBigIcon ? ICON_BIG:ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		if ( !hIcon )
			hIcon = (HICON) GetClassLong( hWnd, bBigIcon ? GCL_HICON : GCL_HICONSM);
	}
	if(!hIcon)
		hIcon = LoadIcon(NULL, MAKEINTRESOURCE(IDI_APPLICATION));

	return hIcon;
}
