#include <windows.h>
#include "../current/lsapi/lsapi.h"
#include "CWinMgr.h"
#include "utilities.h"
#include "taskbarbutton.h"

// undocumented SwitchToThisWindow API (maybe this should be in LSAPI?)/
extern void (WINAPI *SwitchToThisWindow)(HWND, int);

bool CWinMgr::IsActive(HWND hWindow)
{
	HWND hOwner = GetOwnerWindow(GetForegroundWindow());

	if( hOwner )
      return ( hOwner == hWindow );
	else
      return ( GetForegroundWindow() == hWindow);
}

int CWinMgr::GetState(HWND hWindow)
{
	if(IsIconic(GetRealWindow(hWindow)))
        return STATE_MINIMIZED;
	else if (IsActive(hWindow))
        return STATE_SELECTED;
	else
		return STATE_NORMAL;
}

/*void CWinMgr::SetOnAllDesktops(HWND hWindow)
{
	// hide us from the VWM
	(LONG) = SetWindowLong( GetRealWindow(hWindow), GWL_USERDATA, magicDWord );
	force it into the taskbar
}

void CWinMgr::SetOnOneDesktop(HWND hWindow)
{
}*/

void CWinMgr::OnTopToggle(HWND hWindow)
{
	HWND hRealWindow = GetRealWindow(hWindow);
	if (!IsOnTop(hRealWindow))
	{
		SetOnTop(hRealWindow);
	}
	else
	{
		SetNotOnTop(hRealWindow);
	}
}

bool CWinMgr::IsOnTop(HWND hWindow)
{
	LONG lWindowLong = GetWindowLong(GetRealWindow(hWindow), GWL_EXSTYLE);
	if( lWindowLong  )
	{
		return ((lWindowLong& WS_EX_TOPMOST) == WS_EX_TOPMOST );
	}
	else
	{
		return false;
	}
}

void CWinMgr::SetOnTop(HWND hWindow)
{
	hWindow = GetRealWindow(hWindow);
	//SwitchToThisWindow( hWindow, 1);
	EndDeferWindowPos(DeferWindowPos(BeginDeferWindowPos(1) ,hWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE));
}

void CWinMgr::SetNotOnTop(HWND hWindow)
{
	EndDeferWindowPos(DeferWindowPos(BeginDeferWindowPos(1) ,hWindow, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE));
}

bool CWinMgr::IsShaded(HWND hWindow)
{
	RECT r;
	GetWindowRect(hWindow, &r);
	return (GetSystemMetrics(SM_CYMIN) == (r.bottom - r.top ));
}

void CWinMgr::Shade(HWND hWindow)
{
	hWindow = GetRealWindow(hWindow);
	RECT r;
	SetForegroundWindow(hWindow);
	GetWindowRect(hWindow, &r);
	
	if(!IsZoomed(hWindow))
	{
		if(SetProp(hWindow,"WCNormalHeight",(HANDLE)(r.bottom - r.top)));
	}
	if(SetWindowPos(hWindow, HWND_TOP, r.left, r.top, r.right - r.left, GetSystemMetrics(SM_CYMIN), SWP_NOOWNERZORDER | SWP_NOSENDCHANGING));
}

void CWinMgr::UnShade(HWND hWindow)
{
	RECT r;
	hWindow = GetRealWindow(hWindow);
	SetForegroundWindow(hWindow);
	GetWindowRect(hWindow, &r);

	if (IsZoomed(hWindow))
	{
		if(SetWindowPos(hWindow, HWND_TOP, r.left, r.top, r.right - r.left, GetSystemMetrics(SM_CYSCREEN), SWP_NOOWNERZORDER | SWP_NOSENDCHANGING ));
	}
	else
	{
		long lHeight = (long)GetProp(hWindow,"WCNormalHeight");
		if(lHeight != NULL)
		{
			RemoveProp(hWindow,"WCNormalHeight");
			if(SetWindowPos(hWindow, HWND_TOP, r.left, r.top, r.right - r.left, lHeight, SWP_NOOWNERZORDER | SWP_NOSENDCHANGING ));
		}
		else
		{
			if(SetWindowPos(hWindow, HWND_TOP, r.left, r.top, r.right - r.left, GetSystemMetrics(SM_CYSCREEN), SWP_NOOWNERZORDER | SWP_NOSENDCHANGING ));
		}
	}
}


void CWinMgr::ToggleShade(HWND hWindow)
{
	//from Mirul's Winctrl.dll

	bool bWindowShaded = IsShaded(GetRealWindow(hWindow));

	if(!bWindowShaded)
	{
		Shade(hWindow);
	}
	else
	{
		UnShade(hWindow);
	}	
}

void CWinMgr::MinimizeWindow(HWND hWindow)
{
	ShowWindowAsync( hWindow, SW_MINIMIZE );
}

void CWinMgr::RestoreWindow(HWND hWindow)
{
	SwitchToThisWindow( hWindow, SW_RESTORE );
}

void CWinMgr::SelectWindow(HWND hWindow)
{
	SwitchToThisWindow( hWindow, SW_RESTORE );
}

void CWinMgr::Close(HWND hWindow)
{
	SendMessage(hWindow, WM_CLOSE,0,0);
}

void CWinMgr::Close2(HWND hWindow)
{
	SendMessage(hWindow, WM_DESTROY,0,0); //if cancel -> still destroyed
}

//Private
HWND CWinMgr::GetOwnerWindow(HWND hWindow)
{
	return GetWindow(hWindow, GW_OWNER);
}

HWND CWinMgr::GetRealWindow(HWND hWindow)
{
	HWND hOwner = GetOwnerWindow(hWindow);

	if(hOwner)
	{
      return hOwner;
	}
	else
	{
      return hWindow;
	}
}
