	#include "bangs.h"
#include "taskbar.h"
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/macros.h"

//#include "CWinMgr.h"

extern Taskbar *taskbar;

/*CWinMgr BangWindowManager;

void SetNotOnTopBangCommand(HWND hCaller, const char *args)
{
	BangWindowManager.SetNotOnTop(taskbar->gethWnd());
}

void SetOnTopBangCommand(HWND hCaller, const char *args)
{
	BangWindowManager.SetOnTop(taskbar->gethWnd());
}

void hideBangCommand(HWND hCaller, const char *args)
{
	if(BangWindowManager.IsOnTop(taskbar->gethWnd()))
	{
		SetNotOnTopBangCommand(taskbar->gethWnd(),"");
	}
	else
	{
		SetOnTopBangCommand(taskbar->gethWnd(),"");
	}
}*/

void hideBangCommand(HWND hCaller, const char *args)
{
	taskbar->hide();
}

//20021108
void refreshBangCommand(HWND hCaller, const char *args)
{
	taskbar->OnRefresh();
}

void toggleBangCommand(HWND hCaller, const char *args)
{
	if (taskbar->isVisible())
		taskbar->hide();
	else
		taskbar->show();
}

void showBangCommand(HWND hCaller, const char *args)
{
	taskbar->show();
}

void sizeBangCommand(HWND hCaller, const char *args){
    //code from www.mindjunction.com
	int cx = 0, cy = 0;
	StringToInts(args, &cx, &cy);
	if (cx <= 0)
		cx = taskbar->width;
	if (cy <= 0)
		cy = taskbar->height;

	MoveWindow( taskbar->hWnd ,  taskbar->taskbarX, taskbar->taskbarY, cx, cy, TRUE);
	taskbar->width = cx;
	taskbar->height = cy;
	taskbar->Layout();
}

void maxTasksBangCommand(HWND hCaller, const char *args){
	int i = 0;
    
	//code from www.mindjunction.com
    char token1[BUFFER_SIZE], extra_text[BUFFER_SIZE];
    char* tokens[11];
    int count;
    tokens[0] = token1;

    count = LCTokenize (args, tokens, 1, extra_text);

    i = atoi(token1);

	taskbar->maxButtonCount =  i;
	if (taskbar->maxButtonCount <= 0)
	  taskbar->maxButtonCount = 1;
	taskbar->Layout();
}

void moveBangCommand(HWND hCaller, const char *args){
    //code from www.mindjunction.com
	int cx = 0, cy = 0;
	StringToInts(args, &cx, &cy);

	char tmpClass[BUFFER_SIZE];
    GetClassName(GetParent(taskbar->hWnd ), tmpClass, 1024);

	if (!lstrcmpi(tmpClass,"LsBoxClass") && taskbar->LsBoxed){
		RECT r;
		GetClientRect( GetParent(taskbar->hWnd ), &r );
		if (cx < 0)
			cx = (r.right - r.left) + cx;
		if (cy < 0)
			cy = (r.bottom - r.top) + cy;
	}
	else {
		if (cx < 0)
			cx = SCREEN_WIDTH + cx;
		if (cy < 0)
			cy = SCREEN_HEIGHT + cy;
	}

	MoveWindow( taskbar->hWnd ,  cx, cy, taskbar->width, taskbar->height, TRUE);
	taskbar->taskbarX = cx;
	taskbar->taskbarY = cy;

	taskbar->Layout();
}

void linesBangCommand(HWND hCaller, const char *args){
    //code from www.mindjunction.com
	int lines = 0;
    char token1[BUFFER_SIZE], extra_text[BUFFER_SIZE];
    char* tokens[11];
    int count;
    tokens[0] = token1;

    count = LCTokenize (args, tokens, 1, extra_text);

    lines = atoi(token1);

	taskbar->taskbarLines =  lines;
	if (taskbar->taskbarLines <= 0)
	  taskbar->taskbarLines = 1;

    taskbar->Layout();

}

void shrinkBangCommand(HWND hCaller, const char *args){
    //code from www.mindjunction.com
	int x = 0, y = 0;
	StringToInts(args, &x, &y);
	if (x <= 0)
		x = 0;
	if (y <= 0)
		y = 0;

	//MoveWindow( taskbar->hWnd ,  taskbar->taskbarX, taskbar->taskbarY, taskbar->width - x,taskbar->height - y, TRUE);
    taskbar->Resize(-x,-y);
	/*taskbar->width = taskbar->width - x;
	taskbar->height = taskbar->width - y;
	taskbar->Layout();*/
}

void growBangCommand(HWND hCaller, const char *args){
    //code from www.mindjunction.com
	int x = 0, y = 0;
	StringToInts(args, &x, &y);
	if (x <= 0)
		x = 0;
	if (y <= 0)
		y = 0;


	//MoveWindow( taskbar->hWnd ,  taskbar->taskbarX, taskbar->taskbarY, taskbar->width + x,taskbar->height + y, TRUE);
    taskbar->Resize(x,y);
	/*taskbar->width = taskbar->width + x;
	taskbar->height = taskbar->width + y;
	taskbar->Layout();*/
}

void moveByBangCommand(HWND hCaller, const char *args){
    //code from www.mindjunction.com
	int cx = 0, cy = 0;
	StringToInts(args, &cx, &cy);

    //WTF ??????
	MoveWindow( taskbar->hWnd ,  taskbar->taskbarX + cx, taskbar->taskbarY + cy, taskbar->width ,taskbar->height, TRUE);
	taskbar->taskbarX = taskbar->taskbarX + cx;
    taskbar->taskbarY = taskbar->taskbarY + cy;
	taskbar->Layout();
}

/*void scrollFlashOnByBangCommand(HWND hCaller, const char *args){
	taskbar->timerScrollEnabled = true;
	taskbar->scrollWas = (GetKeyState(VK_SCROLL) != 0);
}

void scrollFlashOffByBangCommand(HWND hCaller, const char *args){
	taskbar->timerScrollEnabled = false;
    taskbar->resetScroll = true;
}

void scrollFlashToggleByBangCommand(HWND hCaller, const char *args){
	if(taskbar->timerScrollEnabled)
		taskbar->timerScrollEnabled = false;
	else
		taskbar->timerScrollEnabled = true;
}*/

void hideTasksToggleBangCommand(HWND hCaller, const char *args){
	if(taskbar->reallyHidden)
		hideTasksOffBangCommand(NULL, "");		
	else
		hideTasksOnBangCommand(NULL, "");
}

void hideTasksOnBangCommand(HWND hCaller, const char *args){
	taskbar->reallyHidden = true;
}

void hideTasksOffBangCommand(HWND hCaller, const char *args){
	taskbar->reallyHidden = false;
}

void taskbarSwitchBangCommand(HWND hCaller, const char *args)
{
	if( taskbar->lastActive ){
		taskbar->SwitchToButton(args);
	}
	return;
} 

void taskbarShowPartBangCommand(HWND hCaller, const char *args)
{
	//add the ability to specify of how many tasks it moves
	taskbar->ShowPart(args, 1);
	taskbar->Layout();
}

void BangBoxHook(HWND caller, const char *args)
{
	char *handle = strrchr(args,' ');

	if (handle) 
	{
		HWND boxwnd = (HWND)atoi(handle+1);
		if (boxwnd) 
		{
			HWND hWnd = taskbar->hWnd ;
			if (boxwnd != GetParent(hWnd))
			{
				SetWindowLong(hWnd, GWL_STYLE, (GetWindowLong(hWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);				
				SetParent(hWnd, boxwnd);
				RECT r;
				GetClientRect( boxwnd, &r );
				/*if (taskbar->taskbarPositioning)
				{*/
					int x = taskbar->taskbarXS;
					int y = taskbar->taskbarYS;
					if(taskbar->taskbarXS<0)
						x = (r.right - r.left) + taskbar->taskbarXS;
					if(taskbar->taskbarYS<0)
						y = (r.bottom - r.top) + taskbar->taskbarYS;
					MoveWindow( taskbar->hWnd ,  x, y, taskbar->width ,taskbar->height, TRUE);
				/*}
				else
				{
					if ( taskbar->edge == EDGE_TOP )
					{
						MoveWindow( taskbar->hWnd ,  0, 0, taskbar->width ,taskbar->height, TRUE);
					}
					else
					{
						MoveWindow( taskbar->hWnd ,  0, r.bottom - r.top - taskbar->neededHeight, taskbar->width ,taskbar->height, TRUE);
					}
				}*/
		        showBangCommand(NULL, "");
				taskbar->LsBoxed = true;
			}
		}
	}
	return;
}

bool HasParameter(const char* pszIn)
{
	int nAccentPlace1 = -1;
	int nAccentPlace2 = -1;
	int nAtPlace = -1;
	int i;
	int nStringLength = strlen( pszIn );

	for( i = 0 ; ( i < nStringLength ) && ( nAccentPlace1 == -1 ) ; ++i )
	{
		if( pszIn[i] == '^' )
			nAccentPlace1 = i;
	}

	for( i = 0 ; ( i < nStringLength ) && ( nAtPlace == -1 ) ; ++i )
	{
		if( pszIn[i] == '@' )
			nAtPlace = i;
	}

	for( i = nAtPlace ; ( i < nStringLength ) ; ++i )
	{
		if( pszIn[i] == '^' ) 
			if( ( ( i + 1 < nStringLength) && ( pszIn[ i + 1 ] != '@') ) || ( i + 1 == nStringLength) )
			{
				nAccentPlace2 = i;
				//LSLogPrintf(0, __FILE__, "i: %d", i);
			}
	}

	if( ( nAccentPlace2 > nAtPlace ) && ( nAtPlace == nAccentPlace1 + 1 ) && ( nAccentPlace2 > nAccentPlace1 + 1 ) )
		return true;
	else
		return false;
}

void ExecuteParameter( const char* pszArgs, char* pszToFind, char* pszToReplace )
{
	char szCommand[1024];
	wsprintf(szCommand, "!WndSendToTray %s", pszToReplace);
	//LSLogPrintf(0, __FILE__, "%s", szCommand);
	LSExecute(NULL, szCommand, NULL);
}

//!taskbarexecute ^@WindowClassName^
void executeBangCommand(HWND hCaller, const char *args)
{
	//get string and replace vars with values
	//executeString
	//-------------//
	//for the time being, the only parameter can be ^@WindowClassName^
	char pszClassName[1024];
	if( HasParameter( args ) )
	{
		GetClassName(taskbar->lastActive, pszClassName, 1024);
		ExecuteParameter( args, "WindowClassName", pszClassName );
	}

		
	/*
		copier ce qui pr�c�de et ce qui suit dans un string, et remplacer entre-temps le string avec la class de la derni�re fen�tre
		args = module.ParseParameter( GetParameter );
	*/
}
