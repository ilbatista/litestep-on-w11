/*
	20021208	Per-state showText
*/
#include <algorithm>
#include "common.h"
#include <commctrl.h>
#include <shellapi.h>
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/macros.h"
#include "CLsFont.h"

CLsFont::CLsFont():
//m_hFont(),
m_wTextColor(RGB(255, 255, 255)),
m_bUseShadow(FALSE),
m_wShadowColor(RGB(255, 255, 255)),
m_nShadowOffsetX(1),
m_nShadowOffsetY(1),
m_nTextAlign(DT_SINGLELINE | DT_END_ELLIPSIS)
{
	//strcpy(m_pszFontName, pszFontName);
}

void CLsFont::GetTextMetrics(TEXTMETRIC &tmTemp)
{
	HDC hDC;
	HFONT hfnTemp;

	hDC = GetDC( NULL );
	hfnTemp = (HFONT) SelectObject( hDC, m_hFont );

	::GetTextMetrics( hDC, &tmTemp );

	SelectObject( hDC, hfnTemp );
	ReleaseDC( NULL, hDC );
	DeleteObject( hfnTemp );	
}

CLsFont::~CLsFont()
{
	DeleteObject( m_hFont );
}

void CLsFont::GetTextAlignment(char* pszFontName, UINT uDefaultH, UINT uDefaultV)
{
	char pszTemp[MAX_PATH];
	char pszBuffer[MAX_PATH];
	
	m_nTextAlign = DT_SINGLELINE | DT_END_ELLIPSIS;
	wsprintf(pszTemp, "%sHFontAlign", pszFontName);
	if ( GetRCString(pszTemp, pszBuffer, "", 16 ) )
	{
		if ( !stricmp( pszBuffer, ".center" ) )
			m_nTextAlign = m_nTextAlign | DT_CENTER;
		else if ( !stricmp( pszBuffer, ".right" ) )
			m_nTextAlign = m_nTextAlign | DT_RIGHT;
		else
			m_nTextAlign = m_nTextAlign | DT_LEFT;
	}
	else
		m_nTextAlign = m_nTextAlign | uDefaultH;

	wsprintf(pszTemp, "%sVFontAlign", pszFontName);
	if ( GetRCString( pszTemp, pszBuffer, "", 16 ) )
	{
		if ( !stricmp( pszBuffer, ".center" ) )
			m_nTextAlign = m_nTextAlign | DT_VCENTER;
		else if ( !stricmp( pszBuffer, ".bottom" ) )
			m_nTextAlign = m_nTextAlign | DT_BOTTOM;
		else
			m_nTextAlign = m_nTextAlign | DT_TOP;
	}
	else
		m_nTextAlign = m_nTextAlign | uDefaultV;
}


void CLsFont::Apply( HDC hDC, RECT &r, char* pszCaption)
{
	HFONT hTempFont;
	COLORREF wTempColor;

	if(!pszCaption)
	{
		return;
	}

	SetBkMode( hDC, TRANSPARENT );
	
	if(m_bUseShadow)
	{
		r.left += m_nShadowOffsetX;
		r.top += m_nShadowOffsetY;

		wTempColor = SetTextColor( hDC, m_wShadowColor);
		hTempFont = (HFONT) SelectObject( hDC, m_hFont);
		DrawText(hDC, pszCaption, strlen(pszCaption), &r, m_nTextAlign);
		SetTextColor( hDC, wTempColor );
		SelectObject( hDC, hTempFont );

		r.left -= m_nShadowOffsetX;
		r.top -= m_nShadowOffsetY;

	}

	wTempColor = SetTextColor( hDC, m_wTextColor);
	hTempFont = (HFONT) SelectObject( hDC, m_hFont );
	DrawText( hDC, pszCaption, strlen(pszCaption), &r, m_nTextAlign );
	SetTextColor( hDC, wTempColor );
	SelectObject( hDC,hTempFont);
	DeleteObject(hTempFont);
}

void CLsFont::ReadFontColor(char* pszFont, COLORREF wDefaultColor)
{
	m_wTextColor = GetRCColor(pszFont, wDefaultColor);
}

void CLsFont::ReadShadowSettings(char* pszFontName, BOOL bDefault, COLORREF wDefaultColor, int nDefaultX, int nDefaultY)
{
	char pszTemp[MAX_PATH];

	wsprintf(pszTemp, "%sFontNoShadow\0", pszFontName);
	BOOL bUseShadow = FALSE;
	bUseShadow = GetRCBool(pszTemp, TRUE);
	if(bDefault == TRUE)
	{
		m_bUseShadow = !bUseShadow;
	}
	else
	{
		m_bUseShadow = FALSE;
	}

	wsprintf(pszTemp, "%sFontShadowColor", pszFontName);
	m_wShadowColor = GetRCColor(pszTemp, wDefaultColor);

	wsprintf(pszTemp, "%sFontShadowOffsetX", pszFontName);
	m_nShadowOffsetX = GetRCInt(pszTemp, nDefaultX);

	wsprintf(pszTemp, "%sFontShadowOffsetY", pszFontName);
	m_nShadowOffsetY = GetRCInt(pszTemp, nDefaultY);
}

HFONT CLsFont::GetDefaultFont(char* pszFontRCName, LOGFONT* lfDefault)
{
	char pszTemp[MAX_PATH];
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));
	//20030109 internationalisation: thanks to Tom Ephrati for noticeing
	lf.lfCharSet = DEFAULT_CHARSET;

	wsprintf(pszTemp, "%sFontFace", pszFontRCName);
	//font settings
	GetRCString(pszTemp, lf.lfFaceName, lfDefault->lfFaceName, LF_FACESIZE);
	strcpy(lfDefault->lfFaceName, lf.lfFaceName);

	wsprintf(pszTemp, "%sFontHeight", pszFontRCName);
	lf.lfHeight = GetRCInt(pszTemp, lfDefault->lfHeight);
	lfDefault->lfHeight = lf.lfHeight;

	wsprintf(pszTemp, "%sFontBold", pszFontRCName);
	lf.lfWeight = GetRCBool(pszTemp, TRUE) ? FW_BOLD : FW_NORMAL;
	lfDefault->lfWeight = lf.lfWeight;

	wsprintf(pszTemp, "%sFontItalic", pszFontRCName);
	lf.lfItalic = GetRCBool(pszTemp, TRUE);
	lfDefault->lfItalic = lf.lfItalic;

	wsprintf(pszTemp, "%sFontUnderLine", pszFontRCName);
	lf.lfUnderline = GetRCBool(pszTemp, TRUE);
	lfDefault->lfUnderline = lf.lfUnderline;

	m_hFont = CreateFontIndirect(&lf);
	return m_hFont;
}

HFONT CLsFont::GetFont(char* pszFontRCName,const LOGFONT* lfDefault)
{
	char pszTemp[MAX_PATH];
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));
	//20030109 internationalisation: thanks to Tom Ephrati for noticeing
	lf.lfCharSet = DEFAULT_CHARSET;

	wsprintf(pszTemp, "%sFontFace", pszFontRCName);
	//font settings
	GetRCString(pszTemp, lf.lfFaceName, lfDefault->lfFaceName, LF_FACESIZE);
	wsprintf(pszTemp, "%sFontHeight", pszFontRCName);
	lf.lfHeight = GetRCInt(pszTemp, lfDefault->lfHeight);
	wsprintf(pszTemp, "%sFontBold", pszFontRCName);
	lf.lfWeight = GetRCBool(pszTemp, TRUE) ? FW_BOLD : FW_NORMAL;
	wsprintf(pszTemp, "%sFontItalic", pszFontRCName);
	lf.lfItalic = GetRCBool(pszTemp, TRUE);
	wsprintf(pszTemp, "%sFontUnderLine", pszFontRCName);
	lf.lfUnderline = GetRCBool(pszTemp, TRUE);

	m_hFont = CreateFontIndirect(&lf);
	return m_hFont;
}
