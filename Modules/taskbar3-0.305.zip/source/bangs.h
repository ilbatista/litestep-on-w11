#ifndef __BANGS_H
#define __BANGS_H

#include "taskbar.h"
#include "../current/lsapi/lsapi.h"
#include "AggressiveOptimize.h"

void hideBangCommand(HWND hCaller, const char *args);
void toggleBangCommand(HWND hCaller, const char *args);
void showBangCommand(HWND hCaller, const char *args);

void sizeBangCommand(HWND hCaller, const char *args);
void moveBangCommand(HWND hCaller, const char *args);

void BangBoxHook(HWND hCaller, const char *args);
void linesBangCommand(HWND hCaller, const char *args);

void shrinkBangCommand(HWND hCaller, const char *args);
void growBangCommand(HWND hCaller, const char *args);

void moveByBangCommand(HWND hCaller, const char *args);

/*void scrollFlashOnByBangCommand(HWND hCaller, const char *args);
void scrollFlashOffByBangCommand(HWND hCaller, const char *args);
void scrollFlashToggleByBangCommand(HWND hCaller, const char *args);*/

void hideTasksToggleBangCommand(HWND hCaller, const char *args);
void hideTasksOnBangCommand(HWND hCaller, const char *args);
void hideTasksOffBangCommand(HWND hCaller, const char *args);

void taskbarSwitchBangCommand(HWND hCaller, const char *args);

void taskbarShowPartBangCommand(HWND hCaller, const char *args);

void maxTasksBangCommand(HWND hCaller, const char *args);
//20021108
void refreshBangCommand(HWND hCaller, const char *args);
void executeBangCommand(HWND hCaller, const char *args);

#endif // __BANGS_H