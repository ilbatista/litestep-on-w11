/****************************************************************************
****************************************************************************/

/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/

#include <algorithm>
#include "common.h"
#include <commctrl.h>
#include <shellapi.h>
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/macros.h"
#include "utilities.h"
#include "taskbar.h"
#include "bangs.h"
#include "CWinMgr.h"

// undocumented SwitchToThisWindow API (maybe this should be in LSAPI?)
void (WINAPI *SwitchToThisWindow)(HWND, int);

const char aboutStr[] = "taskbar3.dll: 0.305";

//hack!!
int g_nButtonsAddedAtStartup;

Taskbar *taskbar;
CWinMgr WindowManager;

vector<string> NoFlashList;
vector<string> RemoveList;
vector<string> HideList;
vector<string> AddList;
//vector<string> NoScrollList;

//
// utility functions
//

void Taskbar::OnMove( int xP, int yP )
{
	taskbarX = xP;
	taskbarY = yP;
    SetWindowPosition();
}

void Taskbar::SwitchToButton( const char *args ){
	HWND current, prev, next;
	current = prev = next = NULL;
	TaskbarButtonIterator it ;

	current = lastActive;

	it = buttons.begin();

	while (it != buttons.end() && (*it)->hTask  != next){
		if((*it)->hTask  == current){
			++it;
			if(it != buttons.end())
				next = (*it)->hTask ;
			
		}
		else{
			prev = (*it)->hTask ;
			++it;
		}
	}

	if(!strcmp(args, "next") && next != NULL)
		WindowManager.SelectWindow(next);
	else if (!strcmp(args, "prev") && prev != NULL)
		WindowManager.SelectWindow(prev);
}

void Taskbar::ShowPart( const char *args , int i ){
	if(!strcmp(args, "next")){
		if( taskbar->buttons.size() > taskbar->maxButtonCount )
		if( taskbar->buttonCountStart + i <= taskbar->buttons.size() - taskbar->maxButtonCount )
			taskbar->buttonCountStart = taskbar->buttonCountStart + i;
	}
	else if(!strcmp(args, "prev"))
		if( taskbar->buttonCountStart - i >= 0 )
			taskbar->buttonCountStart = taskbar->buttonCountStart - i;
}

//
// Taskbar
//

Taskbar::Taskbar()
: hWnd(NULL), hInstance(NULL), hToolTips(NULL), /*edge(EDGE_BOTTOM),*/ height(0), width(0),
  neededHeight(0), screenWidth(0), active(FALSE), mouseOver(FALSE),
  capture(NULL), skin(NULL), buttonSkin(NULL), activeButtonSkin(NULL), flashSkin(NULL),
  minimizedSkin(NULL), lastActive(GetActiveWindow()),
  taskbarLines(1), alwaysOnTop(FALSE),
  LsBoxed(false), reallyHidden(false), visible(false), nOldFlashingCount(0),
  buttonCountStart(0), useRealFlashing(false), taskbarTextShadow(false), textMinimizedNoShadow(FALSE),
  textNormalNoShadow(FALSE), textSelectedNoShadow(FALSE), textFlashingNoShadow(FALSE), switchOnHover(false), useToolTips(true),
  ColorHue(RGB(125,125,125)), HueIntensity(0), NormalColorHue(RGB(125,125,125)), NormalHueIntensity(0),
  MinimizedColorHue(RGB(125,125,125)), MinimizedHueIntensity(0), SelectedColorHue(RGB(125,125,125)), SelectedHueIntensity(0),
  FlashingColorHue(RGB(125,125,125)), FlashingHueIntensity(0), nFlashingCount(0)
{
	// ...
}

Taskbar::~Taskbar()
{
	// ...
}

UINT messages[] = {
                      LM_LSSELECT,
                      LM_GETMINRECT,
                      LM_REDRAW,
                      LM_WINDOWACTIVATED,
                      LM_WINDOWCREATED,
                      LM_WINDOWDESTROYED,
					  LM_GETREVID,
					  LM_REFRESH,
                      0
                  };

void Taskbar::OnLoad( HINSTANCE hInstanceP )
{
	g_nButtonsAddedAtStartup = 0;

	hInstance = hInstanceP;

	// get config variables from step.rc
	ReadPositionConfig();

	// register taskbar window class
	WNDCLASSEX wc;
	memset( &wc, 0, sizeof(WNDCLASSEX) );

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = Taskbar::WndProc;
	wc.cbWndExtra = sizeof(Taskbar *);
	wc.hInstance = hInstance;
	wc.hCursor = LoadCursor( NULL, IDC_ARROW );
	wc.lpszClassName = WC_TASKBAR;

	if ( !RegisterClassEx( &wc ) )
	{
		RESOURCE_MSGBOX( hInstance, IDS_TASKBAR_ERROR1,
		                 "Could not register taskbar window class.", "Taskbar")
		return ;
	}

     hWnd = CreateWindowEx( alwaysOnTop? WS_EX_TOOLWINDOW | WS_EX_TOPMOST : WS_EX_TOOLWINDOW, //666
                            WC_TASKBAR,
                            NULL,
                            WS_POPUP,
                            taskbar->taskbarX, taskbar->taskbarY, taskbar->width, taskbar->height,
							GetParentSettings(alwaysOnTop),
                            NULL,
                            hInstance,
                            (LPVOID) this );

	if ( !hWnd )
	{
		RESOURCE_MSGBOX( hInstance, IDS_TASKBAR_ERROR2,
		                 "Could not create taskbar window.", "Taskbar")

		return ;
	}
	// create tooltips control
	if(useToolTips)//20021108
	{
		hToolTips = CreateWindowEx( WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
			                        TOOLTIPS_CLASS,
									NULL,
									TTS_ALWAYSTIP | WS_POPUP,
									0, 0, 0, 0,
									hWnd,
									NULL,
									hInstance,
									NULL );

		SetWindowPos( hToolTips, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE); //20021108
	}
	OnRefreshReload();
}

void Taskbar::OnRefreshUnload()
{
	// shutdown timer
	KillTimer(hWnd, TIMER_UPDATE);
	// release buttons
	for (TaskbarButtonIterator it = buttons.begin(); it != buttons.end(); ++it)
	{
		delete (*it);
		*it = NULL;
	}
	buttons.clear();
	// release skins
	delete skin;
	delete buttonSkin;
	delete activeButtonSkin;
	delete minimizedSkin;
	delete flashSkin;

	DeleteObject((void*)skin->Font.m_hFont);
	DeleteObject((void*)buttonSkin->Font.m_hFont);
	DeleteObject((void*)activeButtonSkin->Font.m_hFont);
	DeleteObject((void*)minimizedSkin->Font.m_hFont);
	DeleteObject((void*)flashSkin->Font.m_hFont);

	//20021230
	free (pszOnAddCommand);
	free (pszOnDelCommand);
	free (pszOnFlashStartCommand);
	free (pszOnFlashStopCommand);
}

void Taskbar::OnRefreshReload()
{
	g_nButtonsAddedAtStartup = 0;
	//read new config
	ReadConfig();
	SetWindowPos( hWnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	//SetWindowPos( hWnd, alwaysOnTop? HWND_TOPMOST : HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	// hide us from the VWM
	SetWindowLong( hWnd, GWL_USERDATA, magicDWord );
	ComputeNeededHeight();
	SetWindowPosition();
	ShowWindow(hWnd, visible ? SW_SHOWNOACTIVATE : SW_HIDE);

	EnumWindows(Taskbar::EnumWindowsProc, (LPARAM) this);

	SetTimer(hWnd, TIMER_UPDATE, timerRefresh, NULL);
	// register for LS messages
	SendMessage( GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM) hWnd, (LPARAM) ::messages );
	DragAcceptFiles(hWnd, TRUE);
	Layout();
}

void Taskbar::OnUnload()
{
	OnRefreshUnload();
	// unregister messages
	SendMessage( GetLitestepWnd(), LM_UNREGISTERMESSAGE,
	             (WPARAM) hWnd, (LPARAM) ::messages );

	// destroy tooltips control
	if ( hToolTips )
		DestroyWindow( hToolTips );

	// destroy window and unregister class
	if ( hWnd )
		DestroyWindow( hWnd );

	UnregisterClass( WC_TASKBAR, hInstance );

}

void Taskbar::hide()
{
	if (visible)
	{
		visible = false;
		ShowWindow(hWnd, SW_HIDE);
	}
}

void Taskbar::show()
{
	if (!visible)
	{
		visible = true;
		ShowWindow(hWnd, SW_SHOWNOACTIVATE);
	}
}

void Taskbar::Invalidate( int x, int y, int cx, int cy )
{
	RECT r;

	r.left = x;
	r.top = y;
	r.right = x + cx;
	r.bottom = y + cy;

	InvalidateRect( hWnd, &r, FALSE );
}

TaskbarButton *Taskbar::GetCapture()
{
	return capture;
}

void Taskbar::SetCapture( TaskbarButton *button )
{
	::SetCapture( hWnd );
	capture = button;
}

void Taskbar::ReleaseCapture()
{
	::ReleaseCapture();
	capture = NULL;
}

TaskbarButton *Taskbar::ButtonAtPoint( int x, int y )
{
	for (TaskbarButtonIterator it = buttons.begin(); it != buttons.end(); ++it)
	{
		if ( (*it)->HasPoint(x, y) )
		{
			return (*it);
		}
	}

	return NULL;
}

int Taskbar::GetRCMouse(const char * rcString, int intDefault){
	char buffer[MAX_PATH];

	if ( GetRCString( rcString, buffer, "", 16 ) ){
		if ( !stricmp( buffer, ".select" ) )
			return MOUSE_SELECT;
		else if ( !stricmp( buffer, ".menu" ) )
			return MOUSE_MENU;
		else if ( !stricmp( buffer, ".close" ) )
			return MOUSE_CLOSE;
		else if ( !stricmp( buffer, ".close2" ) )
			return MOUSE_CLOSE2;
		else if ( !stricmp( buffer, ".ontop" ) )
			return MOUSE_ONTOP;
		else if ( !stricmp( buffer, ".shade" ) )
			return MOUSE_SHADE;
		else
			return MOUSE_SELECT;
	}
	else
		return intDefault;
}

void Taskbar::GetRCList(char *text, vector<string> &theList){
	//code from www.mindjunction.com
	FILE *f;
	f = LCOpen (NULL);
	if (f){
		char buffer[BUFFER_SIZE];
 		char token1[1204], token2[BUFFER_SIZE], extra_text[BUFFER_SIZE];
 		char* tokens[2];
	 
 		tokens[0] = token1;
 		tokens[1] = token2;
 
	 	buffer[0] = 0;

		while (LCReadNextConfig (f, text, buffer, sizeof (buffer)))
		{
			int count;
 
			token1[0] = token2[0] = extra_text[0] = NULL;
  
 			count = LCTokenize (buffer, tokens, 2, extra_text);
  
  			// token 1 is "*TaskbarXXXX", token 2 is the
  			// application class or title, and the extra_text are something to forget.
  			if (count >= 2)
				theList.push_back(tokens[1]);
 		}
	}
}

void Taskbar::GetRCRect(char *text, int &left, int &right, int &top, int &bottom, int dv_left, int dv_right, int dv_top, int dv_bottom){
	char buffer[BUFFER_SIZE];
 	char token1[1204], token2[BUFFER_SIZE], token3[BUFFER_SIZE], token4[BUFFER_SIZE], extra_text[BUFFER_SIZE];
 	char* tokens[4];
	 
 	tokens[0] = token1;
 	tokens[1] = token2;
 	tokens[2] = token3;
 	tokens[3] = token4;
 
	buffer[0] = 0;

    if(GetRCLine(text, buffer, 1024, "")){
		int count;

		//20021125
		token1[0] = token2[0] = token3[0] = token4[0] = extra_text[0] = NULL;
  
	 	count = LCTokenize (buffer, tokens, 4, extra_text);
        if(count >= 1){
			if(count >=4){
				left = atoi(token1);
				right = atoi(token2);
				top = atoi(token3);
				bottom = atoi(token4);
			}
			else{
				right = top = bottom = left = atoi(token1);
			}
		}
		else{
			right = dv_right;
			top = dv_top;
			bottom = dv_bottom;
			left = dv_left;
		}
	}
	else{
		right = dv_right;
		top = dv_top;
		bottom = dv_bottom;
		left = dv_left;
	}
}

void Taskbar::ReadPositionConfig()
{

	visible = (!GetRCBool( "TaskbarStartHidden", TRUE));
	taskbarX = GetRCInt("TaskbarX", 0);
	taskbarXS = taskbarX;
	if (taskbarX < 0)
		taskbarX = SCREEN_WIDTH + taskbarX;
	taskbarY = GetRCInt("TaskbarY", -(SCREEN_HEIGHT+1));
	taskbarYS = taskbarY;
	if (taskbarY < 0)
		taskbarY = SCREEN_HEIGHT + taskbarY;
	alwaysOnTop = (TRUE == GetRCBool("TaskbarAlwaysOnTop", TRUE));
	taskbarHeight = GetRCInt( TEXT("TaskbarHeight"), 0 );
	screenWidth = GetRCInt( TEXT("TaskbarWidth"), SCREEN_WIDTH );
}

TaskbarSkin* Taskbar::GetSkin(char* pszType)
{
	char pszTemp[MAX_PATH];
	char buffer[MAX_PATH];
	char bufferLeft[MAX_PATH];
	char bufferRight[MAX_PATH];
	wsprintf(pszTemp, "%sSkinCenter", pszType);
	if ( GetRCString(pszTemp, buffer, "", MAX_PATH ) )
	{
		wsprintf(pszTemp, "%sSkinLeft", pszType);
		GetRCString(pszTemp, bufferLeft, "", MAX_PATH );
		wsprintf(pszTemp, "%sSkinRight", pszType);
		GetRCString(pszTemp, bufferRight, "", MAX_PATH );

		return new TaskbarSkin( bufferLeft, buffer, bufferRight );
	}
	else
	{
		return new TaskbarSkin( NULL, NULL, NULL );
	}
}

void TaskbarSkin::ReadSkinColor(char* pszType, COLORREF clrBack, COLORREF clrFore, COLORREF clrFore2)
{
	char pszTemp[MAX_PATH];
	wsprintf(pszTemp, "%sBack", pszType);
	this->SetBackColor(GetRCColor(pszTemp,clrBack));

	wsprintf(pszTemp, "%sFore", pszType);
	this->foreColor1 = GetRCColor(pszTemp, clrFore);

	wsprintf(pszTemp, "%sFore2", pszType);
	this->foreColor2 = GetRCColor(pszTemp, clrFore2);
}

char* ReadCommand(char* pszRCLine)
{
	char buffer[BUFFER_SIZE];
	char* pszTemp;
	pszTemp = NULL;
	if ( GetRCString( pszRCLine, buffer, "", BUFFER_SIZE ) )
	{
		int nCommandSize = strlen(buffer);
		if(nCommandSize >0)
		{
			pszTemp =  (char*) malloc ((strlen(buffer)+1)*sizeof(char));
			strcpy(pszTemp, buffer);
		}
	}
	return pszTemp;
}

void Taskbar::ReadConfig()
{
	char buffer[MAX_PATH];

	// flash
	isTaskFlash = !(GetRCBool( "TaskbarDisableFlashing", TRUE));

	// skin settings
	noSkinShift = GetRCBool( "TaskbarNoSkinShift", TRUE );
	noTextShift = GetRCBool( "TaskbarNoFontShift", TRUE );

	skin = GetSkin("Taskbar");
	buttonSkin = GetSkin("TaskbarNormal");
	activeButtonSkin = GetSkin("TaskbarActive");
	minimizedSkin = GetSkin("TaskbarMinimized");
	flashSkin = GetSkin("TaskbarFlashing");

	skin->ReadSkinColor("Taskbar", RGB( 192, 192, 192 ), RGB( 255, 255, 255 ), RGB( 128, 128, 128 ));
	buttonSkin->ReadSkinColor("TaskbarNormal", skin->GetBackColor(), this->skin->foreColor1, this->skin->foreColor2);
	//20021227 they get inverted after(wards!!!!!
	activeButtonSkin->ReadSkinColor("TaskbarActive", skin->GetBackColor(), this->skin->foreColor1, this->skin->foreColor2);
	minimizedSkin->ReadSkinColor("TaskbarMinimized", skin->GetBackColor(), this->skin->foreColor1, this->skin->foreColor2);
	flashSkin->ReadSkinColor("TaskbarFlashing", RGB(0,0,255), this->skin->foreColor1, this->skin->foreColor2);

	//20030103
	GetRCString( "TaskbarRealFlashingUseSkin", m_pszFlashingUseSkin, "", 16 );
	//Get fonts

	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, 0);

	LOGFONT *lfDefault = &ncm.lfCaptionFont;

	//20021203
	/*general settings*/
	taskbarTextShadow = GetRCBool("TaskbarUseFontShadow", TRUE);
	textShadowColor = GetRCColor("TaskbarFontShadowColor", RGB(0,0,0));
	textShadowOffsetX = GetRCInt("TaskbarFontShadowOffsetX", 1);
	textShadowOffsetY = GetRCInt("TaskbarFontShadowOffsetY", 1);
	//20021229 - quick & dirty fix: why :S
	++textShadowOffsetY;
	/**/
	buttonSkin->Font.GetDefaultFont("TaskbarNormal", lfDefault);
	activeButtonSkin->Font.GetFont("TaskbarActive", lfDefault);
	minimizedSkin->Font.GetFont("TaskbarMinimized", lfDefault);
	flashSkin->Font.GetFont("TaskbarFlashing", lfDefault);

	buttonSkin->Font.ReadFontColor("TaskbarNormalFontColor", RGB( 0, 0, 0 ));
	activeButtonSkin->Font.ReadFontColor("TaskbarActiveFontColor", RGB( 0, 0, 0 ));
	minimizedSkin->Font.ReadFontColor("TaskbarMinimizedFontColor", RGB( 0, 0, 0 ));
	flashSkin->Font.ReadFontColor("TaskbarFlashingFontColor", RGB( 255, 255, 255 ));

	UINT nTextAlignH;
	UINT nTextAlignV;
	if ( GetRCString( "TaskbarHorizontalFontAlign", buffer, "", 16 ) )
	{
		if ( !stricmp( buffer, ".center" ) )
			nTextAlignH = DT_CENTER;
		else if ( !stricmp( buffer, ".right" ) )
			nTextAlignH = DT_RIGHT;
		else
			nTextAlignH = DT_LEFT;
	}
	else
		nTextAlignH = DT_LEFT;

	if ( GetRCString( "TaskbarVerticalFontAlign", buffer, "", 16 ) )
	{
		if ( !stricmp( buffer, ".center" ) )
			nTextAlignV = DT_VCENTER;
		else if ( !stricmp( buffer, ".bottom" ) )
			nTextAlignV = DT_BOTTOM;
		else
			nTextAlignV = DT_TOP;
	}
	else
		nTextAlignV = DT_VCENTER;
	
	buttonSkin->Font.GetTextAlignment("TaskbarNormal", nTextAlignH, nTextAlignV);
	activeButtonSkin->Font.GetTextAlignment("TaskbarActive", nTextAlignH, nTextAlignV);
	minimizedSkin->Font.GetTextAlignment("TaskbarMinimized", nTextAlignH, nTextAlignV);
	flashSkin->Font.GetTextAlignment("TaskbarFlashing", nTextAlignH, nTextAlignV);

	buttonSkin->Font.ReadShadowSettings("TaskbarNormal", taskbarTextShadow, textShadowColor, textShadowOffsetX, textShadowOffsetY);
	activeButtonSkin->Font.ReadShadowSettings("TaskbarActive", taskbarTextShadow, textShadowColor, textShadowOffsetX, textShadowOffsetY);
	minimizedSkin->Font.ReadShadowSettings("TaskbarMinimized", taskbarTextShadow, textShadowColor, textShadowOffsetX, textShadowOffsetY);
	flashSkin->Font.ReadShadowSettings("TaskbarFlashing", taskbarTextShadow, textShadowColor, textShadowOffsetX, textShadowOffsetY);
	//Get fonts end
	reallyHidden = GetRCBool("TaskbarHideTasks", TRUE);
	
	maxTaskWidth = GetRCInt( TEXT("TaskbarMaxTaskWidth"), SCREEN_WIDTH );

	GetRCRect("TaskbarBorder", borderLeft, borderRight, borderTop, borderBottom, 4, 4, 4, 4);
	GetRCRect("TaskbarButtonBorder", buttonBorderLeft, buttonBorderRight, buttonBorderTop, buttonBorderBottom, 4, 4, 4, 4);
	GetRCRect("TaskbarButtonFontBorder", buttonTextBorderLeft, buttonTextBorderRight, buttonTextBorderTop, buttonTextBorderBottom, 20, 0, 0, 0);

	spacing = GetRCInt( TEXT("TaskbarSpacing"), 3 );
	iconSize = GetRCInt( TEXT("TaskbarIconSize"), 16);

	showIcon = GetRCBoolDef("TaskbarIconShow", TRUE) ? true : false;

    /*mouse buttons on bar*/
	GetRCLine("TaskBarLButtonDown", taskbarLButtonDown, MAX_LINE_LENGTH, "!none");
	GetRCLine("TaskBarRButtonDown", taskbarRButtonDown, MAX_LINE_LENGTH, "!none");
	GetRCLine("TaskBarMButtonDown", taskbarMButtonDown, MAX_LINE_LENGTH, "!none");
	GetRCLine("TaskBarLButtonUp", taskbarLButtonUp, MAX_LINE_LENGTH, "!none");
	GetRCLine("TaskBarRButtonUp", taskbarRButtonUp, MAX_LINE_LENGTH, "!none");
	GetRCLine("TaskBarMButtonUp", taskbarMButtonUp, MAX_LINE_LENGTH, "!none");

	/*action on tiles*/
	TaskBarTileLButton = GetRCMouse("TaskbarTButtonL", MOUSE_SELECT);
	TaskBarTileMButton = GetRCMouse("TaskBarTButtonM", MOUSE_NONE);
	TaskBarTileRButton = GetRCMouse("TaskBarTButtonR", MOUSE_MENU);

	taskbarLines =  GetRCInt( TEXT("TaskbarLines"), 1 );
	if (taskbarLines <= 0)
	  taskbarLines = 1;

	timerRefresh =  GetRCInt( TEXT("TaskbarRefresh"), 500 );
    if (timerRefresh < 100)
		timerRefresh = 500;
	//20021230
	pszOnAddCommand = ReadCommand("TaskbarOnAdd");
	pszOnDelCommand = ReadCommand("TaskbarOnDel");
	pszOnFlashStartCommand = ReadCommand("TaskbarOnFlashStart");
	pszOnFlashStopCommand = ReadCommand("TaskbarOnFlashStop");

	//Taskbar Lists
    /*vector<string> HideList;*/
	GetRCList("*TaskbarNoFlash", NoFlashList);
	GetRCList("*TaskbarRemove", RemoveList);
	GetRCList("*TaskbarAdd", AddList);
	//GetRCList("*TaskbarNoScroll",NoScrollList);
	GetRCList("*TaskbarHide", HideList);

	iconX = GetRCInt( TEXT("TaskBarIconX"), 0);
	iconY = GetRCInt( TEXT("TaskBarIconY"), 0);

	showText = GetRCBoolDef("TaskbarFontShow", TRUE) ? true : false;

	if ( GetRCString( "TaskbarButtonDirection", buffer, "", 16 ) )
	{
		if ( !stricmp( buffer, ".left" ) )
			direction = DIRECTION_LEFT;
		else
			direction = DIRECTION_RIGHT;
	}
	else
		direction = DIRECTION_RIGHT;

	maxButtonCount = GetRCInt("TaskbarMaxButtonCount", SCREEN_WIDTH);
	if( maxButtonCount <= 0)
		maxButtonCount = SCREEN_WIDTH;
	useRealFlashing = (TRUE == GetRCBool("TaskbarUseRealFlashing", TRUE));
	//20021108
	switchOnHover = (TRUE == GetRCBool("TaskbarSwitchOnMouseHover", TRUE));
	//20021110
	if (GetRCString( "TaskbarUseToolTips", buffer, "", 16 ))
	{
		if ( !stricmp( buffer, "false" ) )
			useToolTips = false;
	}
	//useToolTips = GetRCBool("TaskbarUseToolTips", TRUE);
	minimizeOnHover = (TRUE == GetRCBool("TaskbarMinimizeOnMouseHover", TRUE));
	//20021121
	UseSaturation = (TRUE == GetRCBool("TaskbarUseSaturation", TRUE));
	UseHueing = (TRUE == GetRCBool("TaskbarUseHueing", TRUE));

	ColorHue = GetRCColor( "TaskbarHueColor", RGB( 125, 125, 125 ));
	HueIntensity = GetRCInt("TaskbarHueIntensity", 0);
	//20021231
	/*buttonSkin->HueColor = GetRCColor( "TaskbarNormalHueColor", taskbar->ColorHue );
	buttonSkin->HueIntensity = GetRCInt("TaskbarNormalHueIntensity", taskbar->HueIntensity);
	minimizedSkin->HueColor = GetRCColor( "TaskbarMinimizedHueColor", ColorHue );
	minimizedSkin->HueIntensity = GetRCInt("TaskbarMinimizedHueIntensity", HueIntensity);
	activeButtonSkin->HueColor = GetRCColor( "TaskbarSelectedHueColor", ColorHue );
	activeButtonSkin->HueIntensity = GetRCInt("TaskbarSelectedHueIntensity", HueIntensity);
	flashSkin->HueColor = GetRCColor( "TaskbarFlashingHueColor", ColorHue );
	flashSkin->HueIntensity = GetRCInt("TaskbarFlashingHueIntensity", HueIntensity);*/

	NormalColorHue = GetRCColor( "TaskbarNormalHueColor", taskbar->ColorHue );
	NormalHueIntensity = GetRCInt("TaskbarNormalHueIntensity", taskbar->HueIntensity);
	MinimizedColorHue = GetRCColor( "TaskbarMinimizedHueColor", ColorHue );
	MinimizedHueIntensity = GetRCInt("TaskbarMinimizedHueIntensity", HueIntensity);
	SelectedColorHue = GetRCColor( "TaskbarSelectedHueColor", ColorHue );
	SelectedHueIntensity = GetRCInt("TaskbarSelectedHueIntensity", HueIntensity);
	FlashingColorHue = GetRCColor( "TaskbarFlashingHueColor", ColorHue );
	FlashingHueIntensity = GetRCInt("TaskbarFlashingHueIntensity", HueIntensity);

	SaturationIntensity =  GetRCInt("TaskbarSaturationIntensity", 0);
	//20021231
	/*buttonSkin->SaturationIntensity = GetRCInt("TaskbarNormalSaturationIntensity", SaturationIntensity);
	minimizedSkin->SaturationIntensity = GetRCInt("TaskbarMinimizedSaturationIntensity", SaturationIntensity);
	activeButtonSkin->SaturationIntensity = GetRCInt("TaskbarSelectedSaturationIntensity", SaturationIntensity);
	flashSkin->SaturationIntensity = GetRCInt("TaskbarFlashingSaturationIntensity", SaturationIntensity);*/
	NormalSaturationIntensity = GetRCInt("TaskbarNormalSaturationIntensity", SaturationIntensity);
	MinimizedSaturationIntensity = GetRCInt("TaskbarMinimizedSaturationIntensity", SaturationIntensity);
	SelectedSaturationIntensity = GetRCInt("TaskbarSelectedSaturationIntensity", SaturationIntensity);
	FlashingSaturationIntensity = GetRCInt("TaskbarFlashingSaturationIntensity", SaturationIntensity);
}

void Taskbar::Resize(int x, int y){
	MoveWindow( taskbar->hWnd ,  taskbar->taskbarX, taskbar->taskbarY, taskbar->width + x,taskbar->height + y, TRUE);
}

void Taskbar::Layout()
{
	//20030109
	nFlashingCount = 0;
	inCriticalProcess = true;
	int buttonCount = buttons.size();
	if( taskbar->reallyHidden )
	{
		for (TaskbarButtonIterator it = buttons.begin(); it != buttons.end(); ++it)
			if ( IsOnTaskbarList((*it)->hTask , HideList) )
				--buttonCount;
	}

    //on ne doit montrer qu'une partie des boutons
	if ( buttonCount > maxButtonCount)
	    buttonCount = maxButtonCount;

	if (buttonCount <= 0)
	{
		InvalidateRect( hWnd, NULL, FALSE );
		inCriticalProcess = false;
		return ;
	}

	int availableWidth = width - borderLeft - borderRight;
	availableWidth = max( availableWidth, 0 );  // cannot be less than zero

	if ( buttonCount > 1 )
	{
		availableWidth = availableWidth - (buttonCount - 1) * spacing;
		availableWidth = max( availableWidth, 0 );
	}

	int widthPerButton = min(availableWidth / buttonCount,maxTaskWidth);

	int buttonHeight = (height - borderTop - borderBottom - (taskbarLines - 1) * spacing) / taskbarLines;

	int lines =0;
	int linebuttonCount;

    if(taskbarLines>1){
		if (!(buttonCount%taskbarLines))
			linebuttonCount = ((buttonCount) / taskbarLines);
		else
			linebuttonCount = ((buttonCount) / taskbarLines) + 1;
	}
	else
	  linebuttonCount = buttonCount;

    int error = availableWidth % linebuttonCount;
    int errorDone = 0;
    widthPerButton = min(availableWidth / linebuttonCount,maxTaskWidth);

	//vers la droite
	int x;
	if(taskbar->direction == DIRECTION_RIGHT)
		x = borderLeft;
	else
		x = taskbar->width - borderRight - widthPerButton;

	int y = borderTop;

	int buttonNum = 0;
	// set placement for each button
	for (TaskbarButtonIterator it = buttons.begin(); it != buttons.end(); ++it)
	{
		TaskbarButton *button = *it;

		if((taskbar->reallyHidden && !IsOnTaskbarList((*it)->hTask , HideList)) || !taskbar->reallyHidden){
			if( ( buttonNum >= buttonCountStart ) && ( buttonNum - buttonCountStart < maxButtonCount ) ){
				if ( error > 0 )
				{
					++lines;
					if((lines % taskbarLines) == 0){
			  			error--;
				  		errorDone++;
					}
 		    		button->Move( x , y, widthPerButton + 1, buttonHeight );

					if(taskbar->direction == DIRECTION_RIGHT)
						x = borderLeft + (lines / taskbarLines) * widthPerButton + (lines / taskbarLines) * spacing + errorDone;
					else 
						x = taskbar->width - borderRight - (lines / taskbarLines + 1 ) * widthPerButton - (lines / taskbarLines) * spacing - errorDone;
	            	y = borderTop + (lines % taskbarLines) * buttonHeight + (lines % taskbarLines) * spacing;
				}
				else
				{
					button->Move( x , y, widthPerButton, buttonHeight );
					++lines;

					if(taskbar->direction == DIRECTION_RIGHT)
						x = borderLeft + (lines / taskbarLines) * widthPerButton + (lines / taskbarLines) * spacing + errorDone;
					else
						x = taskbar->width - borderRight - (lines / taskbarLines + 1) * widthPerButton - (lines / taskbarLines) * spacing - errorDone;
					y = borderTop + (lines % taskbarLines) * buttonHeight + (lines % taskbarLines) * spacing;
				}
			}
			else
				button->Move( x , y, 0, 0);
			++buttonNum;
		}
		else
			button->Move( x , y, 0, 0);
	}
	InvalidateRect( hWnd, NULL, FALSE );
	inCriticalProcess = false;
}



void Taskbar::SetWindowPosition()
{
	/*if(taskbarY == -1)
	{
		SetWindowPos( hWnd, NULL, taskbarX, SCREEN_HEIGHT - neededHeight, screenWidth, neededHeight, SWP_NOACTIVATE | SWP_NOZORDER );
	}
	else
	{*/
		SetWindowPos( hWnd, NULL, taskbarX, taskbarY, screenWidth, neededHeight, SWP_NOACTIVATE | SWP_NOZORDER );
	//}
}

TaskbarButton *Taskbar::SearchForButtonByHandle( HWND hWnd )
{
	for (TaskbarButtonIterator it = buttons.begin(); it != buttons.end(); ++it)
	{
		if ( hWnd == (*it)->hTask  )
			return (*it);
	}

	return NULL;
}

void Taskbar::OnActivate( BOOL becomingActive )
{
	//what's the purpose of active?
	active = becomingActive;
}

void Taskbar::OnDisplayChange()
{
  // ....
}

void Taskbar::OnGetMinRect( HWND hWnd, RECT *rectangle )//CPU 20020501
{
	TaskbarButton *button;
	button = SearchForButtonByHandle(hWnd);
}

void Taskbar::OnLButtonDown( int x, int y )
{
	TaskbarButton *button;

	if ( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if ( button )
	{
		//20021125
		button->OnButtonDown( x, y, taskbar->TaskBarTileLButton);
	}
	else
	{
		LSExecute(NULL, Taskbar::taskbarLButtonDown, NULL);
	}
}

void Taskbar::OnMButtonDown( int x, int y )
{
	TaskbarButton *button;

	if ( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if ( button )
	{
		//20021125
		button->OnButtonDown( x, y, taskbar->TaskBarTileMButton);
	}
	else
	{
		LSExecute(NULL, Taskbar::taskbarMButtonDown, NULL);
	}
}

void Taskbar::OnMButtonUp( int x, int y )
{
	TaskbarButton *button;

	if ( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if ( button )
	{
		//20021125
		button->OnButtonUp( x, y, taskbar->TaskBarTileMButton);		
	}
	else
	{
		LSExecute(NULL, Taskbar::taskbarMButtonUp, NULL);
	}

}


void Taskbar::OnLButtonUp( int x, int y )
{
	TaskbarButton *button;

	if ( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if ( button )
	{
		//20021125
		button->OnButtonUp( x, y, taskbar->TaskBarTileLButton);		
	}

	else{
		if( taskbar->lastActive )
		{
			taskbar->lastActive = NULL;
		}
		LSExecute(NULL, Taskbar::taskbarLButtonUp, NULL);
	}
}

void Taskbar::OnMouseMove( int x, int y )
{
	mouseOver = TRUE;

	TaskbarButton *button;

	if ( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if ( button )
	{
		button->OnMouseMove( x, y );
		return ;
	}
}

void Taskbar::OnPaint( HDC hDC )
{
	HDC hdcBuffer;
	HBITMAP hbmBuffer;
	HBITMAP hbmTemp;

	hdcBuffer = CreateCompatibleDC( hDC );
	hbmBuffer = CreateCompatibleBitmap( hDC, width, height );
	hbmTemp = (HBITMAP) SelectObject( hdcBuffer, hbmBuffer );

	//if ( !skin )
	if ( skin != NULL && !skin->IsValid() )
	{
		RECT r;
		GetClientRect( hWnd, &r );

		//if ( !msTaskbar )
		{
			// simple 3D frame
			HBRUSH hbrBack;
			HBRUSH hbrOld;
			HPEN hpnFore;
			HPEN hpnTemp;

			//hbrBack = (HBRUSH)GetStockObject(NULL_BRUSH);
			hbrBack = CreateSolidBrush( skin->GetBackColor() );
			hbrOld = (HBRUSH)SelectObject(hDC,hbrBack);
			FillRect( hdcBuffer, &r, hbrBack );
			DeleteObject( hbrBack );

			hpnFore = CreatePen( PS_SOLID, 1, skin->foreColor2 );
			hpnTemp = (HPEN) SelectObject( hdcBuffer, hpnFore );

			MoveToEx( hdcBuffer, r.left, r.bottom - 1, NULL );
			LineTo( hdcBuffer, r.right - 1, r.bottom - 1 );
			LineTo( hdcBuffer, r.right - 1, r.top );

			SelectObject( hdcBuffer, hpnTemp );
			DeleteObject( hpnFore );

			hpnFore = CreatePen( PS_SOLID, 1, skin->foreColor1 );
			hpnTemp = (HPEN) SelectObject( hdcBuffer, hpnFore );

			LineTo( hdcBuffer, r.left, r.top );
			LineTo( hdcBuffer, r.left, r.bottom - 1 );

			SelectObject( hdcBuffer, hpnTemp );
			DeleteObject( hpnFore );
			//20021125 needed ?
			DeleteObject( hpnTemp );

		}
		/*else
		{
			// MS taskbar style
			DrawEdge( hdcBuffer, &r, EDGE_RAISED, BF_RECT | BF_MIDDLE );
		}*/
	}
	else if (skin != NULL)
	{
		// skin
		skin->Apply( hdcBuffer, 0, 0, width, height );
	}

	int buttonNum = 0;
	for (TaskbarButtonIterator it = buttons.begin(); it != buttons.end(); ++it)
	{
		if( ( buttonNum >= buttonCountStart ) && ( buttonNum - buttonCountStart < maxButtonCount ) )
		{
			if ((taskbar->reallyHidden ) && (!IsOnTaskbarList((*it)->hTask , HideList)))
				(*it)->OnPaint( hdcBuffer );
			else if (!taskbar->reallyHidden )
				(*it)->OnPaint( hdcBuffer );
		}
		++buttonNum;
	}

	//20021125 - transp
	BitBlt( hDC, 0, 0, width, height, hdcBuffer, 0, 0, SRCCOPY );
	//TransparentBltLS( hDC, 0, 0, width, height, hdcBuffer, 0, 0, RGB( 255, 0, 255 ) );

	SelectObject( hDC, hbmTemp );
	DeleteObject( hDC);
	DeleteDC( hDC );
	//20021125 needed ?
	DeleteObject( hbmTemp );
	DeleteObject( hdcBuffer );
	DeleteObject( hbmBuffer );
	DeleteDC( hdcBuffer );
}

// OnRedraw
//

void Taskbar::OnRedraw( HWND hWnd, BOOL fFlash )
{
	TaskbarButton *button = SearchForButtonByHandle(hWnd);

	if (button)
	{
		if(GetActiveWindow() != button->hTask)
		{
			button->SetFlashing(fFlash);
		}
		else
		{
			if(useRealFlashing)
			{
				if(fFlash)
					button->flashingFlashSkin = !(button->flashingFlashSkin) ; //200206111
				else
					button->flashingFlashSkin = true;
			}
		}
		button->OnUpdate(TRUE);
	}
}

void Taskbar::OnRButtonDown( int x, int y )
{
	TaskbarButton *button;

	if ( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if ( button )
	{
		//20021125
		button->OnButtonDown( x, y, taskbar->TaskBarTileRButton);
	}

	else
      LSExecute(NULL, this->taskbarRButtonDown, NULL);

}

void Taskbar::OnRButtonUp( int x, int y )
{
	TaskbarButton *button;

	if ( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if ( button )
	{
		//20021125
		button->OnButtonUp( x, y, taskbar->TaskBarTileRButton);
	}
	else
      LSExecute(NULL, this->taskbarRButtonUp, NULL);
}

void Taskbar::ComputeNeededHeight()
{
	TEXTMETRIC tm;
	buttonSkin->Font.GetTextMetrics(tm);
    
	if(taskbarHeight <= 0)
	{
	  neededHeight = max( (const int)(tm.tmHeight + tm.tmExternalLeading), iconSize );
  	  neededHeight = neededHeight + buttonBorderTop + buttonBorderBottom;
	  neededHeight = neededHeight + borderTop + borderBottom;
	}
	else
      neededHeight = taskbarHeight;
}

void Taskbar::OnSize( int widthP, int heightP )
{
	height = heightP;
	width = widthP;

	Layout();
}

//20030120 -> change name
int Taskbar::CountState(int nState)
{
	int buttonNum = 0;
	for (TaskbarButtonIterator it = buttons.begin(); it != buttons.end(); ++it)
	{
		if( (*it)->getCurrentState(TRUE) == nState )
		{
			//LSLogPrintf(0, __FILE__, "%s", (*it)->GetWindowCaption() );
			if((*it)->hTask != GetActiveWindow())
			++buttonNum;
		}
	}
	return buttonNum;
}

void Taskbar::OnTimerUpdate(int whichTimer)
{
	//20030120
	nFlashingCount = CountState(STATE_FLASHING);
	//LSLogPrintf(0, __FILE__, "%d", nFlashingCount);
	if( nFlashingCount != nOldFlashingCount )
	{
		if( nFlashingCount > 0 )
		{
			if(pszOnFlashStartCommand)
			{
				LSExecute(NULL, pszOnFlashStartCommand, NULL);
			}
		}
		else
		{
			if(pszOnFlashStopCommand)
			{
				LSExecute(NULL, pszOnFlashStopCommand, NULL);
			}
		}
		nOldFlashingCount = nFlashingCount;
	}

	if(!inCriticalProcess && visible)
	{
		for (TaskbarButtonIterator it = buttons.begin(); it != buttons.end(); ++it)
		{
			(*it)->OnUpdate((*it)->getCurrentState(true) != (*it)->currentState);
		}
	}
}

//fFullScreen, really ????
void Taskbar::OnWindowActivated( HWND hApplication, BOOL fFullScreen ) //win95?
{
	TaskbarButton *button = SearchForButtonByHandle(hWnd);

	if (button)
	{
		button->flashingFlashSkin = false;
		//20030120
		button->SetFlashing(FALSE);
		button->currentState = button->getCurrentState(FALSE);
    }	
	taskbar->Layout();
}

void Taskbar::OnRefresh(  )
{
	OnRefreshUnload();
	OnRefreshReload();
}

void Taskbar::OnWindowCreated( HWND hTask )
{
    if (SearchForButtonByHandle(hTask) == NULL && !IsOnTaskbarList(hTask, RemoveList))
	{
		TaskbarButton *button = new TaskbarButton( *this, hTask );
		button->SetSkin(buttonSkin);
		button->SetActiveSkin(activeButtonSkin);
		button->SetFlashSkin(flashSkin);
		button->SetMinimizedSkin(minimizedSkin);

		buttons.push_back( button );
		//20021230
		OnButtonAdded();
	}
	Layout();
}

void Taskbar::OnWindowDestroyed( HWND hTask )
{
	for (TaskbarButtonIterator i = buttons.begin(); i != buttons.end(); ++i )
	{
		TaskbarButton *button = *i;

		if ( button->hTask  == hTask )
		{
			//LSLogPrintf(0, __FILE__, "%s",button->GetWindowCaption());
			delete button;
			buttons.erase( i );

			if(taskbar->buttonCountStart>0)
				taskbar->buttonCountStart -=1;
			//20021230
			//trouble with VWM's ... windows get removed when they are on other desks
			//and VWMHideTaskOnSwitch is on
			OnButtonRemoved();
			return ;
		}
	}
}

BOOL Taskbar::OnWindowMessage( UINT nMessage, WPARAM wParam, LPARAM lParam, LRESULT &lResult )
{
	lResult = 0;

	// relay mouse messages to tooltips control
	if(useToolTips)//20021108
	if ( nMessage >= WM_MOUSEFIRST && nMessage <= WM_MOUSELAST )
	{
		/*//20021231
		if(!WindowManager.IsActive(gethWnd()))
		{
			SwitchToThisWindow( gethWnd(), SW_NORMAL );
		}*/
		
		MSG msg;

		msg.hwnd = hWnd;
		msg.message = nMessage;
		msg.wParam = wParam;
		msg.lParam = lParam;

		SendMessage( hToolTips, TTM_RELAYEVENT, 0, (LPARAM) &msg );
		//20021126 sometimes, the buttons wouldn't repaint correctly because of the tooltips, fixed (blkhawk)
		//SetWindowPos( hToolTips, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	}

	switch ( nMessage )
	{
		case WM_DROPFILES:
		{
			POINT pt;
			HDROP hDrop = (HDROP)wParam;
			DragQueryPoint(hDrop, &pt);
			//Change in tasks.dll
			//if(!SendMessage(ButtonAtPoint(pt.x, pt.y)->hTask, nMessage, (WPARAM)hDrop, (LPARAM)0));
			//20030123
			//if(!PostMessage((HWND)ButtonAtPoint(pt.x, pt.y)->hTask, nMessage, (WPARAM)hDrop, (LPARAM)0));
			if(!SendMessage((HWND)ButtonAtPoint(pt.x, pt.y)->hTask, nMessage, (WPARAM)hDrop, (LPARAM)0));
			WindowManager.RestoreWindow((HWND)ButtonAtPoint(pt.x, pt.y)->hTask);
			DragFinish(hDrop);

		}
		case WM_CLOSE:
		{
			return TRUE;
		}
		/*case LM_BRINGTOFRONT:
		{
			OnWindowActivated( (HWND) wParam, FALSE );
			return TRUE;
		}*/

		case LM_LSSELECT:
		{
			OnWindowActivated( (HWND) wParam, FALSE );
			return TRUE;
		}

		case LM_GETMINRECT:
		{
			//20021116
			//OnGetMinRect( (HWND) wParam, (RECT *) lParam );
			//LSLogPrintf(0,"taskbar3", "LM_GETMINRECT: %d", (HWND) wParam);
			return TRUE;
		}

		case LM_REDRAW:
		{
			OnRedraw( (HWND) wParam, (BOOL) lParam ); 
			//LSLogPrintf(0,__FILE__, "Wallaper change");
			return TRUE;
		}

		case LM_WINDOWACTIVATED:
		{
			OnWindowActivated( (HWND) wParam, (BOOL) lParam );
			TaskbarButton *button = SearchForButtonByHandle(hWnd);
			if (button)
			{
				button->SetFlashing(FALSE);
			}
			return TRUE;
		}

		case LM_WINDOWCREATED:
		{
			OnWindowCreated( (HWND) wParam );
			return TRUE;
		}

		case LM_WINDOWDESTROYED:
		{
			OnWindowDestroyed( (HWND) wParam );
			Layout();
			return TRUE;
		}

		case LM_REFRESH:
		{
			OnRefresh();
			return TRUE;
		}

		case LM_GETREVID:
		{
			char* buf = (char*)lParam;
			strcpy(buf, aboutStr);
			return strlen(buf);
		}

		case WM_DISPLAYCHANGE:
		{
			OnDisplayChange();
			return TRUE;
		}

		case WM_LBUTTONDOWN:
		{
			OnLButtonDown( LOWORD(lParam), HIWORD(lParam));
			return TRUE;
		}
		case WM_LBUTTONUP:
		{
			OnLButtonUp( LOWORD(lParam), HIWORD(lParam));
			return TRUE;
		}
		case WM_MBUTTONDOWN:
		{
			OnMButtonDown( LOWORD(lParam), HIWORD(lParam));
			return TRUE;
		}
		case WM_MOUSEMOVE:
		{
			OnMouseMove( LOWORD( lParam ), HIWORD( lParam ) );
			return TRUE;
		}
	
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hDC;

			hDC = BeginPaint( hWnd, &ps );
			OnPaint( hDC );
			EndPaint( hWnd, &ps );

			return TRUE;
		}

		case WM_RBUTTONDOWN:
		{
			OnRButtonDown( (int) (short) LOWORD( lParam ), (int) (short) HIWORD( lParam ) );
			return TRUE;
		}

		case WM_RBUTTONUP:
		{
			OnRButtonUp( (int) (short) LOWORD( lParam ), (int) (short) HIWORD( lParam ) );
			return TRUE;
		}
		case WM_SIZE:
		{
			OnSize( (int) (short) LOWORD( lParam ), (int) (short) HIWORD( lParam ) );
			return TRUE;
		}
		case WM_TIMER:
		{
			switch ( wParam )
			{
				/*case TIMER_AUTOHIDE:
				{
					OnTimerAutoHide();
					return TRUE;
				}*/
				
				case TIMER_UPDATE:
				{
					if(g_nButtonsAddedAtStartup > 0)
					{
						for(int nI = 0; nI < g_nButtonsAddedAtStartup;++nI)
						{
							OnButtonAdded();
						}
						g_nButtonsAddedAtStartup = 0;
					}
					OnTimerUpdate(TIMER_UPDATE);
					return TRUE;
				}
				/*case TIMER_UPDATE_SCROLL:
				{
					OnTimerUpdate(TIMER_UPDATE_SCROLL);
					return TRUE;
				}*/
			}

			return FALSE;
		}
	}

	return FALSE;
}
void Taskbar::OnButtonAdded()
{
	if(pszOnAddCommand)
	{
		LSExecute(NULL, pszOnAddCommand, NULL);
	}
	//buttons.size()
}

void Taskbar::OnButtonRemoved()
{
	if(pszOnDelCommand)
	{
		LSExecute(NULL, pszOnDelCommand, NULL);
	}
	//buttons.size()
}


BOOL WINAPI Taskbar::EnumWindowsProc(HWND hWnd, LPARAM lParam)
{
	Taskbar *taskbar = (Taskbar *) lParam;
	if (taskbar && IsAppWindow(hWnd))
	{
		TaskbarButton *button = taskbar->SearchForButtonByHandle(hWnd);

		if (button == 0)
		{
			button = new TaskbarButton(*taskbar, hWnd);

			button->SetActiveSkin(taskbar->activeButtonSkin);
			button->SetSkin(taskbar->buttonSkin);
			button->SetFlashSkin(taskbar->flashSkin);
			button->SetMinimizedSkin(taskbar->minimizedSkin);

			taskbar->buttons.push_back(button);
			taskbar->listChanged = true;
			//this doesn't work if we try to grow ... gonna hack :)
			//taskbar->OnButtonAdded();
			++g_nButtonsAddedAtStartup;
		}
	}
	return TRUE;
}

LRESULT WINAPI Taskbar::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	Taskbar *taskbar = (Taskbar *) GetWindowLong(hWnd, 0);

	if (message == WM_NCCREATE)
	{
		LPCREATESTRUCT pcs = (LPCREATESTRUCT) lParam;
		taskbar = (Taskbar *) pcs->lpCreateParams;

		taskbar->hWnd = hWnd;
		SetWindowLong(hWnd, 0, (LONG) taskbar);
	}

	if (taskbar)
	{
		LRESULT lResult;

		if (taskbar->OnWindowMessage(message, wParam, lParam, lResult))
			return lResult;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}
