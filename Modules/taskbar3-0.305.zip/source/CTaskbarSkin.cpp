/*#include "bangs.h"
#include "taskbar.h"
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/macros.h"

CTaskbarSkin::CTaskbarSkin()
{
	CTaskbarSkin(NULL, NULL, NULL);
}

CTaskbarSkin::CTaskbarSkin( LPCSTR pszLeft, LPCSTR pszMiddle, LPCSTR pszRight )
: bStretch(TRUE), m_crBackColor(0), hbmLeft(NULL), hbmMiddle(NULL), hbmRight(NULL)
{
	//if(pszLeft && pszRight && pszMiddle)
	if ( pszLeft && pszLeft[0] )
	{
		hbmLeft = LoadLSImage( pszLeft, NULL );
		GetLSBitmapSize( hbmLeft, &leftW, &leftH );
	}

	if ( pszMiddle && pszMiddle[0] )
	{
		hbmMiddle = LoadLSImage( pszMiddle, NULL );
		GetLSBitmapSize( hbmMiddle, &middleW, &middleH );
	}

	if ( pszRight && pszRight[0] )
	{
		hbmRight = LoadLSImage( pszRight, NULL );
		GetLSBitmapSize( hbmRight, &rightW, &rightH );
	}
}

CTaskbarSkin::~CTaskbarSkin()
{
	if ( hbmLeft )
		DeleteObject( hbmLeft );

	if ( hbmMiddle )
		DeleteObject( hbmMiddle );

	if ( hbmRight )
		DeleteObject( hbmRight );
}

void CTaskbarSkin::Apply( HDC hDC, int x, int y, int width, int height )
{
	HDC hdcBuffer;
	HDC hdcMem;

	hdcBuffer = CreateCompatibleDC( hDC );
	hdcMem = CreateCompatibleDC( hDC );

	SetStretchBltMode( hdcBuffer, STRETCH_DELETESCANS );

	if ( this->IsValid() && width > 0 )
	{
		HBITMAP hbmBuffer;
		HGDIOBJ hgoBuffer;
		HGDIOBJ hgoMem;
		int widthLeft = width;

		hbmBuffer = CreateCompatibleBitmap( hDC, width, height );
		hgoBuffer = SelectObject( hdcBuffer, hbmBuffer );

		hgoMem = SelectObject( hdcMem, hbmLeft );

		if (stretch)
		{
			StretchBlt( hdcBuffer, 0, 0, min( widthLeft, leftW ), height, hdcMem, 0, 0, leftW, leftH, SRCCOPY );
		}
		else
		{
			BitBlt(hdcBuffer, 0, 0, min(widthLeft, leftW), height, hdcMem, 0, 0, SRCCOPY);
		}

		SelectObject( hdcMem, hgoMem );
		widthLeft = widthLeft - leftW;

		hgoMem = SelectObject( hdcMem, hbmRight );

		if (stretch)
		{
			StretchBlt( hdcBuffer, width - rightW, 0, min( widthLeft, rightW ), height, hdcMem, 0, 0, rightW, rightH, SRCCOPY );
		}
		else
		{
			BitBlt(hdcBuffer, width - rightW, 0, min(widthLeft, rightW), height, hdcMem, 0, 0, SRCCOPY);
		}

		SelectObject( hdcMem, hgoMem );
		widthLeft = widthLeft - rightW;
  
		hgoMem = SelectObject( hdcMem, hbmMiddle );

		if (stretch)
		{
			StretchBlt( hdcBuffer, hbmLeft ? leftW : 0, 0, widthLeft, height,
			            hdcMem, 0, 0, middleW, middleH, SRCCOPY );
		}
		else
		{
			BitBlt(hdcBuffer, hbmLeft ? leftW : 0, 0, widthLeft, height, hdcMem, 0, 0, SRCCOPY);
		}

		SelectObject( hdcMem, hgoMem );
		SelectObject( hdcBuffer, hgoBuffer );
		DeleteObject( hbmBuffer );
		DeleteObject( hgoBuffer );
		DeleteObject( hgoMem );
	}
	else
	{
		RECT r;
		HBRUSH hbrBack;

		r.top = 0;
		r.left = 0;
		r.bottom = height;
		r.right = width;

		hbrBack = CreateSolidBrush( m_crBackColor );
		FillRect( hdcMem, &r, hbrBack );
		FillRect( hdcBuffer, &r, hbrBack );
		DeleteObject( hbrBack );
	}

	TransparentBltLS( hDC, x, y, width, height, hdcBuffer, 0, 0, RGB( 255, 0, 255 ) );

	DeleteDC( hdcBuffer );
	DeleteDC( hdcMem );
}


void CTaskbarSkin::SetStretch(BOOL s)
{
	stretch = s;
}

BOOL CTaskbarSkin::IsStretched()
{
	return bStretch;
}

CTaskbarSkin* TaskbarButton::GetSkin()
{
	return skin;
}

CTaskbarSkin* TaskbarButton::GetActiveSkin()
{
	return activeskin;
}

CTaskbarSkin* TaskbarButton::GetFlashSkin()
{
	return flashskin;
}

CTaskbarSkin* TaskbarButton::GetMinimizedSkin()
{
	return minimizedskin;
}

bool CTaskbarSkin::IsValid()
{
	if(hbmLeft == NULL)
		return false;
	if(hbmMiddle == NULL)
		return false;
	if(hbmRight == NULL)
		return false;
	return true;
}
*/