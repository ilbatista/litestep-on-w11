/*#ifndef __CTASKBARSKIN_H
#define __CTASKBARSKIN_H

#include <string>
#include <vector>
#include "../current/lsapi/lsapi.h"
#include "taskbar.h"
#include "utilities.h"
#include "bangs.h"
#include "CLsFont.h"
#include "AggressiveOptimize.h"
using namespace std;

class CTaskbarSkin
{
private:
	HBITMAP hbmLeft;
	int nLeftH;
	int nLeftW;

	HBITMAP hbmMiddle;
	int nMiddleH;
	int nMiddleW;

	HBITMAP hbmRight;
	int nRightH;
	int nRightW;

public:
	COLORREF m_crBackColor;

	CLsFont clsFont;

	BOOL bStretch;
	BOOL IsStretched();
	void SetStretch(BOOL s);

	CTaskbarSkin();
	CTaskbarSkin( LPCSTR, LPCSTR, LPCSTR );
	virtual ~CTaskbarSkin();

	void Apply( HDC, int, int, int, int );
	bool IsValid();
};

#endif*/