#ifndef __UTILITIES_H
#define __UTILITIES_H

#include <string>
#include <vector>
#include "../current/lsapi/lsapi.h"
#include "taskbar.h"
#include "bangs.h"
#include "AggressiveOptimize.h"
using namespace std;

void StringToInts(const char *, int *, int *);
BOOL IsSubString(string, string);
BOOL IsOnTaskbarList(HWND , vector<string> );
HICON GetIconFromWindow( HWND, BOOL );
BOOL IsAppWindow( HWND );
HWND GetParentSettings( bool );

#endif
