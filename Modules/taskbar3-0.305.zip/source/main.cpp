/*
- Addded [jesus_mjjjg / 20003-02-08 (0:37)]
  !TaskbarExecute ....
*/
#include <algorithm>
#include "common.h"
#include <commctrl.h>
#include <shellapi.h>
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/macros.h"
#include "utilities.h"
#include "taskbar.h"
#include "bangs.h"

#include "AggressiveOptimize.h"

extern Taskbar *taskbar;

extern vector<string> NoFlashList;
extern vector<string> RemoveList;
extern vector<string> HideList;
extern vector<string> AddList;
extern vector<string> NoScrollList;

int initModuleEx(HWND hParent, HINSTANCE hInstance, LPCSTR pszPath)
{
	InitCommonControls();

	SwitchToThisWindow = (void (WINAPI *)(HWND, int)) GetProcAddress(
	                         GetModuleHandle("USER32.DLL"),
	                         "SwitchToThisWindow");

	taskbar = new Taskbar;
	taskbar->OnLoad(hInstance);

	AddBangCommand("!TaskbarHide", hideBangCommand);
	AddBangCommand("!TaskbarToggle", toggleBangCommand);
	AddBangCommand("!TaskbarShow", showBangCommand);

	AddBangCommand("!TaskbarSize", sizeBangCommand);
	AddBangCommand("!TaskbarMove", moveBangCommand);

	AddBangCommand("!TaskbarBoxHook", BangBoxHook);
	AddBangCommand("!TaskbarLines", linesBangCommand);
	AddBangCommand("!TaskbarShrink", shrinkBangCommand);
	AddBangCommand("!TaskbarGrow", growBangCommand);
	AddBangCommand("!TaskbarMoveBy", moveByBangCommand);

	/*AddBangCommand("!TaskbarScrollFlashOn", scrollFlashOnByBangCommand);
	AddBangCommand("!TaskbarScrollFlashOff", scrollFlashOffByBangCommand);
	AddBangCommand("!TaskbarScrollFlashToggle", scrollFlashToggleByBangCommand);*/

	AddBangCommand("!TaskbarToggleTasks", hideTasksToggleBangCommand);
	AddBangCommand("!TaskbarHideTasks", hideTasksOnBangCommand);
	AddBangCommand("!TaskbarShowTasks", hideTasksOffBangCommand);

	AddBangCommand("!TaskbarSwitch", taskbarSwitchBangCommand);
	AddBangCommand("!TaskbarShowPart", taskbarShowPartBangCommand);
	AddBangCommand("!TaskbarMaxTasks", maxTasksBangCommand);
	//20021108
	AddBangCommand("!TaskbarRefresh", refreshBangCommand);
	AddBangCommand("!TaskbarExecute", executeBangCommand);
	return 0;
}

void quitModule(HINSTANCE hInstance)
{
	RemoveBangCommand("!TaskbarHide");
	RemoveBangCommand("!TaskbarToggle");
	RemoveBangCommand("!TaskbarShow");

	RemoveBangCommand("!TaskbarSize");
	RemoveBangCommand("!TaskbarMove");
	
	RemoveBangCommand("!TaskbarBoxHook");
    RemoveBangCommand("!TaskbarLines");

	RemoveBangCommand("!TaskbarShrink");
	RemoveBangCommand("!TaskbarGrow");

	RemoveBangCommand("!TaskbarMoveBy");

	RemoveBangCommand("!TaskbarScrollFlashOn");
	RemoveBangCommand("!TaskbarScrollFlashOff");
	RemoveBangCommand("!TaskbarScrollFlashToggle");

	RemoveBangCommand("!TaskbarToggleTasks");
	RemoveBangCommand("!TaskbarHideTasks");
	RemoveBangCommand("!TaskbarShowTasks");

	RemoveBangCommand("!TaskbarSwitch");
	RemoveBangCommand("!TaskbarShowPart");
	RemoveBangCommand("!TaskbarMaxTasks");
	//20021108
	RemoveBangCommand("!TaskbarRefresh");

	RemoveBangCommand("!TaskbarExecute");

	taskbar->OnUnload();
	delete taskbar;
}

extern "C" int WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
		DisableThreadLibraryCalls(hInstance);

	return 1;
}