/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __TASKBAR_H
#define __TASKBAR_H

#include <string>
#include <vector>
#include "../current/lsapi/lsapi.h"
#include "taskbarbutton.h"
#include "taskbarskin.h"
#include "utilities.h"
#include "bangs.h"
#include "AggressiveOptimize.h"
using namespace std;

#define BUFFER_SIZE		1024

#define WC_TASKBAR		"TaskbarLS"

/*#define EDGE_BOTTOM		0
#define EDGE_TOP		1*/

#define TIMER_UPDATE		1
#define TIMER_UPDATE_SCROLL	2

#define MOUSE_NONE		0
#define MOUSE_SELECT	1
#define MOUSE_MENU		2
#define MOUSE_CLOSE		3
#define MOUSE_CLOSE2	4
#define MOUSE_ONTOP		5
#define MOUSE_SHADE		6

#define DIRECTION_RIGHT	0
#define DIRECTION_LEFT	1

#define STATE_UNKNOWN	1
#define STATE_NORMAL	2
#define STATE_SELECTED	4
#define STATE_MINIMIZED	8
#define STATE_FLASHING	16

#define WC_SHELLDESKTOP    "DesktopBackgroundClass"

class Taskbar;
class TaskbarButton;
class TaskbarSkin;
class Texture;

typedef vector<TaskbarButton *>::iterator TaskbarButtonIterator;

class Taskbar
{
	friend class TaskbarButton;
	friend void sizeBangCommand(HWND , const char *);
	friend void moveBangCommand(HWND , const char *);
	friend void shrinkBangCommand(HWND , const char *);
	friend void growBangCommand(HWND , const char *);
	friend void moveByBangCommand(HWND , const char *);
	friend void BangBoxHook(HWND , const char *);

	//friend void DebugBangCommand(HWND , const char *);
private:   // variables

	HWND hWnd;
	HINSTANCE hInstance;
	HWND hToolTips;

	boolean alwaysOnTop;
	boolean visible;

	int screenWidth;

	RECT adjustedDeskArea;
	RECT prevDeskArea;

	BOOL active;
	BOOL mouseOver;
	TaskbarButton *capture;

	BOOL isTaskFlash;


	/*HFONT activeFont;
	HFONT font;
	HFONT minimizedFont;
	HFONT flashFont;*/

	vector<TaskbarButton *> buttons;

	boolean listChanged;

    int maxTaskWidth;
	int borderLeft;
	int borderTop;
	int borderRight;
	int borderBottom;

	int iconSize;
	int spacing;

	int buttonBorderLeft;
	int buttonBorderTop;
	int buttonBorderRight;
	int buttonBorderBottom;

	int taskbarHeight;

    TaskbarSkin *minimizedSkin;

public:
	//20021230
	void OnRefreshUnload();
	void OnRefreshReload();

	char* pszOnAddCommand;
	char* pszOnDelCommand;
	char* pszOnFlashStartCommand;
	char* pszOnFlashStopCommand;
	int nOldFlashingCount;

	void OnButtonAdded();
	void OnButtonRemoved();
	//20021215 (was private)
	TaskbarSkin *skin;
	TaskbarSkin *buttonSkin;
	TaskbarSkin *activeButtonSkin;
	TaskbarSkin *flashSkin;

	//20021121
	/*UCHAR HueIntensity;
	UCHAR NormalColorHue;
	UCHAR MinimizedColorHue;
	UCHAR SelectedColorHue;
	UCHAR FlashingColorHue;*/
	ULONG HueIntensity;
	ULONG NormalColorHue;
	ULONG MinimizedColorHue;
	ULONG SelectedColorHue;
	ULONG FlashingColorHue;

	ULONG SaturationIntensity;
	ULONG NormalSaturationIntensity;
	ULONG MinimizedSaturationIntensity;
	ULONG SelectedSaturationIntensity;
	ULONG FlashingSaturationIntensity;
	bool UseSaturation;
	bool UseHueing;
	
	COLORREF ColorHue;
	COLORREF NormalHueIntensity;
	COLORREF MinimizedHueIntensity;
	COLORREF SelectedHueIntensity;
	COLORREF FlashingHueIntensity;

	
	//20021121
	HWND gethWnd(){return hWnd;}
	void OnPaint( HDC );
	//20021108
	bool switchOnHover;
	bool minimizeOnHover;
	bool useToolTips;
	void OnRefresh();
	//20030109
	int nFlashingCount;
    //int nOldFlashingCount;
	//20030120
	int CountState(int nState);

	//20021227
	TaskbarSkin* GetSkin(char*);
#ifdef TASKBAR_SORT
BOOL Taskbar::smaller(TaskbarButtonIterator,TaskbarButtonIterator);
#endif

	Taskbar();
	virtual ~Taskbar();

	void Resize(int , int);

	void OnLoad( HINSTANCE );
	void OnUnload();

	void Invalidate( int, int, int, int );

	TaskbarButton *GetCapture();
	void SetCapture( TaskbarButton * );
	void ReleaseCapture();

	friend class TaskbarButton;

	//TRUE if the user specifies tasks flashing
	BOOL IsTaskFlash() const
	{
		return isTaskFlash;
	}

	boolean isAlwaysOnTop() const
	{
		return alwaysOnTop;
	}
	boolean isVisible() const
	{
		return visible;
	}

	void hide();
	void show();
    //BOOL IsAlreadyInList(HWND );
	BOOL showIcon;

	void GetRCRect(char *, int &, int &, int &, int &, int, int, int, int);
	//BOOL taskbarPositioning;
	//int edge;
	//20030103
	char m_pszFlashingUseSkin[16];

	int taskbarX;
	int taskbarY;
	int taskbarXS;
	int taskbarYS;

	HWND lastActive;
    int taskbarLines;
	void Layout();
	int neededHeight;
	void OnMove(int, int);
	int height;
	int width;

	BOOL reallyHidden;


    char taskbarLButtonDown[MAX_LINE_LENGTH];
    char taskbarRButtonDown[MAX_LINE_LENGTH];
    char taskbarLButtonUp[MAX_LINE_LENGTH];
    char taskbarRButtonUp[MAX_LINE_LENGTH];
    char taskbarMButtonDown[MAX_LINE_LENGTH];
    char taskbarMButtonUp[MAX_LINE_LENGTH];

	int TaskBarTileLButton;
	int TaskBarTileMButton;
	int TaskBarTileRButton;
	bool waitForBox;
	/*int flashCount;
	bool scrollWas;
	bool resetScroll;*/
	bool inCriticalProcess;
	int timerRefresh;
	//int timerScroll;
	//bool timerScrollEnabled;

	bool AddWindowToList(HWND);
    void FillList(char * , vector<string>);
	int GetRCMouse(const char * , int);
	void GetRCList(char *, vector<string> &);
	bool LsBoxed;

	int iconX;
	int iconY;

	int buttonTextBorderLeft;
	int buttonTextBorderTop;
	int buttonTextBorderRight;
	int buttonTextBorderBottom;

	BOOL showText;
	/*int textX;
	int textY;*/

	int direction;
	
	void SwitchToButton( const char * );
	int maxButtonCount;
	int buttonCountStart;
    void ShowPart( const char * , int i);
	bool useRealFlashing;

private:   // functions

	TaskbarButton *SearchForButtonByHandle( HWND );

	TaskbarButton *ButtonAtPoint( int, int );
	void ReadConfig();
	void ReadPositionConfig();
	void SetWindowPosition();

	void Dock( HWND );

private:   // configuration variables

	BOOL stripTaskbar;

	//BOOL msTaskbar;
	/*COLORREF foreColor1;
	COLORREF foreColor2;*/
	/*COLORREF backColor;
	COLORREF normalColor;
	COLORREF flashColor;
	COLORREF minColor;
	COLORREF activeColor;*/

	COLORREF textColor;
	COLORREF textActiveColor;
	COLORREF textMinimizedColor;
	COLORREF textFlashColor;

	COLORREF textShadowColor;
	BOOL taskbarTextShadow;
 	int textShadowOffsetX;
	int textShadowOffsetY;

    bool textMinimizedNoShadow;
    bool textNormalNoShadow;
    bool textSelectedNoShadow;
    bool textFlashingNoShadow;

	COLORREF textMinimizedShadowColor;
	COLORREF textSelectedShadowColor;
	COLORREF textNormalShadowColor;
	COLORREF textFlashingShadowColor;


	BOOL noSkinShift;
	BOOL noTextShift;

private:   // message handlers

	//mouse messages
	void OnMouseMove	(int,int );
	void OnLButtonDown	(int,int );
	void OnLButtonUp	(int,int );
	void OnMButtonDown	(int,int );
	void OnMButtonUp	(int,int );
	void OnRButtonDown	(int,int );
	void OnRButtonUp	(int,int );
	//� faire	
	void OnMouseEnter	(int,int );
	void OnMouseQuit	(int,int );
	void OnMouseHover	(int,int );

	void OnActivate( BOOL );
	void OnDisplayChange();
	void OnGetMinRect( HWND, RECT * );
	//20021121
	//void OnPaint( HDC );
	void OnRedraw( HWND, BOOL );
	void ComputeNeededHeight();
	void OnSize( int, int );
	void OnTimerUpdate(int);
	void OnWindowActivated( HWND, BOOL );
	void OnWindowCreated( HWND );
	void OnWindowDestroyed( HWND );
	BOOL OnWindowMessage( UINT, WPARAM, LPARAM, LRESULT & );

private:   // statics
	static BOOL WINAPI EnumWindowsProc( HWND, LPARAM );
	static LRESULT WINAPI WndProc( HWND, UINT, WPARAM, LPARAM );
protected:
};

BOOL WINAPIV PrintLog( LPCSTR, ... );

extern void (WINAPI *SwitchToThisWindow)( HWND, int );

#endif // __TASKBAR_H
