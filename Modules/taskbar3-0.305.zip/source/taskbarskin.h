#ifndef __TASKBARSKIN_H
#define __TASKBARSKIN_H

#include <string>
#include <vector>
#include "../current/lsapi/lsapi.h"
#include "taskbar.h"
#include "utilities.h"
#include "bangs.h"
#include "CLsFont.h"
#include "AggressiveOptimize.h"
using namespace std;

class TaskbarSkin
{
public:
	//20021231
	COLORREF HueColor;
	int HueIntensity;
	int SaturationIntensity;
	//20021203
	CLsFont Font;

	COLORREF GetBackColor();
	void SetBackColor(COLORREF color);
	BOOL stretch;
	BOOL GetStretch();
	void SetStretch(BOOL s);

	TaskbarSkin();
	TaskbarSkin( LPCSTR, LPCSTR, LPCSTR );
	virtual ~TaskbarSkin();

	void Apply( HDC, int, int, int, int );
	bool IsValid();
	//20021226
	COLORREF foreColor1;
	COLORREF foreColor2;
	//20021227
	void ReadSkinColor(char* , COLORREF , COLORREF , COLORREF );
protected:
	HBITMAP hbmLeft;
	int leftH;
	int leftW;

	HBITMAP hbmMiddle;
	int middleH;
	int middleW;

	HBITMAP hbmRight;
	int rightH;
	int rightW;
private:
	COLORREF backColor;
};
#endif