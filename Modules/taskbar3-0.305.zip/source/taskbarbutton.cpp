#include <algorithm>
#include "common.h"
#include <commctrl.h>
#include <shellapi.h>
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/macros.h"
#include "utilities.h"
#include "taskbar.h"
#include "bangs.h"
#include "taskbarbutton.h"
extern Taskbar *taskbar;

#include "CWinMgr.h"
extern CWinMgr WindowManager;

extern vector<string> NoFlashList;
extern vector<string> RemoveList;
extern vector<string> HideList;
extern vector<string> AddList;
extern vector<string> NoScrollList;

//20021128
#define TIP_ADD		0
#define TIP_UPDATE	1
#define TIP_DEL		2
#define TIP_NEW		3

HWND TaskbarButton::buttonHandler()
{
	return hTask;
}

//20021128
void TaskbarButton::AdjustTooltip(int nMode, LPSTR caption)
{
	if (hTask && container.useToolTips)
	{
		TOOLINFO ti;
		memset( &ti, 0, sizeof(TOOLINFO) );

		ti.cbSize = sizeof(TOOLINFO);
		ti.hwnd = container.hWnd;
		ti.uId = (UINT) this;

		switch (nMode)
		{
			case TIP_ADD:
				ti.lpszText = caption;
				SendMessage( container.hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti );				
				SetWindowPos( container.hToolTips, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
				break;
			case TIP_UPDATE:
				ti.lpszText = caption;
				SendMessage( container.hToolTips, TTM_UPDATETIPTEXT, 0, (LPARAM) &ti );
				//20021223
				SetWindowPos( container.hToolTips, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE|SWP_NOZORDER);
				break;
			case TIP_DEL:
				SendMessage( container.hToolTips, TTM_DELTOOL, 0, (LPARAM) &ti );
				break;
			case TIP_NEW:
				ti.rect.left = x;
				ti.rect.top = y;
				ti.rect.right = x + width;
				ti.rect.bottom = y + height;
				SendMessage( container.hToolTips, TTM_NEWTOOLRECT, 0, (LPARAM) &ti );
				SetWindowPos( container.hToolTips, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
				break;
		}
	}
}

TaskbarButton::TaskbarButton( Taskbar &tb, HWND hWnd )
: container(tb), skin(NULL), activeskin(NULL), flashskin(NULL), minimizedskin(NULL),
  otherCaption(NULL), caption(NULL), /*mousePressed(FALSE),*/ mouseOver(FALSE),
  taskflash(FALSE), x(0), y(0), height(0), width(0), flashing(false), flashingFlashSkin(false),
  currentState(STATE_UNKNOWN), hTask(hWnd)
{
	isOnTop = WindowManager.IsOnTop(hTask);

	caption = GetWindowCaption();
	//20021128
	AdjustTooltip(TIP_ADD, caption);
	
	if(taskbar->showIcon)
		icon = GetIcon();
}

TaskbarButton::~TaskbarButton()
{
	delete caption;
	delete otherCaption;

	//20021128
	AdjustTooltip(TIP_DEL, caption);
}

BOOL TaskbarButton::HasPoint( int xP, int yP )
{
	if ( xP < (x + width) && xP >= x )
	{
		if ( yP < (y + height) && yP >= y )
			return TRUE;
	}
	return FALSE;
}

void TaskbarButton::Move( int xP, int yP, int widthP, int heightP )
{
	x = xP;
	y = yP;
	height = heightP;
	width = widthP;

	AdjustTooltip(TIP_NEW, caption);
}

void TaskbarButton::SelectUp()
{
	//mousePressed = FALSE;
	if ( container.GetCapture() != this )
	{
		return ;
	}

	container.ReleaseCapture();

	if ( !mouseOver )
	{
		container.Invalidate( x, y, width + 1, height + 1 );
		return ;
	}
}

void TaskbarButton::SelectDown()
{
	container.SetCapture( this );

	if(this->currentState == STATE_FLASHING)
	{
			this->SetFlashing(FALSE);
			this->currentState = this->getCurrentState(false);
	}
	switch(this->currentState)
	{
		case STATE_MINIMIZED:
			WindowManager.RestoreWindow(hTask);
			break;
		case STATE_SELECTED:
			WindowManager.MinimizeWindow(hTask);
			break;
		default:
			{
				WindowManager.SelectWindow(hTask);
			}
	}
}

void TaskbarButton::MenuUp(){
	//mousePressed = FALSE;
	if ( container.GetCapture() != this )
		return ;

	container.ReleaseCapture();

	if ( !mouseOver )
	{
		container.Invalidate( x, y, width + 1, height + 1 );
		return ;
	}

	HMENU systemMenu;
	systemMenu = GetSystemMenu( hTask, FALSE );

	WINDOWPLACEMENT wp;
	wp.length = sizeof(WINDOWPLACEMENT);
	GetWindowPlacement( hTask, &wp );

	// restore is enabled only if minimized or maximized (not normal)
	EnableMenuItem( systemMenu, SC_RESTORE, MF_BYCOMMAND |
	                (wp.showCmd != SW_SHOWNORMAL ? MF_ENABLED : MF_GRAYED) );

	// move is enabled only if normal
	EnableMenuItem( systemMenu, SC_MOVE, MF_BYCOMMAND |
	                (wp.showCmd == SW_SHOWNORMAL ? MF_ENABLED : MF_GRAYED) );

	// size is enabled only if normal
	EnableMenuItem( systemMenu, SC_SIZE, MF_BYCOMMAND |
	                (wp.showCmd == SW_SHOWNORMAL ? MF_ENABLED : MF_GRAYED) );

	// minimize is enabled only if not minimized
	EnableMenuItem( systemMenu, SC_MOVE, MF_BYCOMMAND |
	                (wp.showCmd != SW_SHOWMINIMIZED ? MF_ENABLED : MF_GRAYED) );

	// maximize is enabled only if not maximized
	EnableMenuItem( systemMenu, SC_MOVE, MF_BYCOMMAND |
	                (wp.showCmd != SW_SHOWMAXIMIZED ? MF_ENABLED : MF_GRAYED) );


	// let application modify menu
	SendMessage( hTask, WM_INITMENUPOPUP, (WPARAM) systemMenu, MAKELPARAM( 0, TRUE ) );
	SendMessage( hTask, WM_INITMENU, (WPARAM) systemMenu, 0 );

	// display the menu
	POINT pt;
	GetCursorPos( &pt );

	int command = TrackPopupMenu( systemMenu,
	                              TPM_RETURNCMD | TPM_RIGHTBUTTON,
	                              pt.x, pt.y, 0,
	                              container.hWnd,
	                              NULL );

	if ( command )
	{
		if ( command != SC_MINIMIZE && command != SC_CLOSE )
			//SetForegroundWindow( hTask );
			WindowManager.SelectWindow(hTask);

		//20030123
		//PostMessage( hTask, WM_SYSCOMMAND, (WPARAM) command, MAKELPARAM( pt.x, pt.y ) );
		SendMessage( hTask, WM_SYSCOMMAND, (WPARAM) command, MAKELPARAM( pt.x, pt.y ) );
	}
	else
	{
		container.Invalidate( x, y, width + 1, height + 1 );
	}
}

void TaskbarButton::MenuDown()
{
	container.SetCapture( this );
	SetFlashing(FALSE);
	container.Invalidate( x, y, width + 1, height + 1 );
}

void TaskbarButton::OnMouseMove( int mX, int mY )
{
	if ( mouseOver != HasPoint( mX, mY ) )
	{
		mouseOver = !mouseOver;
		container.Invalidate( x, y, width + 1, height + 1 );
	}

	if(taskbar->switchOnHover && getCurrentState(false) != STATE_SELECTED) //20021108
	{
		//20021110
		WindowManager.SelectWindow(hTask);
	}
	//buggy
	/*else if(taskbar->minimizeOnHover && getCurrentState(false) == STATE_SELECTED)
	{
		WindowManager.MinimizeWindow(hTask);
	}*/
}

int TaskbarButton::getCurrentState(bool returnFlashing = true)
{

	//20030120
	//if(returnFlashing && GetFlashing() && container.IsTaskFlash() && !IsOnTaskbarList(this->hTask, NoFlashList))
	if(returnFlashing)
	{
		if(!IsOnTaskbarList(this->hTask, NoFlashList))
		{
			if( GetActiveWindow() != this->hTask)
			{
				if(GetFlashing() && container.IsTaskFlash())
				return STATE_FLASHING;
			}

		}
	}

	return 	WindowManager.GetState(hTask);
}

void TaskbarButton::OnPaint( HDC hDC )
{
	RECT r;

	r.left = x;
	r.top = y;
	r.right = x + width;
	r.bottom = y + height;

    TaskbarSkin *tempskin;

	int skinShift = 0;
	int textShift = 0;

	//20021129

	currentState = getCurrentState(false);

	if( STATE_SELECTED == currentState )
	{
		taskbar->lastActive = this->hTask;
	}

	if(container.IsTaskFlash() && ( STATE_SELECTED == currentState ))
	{
		SetFlashing(FALSE);
		flashing = false;
	}

	currentState = getCurrentState();

	if(currentState == STATE_FLASHING)
	{
		container.nFlashingCount++;
		if(!taskbar->useRealFlashing)
		{
			tempskin = taskbar->flashSkin;
		}
		else if (taskbar->useRealFlashing && flashingFlashSkin)//20020611
		{
			tempskin = taskbar->flashSkin;
		}
		else
		{
			//20030103
			//trankillity: before it would only be Taskbar back; now it defaults to it
			//TaskbarRealFlashingUseSkin normal, active, minimized, none (taskbar back)
			if(!strcmp(taskbar->m_pszFlashingUseSkin, "normal"))
			{
				tempskin = taskbar->buttonSkin;
			}
			else if(!strcmp(taskbar->m_pszFlashingUseSkin, "active"))
			{
				tempskin = taskbar->activeButtonSkin;
			}
			else if(!strcmp(taskbar->m_pszFlashingUseSkin, "active"))
			{
				tempskin = taskbar->activeButtonSkin;
			}
			else if(!strcmp(taskbar->m_pszFlashingUseSkin, "minimized"))
			{
				tempskin = taskbar->minimizedSkin;
			}
		}
	}
	else if(currentState == STATE_MINIMIZED)
			tempskin = taskbar->minimizedSkin;
	else if ( currentState == STATE_SELECTED )
	{
		//flash active
			tempskin = taskbar->activeButtonSkin;

		skinShift = container.noSkinShift ? 0 : 1;
		textShift = container.noTextShift ? 0 : 1;
	}
	else
	{
			tempskin = taskbar->buttonSkin;
	}

	if ( (tempskin != NULL) && (!tempskin->IsValid()) )
	{
		HBRUSH hbrBack;
		HPEN hpnFore;
		HPEN hpnTemp;
		COLORREF backcolor = tempskin->GetBackColor();

		hbrBack = CreateSolidBrush(backcolor);
		FillRect( hDC, &r, hbrBack );
		DeleteObject( hbrBack );

		//bevels .... make one per state too ?
		//hpnFore = CreatePen( PS_SOLID, 1, ( STATE_SELECTED == currentState ) ? container.foreColor1 : container.foreColor2 );
		hpnFore = CreatePen( PS_SOLID, 1, ( STATE_SELECTED == currentState ) ? tempskin->foreColor1 : tempskin->foreColor2);
		hpnTemp = (HPEN) SelectObject( hDC, hpnFore );

		MoveToEx( hDC, r.left, r.bottom - 1, NULL );
		LineTo( hDC, r.right - 1, r.bottom - 1 );
		LineTo( hDC, r.right - 1, r.top );

		SelectObject( hDC, hpnTemp );
		DeleteObject( hpnFore );

		hpnFore = CreatePen( PS_SOLID, 1, ( STATE_SELECTED == currentState ) ? tempskin->foreColor2 : tempskin->foreColor1 );
		hpnTemp = (HPEN) SelectObject( hDC, hpnFore );

		LineTo( hDC, r.left, r.top );
		LineTo( hDC, r.left, r.bottom - 1 );

		SelectObject( hDC, hpnTemp );
		DeleteObject( hpnFore );
	}
	else if(tempskin != NULL)
	{
		// simple 3D frame
		HBRUSH hbrBack;

		hbrBack = CreateSolidBrush( skin->GetBackColor());
		FillRect( hDC, &r, hbrBack );
		DeleteObject( hbrBack );

		// skin
		tempskin->Apply( hDC, x + skinShift, y + skinShift, width, height );
	}

	r.left += taskbar->buttonBorderLeft;
	r.top += taskbar->buttonBorderTop;
	r.right -= taskbar->buttonBorderRight;
	r.bottom -= taskbar->buttonBorderBottom;

	OffsetRect( &r, textShift, textShift );

	if (taskbar->showIcon && icon)
	{
		int iconWidth = taskbar->iconSize, iconHeight =  taskbar->iconSize;
		int tmpIconX, tmpIconY;

		if(taskbar->iconX<0)
			tmpIconX = this->width / 2 + r.left - taskbar->iconSize / 2 - taskbar->buttonBorderLeft;
		else{
			tmpIconX = r.left + taskbar->iconX;
		}

		if(taskbar->iconY<0)
			tmpIconY = this->height / 2 + r.top - taskbar->iconSize / 2 - taskbar->buttonBorderTop;
		else{
			tmpIconY = r.top + taskbar->iconY;
		}
		//icon size things
		if (((r.right - r.left) < taskbar->iconSize) || ((r.bottom - r.top) < taskbar->iconSize))
			iconHeight = iconWidth = min(r.right - r.left, r.bottom - r.top);
		/*20021121*/
		ULONG useHueIntensity = taskbar->HueIntensity;
		ULONG useSaturation = taskbar->SaturationIntensity;
		COLORREF useClrHue = taskbar->ColorHue;
		
		if (currentState == STATE_FLASHING && !taskbar->useRealFlashing)
		{
			useHueIntensity = taskbar->FlashingHueIntensity;
			useSaturation = taskbar->FlashingSaturationIntensity;
			useClrHue = taskbar->FlashingColorHue;
		}
		else if(currentState == STATE_FLASHING && taskbar->useRealFlashing && flashingFlashSkin)
		{
			useHueIntensity = taskbar->FlashingHueIntensity;
			useSaturation = taskbar->FlashingSaturationIntensity;
			useClrHue = taskbar->FlashingColorHue;
		}
		else if(currentState == STATE_MINIMIZED)
		{
			useHueIntensity = taskbar->MinimizedHueIntensity;
			useSaturation = taskbar->MinimizedSaturationIntensity;
			useClrHue = taskbar->MinimizedColorHue;
		}
		else if ( currentState == STATE_SELECTED )
		{
			useHueIntensity = taskbar->SelectedHueIntensity;
			useSaturation = taskbar->SelectedSaturationIntensity;
			useClrHue = taskbar->SelectedColorHue;
		}
		else
		{
			useHueIntensity = taskbar->NormalHueIntensity;
			useSaturation = taskbar->NormalSaturationIntensity;
			useClrHue = taskbar->NormalColorHue;
		}
		//20021231
		/*if(tempskin != NULL)
		{
			useHueIntensity = tempskin->HueIntensity;
			useSaturation = tempskin->SaturationIntensity;
			useClrHue = tempskin->HueColor;
		}*/

		if(taskbar->UseHueing || taskbar->UseSaturation)
		{		
			UINT y = 0;
			HDC hdc        = ::CreateCompatibleDC(hDC);
			HBITMAP hbmNew = ::CreateCompatibleBitmap(hDC, 2*iconWidth, iconWidth);
			HBITMAP hbmOld = (HBITMAP) ::SelectObject(hdc, hbmNew);

			DrawIconEx(hdc, 0, 0, icon, iconWidth, iconWidth, 0, NULL, DI_NORMAL);
			DrawIconEx(hdc, iconWidth, 0, icon, iconWidth, iconWidth, 0, NULL, DI_MASK);
			while (y < iconWidth)
			{
				UINT x = 0;
				while (x < iconWidth)
				{
					// loop through all transparent pixels...
					while (x < iconWidth)
					{
						// if the mask-pixel is white, then break
						if ( !GetPixel(hdc, x+iconWidth, y) )
						{
							COLORREF cl = ::GetPixel(hdc, x, y);
							BYTE r = GetRValue(cl);
							BYTE g = GetGValue(cl);
							BYTE b = GetBValue(cl);

								// saturation effect
							if (taskbar->UseSaturation)
							{
								BYTE gray = (BYTE)(r*0.3086+g*0.6094+b*0.0820);
								r = (BYTE)((r*useSaturation+gray*(255-useSaturation)+255)>>8);
								g = (BYTE)((g*useSaturation+gray*(255-useSaturation)+255)>>8);
								b = (BYTE)((b*useSaturation+gray*(255-useSaturation)+255)>>8);
							}

							if (taskbar->UseHueing)
							{
								r = (BYTE)((r*(255-useHueIntensity)+GetRValue(useClrHue)*useHueIntensity+255)>>8);
								g = (BYTE)((g*(255-useHueIntensity)+GetGValue(useClrHue)*useHueIntensity+255)>>8);
								b = (BYTE)((b*(255-useHueIntensity)+GetBValue(useClrHue)*useHueIntensity+255)>>8);
							}
							SetPixel(hDC, tmpIconX+x, tmpIconY+y, RGB(r, g, b));
						}
						x++;
					}
				}
				y++;
			}
			SelectObject(hdc, hbmOld);
			DeleteObject(hbmNew);
			DeleteDC(hdc);
		}
		else
		{
			DrawIconEx( hDC, tmpIconX, tmpIconY , icon, iconWidth, iconHeight, 0, NULL, DI_NORMAL );
		}
	}

	if(taskbar->showText)
	{
		r.left += taskbar->buttonTextBorderLeft;
		r.top += taskbar->buttonTextBorderTop;
		r.right -= taskbar->buttonTextBorderRight;
		r.bottom -= taskbar->buttonTextBorderBottom;

		if (hTask)
		{
			if (caption)
			{
				//beware if the skins don't exist !!!!
				if(currentState == STATE_FLASHING)
					flashskin->Font.Apply(hDC, r, caption);
				else if(IsIconic(hTask))
					minimizedskin->Font.Apply(hDC, r, caption);
				else if(WindowManager.IsActive(hTask))
					activeskin->Font.Apply(hDC, r, caption);
				else
					taskbar->buttonSkin->Font.Apply(hDC, r, caption);					
			}
		}
		else
		{
			if (otherCaption)
			{
				if(currentState == STATE_FLASHING)
					flashskin->Font.Apply(hDC, r, otherCaption);
				else if(IsIconic(hTask))
					minimizedskin->Font.Apply(hDC, r, otherCaption);
				else if(WindowManager.IsActive(hTask))
					activeskin->Font.Apply(hDC, r, otherCaption);
				else
					taskbar->buttonSkin->Font.Apply(hDC, r, otherCaption);
			}
		}
	}
}

//20021125
void TaskbarButton::OnButtonUp( int nX, int nY, int nButtonCase)
{
	switch (nButtonCase){
		case MOUSE_SELECT:
			SelectUp();
		    break;
		case MOUSE_MENU:
			MenuUp();
		    break;
		case MOUSE_ONTOP:
			WindowManager.OnTopToggle(hTask);
			break;
		case MOUSE_CLOSE:
			WindowManager.Close(hTask);
		    break;
		case MOUSE_CLOSE2:
			WindowManager.Close2(hTask);
		    break;
		case MOUSE_SHADE:
			WindowManager.ToggleShade(hTask);
		    break;
		case MOUSE_NONE:
		    break;
        default:
		    break;
	}
}

void TaskbarButton::OnButtonDown( int nX, int nY, int nButtonCase)
{
	switch (nButtonCase){
		case MOUSE_SELECT:
			SelectDown();
		    break;
		case MOUSE_MENU:
			MenuDown();
		    break;
		case MOUSE_ONTOP:
			WindowManager.OnTopToggle(hTask);
			break;
		case MOUSE_CLOSE:
			WindowManager.Close(hTask);
		    break;
		case MOUSE_CLOSE2:
			WindowManager.Close2(hTask);
		    break;
		case MOUSE_SHADE:
			WindowManager.ToggleShade(hTask);
		    break;
		case MOUSE_NONE:
		    break;
        default:
		    break;
	}
}

void TaskbarButton::OnUpdate(BOOL needRedraw)
{
	if (!needRedraw)
	{
		LPSTR temp1, temp2;

		if (hTask)
		{
			temp1 = caption;
			temp2 = GetWindowCaption();
		}
		else
		{
			temp1 = otherCaption;
			temp2 = NULL;
		}

		if ( temp2 == NULL || strcmp( temp1, temp2 ) != 0 )
		{
			if (temp2)
			{
				delete [] caption;
				caption = temp2;
				needRedraw = TRUE;
				temp1 = caption;
			}
			AdjustTooltip(TIP_UPDATE, temp1);
		}
		else
		{
			if (temp2)
			{
				delete [] temp2;
			}
		}

		// has icon changed?
		HICON tempIcon = GetIcon();

		if ( icon != tempIcon )
		{
			icon = tempIcon;
			needRedraw = TRUE;
		}
	}

	if ( needRedraw )
	  container.Invalidate( x, y, width + 1, height + 1 );
}

LPSTR TaskbarButton::GetWindowCaption()
{
	LPSTR windowCaption = NULL;
	int length;

	if (hTask)
	{
		length = GetWindowTextLength( hTask );

		windowCaption = new char[length + 1];
		GetWindowText( hTask, windowCaption, length + 1 );
	}

	return windowCaption;
}

HICON TaskbarButton::GetIcon()
{
	return GetIconFromWindow( hTask, (taskbar->iconSize>=32) ); //get a big icon sometimes
}

void TaskbarButton::SetCaption(LPCSTR cap)
{
	if (!cap)
	{
		return ;
	}

	if (otherCaption)
	{
		delete [] otherCaption;
	}

	otherCaption = new char[strlen(cap) + 1];

	strcpy(otherCaption, cap);

	AdjustTooltip(TIP_ADD, otherCaption);
}
