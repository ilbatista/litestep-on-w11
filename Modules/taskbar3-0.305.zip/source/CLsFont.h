#if !defined(__CLSFONT_H)
	#define __CLSFONT_H

	class CLsFont
	{
		private:
			//char*		m_pszFontName;
			//HFONT		m_hFont;
			COLORREF	m_wTextColor;
			BOOL		m_bUseShadow;
			COLORREF	m_wShadowColor;
			int			m_nShadowOffsetX;
			int			m_nShadowOffsetY;
			UINT		m_nTextAlign;
		public:
			HFONT		m_hFont;
			CLsFont();
			~CLsFont();
			HFONT GetFont (char*,const LOGFONT*);
			HFONT GetDefaultFont(char*, LOGFONT*);
			void ReadFontColor(char*, COLORREF);
			void ReadShadowSettings(char*, BOOL, COLORREF, int, int);
			void Apply( HDC, RECT&, char*);
			void GetTextAlignment(char*, UINT, UINT);
			void GetTextMetrics(TEXTMETRIC &);
	};		
#endif