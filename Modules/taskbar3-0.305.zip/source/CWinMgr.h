#if !defined(__CWINMGR_H)
	#define __CWINMGR_H

	#define STATE_UNKNOWN	1
	#define STATE_NORMAL	2
	#define STATE_SELECTED	4
	#define STATE_MINIMIZED	8
	#define STATE_FLASHING	16

	class CWinMgr
	{
		public:
			int GetState(HWND);
			bool IsActive(HWND);
			void OnTopToggle(HWND);
			void SetOnTop(HWND);
			bool IsOnTop(HWND);
			void SetNotOnTop(HWND);
			bool IsShaded(HWND);
			void ToggleShade(HWND);
			void Shade(HWND);
			void UnShade(HWND);
			void MinimizeWindow(HWND);
			void RestoreWindow(HWND);
			void SelectWindow(HWND);
			void Close(HWND);
			void Close2(HWND);
		private:
			HWND GetRealWindow(HWND);
			HWND GetOwnerWindow(HWND);
	};
#endif