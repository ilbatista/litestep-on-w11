////////////////////////
// LSSnake 1.1
// By: MrJukes
// Released: 4/25/00
////////////////////////

step.rc entries:
LoadModule h:\litestep\lssnake.dll

LSSnakeX 100
LSSnakeY 100
LSSnakeWidth 150
LSSnakeHeight 150
; The speed is in milliseconds.  100 is pretty quick.
LSSnakeSpeed 100
LSSnakeSnakeColor FFFFFF
LSSnakeBGColor 000000
LSSnakeFoodColor FF0000
LSSnakeTextColor 0000FF
LSSnakeBlockSize 5

Bang Commands:
!LSSnakeHide
!LSSnakeShow
!LSSnakeToggle
!LSSnakeFocus

Game Play:
To start play, Left click anywhere in the LSSnake window or hit Enter.
To pause the game, Left click anywhere in the LSSnak windows or hit Enter.
Use the Left, Right, Up, and Down arrows to move the snake around.
Do not touch the walls and do not run into yourself, this will result in you losing.

Have fun,
	MrJukes (mrjukes@purdue.edu)