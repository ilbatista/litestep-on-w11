#include "common.h"
#include "LabelSettings.h"
#include "Font.h"
#include "Texture.h"

NameValuePair alignValues[] = {
	{ "left", DT_LEFT },
	{ "center", DT_CENTER },
	{ "right", DT_RIGHT },
	{ 0, 0 }
};

NameValuePair vertAlignValues[] = {
	{ "top", ALIGN_TOP },
	{ "center", ALIGN_CENTER },
	{ "bottom", ALIGN_BOTTOM },
	{ 0, 0 }
};

NameValuePair keyValues[] = {
	{ "ctrl", 1 },
	{ "shift", 2 },
	{ "ctrl+shift", 3 },
	{ "shift+ctrl", 3 },
	{ 0, 0 }
};

NameValuePair buttonValues[] = {
	{ "left", 1 },
	{ "right", 2 },
	{ "middle", 3 },
	{ 0, 0 }
};

NameValuePair autoWidthValues[] = {
	{ "left", 1 },
	{ "right", 2 },
	{ "center", 3 },
	{ 0, 0 }
};

NameValuePair autoHeightValues[] = {
	{ "top", 1 },
	{ "bottom", 2 },
	{ "center", 3 },
	{ 0, 0 }
};

NameValuePair transparencyValues[] = {
	{ "true", 1 },
	{ "fake", 2 },
	{ "false", 3 },
	{ "off", 3 },
	{ "none", 3 },
	{ ".none", 3 },
	{ 0, 0 }
};

NameValuePair effectValues[] = {
	{ "Random", -1},
	{ "Spin", 0},
	{ "Vortex", 1},
	{ "ScatterGather", 2},
	{ "Spike", 3},
	{ "Fireworks", 4},
	{ 0, 0 }
};

NameValuePair overeffectValues[] = {
	{ "Random", -1},
	{ "None", 0},
	{ "VerticalLines", 1},
	{ "HorizontalLines", 2},
	{ "Switch(lr)", 3},
	{ "Switch(rl)", 4},
	{ "Wave(tb)", 5},
	{ "Wave(bt)", 6},
	{ "Wave(lr)", 7},
	{ "Wave(rl)", 8},
	{ "Pixelize", 9},
	{ "Border", 10},
	{ "Stretch(lr)", 11},
	{ "Stretch(rl)", 12},
	{ "Stretch(tb)", 13},
	{ "Stretch(bt)", 14},
	{ "Slide(lr)", 15},
	{ "Slide(rl)", 16},
	{ "Slide(tb)", 17},
	{ "Slide(bt)", 18},
	{ "Slide(ltrb)", 19},
	{ "Slide(lbrt)", 20},
	{ 0, 0 }
};

NameValuePair scrollValues[] = {
	{ "horizontal", 1},
	{ "vertical", 2},
	{ "horizontal-left", 1},
	{ "vertical-up", 2},
	{ "horizontal-right", 3},
	{ "vertical-down", 4},
	{ 0, 0 }
};

LabelSettings::LabelSettings()
{
	const char *name = "AllLabels";
	isDefault = true;

	alwaysOnTop = GetRCBoolean(name, "AlwaysOnTop");
	startHidden = GetRCBoolean(name, "StartHidden");
	bUseFahrenheit = GetRCBoolean(name, "UseFahrenheit");

	skin = GetRCTexture(name, "");

	font = GetRCFont(name);
	
	leftBorder = GetRCInt(name, "LeftBorder", 0);
	topBorder = GetRCInt(name, "TopBorder", 0);
	rightBorder = GetRCInt(name, "RightBorder", 0);
	bottomBorder = GetRCInt(name, "BottomBorder", 0);

	align = GetRCNamedValue(name, "Align", alignValues, DT_CENTER);
	vertAlign = GetRCNamedValue(name, "VertAlign", vertAlignValues, ALIGN_CENTER);
	updateInterval = GetRCInt(name, "UpdateInterval", 1000);
	alwaysUpdateContent = GetRCBoolean(name, "UpdateAlways");

	int screenX = GetSystemMetrics(SM_CXSCREEN);
	int screenY = GetSystemMetrics(SM_CYSCREEN);

	width = GetRCDimen(name, "Width", 64, screenX);
	height = GetRCDimen(name, "Height", 64, screenY);
	x = GetRCCoord(name, "X", 0, screenX);
	y = GetRCCoord(name, "Y", 0, screenY);

	text = GetRCString(name, "Text", "");
	tooltip = GetRCString(name, "Tooltip", "");

	lineBreak = GetRCBoolean(name, "AutoLineBreak");

	leftClickCommand = GetRCLine(name, "OnLeftClick", "");
	leftDoubleClickCommand = GetRCLine(name, "OnLeftDoubleClick", "");
	middleClickCommand = GetRCLine(name, "OnMiddleClick", "");
	middleDoubleClickCommand = GetRCLine(name, "OnMiddleDoubleClick", "");
	rightClickCommand = GetRCLine(name, "OnRightClick", "");
	rightDoubleClickCommand = GetRCLine(name, "OnRightDoubleClick", "");
	wheelDownCommand = GetRCLine(name, "OnWheelDown", "");
	wheelUpCommand = GetRCLine(name, "OnWheelUp", "");
	enterCommand = GetRCLine(name, "OnEnter", "");
	leaveCommand = GetRCLine(name, "OnLeave", "");
	dropCommand = GetRCLine(name, "OnDrop", "");
	textChangeCommand = GetRCLine(name, "OnTextChange", "");
	resizeCommand = GetRCLine(name, "OnResize", "");

	scrollPadLength = GetRCInt(name, "scrollPad", 10); 
	scrollInterval = GetRCInt(name, "scrollInterval", 100);
	scrollSpeed = GetRCInt(name, "scrollSpeed", 1);
	scroll = GetRCNamedValue(name, "scroll", scrollValues, 0);

	autoWidthMode = GetRCNamedValue(name, "AutoWidthMode", autoWidthValues, 0);
	autoHeightMode = GetRCNamedValue(name, "AutoHeightMode", autoHeightValues, 0);
	autoMaxWidth = GetRCDimen(name, "AutoMaxWidth", screenX, screenX);
	autoMaxHeight = GetRCDimen(name, "AutoMaxHeight", screenY, screenY);

	transparencyMode = GetRCNamedValue(name, "TransparencyMode", transparencyValues, 1);
	alphaTransparency = GetRCInt(name, "AlphaTransparency", 255);
	alphaFade = GetRCBoolean(name, "AlphaFade");
	ghosted = GetRCBoolean(name, "Ghosted");

	moveable = GetRCBoolean(name, "Moveable");
	moveKey = GetRCNamedValue(name, "MoveModifierKey", keyValues, 1);
	moveButton = GetRCNamedValue(name, "MoveButton", buttonValues, 1);

	string helper;
	helper = "*";
	helper.append(name);
	helper.append("OnLeftClickRegion");
	labelLeftClickRegions = GetRCLineList(helper.c_str());
	helper = "*";
	helper.append(name);
	helper.append("OnRightClickRegion");
	labelRightClickRegions = GetRCLineList(helper.c_str());
	helper = "*";
	helper.append(name);
	helper.append("OnMiddleClickRegion");
	labelMiddleClickRegions = GetRCLineList(helper.c_str());

	enterleaveRegion = GetRCLine(name, "OnEnterLeaveRegion", "0 0 -0 -0");

	labelGroup = GetRCString(name, "AddToGroup", "");

	//Animations
	imageLoop = GetRCInt(name, "FrameLoops", -1);
	imageFrameDelay = GetRCInt(name, "FrameDelay", 100);
	imageFrameCount = GetRCInt(name, "FrameCount", 0);
	hoverimageLoop = GetRCInt(name, "HoverFrameLoops", -1);
	hoverimageFrameDelay = GetRCInt(name, "HoverFrameDelay", 100);
	hoverimageFrameCount = GetRCInt(name, "HoverFrameCount", 0);

	overblendStyle = GetRCNamedValue(name, "OverBlendEffect", overeffectValues, 0);
}

LabelSettings::LabelSettings(const char *name)
{
	isDefault = false;

	alwaysOnTop = GetRCBoolean(name, "AlwaysOnTop", defaultSettings->alwaysOnTop);
	startHidden = GetRCBoolean(name, "StartHidden", defaultSettings->startHidden);
	bUseFahrenheit = GetRCBoolean(name, "UseFahrenheit", defaultSettings->bUseFahrenheit);

	skin = GetRCTexture(name, "", defaultSettings->skin);

	font = GetRCFont(name, defaultSettings->font);
	
	leftBorder = GetRCInt(name, "LeftBorder", defaultSettings->leftBorder);
	topBorder = GetRCInt(name, "TopBorder", defaultSettings->topBorder);
	rightBorder = GetRCInt(name, "RightBorder", defaultSettings->rightBorder);
	bottomBorder = GetRCInt(name, "BottomBorder", defaultSettings->bottomBorder);

	align = GetRCNamedValue(name, "Align", alignValues, defaultSettings->align);
	vertAlign = GetRCNamedValue(name, "VertAlign", vertAlignValues, defaultSettings->vertAlign);
	updateInterval = GetRCInt(name, "UpdateInterval", defaultSettings->updateInterval);
	alwaysUpdateContent = GetRCBoolean(name, "UpdateAlways", defaultSettings->alwaysUpdateContent);

	int screenX = GetSystemMetrics(SM_CXSCREEN);
	int screenY = GetSystemMetrics(SM_CYSCREEN);

	width = GetRCDimen(name, "Width", defaultSettings->width, screenX);
	height = GetRCDimen(name, "Height", defaultSettings->height, screenY);
	x = GetRCCoord(name, "X", defaultSettings->x, screenX);
	y = GetRCCoord(name, "Y", defaultSettings->y, screenY);

	text = GetRCString(name, "Text", defaultSettings->text);
	tooltip = GetRCString(name, "Tooltip", defaultSettings->tooltip);

	lineBreak = GetRCBoolean(name, "AutoLineBreak", defaultSettings->lineBreak);

	leftClickCommand = GetRCLine(name, "OnLeftClick", defaultSettings->leftClickCommand);
	leftDoubleClickCommand = GetRCLine(name, "OnLeftDoubleClick", defaultSettings->leftDoubleClickCommand);
	middleClickCommand = GetRCLine(name, "OnMiddleClick", defaultSettings->middleClickCommand);
	middleDoubleClickCommand = GetRCLine(name, "OnMiddleDoubleClick", defaultSettings->middleDoubleClickCommand);
	rightClickCommand = GetRCLine(name, "OnRightClick", defaultSettings->rightClickCommand);
	rightDoubleClickCommand = GetRCLine(name, "OnRightDoubleClick", defaultSettings->rightDoubleClickCommand);
	wheelDownCommand = GetRCLine(name, "OnWheelDown", defaultSettings->wheelDownCommand);
	wheelUpCommand = GetRCLine(name, "OnWheelUp", defaultSettings->wheelUpCommand);
	enterCommand = GetRCLine(name, "OnEnter", defaultSettings->enterCommand);
	leaveCommand = GetRCLine(name, "OnLeave", defaultSettings->leaveCommand);
	dropCommand = GetRCLine(name, "OnDrop", defaultSettings->dropCommand);
	textChangeCommand = GetRCLine(name, "OnTextChange", defaultSettings->textChangeCommand);
	resizeCommand = GetRCLine(name, "OnResize", defaultSettings->resizeCommand);

	scrollPadLength = GetRCInt(name, "scrollPad", defaultSettings->scrollPadLength);
	scrollInterval = GetRCInt(name, "scrollInterval", defaultSettings->scrollInterval);
	scrollSpeed = GetRCInt(name, "scrollSpeed", defaultSettings->scrollSpeed);
	scroll = GetRCNamedValue(name, "scroll", scrollValues, defaultSettings->scroll);
	//Compatibility to old Boolean Value Scroll
	if (GetRCBoolean(name, "scroll") && scroll == 0)
		scroll = 1;

	autoWidthMode = GetRCNamedValue(name, "AutoWidthMode", autoWidthValues, defaultSettings->autoWidthMode);
	autoHeightMode = GetRCNamedValue(name, "AutoHeightMode", autoHeightValues, defaultSettings->autoHeightMode);
	autoMaxWidth = GetRCDimen(name, "AutoMaxWidth", defaultSettings->autoMaxWidth, screenX);
	autoMaxHeight = GetRCDimen(name, "AutoMaxHeight", defaultSettings->autoMaxHeight, screenY);

	transparencyMode = GetRCNamedValue(name, "TransparencyMode", transparencyValues, defaultSettings->transparencyMode);
	alphaTransparency = GetRCInt(name, "AlphaTransparency", defaultSettings->alphaTransparency);
	alphaFade = GetRCBoolean(name, "AlphaFade", defaultSettings->alphaFade);
	ghosted = GetRCBoolean(name, "Ghosted", defaultSettings->ghosted);

	moveable = GetRCBoolean(name, "Moveable", defaultSettings->moveable);
	moveKey = GetRCNamedValue(name, "MoveModifierKey", keyValues, defaultSettings->moveKey);
	moveButton = GetRCNamedValue(name, "MoveButton", buttonValues, defaultSettings->moveButton);

	string helper;
	helper = "*";
	helper.append(name);
	helper.append("OnLeftClickRegion");
	labelLeftClickRegions = GetRCLineList(helper.c_str());
	helper = "*";
	helper.append(name);
	helper.append("OnRightClickRegion");
	labelRightClickRegions = GetRCLineList(helper.c_str());
	helper = "*";
	helper.append(name);
	helper.append("OnMiddleClickRegion");
	labelMiddleClickRegions = GetRCLineList(helper.c_str());

	enterleaveRegion = GetRCLine(name, "OnEnterLeaveRegion", defaultSettings->enterleaveRegion);

	labelGroup = GetRCString(name, "AddToGroup", defaultSettings->labelGroup);

	//Animations
	imageLoop = GetRCInt(name, "FrameLoop", defaultSettings->imageLoop);
	imageFrameDelay = GetRCInt(name, "FrameDelay", defaultSettings->imageFrameDelay);
	imageFrameCount = GetRCInt(name, "FrameCount", defaultSettings->imageFrameCount);
	hoverimageLoop = GetRCInt(name, "HoverFrameLoop", defaultSettings->hoverimageLoop);
	hoverimageFrameDelay = GetRCInt(name, "HoverFrameDelay", defaultSettings->hoverimageFrameDelay);
	hoverimageFrameCount = GetRCInt(name, "HoverFrameCount", defaultSettings->hoverimageFrameCount);

	overblendStyle = GetRCNamedValue(name, "OverblendEffect", overeffectValues, defaultSettings->overblendStyle);
}

LabelSettings::~LabelSettings()
{
	if(isDefault)
	{
		delete skin;
		delete font;
	}
}

LabelSettings* defaultSettings = NULL;
