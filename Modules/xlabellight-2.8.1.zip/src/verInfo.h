#if !defined(__VERINFO_H)
#define __VERINFO_H

#define V_AUTHOR "Andymon"
#define V_NAME "xLabelLight"
#define V_VERSION "2.8.1"

#endif
