#ifndef __NETSTATS_H
#define __NETSTATS_H

#define NUM_SAMPLES 10
#define SAMPLE_INTERVAL 1000

class NetStats
{
public:
	NetStats();
	virtual ~NetStats();

	int GetBytesPerSecIn();
	int GetBytesPerSecOut();
	BOOL IsConnAvailable();
	BOOL Start();
	void Stop();

private:
	HINSTANCE hinstInetMib;
	PFNSNMPEXTENSIONQUERY pfnSnmpExtensionQuery;
	PFNSNMPEXTENSIONINIT pfnSnmpExtensionInit;
	HANDLE hThread;
	BOOL fFirstUpdate;
	DWORD dwLastUpdateTime;
	int nSamplesIn[NUM_SAMPLES];
	int nSamplesOut[NUM_SAMPLES];
	int iSample;
	int ifInOctetsLast;
	int ifOutOctetsLast;
	int nBytesPerSecIn;
	int nBytesPerSecOut;

	void Update();
	static DWORD WINAPI ThreadProc(LPVOID pvThis);
	int GetDefRouteIfIndex();
	int GetIfStats(int ifIndex, int *ifInOctetsPtr, int *ifOutOctetsPtr);
};

#endif
