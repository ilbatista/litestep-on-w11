///////////////////////////////////////////////////////////
//
//           LSLIVE! version 2.0.0.2 Alpha
//            Animated gifs for Litestep
//                   09/06/2005
//                written by Mercutio
//
///////////////////////////////////////////////////////////

ABOUT:

LSLIVE! is a module to allow use of animated .gif's in Litestep.
I started this project in 1998, and the first releases were stand-
alone .exe files that provided similar functionality.  This version
(finally) is as it was originally intended to be... a Litestep
module.  This release is a bit "stripped down" feature-wise 
but more features are planned for later versions.


FUNCTIONS:

As of this release, LSLIVE! does exactly two things:
1. display animated gifs on the Litestep desktop
2. Launch .exe files
True transparency is currently in the works.  Additional features
will be added as I think of them/have time to work on them.


SETUP:

Unzip the .zip file into your Litestep/Modules folder.  Add the
path to lslive.dll to your step.rc.  Right now, there are two
configurable settings; Image path, and shortcut path.  These are
(for now) located in the lslive.ini file which should be found in
the same folder as the module.  Within the next few releases, this
will change to the Modules.ini file.  The settings are straight
forward; Just set the GifPath to the path where the gif file you
want to use is located, same for the ExePath.


Disclaimer:

This software is currently in ALPHA...  while it is working properly
to the best of my knowledge, it has only been tested on one computer
under one environment.  I am not responsible for anything it might
do to you, your computer, your cat, ferret, or other small domestic 
animal, etc., etc...


Contact:

Questions and concerns can be sent to jl_keller@hotmail.com.
My nick on Litestep.net is lslive_mercutio.  You can contact me
for other contact info (IRC, ICQ, etc.).