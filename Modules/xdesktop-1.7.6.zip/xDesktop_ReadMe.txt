-\\____________________________//-
-//                            \\-
         xDesktop  v1.7.6
	        by Andymon
	 andymon@ls-universe.info
-\\____________________________//-
-//                            \\-

--------
Overview
--------

	This simulation of the explorer desktop is up to 95% identical to Explorer Desktop! Just 
	set the following Three Lines and you're having your OldStyle Explorer Desktop =)

	xDesktopAutoCreate
	xDesktopConfigFile "$ConfigDir$yourdesktopfile.rc"
	include "$ConfigDir$yourdesktopfile.rc"

------------------------
Basic Settings Overview:
------------------------

	Of course, you should also specify some basic layout informations.
	
	xDesktopX
	xDesktopY
	xDesktopItemWidth
	xDesktopItemHeight
	xDesktopSpacingX
	xDesktopSpacingY
	xDesktopDirection
	xDesktopWrapDirection
	xDesktopWrapCount 
	
	These settings affect only the "!xDesktopCreate replace ..." Bang and "xDesktopAutoCreate"
	to provide a instant layout ;) The further finetune positioning should be made by hand (Draggable). 

------------------------------
Configuration of the "Desktop"
------------------------------

Internal Syntax for each DesktopItem

*xdesktopitem xdi(number) (x pos) (y pos) "(Quoted Path)"
	Each specified line creates an DesktopItem with the Icon of the specified file. Path MUST be be quoted! 

------------------
Essential Settings
------------------

xDesktopAutoCreate
	This command enables the complete "Explorer Desktop Emulation"!
	If NO! *xdesktopitem line is set the desktop is automatically created!
	Deleted Files/Folders are instantly removed!
	Added Files/Folders appear at position x=100, y=100 for further positioning!
	
	You can use the jdesk-0.73 feature, to make your "Desktop" complete =) :
	jDeskDesktopFolder "$desktop$"

		If used and set to a valid directory, it will enable drag and drop of files or folders onto the 
		jDesk desktop area. Any file dropped on the desktop will be automatically copied into the folder 
		specified. If the file exists, you will be prompted to overwrite. You can move files holding the 
		SHIFT key or to create shortcuts holding the CTRL+SHIFT keys during dragging. 


xDesktopConfigFile "(Quoted path to rc-file)"
	This command specifies the rc-file in which your *xdesktopitem lines will be stored.
	MUST be set, for xDesktopAutoCreate, !xDesktopCreate and !xDesktopSave to work!
	The Path must, as always, be quoted!
	MUST be "included" of course!
	include "(Quoted path to rc-file)" 

------------------
Desktop Arrangment
------------------

xDesktopAddPositionX 
    Sets the horizontal position of an added DesktopIcon in pixels. 
    
xDesktopAddPositionY 
    Sets the vertical position of an added DesktopIcon in pixels. 
           
xDesktopX (number)
	Sets the horizontal position of the first DesktopIcon in pixels. 

xDesktopY (number)
	Sets the vertical position of the first DesktopIcon in pixels. 

xDesktopItemWidth (number)
	This command specifies the width of each DesktopItem [Icon + Text] If no value is provided 
	then the default is 100.
	TIP:
	If the text is cut of on some DesktopIcons (too long) simply make this setting larger!! 

xDesktopItemHeight (number)
	This command specifies the height of each DesktopItem [Icon + Text] If no value is provided 
	then the default is 75.
	TIP:
	If the text is cut of on some DesktopIcons (too high) simply make this setting larger!! 

xDesktopSpacingX (number)
	This command specifies the horizontal space between each DesktopItem.
	Note: 	The distance is calculated between the xDesktopItemWidth. 
			If no value is provided then the default is 0. 

xDesktopSpacingY (number)
	This command specifies the vertical space between each DesktopItem.
	Note: 	The distance is calculated between the xDesktopItemHeight.
			If no value is provided then the default is 0. 

xDesktopDirection "left", "right", "up", or "down"
	The direction to draw the icons in. Defaults to "right". 

xDesktopWrapDirection "up", "down", "left", or "right"
	Direction to wrap the icons in. Defaults to "down".
	Note: If Direction is set to right or left, WrapDirection must be up or down and vice versa. 

xDesktopWrapCount (number)
	Number of icons to display before wrapping to the next line or column. If no value is 
	provided then the default is automatically calculated. 

xDesktopMoveable
    If this command is set to FALSE, then the DesktopIcons aren't moveable.
    Default: true
    
xDesktopSnapTo (x) (y) (cx) (cy) (snapdistance)
    If ALL FIVE values are defined, the DesktopIcons Snap To a virtual Grid (with Left|Top),
    if moved. The Grid Lines starts at "x" and "y" and are repeated every "cx" and "cy".
    "snapdistance" is the distance, values between 5 and 10 normally work best.
    
xDesktopEasyFocus
    If this command is present, then the DesktopIcon are visually selected, if the mouse hovers on them.
    Default: false

-------------------
Desktop Item Layout
-------------------

xDesktopNoSystemContextMenu 
    If set, ONLY the four SystemIcons have no ContextMenu!
    (Problems on some Systems, so you can now simply deactivate it and be sure of crashes!)

xDesktopNoWorkspace
    If set, Workspace Icon isn't shown

xDesktopNoMyDocuments
    If set, MyDocuments Icon isn't shown

xDesktopNoNetwork
    If set, Network Icon isn't shown

xDesktopNoTrashcan
    If set, Trashcan Icon isn't shown

xDesktopNoIcon
    If set, a  TextOnly Desktop"Icon" is shown ;)
    Make sure you use a xDesktopTextBackground (default is Gray)!!
           
xDesktopIconsize (number)
	This command specifies the Size (Width/Height) of the displayed Icon.
	Minimum: 16
	Maximum: 64
	If no value is provided then the default is 32. 
	
xDesktopUseSmallIcon
    The base image for the displayed File-Icon is extracted with 16x16 instead of 32x32.
    
xDesktopNoActiveIconColor BOOL
    If set, the Active Icon don't get the Default Blueish overlay, best, if someone wants to
    use manually Hueing for Active Icons (see below).

xDesktopAlphaTransparency INT
    Sets the "FAKE" Alphatransparency (0-255) of the Normal DesktopIcon.       

xDesktopActiveAlphaTransparency INT
    Sets the "FAKE" Alphatransparency (0-255) of the Active DesktopIcon. 
                      
xDesktopSaturationIntensity (number)
	This command specifies the color saturation of the DesktopIcons.
	Minimum: 0 -> Grayscale
	Maximum: 255 -> Full Colored (Default)

xDesktopHueIntensity (number)
	This command specifies the amount of the, in the DesktopIcons, blended in color.
	Minimum: 0 -> Nothing (Default)
	Maximum: 255 

xDesktopHueColor (color)
	This command specifies the blended in color in the DesktopIcons

xDesktopActiveSaturationIntensity INT
    Sets the Saturation of the Active DesktopIcon. Default is Normal SaturationIntensity.
    Minimum: 0 -> Grayscale
	Maximum: 255 -> Full Colored
	Default is "xDesktopSaturationIntensity"
	       
xDesktopActiveHueIntensity INT
    This command specifies the amount of the, in the active DesktopIcons, blended in color.
    Minimum: 0 -> Nothing 
	Maximum: 255 
	Default is "xDesktopHueIntensity"
           
xDesktopActiveHueColor COLOR
    This command specifies the amount of the, in the active DesktopIcons, blended in color.
          
xDesktopShowExtensions BOOL or "ExclusionList"
    All extensions, which aren't LNK-Files are shown by default, to disable them completely use
    xDesktopShowExtensions FALSE
           
    If the ExclusionList is set, the specified extensions will never be shown, all others will be displayed!
    ExclusionList Syntax:
    ".bat|.pif|....."

xDesktopLinkOverlayIcon "shell32.dll,29"
    LNK-Files do have the standard overlay Icon ( Small Arrow ) by default ("shell32.dll,29").
    You can use any other Icon as LNK-Overlay Icon or remove it by setting "" as xDesktopLinkOverlayIcon.
                      
xDesktopNoLineBreak BOOL
    If set, the Text is at the end of the ItemWidth is not wrapped, just cut off with "...".
            
xDesktopTextPosition "top", "bottom", "left", or "right"
	This command specifies the position of the Icon Text relative to the icon. If no value 
	is provided then the default is "bottom". 

xDesktopTextBackground (color) [(color)] [(color)]
	If set, this color will be used to paint a box behind the text. If no value is provided 
	or set to "ff00ff" the default is blank (no box is painted). With the optional second and 
	third color you can specify a bevel around the textbox. Second ist the light color, third 
	the dark color. 
	
xDesktopActiveTextBackground (color) [(color)] [(color)]
	If set, this color will be used to paint a box behind the text, if the Icon is active.
	If no value is provided or set to "ff00ff" the default is blank (no box is painted). 
	With the optional second and third color you can specify a bevel around the textbox. 
	Second ist the light color, third the dark color. 

xDesktopTextBackgroundGradientColors [(color)] [(color)] ...
    Sets the colors of the Normal Gradient Painting, first color of the Gradient is the TextBackground (automatically set),
    then optional as many colors as you need.

xDesktopActiveTextBackgroundGradientColors [(color)] [(color)] ...
    Sets the colors of the Active Gradient Painting, first color of the Gradient is the ActiveTextBackground (automatically set),
    then optional as many colors as you need.

xDesktopTextBackgroundGradientVertical BOOL
    If set, the Normal Gradient is painted vertical instead of horizontal.

xDesktopActiveTextBackgroundGradientVertical BOOL
    If set, the Active Gradient is painted vertical instead of horizontal.
           
xDesktopTextBackgroundGradientRepeated INT
    INT specifies how big (in pixels) each plain color of the gradient shall be.

xDesktopActiveTextBackgroundGradientRepeated INT
    INT specifies how big (in pixels) each plain color of the active gradient shall be.
           
xDesktopTextSpacing (number)
	Distance between the icon and the textbox. If no value is provided then the default is 5. 

xDesktopTextBorder INT
    The Border inside the Textbackground, where no Text is painted ( looks simply better then before :) )
    If no value is set the Default is 3.
           
xDesktopStartHidden
	If this command is present then the DesktopItems will be initially invisible. They can 
	later be shown using bang commands "!xdesktopshow" or "!xdesktoptoggle". 

xDesktopFont (font)
	Sets the name of the font used to display text. If no value is provided then the default is "Arial". 

xDesktopActiveFont (font)
	Sets the name of the active font used to display text. If no value is provided then the default is xDesktopFont. 

xDesktopFontCharSet CHARSET
    Mostly for Eastern Fonts, most people will never use this.
    DEFAULT_CHARSET
    ANSI_CHARSET
    BALTIC_CHARSET
    CHINESEBIG5_CHARSET
    EASTEUROPE_CHARSET
    GB2312_CHARSET
    GREEK_CHARSET
    HANGUL_CHARSET
    MAC_CHARSET
    RUSSIAN_CHARSET
    SHIFTJIS_CHARSET
    SYMBOL_CHARSET
    TURKISH_CHARSET
    VIETNAMESE_CHARSET
    JOHAB_CHARSET
    ARABIC_CHARSET
    HEBREW_CHARSET
    THAI_CHARSET
    OEM_CHARSET 
           
xDesktopActiveFontCharSet CHARSET
    Mostly for Eastern Fonts, most people will never use this.
    DEFAULT_CHARSET
    ANSI_CHARSET
    BALTIC_CHARSET
    CHINESEBIG5_CHARSET
    EASTEUROPE_CHARSET
    GB2312_CHARSET
    GREEK_CHARSET
    HANGUL_CHARSET
    MAC_CHARSET
    RUSSIAN_CHARSET
    SHIFTJIS_CHARSET
    SYMBOL_CHARSET
    TURKISH_CHARSET
    VIETNAMESE_CHARSET
    JOHAB_CHARSET
    ARABIC_CHARSET
    HEBREW_CHARSET
    THAI_CHARSET
    OEM_CHARSET 
    
xDesktopFontHeight (number)
	Sets the height of the font used to display the text in pixels. If no value is provided 
	then the default is 15. 

xDesktopActiveFontHeight (number)
	Sets the height of the active font used to display the text in pixels. If no value is provided 
	then the default is xDesktopFontHeight. 

xDesktopFontBold
	If this command is present then the font will be bold. 

xDesktopActiveFontBold
	If this command is present then the active font will be bold. 

xDesktopFontItalic
	If this command is present then the font will be italic. 
	
xDesktopActiveFontItalic
	If this command is present then the active font will be italic. 

xDesktopFontUnderline
	If this command is present then the font will be underlined. 
	
xDesktopActiveFontUnderline
	If this command is present then the active font will be underlined. 

xDesktopFontColor (color)
	Sets the color of the font used to display the text. If no value is provided then the 
	default is black (RGB 0, 0, 0). 
	
xDesktopActiveFontColor (color)
	Sets the color of the font used to display the text. If no value is provided then the 
	default is xDesktopFontColor. 

xDesktopFontShadow
	If this command is present then the font will be shadowed. 
	
xDesktopActiveFontShadow
	If this command is present then the active font will be shadowed.

xDesktopFontShadowColor (color)
	Sets the color used to display the text shadow. If no value is provided then the default 
	is dark gray (RGB 128, 128, 128). 
	
xDesktopActiveFontShadowColor (color)
	Sets the color used to display the text shadow. If no value is provided then the default 
	is xDesktopFontShadowColor. 

xDesktopFontShadowX (number)
	Sets the number of pixels in the horizontal direction that the shadow is offset 
	from the rest of the text; this can be negative. If no value is provided then the default is 1. 
	
xDesktopActiveFontShadowX (number)
	Sets the number of pixels in the horizontal direction that the shadow is offset 
	from the rest of the text; this can be negative. If no value is provided then the default is xDesktopFontShadowX. 

xDesktopFontShadowY (number)
	Sets the number of pixels in the vertical direction that the shadow is offset from 
	the rest of the text; this can be negative. If no value is provided then the default is 1. 

xDesktopActiveFontShadowY (number)
	Sets the number of pixels in the vertical direction that the shadow is offset from 
	the rest of the text; this can be negative. If no value is provided then the default is xDesktopFontShadowY. 
	
xDesktopFontOutline 
    If this is set it makes a special Shadow, an 1 Pixel OutLine around the whole letter.
    You cannot have a Normal Shadow together with a Outline!
    
xDesktopActiveFontOutline 
    If this is set it makes a special Shadow, an 1 Pixel OutLine around the whole letter.
    You cannot have a Normal Shadow together with a Outline!

xDesktopFontOutlineColor (color)
    Sets the color used to display the text outline. If no value is provided then the default is
    dark gray (RGB 128, 128, 128).
    
xDesktopActiveFontOutlineColor (color)
    Sets the color used to display the text outline. If no value is provided then the default is
    xDesktopFontOutlineColor.
    
xDesktopBalloonTooltip 
    If set, a balloontooltip with Info Icon and Title "Icon Info:" will be used.
    
xDesktopTooltipDurations (number) (number)
    The first INT value specifies in ms, how long the mouse must remain stationary within a Icon for the tooltip to show up.
    The second INT value specifies in ms, how long the toolwindow is shown. 

xDesktopTooltipColor (color)
    Color of the Tooltip background.

xDesktopTooltipTextColor (color)
    Color of the Tooltip text.

TIP:
	To remove Text simply set the ItemHeight = IconSize in Top/Bottom Textposition or 
	ItemWidth = IconSize in Left/Right Textposition

----------------------
Desktop Mouse Actions
----------------------

Attention: ".move" only works for ONE Button (last defined with ".move" will become the Movebutton)!

xDesktopOnLeftClick (.none|.move|.open|.properties|.context)
    This command specifies the Action, when you use the Left MouseButton on a DesktopIcon.
    Default: .move

xDesktopOnMiddleClick (.none|.move|.open|.properties|.context)
    This command specifies the Action, when you use the Middle MouseButton on a DesktopIcon.
    Default: .properties

xDesktopOnRightClick (.none|.move|.open|.properties|.context)
    This command specifies the Action, when you use the Right MouseButton on a DesktopIcon.
    Default: .context

xDesktopOnLeftDoubleClick (.none|.open)
    This command specifies the Action, when you perform a LeftDoubleClick on a DesktopIcon.
    Default: .open

xDesktopOnMiddleDoubleClick (.none|.open)
    This command specifies the Action, when you perform a LeftDoubleClick on a DesktopIcon.
    Default: .none

xDesktopOnRightDoubleClick (.none|.open)
    This command specifies the Action, when you perform a RightDoubleClick on a DesktopIcon.
    Default: .none

---------------------------------
Bang Commands for "Desktop Items"
---------------------------------

!xDesktopCreate replace ".desktop"
	If you specify ".desktop", this automatically Creates/REPOSITIONS your complete Desktop.
	Both, in Normal Mode and in xDesktopAutoCreate Mode!! 
	
!xDesktopCreate update ".desktop"
	If you specify ".desktop", this automatically Updates your complete Desktop.
	Both, in Normal Mode and in xDesktopAutoCreate Mode!!
	Use this only if your DesktopItems have changed, when the Tracker didn't run! Not for 
	"Creating" your Desktop. Normally, if you use "xDesktopAutoCreate" this Bang is superfluous. 

!xDesktopCreate "append"|"replace"|"update" "(Quoted Path to Folder)"
	Creates/Changes/Removes the *xdesktopitem lines for every File/Folder found in the specified folder (eg.: $desktop$).
	"append" : 	Keep already present *xdesktopitem lines and append all new ones.
	"replace" : Delete all present *xdesktopitem lines and add only new ones.
	"update" : 	Updates *xdesktopitem lines according to current state (Add & Remove).

ATTENTION:
	xDesktopConfigFile MUST be specified AND Path MUST be enclosed in '" "'.
	If you have set xDesktopAutoCreate then all appended/added DesktopItems, 
	which aren't on your Desktop will be removed on the next recycle! 

The following Bangs affect all DesktopItems at once and are quite obvious:
!xDesktopDestroy 	<- Destroys the Desktop
!xDesktopShow 		<- Shows the Desktop
!xDesktopHide 		<- Hides the Desktop 
!xDesktopToggle 	<- Toggles the Desktop Visibility



-----------------------------------------------------------------------------
Changes for xDesktop
-----------------------------------------------------------------------------

1.7.6 Released on 16-10-2005, Changes by Andymon

- Fixed:   Background Position Problem with WinXP and newer OS.

1.7.5 Released on 28-08-2005, Changes by Andymon

- Added:   xDesktopNoIcon BOOL
           TextOnly Desktop"Icon" ;)
           Make sure you use a xDesktopTextBackground (default is Gray)!!
           
- Added:   xDesktopAddPositionX INT
           xDesktopAddPositionY INT
           You can customize the position where new Icons are displayed the first time.

- Added:   xDesktopTextBackgroundGradientRepeated INT
           xDesktopActiveTextBackgroundGradientRepeated INT
           INT specifies how big (in pixels) each plain color of the gradient shall be.
           
- Added:   xDesktopFontCharSet CHARSET
           xDesktopActiveFontCharSet CHARSET
           Mostly for Eastern Fonts, most people will never use this.
           DEFAULT_CHARSET
           ANSI_CHARSET
           BALTIC_CHARSET
           CHINESEBIG5_CHARSET
           EASTEUROPE_CHARSET
           GB2312_CHARSET
           GREEK_CHARSET
           HANGUL_CHARSET
           MAC_CHARSET
           RUSSIAN_CHARSET
           SHIFTJIS_CHARSET
           SYMBOL_CHARSET
           TURKISH_CHARSET
           VIETNAMESE_CHARSET
           JOHAB_CHARSET
           ARABIC_CHARSET
           HEBREW_CHARSET
           THAI_CHARSET
           OEM_CHARSET

- Added:   xDesktopShowExtensions BOOL or "ExclusionList"
           All extensions, which aren't LNK-Files are shown by default, to disable them completely use
           xDesktopShowExtensions FALSE
           
           If the ExclusionList is set, the specified extensions will never be shown, all others will be displayed!
           ExclusionList Syntax:
           ".bat|.pif|....."
           
- Added:   xDesktopLinkOverlayIcon "shell32.dll,29"
           LNK-Files do have the standard overlay Icon ( Small Arrow ) by default ("shell32.dll,29").
           You can use any other Icon as LNK-Overlay Icon or remove it by setting "" as LinkOverlayIcon.
          
- Changed: IF a TextBackground is used the Text has Antialiasing(ClearType) enabled, and only then!

1.7 Released on 18-05-2005, Changes by Andymon

Info: After a long time, i've added some missing features. :)

- Added:   If a TextBackground is used, it matches the needed rectangle around the Text.
           (If something is cut off, enlarge the xDesktopItemWidth/Height!)

- Added:   xDesktopBalloonTooltip
           If set, a balloontooltip with Info Icon and Title "Icon Info:" will be used.

- Added:   xDesktopTooltipDurations INT INT
           The first INT value specifies in ms, how long the mouse must remain stationary within a Icon for the tooltip to show up.
           The second INT value specifies in ms, how long the toolwindow is shown. 

- Added:   xDesktopTooltipColor COLOR
           Color of the Tooltip background.

- Added:   xDesktopTooltipTextColor COLOR
           Color of the Tooltip text.

- Added:   All Font Settings have now an "Active" State, like the Icon or TextBackground.
           xDesktopActiveFont (font)
           xDesktopActiveFontHeight (number)
           xDesktopActiveFontBold
           xDesktopActiveFontItalic
           xDesktopActiveFontUnderline
           xDesktopActiveFontColor (color)
           xDesktopActiveFontShadow
           xDesktopActiveFontShadowColor (color)
           xDesktopActiveFontShadowX (number)
           xDesktopActiveFontShadowY (number)
           xDesktopActiveFontOutline 
           xDesktopActiveFontOutlineColor (color)
           
           Default is always the "Normal" State.

- Fixed:   SolidColorGradients are now as correct as possible, also if more then 3 Gradient Colors are used.

1.6.5 Released on 08-12-2004, Changes by Andymon

  Info:    For a new release that deserves a new version number i have added "FAKE" AlphaTransparency :)
           Cause its only Fake, it works also under Win9x/Me!
           The Transparent Background ISN'T updated during a Drag'n'Drop (That's no BUG!)

- Added:   xDesktopAlphaTransparency INT
           Sets the Alphatransparency (0-255) of the Normal DesktopIcon.       

- Added:   xDesktopActiveAlphaTransparency INT
           Sets the Alphatransparency (0-255) of the Active DesktopIcon. 
                 
- Fixed:   Silly XP AlphaChannel Icon Bug :|

1.6 Released on 05-12-2004, Changes by Andymon

- Added:   xDesktopNoSystemContextMenu 
           If set, ONLY the four SystemIcons have no ContextMenu!
           (Problems on some Systems, so you can now simply deactivate it and be sure of crashes!)
    
- Added:   xDesktopNoLineBreak BOOL
           If set, the Text is at the end not wrapped, just cut with "...".

- Added:   xDesktopTextBorder INT
           The Border inside the Textbackground, where no Text is painted ( looks simply better then before :) )
           If no value is set the Default is 3.
           
- Added:   xDesktopActiveTextBackground (color) [(color)] [(color)]
           Textbackground for the Active State.

- Added:   xDesktopTextBackgroundGradientColors [(color)] [(color)] ...
           Sets the colors of the Normal Gradient Painting, first color of the Gradient is the TextBackground (automatically Set),
           then optional as many colors as you need.

- Added:   xDesktopActiveTextBackgroundGradientColors [(color)] [(color)] ...
           Sets the colors of the Active Gradient Painting, first color of the Gradient is the ActiveTextBackground (automatically Set),
           then optional as many colors as you need.

- Added:   xDesktopTextBackgroundGradientVertical BOOL
           If set, the Normal Gradient is painted vertical instead of horizontal.

- Added:   xDesktopActiveTextBackgroundGradientColors BOOL
           If set, the Active Gradient is painted vertical instead of horizontal.
           
- Changed: Internals optimized and cleaned up for more speed.

- Fixed:   ZOrder problems! Simply load xDesktop as first module after your Desktop Module and the Icons are
           always under all other Modules.

- Fixed:   Calling !xDesktopDestroy hadn't saved positions.

- Fixed:   System Icon ContextMenus (more stable, more correct), if problems occur simply deactivate SystemIcon ContextMenus with
           "xDesktopNoSystemContextMenu"
           
- Fixed:   Snapping sometimes wasn't perfect, it snapped to strange positions, jumped around.
           
- Fixed:   Not defined $commondesktopdir$ under Win9x/Me had made problems with xDesktopAutoCreate and !xDesktopcreate replace/update .desktop

- Fixed:   xDesktopX and xDesktopY support now '-', 'c' and '~' for initial positioning of the First Icon.

- Fixed:   Under XP the Icons are now Cut out Completely, based on Mask (no longer square DesktopCopy).

- Fixed:   xDesktopSnapTo wasn't mentioned in the ReadMe

- Fixed:   Snapped positions weren't exactly saved (position before Snap was used)

1.5 Released on 28-10-2004, Changes by Andymon

- Fixed:   HighColor(16bit|24bit) support ( and even 256 Colors ;) )

1.4.5 Released on 21-10-2004, Changes by Andymon

- Fixed:   Icons update now dynamically (Trashcan Empty/Full).
           Simply click it (or use xDesktopEasyFocus for simply hover on it) to update.

- Fixed:   Reduced RAM and GDI-Objects again (drastic).

- Fixed:   RightClick Chasing DesktopIcons ;)

1.4 Released on 19-10-2004, Changes by Andymon

- Added:   xDesktopNoActiveIconColor BOOL
           If set the Active Icon don't get the Default Blueish overlay, best, if someone wants to
           use manually Hueing for Active Icons (see below).

- Added:   xDesktopActiveSaturationIntensity INT
           Sets the Saturation of the Active DesktopIcon. Default is Normal SaturationIntensity.
           
- Added:   xDesktopActiveHueIntensity INT
           Sets the HueIntensity of the Active DesktopIcon. Default is Normal HueIntensity.
           
- Added:   xDesktopActiveHueColor COLOR
           Sets the HueColor of the Active DesktopIcon. Default is Normal HueColor.
           
- Fixed:   Too long Texts, which have no LineBreak, now have a ... instead of being cut off on both sides.

- Fixed:   Moving smoothed and enhanced.
           
- Fixed:   Reduced used GDI-Objects by 50% ;)

1.3 Released on 11-08-2004, Changes by Andymon

- Added:   xDesktopFontOutLine
           Makes a special Shadow, an 1 Pixel OutLine around the whole letter.
           You cannot have a Normal Shadow together with a Outline!
           
- Added:   xDesktopFontOutLineColor (color)
           Defines the Color of the OutLine.
           
- Changed: Moving + SnapTo:
           Visually Enhanced SnapTo, no longer shaking and need to "torn away" from Snapped Position :)

- Changed: Colorized DesktopIcons can now have any size, not only 32x32

1.2 Released on 24-06-2004, Changes by Andymon

- Added:   ContextMenu of DesktopIcon have gotten an Additional Menu Entry
           "Remove LS DesktopIcon"
           Calling this MenuPoint removes the DesktopIcon from xDesktop,
           but leaves the Original File unchanged.
           
- Added:   xDesktopUseSmallIcon
           The base image for the displayed File-Icon is extracted with 16x16 instead of 32x32.

- Changed: Some internal optimizations for more speed with Saturation and Hueing.

- Fixed:   GDI Leaks on Recycle, I never checked before!

1.1 Released on 14-06-2004, Changes by Andymon
 
- Added:   xDesktopNoWorkSpace
           xDesktopNoMyDocuments
           xDesktopNoNetwork
           xDesktopNoTrashcan
           If set, simply deactivates the Special Desktop items.
           Attention: Requires a !recycle and a !xdesktopcreate "update" ".desktop"
                      to take effect!
                      
- Added:   xDesktopEasyFocus
           If set, Hovering a DesktopIcon gives active state (visually).
           
- Added:   xDesktopMoveable 
           If set to FALSE the DesktopIcons are fixed. Default: TRUE
           But if you didn't set .move for one MouseButton you have the same effect!
           
- Added:   xDesktopOnLeftClick (action)   <- Default: .move
           xDesktopOnMiddleClick (action) <- Default: .properties
           xDesktopOnRightClick (action)  <- Default: .context
          
           -> Action can be: .open       -> To Execute File
                             .move       -> To Move with That MouseButton
                             .context    -> To Open ContextMenu
                             .properties -> To Open Properties
                             .none       -> To Deactivate
           
           xDesktopOnLeftDoubleClick (action)   <- Default: .open
           xDesktopOnMiddleDoubleClick (action) <- Default: .none
           xDesktopOnRightDoubleClick (action)  <- Default: .none
           
           -> Action can be: .open       -> To Execute File
                             .none       -> To Deactivate

- Fixed:   Old! and Huge Memory Leak, if you Move DesktopIcons!
           Why has noone ever realized it (me also)? Thanks go to Matt.
           
           