///////////////////////
// Wharfanoid V1.0
// Written By: MrJukes
// Graphics By: Floach

// Installation
1) Unzip Wharfanoid.app to your Litestep directory (c:\litestep)
2) Unzip Wharfanoid.bmp to your Images directory (c:\litestep\images)
3) Edit your step.rc to look something like this-
	*Wharf Wharfanoid Wharfanoid.bmp @c:\Litestep\Wharfanoid.app

// Game Play
Left click to start a game.
Left click again to pause.
Left click again to resume.
Silver blocks take two hits to destroy.
All others take one.
You get 3 lives.
Once you lose 3 lives, your level gets set back to 1.

// modules.ini

	[Wharfanoid]
	// The color of the paddle: Format 0x00BBGGRR
	PaddleColor=0x00FFFFFF

	// The color of the ball: Format 0x00BBGGRR
	BallColor=0x00FFFFFF

	// The color of Row 1
	Line1Color=0x00FF0000

	// The color of Row 2
	Line2Color=0x0000FF00

	// The color of Row 3
	Line3Color=0x000000FF

	// The color of Row 4
	Line4Color=0x00FFFF00

	// The initial speed of the ball (1-4)
	BallSpeed=3

	// Demo Mode: 1=Yes 0=No	
	Demo=1

// Popup Menu
	// Speeds - Slow, Medium, Fast, Insane
	// Demo Mode - Toggles Demo Mode
	// About Wharfanoid - Brings up Wharfanoid About Dialog
	// Level: 1 - Tells you what level you are currently on.
	// This resets after you lose your 3 lives.

// Known bugs
 - I wouldn't recommend having WharfPong 1.3 or lower and Wharfanoid in the wharf at the same time
   they seem to have a cursor war.  This will be fixed in WharfPong 1.4.

Have fun,
	MrJukes