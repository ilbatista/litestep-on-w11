#include <string>
#include <list>
#include <fstream>
/*
ok I know this is real bad coding and I will change it when I get around 
to it but this was about 5 minutes of work just to get files working so I could
test how the rest of it works

provides:
readlist(const char * filename)		reads variables from filename
data queryvalue(string s)			returns a struct data that contains a variable 
									corresponding to s
void savevar(data d)				saves a variable to the list for future searching 
void savelist(const char *filename)	saves variables to filename

file structure:
files read by this need to be in the following structure 

varname value
varname2 value
;;;
the rest of the file

lines that do not begin with a letter or underscore are not parsed
variables cannot begin with a number but if they do, they will be read into
the list, they will not however be able to be used in an equation spaces are 
ignored except where required

Parsing stops before the end of the file when a line is reached that starts
with ;;; so any variables that are not numbers or are not in acceptable format
can still be placed in the file

also lines that start with the following are not parsed:
IF
ENDIF
ELSE


  

  
	


  
	
file is case sensitive and I plan on keeping it that way
*/

#ifndef DATASTRUCT

struct data {//all data variables are initialized to be the integer 0
	union {
		double value;
		int op;
	};
	std::string var;//variable name, if exists
	bool isop,isint,unary;
	data() {value=0;isop=false;isint=true;var="";unary=false;};
};
#define DATASTRUCT
#endif

struct data2 {
	data d;
	std::string line;
	bool read;
};
std::list<data2> varlist;

void readlist(const char *filename) {
	std::ifstream file(filename);
	std::string temp;
	data2 d;
	int ct;
	std::getline(file,d.line);
	file.ignore();
	ct=0;
	varlist.clear();
	if(!d.line.length()) return;
	while(file && d.line.substr(0,3)!=";;;") {
		ct=0;
		temp="";
		d.read=false;
		while(d.line.c_str()[ct]==' ' || d.line.c_str()[ct]=='	') ++ct;
		if(((d.line.c_str()[ct]>='A' && d.line.c_str()[ct]<='Z') || 
		   (d.line.c_str()[ct]>='a' && d.line.c_str()[ct]<='z') || 
		   d.line.c_str()[ct]=='_') && d.line.substr(0,2)!="IF" && 
		   d.line.substr(0,4)!="ELSE" && d.line.substr(0,5)!="ENDIF") {
			d.read=true;
			while((d.line.c_str()[ct]>='A' && d.line.c_str()[ct]<='Z') || 
				  (d.line.c_str()[ct]>='a' && d.line.c_str()[ct]<='z') || 
				  (d.line.c_str()[ct]>='0' && d.line.c_str()[ct]<='9') || d.line.c_str()[ct]=='_') {
				temp+=d.line.c_str()[ct];
				++ct;
			}
			d.d.var=temp;
			temp="";
			while(d.line.c_str()[ct]==' ' || d.line.c_str()[ct]=='	') ++ct;
			while(d.line.c_str()[ct]>='0' && d.line.c_str()[ct]<='9') {
				temp+=d.line.c_str()[ct];
				++ct;
			}
			if(d.line.c_str()[ct]=='.') {
				temp+=d.line.c_str()[ct];
				++ct;
				d.d.isint=false;
			}
			while(d.line.c_str()[ct]>='0' && d.line.c_str()[ct]<='9') {
				temp+=d.line.c_str()[ct];
				++ct;
			}
			d.d.value=atof(temp.c_str());
		}
		varlist.push_back(d);
		std::getline(file,d.line);
		file.ignore();
	}
	while(file) {//get the rest of the file
		varlist.push_back(d);
		std::getline(file,d.line);
		file.ignore();
	}
	file.close();
}
	

data queryvalue(std::string s) {
	for (std::list<data2>::const_iterator cti = varlist.begin(); cti!=varlist.end(); cti++) {
		if((*cti).d.var==s) return (*cti).d;
	}
	data zero;
	return zero;
}

void savevar(data d) {
	for (std::list<data2>::iterator cti = varlist.begin(); cti!=varlist.end(); cti++) {
		if((*cti).d.var==d.var) {
			(*cti).d=d;
			return;
		}
	}
}
void savelist(const char *filename) {
	std::ofstream file(filename);
	for (std::list<data2>::iterator cti = varlist.begin(); cti!=varlist.end(); cti++) {
		if((*cti).read) {
			if((*cti).d.isint) file<<(*cti).d.var<<'	'<<int((*cti).d.value)<<std::endl;
			else file<<(*cti).d.var<<'	'<<(*cti).d.value<<std::endl;
		} else file<<(*cti).line<<std::endl;
	}
	file.close();
}