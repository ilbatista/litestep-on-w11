#include <string>
#include <list>
//#include <iostream>

#include "fileio.h"

/*** this header provides the following:
struct data			contains a token of data, either an operand or an operation
	double value	if struct contains an operand, its value is here
	int op			if struct contains an operation, its code is here
	string var		if struct contains an operand and that operand came from a 
					variable the variable's name is stored here
	bool isop		true if operation
	bool isint		true if value is an integer
	bool unary		true if operation and operation is unary
					(only affects one operand)

data equation(list<data>)	solves the equation provided by list
int equation.error			1 if there was an error solving equation 0 else
list<data> tokenize(string) tokenizes the equation so that equation() can use it
string tostr(int)			for user output of the operators

//*/
#ifndef DATASTRUCT

struct data {//all data variables are initialized to be the integer 0
	union {
		double value;
		int op;
	};
	std::string var;//variable name, if exists
	bool isop,isint,unary;
	data() {value=0;isop=false;isint=true;var="";unary=false;};
};
#define DATASTRUCT
#endif

class matheq {
public:
	matheq() {precedencemod=0; error=0; eqcalc.clear(); eqoperations.clear();};
	data operator() (std::list<data>);
	int error;
private:
	std::list<data> eqcalc;
	std::list<data> eqoperations;
	int precedencemod;
	void doop();//does the top operation in eqoperations and uses the top needed variables in eqcalc
	int precedence(int,int);
} equation;

std::list<data> tokenize(std::string);
std::string tostr(int i);


std::list<data> tokenize(std::string s) {
	std::list<data> l;
	std::string temp;
	data tempdata;
	int ct=0;
	while(ct<s.length()) {
		temp="";
		tempdata.unary=false;
		tempdata.isint=true;
		tempdata.isop=false;
		tempdata.value=0;
		tempdata.var="";
		if(s.c_str()[ct]>='0' && s.c_str()[ct]<='9') {
			//temp is a number
			while(s.c_str()[ct]>='0' && s.c_str()[ct]<='9') {
				temp+=s.c_str()[ct];
				++ct;
			}
			if(s.c_str()[ct]=='.') {
				temp+=s.c_str()[ct];
				++ct;
				tempdata.isint=false;
			}
			while(s.c_str()[ct]>='0' && s.c_str()[ct]<='9') {
				temp+=s.c_str()[ct];
				++ct;
			}
			tempdata.value=atof(temp.c_str());
			l.push_back(tempdata);
			--ct;
		} else if((s.c_str()[ct]>='A' && s.c_str()[ct]<='Z') || 
			      (s.c_str()[ct]>='a' && s.c_str()[ct]<='z') || s.c_str()[ct]=='_') {
			while((s.c_str()[ct]>='A' && s.c_str()[ct]<='Z') || 
				  (s.c_str()[ct]>='a' && s.c_str()[ct]<='z') || 
				  (s.c_str()[ct]>='0' && s.c_str()[ct]<='9') || s.c_str()[ct]=='_') {
				temp+=s.c_str()[ct];
				++ct;
			}
			//temp is a variable that represents a number
			tempdata=queryvalue(temp);
			tempdata.var=temp;
			l.push_back(tempdata);
			--ct;
		} else if(s.c_str()[ct]!=' ') {//operation
			tempdata.isop=true;
			switch(s.c_str()[ct]) {
			case '(':
				tempdata.op=100;
				break;
			case ')':
				tempdata.op=101;
				break;
			case '!':
				tempdata.op=1;
				tempdata.unary=true;
				break;
			case '~':
				tempdata.op=2;
				tempdata.unary=true;
				break;
			case '*':
				tempdata.op=3;
				break;
			case '%':
				tempdata.op=4;
				break;
			case '/':
				tempdata.op=5;
				break;
			case '+':
				if(ct==0) {
					tempdata.unary=true;
				} else if(l.back().isop) {
					tempdata.unary=true;
				}
				tempdata.op=6;
				break;
			case '-':
				if(ct==0) {
					tempdata.unary=true;
				} else if(l.back().isop) {
					tempdata.unary=true;
				}
				tempdata.op=7;
				break;
			case '^':
				tempdata.op=8;
				break;
			case '<':
				tempdata.op=9;
				break;
			case '>':
				tempdata.op=10;
				break;
			case '=':
				tempdata.op=11;
				break;
			case '&':
				tempdata.op=12;
				break;
			case '|':
				tempdata.op=13;
				break;
			}
			switch(s.c_str()[ct+1]) {
			case '<':
				if(s.c_str()[ct]=='<') {
					tempdata.op=14;
					if(s.c_str()[ct+2]=='=') tempdata.op+=17;
				}
				break;
			case '>':
				if(s.c_str()[ct]=='>') {
					tempdata.op=15;
					if(s.c_str()[ct+2]=='=') tempdata.op+=17;
				}
				break;
			case '=':
				if(tempdata.op>0 && tempdata.op<14) tempdata.op+=15;
				break;
			case '&':
				if(s.c_str()[ct]=='&') tempdata.op=29;
				break;
			case '|':
				if(s.c_str()[ct]=='|') tempdata.op=30;
				break;
			}
			if(tempdata.op>13 && tempdata.op<100) ++ct;
			if(tempdata.op>30 && tempdata.op<100) ++ct;
			l.push_back(tempdata);
		}// if it wasn't mentioned above it is treated as whitespace
		++ct;
	}
	return l;
}
std::string tostr(int i) {
	std::string s("");
	switch(i) {
	case 100:
		s="(";
		break;
	case 101:
		s=")";
		break;
	case 1:
		s="!";
		break;
	case 2:
		s="~";
		break;
	case 3:
		s="*";
		break;
	case 4:
		s="%";
		break;
	case 5:
		s="/";
		break;
	case 6:
		s="+";
		break;
	case 7:
		s="-";
		break;
	case 8:
		s="^";
		break;
	case 9:
		s="<";
		break;
	case 10:
		s=">";
		break;
	case 11:
		s="=";
		break;
	case 12:
		s="&";
		break;
	case 13:
		s="|";
		break;
	case 14:
		s="<<";
		break;
	case 15:
		s=">>";
		break;
	case 16:
		s="!=";
		break;
	case 17:
		s="~=";
		break;
	case 18:
		s="*=";
		break;
	case 19:
		s="%=";
		break;
	case 20:
		s="/=";
		break;
	case 21:
		s="+=";
		break;
	case 22:
		s="-=";
		break;
	case 23:
		s="^=";
		break;
	case 24:
		s="<=";
		break;
	case 25:
		s=">=";
		break;
	case 26:
		s="==";
		break;
	case 27:
		s="&=";
		break;
	case 28:
		s="|=";
		break;
	case 29:
		s="&&";
		break;
	case 30:
		s="||";
		break;
	case 31:
		s="<<=";
		break;
	case 32:
		s=">>=";
		break;
	}
	return s;
}
/*
(	100
)	101
!	1
~	2
*	3
%	4
/	5
+	6
-	7
^	8
<	9
>	10
=	11
&	12
|	13
<<	14
<<	15
!=	16
~=	17
*=	18
%=	19
/=	20
+=	21
-=	22
^=	23
<=	24
>=	25
==	26
&=	27
|=	28
&&	29
||  30
<<= 31
>>= 32

*/



data matheq::operator ()(std::list<data> l) {
//data matheq::operator()(std::list<data> l) {
	precedencemod=0;
	error=0;
	eqcalc.clear();
	eqoperations.clear();
	bool allowcalculations=false;
	std::list<data>::iterator lci = l.begin();
	while(lci!=l.end()) {
		if(!lci->isop) {
/*			if(lci->isop) std::cout<<tostr(lci->op)<<' '<<(lci->unary? "true": "false" )<<std::endl;
			else if (lci->isint) std::cout<<int(lci->value)<<std::endl;
			else std::cout<<double(lci->value)<<std::endl;//*/// debug info
			eqcalc.push_front(*lci);
			allowcalculations=true;
		} else if(lci->op==100) {
/*			if(lci->isop) std::cout<<tostr(lci->op)<<' '<<(lci->unary? "true": "false" )<<std::endl;
			else if (lci->isint) std::cout<<int(lci->value)<<std::endl;
			else std::cout<<double(lci->value)<<std::endl;//*/// debug info

			eqoperations.push_front(*lci);
		} else if(lci->op==101) {
			while(eqoperations.size() && eqoperations.front().op!=100) {
				doop();
				eqoperations.pop_front();
			}
			eqoperations.pop_front();
			while(eqoperations.size() && eqoperations.front().unary) {//handle any unary ops
				doop();
				eqoperations.pop_front();
			}
		} else {//if(!(eqoperations.front().unary && (*lci).unary)){//if(precedence(eqoperations.front().op,eqoperations.front().unary)!=1) {//don't do assignement ops in here
			while(eqoperations.size() && eqoperations.front().op!=100 && precedence(eqoperations.front().op,eqoperations.front().unary)>=precedence(lci->op,lci->unary)&&allowcalculations) {
				
				doop();
				eqoperations.pop_front();
			}
			eqoperations.push_front(*lci);
		}
		++lci;
	}
	while(eqoperations.size() && eqoperations.front().op!=100) {
		doop();
		eqoperations.pop_front();
	}
	return eqcalc.front();
}
void matheq::doop() {
//void matheq::doop();//does the top operation in eqoperations and uses the top needed variables in eqcalc
	data d1,d2;
	d1=eqcalc.front();
	eqcalc.pop_front();

//	std::cout<<tostr(eqoperations.front().op)<<' '<<(eqoperations.front().unary? "true": "false" )<<std::endl;
	if(!eqoperations.front().unary) {
		d2=eqcalc.front();
		eqcalc.pop_front();
	}
	switch(eqoperations.front().op) {
	case 100:
	case 101:
		eqcalc.push_front(d2);
		break;//should have never entered
	case 1:
		d1.value=!d1.value;
		break;
	case 2:
		d1.value=~int(d1.value);
		d1.isint=true;
		break;
	case 3:
		if(d1.isint) {
			if(d2.isint) {
				d1.value=int(d1.value)*int(d2.value);
			} else {
				d1.value=int(d1.value)*d2.value;
			}
		} else {
			if(d2.isint) {
				d1.value=d1.value*int(d2.value);
			} else {
				d1.value=d1.value*d2.value;
			}
		}
		break;
	case 4:
		if(d1.isint && d2.isint) d1.value=int(d2.value)%int(d1.value);
		else {
			d1.value=int(d2.value)%int(d1.value);
			d1.isint=true;
			error=1;
		}
		break;
	case 5:
		if(d2.isint) {
			if(d1.isint) {
				d1.value=int(d2.value)/int(d1.value);
			} else {
				d1.value=int(d2.value)/d1.value;
			}
		} else {
			if(d1.isint) {
				d1.value=d2.value/int(d1.value);
			} else {
				d1.value=d2.value/d1.value;
			}
		}
		break;
	case 6:
		d1.value+=d2.value;
		if(!(d1.isint && d2.isint)) d1.isint=false;
		break;
	case 7:
		d1.value=d2.value-d1.value;
		if(!(d1.isint && d2.isint)) d1.isint=false;
		break;
	case 8:
		d1.value=int(d2.value)^int(d1.value);
		if(!(d1.isint && d2.isint)) d1.isint=false;
		break;
	case 9:
		d1.value=(d1.value > d2.value);
		d1.isint=true;
		break;
	case 10:
		d1.value=(d1.value < d2.value);
		d1.isint=true;
		break;
	case 11:
		//d1.value=d2.value;
		d1.isint=d2.isint;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 12:
		d1.value=(int(d2.value) & int(d1.value));
		d1.isint=true;
		break;
	case 13:
		d1.value=(int(d2.value) | int(d1.value));
		d1.isint=true;
		break;
	case 14:
		d1.value=(int(d2.value) << int(d1.value));
		d1.isint=true;
		break;
	case 15:
		d1.value=(int(d2.value) >> int(d1.value));
		d1.isint=true;
		break;
	case 16:
		d1.value=(d2.value != d1.value);
		d1.isint=true;
		break;
	case 17:
		d1.value= ~int(d2.value);
		d1.isint=true;
		savevar(d1);
		break;
	case 18:
		if(d1.isint) {
			if(d2.isint) {
				d1.value=int(d1.value)*int(d2.value);
			} else {
				d1.value=int(d1.value)*d2.value;
			}
		} else {
			if(d2.isint) {
				d1.value=d1.value*int(d2.value);
			} else {
				d1.value=d1.value*d2.value;
			}
		}
		d1.var=d2.var;
		savevar(d1);
		break;
	case 19:
		if(d1.isint && d2.isint) d1.value=int(d2.value)%int(d1.value);
		else {
			d1.value=int(d2.value)%int(d1.value);
			d1.isint=true;
			error=1;
		}
		d1.var=d2.var;
		savevar(d1);
		break;
	case 20:
		if(d2.isint) {
			if(d1.isint) {
				d1.value=int(d2.value)/int(d1.value);
			} else {
				d1.value=int(d2.value)/d1.value;
			}
		} else {
			if(d1.isint) {
				d1.value=d2.value/int(d1.value);
			} else {
				d1.value=d2.value/d1.value;
			}
		}
		d1.var=d2.var;
		savevar(d1);
		break;
	case 21:
		d1.value+=d2.value;
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 22:
		d1.value=d2.value-d1.value;
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 23:
		d1.value=int(d2.value)^int(d1.value);
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 24:
		d1.value=(d2.value <= d1.value);
		break;
	case 25:
		d1.value=(d2.value >= d1.value);
		break;
	case 26:
		d1.value=(d2.value == d1.value);
		break;
	case 27:
		d1.value=int(d2.value)&int(d1.value);
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 28:
		d1.value=int(d2.value)|int(d1.value);
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 29:
		d1.value=(d2.value && d1.value);
		break;
	case 30:
		d1.value=(d2.value || d1.value);
		break;
	case 31:
		d1.value=(int(d2.value) << int(d1.value));
		d1.isint=true;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 32:
		d1.value=(int(d2.value) >> int(d1.value));
		d1.isint=true;
		d1.var=d2.var;
		savevar(d1);
		break;
	}
	eqcalc.push_front(d1);
}
int matheq::precedence(int op,int unary) {
	int i;
	switch(op) {
	case 100:
	case 101:
	case 11:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 23:
	case 27:
	case 28:
	case 31:
	case 32:
		i=1;
		break;
	case 30:
		i=2;
		break;
	case 29:
		i=3;
		break;
	case 13:
		i=4;
		break;
	case 8:
		i=5;
		break;
	case 12:
		i=6;
		break;
	case 16:
	case 26:
		i=7;
		break;
	case 9:
	case 10:
	case 24:
	case 25:
		i=8;
		break;
	case 14:
	case 15:
		i=9;
		break;
	case 6:
	case 7:
		i=10;
		break;
	case 3:
	case 4:
	case 5:
		i=11;
		break;
	case 1:
	case 2:
		i=12;
	}
	if(unary) i=13;
	return i;
}