lsmath by Fallout
ver 0.2

--- sections ---
HOWTO
To come
changes
contact info


--- HOWTO ---
this dll provides 3 bangs:
!mathfile filename
!mathequation equationargs
!mathsave
It is meant to work with mzscript.dll to extend its capabilities

!mathfile filename
changes the file to be used by the dll and the variables that it uses
file is kept until next time !mathfile is called

!mathequation equationargs
a c/c++ style equation that is to be solved

!mathsave
saves the file that is being used by mathfile

example:
$configdir$varfile.rc
---------------------
width	51
height	11
style	2

$configdir$script.rc
--------------------
*script bang !setwidthheight
	*script exec !mathequation width=3*(5+6*style)
	*script exec !mathequation height = 3 + 4 * style
*script ~bang

*script bang !increasestyle
	*script exec !mathfile $configdir$varfile.rc
	*script exec !mathequation style += 1
	*script exec !setwidthheight
	*script exec !mathsave
*script ~bang

*script bang !decreasestyle
	*script exec !mathfile $configdir$varfile.rc
	*script exec !mathequation style -= 1
	*script exec !setwidthheight
	*script exec !mathsave
*script ~bang


notes about $configdir$varfile.rc (or whatever file(s) you are using to store variables)
+ it can be included
+ anything that doesn't begin with a letter or an underscore is not read as a variable
+ lines that begin with the following are not parsed: IF ELSE ENDIF
+ spaces and tabs are ignored
+ variables are stopped from being read when a line is reached that begins with ;;;
+ do not put any string variables above ;;; because they will cause unpredictable results

operations and order of operations are as follows: (anything in a group is done left to right unless otherwise noted)
-------------first done
(  )
parenthesis (although they aren't really operations, just modifiers to precedence)
-------------
!  not 1->0 and 0->1
~  bitwise not (flip every bit treated as a signed integer 16 bits)
-  unary minus (only 1 operand)
+  unary plus
operators in this group are done right to left
-------------
*  multiplication
%  modulus (remainder upon division)
/  division
-------------
+  addition
-  subtraction
-------------
<<  shift left (2<<3)->16  anyone who understands bit manipulation should recognize these
>>  shift right (16>>3)->2 they are standard in c as is everything else here (except ~=)
-------------
< less than
> greater than
<= less than or equal to
>= greater than or equal to
-------------
== equal to
!= not equal to
-------------
& bitwise and
-------------
^ bitwise exclusive or
-------------
| bitwise or
-------------
&& boolean and
-------------
|| boolean or
-------------
=   assignment operator
+=  these operators all can be expanded like
-=  a-=b can be rewritten as a=a-b
*=
/=
%=
<<=
>>=
&=
|=
^=
~=
everything in this group is done right to left
-------------last done

more things to know
+ integers are truncated, not rounded
+ decimals should work for any operater that is defined for them
+ variables are case sensitive
+ do not attempt to edit the file at any point between a call of !mathfile and !mathsave because your edit will be lost
+ this is by no means a finished product but more of a public beta
+ the code is ugly, esp for the file usage, I plan on making it better when I am satisfied with features (as soon as I add the conditional operator). This is more or less because I consider the written code to be an algorithm that happens to compile 
+ if you think you have found a bug, attempt to isolate it using the exe and then tell me about it (and a fix in the code provided for the exe if you wish)

--- To come ---
support for the conditional operator ( ? : )

--- changes ---
ver 0.2
+ stable
+ needs a very thourough bug check, and is why I am releasing it (I cannot do it on my own)
+ implementation of features from .1 is complete
+ project contains 2 binary files, a dll and an exe, the exe is a command line processer to aid in finding bugs.  Open it and type help<enter> for more info.

ver 0.1
+ added operators ^  &  ~  !  <  >  |  =  <<  >>  !=  <=  >=  ==  &&  ||
                  ~=  %=  ^=  &=  *=  /=  |=  -=  +=  <<=  >>=
+ added file input and output
+ added support for variables

ver 0
+ start of project
+ operators supported +  -  %  *  /  (  )
+ not very useful b/c no = allowed
--- contact info ---
Fallout
homepage: billbarry.tripod.com
deviantart: after-fallout.deviantart.com
neowin name: after fallout
aim: after fallout
icq: 28308618
msn: after_fallout@yahoo.com or at18326@yahoo.com
Y!: after_fallout@yahoo.com or at18326@yahoo.com
email: after_fallout@yahoo.com or at18326@yahoo.com