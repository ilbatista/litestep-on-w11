===================================================
===================================================
== bangvwm.dll - Who needs a GUI? Not I. ==========
===================================================
===================================================
====== Written by: ================================
================== Chris Rempel (jugg) ============
===================================================
================== http://jugg.logicpd.com/ =======
================== jugg@activatormail.com =========
===================================================
===================================================
= Version: 0.31 = Release Date: 2001.07.06 ========
===================================================
===================================================

-=ToC=-
I. Introduction
II. Installation
III. Information
 A} Commands
 B} Changes
 C} Notes
IV. Tips & Tricks
V. Disclaimer


=====================
== I. Introduction ==
=====================
===================================================

bangvwm.dll is a Virtual Window Manager for Win32
Shells that support the LiteStep module standard.
bangvwm.dll is based off of the idea of LiteStep's
VWM modules, but is purely controlled via !bang
commands and has no built in visual interface. This
gives an extremely fast and simple VWM without the
overhead of other similiar modules.


=Credits/Thanks:=
=================
Thanks to other VWM module authors, particularly
Visigoth and Chaku. Their VWM modules (sysVWM and
ckVWM) were a great reference point and code
snippet source for me to work with.


======================
== II. Installation ==
======================
===================================================

Extract "bangvwm.dll" to your Shell module
directory (c:\purels\modules\). Open up your Shell
configuration file and find the section where all
of your "LoadModule" lines are located. Remove any
"LoadModule" lines that are loading "sysvwm.dll" or
other VWM module. Now, add a new line that looks
like this:

LoadModule c:\purels\modules\bangvwm.dll

Of course, adjust the path as necessary. Refer to
the "Commands" section and configure your new VWM.
Then save your shell configuration file(s) and
issue the Shell's Recycle command (!Recycle).


======================
== III. Information ==
======================
===================================================
= A} Commands =
===============

bVWMDesks 2
  - Purpose: Sets the number of Virtual Windows

  - Parameters: <integer>

  - Defaults to: 2


bVWMStrictGather
  - Purpose: Enables "strict" gathering of windows
    so that the exact window placement is kept
    instead of the default forcing of all window
    boundaries to be inside of the current Virtual
    Window when the gather command is completed.

  - Parameters: none

  - Boolean value: true if set, otherwise false.


bVWMVertical
  - Purpose: Sets the VWM layout to Vertical,
    instead of the default horizontal layout.

  - Parameters: none

  - Boolean value: true if set, otherwise false.


bVWMQuitCmd ".none"
  - Purpose: Sets a command to execute when
    unloading the module. So, this will happen
    during a recycle as well.

  - Parameters: <value>
    <value> - Accepts any !bang command or program
              that can be executed.

  - Defaults to: ".none"


*bVWMExec
  - Purpose: Sets a command to execute when
    switching to the specified Virtual Window

  - Parameters: <integer> <command>

    <integer> - Sets the Virtual Window number

    <command> - Accepts any !bang command or
                program that can be executed.

  - Multiple settings of this command are allowed
    up to the number of Virtual Windows created
    (value of bVWMDesks). Also, there may not be
    two commands with the same VW number.


*bVWMSticky
  - Sets the text to match against all apps
    to determine if they should be kept on every
    VW. The text is matched first against the
    window class, then the window title.

  - parameters: <matchtext>

    <matchtext> is a text string that is compared
                first to the window class and then
                to the window title. If any window
                matches, it will be sticky.

  - Multiple settings of this command are allowed.


  =!Bang Commands=
  ================
   !bVWMSwitchTo
     - parameters: <value>
       <value> can be one of the following;
         ".home" - Goes to initial VW.
         ".end" - Goes to last VW.
         ".next" - Goes to next VW.
         ".prev" - Goes to previous VW.
         <integer> - Goes to specified VW.

     - Issuing this command will set the current VW
       to the specified <value>. If specifing an
       <integer>, the VW list is zero base, meaning
       the first VW is "0".

   !bVWMNext
     (Same as: !bVWMSwitchTo ".next")
     - parameters: none
     - Issuing this command will switch to the next
       Virtual Window.

   !bVWMPrev
     (Same as: !bVWMSwitchTo ".prev")
     - parameters: none
     - Issuing this command will switch to the
       previous Virtual Window.

   !bVWMGather
     - parameters: <value>
       ".home" - Gathers windows to the initial VW.
       ".end" - Gathers windows to the last VW.
       ".next" - Gathers windows to the next VW.
       ".prev" - Gathers windows to the previous
                 VW.
       <integer> - Gathers windows to the specified
                   VW if valid.
       <noparams> - Gathers windows to the current
                    VW.
     - Issuing this command will gather all windows
       to the specified Virtual Window. If called
       without any parameters, it will gather the
       windows to the current Virtual Window.

   !bVWMGatherH
     - Same as !bVWMGather, but this only gathers
       the windows Horizontally.  So if you have a
       window that is vertically off of the display
       it will not be gathered veritcally when
       executing this command, however it will be
       gathered horizontally.

   !bVWMGatherV
     - Same as !bVWMGather, but this only gathers
       the windows Vertically.  So if you have a
       window that is horizontally off of the
       display it will not be gathered horizontally
       when executing this command, however it will
       be gathered vertically.

   !bVWMDesks
    - parameters: <integer>
      <integer> - Sets the number of Virtual
                  Windows.  See "bVWMDesks".

    - Calling this command also reloads the
      *bVWMExec settings. See "*bVWMExec".

===================================================
= B} Changes =
==============
(+)Added
(-)Removed
(*)Changed
(!)Fixed
(^)MiscNote

- 0.31 -
--------
  + Added bVWMStrictGather to specify whether to
    force keeping exact window positions while
    switching VWs.
  + Added bVWMVertical to use a vertical VWM
    instead of a horizontal one.
  + Added bVWMQuitCmd to specify a command to
    execute when recycling/quiting.
  + Added !bVWMGatherV to gather vertically
          !bVWMGatherH to gather horizontally
  + Added !bVWMDesks to dynamically set the number
    of Virtual Windows. (Reloads *bVWMExec)
  + Added *bVWMExec to execute a command on switch
    to specified VW.
  + Added *bVWMSticky for specifying sticky windows
    to keep in every VW.

  * Changed !bVWMDesk to !bVWMSwitchTo

- 0.30 -
--------
  + Initial release.
  + Supports navigating the VWM by !bang commands


===================================================
= C} Notes =
============
Currently there is no way to make the VW auto
switch when focus is set to a window outside of the
current VW.

Known bug. If you change resolutions, the VWM does
not update accordingly (just !Recycle, or reload
as a work around).

Enjoy


=====================
= IV. Tips & Tricks =
=====================
===================================================
If entering an interger value in regards to
specifying what VW to access, remember that the VW
index is base zero, meaning the first VW is "0". So
if you created a VWM with 4 VWs, then you will have
access to VWs 0, 1, 2 and 3.

--

Set your configuration to switch VW's via the
supplied !bang commands with hotkey's, or with
desktop shortcuts for mouse click VW switching.

--

If using a Dual Monitor setup, set your VWM
direction to the opposite of your Monitor setup.
Then only use the corresponding !bVWMGatherx bang
command.  For example if your have a dual monitor
setup which spans horizontally, you will want to
set the bVWMVertical command and only use the
!bVWMGatherV bang command to gather your windows.
Of course you can use the other two gather commands
for advanced uses.

--

For a visual display of what VW you are currently
in you could use shortcuts and the *bVWMExec
settings to accomplish this. For example:

bVWMDesks 4
*bVWMExec 0 !execute [!ShowShortcutGroup 0][!HideShortcutGroup 1][!HideShortcutGroup 2][!HideShortcutGroup 3]
*bVWMExec 1 !execute [!ShowShortcutGroup 1][!HideShortcutGroup 0][!HideShortcutGroup 2][!HideShortcutGroup 3]
*bVWMExec 2 !execute [!ShowShortcutGroup 2][!HideShortcutGroup 0][!HideShortcutGroup 1][!HideShortcutGroup 3]
*bVWMExec 3 !execute [!ShowShortcutGroup 3][!HideShortcutGroup 0][!HideShortcutGroup 1][!HideShortcutGroup 2]

Or something like that... I never use shortcuts,
but you get the idea :)


=================
= V. Disclaimer =
=================
===================================================

Copyright (C) 2001, Chris Rempel

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT  WARRANTY
OF ANY KIND, EXPRESS OR  IMPLIED, INCLUDING BUT NOT
LIMITED  TO  THE   WARRANTIES  OF  MERCHANTABILITY,
FITNESS  FOR   A   PARTICULAR   PURPOSE   AND  NON-
INFRINGEMENT.  IN  NO  EVENT  SHALL THE  AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,  DAMAGES
OR  OTHER  LIABILITY,   WHETHER  IN  AN  ACTION  OF
CONTRACT,  TORT OR OTHERWISE,  ARISING FROM, OUT OF
OR IN CONNECTION  WITH  THE  SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
