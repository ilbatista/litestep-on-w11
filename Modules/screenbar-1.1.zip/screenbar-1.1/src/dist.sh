#!/bin/bash

VERSION=1.1
DISTDIR=dist
PACKAGEDIR=$DISTDIR/screenbar-$VERSION

if [ -d "$PACKAGEDIR" ]; then
	rm -rf "$PACKAGEDIR"
fi

mkdir -p "$PACKAGEDIR/src"

cp screenbar/Release/screenbar.dll "$PACKAGEDIR"
cp screenbar/Debug/screenbar.dll "$PACKAGEDIR/screenbar_debug.dll"
cp screenbar/screenbar_hotkeys.rc "$PACKAGEDIR"
cp screenhk/Release/screenhk.dll "$PACKAGEDIR"

cp -R screenhk screenbar "$PACKAGEDIR/src"
cp dist.sh Doxyfile *.txt *.sln "$PACKAGEDIR/src"
cp README* COPYING.txt "$PACKAGEDIR"

# Remove intermediate files
(
	cd "$PACKAGEDIR/src"
	rm -rf screenbar/Release screenbar/Debug screenhk/Release screenhk/Debug
	find . -iname '.svn' |xargs rm -rf
	find . -iname '.user' |grep vcproj |xargs rm -f
)

# Zip it all up
(
	cd $DISTDIR
	zip -r screenbar-$VERSION.zip "screenbar-$VERSION"
)

# Put together a theme
THEMEDIR=theme/ScreenbarSample
mkdir -p "$THEMEDIR/modules"
cp "$PACKAGEDIR/screenbar.dll" "$THEMEDIR/modules"
cp "$PACKAGEDIR/screenhk.dll" "$THEMEDIR/modules"
cp /bin/system/Litestep/themes/ScreenbarSample/theme.rc "$THEMEDIR"
cp -R /bin/system/Litestep/themes/ScreenbarSample/images "$THEMEDIR"

(
    cd theme
    zip -r "screenbar-${VERSION}_theme.zip" ScreenbarSample
)

cp theme/screenbar-${VERSION}_theme.zip dist

