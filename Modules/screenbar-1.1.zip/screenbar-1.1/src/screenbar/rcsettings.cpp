/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenbar.hpp"

#pragma warning (disable: 4800)

RCSettings *settings;

extern const char *defaultSettings;

void loadDefaultSettings()
{
	char *copy = _strdup(defaultSettings);
	char *pos = strtok(copy, "\n");
	
	do {
		char *line = _strdup(pos);
		
		// Separate the line into a varname portion and a value portion
		char *varname = line;
		while(*varname && isspace(*varname))
			varname++;
		if(!*varname)
			continue;
		
		char *linepos = varname;
		while(*linepos && !isspace(*linepos))
			linepos++;
		if(*linepos) {
			*linepos = 0;
			linepos++;
		}
		while(*linepos && isspace(*linepos))
			linepos++;
		char *value = linepos;
		
		if(!rcIsDefined(varname))
			LSSetVariable(varname, value);
		
		free(line);
	} while(pos = strtok(NULL, "\n"));
	
	free(copy);
}

bool rcIsDefined(const char *name)
{
	if(GetRCLine(name, NULL, 0, NULL))
		return true;
	else
		return false;
}

bool rcIsDefined(const char *name, const char *prefix)
{
	string varname = string(prefix) + name;
	if(GetRCLine(varname.c_str(), NULL, 0, NULL))
		return true;
	else
		return false;
}

static string findRCSetting(const char *name, const char *prefix)
{
	string ret = string(prefix) + name;
	if(!rcIsDefined(ret.c_str())) {
		string warning = string("Undefined configuration option: ") + ret;
		warn(warning.c_str());
	}
	return ret;
}
static string findDefaultableRCSetting(const char *name, const char *prefix)
{
	string ret = string(prefix) + name;
	return ret;
}

int getConfigInt(const char *name, const char *prefix)
{
	string fullName = findRCSetting(name, prefix);
	return GetRCInt(fullName.c_str(), 0);
}
int getConfigInt(const char *name, int defaultValue, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	return GetRCInt(fullName.c_str(), defaultValue);
}
float getConfigFloat(const char *name, const char *prefix)
{
	string val = getConfigString(name, NULL, prefix);
	return atof(val.c_str());
}
float getConfigFloat(const char *name, float defaultValue, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	if(rcIsDefined(fullName.c_str())) {
		string val = getConfigString(fullName.c_str(), NULL, "");
		return atof(val.c_str());
	} else {
		return defaultValue;
	}
}
COLORREF getConfigColor(const char *name, const char *prefix)
{
	string fullName = findRCSetting(name, prefix);
	return GetRCColor(fullName.c_str(), 0);
}
COLORREF getConfigColor(const char *name, int r, int g, int b, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	COLORREF defaultVal = (r + (g<<8) + (b<<16));
	return GetRCColor(fullName.c_str(), defaultVal);
}
string getConfigString(const char *name, const char *defaultValue, const char *prefix)
{
	string fullName;
	fullName = findDefaultableRCSetting(name, prefix);
	
	char buf[4096];
	BOOL bRet = GetRCString(fullName.c_str(), buf, defaultValue, 4096);
	// special case not-defaultable handling
	if(!defaultValue && (!bRet || *buf == '\0')) {
		string warning = string("Undefined configuration option: ") + fullName;
		warn(warning.c_str());
	}
	return buf;
}
string getConfigLine(const char *name, const char *defaultValue, const char *prefix)
{
	string fullName;
	fullName = findDefaultableRCSetting(name, prefix);
	
	char buf[4096];
	BOOL bRet = GetRCLine(fullName.c_str(), buf, 4096, defaultValue);
	// special case not-defaultable handling
	if(!defaultValue && (!bRet || *buf == '\0')) {
		string warning = string("Undefined configuration option: ") + fullName;
		warn(warning.c_str());
	}
	return buf;
}
int getConfigCoord(const char *name, int limit, const char *prefix)
{
	string fullName = findRCSetting(name, prefix);
	return GetRCCoordinate(fullName.c_str(), 0, limit);
}
int getConfigCoord(const char *name, int defaultValue, int limit, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	return GetRCCoordinate(fullName.c_str(), defaultValue, limit);
}
bool getConfigBool(const char *name, const char *prefix)
{
	string fullName = findRCSetting(name, prefix);
	return GetRCBoolDef(fullName.c_str(), FALSE);
}
bool getConfigBool(const char *name, bool defaultValue, const char *prefix)
{
	string fullName = findDefaultableRCSetting(name, prefix);
	return GetRCBoolDef(fullName.c_str(), defaultValue);
}

void setConfigInt(const char *varname, int value, const char *prefix)
{
	string varFullName = string(prefix)+varname;
	char valueStr[32];
	sprintf(valueStr, "%i", value);
	LSSetVariable(varFullName.c_str(), valueStr);
}
void setConfigLine(const char *varname, const char *value, const char *prefix)
{
	string varFullName = string(prefix)+varname;
	LSSetVariable(varFullName.c_str(), value);
}
void setConfigBool(const char *varname, bool value, const char *prefix)
{
	string varFullName = string(prefix)+varname;
	LSSetVariable(varFullName.c_str(), value?"true":"false");
}

RCSettings::~RCSettings()
{
}

void RCSettings::refresh()
{
	// base settings
	keepEmptyDesktops       = getConfigBool("KeepEmptyDesktops", false);
	keepEmptyFocusedDesktop = getConfigBool("KeepEmptyFocusedDesktop", false);
	autoGather              = getConfigBool("AutoGather", true);
	rescueOffScreenWindows  = getConfigBool("RescueOffScreenWindows", true);
	trackProcesses          = getConfigBool("TrackProcesses", false);
	
	altTabMonitor = getConfigLine("AltTabMonitor", "cursor");
	panels        = getConfigLine("Panels", "");

	pollInterval = getConfigInt("PollInterval", 500);
	if(pollInterval && pollInterval < 10) pollInterval = 10;
	
	hoverTrackingInterval = getConfigInt("HoverTrackingInterval", 0);
}
