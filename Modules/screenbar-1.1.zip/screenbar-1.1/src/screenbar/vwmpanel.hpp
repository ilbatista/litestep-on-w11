/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

class VWMPanel
{
public:
	VWMPanel(string prefix, Monitor *monitor, HWND parentWindow);
	virtual ~VWMPanel();
	
	static void registerWindowClass();
	static void unregisterWindowClass();
	
	/// Register/unregister event handlers for LiteStep and timer events. Only
	/// the first panel handles these events; other panels don't.
	void registerEventHandlers();
	void unregisterEventHandlers();
	
	string getPrefix();
	void setVisible(bool visible);
	void setAlwaysOnTop(bool onTop);
	bool getVisible();
	bool getAlwaysOnTop();
	HWND getWindow();
	Monitor *getMonitor();
	
	Rect getRect();
	Point getTopLeft();
	
	Point getMenuPos(Rect buttonRect);
	string getMenuEdge();
	
	void checkForUpdates();
	void forcePanelRedraw();
	
	static LRESULT CALLBACK eventHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	LRESULT handleEvent(UINT uMsg, WPARAM wParam, LPARAM lParam);
	int mouseButtonEvent(MouseButton button, MouseAction action, int x, int y);
	int mouseMoveEvent(int x, int y);
	
	void beginDrag();
	void cancelDrag();
	void finishDrag();
	void dropDraggedObject(string droppedObjName, int x, int y);
	void hoverDraggedObject(string hoveredObjName, int x, int y);

	void initDrawContext();
	void destroyDrawContext();
	void onPaint(bool hidden);
	
	LayoutLocation elementAtPoint(int x, int y);
	Layout *getLayout();
	
	HDC backBuffer;
	HBITMAP backBufferMem;

	void hide();
	void unhide();
	
protected:
	string prefix;
	
	/*int x, y;
	int width, height;*/
	Rect visibleRect;
	
	bool isAppbar;
	bool autoHide;
	int screenEdge;
	int thickness;
	int hiddenThickness;
	int autoHideDelay;
	APPBARDATA appbarData;
	
	void updateAppbarPos();
	Rect getAppbarPos(const RECT *prevPos, bool hidden);
	
	bool hidden;

	Layout *layout;
	LayoutLocation lastClickLocation;
	Monitor *monitor;
	
	bool transparent;
	COLORREF fillColor;
	
	bool visible;
	bool alwaysOnTop;
	HWND window;
	HWND parentWindow;
	
	bool isEventHandler;
};
