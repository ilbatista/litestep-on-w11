/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// DO NOT DELETE NEXT LINE
// LMA1.0 
/*
LiteStep Module AppWizard
*/

#ifndef __Wndman_H
#define __Wndman_H

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <stdlib.h>
#include <shellapi.h>

#include "..\current\lsapi\lsapi.h"
#include "..\current\lsapi\lswinbase.h"

class WndWindow 
{
public:
	WndWindow (HWND window, int ID);
	~WndWindow ();
	WndWindow * next;

private:
	HWND window;
	int uID;
};

class Wndman : public Window
{
public:
	WndWindow *minWnds;
	int trayedIcons;

public:
	Wndman(HWND parentWnd, int& code);
	~Wndman();

	// window finders:
	HWND getFocusHWND(void);
	HWND getActiveHWND(void);
	HWND getForegroundHWND(void);

	HWND getHWNDBelow(HWND window);
	HWND getHWNDAbove(HWND window);
	HWND getHWNDhelper(LPCSTR args);
	BOOL returnHWNDAndCoords(HWND *window, int *x, int *y, LPCSTR args);

	// trayfunctions
	BOOL WndTraySend(HWND window, int UID);
	BOOL WndTrayRestore(HWND window, int UID);

	void WindowInfo(HWND window, BOOL alert);

	// opacity functions
	void setHWNDAlpha(HWND window, int Alpha);
	int getHWNDAlpha(HWND window);

	// size & positioning
	void WndSize(HWND window, int sizeProp, int x, int y);
	void WndPos(HWND window, int moveProp, int x, int y);

	// bang functions
	void WindowForeground(HWND wnd);
	void WindowPushBottom(HWND wnd);
	void WindowPushBack(HWND wnd);
	void WindowSetOpacity(LPCSTR args);
	void WindowOnTop(HWND, LPCSTR);
	void WindowHide(HWND window);
	void WindowRestore(HWND window);
	void WindowMaxToggle(HWND window);
	void WindowMaximize(HWND window);
	void WindowMinimize(HWND window);
	void WindowClose(HWND window);

	void WindowAllInfo(HWND, LPCSTR);

private:

	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
	void onTray(Message& message);

	// helpers
	HWND getTargetHWND(int window_code);
	char *isToolTipHWND(HWND window);

	void setHWNDNoAlpha(HWND window);
	void setHWNDAcceptAlpha(HWND window);
	void hideHWNDVWM(HWND window);

	HICON GetIconFromWindow( HWND hWnd, BOOL bBigIcon );

};

void BangWndForeground(HWND, LPCSTR);
void BangWndSetOpacity(HWND, LPCSTR);
void BangWndPushBottom(HWND, LPCSTR);
void BangWndPushBack(HWND, LPCSTR);
void BangWndOnTop(HWND, LPCSTR);
void BangWndHide(HWND, LPCSTR);
void BangWndMaxToggle(HWND, LPCSTR);
void BangWndMaximize(HWND, LPCSTR);
void BangWndRestore(HWND, LPCSTR);
void BangWndMinimize(HWND, LPCSTR);
void BangWndClose(HWND caller, LPCSTR args);
void BangWndInfo(HWND caller, LPCSTR args);
void BangWndAllInfo(HWND caller, LPCSTR args);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
