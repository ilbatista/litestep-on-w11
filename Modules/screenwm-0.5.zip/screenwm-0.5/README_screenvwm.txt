ScreenVWM - a Litestep taskbar and VWM
By Jim Babcock

ScreenVWM is a combination virtual window manager and taskbar with a simple,
drag-and-drop interface.


This documentation is currently HIGHLY INCOMPLETE. Refer to rcsettings.cpp for
a complete list of settings.

Behavior Settings
  swmSwitchDeskWithDrag [default true]
    If disabled, dragging a task between desks will not switch to the desk
    being dragged to.

  swmKeepEmptyDesktops [default false]
    If enabled, empty desktops will not be automatically deleted. Not
    recommended.

  swmDragCreatesDesk [default true]
    If enabled, dragging a task into unused taskbar area will create a new
    desk and put that task on it.

  swmMinimizeClick [default true]
    If set to false, clicking on the foreground task's task icon will not
    minimize it.


Bang Commands
  !vwmCreate
    Create a new desk containing the foreground task and switch to it. This is
	equivalent to dragging the foreground task to an unused part of the
	taskbar.

  !vwmDesk <desk>
    Switch to the given desk, where <desk> is either a number (eg "!vwmDesk 1")
    or a description (eg "!vwmDesk next"). See "Desk descriptions".

  !vwmNext, !vwmPrev, !vwmUp, !vwmDown, !vwmLeft, !vwnRight, !vwmDown
    Short for !vwmDesk <description>. See "Desk Descriptions".

  !vwmDestroy        
    Destroy the current desk, moving all of its tasks to the previous desk,
    which becomes focused.

  !vwmGather
    Combine all desktops into one, moving all windows on screen.

  !vwmMaximizeWindow
    Maximizes the foreground window.

  !vwmMinimizeWindow
    Minimizes the foreground window.

  !vwmMoveWindow
	Moves the foreground window, as though you had picked 'move' from its
	system menu.

  !vwmResizeWindow
    Resizes the foreground window, as though you had picked 'resize' from its
    system menu.

Desk Descriptions

Wherever a bang command or variable refers to a desktop, you may either put
that desktop's number, or one of the following descriptions:

    prev, next    The desktops before and after the focused desktop
    current       The desktop you are looking at now
    other         The desktop you last looked at, besides the focused one
    up, left      Synonyms for 'prev' provided for compatibility
    right, down   Synonyms for 'next' provided for compatibiliity

------------
Legalities
  ScreenVWM is copyright (C) 2008 James Babcock. It contains code derived from
LiteStep, which is copyright (C) 1997-2008 The LiteStep Development Team.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
file license.txt for details.


