#pragma once
#include <vector>
using std::vector;
#include <string>
using std::string;
#include "wrappingflow.hpp"

struct LayoutSettings;
struct RCSettings;

struct LayoutSettings
{
public:
	// Initialize to defaults
	LayoutSettings(RCSettings *baseSettings);
	// Initialize from variables. defaults is a LayoutSettings that will be
	// copied for any variables not provided. fallbackIndex is a suffix added
	// to each variable name (no suffix if fallbackIndex<=1);
	LayoutSettings(LayoutSettings *defaults, int fallbackIndex);
	bool hasNonDefault;
	
	// Internal layout
	int panelRows;
	int tasksIconSize;
	int tasksBorderThickness;
	
	string labelFont;
	int labelFontSize;
	bool centerLabel;
	
	bool hideMinimap;
	
	/// Dimensions of the minimap. If this is too large to fit, these will be
	/// shrunk in an aspect-ratio preserving manner.
	int minimapWidth;
	int minimapHeight;
	
	int deskBaseSize;
	int labelOffsetX;
	int labelOffsetY;
	int minimapOffsetX;
	int minimapOffsetY;
	int tasksOffsetX;
	int tasksOffsetY;
	
private:
	char *suffix;
	int getInt(const char *name, int defaultValue);
	string getString(const char *name, const string &defaultValue);
	bool getBool(const char *title, BOOL valueIfFound, bool defaultValue);
};
LayoutSettings impliedLayoutFallback(const LayoutSettings &last);

struct RCSettings
{
public:
	~RCSettings();
	void refresh(bool inWharf);
	
	vector<LayoutSettings> layoutSettings;
	
	// Position
	int panelX;
	int panelY;
	int panelWidth;
	int panelHeight;
	int reservedSize;
	
	// Window tracking settings
	int pollInterval;
	
	// Behavior settings
	bool switchDeskWithDrag;
	bool keepEmptyDesktops;
	bool dragCreatesDesks;
	bool minimizeOnClick;
	bool noAutoGather;
	
	// Minimap settings
	int minimapTitleBarsThickness;
	int minimapIconSize;
	
	// Task display settings
	FlowDirection flowDirection;
	int tasksOffsetX;
	int tasksOffsetY;
	int tasksOffsetXMin;
	int tasksOffsetYMin;
	int tasksOffsetXFocused;
	int tasksOffsetYFocused;
	bool tasksIconTransparent;
	bool tasksIconTransparentFocused;
	bool tasksIconTransparentMin;
	
	// Visibility settings
	bool visible;
	bool onTop;
	int autoHideDistance;
	
	// Draw settings
	bool drawFocusedPanelRect;
	
	// Colors
	COLORREF panelBackgroundColor;
	COLORREF panelBackgroundColorFocused;
	COLORREF panelBorderColorFocused;
	COLORREF panelBorderColor;
	COLORREF vwmBackgroundColor;
	COLORREF vwmWindowColor;
	COLORREF vwmTitleBarColor;
	COLORREF vwmFocusedTitleBarColor;
	COLORREF vwmBorderColor;
	COLORREF vwmWindowBorderColor;
	COLORREF tasksBackColor;
	COLORREF tasksBackColorMin;
	COLORREF tasksBackColorFocused;
	COLORREF tasksBorderColor;
	COLORREF tasksBorderColorMin;
	COLORREF tasksBorderColorFocused;
	COLORREF labelColor;
	COLORREF labelColorFocused;
};
