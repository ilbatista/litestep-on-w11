#include "vwm.h"

void bangCreate(HWND sender, const char *args);
void bangDestroy(HWND sender, const char *args);
void bangGather(HWND sender, const char *args);
void bangDesk(HWND sender, const char *args);
void bangNext(HWND sender, const char *args);
void bangPrev(HWND sender, const char *args);
void bangOther(HWND sender, const char *args);
void bangToggle(HWND sender, const char *args);
void bangShow(HWND sender, const char *args);
void bangHide(HWND sender, const char *args);
void bangOpen(HWND sender, const char *args);
void bangMoveApp(HWND sender, const char *args);
void bangOntopToggle(HWND sender, const char *args);
void bangMinimizeWindow(HWND sender, const char *args);
void bangMaximizeWindow(HWND sender, const char *args);
void bangMoveWindow(HWND sender, const char *args);
void bangResizeWindow(HWND sender, const char *args);

struct BangCommandInfo {
	const char *name;
	void (*func)(HWND sender, const char *args);
};
static BangCommandInfo bangCommands[] = {
	{ "!vwmCreate",      bangCreate },
	{ "!vwmDestroy",     bangDestroy },
	{ "!vwmGather",      bangGather },
	{ "!vwmDesk",        bangDesk },
	{ "!vwmNext",        bangNext },
	{ "!vwmPrev",        bangPrev },
	{ "!vwmOther",       bangOther },
	{ "!vwmToggle",      bangToggle },
	{ "!vwmShow",        bangShow },
	{ "!vwmHide",        bangHide },
	{ "!vwmOpen",        bangOpen },
	{ "!vwmMoveApp",     bangMoveApp },
	{ "!vwmOntopToggle", bangOntopToggle },
	
	{ "!vwmMinimizeWindow", bangMinimizeWindow },
	{ "!vwmMaximizeWindow", bangMaximizeWindow },
	{ "!vwmMoveWindow",     bangMoveWindow },
	{ "!vwmResizeWindow",   bangResizeWindow },

	// For backwards compatibility with other VWMs, !vwmUp and !vwmLeft are
	// aliased to !vwmPrev, and !vwmRight and !vwmDown are aliased to !vwmNext.
	{ "!vwmUp",          bangPrev },
	{ "!vwmDown",        bangNext },
	{ "!vwmLeft",        bangPrev },
	{ "!vwmRight",       bangNext },
};
static const int numBangCommands = sizeof(bangCommands) / sizeof(*bangCommands);

void initBangs()
{
	for(int ii=0; ii<numBangCommands; ii++)
	{
		BangCommandInfo *cmd = &bangCommands[ii];
		AddBangCommand(cmd->name, cmd->func);
	}
}

void cleanupBangs()
{
	for(int ii=0; ii<numBangCommands; ii++)
	{
		BangCommandInfo *cmd = &bangCommands[ii];
		RemoveBangCommand(cmd->name);
	}
}


void bangCreate(HWND sender, const char *args)
{
	vwm->createDesktop();
}
void bangDestroy(HWND sender, const char *args)
{
	vwm->destroyDesktop(vwm->findDesk("current"));
}
void bangGather(HWND caller , const char *args)
{
	vwm->gather();
}
void bangDesk(HWND sender, const char *args)
{
	vwm->switchDesk(vwm->findDesk(args));
}
void bangNext(HWND sender, const char *args)
{
	vwm->switchDesk(vwm->findDesk("next"));
}
void bangPrev(HWND sender, const char *args)
{
	vwm->switchDesk(vwm->findDesk("prev"));
}
void bangOther(HWND sender, const char *args)
{
	vwm->switchDesk(vwm->findDesk("other"));
}
void bangToggle(HWND sender, const char *args)
{
	vwm->toggle();
}
void bangShow(HWND sender, const char *args)
{
	vwm->show();
}
void bangHide(HWND sender, const char *args)
{
	vwm->hide();
}
void bangOpen(HWND sender, const char *args)
{
	char ndesk[MAX_LINE_LENGTH], cmd[MAX_LINE_LENGTH];
	char *tokens[1] = {ndesk};

	if (LCTokenize(args, tokens, 1, cmd))
	{
		VirtualDesktop *desk = vwm->findDesk(ndesk);
		vwm->switchDesk(desk);
		LSExecute( NULL, cmd, SW_SHOWNORMAL );
	}
}
void bangMoveApp(HWND sender, const char *args)
{
	VirtualDesktop *destination = vwm->findDesk(args);
	vwm->moveApp(destination);
}
void bangOntopToggle(HWND sender, const char *args)
{
	vwm->ontopToggle();
}

void bangMinimizeWindow(HWND sender, const char *args)
{
	WindowData *window = vwm->getForegroundWindow();
	if(window)
		vwm->minimizeWindow(window);
}

void bangMaximizeWindow(HWND sender, const char *args)
{
	WindowData *window = vwm->getForegroundWindow();
	if(window) {
		if(IsZoomed(window->handle))
			vwm->restoreWindow(window);
		else
			vwm->maximizeWindow(window);
	}
}

void bangMoveWindow(HWND sender, const char *args)
{
	HWND window = GetForegroundWindow();
	Message msg;
	msg.lParamLo = 0;
	msg.lParamHi = 0;
	SendMessage(window, WM_SYSCOMMAND, SC_MOVE, msg.lParam);
}

void bangResizeWindow(HWND sender, const char *args)
{
	HWND window = GetForegroundWindow();
	Message msg;
	msg.lParamLo = 0;
	msg.lParamHi = 0;
	SendMessage(window, WM_SYSCOMMAND, SC_SIZE, msg.lParam);
}