/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
4/30/08 - jimrandomh
- Used this file from Litestep's vwm2 as the starting point of screenVWM.
  Changed just about everything. Includes contributions by allelimo,
  Vendicator, Bobby G. Vinyard, Charles Oliver Nutter (Headius), and Gustav
  Munkby (grd).
****************************************************************************/

#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include "vwm.h"
#include "trace.hpp"

VWM *vwm = NULL;
const char *traceFilename = "screenvwm.log";

//=========================================================
// Module initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInstance, LPCSTR szPath)
{
	int code;
	
	vwm = new VWM(ParentWnd, code, dllInstance);
	vwm->finalize();
	
	return code;
}

int initWharfModule(HWND ParentWnd, HINSTANCE dllInstance, void *wharfData)
{
	int code;

	vwm = new VWM(ParentWnd, code, dllInstance);
	vwm->finalize();

	return code;
}

void quitModule(HINSTANCE dllInst)
{
	vwm->saveDesktops();
	delete vwm;
	trace.close();
}

void quitWharfModule(HINSTANCE dllInst)
{
	delete vwm;
	trace.close();
}

//=========================================================
// VWM miscellaneous
//=========================================================
VWM::VWM(HWND parentWindow, int& code, HINSTANCE dllInst)
	:parentWindow(parentWindow), dllInstance(dllInstance)
{
	// if the parent window is not litestep, it must be the wharf
	if(parentWindow == GetLitestepWnd()) {
		inWharf = false;
		parentWindow = FindWindow("DesktopBackgroundClass", NULL);
		if(!parentWindow)
			parentWindow = GetDesktopWindow();
	} else {
		inWharf = true;
	}
	
	updateNextDraw = false;
	draggingTask = NULL;
	dragSourceDesk = NULL;
	dragCreatedDesk = NULL;
	dragIconWnd = NULL;
}

VWM::~VWM()
{
	images.destroyImages();
	cleanupTrackingHooks();
	unregisterEventHandlers();
	destroyWindow();
	destroyDragIcon();
	destroyDragIconClass();
	delete settings;
}

int VWM::finalize()
{
	settings = new RCSettings();
	settings->refresh(inWharf);
	
	setScreenSize(SCREEN_WIDTH, SCREEN_HEIGHT);
	initBangs();
	initStickyWindows();
	initDesktops();
	
	if(!createWindow())
		return 1;
	createDragIconClass();
	
	registerEventHandlers();
	initDrawContext();
	images.loadImages();
	
	initTrackingHooks();
	
	DragAcceptFiles(vwmWindow, TRUE);
	
	updateWindowList();
	
	if (settings->onTop)
		SetWindowPos(vwmWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

	if (settings->visible && settings->autoHideDistance)
	{
		// if it's at the edge of the screen
		if( (windowX == (SCREEN_LEFT))
		 || (windowY == (SCREEN_TOP))
		 || (windowX + windowWidth == screenWidth)
		 || (windowY + windowHeight == screenHeight) )
		{
			POINT pt;
			GetCursorPos(&pt);
			if( (pt.x < windowX)
			 || (pt.x > windowX + windowWidth)
			 || (pt.y < windowY)
			 || (pt.y > windowY + windowHeight) )
				settings->visible = FALSE;
		}
	}

	ShowWindow(vwmWindow, settings->visible?SW_SHOWNORMAL:SW_HIDE);

	// Set a timer to update the VWM display (would like to replace this with a hook...)
	if(settings->pollInterval)
		SetTimer(vwmWindow, 1, settings->pollInterval, NULL);
	
	return 0;
}

void VWM::initStickyWindows()
{
	// Read vwmSticky options and populate vec stickyWindows with them
	FILE *f;
	char buffer[MAX_LINE_LENGTH];

	f = LCOpen(NULL);
	if(!f)
		return;
	
	while(LCReadNextConfig(f, "*vwmSticky", buffer, MAX_LINE_LENGTH))
	{
		char firstToken[MAX_LINE_LENGTH];
		char *tokens[] = { firstToken };
		
		LCTokenize ((char *)(buffer + 11), tokens, 1, NULL);
		
		if(*firstToken)
			stickyWindows.insert(firstToken);
	}
	LCClose(f);
}

WindowData *VWM::getForegroundWindow()
{
	if(!foregroundHandle)
		return NULL;
	if(windowsByHandle.find(foregroundHandle)==windowsByHandle.end())
		return NULL;
	return windowsByHandle[foregroundHandle];
}

VirtualDesktop *VWM::getDeskFromWnd(HWND window)
{
	if(!window)
		return NULL;
	
	if(windowsByHandle.find(window) != windowsByHandle.end())
	{
		return windowsByHandle[window]->desk;
	}
	else
	{
		RECT screenPos;
		GetWindowRect(window, &screenPos);
		VirtualDesktop *desk = deskFromLocation(screenPos);
		if(desk)
			return desk;
		else
			return currentDesktop;
	}
}

void VWM::createDesktop()
{
	VirtualDesktop *newDesk = new VirtualDesktop(desktops.size(), storageManager.getStorageArea());
	desktops.push_back(newDesk);
	
	if(!foregroundHandle)
		raiseLocalForeground();
	moveApp(newDesk);
	switchDesk(newDesk);
}

bool VWM::destroyDesktop(VirtualDesktop *desk)
{
	// If there's only one desktop left, it can't be destroyed
	if(desktops.size()<=1)
		return false;
	
	// If there's a drag/drop in progress, cancel it
	if(draggingTask)
		endDrag();
	
	// Pick a desktop to move windows to. All desktops except the first merge
	// to the left. The first (leftmost) desktop merges to the right instead.
	VirtualDesktop *mergeTarget;
	VirtualDesktop *deletedDesktop = desk;
	if(desk->index > 0)
		mergeTarget = desktops[desk->index-1];
	else
		mergeTarget = desktops[1];
	
	beginMovingWindows();
	
	for(map<HWND, WindowData*>::iterator it = windowsByHandle.begin(); it != windowsByHandle.end(); it++)
	{
		HWND handle = it->first;
		WindowData *windowData = it->second;
		
		// Relabel windows on the deleted desktop as being on the merge target
		if(windowData->desk == deletedDesktop) {
			if(deletedDesktop != currentDesktop) {
				deletedDesktop->storage->unstoreRect(windowData->screenPos);
				mergeTarget->storage->storeRect(windowData->screenPos);
				setWindowPos(windowData->handle, &windowData->screenPos);
			}
			
			windowData->desk = mergeTarget;
		}
		// Move windows on the merge target on-screen
		else if(windowData->desk == mergeTarget) {
			if(currentDesktop == deletedDesktop) {
				mergeTarget->storage->unstoreRect(windowData->screenPos);
				setWindowPos(handle, &windowData->screenPos);
			}
		}
	}
	
	finishMovingWindows();
	
	if(currentDesktop == deletedDesktop) {
		currentDesktop = mergeTarget;
		currentDesktop->focused = true;
	}
	
	// Remove the deleted desktop from the desk list and update everyone's indices
	for(unsigned ii=deletedDesktop->index; ii<desktops.size()-1; ii++)
	{
		desktops[ii] = desktops[ii+1];
		desktops[ii]->index = ii;
	}
	desktops.pop_back();
	delete deletedDesktop;
	
	// Clean up other possible references to the deleted desk
	if(lastDesktop == deletedDesktop)
		lastDesktop = NULL;
	
	if(currentDesktop == mergeTarget)
		raiseLocalForeground();
	
	forceRedraw(true);
	return true;
}

void VWM::switchDesk(VirtualDesktop *newDesk, bool skipFocus)
{
	if(!newDesk)
		return;
	if(newDesk == currentDesktop)
		return;
	
	beginMovingWindows();
	
	for(map<HWND, WindowData*>::iterator it = windowsByHandle.begin(); it != windowsByHandle.end(); it++)
	{
		HWND window = it->first;
		WindowData *windowData = it->second;
		if(isSticky(window))
			continue;
		
		bool moved = false;
		if(windowData->desk == currentDesktop) {
			// Move windows off-screen
			windowData->desk->storage->storeRect(windowData->screenPos);
			moved = true;
		} else if(windowData->desk == newDesk) {
			// Move windows from off-screen to on-
			windowData->desk->storage->unstoreRect(windowData->screenPos);
			moved = true;
		}
		
		if(moved) {
			setWindowPos(windowData->handle, &windowData->screenPos);
		}
	}
	
	finishMovingWindows();
	
	currentDesktop->focused = false;
	newDesk->focused = true;
	
	lastDesktop = currentDesktop;
	currentDesktop = newDesk;
	
	// Pick the topmost task on this desktop and focus it
	if(!skipFocus)
		raiseLocalForeground();
	
	forceRedraw(true);
}

/// If the focused window is on another desktop or is the desktop itself, focus
/// on the topmost window of this desktop. If there is no such window, focus on
/// the desktop.
void VWM::raiseLocalForeground()
{
	for(unsigned ii=0; ii<zOrder.size(); ii++)
	{
		HWND handle = zOrder[ii];
		if(windowsByHandle.find(handle)==windowsByHandle.end())
			continue;
		WindowData *window = windowsByHandle[handle];
		
		// Only focus something that's on the right desk
		if(window->desk != currentDesktop)
			continue;
		// Don't focus non-task windows (we want their owners instead) or
		// minimized windows (that'd be silly)
		if(!window->isTask || window->minimized)
			continue;
		
		raiseWindow(window);
		break;
	}
	
	// If we got throught he whole window list without finding something
	// suitable to focus, focus on the desktop.
	SetFocus(parentWindow);
}

bool VWM::isSticky(HWND window)
{
	char buffer[256];
	if(!GetWindowText(window, buffer, 255))
		return false;
	
	return stickyWindows.find(string(buffer)) != stickyWindows.end();
}

void VWM::moveWindow(WindowData *window, RECT pos, VirtualDesktop *desk)
{
	if(desk != window->desk)
		window->desk = desk;
	
	if(!desk->focused)
		desk->storage->storeRect(pos);
	
	// If moving a window onto a different desk, move all children onto that
	// desk as well
	set<WindowData*> movingWindows;
	
	window->screenPos = pos;
	setWindowPos(window->handle, &window->screenPos);
}

void VWM::moveWindow(WindowData *window, VirtualDesktop *desk)
{
	if(desk == window->desk)
		return;
	
	if(!window->desk->focused)
		window->desk->storage->unstoreRect(window->screenPos);
	if(!desk->focused)
		desk->storage->storeRect(window->screenPos);
	
	window->desk = desk;
	setWindowPos(window->handle, &window->screenPos);
}

void VWM::raiseWindow(WindowData *window)
{
	SendMessage(parentWindow, LM_BRINGTOFRONT, 0, (LPARAM)window->handle);
}

void VWM::minimizeWindow(WindowData *window)
{
	SendMessage(window->handle, WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE, 0);
	window->focused = false;
}

void VWM::maximizeWindow(WindowData *window)
{
	SendMessage(window->handle, WM_SYSCOMMAND, (WPARAM)SC_MAXIMIZE, 0);
}

void VWM::restoreWindow(WindowData *window)
{
	SendMessage(window->handle, WM_SYSCOMMAND, (WPARAM)SC_RESTORE, 0);
}

void VWM::gather()
{
	if(draggingTask)
		endDrag();
	
	beginMovingWindows();
	
	// Move everything onto the current desktop
	for(map<HWND, WindowData*>::iterator it = windowsByHandle.begin(); it != windowsByHandle.end(); it++)
	{
		HWND handle = it->first;
		WindowData *windowData = it->second;
		
		RECT newPos = getGatherTarget(windowData->screenPos);
		windowData->screenPos = newPos;
		
		setWindowPos(it->first, &windowData->screenPos);
		
		windowData->desk = currentDesktop;
	}
	
	finishMovingWindows();
	
	// Delete all other desktops
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		if(desktops[ii]!=currentDesktop)
			delete desktops[ii];
	}
	desktops.clear();
	desktops.push_back(currentDesktop);
	currentDesktop->index = 0;
	
	forceRedraw(true);
}



void VWM::moveApp(VirtualDesktop *dest)
{
	if(!dest)
		return;
	HWND foregroundWindow = GetForegroundWindow();
	if(windowsByHandle.find(foregroundWindow) == windowsByHandle.end())
		return;
	WindowData *windowData = windowsByHandle[foregroundWindow];
	
	if(!windowData->desk->focused)
		windowData->desk->storage->unstoreRect(windowData->screenPos);
	if(!dest->focused)
		dest->storage->storeRect(windowData->screenPos);
	
	// Move the foreground window and everything in its task-group (see
	// getWindowGroup) onto the new desktop.
	set<WindowData*> alongForTheRide;
	getTaskGroup(windowData, &alongForTheRide);
	
	// HACK: To keep switchDesktop from moving windows it shouldn't,
	// temporarily set their desk to nowhere.
	for(set<WindowData*>::iterator ii=alongForTheRide.begin(); ii!=alongForTheRide.end(); ii++)
		(*ii)->desk = NULL;
	
	switchDesk(dest, true);
	
	for(set<WindowData*>::iterator ii=alongForTheRide.begin(); ii!=alongForTheRide.end(); ii++)
		(*ii)->desk = dest;
}

/// Find a desktop given a string description of it. The string can be a
/// name, number, or direction (the directions are: left, right, up, down,
/// next, prev). Directions are relative to relativeTo, which is the
/// current desktop if not specified.
VirtualDesktop *VWM::findDesk(const char *deskName, VirtualDesktop *relativeTo)
{
	if(isdigit(*deskName)) {
		int index = atoi(deskName) - 1;
		if(index < 0 || index >= (int)desktops.size())
			return NULL;
		else
			return desktops[index];
	}
	
	if(!relativeTo)
		relativeTo = currentDesktop;
	
	if(!stricmp(deskName, "current"))
	{
		return currentDesktop;
	}
	else if(!stricmp(deskName, "next")
	     || !stricmp(deskName, "down")
	     || !stricmp(deskName, "right"))
	{
		if(relativeTo->index+1 < (int)desktops.size())
			return desktops[relativeTo->index+1];
		else
			return desktops[0];
	}
	else if(!stricmp(deskName, "prev")
	     || !stricmp(deskName, "up")
	     || !stricmp(deskName, "left"))
	{
		if(relativeTo->index > 0)
			return desktops[relativeTo->index-1];
		else
			return desktops[desktops.size()-1];
	}
	else if(!stricmp(deskName, "other"))
	{
		if(lastDesktop != currentDesktop)
			return lastDesktop;
		else
			return findDesk("next");
	}
	
	for(unsigned ii = 0; ii < desktops.size(); ii++)
	{
		if (!stricmp(deskName, desktops[ii]->getName().c_str()))
			return desktops[ii];
	}

	return NULL;
}
