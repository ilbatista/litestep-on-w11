#ifndef WINDOWTRACKING_HPP
#define WINDOWTRACKING_HPP
struct VirtualDesktop;

/// Cached information about a window which we're keeping track of. Windows
/// can disappear, move, or change properties at any time (they have threads/
/// wills of their own!), sometimes without us noticing, so there's no
/// guarantee that this information isn't stale.
struct WindowData
{
	HWND handle;
	RECT screenPos;
	int z;
	
	bool focused;
	bool minimized;
	
	/// The process ID which owns this window
	DWORD pid;
	
	/// Whether this window should appear on the taskbar. (Either it has
	/// WS_EX_APPWINDOW or no other window could be found which is responsible
	/// for it).
	bool isTask;
	
	/// Whether this is a popup window; that is, it has WS_POPUP set. Affects
	/// how this window is displayed on the minimap.
	bool isPopup;
	
	/// If this is a popup window, this is its parent (if it has one) or owner
	/// (if it has one). If it's unowned or not a popup, this is NULL.
	HWND parent;
	
	/// The virtual desktop this window is currently on
	VirtualDesktop *desk;
	
	HICON bigIcon;
	HICON smallIcon;
	
	bool visited;
	
	HICON getIcon(int size);
};

#endif