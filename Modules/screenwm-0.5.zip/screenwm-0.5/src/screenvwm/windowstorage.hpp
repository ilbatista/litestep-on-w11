#pragma once
#include <litestep/lsapi/lsapi.h>
#include <set>
using std::set;

class StorageArea
{
public:
	~StorageArea();
	
	RECT getRect();
	void storeRect(RECT &rect);
	void unstoreRect(RECT &rect);
	
	void *save(int *saveSize);
	void restore(void *state, int size);
	
private:
	friend class StorageManager;
	StorageArea(StorageManager *owner, int index, int x, int y);
	
	int index;
	StorageManager *owner;
	int x;
	int y;
};

class StorageManager
{
public:
	StorageManager();
	~StorageManager();
	
	StorageArea *getStorageArea();
	void releaseStorageArea(StorageArea *area);
	
	void *save(int *stateSize, int focus, vector<StorageArea*> deskAreas);
	int restore(void *state, vector<StorageArea*> &deskAreas);
	
private:
	int maxArea;
	int spacingX;
	int spacingY;
	set<int> unusedAreas;
};

