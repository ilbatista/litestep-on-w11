/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __VWM2_H
#define __VWM2_H

#define _WIN32_WINNT 0x0500
#include <litestep/lsapi/lsapi.h>
#include "rcsettings.hpp"
#include "windowstorage.hpp"
#include "windowtracking.hpp"
#include "swmimages.hpp"

#include <vector>
using std::vector;
#include <map>
using std::map;
using std::pair;
#include <string>
using std::string;
#include <set>
using std::set;

#define VERSION_STRING "screenvwm 0.5"

#define MAX_LINE_LENGTH 4096
#pragma warning (disable: 4800) // Conversion from int to bool
#pragma warning (disable: 4244) // Implicit conversion from int to float

struct Message
{
	UINT uMsg;
	union 
	{
		struct
		{
			WPARAM wParam;
			LPARAM lParam;
			LRESULT lResult;
		};
		struct
		{
			WORD wParamLo;
			WORD wParamHi;
			WORD lParamLo;
			WORD lParamHi;
			WORD lResultLo;
			WORD lResultHi;
		};
	};
};

struct VirtualDesktop;
struct WindowData;

/// A virtual desktop within the VWM.
struct VirtualDesktop
{
	VirtualDesktop(int index, StorageArea *storage);
	~VirtualDesktop();
	
	bool layoutDone;
	
	int index;
	string getName();
	string getLabel();
	
	// Position and size for the entire display of this VWM (including
	// label, minimap, tasks, and area in between them)
	int panelX, panelY;
	int panelWidth, panelHeight;
	
	int labelX, labelY;
	
	int minimapX, minimapY;
	int minimapWidth, minimapHeight;
	
	int tasksIconSize;
	int tasksIconArea;
	int tasksNumRows;
	int tasksNumCols;
	int tasksX, tasksY;
	int tasksWidth, tasksHeight;
	
	bool focused;
	StorageArea *storage;
	
	/// List of windows that're on this desktop. Only updated when
	/// VWM::doLayout is called;
	std::vector<WindowData*> tasks;
	/// Number of windows that're on this desktop. Unlike tasks, this is
	/// updated immediately as soon as we notice that a new window has appeared
	/// or disappeared.
	int numTasks;
	
	RECT VirtualDesktop::getMinimapRect();
};

/// Virtual Window Manager - the widget that this module exists to provide.
class VWM
{
public:
	VWM(HWND parentWnd, int& code, HINSTANCE dllInstance);
	~VWM();
	int finalize();

	void gather();
	
	void createDesktop();
	bool destroyDesktop(VirtualDesktop *desk);
	void switchDesk(VirtualDesktop *newDesk, bool skipFocus=false);
	void moveApp(VirtualDesktop *dest);
	void moveWindow(WindowData *window, VirtualDesktop *desk);
	void moveWindow(WindowData *window, RECT pos, VirtualDesktop *desk);
	void raiseWindow(WindowData *window);
	void minimizeWindow(WindowData *window);
	void maximizeWindow(WindowData *window);
	void restoreWindow(WindowData *window);
	void saveDesktops();
	
	WindowData *getForegroundWindow();
	void raiseLocalForeground();
	
	const RCSettings *getSettings() { return settings; }
	int getScreenWidth() { return screenWidth; }
	int getScreenHeight() { return screenHeight; }
	
	VirtualDesktop *findDesk(const char *deskName, VirtualDesktop *relativeTo=NULL);
	
private:
	RCSettings *settings;
	int screenWidth;
	int screenHeight;
	
	// VWM window management
	// (in vwmwindow.cpp) @{
	HINSTANCE dllInstance;
	HWND vwmWindow;
	HWND parentWindow;
	bool inWharf;
	bool createWindow();
	void destroyWindow();
	void registerWindowClass();
	void unregisterWindowClass();
	static LRESULT CALLBACK VWM::wndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
public:
	void ontopToggle();
	void toggle();
	void show();
	void hide();
private:
	//@}
	
	// Sticky windows handling
	// (in vwm.cpp) @{
	void initStickyWindows();
	bool isSticky(HWND window);
	set<string> stickyWindows;
	//@}
	
	// Virtual desktop data structures
	// (getters in vwm.cpp) @{
	VirtualDesktop *currentDesktop;
	VirtualDesktop *lastDesktop;
	vector<VirtualDesktop*> desktops;
	VirtualDesktop *getDeskFromWnd(HWND window);
	//@}
	
	// windowtracking.cpp
	// Window tracking and moving @{
	vector<HWND> zOrder;
	map<HWND, WindowData*> windowsByHandle;
	StorageManager storageManager;
	HWND foregroundHandle;
	bool updateNextDraw;

	bool updateWindowList();
	bool updateWindow(WindowData *window);
	WindowData *noticeWindowCreation(HWND handle);
	void noticeWindowDisappearance(WindowData *window);
	VirtualDesktop *rescueOffscreenWindow(HWND handle, RECT *pos);
	
	HDWP windowMover;
	void beginMovingWindows();
	void setWindowPos(HWND handle, const RECT *pos);
	void finishMovingWindows();
	
	void getTaskGroup(WindowData *member, set<WindowData*> *vec);
	bool shouldIgnoreWindow(HWND window);
	
	void initTrackingHooks();
	void cleanupTrackingHooks();
	void interceptWindowPosChange(HWND window, WINDOWPOS *pos);
	friend void hookWindowPosChangedProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	//@}
	
	// vwmevents.cpp
	// Event handlers @{
	void registerEventHandlers();
	void unregisterEventHandlers();
	virtual void windowProc(Message& message);
	void onCreate(Message& message);
	void onDestroy(Message& message);
	void onGetRevId(Message& message);
	void onMouseButtonDown(Message& message);
	void onMouseButtonUp(Message& message);
	void onMouseMove(int x, int y);
	void onSysCommand(Message& message);
	void onWindowActivated(Message& message);
	void onTimer(Message& message);
	void onDropFiles(Message& message);
	void onVWMPosChanging(Message& message);
	void onBringToFront(Message& message);
	void onSwitchToN(Message& message);
	void onListDesktops(Message& message);
	void onGetDesktopOf(Message& message);
	//@}
	
	// dragndrop.cpp
	// Drag, drop, and pending-minimization @{
	HWND pendingMinimize;
	HWND draggingTask;
	/// If dragging a task, whether the drag affects location (otherwise it
	/// only affects which desktop)
	bool draggingLocation;
	VirtualDesktop *dragCreatedDesk;
	POINT diffPt;
	VirtualDesktop *dragSourceDesk;
	RECT dragSourceRect;
	HWND dragIconWnd;
	HICON dragIcon;
	int dragIconSize;
	void beginWindowDrag(WindowData *window, bool draggingLocation, POINT click, POINT clickOffset);
	void continueWindowDrag(int mouseX, int mouseY);
	void endDrag();
	void createDragIconClass();
	void destroyDragIconClass();
	void createDragIcon(int centerX, int centerY, HICON icon);
	void destroyDragIcon();
	friend LRESULT CALLBACK dragIconWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	//@}
	
	// vwmgeom.cpp
	// Geometry calculations @{
	int windowX;
	int windowY;
	int windowWidth;
	int windowHeight;
	int layoutIndex;
	LayoutSettings *layoutSettings;
	void initDesktops();
	bool restoreDesktops();
	void tryLayouts();
	bool doLayout();
	void updateTaskLists();
	WindowData *taskFromPoint(int x, int y);
	WindowData *findMinimapWindow(VirtualDesktop *desk, int x, int y);
	void setScreenSize(int cx, int cy);
	RECT getMaximizeArea();
	void getDragDestination(RECT *rect, VirtualDesktop **desk, WindowData *window, POINT clickOffset, int mouseX, int mouseY);
	RECT getGatherTarget(RECT source);
	void screenToMinimapPos(VirtualDesktop *desk, RECT screenPos, RECT *vwmPos, POINT *iconPos);
	POINT minimapToScreenPos(VirtualDesktop *desk, int x, int y);
	VirtualDesktop *deskFromLocation(RECT pos);
	VirtualDesktop *panelPointToDesk(int x, int y);
	//@}
	
	// vwmpaint.cpp
	// Rendering @{
	HDC backBuffer;
	HBITMAP backBufferMem;
	vector<HFONT> labelFonts;
	HFONT oldFont;
	SWMImageManager images;
	void initDrawContext();
	HFONT loadLabelFont(LayoutSettings *settings);
	void destroyDrawContext();
	void forceRedraw(bool updateWindows);
	void onPaint(Message& message);
	void paintBackground();
	void paintDeskBackgrounds();
	void paintMinimapBackgrounds();
	void paintMinimapWindows();
	void paintTasks();
	void paintDeskLabels();
	//@}
};
extern VWM *vwm;

void initBangs();
void cleanupBangs();

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
	__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, void *wharfData);
	__declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);
}

#endif
