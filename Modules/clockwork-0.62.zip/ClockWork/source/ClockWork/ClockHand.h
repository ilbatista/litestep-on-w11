#ifndef __CLOCKHAND_H
#define __CLOCKHAND_H

#include <windows.h>
#include <gdiplus.h>
using namespace Gdiplus;

#include "TrigBuffer.h"
#include "HandCalc.h"
#include "ClockDisplay.h"

typedef struct
{
	double x;
	double y;
} POINTF;

// for hands & drawing
class ClockHand : public ClockDisplay
{
public:
	ClockHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a);
	~ClockHand();

	int GetLength();
	int GetWeight();
	int GetBorder();
	int GetAlpha();
	COLORREF GetColor();
	COLORREF GetInnerColor();

	static float GetCenterX();
	static float GetCenterY();
	static void SetCenter(float, float);
	static void SetAdaptRegion(bool bNoAdapt);
	static bool GetAdaptRegion();

	static SinBuffer *sinus;
	static CosBuffer *cosinus;

	virtual void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time) = 0;

protected:
	static void ConvertToGDIPoint(POINT out[], const PointF in[], const int size);
	static void CalcBoxPoints(bool aamode, PointF points[], const int index, const int weight, const int length);
	static void CalcTriPoints(bool aamode, PointF points[], const int index, const int weight, const int length);

protected:
	HandCalc* calc;

private:
	static bool bNoAdaptRegion;

	static float nCenterX;
	static float nCenterY;

	COLORREF clrOut;
	COLORREF clrIn;
	int nWeight;
	int nLength;
	int nBorder;
	int nAlpha;

};


class AATriHand : public ClockHand
{
public:
	AATriHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a);
	~AATriHand();
	void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);

protected:
	Pen* polyPen;
	SolidBrush* polyBrush;
};

class TriHand : public ClockHand
{
public:
	TriHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a);
	~TriHand();
	void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);

protected:
	HPEN hpen;
	HBRUSH hbrush;
};

class AABoxHand : public ClockHand
{
public:
	AABoxHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a);
	~AABoxHand();
	void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);

protected:
	Pen* polyPen;
	SolidBrush* polyBrush;
};

class BoxHand : public ClockHand
{
public:
	BoxHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a);
	~BoxHand();
	void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);
	
protected:
	HPEN hpen;
	HBRUSH hbrush;
};

class AALineHand : public ClockHand
{
public:
	AALineHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a);
	~AALineHand();
	void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);

protected:
	Pen* linePen;
};

class LineHand : public ClockHand
{
public:
	LineHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a);
	~LineHand();
	void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);
	
protected:
	HPEN hpen;
};

#endif