/*

	Trigonometric Buffer class, precalculates all the values
	on a circle with given precision (how many pieces the circle is divided into)

*/

#include <math.h>
#include "TrigBuffer.h"
#include "log_on.h"


#ifdef DEBUG
	#include <stdio.h>
#endif

#define pi 3.141592653589793238462643

TrigBuffer::TrigBuffer(int circle_steps=360)
{
	nSteps = circle_steps;
	dValues = new double[circle_steps];
}

TrigBuffer::~TrigBuffer()
{
	delete [] dValues;
}

double& TrigBuffer::operator[] (int i)
{
#ifdef _DEBUG
	if (i < nSteps && i >= 0)
		return dValues[i];
	else
		throw "TrigBuffer: Out of Bounds exception";
#else
	// to allow any value, for say calc of 360 degree sinus etc...
	return dValues[i % nSteps];
#endif

}

int TrigBuffer::GetPrecision()
{
	return nSteps;
}

// pre calculate the values, using shift to set start of circle
void TrigBuffer::Calc(int shift)
{
	double angle;
	#ifdef DEBUG
		FILE *out = fopen("c:\\buffer.log", "w");
	#endif
	for (int i = 0; i<nSteps; i++)
	{
		angle = 2 * pi * (double)(i+shift) / nSteps;
		dValues[i] = trig(angle);
		#ifdef DEBUG
			fprintf(out, "%d: %f - %f \n", i, angle, dValues[i]);
		#endif
	}
	#ifdef DEBUG
		fclose(out);
	#endif
}

SinBuffer::SinBuffer(int circle_steps=360, int start_shift=0) : TrigBuffer(circle_steps)
{
	Calc(start_shift);
}

double SinBuffer::trig(double i)
{
	return sin(i);
}


CosBuffer::CosBuffer(int circle_steps=360, int start_shift=0) : TrigBuffer(circle_steps)
{
	Calc(start_shift);
}

double CosBuffer::trig(double i)
{
	return cos(i);
}
