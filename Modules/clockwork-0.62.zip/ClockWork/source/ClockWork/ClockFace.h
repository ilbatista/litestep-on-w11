#ifndef __CLOCKFACE_H
#define __CLOCKFACE_H

#include "TrigBuffer.h"
#include "ClockHand.h"
#include "TextClock.h"
#include <windows.h>

#include <vector>
using namespace std;


/* ClockFace */

class ClockFace
{
public:
	ClockFace(LPCSTR prefix);
	~ClockFace();
	void DrawClock(const HDC hdc, HRGN hrgn);
	void CalcCenter();
	void CalcCenter(int, int);
	void SetSize(int w, int h);
	void SetBorders(int t, int l, int r, int b);
	void ReadClockSettings();
	int GetRefresh();

private:
	ClockDisplay* LoadDisplay(LPCSTR type, LPCSTR prefix, const int x, const int y, const int w, const int h);
	ClockHand* LoadHand(const int type_id, LPCSTR type, COLORREF ci, COLORREF co, int l, int w, int b, int a);

private:
	const char *Prefix;

	bool bNoSeconds;

	int nResolution;
	int nRefresh;

	vector<ClockDisplay*> displays;

	int nWidth;
	int nHeight;

	// borders
	int borderTop;
	int borderLeft;
	int borderRight;
	int borderBottom;

};

#endif