#ifndef __CLOCKDISPLAY_H
#define __CLOCKDISPLAY_H

#include "../VTK/apis.h"

/*

	Interface class for all clock parts that want to be updated by time

*/

extern LPCSTR szLogName;

class ClockDisplay
{
public:
	ClockDisplay() {};
	virtual ~ClockDisplay()
	{
		_LSLog(LOG_DEBUG, szLogName, "ClockDisplay destructor");
	};

	virtual void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time) = 0;
};

#endif