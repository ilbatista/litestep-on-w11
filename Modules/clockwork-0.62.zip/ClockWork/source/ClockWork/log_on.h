#ifndef __LOG_ON_H
#define __LOG_ON_H

#define DEBUG

//#define SPAMDEBUG

#endif