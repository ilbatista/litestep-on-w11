#ifndef __TRIGBUFFER_H
#define __TRIGBUFFER_H

class TrigBuffer
{
public:
	TrigBuffer(int circle_steps);
	~TrigBuffer();

	void Calc(int shift);
	double& operator[] (int i);
	int GetPrecision();

private:
	virtual double trig(double i) = 0;

private:
	double *dValues;
	int nSteps;

};

class SinBuffer : public TrigBuffer
{
public:
	SinBuffer(int circle_steps, int start_shift);

private:
	double trig(double i);
};

class CosBuffer : public TrigBuffer
{
public:
	CosBuffer(int circle_steps, int start_shift);

private:
	double trig(double i);
};

#endif