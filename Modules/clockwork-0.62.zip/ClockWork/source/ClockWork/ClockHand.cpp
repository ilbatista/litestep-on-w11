/* ClockHand */

#include <math.h>
#include "ClockHand.h"
#include <gdiplus.h>
using namespace Gdiplus;
#include "log_on.h"

#ifdef _DEBUG
	#include "../VTK/apis.h"
#endif

extern LPCSTR szLogName;

SinBuffer* ClockHand::sinus = NULL;
CosBuffer* ClockHand::cosinus = NULL;
float ClockHand::nCenterX = 0;
float ClockHand::nCenterY = 0;
bool ClockHand::bNoAdaptRegion = false;

#ifdef _DEBUG

double pythagoras(double x1, double x2)
{
	return ( sqrt( pow(x1, 2) + pow(x2, 2) ) );
}
#endif

ClockHand::ClockHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	clrIn(ci),
	clrOut(co),
	nLength(l),
	nWeight(w),
	nBorder(b),
	nAlpha(a),
	calc(NULL)
{
#ifdef _DEBUG
	_LSLogPrintf(LOG_DEBUG, "ClockHand", "Load id:%d, w:%d, l:%d, b:%d, a:%d", type_id, w, l, b, a);
#endif
	switch (type_id)
	{
		case HAND_HOUR:
			calc = new HourCalc;
		break;
		case HAND_MINUTE:
			calc = new MinuteCalc;
		break;
		case HAND_SECOND:
			calc = new SecondCalc;
		break;
		default:
		break;
	}
}

ClockHand::~ClockHand()
{
#ifdef _DEBUG
	_LSLog(LOG_DEBUG, szLogName, "ClockHand Destructor");
#endif
	if (calc)
		delete calc;
}

COLORREF ClockHand::GetColor()
{
	return clrOut;
}

COLORREF ClockHand::GetInnerColor()
{
	return clrIn;
}

int ClockHand::GetAlpha()
{
	return nAlpha;
}

int ClockHand::GetBorder()
{
	return nBorder;
}

int ClockHand::GetWeight()
{
	return nWeight;
}

int ClockHand::GetLength()
{
	return nLength;
}

void ClockHand::SetCenter(float cx, float cy)
{
	nCenterX = cx;
	nCenterY = cy;
}

float ClockHand::GetCenterX()
{
	return nCenterX;
}

float ClockHand::GetCenterY()
{
	return nCenterY;
}

void ClockHand::SetAdaptRegion(bool bNoAdapt)
{
	bNoAdaptRegion = bNoAdapt;
}

bool ClockHand::GetAdaptRegion()
{
	return !bNoAdaptRegion;
}

int round(double x)
{
	return (x - floor(x) >= 0.5) ? (int) x+1 : (int) x;

	/*if (x - floor(x) >= 0.5)
		return (int) x+1;
	else
		return (int) x;*/
}

// static convert between gdi+/gdi points
void ClockHand::ConvertToGDIPoint(POINT out[], const PointF in[], const int size)
{
	for (int i = 0; i < size; i++)
	{
		out[i].x = (int)(in[i].X);
		out[i].y = (int)(in[i].Y);
	}
}


/* LineHand, for drawing using lines */
LineHand::LineHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(type_id, ci, co, l, w, b, a)
{
	hpen = CreatePen(PS_SOLID, GetWeight(), GetColor());
}

LineHand::~LineHand()
{
	DeleteObject(hpen);
}

void LineHand::DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	HPEN hpenold;
	int end_x, end_y;
	int index = calc->GetIndex(time);

	end_x = GetCenterX() + GetLength() * (*sinus)[index];
	end_y = GetCenterY() + GetLength() * (*cosinus)[index];

	hpenold = (HPEN) SelectObject(hdc, hpen);

	MoveToEx(hdc, GetCenterX(), GetCenterY(), NULL);
	LineTo(hdc, end_x, end_y);
	SelectObject(hdc, hpenold);
}


/* AALineHand, for drawing using gdi+ lines */
AALineHand::AALineHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(type_id, ci, co, l, w, b, a)
{
#ifdef _DEBUG
	_LSLogPrintf(LOG_DEBUG, szLogName, "AALineHand constructor");
#endif
	Color line(GetAlpha(), GetRValue(GetColor()), GetGValue(GetColor()), GetBValue(GetColor()));
	linePen = new Pen(line, GetWeight());
}

AALineHand::~AALineHand()
{
#ifdef _DEBUG
	_LSLog(LOG_DEBUG, szLogName, "AALineHand Destructor");
#endif
	if (linePen)
	{
		_LSLogPrintf(LOG_DEBUG, szLogName, "Delete Pen: %d", linePen);
		delete linePen;
		_LSLog(LOG_DEBUG, szLogName, "delete done");
		linePen = NULL;
	}
#ifdef _DEBUG
	_LSLog(LOG_DEBUG, szLogName, "AALineHand Destructor done");
#endif
}

void AALineHand::DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	Graphics graphics(hdc);
	int index = calc->GetIndex(time);

	graphics.SetSmoothingMode(SmoothingModeAntiAlias);	

	// Initialize the coordinates of the points that define the line.
	REAL x1 = GetCenterX();
	REAL y1 = GetCenterY();
	REAL x2 = GetCenterX() + GetLength() * (*sinus)[index];
	REAL y2 = GetCenterY() + GetLength() * (*cosinus)[index];

	// Draw the line.
	graphics.DrawLine(linePen, x1, y1, x2, y2);
}


// static, calcs points for a box..
void ClockHand::CalcBoxPoints(bool aamode, PointF points[], const int index, const int weight, const int length)
{
	double width = weight/2;
	double lwidth, rwidth;

	/*if (true)//!aamode)
	{*/
		// for accurate width check using pythagoras
		lwidth = (int) width + ((int)weight%2);
		rwidth = (int) width;
	/*}
	else
	{
		lwidth = width;
		rwidth = width;
	}*/

	points[0].X = GetCenterX() - lwidth * (*cosinus)[index]; // l
	points[0].Y = GetCenterY() + lwidth * (*sinus)[index]; // l

	points[1].X = points[0].X + length * (*sinus)[index];
	points[1].Y = points[0].Y + length * (*cosinus)[index];

	points[3].X = GetCenterX() + rwidth * (*cosinus)[index]; // r
	points[3].Y = GetCenterY() - rwidth * (*sinus)[index]; // r

	points[2].X = points[3].X + length * (*sinus)[index];
	points[2].Y = points[3].Y + length * (*cosinus)[index];

#ifdef SPAMDEBUG
	_LSLogPrintf(LOG_DEBUG, "Box calc", "Width: %d", (int)(10*pythagoras(points[0].X-points[3].X, points[0].Y-points[3].Y)));
#endif

}


/* AABoxHand, for drawing using boxes and adding the region */
AABoxHand::AABoxHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(type_id, ci, co, l, w, b, a)
{
	Color poly(GetAlpha(), GetRValue(GetColor()), GetGValue(GetColor()), GetBValue(GetColor()));
	polyPen = new Pen(poly, GetBorder());
	Color in(GetAlpha(), GetRValue(GetInnerColor()), GetGValue(GetInnerColor()), GetBValue(GetInnerColor()));
	polyBrush = new SolidBrush(in);
	//polyPen->SetBrush(polyBrush);
}

AABoxHand::~AABoxHand()
{
	delete polyPen;
	delete polyBrush;
}

void AABoxHand::DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	Graphics graphics(hdc);

	//graphics.SetCompositingQuality(CompositingQualityGammaCorrected);
	graphics.SetSmoothingMode(SmoothingModeAntiAlias);

	PointF points[4];
	CalcBoxPoints(true, points, calc->GetIndex(time), GetWeight(), GetLength());
	POINT ps[4];
	ConvertToGDIPoint(ps, points, 4);

	if ( RGB(255, 0, 255) != GetInnerColor())
		graphics.FillPolygon(polyBrush, points, 4);

	graphics.DrawPolygon(polyPen, points, 4);

	if (GetAdaptRegion())
	{
		// adapt region to it as well
		HRGN add = CreatePolygonRgn(ps, 4, WINDING);
		CombineRgn(hrgn, hrgn, add, RGN_OR);
		DeleteObject(add);
	}
}


/* BoxHand, for drawing using boxes and adding the region */
BoxHand::BoxHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(type_id, ci, co, l, w, b, a)
{
	hpen = CreatePen(PS_SOLID, GetBorder(), GetColor());
	hbrush = CreateSolidBrush( GetInnerColor() );
}

BoxHand::~BoxHand()
{
	DeleteObject(hbrush);
	DeleteObject(hpen);
}

void BoxHand::DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	HPEN hpenold;
	HBRUSH hbrushold;

	PointF points[4];
	CalcBoxPoints(false, points, calc->GetIndex(time), GetWeight(), GetLength());
	POINT ps[4];
	ConvertToGDIPoint(ps, points, 4);

	SetPolyFillMode(hdc, WINDING);	
	hpenold = (HPEN) SelectObject(hdc, hpen);	
	hbrushold = (HBRUSH) SelectObject(hdc, hbrush);

	// draw using box polygon
	Polygon(hdc, ps, 4);

	if (GetAdaptRegion())
	{
		// adapt region to it as well
		HRGN add = CreatePolygonRgn(ps, 4, WINDING);
		CombineRgn(hrgn, hrgn, add, RGN_OR);
		DeleteObject(add);
	}

	SelectObject(hdc, hbrushold);
	SelectObject(hdc, hpenold);
}

// static, calcs points for a triangle..
void ClockHand::CalcTriPoints(bool aamode, PointF points[], const int index, const int weight, const int length)
{
	double width = weight/2;
	double lwidth, rwidth;

	/*if (true)//!aamode)
	{*/
		// for accurate width check using pythagoras
		lwidth = (int) width + ((int)weight%2);
		rwidth = (int) width;
	/*}
	else
	{
		lwidth = width;
		rwidth = width;
	}*/	

	points[0].X = GetCenterX() - lwidth * (*cosinus)[index]; // l
	points[0].Y = GetCenterY() + lwidth * (*sinus)[index]; // l

	points[1].X = GetCenterX() + length * (*sinus)[index];
	points[1].Y = GetCenterY() + length * (*cosinus)[index];

	points[2].X = GetCenterX() + rwidth * (*cosinus)[index]; // r
	points[2].Y = GetCenterY() - rwidth * (*sinus)[index]; // r

#ifdef SPAMDEBUG
	_LSLogPrintf(LOG_DEBUG, "Tri calc", "Width: %d", (int) (10* pythagoras(points[0].X-points[2].X, points[0].Y-points[2].Y)) );
#endif

}

/* AATriHand, for drawing using a triangle polygon and adding the region */
AATriHand::AATriHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(type_id, ci, co, l, w, b, a)
{
	Color poly(GetAlpha(), GetRValue(GetColor()), GetGValue(GetColor()), GetBValue(GetColor()));
	polyPen = new Pen(poly, GetBorder());
	Color in(GetAlpha(), GetRValue(GetInnerColor()), GetGValue(GetInnerColor()), GetBValue(GetInnerColor()));
	polyBrush = new SolidBrush(in);
	//polyPen->SetBrush(polyBrush);
}

AATriHand::~AATriHand()
{
	delete polyPen;
	delete polyBrush;
}

void AATriHand::DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	Graphics graphics(hdc);

	graphics.SetCompositingQuality(CompositingQualityGammaCorrected);
	graphics.SetSmoothingMode(SmoothingModeAntiAlias);

	PointF points[3];
	CalcTriPoints(true, points, calc->GetIndex(time), GetWeight(), GetLength());
	POINT ps[3];
	ConvertToGDIPoint(ps, points, 3);

	if ( RGB(255, 0, 255) != GetInnerColor())
		graphics.FillPolygon(polyBrush, points, 3);

	graphics.DrawPolygon(polyPen, points, 3);

	if (GetAdaptRegion())
	{
		// adapt region to it as well
		HRGN add = CreatePolygonRgn(ps, 3, WINDING);
		CombineRgn(hrgn, hrgn, add, RGN_OR);
		DeleteObject(add);
	}
}


/* TriHand, for drawing using a triangle polygon and adding the region */
TriHand::TriHand(const int type_id, COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(type_id, ci, co, l, w, b, a)
{
#ifdef _DEBUG
	_LSLog(LOG_DEBUG, szLogName, "TriHand Constructor");
#endif
	hpen = CreatePen(PS_SOLID, GetBorder(), GetColor());
	hbrush = CreateSolidBrush( GetInnerColor() );
}

TriHand::~TriHand()
{
#ifdef _DEBUG
	_LSLog(LOG_DEBUG, szLogName, "TriHand Destructor");
#endif
	DeleteObject(hbrush);
	DeleteObject(hpen);
}

void TriHand::DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	HPEN hpenold;
	HBRUSH hbrushold;

	PointF points[3];
	CalcTriPoints(false, points, calc->GetIndex(time), GetWeight(), GetLength());
	POINT ps[3];
	ConvertToGDIPoint(ps, points, 3);

	SetPolyFillMode(hdc, WINDING);
	hpenold = (HPEN) SelectObject(hdc, hpen);
	hbrushold = (HBRUSH) SelectObject(hdc, hbrush);

	// draw using triangle polygon
	Polygon(hdc, ps, 3);
	if (GetAdaptRegion())
	{
		// adapt region to it as well
		HRGN add = CreatePolygonRgn(ps, 3, WINDING);
		CombineRgn(hrgn, hrgn, add, RGN_OR);
		DeleteObject(add);
	}

	SelectObject(hdc, hbrushold);
	SelectObject(hdc, hpenold);	
}