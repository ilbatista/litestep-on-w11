import os

class SimpleVarFile:
  def __init__(self):
    return
  
  def read (self, filename):
    self.content = []
    fp = open (filename) 
    while True:
      evarline = fp.readline ()
      if evarline == "":
        break
      evarline = evarline.strip('\n').strip() #stripping unwanted whitespace and \n at beginning and end of each line line
      if (evarline) and (evarline[0] == ';'):    #is it a commentline?
        self.content.append (["",evarline])  #if it's a comment, add it but make the evar key "None"
      else:
        self.content.append (evarline.split (None, 1))  #if it's a normal line, add key and value
    return
  
  def write (self, filename):
    fp = open (filename, 'w')
    for i in self.content: 
      if not i:                          #is this line an empty line?
        fp.write ("\n")                  #if it is, just write a CRLF and move on
      else:
        fp.write (i[0] + ' ' + i[1] + '\n') #write out our (possibly) changed datas
    fp.close()
    return
  
  def getString (self, key):
    lowerkey = key.lower()
    for valuepair in self.content:
      if (lowerkey == valuepair[0].lower()):
        return valuepair[1]
    return None
    
  def setString (self, key, newvalue):
    lowerkey = key.lower()
    for valuepair in self.content:
      if (lowerkey == valuepair[0].lower()):
        valuepair[1] = newvalue
        return
    self.content.append ([key, newvalue])  
    return
    
    
  
# For testing this module
if __name__ == "__main__":
  test = SimpleVarFile()
  test.read ("testvarfile.rc")
  x = test.getString ("otsmajorversion")
  test.write ("testvarfile2.rc")
    
    