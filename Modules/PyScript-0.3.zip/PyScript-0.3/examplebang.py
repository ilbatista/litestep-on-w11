#any Python file which wants to call functions from LSAPI has to have
#such a line. The functions are provided by pyscript.dll
import LSAPI

#This is a bangfunction. It gets called when "!examplebang" is entered
#somewhere. the parameters are always have to be this way
def examplebang (hwnd, command, args):
  
  #LSExecute can execute bangs and programs alike
  #note the escaped doublequotes
  LSAPI.LSExecute (0, "!alert \"This is a bang, scripted with PyScript\" ", 1)  
  																																					   

#Any Python file which is called directly from PyScript has to have a
#InitModule function with the exact parameters hwnd, dllinst and szpath
def InitModuleEx (hwnd, dllinst, szpath):
  #Adds a bang "!pybang" which calls the function "examplebang" when called
  LSAPI.AddBangCommandEx ("!pybang", examplebang)
  #You have to return a zero so Litestep core assumes all went well, just like normal modules do
  return 0 
  
#The function to clean up after ourselves
def QuitModule ():
	#Removes our bang "!pybang" from the Litestep bang table
  LSAPI.RemoveBangCommand ("!pybang")
  return