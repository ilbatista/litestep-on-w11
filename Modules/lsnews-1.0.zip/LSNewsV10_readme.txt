///////////////////////////
// LSNews V1.0
// Release: 10/14/98
// Written By: MrJukes
// News By: [darkS]

// Installation
1) Unzip all the files to your litestep directory
2) Put the normal line in your step.rc
	*Wharf LSNews blah.bmp @c:\litestep\LSNews.app

// Usage
Double click on the module to get new news.
Right click to bring up the popup.

// Modules.ini

	[LSNews]

	// The server that holds the news file
	WebServer=www.xmission.com

	// The WWW port of that server
	Port=80

	// The file path to the news file on the server
	NewsFile=/~augestra/litestep.news 

	// The URL to this file would be- http://www.xmission.com/~augestra/litestep.news 

	// Whether to display the message box when it is done getting news
	MessageBox=1

	// The font to use
	Font=Console

	// The font color	: Format 0x00BBGGRR
	FontColor=0x00000000  

	// The font height
	FontHeight=10

	// The font width
	FontWidth=8

	// Whether to use italics
	Italics=0

	// Whether to underline
	Underline=0

	// Whether to strikeout
	Strikeout=0

Have fun,
	MrJukes
