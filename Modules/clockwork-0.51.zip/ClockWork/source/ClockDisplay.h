#ifndef __CLOCKDISPLAY_H
#define __CLOCKDISPLAY_H

/*

	Interface class for all clock parts that want to be updated by time

*/

class ClockDisplay
{
public:
	virtual void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time) = 0;
};

#endif