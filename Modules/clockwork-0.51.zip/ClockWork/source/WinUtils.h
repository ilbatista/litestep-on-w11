#ifndef __WINUTILS_H
#define __WINUTILS_H

#include <windows.h>

// name of shelldesktop class
#define WC_SHELLDESKTOP    "DesktopBackgroundClass"

// defines for strange windows version
#ifndef SPI_GETSCREENSAVERRUNNING
#define SPI_GETSCREENSAVERRUNNING 114
#endif

class WinUtils
{
public:
	static HWND GetDesktopHWND(void);
	static bool IsScreenSaverRunning(void);
	static bool IsWinNT5(void);
	static DWORD ModifyStyle(HWND hWnd, DWORD dwRemove, DWORD dwAdd);
};

#endif