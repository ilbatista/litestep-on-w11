/*

	Class that adds clicking to a window
	requires a GetHWND() function implemented in child class

*/

#include "Clickable.h"
#include "LSUtils.h"
#include "..\current\lsapi\lsapi.h"

//#define DEBUG

Clickable::Clickable(LPCSTR prefix) :
	OnLeftDBL(NULL),
	OnLeftDown(NULL),
	OnLeftUp(NULL),
	OnRightDBL(NULL),
	OnRightDown(NULL),
	OnRightUp(NULL),
	OnMiddleDBL(NULL),
	OnMiddleDown(NULL),
	OnMiddleUp(NULL),
	Prefix(prefix)
{

}

Clickable::~Clickable()
{
	if (OnLeftDBL)
		delete [] OnLeftDBL;
	if (OnLeftDown)
		delete [] OnLeftDown;
	if (OnLeftUp)
		delete [] OnLeftUp;
	if (OnRightDBL)
		delete [] OnRightDBL;
	if (OnRightDown)
		delete [] OnRightDown;
	if (OnRightUp)
		delete [] OnRightUp;
	if (OnMiddleDBL)
		delete [] OnMiddleDBL;
	if (OnMiddleDown)
		delete [] OnMiddleDown;
	if (OnMiddleUp)
		delete [] OnMiddleUp;

}

void Clickable::ReadClickSettings()
{
	char szTemp[MAX_LINE_LENGTH];
	memset(szTemp, 0, MAX_LINE_LENGTH);

	LSUtils::PrefixedGetRCLine(Prefix, "OnLeftDBL", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnLeftDBL = new char[strlen(szTemp)+1];
	strcpy(OnLeftDBL, szTemp);

	LSUtils::PrefixedGetRCLine(Prefix, "OnLeftDown", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnLeftDown = new char[strlen(szTemp)+1];
	strcpy(OnLeftDown, szTemp);

	LSUtils::PrefixedGetRCLine(Prefix, "OnLeftUp", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnLeftUp = new char[strlen(szTemp)+1];
	strcpy(OnLeftUp, szTemp);

	LSUtils::PrefixedGetRCLine(Prefix, "OnRightDBL", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnRightDBL = new char[strlen(szTemp)+1];
	strcpy(OnRightDBL, szTemp);

	LSUtils::PrefixedGetRCLine(Prefix, "OnRightDown", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnRightDown = new char[strlen(szTemp)+1];
	strcpy(OnRightDown, szTemp);

	LSUtils::PrefixedGetRCLine(Prefix, "OnRightUp", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnRightUp = new char[strlen(szTemp)+1];
	strcpy(OnRightUp, szTemp);

	LSUtils::PrefixedGetRCLine(Prefix, "OnMiddleDBL", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnMiddleDBL = new char[strlen(szTemp)+1];
	strcpy(OnMiddleDBL, szTemp);

	LSUtils::PrefixedGetRCLine(Prefix, "OnMiddleDown", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnMiddleDown = new char[strlen(szTemp)+1];
	strcpy(OnMiddleDown, szTemp);

	LSUtils::PrefixedGetRCLine(Prefix, "OnMiddleUp", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnMiddleUp = new char[strlen(szTemp)+1];
	strcpy(OnMiddleUp, szTemp);

}

void Clickable::BangExecute(const int ID)
{
	switch(ID)
	{
		case WM_LBUTTONDBLCLK:
		case LEFT_DBL:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetHWND(), OnLeftDBL, 0);
			#else
				LSExecute(GetHWND(), OnLeftDBL, 0);
			#endif
		break;
		case WM_LBUTTONDOWN:
		case LEFT_DOWN:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetHWND(), OnLeftDown, 0);
			#else
				LSExecute(GetHWND(), OnLeftDown, 0);
			#endif
		break;
		case WM_LBUTTONUP:
		case LEFT_UP:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetHWND(), OnLeftUp, 0);
			#else
				LSExecute(GetHWND(), OnLeftUp, 0);
			#endif
		break;

		case WM_RBUTTONDBLCLK:
		case RIGHT_DBL:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetHWND(), OnRightDBL, 0);
			#else
				LSExecute(GetHWND(), OnRightDBL, 0);
			#endif
		break;
		case WM_RBUTTONDOWN:
		case RIGHT_DOWN:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetHWND(), OnRightDown, 0);
			#else
				LSExecute(GetHWND(), OnRightDown, 0);
			#endif
		break;
		case WM_RBUTTONUP:
		case RIGHT_UP:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetHWND(), OnRightUp, 0);
			#else
				LSExecute(GetHWND(), OnRightUp, 0);
			#endif			
		break;

		case WM_MBUTTONDBLCLK:
		case MIDDLE_DBL:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetHWND(), OnMiddleDBL, 0);
			#else
				LSExecute(GetHWND(), OnMiddleDBL, 0);
			#endif			
		break;
		case WM_MBUTTONDOWN:
		case MIDDLE_DOWN:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetHWND(), OnMiddleDown, 0);
			#else
				LSExecute(GetHWND(), OnMiddleDown, 0);
			#endif			
		break;
		case WM_MBUTTONUP:
		case MIDDLE_UP:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetHWND(), OnMiddleUp, 0);
			#else
				LSExecute(GetHWND(), OnMiddleUp, 0);
			#endif			
		break;
	}
}