#ifndef __HANDCALC_H
#define __HANDCALC_H

#include <windows.h>

enum {
	HAND_SECOND,
	HAND_MINUTE,
	HAND_HOUR
};

class HandCalc
{
public:
	virtual void CalcIndexBuffer();
	virtual int GetIndex(const SYSTEMTIME time);
	static void SetResolution(int res);

protected:
	static int nResolution;
	static double n12PartSteps;
	static double n60PartSteps;
};

class HourCalc : public HandCalc
{
public:
	HourCalc();
	void CalcIndexBuffer();
	int GetIndex(const SYSTEMTIME time);

private:
	static int HourIndexBuffer[24][60];
};

class MinuteCalc : public HandCalc
{
public:
	MinuteCalc();
	void CalcIndexBuffer();
	int GetIndex(const SYSTEMTIME time);

private:
	static int MinuteIndexBuffer[60][60];
};

class SecondCalc : public HandCalc
{
public:
	SecondCalc();
	void CalcIndexBuffer();
	int GetIndex(const SYSTEMTIME time);

private:
	static int SecondIndexBuffer[60][1000];
};

#endif