#ifndef __CLOCKFACE_H
#define __CLOCKFACE_H

#include "TrigBuffer.h"
#include "ClockHand.h"
#include <windows.h>

#include <vector>
using namespace std;


/* ClockFace */

class ClockFace
{
public:
	ClockFace(LPCSTR prefix);
	~ClockFace();
	void DrawClock(const HDC hdc, HRGN hrgn);
	void CalcCenter(int, int);
	void ReadClockSettings();
	int GetRefresh();

private:
	ClockHand* LoadHand(const int type_id, LPCSTR type, COLORREF ci, COLORREF co, int l, int w, int b, int a);

private:
	const char *Prefix;

	BOOL bNoSeconds;

	int nResolution;
	int nRefresh;

	vector<ClockDisplay*> hands;

};

#endif