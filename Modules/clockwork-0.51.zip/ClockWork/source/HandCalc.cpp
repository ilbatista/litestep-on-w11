#include "HandCalc.h"
#include "log_on.h"

int HandCalc::nResolution = 0;
double HandCalc::n12PartSteps = 0;
double HandCalc::n60PartSteps = 0;

void HandCalc::SetResolution(int res)
{
	nResolution = res;
	n12PartSteps = (double)res / 12;
	n60PartSteps = (double)res / 60;
}

int HourCalc::HourIndexBuffer[24][60];
HourCalc::HourCalc()
{
	CalcIndexBuffer();
}

void HourCalc::CalcIndexBuffer()
{
	// hours
	// index = (double)(time.wHour % 12 + (double)time.wMinute/60) * n12PartSteps;
	for (int i=0; i<24; i++)
	{
		for (int j=0; j<60; j++)
		{
			HourIndexBuffer[i][j] = (double)(i % 12 + (double)j/60) * n12PartSteps;
		}
	}
}

int HourCalc::GetIndex(const SYSTEMTIME time)
{
	return HourIndexBuffer[time.wHour][time.wMinute];
}


int MinuteCalc::MinuteIndexBuffer[60][60];
MinuteCalc::MinuteCalc()
{
	CalcIndexBuffer();
}

void MinuteCalc::CalcIndexBuffer()
{
	// minutes
	// index = (double)(time.wMinute + (double)time.wSecond/60) * n60PartSteps;
	for (int i=0; i<60; i++)
	{
		for (int j=0; j<60; j++)
		{
			MinuteIndexBuffer[i][j] = (double)(i + (double)j/60) * n60PartSteps;
		}
	}
}

int MinuteCalc::GetIndex(const SYSTEMTIME time)
{
	return MinuteIndexBuffer[time.wMinute][time.wSecond];
}


int SecondCalc::SecondIndexBuffer[60][1000];
SecondCalc::SecondCalc()
{
	CalcIndexBuffer();
}

void SecondCalc::CalcIndexBuffer()
{
	// seconds
	// index = (double)(time.wSecond + (double)time.wMilliseconds/1000) * n60PartSteps;
	for (int i=0; i<60; i++)
	{
		for (int j=0; j<1000; j++)
		{
			SecondIndexBuffer[i][j] = (double)(i + (double)j/1000) * n60PartSteps;
		}
	}
}

int SecondCalc::GetIndex(const SYSTEMTIME time)
{
	return SecondIndexBuffer[time.wSecond][time.wMilliseconds];
}