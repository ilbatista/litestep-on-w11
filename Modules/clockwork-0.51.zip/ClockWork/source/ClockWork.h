#ifndef __ClockWork_H
#define __ClockWork_H

#include <windows.h>
#include <gdiplus.h>
using namespace Gdiplus;

#include "..\current\lsapi\lsapi.h"

#include "GuiWindow.h"
#include "Clickable.h"
#include "ClockFace.h"
#include "log_on.h"

#define MAX_LINE_LENGTH 4096

class ClockWork : public GuiWindow, Clickable
{
private:
	// for clock implementation:
	ClockFace clock;

	// borders
	int borderTop;
	int borderLeft;
	int borderRight;
	int borderBottom;
	BOOL borderDrag;
	BOOL bDoNotAlignUsingBorders;

	// bitmaps, etc
	HBITMAP hbmSkin; // bitmap
	HBITMAP hbmBack; // created image
	HRGN hrgnBack;
	BOOL bTranspBack;
	BOOL bSkinTiled;
	BOOL bTranspSkin;

	// GDI+
	GdiplusStartupInput gdiplusStartupInput;
	ULONG_PTR           gdiplusToken;

	// bg colors
	COLORREF clrBack;
	COLORREF clrBorder;

public:
	// for the Clickable class
	HWND GetHWND();
#ifdef DEBUG
	void Info();
#endif

	ClockWork(HWND parentWnd, int& code, bool Wharfed);
	~ClockWork();

private:
	void DrawClock(HDC hdc);
	void CreateBackground();
	void PaintBackground( HDC hdcDst, HRGN hrgnDst );
	int CopyBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc);
	int SizeBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc);
	void ReadSizeAndPos();
	void ReadGUIProps();

	virtual void windowProc(Message& message);

	//void onRefresh(Message& message);
	void onCreate(Message& message);
	void onDestroy(Message& message);
	void onDisplayChange(Message& message);
	void onPaint(Message& message);
	//void onWindowActivated(Message& message);
	//void onWindowPosChanging(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
	void onTimer(Message& message);

	void onMouse(Message& message);

};

#ifdef DEBUG
void BangInfo(HWND, LPCSTR);
#endif
void BangSetTime(HWND, LPCSTR);
void BangToggle(HWND, LPCSTR);
void BangHook(HWND, LPCSTR);
void BangSetOnTop(HWND, LPCSTR);
void BangToggleOnTop(HWND, LPCSTR);
void BangShow(HWND, LPCSTR);
void BangHide(HWND, LPCSTR);
void BangMove(HWND, LPCSTR);
void BangSize(HWND, LPCSTR);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
