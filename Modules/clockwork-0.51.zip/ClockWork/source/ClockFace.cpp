/*

	ClockFace class that handles all the clock functions

*/

#include <math.h>
#include "ClockFace.h"
#include "HandCalc.h"

#include "LSUtils.h"
#include "..\current\lsapi\lsapi.h"

#include "log_on.h"


/* ClockFace */

ClockFace::ClockFace(LPCSTR prefix) :
	bNoSeconds(false),
	Prefix(prefix),
	nResolution(60)
{
}

ClockFace::~ClockFace()
{
	for (vector<ClockDisplay*>::iterator i = hands.begin(); i != hands.end(); i++)
	{
		delete (ClockDisplay*)(*i);		
	}
	hands.clear();

	delete ClockHand::sinus;
	delete ClockHand::cosinus;
}

int ClockFace::GetRefresh()
{
	return nRefresh;
}

// drawing function, originally from aLsClock
void ClockFace::DrawClock(const HDC hdc, HRGN hrgn)
{
	SYSTEMTIME time;
	GetLocalTime(&time);

	// use objects in given order instead of switching on every update
	for (vector<ClockDisplay*>::iterator i = hands.begin(); i != hands.end(); i++)
	{
		(*i)->DrawClock(hdc, hrgn, time);
	}
}

void ClockFace::CalcCenter(int width, int height)
{
	// calculate center
	ClockHand::SetCenter((float)width / 2, (float)height / 2);
}

void ClockFace::ReadClockSettings()
{
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "Looking for prefix: %s", Prefix);
#endif

	char szMainHand[MAX_LINE_LENGTH];
	char szTemp[MAX_LINE_LENGTH];
	COLORREF ci, co;
	int w, l, b_main, b, a_main, a;
	int nCenterX = ClockHand::GetCenterX();
	int nCenterY = ClockHand::GetCenterY();
	ClockHand *second, *minute, *hour;

	LSUtils::PrefixedGetRCString(Prefix, "HandType", szMainHand, "line" , MAX_LINE_LENGTH);
	a_main = LSUtils::PrefixedGetRCInt(Prefix, "HandAlpha", 255);
	a_main = max(min(a_main, 255), 0);
	b_main = LSUtils::PrefixedGetRCInt(Prefix, "HandBorder", 1);

	ClockHand::SetAdaptRegion(LSUtils::PrefixedGetRCBool(Prefix, "NoAdaptRegion", TRUE));

	nResolution = min(LSUtils::PrefixedGetRCInt(Prefix, "Resolution", 60), 60000);
	nRefresh = LSUtils::PrefixedGetRCInt(Prefix, "Refresh", 60000/nResolution);

	HandCalc::SetResolution(nResolution);
	ClockHand::sinus = new SinBuffer(nResolution, 0);
	ClockHand::cosinus = new CosBuffer(nResolution, -(nResolution)/2);

	// seconds:
	bNoSeconds = LSUtils::PrefixedGetRCBool(Prefix, "NoSeconds", TRUE);
	if (!bNoSeconds)
	{
		LSUtils::PrefixedGetRCString(Prefix, "SecondHandType", szTemp, szMainHand , MAX_LINE_LENGTH);
		co = LSUtils::PrefixedGetRCColor(Prefix, "SecondColor", RGB(255, 0, 0));
		ci = LSUtils::PrefixedGetRCColor(Prefix, "SecondInnerColor", co);
		b = LSUtils::PrefixedGetRCInt(Prefix, "SecondBorder", b_main);
		w = LSUtils::PrefixedGetRCInt(Prefix, "SecondWeight", 1);
		l = LSUtils::PrefixedGetRCInt(Prefix, "SecondLength", 0.9*min(nCenterX, nCenterY));
		a = LSUtils::PrefixedGetRCInt(Prefix, "SecondAlpha", a_main);
		second = LoadHand(HAND_SECOND, szTemp, ci, co, l, w, b, a);
	}
	
	// minutes:
	LSUtils::PrefixedGetRCString(Prefix, "MinuteHandType", szTemp, szMainHand , MAX_LINE_LENGTH);
	co = LSUtils::PrefixedGetRCColor(Prefix, "MinuteColor", RGB(0, 255, 0));
	ci = LSUtils::PrefixedGetRCColor(Prefix, "MinuteInnerColor", co);
	b = LSUtils::PrefixedGetRCInt(Prefix, "MinuteBorder", b_main);
	l = LSUtils::PrefixedGetRCInt(Prefix, "MinuteLength", 0.9*min(nCenterX, nCenterY));
	w = LSUtils::PrefixedGetRCInt(Prefix, "MinuteWeight", 2);
	a = LSUtils::PrefixedGetRCInt(Prefix, "MinuteAlpha", a_main);
	minute = LoadHand(HAND_MINUTE, szTemp, ci, co, l, w, b, a);

	// hours:
	LSUtils::PrefixedGetRCString(Prefix, "HourHandType", szTemp, szMainHand , MAX_LINE_LENGTH);
	co = LSUtils::PrefixedGetRCColor(Prefix, "HourColor", RGB(0, 0, 255));
	ci = LSUtils::PrefixedGetRCColor(Prefix, "HourInnerColor", co);
	b = LSUtils::PrefixedGetRCInt(Prefix, "HourBorder", b_main);
	l = LSUtils::PrefixedGetRCInt(Prefix, "HourLength", 0.7*min(nCenterX, nCenterY));
	w = LSUtils::PrefixedGetRCInt(Prefix, "HourWeight", 3);
	a = LSUtils::PrefixedGetRCInt(Prefix, "HourAlpha", a_main);
	hour = LoadHand(HAND_HOUR, szTemp, ci, co, l, w, b, a);

	char t1[MAX_LINE_LENGTH], t2[MAX_LINE_LENGTH], t3[MAX_LINE_LENGTH];
	char* tokens[3] = {t1, t2, t3};

	LSUtils::PrefixedGetRCLine(Prefix, "DrawOrder", szTemp, MAX_LINE_LENGTH, "h m s");
	int count = LCTokenize(szTemp, tokens, 3, NULL);

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "order string: %s, c: %d", szTemp, count);
#endif
	
	for (int i = 0; i < count; i++)// count
	{
		// compile a list in what order functions should be run, since this is needs only be done once...
		switch(tokens[i][0])
		{
			case 'h':
				hands.push_back(hour);
			break;

			case 'm':
				hands.push_back(minute);
			break;

			case 's':
				if (!bNoSeconds)
				{
					hands.push_back(second);
				}
			break;
		}
	}

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "token string: %s, c: %d", szTemp, count);
	LSLogPrintf(LOG_DEBUG, Prefix, "lengths: h %d, m %d s %d", hour->GetLength(), minute->GetLength(), second->GetLength());
#endif

}

ClockHand* ClockFace::LoadHand(const int type_id, LPCSTR type, COLORREF ci, COLORREF co, int l, int w, int b, int a)
{
	if (stricmp(type, "box") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading boxhand");
#endif
		return new BoxHand(type_id, ci, co, l, w, b, a);
	}
	else if (stricmp(type, "triangle") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading trihand");
#endif
		return new TriHand(type_id, ci, co, l, w, b, a);
	}
	else if (stricmp(type, "aaline") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading AALineHand");
#endif
		return new AALineHand(type_id, ci, co, l, w, b, a);
	}
	else if (stricmp(type, "aabox") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading AABoxHand");
#endif
		return new AABoxHand(type_id, ci, co, l, w, b, a);
	}
	else if (stricmp(type, "aatriangle") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading AATriHand");
#endif
		return new AATriHand(type_id, ci, co, l, w, b, a);
	}
	else 
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading Linehand (default)");
#endif
		return new LineHand(type_id, ci, co, l, w, b, a);
	}
}