require "args";
--require "animation"; needs fixing (is this a lua problem?)
require "timer";
require "evar";
require "textedit";

for k,v in pairs( lslua ) do _G[ k ] = v end

function bang_pause_test( str )
    message_box( mouse().x, mouse().y );
    timer.pause( str );
    message_box( res().x, res().y );
    message_box( milli() );
end

function bang_args_test( str )
    local params = args.qsplit( str );
    for i, v in ipairs( params ) do
        message_box( v );
    end
end

function test1()
    local x = 500
    for i = 1, 20 do
        exec( "!LabelMoveBy", "anitest1", 5, 0 );
        timer.pause( "4s" );
        x = x - 20;
        animation.end_frame();
        message_box( "back to test1" );
    end
end

function test2()
    local x = 500
    for i = 1, 20 do
        exec( "!LabelMoveBy", "anitest2", 0, 5 );
        timer.pause( "4s" );
        x = x - 20;
        animation.end_frame();
        message_box( "back to test2" );
    end
end
--[[ FIXME: animations don't work in this release
function bang_animation_test( str )
    local cotest1 = animation.create( test1 );
    --local cotest2 = animation.create( test2 );
    animation.run( cotest1 );
    --animation.run( cotest2 );
    --cotest1 = animation.create( test1 );
    --cotest2 = animation.create( test2 );
    --animation.run( cotest1, cotest2 );
end
]]

function bang_textedit_test( str )
    --textedit.append( str,  "this is a test" );
    --textedit.insert( str, "%*ShortCut", ";this is a shortcut", "bg" );
    --textedit.delete( str, "whee", "ig" );
    --textedit.replace( str, "is", "are", "Ggi" );
    --message_box( textedit.find( str, "Whee", "i" )[1] or -1 );
    --message_box( textedit.delete_line( str, 9 ) );
    --message_box( textedit.insert_line( str, "whee!", 20, true ) or -1 );
    --message_box( textedit.get_line( str, 9 ) or -1 );
end
