#include <windows.h>
#include "C:\Microsoft Visual Studio\Ls Projects\IndieStep\lsapi\lsapi.h"


extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}
