#include "lscolor.h"

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath) {

	int code=0, i, r, g, b;
	char rgb[8], clrVal[8];
    bool sysBool;
	DWORD color;
    LOGFONT fontInfo;
    NONCLIENTMETRICS ncMetrics;

	int sysColorIndex[] = {COLOR_3DDKSHADOW, COLOR_3DFACE, COLOR_3DHILIGHT, COLOR_3DLIGHT,
		COLOR_3DSHADOW, COLOR_ACTIVEBORDER, COLOR_ACTIVECAPTION, COLOR_APPWORKSPACE,
		COLOR_BACKGROUND, COLOR_BTNTEXT, COLOR_CAPTIONTEXT,
//		COLOR_GRADIENTACTIVECAPTION, COLOR_GRADIENTINACTIVECAPTION,
		27, 28,
		COLOR_GRAYTEXT, COLOR_HIGHLIGHT, COLOR_HIGHLIGHTTEXT,
		COLOR_INACTIVEBORDER, COLOR_INACTIVECAPTION, COLOR_INACTIVECAPTIONTEXT,
		COLOR_INFOBK, COLOR_INFOTEXT, COLOR_MENU, COLOR_MENUTEXT, COLOR_SCROLLBAR, COLOR_WINDOW,
		COLOR_WINDOWFRAME, COLOR_WINDOWTEXT};

	char* varNameIndex[] = {"3dDkShadow", "3dFace", "3dHilight", "3dLight",
		"3dShadow", "ActiveBorder", "ActiveCaption", "AppWorkspace",
		"Background", "BtnText", "CaptionText",
		"GradientActiveCaption", "GradientInactiveCaption",
		"GrayText", "Hilight", "HilightText",
		"InactiveBorder", "InactiveCaption", "InactiveCaptionText",
		"InfoBk", "InfoText", "Menu", "MenuText", "Scrollbar", "Window",
		"Windowframe", "WindowText"};

	for ( i=0; i<(sizeof(sysColorIndex)/sizeof(int)); i++ ) {
		color = GetSysColor(sysColorIndex[i]);
//		wsprintf(bangCmd, "!setvar %s ", varNameIndex[i]);

		r = GetRValue(color);
		itoa(r, rgb, 16);
//		strcat(bangCmd, rgb);
          strcpy(clrVal, rgb);

		g = GetGValue(color);
		itoa(g, rgb, 16);
//		strcat(bangCmd, rgb);
          strcat(clrVal, rgb);

		b = GetBValue(color);
		itoa(b, rgb, 16);
//		strcat(bangCmd, rgb);
          strcat(clrVal, rgb);

//		LSExecute(NULL, bangCmd, 0);
          // LSSetVariable( LPCSTR var, LPCSTR value );
          LSSetVariable(varNameIndex[i], clrVal);
	}

    SystemParametersInfo(SPI_GETICONTITLELOGFONT, sizeof(LOGFONT), &fontInfo, 0);
//    wsprintf(bangCmd, "!setVar IconTitleFont %s", fontInfo.lfFaceName);
//    LSExecute(NULL, bangCmd, 0);
    LSSetVariable("IconTitleFont", fontInfo.lfFaceName);

    SystemParametersInfo(SPI_GETMENUDROPALIGNMENT, 0, &sysBool, 0);
//    wsprintf(bangCmd, "!setVar MenuDropAlignment %i", sysBool ? 1 : 0);
//    LSExecute(NULL, bangCmd, 0);
    itoa(sysBool ? 1 : 0, clrVal, 10);
    LSSetVariable("MenuDropAlignment", clrVal);

    ncMetrics.cbSize = sizeof(NONCLIENTMETRICS);
    SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncMetrics, 0);
//    wsprintf(bangCmd, "!setVar CaptionFont %s", ncMetrics.lfCaptionFont.lfFaceName);
//    LSExecute(NULL, bangCmd, 0);
    LSSetVariable("CaptionFont", ncMetrics.lfCaptionFont.lfFaceName);

//    wsprintf(bangCmd, "!setVar SmCaptionFont %s", ncMetrics.lfSmCaptionFont.lfFaceName);
//    LSExecute(NULL, bangCmd, 0);
    LSSetVariable("SmCaptionFont", ncMetrics.lfSmCaptionFont.lfFaceName);

//    wsprintf(bangCmd, "!setVar MenuFont %s", ncMetrics.lfMenuFont.lfFaceName);
//    LSExecute(NULL, bangCmd, 0);
    LSSetVariable("MenuFont", ncMetrics.lfMenuFont.lfFaceName);

//    wsprintf(bangCmd, "!setVar StatusFont %s", ncMetrics.lfStatusFont.lfFaceName);
//    LSExecute(NULL, bangCmd, 0);
    LSSetVariable("StatusFont", ncMetrics.lfSmCaptionFont.lfFaceName);

//    wsprintf(bangCmd, "!setVar MessageFont %s", ncMetrics.lfMessageFont.lfFaceName);
//    LSExecute(NULL, bangCmd, 0);
    LSSetVariable("MessageFont", ncMetrics.lfMessageFont.lfFaceName);


	return code;
}

void quitModule(HINSTANCE dllInst) {

}