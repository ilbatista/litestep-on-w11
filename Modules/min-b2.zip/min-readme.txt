///////////////////////////////
// Minimize to Desktop Icon
// By: MrJukes
// Released: 2/3/99
///////////////////////////////

Left click and drag will drag the icon around.
Double click with the left will restore the window.

To load in your step.rc put this line AFTER loading desktop.dll:
	LoadModule c:\litestep\min.dll

Have fun,
	MrJukes

// Things that will be added
- User definable size
- User definable starting point
- User definable direction
- More user definable stuff
- Transparency *shudder*