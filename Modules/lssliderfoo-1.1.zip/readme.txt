[Changelog]

1.1 : Major fix, 1.0 was an old testversion, not functional, 1.1 should work;)
1.0 : Initial Release

Just a small mod of the lsslider source, 
basically converts it to use foobar2000 with the foo_remote plugin.

by thegeek @ efnet.


I don't know how all this works, so if anyone has any objections to me
releasing this, please let me know. I just thought someone(like me)
would really like to use this. I really suck at programming, so the code is probably terrible.
However, it does work, just make sure to replace your slider line

from (example): 
*Slider "Track"  $SlidersX$ 12 1 "SliderTrack.png" "SliderHandleT.png" #1HIT [WINAMP] 0
to:
*Slider "Track"  $SlidersX$ 12 1 "SliderTrack.png" "SliderHandleT.png" #1HIT [FOOBAR] 0 