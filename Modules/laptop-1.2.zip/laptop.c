/************************************************

  laptop.dll v1.2

  by: Jeb Crouson (TrOgI)
  crouson@inreach.com
  http://lssource.cjb.net

  updated by Syl
  rouque_s@epita.fr
  http://www.epita.fr/~rouque_s

************************************************/

#include <windows.h>
#include <stdio.h>
#include "laptop.h"
#include "lsapi.h"

void Standby(HWND caller, const char* arg);
void Hibernate(HWND caller, const char* arg);
void Shutdown(HWND caller, const char* arg);
void Restart(HWND caller, const char* arg);
void Power(HWND caller, const char* arg);
void PCCard(HWND caller, const char* arg);

int adjustPrivilege()
{
	HANDLE hToken; 
	TOKEN_PRIVILEGES tkp; 
	OSVERSIONINFO os = { sizeof(os) };
 
	GetVersionEx(&os);
	if (VER_PLATFORM_WIN32_NT != os.dwPlatformId)
		return 0;

	// Get a token for this process. 
 

	if (!OpenProcessToken(GetCurrentProcess(), 
			TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
		return -1;
 
	// Get the LUID for the shutdown privilege. 
 
	LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, 
			&tkp.Privileges[0].Luid); 
 
	tkp.PrivilegeCount = 1;  // one privilege to set    
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
 
	// Get the shutdown privilege for this process. 
 
	AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
			(PTOKEN_PRIVILEGES)NULL, 0); 
 
	// Cannot test the return value of AdjustTokenPrivileges. 
 
	if (GetLastError() != ERROR_SUCCESS) 
		return -2;

	return 0;
} 

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	AddBangCommand("!Standby", Standby);
	AddBangCommand("!Hibernate", Hibernate);
	AddBangCommand("!Shutdown2", Shutdown);
	AddBangCommand("!Restart", Restart);
	AddBangCommand("!Power", Power);
	AddBangCommand("!PCCard", PCCard);
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
}

void Standby(HWND caller, const char* arg)
{
	adjustPrivilege();
	SetSystemPowerState(TRUE, FALSE);
}

void Hibernate(HWND caller, const char* arg)
{
	adjustPrivilege();
	SetSystemPowerState(FALSE, FALSE);
}

void Shutdown(HWND caller, const char* arg)
{
	adjustPrivilege();
	ExitWindowsEx(EWX_SHUTDOWN, 0);
}

void Restart(HWND caller, const char* arg)
{
	adjustPrivilege();
	ExitWindowsEx(EWX_REBOOT, 0);
}

void Power(HWND caller, const char* arg)
{
	char winDir[128];
	GetSystemDirectory(winDir, 128);
	ShellExecute(caller, "open", "rundll32.exe", "shell32.dll,Control_RunDLL powercfg.cpl", winDir, SW_SHOWNORMAL);
}

void PCCard(HWND caller, const char* arg)
{
	char winDir[128];
	GetSystemDirectory(winDir, 128);
	ShellExecute(caller, "open", "rundll32.exe", "shell32.dll,Control_RunDLL main.cpl PC Card (PCMCIA)", winDir, SW_SHOWNORMAL);
}