#ifndef __VOICECOMMAND_H
#define __VOICECOMMAND_H

class CTestGramNotify : public CSRGramNotifySink
{
public:
    STDMETHODIMP PhraseFinish(DWORD, QWORD, QWORD, PSRPHRASEW, LPUNKNOWN);
};
typedef CTestGramNotify * PCTestGramNotify;

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif

#endif