*****************************************
*	VoiceX 0.1			*
*	by Jeb Crouson (aka TrOgI)	*
*	crouson@inreach.com		*
*****************************************

Intro
~~~~~
This module uses speech recognition to allow you to execute commands with your voice. A grammar file is used to set the commands to be recognized and the actions to take when a command is recognized.


How to use
~~~~~~~~~~
First you must have the Microsoft SAPI 4.0 and Speech Recognition Engine installed. They can be found at http://www.microsoft.com/downloads/release.asp?ReleaseID=26299 (get the SAPI4SDKSUITE.exe) which includes an SDK or at http://www.microsoft.com/msagent/downloads.htm (get the SAPI4 runtime libraries and the speech recognition engine).

Next you must write your grammar in a file as the following example:

[(commands)]
1=winamp
2=play
3=stop
4=notepad
5=time

[Actions]
1=!Amp_Power
2=!Amp_Play
3=!Amp_Stop
4=notepad
5=d:\lsdistro\ctime.exe

The commands are the words that the speech engine will listen for and the actions are what this module will execute when a command is recognized. Commands must be first in the file and the [(commands)] and [Actions] must be used. You may use as many numbered commands and corresponding actions as you like. Do not use paths with spaces in them.

Then load the module in your step.rc...

	LoadModule VoiceX.dll

And set your grammer file in your step.rc...

	VoiceXGrammarFile "c:\litestep\grammarfile.txt"

and use the bang commands to turn the speech recognition engine on and off....


Step.rc Commands
~~~~~~~~~~~~~~~~
VoiceXGrammarFile "full path to file"

example:
VoiceXGrammarFile "c:\litestep\voicex_grammar.txt"


Bang Commands
~~~~~~~~~~~~~
!VoiceXOn			;turns speech recognition on
!VoiceXOff			;turns speech recognition off


Many thanks go to MrJukes for releasing the source to his LiteSpeak module which gave me the inspiration and the basis for this module.

Please send all bug reports to crouson@inreach.com
This is beta software. Use at your own risk.