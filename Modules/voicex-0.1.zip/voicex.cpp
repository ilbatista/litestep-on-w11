#include <windows.h>
#include <initguid.h>
#include <spchwrap.h>

#include "lsapi.h"
#include "voicex.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "VoiceX"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Function Prototypes
void BangVXOn(HWND caller, LPCSTR args);
void BangVXOff(HWND caller, LPCSTR args);
void BangVXToggle(HWND caller, LPCSTR args);
int Initialize();
void Destroy();

HWND hMainWnd;
LPSTR szGrammar = NULL;
LPSTR szGrammarFile = NULL;
BOOL bActivated = FALSE;

PCTestGramNotify	pGramNotifySink;
PCSRGramComp        gpCSRGramComp = NULL;
PCSRMode			pCSRMode = NULL;

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	char szGrammarTemp[256];

	WNDCLASS wc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name

	if (!RegisterClass(&wc)) 
	{
		MessageBox(NULL,"Error registering window class",szAppName, MB_OK);
		return 1;
	}

    hMainWnd = CreateWindowEx(0, szAppName, szAppName, WS_POPUP, 0, 0, 0, 0, 0, NULL, dllInst, 0);

    if (!hMainWnd) 
    {						   
        MessageBox(NULL,"Error creating window",szAppName,MB_OK);
        return 1;
    }

	GetRCString("VoiceXGrammarFile", szGrammarTemp, "", 256);
	szGrammarFile = new char[strlen(szGrammarTemp) + 1];
	strcpy(szGrammarFile, szGrammarTemp);

    if (!Initialize())
	{
		MessageBox(NULL, "Error Initializing Speech Recognition", szAppName, MB_OK);
		return 0;
	}

	AddBangCommand("!VoiceXOn", BangVXOn);
	AddBangCommand("!VoiceXOff", BangVXOff);
	AddBangCommand("!VoiceXToggle", BangVXToggle);

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!VoiceXOn");
	RemoveBangCommand("!VoiceXOff");
	RemoveBangCommand("!VoiceXToggle");

	Destroy();
    DestroyWindow(hMainWnd);
    UnregisterClass(szAppName, dllInst);
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
		SendMessage(GetLitestepWnd(), message, wParam, lParam);
		break;
    case WM_SYSCOMMAND:
		if(wParam == SC_CLOSE)
			PostMessage(GetLitestepWnd(), WM_KEYDOWN, LM_SHUTDOWN, 0);
		else
			DefWindowProc(hwnd, message, wParam, lParam);
		break;
    case LM_RECYCLE:
		SendMessage(GetLitestepWnd(), message, wParam, lParam);
		break;
    case WM_CREATE:
		break;
    case WM_ERASEBKGND:
		break;
    case LM_REGISTERMESSAGE:
    case LM_UNREGISTERMESSAGE:
		SendMessage(GetLitestepWnd(), message, wParam, lParam);
		break;
    default:
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}

STDMETHODIMP CTestGramNotify::PhraseFinish(DWORD dwFlags, QWORD qTimeStampBegin, QWORD qTimeStampEnd, PSRPHRASEW pSRPhrase, LPUNKNOWN lpResults)
{
    WCHAR	*pszRet = NULL;
    DWORD	dwRetSize;
    DWORD	dwRetVal;
    HRESULT	hRes;
    char    szTemp[64];
	char    szTemp2[1024];

    hRes = gpCSRGramComp->PhraseParse(pSRPhrase, &dwRetVal, &pszRet, &dwRetSize);
    if(hRes)
        return NOERROR;
    else
	{
        sprintf(szTemp, "%d", (int) dwRetVal);
		GetPrivateProfileString("Actions", szTemp, NULL, szTemp2, sizeof(szTemp2), szGrammarFile);
		LSExecute(NULL, szTemp2, NULL);
    }
    if(pszRet)
        CoTaskMemFree(pszRet);
	return NOERROR;
}

void BangVXOn(HWND caller, LPCSTR args)
{
	if(!bActivated)
	{
		HRESULT hRes;
		hRes = gpCSRGramComp->Activate();
		if(hRes)
			MessageBox(NULL, "Speech Recognition failed to turn on!", "DirectSpeechRecognition", MB_OK);
		else
			bActivated = TRUE;
	}
}

void BangVXOff(HWND caller, LPCSTR args)
{
	if(bActivated)
	{
		HRESULT hRes;
		hRes = gpCSRGramComp->Deactivate();
		if(hRes)
			MessageBox(NULL, "Speech Recognition failed to turn off!", "DirectSpeechRecognition", MB_OK);
		else
			bActivated = FALSE;
	}
}

void BangVXToggle(HWND caller, LPCSTR args)
{
	if(bActivated)
		BangVXOff(NULL, NULL);
	else
		BangVXOn(NULL, NULL);
}

void GetGrammar()
{
	FILE *fp;
	char temp[256];
	char szGramTemp[1024] = "[Grammar]\nLangID=1033\n";

	if((fp = fopen(szGrammarFile, "r")) != NULL)
	{
		while(!feof(fp))
		{
			if(fgets(temp, sizeof(temp), fp) != NULL)
			{
				temp[lstrlen(temp)-1] = 0;
				if(lstrlen(temp))
				{
					if(!lstrcmpi(temp, "[Actions]"))
						break;

					strcat(szGramTemp, temp);
					strcat(szGramTemp, "\n");
				}
			}
		}
	}
	fclose(fp);

	szGrammar = new char[strlen(szGramTemp) + 1];
	strcpy(szGrammar, szGramTemp);
}

int Initialize()
{
	CoInitialize(NULL);

	pCSRMode = new CSRMode;
    if(!pCSRMode)
		return -1;

    HRESULT hRes;
    hRes = pCSRMode->Init();
    if(hRes)
		return -1;

	pGramNotifySink = new CTestGramNotify;
    if(!pGramNotifySink)
        return -1;
	
	GetGrammar();

    gpCSRGramComp = pCSRMode->GrammarFromMemory(pGramNotifySink, szGrammar, strlen(szGrammar)+1);
    if(!gpCSRGramComp)
        return -1;

	return 1;
}

void Destroy()
{
	if(gpCSRGramComp)
        delete gpCSRGramComp;
	if(pGramNotifySink)
		delete pGramNotifySink;
	if(pCSRMode)
        delete pCSRMode;

	CoUninitialize();
}