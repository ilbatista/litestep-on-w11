How to Skin
===========
The borders and background images are stored in the [Images] section
of the lsplaylist.cfg.  Here is an example:

[Images]
TopBorder=.\skins\default\border-top.bmp
BottomBorder=.\skins\default\border-bottom.bmp
LeftBorder=.\skins\default\border-left.bmp
RightBorder=.\skins\default\border-right.bmp
MainBackground=.\skins\default\bg-main.bmp

There is only Magic Pink(tm) support for the MainBackground image.