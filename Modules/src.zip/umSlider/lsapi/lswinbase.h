#ifndef __LSWINBASE_H
#define __LSWINBASE_H

#define BEGIN_MESSAGEPROC	{Message message={uMsg,lParam,wParam,0}; switch (message.uMsg) {
#define MESSAGE(handler, msg) case msg: handler(message); break;
#define REJECT_MESSAGE(msg) case msg: break;
#define END_MESSAGEPROC default: message.lResult = DefWindowProc(m_hWnd, message.uMsg, message.wParam, message.lParam); } return message.lResult;}

struct Message
{
	UINT uMsg;
	union 
	{
		struct
		{
			WPARAM wParam;
			LPARAM lParam;
			LRESULT lResult;
		};
		struct
		{
			WORD wParamLo;
			WORD wParamHi;
			WORD lParamLo;
			WORD lParamHi;
			WORD lResultLo;
			WORD lResultHi;
		};
	};
};

// Code for multimonitor systems
#define SCREEN_LEFT GetSystemMetrics(SM_XVIRTUALSCREEN)
#define SCREEN_TOP GetSystemMetrics(SM_YVIRTUALSCREEN)
#define IS_MULTI_MON (GetSystemMetrics(SM_CMONITORS) > 1)
#define SCREEN_WIDTH (IS_MULTI_MON ? GetSystemMetrics(SM_CXVIRTUALSCREEN) : GetSystemMetrics(SM_CXSCREEN))
#define SCREEN_HEIGHT (IS_MULTI_MON ? GetSystemMetrics(SM_CYVIRTUALSCREEN) : GetSystemMetrics(SM_CYSCREEN))


#endif
