/***************************************************************************
****************************************************************************

This is a part of the xModule Source code.

Copyright (C) 2003-2006 The LS-Universe Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

****************************************************************************
****************************************************************************/

#if !defined(AFX_XEXPORTS_H__51ECA8C7_D434_472F_A091_729640965DEB__INCLUDED_)
#define AFX_XEXPORTS_H__51ECA8C7_D434_472F_A091_729640965DEB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef XPAINTCLASS_EXPORTS
	#define XPAINTCLASS_API __declspec(dllexport)
#else
	#define XPAINTCLASS_API __declspec(dllimport)
#endif

//Enable This Line, If you want to use the xPaintHTMLText Class! MFC required!
//Otherwise keep this commented.
//#define HTMLTEXT_MFC

#include "BasicDefines.h"

#include "PaintTexture.h"
#include "PaintIcon.h"
#include "PaintText.h"
#ifdef HTMLTEXT_MFC
	#include "PaintHTMLText.h"
#endif
#include "PaintTooltip.h"

XPAINTCLASS_API HMONITOR GetMonitor(int iMonitor);

XPAINTCLASS_API BOOL IsOS(const int &os);
XPAINTCLASS_API int QueryPixelDepth();
XPAINTCLASS_API HWND GetLitestepDesktop();
XPAINTCLASS_API BOOL IsAppWindow(const HWND &hWnd);

XPAINTCLASS_API void ModifyStyle(HWND hWnd, DWORD removeStyle, DWORD addStyle);
XPAINTCLASS_API void ModifyStyleEx(HWND hWnd, DWORD removeStyle, DWORD addStyle);

XPAINTCLASS_API BOOL GetxRCBool(LPCSTR uniqueKey, LPCSTR baseName, BOOL defaultVal = FALSE);
XPAINTCLASS_API BOOL Getx2RCBool(LPCSTR uniqueKey, LPCSTR baseName, BOOL defaultVal = FALSE);

XPAINTCLASS_API void GetxRCString(LPSTR pszValue, LPCSTR uniqueKey, LPCSTR baseName, LPCSTR defaultVal);
XPAINTCLASS_API void Getx2RCString(LPSTR pszValue, LPCSTR uniqueKey, LPCSTR baseName, LPCSTR defaultVal);

XPAINTCLASS_API void GetxRCLine(LPSTR pszValue, LPCSTR uniqueKey, LPCSTR baseName, LPCSTR defaultVal);
XPAINTCLASS_API void Getx2RCLine(LPSTR pszValue, LPCSTR uniqueKey, LPCSTR baseName, LPCSTR defaultVal);

XPAINTCLASS_API int GetxRCNamedValue(LPCSTR uniqueKey, LPCSTR baseName, const NameValuePair *nameValuePairs, int defaultVal);
XPAINTCLASS_API int Getx2RCNamedValue(LPCSTR uniqueKey, LPCSTR baseName, const NameValuePair *nameValuePairs, int defaultVal);

XPAINTCLASS_API int GetxRCColor(LPCSTR uniqueKey, LPCSTR baseName, int defaultVal);
XPAINTCLASS_API int Getx2RCColor(LPCSTR uniqueKey, LPCSTR baseName, int defaultVal);

XPAINTCLASS_API int GetxRCInt(LPCSTR uniqueKey, LPCSTR baseName, int defaultVal, int minVal = MIN_INTEGER, int maxVal = MAX_INTEGER);
XPAINTCLASS_API int Getx2RCInt(LPCSTR uniqueKey, LPCSTR baseName, int defaultVal, int minVal = MIN_INTEGER, int maxVal = MAX_INTEGER);

XPAINTCLASS_API int xParseCoord(LPCSTR aString, int defaultVal, int maxVal, BOOL bYCoordinate);
XPAINTCLASS_API int GetxRCCoord(LPCSTR uniqueKey, LPCSTR baseName, int defaultVal, int maxVal, BOOL bYCoordinate);
XPAINTCLASS_API int Getx2RCCoord(LPCSTR uniqueKey, LPCSTR baseName, int defaultVal, int maxVal, BOOL bYCoordinate);

XPAINTCLASS_API int xParseDimen(LPCSTR aString, int defaultVal, int maxVal, BOOL bYCoordinate);
XPAINTCLASS_API int GetxRCDimen(LPCSTR uniqueKey, LPCSTR baseName, int defaultVal, int maxVal, BOOL bYCoordinate);
XPAINTCLASS_API int Getx2RCDimen(LPCSTR uniqueKey, LPCSTR baseName, int defaultVal, int maxVal, BOOL bYCoordinate);

XPAINTCLASS_API void TileBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, DWORD rasterOp);
XPAINTCLASS_API void HorizontalTileBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, DWORD rasterOp);
XPAINTCLASS_API void VerticalTileBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, DWORD rasterOp);
XPAINTCLASS_API void MultiBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, int cxLeft, int cyTop, int cxRight, int cyBottom, int mode, DWORD rasterOp);

XPAINTCLASS_API void PaintDesktopEx(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, int xSrc, int ySrc, BOOL updateCache);

XPAINTCLASS_API HWND FindWindowEx2(LPCSTR pszClass, LPCSTR pszTitle);

XPAINTCLASS_API PaintTexture *Create_xTextureClass();
XPAINTCLASS_API PaintIcon *Create_xIconClass();
XPAINTCLASS_API PaintText *Create_xTextClass();
#ifdef HTMLTEXT_MFC
	XPAINTCLASS_API PaintHTMLText *Create_xHTMLTextClass();
#endif
XPAINTCLASS_API PaintTooltip *Create_xTooltipClass(HWND hWndParent, HINSTANCE hInstanceParent);

XPAINTCLASS_API void Destroy_xTextureClass(PaintTexture *destroyTextureClass);
XPAINTCLASS_API void Destroy_xIconClass(PaintIcon *destroyIconClass);
XPAINTCLASS_API void Destroy_xTextClass(PaintText *destroyTextClass);
#ifdef HTMLTEXT_MFC
	XPAINTCLASS_API void Destroy_xHTMLTextClass(PaintHTMLText *destroyHTMLTextClass);
#endif
XPAINTCLASS_API void Destroy_xTooltipClass(PaintTooltip *destroyTooltipClass);

#endif // !defined(AFX_XEXPORTS_H__51ECA8C7_D434_472F_A091_729640965DEB__INCLUDED_)
