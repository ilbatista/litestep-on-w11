/***************************************************************************
****************************************************************************

This is a part of the xModule Source code.

Copyright (C) 2003-2006 The LS-Universe Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

****************************************************************************
****************************************************************************/

#if !defined(AFX_PAINTTEXTURE_H__5FE1534C_814C_44CB_97A9_3E4569FEE9C2__INCLUDED_)
#define AFX_PAINTTEXTURE_H__5FE1534C_814C_44CB_97A9_3E4569FEE9C2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef AC_SRC_ALPHA
	#define AC_SRC_ALPHA            0x00000001L
#endif

#ifndef XPAINTCLASS_EXPORTS
	#include <vector>
	using namespace std;
#endif

typedef vector<COLORREF> ColorRefList;
typedef vector<COLORREF>::iterator ColorRefListIterator;

typedef vector<int> ColorRepeatedList;
typedef vector<int>::iterator ColorRepeatedListIterator;

class PaintTexture  
{

public:
	PaintTexture();
	PaintTexture(const PaintTextureDefaults *pPaintTextureDefaults);
	virtual ~PaintTexture();

	XPAINTCLASS_API BOOL configure(LPCSTR pszName, LPCSTR pszPrefix, BOOL bUseAlphaMap = FALSE, const PaintTexture *pDefaultPaintTexture = NULL, const PaintTextureDefaults *pPaintTextureDefaults = NULL);
	
	XPAINTCLASS_API void apply(HDC desthDC, int x, int y, int width, int height, int iFrameCounter = -1);

	XPAINTCLASS_API int getPaintingMode()
	{
		return m_iPaintingMode;
	};

	XPAINTCLASS_API POINT getImageSize()
	{
		POINT ptSize; 
		ptSize.x = m_iImageWidth;
		ptSize.y = m_iImageHeight;
		return ptSize;
	};

private:

	bool Create_Image();
	bool Create_Icon();

	//*****************************************************************
	// Internal Variables
	//*****************************************************************
	
	bool m_bSpecialSetup;

	//Multi/SingleColor ImageBackup for less CPU
	int m_iOldPaintingWidth;
	int m_iOldPaintingHeight;

	BOOL m_bUseAlphaMap;

	HDC memoryDC;
	HBITMAP memoryBitmap;

	//*****************************************************************
	// Settings
	//*****************************************************************

	string m_strTexture_X;
	string m_strTexture_Y;

	string m_strTexture_Width;
	string m_strTexture_Height;

	// -1 Deactivated, 0 Image, 1 Icon, 2 MultiColor, 3 SingleColor, 4 BorderButton
	int m_iPaintingMode;

	//-----------------------------------------------------------------
	//Colors and Image/Icon
	//-----------------------------------------------------------------

	bool m_bDisablePerformanceCaching;

	int m_iBorderMethod;

	int m_iAlphaTransparency;

	bool m_bTrueTransparency;

	//-----------------------------------------------------------------
	//Icon
	//-----------------------------------------------------------------
	
	string m_strIconPath;

	int m_iExtractIconSize;

	//-----------------------------------------------------------------
	//Image
	//-----------------------------------------------------------------

	string m_strImagePath;
	
	int m_iImageHeight;
	int m_iImageWidth;

	string m_strImageEdges;
	int m_iLeftImageEdge;
	int m_iTopImageEdge;
	int m_iRightImageEdge;
	int m_iBottomImageEdge;

	string m_strImageCrop;
	int m_iLeftImageCrop;
	int m_iTopImageCrop;
	int m_iRightImageCrop;
	int m_iBottomImageCrop;

	int m_iMode;

	COLORREF m_clrHueColor;
	int m_iHueIntensity;
	int m_iLuminanceIntensity;	
	int m_iSaturationIntensity;

	COLORREF m_clrMixColor;
	int m_iMixIntensity;

	//Animation
	int m_iFrameWidth;
	int m_iFrameHeight;

	//-----------------------------------------------------------------
	//Colors
	//-----------------------------------------------------------------

	string m_strColors;

	COLORREF m_clrBackgroundColor;
	COLORREF m_clrDarkBevelColor;
	COLORREF m_clrLightBevelColor;
	
	string m_strGradientColors;

	string m_strGradientRepeatedColors;

	int m_iGradientType;
	int m_iGradientTransformationType;

	string m_strBevels;
	int m_iLeftBevel;
	int m_iRightBevel;
	int m_iTopBevel;
	int m_iBottomBevel;

	//*****************************************************************
	// Settings Based Lists
	//*****************************************************************

	ColorRefList GradientColors;

	ColorRepeatedList GradientRepeatedColors;

};

#endif // !defined(AFX_PAINTTEXTURE_H__5FE1534C_814C_44CB_97A9_3E4569FEE9C2__INCLUDED_)
