/***************************************************************************
****************************************************************************

This is a part of the xModule Source code.

Copyright (C) 2003-2006 The LS-Universe Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

****************************************************************************
****************************************************************************/

#if !defined(AFX_PAINTTEXT_H__895FC59C_0304_4812_993C_99470F931EA8__INCLUDED_)
#define AFX_PAINTTEXT_H__895FC59C_0304_4812_993C_99470F931EA8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class PaintText  
{
public:
	PaintText();
	PaintText(const PaintTextDefaults *pPaintTextDefaults);
	virtual ~PaintText();

	XPAINTCLASS_API BOOL configure(LPCSTR pszName, LPCSTR pszPrefix, BOOL bUseAlphaMap = FALSE, const PaintText *pDefaultPaintText = NULL, const PaintTextDefaults *pPaintTextDefaults = NULL);
	
	XPAINTCLASS_API void apply(HDC desthDC, int x, int y, int width, int height, LPCSTR pszDrawText, BOOL bMultiLine = FALSE, BOOL bSetScrolling = FALSE, BOOL bDisableExtras = FALSE);
	
	XPAINTCLASS_API POINT measure(HDC desthDC, int x, int width, LPCSTR pszDrawText, BOOL bWithBorders = FALSE);
	
	XPAINTCLASS_API int getAlphaTransparency()
	{
		return m_iFontAlphaTransparency;
	};

	XPAINTCLASS_API RECT getTextFade() 
	{
		RECT textFade;
		textFade.left = m_iLeftFade;
		textFade.right = m_iRightFade;
		textFade.top = m_iTopFade;
		textFade.bottom = m_iBottomFade;
		return textFade;
	};
	
	XPAINTCLASS_API RECT getBorder() 
	{
		RECT borders;
		borders.left = m_iLeftBorder;
		borders.right = m_iRightBorder;
		borders.top = m_iTopBorder;
		borders.bottom = m_iBottomBorder;
		return borders;
	};

private:

	void iapply(HDC desthDC, int x, int y, int width, int height, const string &drawText, bool bMultiLine, bool bSetScrolling);
	
	//*****************************************************************
	// Internal Variables
	//*****************************************************************

	HFONT Font;
	HFONT tmpFont;

	bool m_bUseAlphaMap;

	//*****************************************************************
	// Settings
	//*****************************************************************

	bool m_bFontVisible;

	int m_iFontAlphaTransparency;

	string m_strBorders;
	int m_iLeftBorder;
	int m_iTopBorder;
	int m_iRightBorder;
	int m_iBottomBorder;

	string m_strFontName;
	int m_iFontHeight;
	COLORREF m_clrFontColor;

	short m_shFontCharSet;

	bool m_bFontSmoothing;
	bool m_bFontClearType;

	bool m_bFontBold;
	bool m_bFontItalic;
	bool m_bFontUnderline;

	bool m_bFontShadow;
	int m_iFontShadowX;
	int m_iFontShadowY; 
	int m_iFontBlockedShadow;
	COLORREF m_clrFontShadowColor;

	bool m_bFontOutline;
	COLORREF m_clrFontOutlineColor;
	bool m_bFontOutlineExtra;

	COLORREF m_clrFontEmbossColor1;
	COLORREF m_clrFontEmbossColor2;

	int m_iFontAlign;
	int m_iFontVertAlign;

	bool m_bFontNoEllipsis;

	//-----------------------------------------------------------------
	//Font Fade Settings
	//-----------------------------------------------------------------

	string m_strFontFadeCFG;
	bool m_bFontFade;
	int m_iLeftFade;
	int m_iRightFade;
	int m_iTopFade;
	int m_iBottomFade;

};

#endif // !defined(AFX_PAINTTEXT_H__895FC59C_0304_4812_993C_99470F931EA8__INCLUDED_)
