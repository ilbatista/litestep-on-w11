/***************************************************************************
****************************************************************************

This is a part of the xModule Source code.

Copyright (C) 2003-2006 The LS-Universe Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

****************************************************************************
****************************************************************************/

#if !defined(AFX_PAINTICON_H__0FE004D8_B0BB_4DD8_917F_351C813F9214__INCLUDED_)
#define AFX_PAINTICON_H__0FE004D8_B0BB_4DD8_917F_351C813F9214__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class PaintIcon  
{
public:
	PaintIcon();
	PaintIcon(const PaintIconDefaults *pPaintIconDefaults);
	virtual ~PaintIcon();

	XPAINTCLASS_API BOOL configure(LPCSTR pszName, LPCSTR pszPrefix, BOOL bUsePositioning = TRUE, BOOL bUseAlphaMap = FALSE, const PaintIcon *pDefaultPaintIcon = NULL, const PaintIconDefaults *pPaintIconDefaults = NULL);
	
	XPAINTCLASS_API void apply(HDC hDC, int x, int y, int width, int height, HICON hIcon);

	XPAINTCLASS_API int getIconSize()
	{ 
		return m_iIcon_Size;
	};

private:

	//*****************************************************************
	// Internal Variables
	//*****************************************************************

	BOOL m_bUseAlphaMap;
	
	//*****************************************************************
	// Settings
	//*****************************************************************

	bool m_bIcon_Visible;

	string m_strIcon_X;
	string m_strIcon_Y;

	int m_iIcon_Size;

	int m_iIcon_AlphaTransparency;

	COLORREF m_clrIcon_HueColor;
	int m_iIcon_HueIntensity;
	int m_iIcon_LuminanceIntensity;
	int m_iIcon_SaturationIntensity;

	COLORREF m_clrIcon_MixColor;
	int m_iIcon_MixIntensity;

};

#endif // !defined(AFX_PAINTICON_H__0FE004D8_B0BB_4DD8_917F_351C813F9214__INCLUDED_)
