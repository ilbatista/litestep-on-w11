/***************************************************************************
****************************************************************************

This is a part of the xModule Source code.

Copyright (C) 2003-2006 The LS-Universe Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

****************************************************************************
****************************************************************************/

#if !defined(AFX_PAINTHTMLTEXT_H__E6E09A06_25F5_4AB9_947E_7F371B057D2C__INCLUDED_)
#define AFX_PAINTHTMLTEXT_H__E6E09A06_25F5_4AB9_947E_7F371B057D2C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "./MFC/HTMLFont.h"

class PaintHTMLText  
{
public:
	PaintHTMLText();
	PaintHTMLText(const PaintTextDefaults *pPaintTextDefaults);
	virtual ~PaintHTMLText();

	XPAINTCLASS_API BOOL configure(LPCSTR pszName, LPCSTR pszPrefix, BOOL bUseAlphaMap = FALSE, const PaintHTMLText *pDefaultPaintHTMLText = NULL, const PaintTextDefaults *pPaintTextDefaults = NULL);
	
	XPAINTCLASS_API void apply(HDC desthDC, int x, int y, int width, int height, LPCSTR drawText, LPSTR HREFActions = NULL, int iSetAlign = -1, int iSetVertAlign = -1, BOOL bSetScrolling = FALSE, BOOL bDisableExtras = FALSE);

	XPAINTCLASS_API POINT measure(HDC desthDC, int x, int width, LPCSTR drawText, BOOL bWithBorders = FALSE);
	
	XPAINTCLASS_API int getAlphaTransparency()
	{
		return m_iFontAlphaTransparency;
	};

	XPAINTCLASS_API RECT getTextFade() 
	{
		RECT textFade;
		textFade.left = m_iLeftFade;
		textFade.right = m_iRightFade;
		textFade.top = m_iTopFade;
		textFade.bottom = m_iBottomFade;
		return textFade;
	};
	
	XPAINTCLASS_API RECT getBorders() 
	{
		RECT borders;
		borders.left = m_iLeftBorder;
		borders.right = m_iRightBorder;
		borders.top = m_iTopBorder;
		borders.bottom = m_iBottomBorder;
		return borders;
	};

private:

	void iapply(HDC desthDC, int x, int y, int width, int height, const string &drawText, StringList &listHREFClickRegions, int iSetAlign = -1, int iSetVertAlign = -1, bool bSetScrolling = false);

	//*****************************************************************
	// Internal Variables
	//*****************************************************************

	bool m_bUseAlphaMap;

	CHTMLFont HTMLFont;

	//*****************************************************************
	// Settings
	//*****************************************************************

	bool m_bFontVisible;

	int m_iFontAlphaTransparency;

	string m_strBorders;
	int m_iLeftBorder;
	int m_iTopBorder;
	int m_iRightBorder;
	int m_iBottomBorder;

	string m_strFontName;
	int m_iFontHeight;
	COLORREF m_clrFontColor;

	short m_shFontCharSet;

	bool m_bFontSmoothing;
	bool m_bFontClearType;

	bool m_bFontBold;
	bool m_bFontItalic;
	bool m_bFontUnderline;

	bool m_bFontShadow;
	int m_iFontShadowX;
	int m_iFontShadowY; 
	int m_iFontBlockedShadow;
	COLORREF m_clrFontShadowColor;

	bool m_bFontOutline;
	COLORREF  m_clrFontOutlineColor;
	bool m_bFontOutlineExtra;

	COLORREF m_clrFontEmbossColor1;
	COLORREF m_clrFontEmbossColor2;

	int m_iFontAlign;
	int m_iFontVertAlign;

	bool m_bFontNoEllipsis;

	bool m_bLineBreak;
	int m_iNewlineSpace;

	//-----------------------------------------------------------------
	//Font Fade Settings
	//-----------------------------------------------------------------

	string m_strFontFadeCFG;
	bool m_bFontFade;
	int m_iLeftFade;
	int m_iRightFade;
	int m_iTopFade;
	int m_iBottomFade;

};

#endif // !defined(AFX_PAINTHTMLTEXT_H__E6E09A06_25F5_4AB9_947E_7F371B057D2C__INCLUDED_)
