/***************************************************************************
****************************************************************************

This is a part of the xModule Source code.

Copyright (C) 2003-2006 The LS-Universe Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

****************************************************************************
****************************************************************************/

#if !defined(AFX_BASICDEFINES_H__65EDA485_E98A_48EC_9389_7A57F10BC40E__INCLUDED_)
#define AFX_BASICDEFINES_H__65EDA485_E98A_48EC_9389_7A57F10BC40E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef XPAINTCLASS_EXPORTS
	#include <string>
	using namespace std;
#endif

#define OS_9X   0x0001
#define OS_NT   0x0002
#define OS_95   0x0004
#define OS_98   0x0008
#define OS_ME   0x0010
#define OS_NT4  0x0020
#define OS_2K   0x0040
#define OS_XP   0x0080
#define OS_2KXP 0x0100

//#define StringCbCopy(a, b, c) strncpy((a), (c), (b))
//#define StringCbPrintf _snprintf

// Seg@ was here =)
// #define StringCchCat(a, b, c) strncat((a), (c), (b))
// #define StringCchCopy(a, b, c) strncpy((a), (c), (b))

//#define StringCchLength(a, b, c) *(c) = strlen((a)), S_OK
//#define StringCchPrintf _snprintf

enum
{
	MULTIBLT_STRETCH,
	MULTIBLT_TILE,
	MULTIBLT_TILEHORIZONTAL,
	MULTIBLT_TILEVERTICAL
};

#define	GRADIENT_NONE			-1
#define	GRADIENT_HORIZONTAL		0
#define	GRADIENT_VERTICAL		1
#define	GRADIENT_RADIAL			2
#define	GRADIENT_DIAGONAL		3
#define	GRADIENT_FDIAGONAL		4
#define	GRADIENT_BDIAGONAL		5

#define	TRANSFORMATION_NONE			-1
#define	TRANSFORMATION_CHARICATURE  0
#define	TRANSFORMATION_FISHEYE		1
#define	TRANSFORMATION_SWIRLED		2
#define	TRANSFORMATION_CYLINDER		3
#define	TRANSFORMATION_SHIFT		4

const int MAX_INTEGER = 0x7FFFFFFF;
const int MIN_INTEGER = 0x80000000;

struct NameValuePair
{
	const char *name;
	int value;
};

struct PaintTextureDefaults
{
	PaintTextureDefaults() :
	m_strTexture_X("0"),
	m_strTexture_Y("0"),

	m_strTexture_Width("100%"),
	m_strTexture_Height("100%"),

	m_iPaintingMode(-1),

	//-----------------------------------------------------------------
	//Colors or Image
	//-----------------------------------------------------------------
	
	m_bDisablePerformanceCaching(FALSE),

	m_iBorderMethod(0),

	m_iAlphaTransparency(255),

	m_bTrueTransparency(FALSE),

	m_strImagePath(""),
	m_strIconPath(""),

	//-----------------------------------------------------------------
	//Icon
	//-----------------------------------------------------------------

	m_iExtractIconSize(32),

	//-----------------------------------------------------------------
	//Image/Icon
	//-----------------------------------------------------------------
	
	m_iImageHeight(64),
	m_iImageWidth(64),	
	
	m_strImageEdges(""),
	m_iLeftImageEdge(0),
	m_iTopImageEdge(0),
	m_iRightImageEdge(0),
	m_iBottomImageEdge(0),

	m_strImageCrop(""),
	m_iLeftImageCrop(0),
	m_iTopImageCrop(0),
	m_iRightImageCrop(0),
	m_iBottomImageCrop(0),

	m_iMode(MULTIBLT_STRETCH),

	m_clrHueColor(RGB(255,255,255)),
	m_iHueIntensity(0),
	m_iLuminanceIntensity(0),	
	m_iSaturationIntensity(100),

	m_clrMixColor(RGB(255,255,255)),
	m_iMixIntensity(0),

	m_iFrameWidth(0),
	m_iFrameHeight(0),

	//-----------------------------------------------------------------
	//Colors
	//-----------------------------------------------------------------

	m_strColors(""),

	m_clrBackgroundColor(RGB(255,255,255)),
	m_clrDarkBevelColor(GetSysColor(COLOR_3DLIGHT)),
	m_clrLightBevelColor(GetSysColor(COLOR_3DSHADOW)),

	m_strGradientColors(""),

	m_strGradientRepeatedColors(""),

	m_iGradientType(0),
	m_iGradientTransformationType(-1),

	m_strBevels(""),
	m_iLeftBevel(0),
	m_iRightBevel(0),
	m_iTopBevel(0),
	m_iBottomBevel(0)
	{};

	LPCSTR m_strTexture_X;
	LPCSTR m_strTexture_Y;

	LPCSTR m_strTexture_Width;
	LPCSTR m_strTexture_Height;

	int m_iPaintingMode;

	//-----------------------------------------------------------------
	//Colors or Image
	//-----------------------------------------------------------------
	
	BOOL m_bDisablePerformanceCaching;

	int m_iBorderMethod;

	int m_iAlphaTransparency;

	BOOL m_bTrueTransparency;

	//-----------------------------------------------------------------
	//Icon
	//-----------------------------------------------------------------
	
	LPCSTR m_strIconPath;

	int m_iExtractIconSize;

	//-----------------------------------------------------------------
	//Image/Icon
	//-----------------------------------------------------------------
	
	LPCSTR m_strImagePath;

	int m_iImageHeight;
	int m_iImageWidth;	
	
	LPCSTR m_strImageEdges;
	int m_iLeftImageEdge;
	int m_iTopImageEdge;
	int m_iRightImageEdge;
	int m_iBottomImageEdge;

	LPCSTR m_strImageCrop;
	int m_iLeftImageCrop;
	int m_iTopImageCrop;
	int m_iRightImageCrop;
	int m_iBottomImageCrop;

	int m_iMode;

	COLORREF m_clrHueColor;
	int m_iHueIntensity;
	int m_iLuminanceIntensity;	
	int m_iSaturationIntensity;

	COLORREF m_clrMixColor;
	int m_iMixIntensity;

	int m_iFrameWidth;
	int m_iFrameHeight;

	//-----------------------------------------------------------------
	//Colors
	//-----------------------------------------------------------------

	LPCSTR m_strColors;

	COLORREF m_clrBackgroundColor;
	COLORREF m_clrDarkBevelColor;
	COLORREF m_clrLightBevelColor;

	LPCSTR m_strGradientColors;

	LPCSTR m_strGradientRepeatedColors;

	int m_iGradientType;
	int m_iGradientTransformationType;

	LPCSTR m_strBevels;
	int m_iLeftBevel;
	int m_iRightBevel;
	int m_iTopBevel;
	int m_iBottomBevel;

};

struct PaintIconDefaults
{
	PaintIconDefaults() :
	m_bIcon_Visible(TRUE),

	m_strIcon_X(""),
	m_strIcon_Y(""),

	m_iIcon_Size(16),

	m_iIcon_AlphaTransparency(255),

	m_clrIcon_HueColor(RGB(255,255,255)),
	m_iIcon_HueIntensity(0),
	m_iIcon_LuminanceIntensity(0),
	m_iIcon_SaturationIntensity(100),

	m_clrIcon_MixColor(RGB(255,255,255)),
	m_iIcon_MixIntensity(0)
	{};

	BOOL m_bIcon_Visible;

	LPCSTR m_strIcon_X;
	LPCSTR m_strIcon_Y;

	int m_iIcon_Size;

	int m_iIcon_AlphaTransparency;

	COLORREF m_clrIcon_HueColor;
	int m_iIcon_HueIntensity;
	int m_iIcon_LuminanceIntensity;
	int m_iIcon_SaturationIntensity;

	COLORREF m_clrIcon_MixColor;
	int m_iIcon_MixIntensity;
};

struct PaintTextDefaults
{
	PaintTextDefaults() :
	m_bFontVisible(TRUE),

	m_iFontAlphaTransparency(255),

	m_strBorders(""),
	m_iLeftBorder(0),
	m_iTopBorder(0),
	m_iRightBorder(0),
	m_iBottomBorder(0),

	m_strFontName("Arial"),
	m_iFontHeight(15),
	m_clrFontColor(RGB(0,0,0)),

	m_shFontCharSet(DEFAULT_CHARSET),

	m_bFontSmoothing(TRUE),
	m_bFontClearType(TRUE),

	m_bFontBold(FALSE),
	m_bFontItalic(FALSE),
	m_bFontUnderline(FALSE),

	m_bFontShadow(FALSE),
	m_iFontShadowX(1),
	m_iFontShadowY(1),
	m_iFontBlockedShadow(0),
	m_clrFontShadowColor(RGB(128,128,128)),

	m_bFontOutline(FALSE),
	m_clrFontOutlineColor(RGB(128,128,128)),
	m_bFontOutlineExtra(FALSE),

	m_clrFontEmbossColor1(RGB(255,0,255)),
	m_clrFontEmbossColor2(RGB(255,0,255)),

	m_iFontAlign(DT_LEFT),
	m_iFontVertAlign(DT_VCENTER),

	m_bFontNoEllipsis(FALSE),

	m_bLineBreak(FALSE),
	m_iNewlineSpace(0),

	m_strFontFadeCFG("0"),
	m_iLeftFade(0),
	m_iRightFade(0),
	m_iTopFade(0),
	m_iBottomFade(0)
	{};

	BOOL m_bFontVisible;

	int m_iFontAlphaTransparency;

	LPCSTR m_strBorders;
	int m_iLeftBorder;
	int m_iTopBorder;
	int m_iRightBorder;
	int m_iBottomBorder;

	LPCSTR m_strFontName;
	int m_iFontHeight;
	COLORREF m_clrFontColor;

	short m_shFontCharSet;

	BOOL m_bFontSmoothing;
	BOOL m_bFontClearType;

	BOOL m_bFontBold;
	BOOL m_bFontItalic;
	BOOL m_bFontUnderline;

	BOOL m_bFontShadow;
	int m_iFontShadowX;
	int m_iFontShadowY; 
	int m_iFontBlockedShadow;
	COLORREF m_clrFontShadowColor;

	BOOL m_bFontOutline;
	COLORREF m_clrFontOutlineColor;
	BOOL m_bFontOutlineExtra;

	COLORREF m_clrFontEmbossColor1;
	COLORREF m_clrFontEmbossColor2;

	int m_iFontAlign;
	int m_iFontVertAlign;

	BOOL m_bFontNoEllipsis;

	BOOL m_bLineBreak;
	int m_iNewlineSpace;

	//-----------------------------------------------------------------
	//Font Fade Settings
	//-----------------------------------------------------------------

	LPCSTR m_strFontFadeCFG;
	int m_iLeftFade;
	int m_iRightFade;
	int m_iTopFade;
	int m_iBottomFade;

};

#endif // !defined(AFX_BASICDEFINES_H__65EDA485_E98A_48EC_9389_7A57F10BC40E__INCLUDED_)
