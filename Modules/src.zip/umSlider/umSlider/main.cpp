// main.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "main.h"
#include "utils.h"
#include "Slider.h"
#include "VolumeControl.h"
#include "TooltipService.h"
#include "bangs.h"

extern "C" {
    __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
    __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

HINSTANCE g_hInstance;

char g_szAppName[] = "umSlider";
char g_szSliderClass[] = "umSliderWindowClass";
char g_szHandleClass[] = "umSliderHandWindowClass";

int lsMessages[] =
{
	LM_GETREVID,
	0
};
HWND messageHandler;
LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
const char rcsRevision[] = "1.0";

CVolumeControl *g_pMixer = NULL;
CTooltipService *g_pTooltips = NULL;

PSLIDERLISTITEM g_pSliders = NULL;
void InitSliders();
CSlider* ParseSliderConfig(const char *szLine);

LRESULT WINAPI SliderWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
LRESULT WINAPI HandleWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int g_nVolumeStep;
int g_nBalanceStep;

////////////////////////////////////////////////////////////////////
//
// DLL entry point
//
BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

////////////////////////////////////////////////////////////////////
//
// Module entry point
//
int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
	g_hInstance = dll;

	// register the main window
	// it will handle LS and mixer messages

	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = MessageHandlerProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = g_hInstance;
	wc.hbrBackground = NULL;
	wc.hCursor = NULL;
	wc.hIcon = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = g_szAppName;
	wc.hIconSm = 0;

	if (!RegisterClassEx(&wc))
	{
		utils::ErrorBox("Cannot register main window class...");
		return 1;
	}

	ZeroMemory(&wc, sizeof(WNDCLASSEX));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.lpfnWndProc = SliderWindowProc;
	wc.lpszClassName = g_szSliderClass;
	wc.hInstance = g_hInstance;
	if (!RegisterClassEx(&wc))
	{
		utils::ErrorBox("Cannot register slider window class");
		return 1;
	}

	ZeroMemory(&wc, sizeof(WNDCLASSEX));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.lpfnWndProc = HandleWindowProc;
	wc.lpszClassName = g_szHandleClass;
	wc.hInstance = g_hInstance;
	if (!RegisterClassEx(&wc))
	{
		utils::ErrorBox("Cannot register handle window class");
		return 2;
	}

	messageHandler = CreateWindowEx(WS_EX_TOOLWINDOW,
		g_szAppName,
		0,
		WS_POPUP,
		0, 0, 0, 0, 
		0,
		0,
		dll,
		0);

	if (!messageHandler)
	{
		utils::ErrorBox("Cannot create main window...");
		return 1;
	}	
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM) messageHandler, (LPARAM) lsMessages);

	// try to create a mixer
	g_pMixer = new CVolumeControl(messageHandler);
	if (g_pMixer->m_nCode != 0)
	{
		// delete mixer object to prevent bangs from failure
		delete g_pMixer;
		g_pMixer = NULL;
		// it is safe to exit here since quitModule check
		// all pointers
		return 1;
	}

	g_pTooltips = new CTooltipService();
	g_pTooltips->Init(g_hInstance);


	InitCommonControls();

	InitSliders();

	RegisterBangs();

	return 0;
}

///////////////////////////////////////////////////////////////////////////
//
// Destructor :)
//
void quitModule(HINSTANCE dllInst)
{
	UnregisterBangs();

	while (g_pSliders)
	{
		PSLIDERLISTITEM pHead = g_pSliders;
		g_pSliders = g_pSliders->pNext;
		delete pHead->pSlider;
		delete pHead;

	}

	if (g_pMixer) delete g_pMixer;
	if (g_pTooltips) delete g_pTooltips;

	SendMessage(
		GetLitestepWnd(),
		LM_UNREGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	DestroyWindow(messageHandler);

	UnregisterClass(g_szAppName, dllInst);
	UnregisterClass(g_szSliderClass, dllInst);
	UnregisterClass(g_szHandleClass, dllInst);
}

////////////////////////////////////////////////////////////////////////////
//
// Main umSlider window created to process the following messages:
//	LM_GETREVID				-	Revision ID
//	MM_MIXM_LINE_CHANGE		-	Callback notification is much better
//	MM_MIXM_CONTROL_CHANGE		than timer
//
LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case LM_GETREVID:
		LPSTR buf;
		buf = (LPSTR)lParam;
		switch (wParam)
		{
		case 0:
		case 1:
			StringCchPrintf(buf, lParam, "umSlider: %s (Seg@, Brian)", rcsRevision);
			break;
		default:
			StringCchCopy(buf, lParam, "");
		}
		return strlen(buf);
	case MM_MIXM_LINE_CHANGE:
	case MM_MIXM_CONTROL_CHANGE:
		for (PSLIDERLISTITEM pIterator = g_pSliders; pIterator; pIterator = pIterator->pNext)
		{
			CSlider *pSlider = pIterator->pSlider;
			if (pSlider->m_nType != MODE_AMP && pSlider->m_nType != MODE_AMPVOLUME)
			{
				PostMessage(pSlider->m_hSlider, WM_UPDATE, 0, 0);
			}
		}
		break;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


///////////////////////////////////////////////////////////////////////////////////////
//
// Read the config and create sliders
//
void InitSliders()
{
	LPVOID f = LCOpen(NULL);		// step.rc
	if (!f)
	{
		utils::ErrorBox("Cannot open step.rc for reading the configuration");
		return;
	}

	// let's enumerate sliders

	char
		szLine[MAX_LINE_LENGTH],	// current line
		szExtra[MAX_LINE_LENGTH],
		token1[MAX_LINE_LENGTH],
		token2[MAX_LINE_LENGTH],
		*tokens[2] = {token1, token2};

	while (LCReadNextConfig(f, "*umSlider", szLine, MAX_LINE_LENGTH))
	{
		LCTokenize(szLine, tokens, 2, szExtra);
		if (token2[0] == 0)
		{
			utils::ErrorBox("Invalid config: *umSlider string without slider name found");
		}
		else
		{
			CSlider *pSlider = new CSlider(token2);
			if (!pSlider->m_bInitialized)
			{
				delete pSlider;
			}
			else
			{
				PSLIDERLISTITEM pItem = new SliderListItem;
				pItem->pSlider = pSlider;
				pItem->pNext = g_pSliders;
				g_pSliders = pItem;
			}
		}
	}
	if (!LCClose(f))
	{
		utils::ErrorBox("Error closing .RC");
	}
}


///////////////////////////////////////////////////////////////////////////////
//
// Find slider by window handle (both main and handle)
//
CSlider* GetSliderByWnd(HWND hWnd)
{
	for (PSLIDERLISTITEM pIterator = g_pSliders; pIterator; pIterator = pIterator->pNext)
	{
		if (pIterator->pSlider->m_hSlider == hWnd || pIterator->pSlider->m_hHandle == hWnd)
		{
			return pIterator->pSlider;
		}
	}
	return NULL;
}

CSlider* GetSliderByName(const char *szName)
{
	char szBuf[MAX_LINE_LENGTH];
	StringCchCopy(szBuf, MAX_LINE_LENGTH, szName);
	PathUnquoteSpaces(szBuf);
	PSLIDERLISTITEM pIterator = g_pSliders;
	while (pIterator)
	{
		if (_stricmp(pIterator->pSlider->m_szName, szBuf) == 0)
		{
			return pIterator->pSlider;
		}
		pIterator = pIterator->pNext;
	}
	return NULL;
}
