#ifndef __BANGS_HEADER__
#define __BANGS_HEADER__

// some contstants for bangs

#define MAX_SLIDER_NAME 64
#define MAX_OPTION_LENGTH 16

#define BANGMODE_NONE		0	// never used but I like such stuff =)
#define BANGMODE_MOVE		1	// !umSliderMove and MoveBy
#define BANGMODE_RESIZE		2	// !umSliderResize and ResizeBy
#define BANGMODE_REPOSITION	3	// !umSliderReposition and RepositionBy

void RegisterBangs();
void UnregisterBangs();

#endif