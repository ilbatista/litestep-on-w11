#ifndef __MAIN_HEADER__
#define __MAIN_HEADER__

extern char g_szAppName[];
extern char g_szSliderClass[];
extern char g_szHandleClass[];
extern HINSTANCE g_hInstance;

extern int g_nVolumeStep;
extern int g_nBalanceStep;

class CTooltipService;
class CVolumeControl;
extern CTooltipService *g_pTooltips;
extern CVolumeControl *g_pMixer;

class CSlider;

CSlider* GetSliderByWnd(HWND hWnd);
CSlider* GetSliderByName(const char *szName);

typedef struct tagSliderListItem
{
	CSlider *pSlider;
	struct tagSliderListItem *pNext;
} SliderListItem, *PSLIDERLISTITEM;

#endif