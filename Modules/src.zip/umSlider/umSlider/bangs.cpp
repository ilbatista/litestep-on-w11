#include "stdafx.h"
#include "bangs.h"
#include "main.h"
#include "slider.h"
#include "volumecontrol.h"
#include "utils.h"

///////////////////////////////////////////////////////////////////////////////
//
// Bangs...
// 

#define MY_MAX_BANG_NAME 16
typedef struct BangItem
{
	char szName[MY_MAX_BANG_NAME];
	BANGCOMMANDPROC pCommand;
} BangItem;

void bangVolumeUp		(HWND hwndCaller, LPCSTR szArgs);
void bangVolumeDown		(HWND hwndCaller, LPCSTR szArgs);
void bangMute			(HWND hwndCaller, LPCSTR szArgs);
void bangBalanceLeft	(HWND hwndCaller, LPCSTR szArgs);
void bangBalanceRight	(HWND hwndCaller, LPCSTR szArgs);
void bangSetVolume		(HWND hwndCaller, LPCSTR szArgs);
void bangSetBalance		(HWND hwndCaller, LPCSTR szArgs);

void bangHide			(HWND hwndCaller, LPCSTR szArgs);
void bangShow			(HWND hwndCaller, LPCSTR szArgs);
void bangToggle			(HWND hwndCaller, LPCSTR szArgs);
void bangHook			(HWND hwndCaller, LPCSTR szArgs);
void bangAlwaysOnTop	(HWND hwndCaller, LPCSTR pszArgs);
void bangMove			(HWND hwndCaller, LPCSTR pszArgs);
void bangMoveBy			(HWND hwndCaller, LPCSTR pszArgs);
void bangResize			(HWND hwndCaller, LPCSTR pszArgs);
void bangResizeBy		(HWND hwndCaller, LPCSTR pszArgs);
void bangReposition		(HWND hwndCaller, LPCSTR pszArgs);
void bangRepositionBy	(HWND hwndCaller, LPCSTR pszArgs);

// it is possible to end the list with something like
// {NULL,NULL}, but for what?
#define BANGS_NUM		18

BangItem g_Bangs[BANGS_NUM] =
{
	{"VolumeUp",	bangVolumeUp},
	{"VolumeDown",	bangVolumeDown},
	{"Mute",		bangMute},
	{"BalanceLeft",	bangBalanceLeft},
	{"BalanceRight",bangBalanceRight},
	{"SetVolume",	bangSetVolume},
	{"SetBalance",	bangSetBalance},

	{"Hide",		bangHide},
	{"Show",		bangShow},
	{"Toggle",		bangToggle},
	{"Hook",		bangHook},
	{"AlwaysOnTop",	bangAlwaysOnTop},
	{"Move",		bangMove},
	{"MoveBy",		bangMoveBy},
	{"Resize",		bangResize},
	{"ResizeBy",	bangResizeBy},
	{"Reposition",	bangReposition},
	{"RepositionBy",bangRepositionBy}
};

void RegisterBangs();
void UnregisterBangs();


///////////////////////////////////////////////////////////////////////////////
//
// Register !bang commands
//

void RegisterBangs()
{
	for (int i = 0; i < BANGS_NUM; i++)
	{
		char szBangName[MAX_BANGCOMMAND];;
		StringCchPrintf(szBangName, MAX_BANGCOMMAND, "!%s%s", g_szAppName, g_Bangs[i].szName);
		AddBangCommand(szBangName, g_Bangs[i].pCommand);
	}
}


///////////////////////////////////////////////////////////////////////////////
//
// Unregister them
//
void UnregisterBangs()
{
	for (int i = 0; i < BANGS_NUM; i++)
	{
		char szBangName[MAX_BANGCOMMAND];;
		StringCchPrintf(szBangName, MAX_BANGCOMMAND, "!%s%s", g_szAppName, g_Bangs[i].szName);
		RemoveBangCommand(szBangName);
	}
}


////////////////////////////////////////////////////////////////////////////
//
// Diagnostic message for !bangs
//
void BangFailed(const char *szBangName, const char *szName)
{
	utils::ErrorBoxPrint("Slider with name \"%s\" not found\n!%s%s bang failed", szName, g_szAppName, szBangName);
}


///////////////////////////////////////////////////////////////////////////////
//
// Volume control bangs
//

void bangVolumeUp(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szChannel[MAX_OPTION_LENGTH],
		szStep[MAX_OPTION_LENGTH],
		szExtra[MAX_LINE_LENGTH],
		*vTokens[] = {szChannel, szStep};

	if (g_pMixer)
	{
		if (LCTokenize(szArgs, vTokens, 2, szExtra) == 2)
			g_pMixer->VolumeUp(atoi(szChannel), atoi(szStep));
		else
			g_pMixer->VolumeUp(atoi(szChannel));
	}
}


void bangVolumeDown(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szChannel[MAX_OPTION_LENGTH],
		szStep[MAX_OPTION_LENGTH],
		szExtra[MAX_LINE_LENGTH],
		*vTokens[] = {szChannel, szStep};

	if (g_pMixer)
	{
		if (LCTokenize(szArgs, vTokens, 2, szExtra) == 2)
			g_pMixer->VolumeDown(atoi(szChannel), atoi(szStep));
		else
			g_pMixer->VolumeDown(atoi(szChannel));
	}
}


void bangMute(HWND hwndCaller, LPCSTR szArgs)
{
	int nChannel = atoi(szArgs);
	if (g_pMixer)
	{
		g_pMixer->SetMute(nChannel, !g_pMixer->GetMute(nChannel));
	}
}


void bangBalanceLeft(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szChannel[MAX_OPTION_LENGTH],
		szStep[MAX_OPTION_LENGTH],
		szExtra[MAX_LINE_LENGTH],
		*vTokens[] = {szChannel, szStep};

	if (g_pMixer)
	{
		if (LCTokenize(szArgs, vTokens, 2, szExtra) == 2)
			g_pMixer->BalanceLeft(atoi(szChannel), atoi(szStep));
		else
			g_pMixer->BalanceLeft(atoi(szChannel));
	}
}


void bangBalanceRight(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szChannel[MAX_OPTION_LENGTH],
		szStep[MAX_OPTION_LENGTH],
		szExtra[MAX_LINE_LENGTH],
		*vTokens[] = {szChannel, szStep};

	if (g_pMixer)
	{
		if (LCTokenize(szArgs, vTokens, 2, szExtra) == 2)
			g_pMixer->BalanceRight(atoi(szChannel), atoi(szStep));
		else
			g_pMixer->BalanceRight(atoi(szChannel));
	}
}


void bangSetBalance(HWND hwndCaller, LPCSTR szArgs)
{
	char
		token1[MAX_LINE_LENGTH], token2[MAX_LINE_LENGTH],
		szExtra[MAX_LINE_LENGTH], *tokens[] = {token1, token2};
	token1[0] = token2[0] = 0;
	LCTokenize(szArgs, tokens, 2, szExtra);
	if (g_pMixer) g_pMixer->ChangeBalance(atoi(token1), atoi(token2));
}


void bangSetVolume(HWND hwndCaller, LPCSTR szArgs)
{
	char
		token1[MAX_LINE_LENGTH], token2[MAX_LINE_LENGTH],
		szExtra[MAX_LINE_LENGTH], *tokens[] = {token1, token2};
	token1[0] = token2[0] = 0;
	LCTokenize(szArgs, tokens, 2, szExtra);
	if (g_pMixer) g_pMixer->ChangeVolume(atoi(token1), atoi(token2));
}


///////////////////////////////////////////////////////////////////////////////
//
// Slider bangs
//

void bangHide(HWND hwndCaller, LPCSTR szArgs)
{
	CSlider *pSlider = GetSliderByName(szArgs);
	if (pSlider)
		pSlider->Hide();
	else
		BangFailed("Hide", szArgs);
}

void bangShow(HWND hwndCaller, LPCSTR szArgs)
{
	CSlider *pSlider = GetSliderByName(szArgs);
	if (pSlider)
		pSlider->Show();
	else
		BangFailed("Show", szArgs);
}


void bangToggle(HWND hwndCaller, LPCSTR szArgs)
{
	CSlider *pSlider = GetSliderByName(szArgs);
	if (pSlider)
		pSlider->ToggleVisibility();
	else
		BangFailed("Toggle", szArgs);
}


///////////////////////////////////////////////////////////////////////////////
//
// Hook to LSBox or similar module
//

void bangHook(HWND hwndCaller, LPCSTR szArgs)
{
	char szName[MAX_SLIDER_NAME], szExtra[MAX_LINE_LENGTH], *tokens[1] = {szName};

	LCTokenize(szArgs, tokens, 1, szExtra);
	CSlider *pSlider = GetSliderByName(szName);
	if (!pSlider)
	{
		BangFailed("Hook", szName);
	}
	else
	{
		char *handle = (char*)strrchr(szArgs, ' ');
		if (handle) 
		{
			pSlider->Hook((HWND)atoi(handle+1));
		} 
	}
}

//
// !umSliderAlwaysOnTop <slider> <on|true, off|false, toggle>
//
void bangAlwaysOnTop(HWND hwndCaller, LPCSTR szArgs)
{
	char szName[MAX_SLIDER_NAME], szOption[MAX_OPTION_LENGTH], *vBuffers[] = {szName, szOption};

	LCTokenize(szArgs, vBuffers, 2, NULL);
	CSlider *pSlider = GetSliderByName(szName);
	if (!pSlider)
	{
		BangFailed("AlwaysOnTop", szName);
		return;
	}
	else
	{
		bool bValue;
		if (_stricmp(szOption, "false") == NULL || _stricmp(szOption, "off") == NULL)
			bValue = false;
		else if (_stricmp(szOption, "toggle") == NULL || _stricmp(szOption, "switch") == NULL)
			bValue = !pSlider->m_bAlwaysOnTop;
		else
			bValue = true;
		pSlider->SetAlwaysOnTopStatus(bValue);
	}
}


//
// !umSliderMove <slider> <x> <y>
//
void bangMove(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szName[MAX_SLIDER_NAME],
		szX   [MAX_OPTION_LENGTH],
		szY   [MAX_OPTION_LENGTH],
		*vBuffers[] = {szName, szX, szY};

	if (LCTokenize(szArgs, vBuffers, 3, NULL) >= 3)
	{
		CSlider *pSlider = GetSliderByName(szName);

		if (!pSlider)
		{
			BangFailed("Move", szName);
		}
		else
		{
			int x = xParseCoord(szX, 0, SCREEN_WIDTH, false);
			int y = xParseCoord(szY, 0, SCREEN_HEIGHT, true);			
			
			pSlider->Reposition(BANGMODE_MOVE, x, y, 0, 0);
		}
	}
}

//
// !umSliderMoveBy <slider> <x> <y>
//
void bangMoveBy(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szName[MAX_SLIDER_NAME],
		szDX[MAX_OPTION_LENGTH],
		szDY[MAX_OPTION_LENGTH],
		*vBuffers[] = {szName, szDX, szDY};

	if (LCTokenize(szArgs, vBuffers, 3, NULL) >= 3)
	{
		CSlider *pSlider = GetSliderByName(szName);

		if (!pSlider)
		{
			BangFailed("MoveBy", szName);
		}
		else
		{
			pSlider->Reposition(BANGMODE_MOVE, atoi(szDX), atoi(szDY), 0, 0, true);
		}
	}
}


//
// !umSliderResize <slider> <width> <height>
//
void bangResize(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szName  [MAX_SLIDER_NAME],
		szW[MAX_OPTION_LENGTH],
		szH[MAX_OPTION_LENGTH],
		*vBuffers[] = {szName, szW, szH};

	if (LCTokenize(szArgs, vBuffers, 3, NULL) >= 3)
	{
		CSlider *pSlider = GetSliderByName(szName);

		if (!pSlider)
		{
			BangFailed("Resize", szName);
		}
		else
		{
			int nWidth	= xParseDimen(szW,  0, SCREEN_WIDTH, false);
			int nHeight	= xParseDimen(szH, 0, SCREEN_HEIGHT, true);
				
			pSlider->Reposition(BANGMODE_RESIZE, 0, 0, nWidth, nHeight);
		}
	}
}

// !umSliderResizeBy <slider> <cx> <cy>
void bangResizeBy(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szName[MAX_SLIDER_NAME],
		szDW[MAX_OPTION_LENGTH],
		szDH[MAX_OPTION_LENGTH],
		*vBuffers[] = {szName, szDW, szDH};

	if (LCTokenize(szArgs, vBuffers, 3, NULL) >= 3)
	{
		CSlider *pSlider = GetSliderByName(szName);

		if (!pSlider)
		{
			BangFailed("ResizeBy", szName);
		}
		else
		{
			int cx = atoi(szDW);
			int cy = atoi(szDH);

			pSlider->Reposition(BANGMODE_RESIZE, 0, 0, cx, cy, true);
		}
	}
}

//
// !umSliderReposition <slider> <x> <y> <width> <height>
//
void bangReposition(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szName[MAX_SLIDER_NAME],
		szX[MAX_OPTION_LENGTH],
		szY[MAX_OPTION_LENGTH],
		szW[MAX_OPTION_LENGTH],
		szH[MAX_OPTION_LENGTH],
		*vBuffers[] = {szName, szX, szY, szW, szH};

	if(LCTokenize(szArgs, vBuffers, 5, NULL) >= 5)
	{
		CSlider *pSlider = GetSliderByName(szName);

		if (!pSlider)
		{
			BangFailed("Reposition", szName);
		}
		else
		{
			int x = xParseCoord(szX, 0, SCREEN_WIDTH, false);
			int y = xParseCoord(szY, 0, SCREEN_HEIGHT, true);
			int w = xParseDimen(szW, 0, SCREEN_WIDTH, false);
			int h = xParseDimen(szH, 0, SCREEN_HEIGHT, true);
				
			pSlider->Reposition(BANGMODE_REPOSITION, x, y, w, h);
		}
	}
}

//
// !umSliderRepositionBy <slider> <cx> <cy> <cwidth> <cheight>
//
void bangRepositionBy(HWND hwndCaller, LPCSTR szArgs)
{
	char
		szName[MAX_SLIDER_NAME],
		szDX[MAX_OPTION_LENGTH],
		szDY[MAX_OPTION_LENGTH],
		szDW[MAX_OPTION_LENGTH],
		szDH[MAX_OPTION_LENGTH],
		*vBuffers[] = {szName, szDX, szDY, szDW, szDH};

	if (LCTokenize(szArgs, vBuffers, 5, NULL) >= 5)
	{
		CSlider *pSlider = GetSliderByName(szName);

		if (!pSlider)
		{
			BangFailed("RepositionBy", szName);
		}
		else
		{
			int x = atoi(szDX);
			int y = atoi(szDY);
			int w = atoi(szDW);
			int h = atoi(szDH);

			pSlider->Reposition(BANGMODE_REPOSITION, x, y, w, h, true);
		}
	}
}

