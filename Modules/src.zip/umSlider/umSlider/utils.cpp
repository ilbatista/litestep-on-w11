#include "stdafx.h"
#include "utils.h"
#include "main.h"

///////////////////////////////////////////////////////////////////
//
// Message box + logging
//
void utils::ErrorBox(const char *szMessage)
{
	MessageBox(NULL, szMessage, "UniMedia Slider :: Error", MB_OK);
	//LSLog(LOG_ERROR, g_szAppName, szMessage);
}


void utils::ErrorBoxPrint(const char *szFormat, ...)
{
	// Format the message
	char szMessage[MAX_LINE_LENGTH];
	va_list argList;

	va_start(argList, szFormat);
	StringCchVPrintf(szMessage, MAX_LINE_LENGTH, szFormat, argList);
	va_end(argList);

	ErrorBox(szMessage);
}



int utils::ErrorBoxE( HWND hWnd, LPCSTR pszText, DWORD dwErrorCode, LPCSTR pszTitle, UINT nFlags )
{
	char szMessage[MAX_PATH];
	int nLen;

	StringCchCopy(szMessage, MAX_PATH, pszText);
	StringCchCat(szMessage, MAX_PATH, " ");
	nLen = lstrlen(szMessage);

	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, dwErrorCode,
	              MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), szMessage + nLen,
	              MAX_PATH - nLen, NULL);

	return MessageBox( hWnd, szMessage, pszTitle, nFlags | MB_TOPMOST);
}


void utils::xUpdateRegion(HWND hWnd, HDC hdcMemory, HBITMAP hMemoryBitmap, int nWidth, int nHeight)
{
	if (hMemoryBitmap != 0 && hdcMemory != 0 )
	{
		RECT rectPosition;
		GetClientRect(hWnd, &rectPosition);

		HDC hdcTemp = CreateCompatibleDC(NULL);
		HBITMAP hbmTemp = CreateBitmap(rectPosition.right, rectPosition.bottom, 1, QueryPixelDepth()*8, NULL);
		HBITMAP hbmOld = (HBITMAP) SelectObject(hdcTemp, hbmTemp);

		StretchBlt(hdcTemp, 0, 0, rectPosition.right, rectPosition.bottom, hdcMemory, 0, 0, nWidth, nHeight, SRCCOPY);

		hbmTemp = (HBITMAP) SelectObject(hdcTemp, hbmOld);

		HRGN hRgn = BitmapToRegion(hbmTemp, RGB(255, 0, 255), 0, 0, 0);
		HRGN hWndRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(hWndRgn, hRgn, NULL, RGN_COPY);

		SetWindowRgn(hWnd, hWndRgn, true);	

		DeleteObject(hWndRgn);
		DeleteObject(hRgn);
		DeleteObject(hbmTemp);
		DeleteDC(hdcTemp);
	}
}


