// TooltipService.cpp: implementation of the CTooltipService class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TooltipService.h"
#include "utils.h"

HINSTANCE CTooltipService::m_hInstance = NULL;
const char szTooltipService[] = "LSWharfHints";

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTooltipService::CTooltipService() : m_hWnd(NULL)
{
}


CTooltipService::~CTooltipService()
{
	if (m_hWnd) DestroyWindow(m_hWnd);
}


void CTooltipService::Init(HINSTANCE hInstance)
{
	m_hInstance = hInstance;
}


bool CTooltipService::InitWindow()
{
	m_hWnd = CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
		TOOLTIPS_CLASS,
		szTooltipService,
		TTS_ALWAYSTIP,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		NULL,
		(HMENU) NULL,
		m_hInstance,
		NULL
		);
	return (m_hWnd != NULL);
}


void CTooltipService::Add(HWND hWnd, const char *szText)
{
	static bool bFirstFailure = true;
	if (!m_hWnd)
	{
		if (!InitWindow())
		{
			if (bFirstFailure)
			{
				utils::ErrorBox("Cannot create hints handler. The feature disabled.");
				bFirstFailure = false;
			}
			return;
		}
	}

	TOOLINFO ti;
	RECT r;

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.hinst = m_hInstance;
	ti.uId = 0;
	ti.lpszText = const_cast<char*>(szText);
	GetClientRect(hWnd, &r);
	ti.rect = r;

	SendMessage(m_hWnd, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);	
}


void CTooltipService::Remove(HWND hWnd)
{
	TOOLINFO ti;
	RECT r = {0, 0, 0, 0};

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.hinst = m_hInstance;
	ti.uId = 0;
	ti.lpszText = NULL;
	ti.rect = r;

	SendMessage(m_hWnd, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}


void CTooltipService::RelayEvent(HWND hWnd, Message &message)
{
	MSG TooltipMessage;
	TooltipMessage.hwnd = hWnd;
	TooltipMessage.message = message.uMsg;
	TooltipMessage.wParam = message.wParam;
	TooltipMessage.lParam = message.lParam;
	SendMessage(m_hWnd, TTM_RELAYEVENT, 0, (LPARAM)&TooltipMessage);
}

