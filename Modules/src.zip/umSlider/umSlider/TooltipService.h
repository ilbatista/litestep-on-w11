// TooltipService.h: interface for the CTooltipService class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __TOOLTIP_SERVICE__
#define __TOOLTIP_SERVICE__

#pragma once

class CTooltipService  
{
	HWND m_hWnd;
public:
	void Add(HWND hWnd, const char *szText);
	void Remove(HWND hWnd);
	void RelayEvent(HWND hWnd, Message &message);
	static HINSTANCE m_hInstance;
	static void Init(HINSTANCE hInstance);
	bool InitWindow();
	CTooltipService();
	virtual ~CTooltipService();

};

#endif
