#ifndef __UTILS_HEADER__
#define __UTILS_HEADER__

namespace utils
{
	void ErrorBox(const char *szMessage);
	void ErrorBoxPrint(const char *szFormat, ...);
	int ErrorBoxE( HWND hWnd, LPCSTR pszText, DWORD dwErrorCode, LPCSTR pszTitle, UINT nFlags );
	void xUpdateRegion(HWND hWnd, HDC hdcMemory, HBITMAP hMemoryBitmap, int nWidth, int nHeight);
}

#endif