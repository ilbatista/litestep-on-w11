// Slider.h: interface for the CSlider class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __SLIDER_HEADER__
#define __SLIDER_HEADER__

#pragma once

#define WM_UPDATE		WM_USER+98
#define WM_CHANGE		WM_USER+99

#define TYPE_NONE		0
#define TYPE_HORIZONTAL	1
#define TYPE_VERTICAL	2

#define MODE_NONE		0
#define MODE_VOLUME		1
#define MODE_BALANCE	2
#define MODE_AMP		3
#define MODE_AMPVOLUME	4

#define TIMER_UPDATE	1

#define TIMER_INTERVAL	250

class CSlider
{
public:

	char *m_szName; // a slider name
	char m_szTip[MAX_LINE_LENGTH]; // slider tooltip

	// -= flags =-

	bool m_bInitialized;	// properly initialized
	bool m_bLoaded;			// slider window loaded

	bool m_bInverted;
	bool m_bVisible;
	bool m_bAlwaysOnTop;

	// type and mode constants are listed above
	int m_nType, m_nMode;

	// hSlider is a slider window, hHandle - handle :)
	HWND m_hSlider, m_hHandle;
	// dcmain for hSlider, dchand for handle
	HDC m_dcMain, m_dcHand;
	// the same for images
	HBITMAP m_hbmBackground, m_hbmHandle;
	// handle offset in according to the settings
	int m_nHandleOffset;
	int m_nX, m_nY;
	int m_nWidth, m_nHeight;
	int m_nHX, m_nHY;
	int m_nHWidth, m_nHHeight;
	int m_nChannel;
	int m_nGroup;

	PaintTexture *m_pTexture, *m_pHandleTexture;

	CSlider(const char *szName);
	virtual ~CSlider();

	bool LoadParameters();
	bool LoadHandlePosition(bool bExist);
	bool CreateUI();
	void SetAlwaysOnTopStatus(bool bNewStatus);

	// message handlers
	void onUpdate();
	void onLButtonDown(int x, int y);
	void onPosChanging(WINDOWPOS *pPos);
	void onPaint(HDC hdc);
	void onPaintHandle(HDC hdc);
	void onSize();

	// bang handlers
	void Show();
	void Hide();
	void ToggleVisibility();
	void Hook(HWND hwndParent);
	void Reposition(int nBangMode, int nX, int nY, int nWidth, int nHeight, bool bRelated = false); 
};

#endif
