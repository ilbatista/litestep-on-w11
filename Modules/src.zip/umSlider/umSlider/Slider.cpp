// Slider.cpp: implementation of the CSlider class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Slider.h"
#include "TooltipService.h"
#include "main.h"
#include "utils.h"
#include "main.h"
#include "VolumeControl.h"
#include "bangs.h"

HWND g_hwndWinamp = NULL;

CSlider* GetSliderByWnd(HWND hWnd);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSlider::CSlider(const char *szName):
					m_bLoaded (false),
					m_bInitialized (false),
					m_bInverted(false),
					m_bAlwaysOnTop(false),
					m_hSlider(NULL),
					m_hHandle(NULL),
					m_nMode(MODE_NONE),
					m_nType(TYPE_NONE),
					m_pTexture(NULL),
					m_pHandleTexture(NULL),
					m_szName(NULL)
{
	size_t nLen = strlen(szName) + 1;
	m_szName = new char[nLen];
	StringCchCopy(m_szName, nLen, szName);
	if (!LoadParameters()) return;
	if (!CreateUI()) return;
	m_bInitialized = true;
}

CSlider::~CSlider()
{
	if (m_nMode == MODE_AMP || m_nMode == MODE_AMPVOLUME)
	{
		KillTimer(m_hSlider, TIMER_UPDATE);
	}
	if (IsWindow(m_hHandle)) DestroyWindow(m_hHandle);
	if (IsWindow(m_hSlider)) DestroyWindow(m_hSlider);
	delete m_szName;
}


bool CSlider::LoadParameters()
{
	NameValuePair vModes[] =
	{
		{"volume",		MODE_VOLUME},
		{"balance",		MODE_BALANCE},
		{"track",		MODE_AMP},
		{"ampvolume",	MODE_AMPVOLUME},
		{NULL,			0}
	};

	NameValuePair vDirections[] = 
	{
		{"horizontal",	TYPE_HORIZONTAL},
		{"vertical",	TYPE_VERTICAL},
		{NULL,			0}
	};

	// slider position
	m_nX = Getx2RCCoord(m_szName, "X", 0, SCREEN_WIDTH,  false);
	m_nY = Getx2RCCoord(m_szName, "Y", 0, SCREEN_HEIGHT, true);

	// slider sizes
	m_nWidth	= Getx2RCCoord(m_szName, "Width", 0, SCREEN_WIDTH,  false);
	m_nHeight	= Getx2RCCoord(m_szName, "Height",0, SCREEN_HEIGHT, true);

	// handle sizes
	m_nHWidth	= Getx2RCCoord(m_szName, "HandleWidth",	0, SCREEN_WIDTH,  false);
	m_nHHeight	= Getx2RCCoord(m_szName, "HandleHeight",0, SCREEN_HEIGHT, true);

	// handle offset
	m_nHandleOffset = Getx2RCInt(m_szName, "HandleOffset", 0/*, 0, m_nWidth*/);

	// slider mode
	m_nMode = Getx2RCNamedValue(m_szName, "Mode", vModes, MODE_NONE);
	switch (m_nMode)
	{
	case MODE_NONE:
		utils::ErrorBoxPrint("Invalid '%s' slider mode\nProper values are 'volume', 'balance', 'track' and 'ampvolume'", m_szName);
		return false;
	case MODE_VOLUME:
	case MODE_BALANCE:
		m_nChannel = Getx2RCInt(m_szName, "Channel", 0);
		break;
	}

	// flags
	m_bInverted		= (Getx2RCBool(m_szName, "Inverted",	FALSE) == TRUE);
	m_bVisible		= (Getx2RCBool(m_szName, "Visible",	TRUE) == TRUE);
	m_bAlwaysOnTop	= (Getx2RCBool(m_szName, "AlwaysOnTop", FALSE) == TRUE);
	m_nType = Getx2RCNamedValue(m_szName, "Direction", vDirections, TYPE_NONE);
	if (m_nType == TYPE_NONE)
	{
		utils::ErrorBoxPrint("Slider '%s' cannot be initialized due to invalid direction value. Only 'horizontal' and 'vertical' values available", m_szName);
		return false;
	}

	// background and handle textures
	m_pTexture = Create_xTextureClass();
	m_pTexture->configure(m_szName, "");
	m_pHandleTexture = Create_xTextureClass();
	m_pHandleTexture->configure(m_szName, "Handle");

	// calculate position
	m_nHX	= (m_nWidth - m_nHWidth)/2;
	m_nHY	= (m_nHeight - m_nHHeight)/2;

	// tooltip
	Getx2RCString(m_szTip, m_szName, "Tip", "");

	return true;
}


//////////////////////////////////////////////////////////////////////////
//
// Create a slider window by filled
// slider structure and some other info
//
bool CSlider::CreateUI()
{
	m_hSlider = CreateWindowEx(
		0,
		g_szSliderClass,
		"",
		WS_POPUP,
		m_nX,
		m_nY,
		m_nWidth,
		m_nHeight,
		GetLitestepDesktop(),
		NULL,
		g_hInstance,
		this);

	if (m_hSlider == NULL)
	{
		utils::ErrorBoxPrint("Cannot create '%s' slider window!", m_szName);
		return false;
	}

	SetWindowLong(m_hSlider, GWL_USERDATA, MAGIC_DWORD);
	if (m_szTip[0]) g_pTooltips->Add(m_hSlider, m_szTip);
	if (m_nMode == MODE_AMP || m_nMode == MODE_AMPVOLUME)
	{
		SetTimer(m_hSlider, TIMER_UPDATE, TIMER_INTERVAL, NULL);
	}

	bool bVisible = LoadHandlePosition(false);
	if (!bVisible)
	{
		m_nHX = 0;
		m_nHY = 0;
	}

	m_hHandle = CreateWindowEx(
		0,
		g_szHandleClass, NULL, WS_CHILD,
		m_nHX, m_nHY, m_nHWidth, m_nHHeight,
		m_hSlider, NULL,
		g_hInstance, this);

	if (m_hHandle == NULL)
	{
		utils::ErrorBoxPrint("Cannot create handle window for the '%s' slider", m_szName);
		return false;
	}

	SetAlwaysOnTopStatus(m_bAlwaysOnTop);

	utils::xUpdateRegion(m_hSlider, m_dcMain, m_hbmBackground, m_nWidth, m_nHeight);
	utils::xUpdateRegion(m_hHandle, m_dcHand, m_hbmHandle, m_nHWidth, m_nHHeight);

	ShowWindow(m_hSlider, m_bVisible ? SW_SHOW : SW_HIDE);
	ShowWindow(m_hHandle, bVisible ? SW_SHOW : SW_HIDE);
	UpdateWindow(m_hSlider);
	UpdateWindow(m_hHandle);

	InvalidateRgn(m_hSlider, NULL, TRUE);
	PostMessage(m_hSlider, WM_UPDATE, 0, 0);

	return true;
}

void CSlider::SetAlwaysOnTopStatus(bool bNewStatus)
{
	static bool bIsFirstSetup = true;
	if (bIsFirstSetup || (bNewStatus != m_bAlwaysOnTop))
	{
		ModifyStyle(m_hSlider, WS_POPUP, WS_CHILD);
		SetParent(m_hSlider, m_bAlwaysOnTop ? NULL : GetLitestepDesktop());
		ModifyStyle(m_hSlider, WS_CHILD, WS_POPUP);
	}
	SetWindowPos(m_hSlider, m_bAlwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
						0, 0, 0, 0,
						SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE );

}


///////////////////////////////////////////////////////////////////////////////////////
//
// This procedure processes all slider messages
//
LRESULT WINAPI SliderWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CSlider *pSlider = NULL;

	if (uMsg == WM_NCCREATE)
	{
		pSlider = reinterpret_cast<CSlider*>((reinterpret_cast<LPCREATESTRUCT>(lParam))->lpCreateParams);
		pSlider->m_hSlider = hWnd;
	}
	else
	{
		pSlider = GetSliderByWnd(hWnd);
	}

	if (pSlider == NULL)
	{
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}

	switch(uMsg)
	{
	case WM_ERASEBKGND:
		pSlider->onPaint((HDC)wParam);
		break;
	case WM_PAINT:
		PAINTSTRUCT ps;
		HDC hdc;
		hdc = BeginPaint(hWnd, &ps);
		pSlider->onPaint(hdc);
		EndPaint(hWnd, &ps);
		break;
	case WM_CHANGE:
		switch(pSlider->m_nMode)
		{
		case MODE_VOLUME:
			g_pMixer->ChangeVolume(pSlider->m_nChannel, (int)wParam);
			break;
		case MODE_BALANCE:
			g_pMixer->ChangeBalance(pSlider->m_nChannel, ((100-(int)wParam)*2)-100);
			break;
		case MODE_AMP:
			PostMessage(g_hwndWinamp, WM_USER, ((SendMessage(g_hwndWinamp,WM_USER, 1, 105)*1000)/100)*wParam, 106);
			break;
		case MODE_AMPVOLUME:
			PostMessage(g_hwndWinamp, WM_USER, wParam * 255 / 100, 122);
			break;
		}
		break;
	case WM_TIMER:
	case WM_UPDATE:
		pSlider->onUpdate();
		break;
	case WM_LBUTTONDOWN:
		pSlider->onLButtonDown(LOWORD(lParam), HIWORD(lParam));
		break;
	case WM_SIZE:
		pSlider->onSize();
		break;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}




///////////////////////////////////////////////////////////////////////////////////////
//
// This procedure processes all slider's handle messages
//
LRESULT WINAPI HandleWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CSlider *pSlider = NULL;

	if (uMsg == WM_NCCREATE)
	{
		pSlider = (CSlider*) (( (LPCREATESTRUCT) (lParam) )->lpCreateParams);
		pSlider->m_hHandle = hWnd;
	}
	else
	{
		pSlider = GetSliderByWnd(hWnd);
	}

	if (pSlider != NULL)
	switch(uMsg)
	{
	case WM_PAINT:
		PAINTSTRUCT ps;
		HDC hdc;
		hdc = BeginPaint(hWnd, &ps);
		pSlider->onPaintHandle(hdc);
		EndPaint(hWnd, &ps);
		break;
	case WM_NCHITTEST:
		return HTCAPTION;
	case WM_WINDOWPOSCHANGING:
		pSlider->onPosChanging((WINDOWPOS*)lParam);
		return 0;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


void CSlider::onUpdate()
{
	m_bLoaded = true;
	if (LoadHandlePosition(true))
	{
		SetWindowPos(m_hHandle,0, m_nHX, m_nHY,0,0,SWP_NOSIZE | SWP_NOZORDER);
	}
}


void CSlider::onLButtonDown(int x, int y)
{
	if (m_nType == TYPE_HORIZONTAL)
	{
		if (m_nHandleOffset <= x && x <= m_nWidth - m_nHandleOffset)
		{
			SetWindowPos(m_hHandle, NULL, x, 0, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
		}
	}
	else // if (m_nType == TYPE_VERTICAL)
	{
		if (m_nHandleOffset <= y && y <= m_nHeight - m_nHandleOffset)
		{
			SetWindowPos(m_hHandle, NULL, 0, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
		}
	}
}


void CSlider::onPosChanging(WINDOWPOS *pPos)
{
	if (!m_bLoaded)
	{
		return;
	}
	if (m_nType == TYPE_HORIZONTAL)
	{
		pPos->x = max(pPos->x, m_nHandleOffset);
		pPos->x = min(pPos->x, m_nWidth - m_nHandleOffset*2 - m_nHWidth);
		pPos->y = (m_nHeight - m_nHHeight)/2;
		if (pPos->x != m_nHX)
		{
			m_nHX = pPos->x;
			int n = (m_nHX - m_nHandleOffset) * 100 / (m_nWidth - 2*m_nHandleOffset - m_nHWidth);
			if (!m_bInverted) n = 100 - n;
			PostMessage(m_hSlider, WM_CHANGE, n, 0);
		}
	}
	else	// if (m_nType == TYPE_VERTICAL)
	{
		pPos->y = max(pPos->y, m_nHandleOffset);
		pPos->y = min(pPos->y, m_nHeight - m_nHandleOffset*2 - m_nHHeight);
		pPos->x = (m_nWidth - m_nHWidth)/2;
		if (pPos->y != m_nHY)
		{
			m_nHY = pPos->y;
			int n = (m_nHY - m_nHandleOffset) * 100 / (m_nHeight - 2*m_nHandleOffset - m_nHHeight);
			if (!m_bInverted) n = 100 - n;
			PostMessage(m_hSlider, WM_CHANGE, n, 0);
		}
	}
}


void CSlider::onPaint(HDC hdc)
{	
	if ( m_hbmBackground != 0 && m_dcMain != 0 )
	{
		BitBlt(hdc, 0, 0, m_nWidth, m_nHeight, m_dcMain, 0, 0, SRCCOPY);
	}
	else
	{
		m_dcMain = CreateCompatibleDC(NULL);

		BITMAPINFO alpha;
		ZeroMemory( &alpha.bmiHeader, sizeof(BITMAPINFOHEADER) );
		alpha.bmiHeader.biWidth=m_nWidth;
		alpha.bmiHeader.biHeight=m_nHeight;    // Set size you need
		alpha.bmiHeader.biPlanes=1;
		alpha.bmiHeader.biBitCount=32;      // Can be 8, 16, 32 bpp or other number
		alpha.bmiHeader.biSizeImage=0;
		alpha.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
		alpha.bmiHeader.biClrUsed= 0;
		alpha.bmiHeader.biClrImportant= 0;
		VOID *pvBits;

		m_hbmBackground = CreateDIBSection( m_dcMain,
											&alpha,
											DIB_RGB_COLORS,
											&pvBits,
											NULL,
											0 );

		SelectObject(m_dcMain, m_hbmBackground);

		//Magic Pink True Transparency
		::SetBkColor(m_dcMain, RGB(255, 0, 255));
				
		//Background Painting
		m_pTexture->apply(m_dcMain, 0, 0, m_nWidth, m_nHeight);

		BitBlt(hdc, 0, 0, m_nWidth, m_nHeight, m_dcMain, 0, 0, SRCCOPY);
	}
}


void CSlider::onPaintHandle(HDC hdc)
{	
	if ( m_hbmHandle != 0 && m_dcHand != 0 )
	{
		BitBlt(hdc, 0, 0, m_nHWidth, m_nHHeight, m_dcHand, 0, 0, SRCCOPY);
	}
	else
	{
		m_dcHand = CreateCompatibleDC(NULL);

		BITMAPINFO alpha;
		ZeroMemory( &alpha.bmiHeader, sizeof(BITMAPINFOHEADER) );
		alpha.bmiHeader.biWidth=m_nHWidth;
		alpha.bmiHeader.biHeight=m_nHHeight;    // Set size you need
		alpha.bmiHeader.biPlanes=1;
		alpha.bmiHeader.biBitCount=32;      // Can be 8, 16, 32 bpp or other number
		alpha.bmiHeader.biSizeImage=0;
		alpha.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
		alpha.bmiHeader.biClrUsed= 0;
		alpha.bmiHeader.biClrImportant= 0;
		VOID *pvBits;

		m_hbmHandle = CreateDIBSection(		m_dcMain,
											&alpha,
											DIB_RGB_COLORS,
											&pvBits,
											NULL,
											0 );

		SelectObject(m_dcHand, m_hbmHandle);

		//Magic Pink True Transparency
		::SetBkColor(m_dcHand, RGB(255, 0, 255));
				
		//Background Painting
		m_pHandleTexture->apply(m_dcHand, 0, 0, m_nHWidth, m_nHHeight);

		BitBlt(hdc, 0, 0, m_nHWidth, m_nHHeight, m_dcHand, 0, 0, SRCCOPY);
	}
}

void CSlider::onSize()
{
	if (m_hbmBackground)
	{
		m_hbmBackground = (HBITMAP) SelectObject(m_dcMain, m_hbmBackground);
		DeleteObject(m_hbmBackground);
	}
	if (m_dcMain) DeleteDC(m_dcMain);

	m_hbmBackground = NULL;
	m_dcMain = NULL;

	utils::xUpdateRegion(m_hSlider, m_dcMain, m_hbmBackground, m_nWidth, m_nHeight);
	InvalidateRgn(m_hSlider, NULL, TRUE);
	PostMessage(m_hSlider, WM_UPDATE, 0, 0);
}


bool CSlider::LoadHandlePosition(bool bExist)
{
	int left = 0, right = 0, tmp;
	switch (m_nMode)
	{
	case MODE_VOLUME:
		g_pMixer->GetVolume(m_nChannel, left, right);
		if (right>left)
			tmp = 100-(right/655);
		else
			tmp = 100-(left/655);
		break;
	case MODE_BALANCE:
		g_pMixer->GetVolume(m_nChannel,left,right);
		if (right > left)
			tmp = 100 - left/(right/100);
		else
			tmp = (right/(left/100)) - 100;
		tmp = (tmp+100)/2;
		break;
	case MODE_AMP:
	case MODE_AMPVOLUME:
		g_hwndWinamp = FindWindow("Winamp v1.x",NULL);
		if (g_hwndWinamp == NULL)
		{
			g_hwndWinamp = FindWindow("grdampclass",NULL);
			if (g_hwndWinamp == NULL)
			{
				g_hwndWinamp = FindWindow("grdamp wndcls",NULL);
				if (g_hwndWinamp == NULL)
				{
					if (bExist) ShowWindow(m_hHandle, SW_HIDE);
					return false;
				}
			}
		}
		if (bExist) ShowWindow(m_hHandle, SW_SHOW);
		int ret = (int)SendMessage(g_hwndWinamp, WM_USER, 0, 104);
		if (ret != 1 && ret!=3)
		{
			if (bExist) ShowWindow(m_hHandle, SW_HIDE);
			return false;
		}
		else
		{
			if (bExist) ShowWindow(m_hHandle, SW_SHOW);
			if (m_nMode == MODE_AMPVOLUME)
			{
				tmp = 100 - (int)SendMessage(g_hwndWinamp, WM_USER, -666, 122) * 100 / 255;
			}
			else // if (m_nMode == MODE_WINAMP)
			{
				tmp = (int)SendMessage(g_hwndWinamp, WM_USER, 1, 105);
				tmp = 100 - 100 * (int)SendMessage(g_hwndWinamp, WM_USER, 0, 105)/(tmp*1000);
			}
		}
		break;
	}

	if (m_bInverted)
	{
		tmp = 100 - tmp;
	}
	if (m_nType == TYPE_VERTICAL)
	{
		m_nHY = (m_nHeight - 2 * m_nHandleOffset - m_nHHeight) * tmp / 100 + m_nHandleOffset;
	}
	else
	{
		m_nHX = (m_nWidth  - 2 * m_nHandleOffset - m_nHWidth) * tmp / 100 + m_nHandleOffset;
	}
	return true;
}


void CSlider::Show()
{
	if (!m_bVisible)
	{
		m_bVisible = true;
		ShowWindow(m_hSlider, SW_SHOW);
	}
}


void CSlider::Hide()
{
	if (m_bVisible)
	{
		m_bVisible = false;
		ShowWindow(m_hSlider, SW_HIDE);
	}
}


void CSlider::ToggleVisibility()
{
	m_bVisible = !m_bVisible;
	ShowWindow(m_hSlider, m_bVisible ? SW_SHOW : SW_HIDE);
}


void CSlider::Hook(HWND hwndParent)
{
	SetParent(m_hSlider, hwndParent);
}


void CSlider::Reposition(int nBangMode, int nX, int nY, int nWidth, int nHeight, bool bRelated)
{
	if (bRelated)
	{
		if (nBangMode != BANGMODE_RESIZE)
		{
			m_nX += nX;
			m_nY += nY;
		}
		if (nBangMode != BANGMODE_MOVE)
		{
			m_nWidth	+= nWidth;
			m_nHeight	+= nHeight;
		}
	}
	else
	{
		if (nBangMode != BANGMODE_RESIZE)
		{
			m_nX = nX;
			m_nY = nY;
		}
		if (nBangMode != BANGMODE_MOVE)
		{
			m_nWidth	= nWidth;
			m_nHeight	= nHeight;
		}
	}

	switch (nBangMode)
	{
	case BANGMODE_MOVE:
		SetWindowPos(m_hSlider, 0, m_nX, m_nY, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOZORDER);
		break;
	case BANGMODE_RESIZE:
		SetWindowPos(m_hSlider, 0, 0, 0, m_nWidth, m_nHeight, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOZORDER);
		break;
	case BANGMODE_REPOSITION:
		SetWindowPos(m_hSlider, 0, m_nX, m_nY, m_nWidth, m_nHeight, SWP_NOACTIVATE | SWP_NOZORDER);
	}
}

