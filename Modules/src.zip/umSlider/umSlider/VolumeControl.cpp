#include "stdafx.h"
#include "VolumeControl.h"
#include "utils.h"

int CVolumeControl::g_nVolumeStep, CVolumeControl::g_nBalanceStep;


CVolumeControl::CVolumeControl(HWND hWnd)
{
	MMRESULT rc;				// Return code.
	MIXERLINE mxl;				// Holds the mixer line data.
	MIXERLINE mxl_con;

	m_nCode = 0;
	m_hMixer = NULL;

	// open mixer
	rc = mixerOpen(&m_hMixer, 0, (DWORD_PTR)hWnd, 0, CALLBACK_WINDOW | MIXER_OBJECTF_MIXER);
	if (rc != MMSYSERR_NOERROR)
	{
		utils::ErrorBox("Cannot open the mixer");
		m_nCode = 1;
		return;
	}

	// Initialize MIXERLINE structure.
	ZeroMemory(&mxl,sizeof(mxl));
	mxl.cbStruct = sizeof(MIXERLINE);
	mxl.dwDestination = 0;

	rc = mixerGetLineInfo((HMIXEROBJ)m_hMixer, &mxl, MIXER_GETLINEINFOF_DESTINATION);
	if (rc != MMSYSERR_NOERROR)
	{
		utils::ErrorBox("Cannot get the mixer line.");
		m_nCode = 2;
		return;
	}

	GetLineControls(mxl);

	for (unsigned int i = 0; i < mxl.cConnections; i++)
	{
		ZeroMemory(&mxl_con,sizeof(MIXERLINE));
		mxl_con.cbStruct		= sizeof(MIXERLINE);
		mxl_con.dwDestination	= 0;
		mxl_con.dwSource		= i;
		rc = mixerGetLineInfo((HMIXEROBJ)m_hMixer, &mxl_con, MIXER_GETLINEINFOF_SOURCE);
		if (rc != MMSYSERR_NOERROR)
			utils::ErrorBox("Cannot obtain line info");
		else
		{
			if (mxl_con.cControls > 0) GetLineControls(mxl_con);
		}
	}

	g_nVolumeStep	= GetRCInt("umSliderVolumeStep", 1);
	g_nBalanceStep	= GetRCInt("umSliderBalanceStep", 1);
}


CVolumeControl::~CVolumeControl()
{
	if (m_hMixer)
	{
		mixerClose(m_hMixer);
		m_vLines.clear();
		m_vMutes.clear();
	}
}


void CVolumeControl::GetLineControls(MIXERLINE &mxl)
{
	MMRESULT rc;
	MIXERLINECONTROLS mxlc;		// Obtains the mixer control.
	MIXERCONTROL *mxc = new MIXERCONTROL[mxl.cControls];

	ZeroMemory(&mxlc, sizeof(mxlc));
	mxlc.cbStruct	=	sizeof(mxlc);
	mxlc.dwLineID	=	mxl.dwLineID;
	mxlc.cControls	=	mxl.cControls;
	mxlc.cbmxctrl	=	sizeof(MIXERCONTROL);
	mxlc.pamxctrl	=	mxc;

	rc = mixerGetLineControls((HMIXEROBJ)m_hMixer, &mxlc, MIXER_GETLINECONTROLSF_ALL);
	if (rc != MMSYSERR_NOERROR)
	{
		utils::ErrorBox("Cannot get the control");
		return;
	}

	for (unsigned int i = 0; i < mxlc.cControls; i++)
	{
		switch (mxc[i].dwControlType)
		{
		case MIXERCONTROL_CONTROLTYPE_VOLUME:
			m_vLines.push_back(mxc[i]);
			break;
		case MIXERCONTROL_CONTROLTYPE_MUTE:
			m_vMutes.push_back(mxc[i]);
			break;
		}
	}
	delete mxc;
}



void CVolumeControl::GetVolume(int channel, int &left, int &right)
{
	MMRESULT rc;
	MIXERCONTROLDETAILS_UNSIGNED values[2];
	MIXERCONTROLDETAILS mxcd;
	ZeroMemory(&mxcd, sizeof(mxcd));
	mxcd.cbStruct		=	sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID	=	m_vLines[channel].dwControlID;
	mxcd.cChannels		=	2;
	mxcd.cMultipleItems	=	0;
	mxcd.cbDetails		=	sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mxcd.paDetails		=	values;
	rc = mixerGetControlDetails((HMIXEROBJ)m_hMixer, &mxcd, MIXER_GETCONTROLDETAILSF_VALUE);
	if (rc != MMSYSERR_NOERROR)
	{
		left = 0;
		right = 0;
		utils::ErrorBox("Cannot get the current volume");
	}
	else
	{
		left = values[0].dwValue;
		right = values[1].dwValue;
	}
}


void CVolumeControl::SetVolume(int channel, int left, int right)
{
	MMRESULT rc;
	MIXERCONTROLDETAILS_UNSIGNED values[2];
	MIXERCONTROLDETAILS mxcd;

	values[0].dwValue = left;
	values[1].dwValue = right;

	ZeroMemory(&mxcd, sizeof(MIXERCONTROLDETAILS));
	mxcd.cbStruct		= sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID	= m_vLines[channel].dwControlID;
	mxcd.cChannels		= 2;
	mxcd.cMultipleItems	= 0;
	mxcd.cbDetails		= sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mxcd.paDetails		= values;

	rc = mixerSetControlDetails((HMIXEROBJ)m_hMixer, &mxcd, MIXER_SETCONTROLDETAILSF_VALUE);
	if (rc != MMSYSERR_NOERROR)
	{
		utils::ErrorBox("Cannot set the volume");
	}
}


void CVolumeControl::SetMute(int channel, bool bMute)
{
	MIXERCONTROLDETAILS_BOOLEAN mcdbValues[2];
	MIXERCONTROLDETAILS mxcd;

	mcdbValues[0].fValue= static_cast<BOOL>(bMute);
	mxcd.cbStruct		= sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID	= m_vMutes[channel].dwControlID;
	mxcd.cChannels		= 1;
	mxcd.cMultipleItems	= 0;
	mxcd.cbDetails		= sizeof(MIXERCONTROLDETAILS_BOOLEAN);
	mxcd.paDetails		= mcdbValues;
	mixerSetControlDetails(reinterpret_cast<HMIXEROBJ>(m_hMixer), &mxcd, MIXER_SETCONTROLDETAILSF_VALUE);
}


bool CVolumeControl::GetMute(int channel)
{
	MIXERCONTROLDETAILS_BOOLEAN mcdbValues[2];
	MIXERCONTROLDETAILS mxcd;
	mxcd.cbStruct		= sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID	= m_vMutes[channel].dwControlID;
	mxcd.cChannels		= 1;
	mxcd.cMultipleItems	= 0;
	mxcd.cbDetails		= sizeof(MIXERCONTROLDETAILS_BOOLEAN);
	mxcd.paDetails		= mcdbValues;
	mixerGetControlDetails(reinterpret_cast<HMIXEROBJ>(m_hMixer), &mxcd, MIXER_GETCONTROLDETAILSF_VALUE);
	return (mcdbValues[0].fValue != 0);
}


void CVolumeControl::ChangeBalance(int channel, int value)
{
	int left, right, volume;
	if (value < -100) value = -100;
	if (value >  100) value =  100;
	GetVolume(channel, left, right);
	volume = (right > left) ? right : left;
	if (value > 0)
	{
		left = (volume / 100) * (100 - value);
		right = volume;
	}
	else
	{
		value *= -1;
		right = (volume / 100) * (100 - value);
		left = volume;
	}
	SetVolume(channel, left, right);
}


void CVolumeControl::ChangeVolume(int channel, int value)
{
	int balance;
	int left, right;

	if (value < 0) value = 0;
	if (value > 100) value = 100;

	GetVolume(channel, left, right);
	if (right > left)
	{
		if (left == 0)
			balance = 100;
		else
			balance = 100 * left / right;
		right = (655 * value);

		if (right > 65535) right = 65535;
		if (right<1) right = 0;

		left = (right / 100) * balance;
	}
	else
	{
		if (left == 0 || right == 0)
			balance = 100;
		else
			balance = 100 * right / left;
		left = (655 * value);

		if (left > 65535) left = 65535;
		if (left < 11) left = 0;

		right = (left / 100) * balance;
	}
	SetVolume(channel, left, right);
}


void CVolumeControl::VolumeUp(int channel, int nVolumeStep)
{
	int left, right, balance;

	GetVolume(channel, left, right);
	if (right > left)
	{
		balance = 100 * left / right;
		right += 655 * nVolumeStep;
		if (right > 65535) right = 65535;
		left = balance * (right / 100);
	}
	else
	{
		balance = 100 * right / left;
		left += 655 * nVolumeStep;
		if (left > 65535)
			left = 65535;
		else
			right = balance * (left / 100);
	}
	SetVolume(channel, left, right);
}


void CVolumeControl::VolumeDown(int channel, int nVolumeStep)
{
	int left, right, balance;

	GetVolume(channel, left, right);
	if (right > left)
	{
		balance = 100 * left / right;
		right -= 655 * nVolumeStep;
		if (right < 0) right = 0;
		left = balance * (right / 100);
	}
	else
	{
		balance = 100 * right / left;
		left -= 655 * nVolumeStep;
		if (left < 0)
			left = 0;
		else
			right = balance * (left / 100);
	}
	SetVolume(channel, left, right);
}


void CVolumeControl::BalanceLeft(int channel, int nBalanceStep)
{
	int balance, left, right;

	GetVolume(channel, left, right);
	if (left > right && left > 0)
	{
		balance = 100 * right / left;
		balance -= nBalanceStep;
		if (balance < 0) balance = 0;
		right = balance * (left / 100);
	}
	if (left <= right && right > 0)
	{
		balance = 100 * left / right;
		if (balance + nBalanceStep <= 100)
		{
			balance += nBalanceStep;
			left = balance * (right / 100);
		}
		else
		{
			balance += nBalanceStep;
			left = right;
			right = (100-(balance-100)) * (left / 100);
		}
	}
	SetVolume(channel, left, right);
}


void CVolumeControl::BalanceRight(int channel, int nBalanceStep)
{
	int balance, left, right;

	GetVolume(channel, left, right);
	if (right > left && right > 0)
	{
		balance = 100 * left / right;
		balance -= nBalanceStep;
		if (balance < 0) balance = 0;
		left = balance * (right / 100);
	}
	if (right <= left && left > 0)
	{
		balance = 100 * right / left;
		if (balance + nBalanceStep <= 100)
		{
			balance += nBalanceStep;
			right = balance * (left / 100);
		}
		else
		{
			balance += nBalanceStep;
			right = left;
			left = (100-(balance-100)) * (right / 100);
		}
	}
	SetVolume(channel, left, right);
}
