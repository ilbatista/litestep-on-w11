#ifndef __VOLUME_CONTROL_HEADER__
#define __VOLUME_CONTROL_HEADER__

#define BALANCE_STEP	1

class CVolumeControl
{
	HMIXER m_hMixer;	// Mixer handle used in mixer API calls.

	typedef vector<MIXERCONTROL> MIXERCONTROLvector;
	typedef vector<MIXERCONTROL>::iterator MIXERCONTROLiterator;

	MIXERCONTROLvector m_vLines;
	MIXERCONTROLvector m_vMutes;

	void GetLineControls(MIXERLINE &mxl);

public:
	static int g_nVolumeStep, g_nBalanceStep;

	CVolumeControl(HWND hWnd);
	~CVolumeControl();
	void GetVolume(int channel, int &left, int &right);
	void SetVolume(int channel, int left, int right);
	void ChangeBalance(int channel, int value);
	void ChangeVolume(int channel, int value);
	void VolumeUp(int channel, int nVolumeStep = g_nVolumeStep);
	void VolumeDown(int channel, int nVolumeStep = g_nVolumeStep);
	void SetMute(int channel, bool bMute);
	bool GetMute(int channel);
	void BalanceLeft(int channel, int nBalanceStep = g_nVolumeStep);
	void BalanceRight(int channel, int nBalanceStep = g_nBalanceStep);

	int m_nCode;
};

#endif
