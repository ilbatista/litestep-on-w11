#if !defined(__VERINFO_H)
#define __VERINFO_H

#define V_NAME "Label"
#define V_VERSION "1.98"
#define V_AUTHOR "Maduin, Sci, ilmcuts, MickeM, Vendicator, wols"

#endif
