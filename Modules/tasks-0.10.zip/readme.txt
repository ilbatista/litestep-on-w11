Tasks.dll - by Remco de Jong (rdj@telekabel.nl)

This module shows all current tasks as 64*64 icons in the bottom left of the screen.

Options in step.rc:

DefaultAppIcon appicon.bmp
TasksTitlesAlways
TasksTitlesWhenMinimized
TasksFont "Arial"
TasksFontSize 12
TasksTextColor FFFFFF
TasksBackColor 000000

LoadModule C:\litestep\tasks.dll

Always put the LoadModule AFTER you loaded desktop.dll etc, so as the last module in the list.

I've chosen a separate file for configuring the icons, I did this because I'm lazy. 
Put a file called tasks.rc in your litestep dirextory, which contains one or more of the following lines:

Netscape>netscape.bmp
Exploring>explorer.bmp

This line would give all windows with "Netscape" in the _title_ the icon netscape.bmp.
A sample tasks.rc is included. PS don't put whitespaces before or after the '>'.

To do list:

- movable icons
- custom starting position and direction

Please e-mail any suggestions / bugs / complaints to rdj@telekabel.nl, or message [rDJ] in #litestep...