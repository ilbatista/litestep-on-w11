Screenbar
by Jim Babcock

For documentation and newer versions, go to
	http://www.jimrandomh.org/screenbar

