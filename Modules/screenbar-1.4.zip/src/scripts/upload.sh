#!/bin/bash

VERSION=`grep "#define VERSION_NUMBER" screenbar/stdafx.h |awk '{print($3)}'`
echo "Uploading Screenbar $VERSION"

OUTPUTDIR=dist/$VERSION

# Upload to jimrandomh.org
(
	cd "$OUTPUTDIR"
	scp *.zip jimrandomh.org:~/incoming
)

