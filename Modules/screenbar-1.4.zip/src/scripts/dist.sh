#!/bin/bash

# Extract version number
VERSION=`grep "#define VERSION_NUMBER" screenbar/stdafx.h |awk '{print($3)}'`
echo "Creating distribution packages for Screenbar $VERSION"

# Create staging directory
STAGINGDIR=dist/staging
echo "Staging directory is $STAGINGDIR"
rm -rf "$STAGINGDIR"
mkdir -p "$STAGINGDIR"

# Set up directory structure and contents for main distribution
PACKAGEDIR="$STAGINGDIR/screenbar-$VERSION"
echo "Package directory is $PACKAGEDIR"
mkdir -p "$PACKAGEDIR"

cp screenbar/Release/screenbar.dll "$PACKAGEDIR/screenbar.dll"
cp screenbar/Debug/screenbar.dll "$PACKAGEDIR/screenbar_debug.dll"

mkdir "$PACKAGEDIR/scripts"
cp screenbar/screenbar_hotkeys.rc "$PACKAGEDIR/scripts"
cp screenbar/defaultSettings.txt "$PACKAGEDIR/scripts/defaultSettings.rc"

cp -R doc "$PACKAGEDIR"
mkdir -p "$PACKAGEDIR/src"
cp -R scripts Doxyfile *.txt *.sln screenbar "$PACKAGEDIR/src"

# Remove intermediate files
(
	cd "$PACKAGEDIR/src" && (
		rm -rf screenbar/Release screenbar/Debug
		find . -iname '.svn' |xargs rm -rf
		find . -iname '.user' |grep vcproj |xargs rm -f
	)
)

# Zip it all up
(
	cd "$PACKAGEDIR"
	zip -q -r ../screenbar-$VERSION.zip *
)

# Make a minimal distribution, for dependency resolution (DLLs and a readme
# that links to the fill distribution only, no source or documentation)
(
	cd "$PACKAGEDIR"
	zip -q -r ../screenbar-${VERSION}_minimal.zip screenbar.dll screenbar_readme.txt
)

# Make a documentation-only package, to unpack on the web site
(
	zip -q -r "$STAGINGDIR/screenbar-${VERSION}_documentation.zip" docs CHANGELOG.txt
)

# Move packages out of the staging area
OUTPUTDIR=dist/$VERSION
mkdir -p "$OUTPUTDIR"
mv $STAGINGDIR/*.zip "$OUTPUTDIR"

