#!/bin/bash

VERSION="$1"

cat screenbar/stdafx.h \
	|sed -e "s/#define VERSION_NUMBER .*/#define VERSION_NUMBER $VERSION/" \
	>screenbar/stdafx.h.new
mv screenbar/stdafx.h.new screenbar/stdafx.h

cat doc/index.html \
	|sed -e "s/<\!--VERSION-->.*/<\!--VERSION-->Version $VERSION/" \
	>doc/index.html.new
mv doc/index.html.new doc/index.html

