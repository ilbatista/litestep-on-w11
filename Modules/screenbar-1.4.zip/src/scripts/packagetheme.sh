#!/bin/bash

THEMENAME="$1"
THEMEVERSION="$2"

ZIPFILE="${THEMENAME}-${THEMEVERSION}.zip"

STAGINGDIR="dist/staging"
rm -rf "$STAGINGDIR"
mkdir -p "$STAGINGDIR"

cp -R "themes/$THEMENAME" "$STAGINGDIR"

# Remove '.svn' directories from theme
(
	cd "$STAGINGDIR" && (
		find . -iname '.svn' |xargs rm -rf
	)
)

# Zip up the theme
(
	cd "$STAGINGDIR"
	zip -r "$ZIPFILE" "$THEMENAME"
)

# Move to output directory
mv "$STAGINGDIR/$ZIPFILE" "dist/themes/${THEMENAME}-${THEMEVERSION}.lsz"

