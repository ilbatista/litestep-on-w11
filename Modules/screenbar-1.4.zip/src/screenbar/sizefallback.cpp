/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"

/////////////////////////////////////////////////////////////////////////////

SizeFallbackChain::SizeFallbackChain(string chain)
{
	vector<string> tokens;
	tokenizeString(chain, tokens, " ");
	
	// The 0th fallback is always the identity transform
	sizeFallbacks.push_back(new SizeFallback());
	
	// Each fallback thereafter is the previous fallback, plus some additional
	// substitutions.
	for(unsigned ii=0; ii<tokens.size(); ii++)
	{
		SizeFallback *prev = sizeFallbacks[ii];
		string mappings = getConfigLine(tokens[ii].c_str(), "", "");
		SizeFallback *fallback = new SizeFallback(*prev, mappings);
		sizeFallbacks.push_back(fallback);
	}
}

SizeFallbackChain::~SizeFallbackChain()
{
	for(unsigned ii=0; ii<sizeFallbacks.size(); ii++)
		delete sizeFallbacks[ii];
}

SizeFallback *SizeFallbackChain::getFallback(int index)
{
	return sizeFallbacks[index];
}

int SizeFallbackChain::numFallbacks()
{
	return sizeFallbacks.size();
}

/////////////////////////////////////////////////////////////////////////////

SizeFallback::SizeFallback()
{
}

SizeFallback::SizeFallback(const SizeFallback &base, string additionalMappings)
{
	mappings = base.mappings;
	
	vector<string> tokens;
	tokenizeString(additionalMappings, tokens, " ,->");
	
	for(unsigned ii=0; ii+1<tokens.size(); ii+=2)
	{
		mappings[tokens[ii]] = layoutPool->getElement(tokens[ii+1]);
	}
}
