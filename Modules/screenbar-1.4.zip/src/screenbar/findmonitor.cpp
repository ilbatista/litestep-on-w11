/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"

set<Monitor*> monitorByDescription(string keyword, string arg)
{
	set<Monitor*> ret;
	
	if(!keyword.size())
		return ret;
	if(isdigit(keyword[0]))
	{
		int index = atoi(keyword.c_str());
		if(index>=0 && index<monitors->numMonitors())
			ret.insert(monitors->getMonitor(index));
	}
	else if(keyword=="all")
	{
		for(int ii=0; ii<monitors->numMonitors(); ii++)
			ret.insert(monitors->getMonitor(ii));
	}
	else if(keyword=="primary")
	{
		ret.insert(monitors->getPrimaryMonitor());
	}
	else if(keyword=="secondary")
	{
		if(monitors->numMonitors() > 1)
			ret.insert(monitors->getMonitor(1));
	}
	else if(keyword=="clicked")
	{
		if(clickContext) {
			LayoutCacheNode *node = clickContext->getNode();
			if(node && node->context.monitor)
				ret.insert(node->context.monitor);
		}
	}
	else if(keyword=="cursor")
	{
		Monitor *monitor = monitors->findMonitor(getCursorPos());
		if(monitor)
			ret.insert(monitor);
	}
	
	return ret;
}

