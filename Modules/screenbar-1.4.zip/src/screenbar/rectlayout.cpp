/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"

RectLayoutElement::RectLayoutElement(string prefix)
	:LayoutElement(prefix)
{
	x = getConfigString("X", "0", prefix.c_str());
	y = getConfigString("Y", "0", prefix.c_str());
	width = getConfigString("Width", "-0", prefix.c_str());
	height = getConfigString("Height", "-0", prefix.c_str());
	
	useAspectRatio = getConfigBool("UseAspectRatio", false, prefix.c_str());
	aspectRatio = getConfigFloat("AspectRatio", 1.0, prefix.c_str());
	
	minLength = getConfigInt("MinLength", 0, prefix.c_str());
	preferredLength = getConfigInt("PreferredLength", 0, prefix.c_str());
	if(minLength > preferredLength)
		preferredLength = minLength;
}

ElementSize RectLayoutElement::getLength(const LayoutCacheNode *node)
{
	int ret;
	if(useAspectRatio)
	{
		if(node->context.vertical)
			ret = (int)((float)node->context.thickness / aspectRatio);
		else
			ret = (int)((float)node->context.thickness * aspectRatio);
	}
	else
	{
		if(node->context.vertical) {
			int contextHeight = node->boundingRect.height;
			ret = ParseCoordinate(height.c_str(), contextHeight, contextHeight);
		} else {
			int contextWidth = node->boundingRect.width;
			ret = ParseCoordinate(width.c_str(), contextWidth, contextWidth);
		}
	}
	
	return ElementSize(max(ret, minLength), max(ret, preferredLength));
}

Rect RectLayoutElement::getRect(Rect contextRect)
{
	Rect ret = contextRect;
	if(useAspectRatio)
	{
		if(ret.width >= ret.height * aspectRatio)
			ret.width = ret.height * aspectRatio;
		else
			ret.height = ret.width / aspectRatio;
	}
	else
	{
		int contextWidth = ret.width;
		int contextHeight = ret.height;
		ret.left  += ParseCoordinate(x.c_str(), 0, contextWidth);
		ret.top   += ParseCoordinate(y.c_str(), 0, contextHeight);
		ret.width  = ParseCoordinate(width.c_str(), contextWidth, contextWidth);
		ret.height = ParseCoordinate(height.c_str(), contextHeight, contextHeight);
	}
	return ret;
}
