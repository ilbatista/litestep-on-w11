/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"

set<VirtualDesktop*> deskByDescription(string keyword, string arg)
{
	set<VirtualDesktop*> ret;
	
	if(keyword=="")
		return ret;
	
	if(isdigit(keyword[0])) {
		int index = atoi(keyword.c_str()) - 1;
		
		VirtualDesktop *desk;
		if(index >= 0) desk = vwm->getDesk(index);
		else desk = vwm->getDesk(vwm->numDesktops()+index);
		
		if(desk)
			ret.insert(desk);
	}
	
	if(keyword=="all")
	{
		for(int ii=0; ii<vwm->numDesktops(); ii++)
			ret.insert(vwm->getDesk(ii));
	}
	else if(keyword=="current")
	{
		for(int ii=0; ii<vwm->numDesktops(); ii++) {
			VirtualDesktop *desk = vwm->getDesk(ii);
			if(desk->monitor)
				ret.insert(desk);
		}
	}
	else if(keyword=="monitor"
	     || keyword=="monitors")
	{
		set<Monitor*> monitors = findMonitors(arg);
		
		for(int ii=0; ii<vwm->numDesktops(); ii++)
		{
			VirtualDesktop *desk = vwm->getDesk(ii);
			if(monitors.find(desk->monitor) != monitors.end())
				ret.insert(desk);
		}
	}
	else if(keyword=="next"
	     || keyword=="down"
	     || keyword=="right")
	{
		Monitor *contextMonitor = findSingleMonitor(arg);
		if(!contextMonitor) return ret;
		VirtualDesktop *contextDesk = contextMonitor->getDesk();
		
		if(contextDesk->index+1 < vwm->numDesktops())
			ret.insert(vwm->getDesk(contextDesk->index+1));
	}
	else if(keyword=="prev"
	     || keyword=="up"
	     || keyword=="left")
	{
		Monitor *contextMonitor = findSingleMonitor(arg);
		if(!contextMonitor) return ret;
		VirtualDesktop *contextDesk = contextMonitor->getDesk();
		
		if(contextDesk->index > 0)
			ret.insert(vwm->getDesk(contextDesk->index-1));
	}
	else if(keyword=="first")
	{
		ret.insert(vwm->getDesk(0));
	}
	else if(keyword=="last")
	{
		ret.insert(vwm->getDesk(vwm->numDesktops()-1));
	}
	else if(keyword=="other")
	{
		VirtualDesktop *lastFocused = vwm->getLastFocusedDesktop();
		if(lastFocused && !lastFocused->monitor)
			ret.insert(lastFocused);
	}
	else if(keyword=="newfirst")
	{
		VirtualDesktop *newDesk = vwm->createDesktop(0);
		if(newDesk)
			ret.insert(newDesk);
	}
	else if(keyword=="newlast")
	{
		VirtualDesktop *newDesk = vwm->createDesktop(vwm->numDesktops());
		if(newDesk)
			ret.insert(newDesk);
	}
	else if(keyword=="newnext")
	{
		Monitor *contextMonitor = findSingleMonitor(arg);
		if(!contextMonitor) return ret;
		VirtualDesktop *contextDesk = contextMonitor->getDesk();
		if(!contextDesk) return ret;
		
		// Create a new desk after the context desk, and return it
		VirtualDesktop *newDesk = vwm->createDesktop(contextDesk->index+1);
		if(newDesk)
			ret.insert(newDesk);
	}
	else if(keyword=="newprev")
	{
		Monitor *contextMonitor = findSingleMonitor(arg);
		if(!contextMonitor) return ret;
		VirtualDesktop *contextDesk = contextMonitor->getDesk();
		if(!contextDesk) return ret;
		
		VirtualDesktop *newDesk = vwm->createDesktop(contextDesk->index);
		if(newDesk)
			ret.insert(newDesk);
	}
	else if(keyword=="clicked")
	{
		if(clickContext) {
			LayoutCacheNode *node = clickContext->getNode();
			if(node && node->context.desk)
				ret.insert(node->context.desk);
		}
	}
	else if(keyword=="dragged")
	{
		if(drag)
			ret.insert(drag->elementContext.desk);
	}
	else if(keyword=="dropped")
	{
		if(droppedContext) {
			LayoutCacheNode *node = droppedContext->getNode();
			if(node && node->context.desk)
				ret.insert(node->context.desk);
		}
	}
	else if(keyword=="hovered")
	{
		Point mousePos = getCursorPos();
		ScreenbarPanel *panel = findPanel(mousePos.x, mousePos.y);
		if(panel) {
			mousePos -= panel->getTopLeft();
			LayoutLocation hovered = panel->elementAtPoint(mousePos.x, mousePos.y);
			ret.insert(hovered.context.desk);
		}
	}
	else
	{
		for(int ii=0; ii<vwm->numDesktops(); ii++)
		{
			if (keyword==vwm->getDesk(ii)->getName()) {
				ret.insert(vwm->getDesk(ii));
				break;
			}
		}
	}

	return ret;
}
