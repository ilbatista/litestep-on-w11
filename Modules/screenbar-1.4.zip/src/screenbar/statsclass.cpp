/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"

typedef BOOL (*ProcessXStatsFunc)(LPSTR, LPCSTR);
static bool xStatsLoaded = false;
static ProcessXStatsFunc xStatsFunc = NULL;
static string xStatsModuleName;

BOOL __stdcall ModulesCallback(LPCSTR pszPath, DWORD dwFlags, LPARAM lParam)
{
	string path = pszPath;
	for(unsigned ii=0; ii<path.length(); ii++)
		path[ii] = tolower(path[ii]);
	
	string::size_type pos = path.find("xstatsclass-");
	if(pos != string::npos)
	{
		xStatsModuleName = path.substr(pos);
		return FALSE;
	}
	
	return TRUE;
}


string statsClassEval(string str, const ElementContext *context)
{
	if(!xStatsLoaded)
	{
		xStatsLoaded = true;
		
		// Enumerate modules looking for a module xstatsclass-*.
		HRESULT hr = EnumLSData(2/*ELD_MODULES*/, (FARPROC)ModulesCallback, (LPARAM)NULL);

		HMODULE module = GetModuleHandleA(xStatsModuleName.c_str());
		if(!module) {
			warn("Couldn't load xstatsclass\n");
			return "?";
		}
		xStatsFunc = (ProcessXStatsFunc)GetProcAddress(module, "processStatsRequest");
		if(!xStatsFunc) {
			warn("Couldn't load xstatsclass\n");
			return "?";
		}
	}
	if(xStatsFunc) {
		char result[4096];
		xStatsFunc(result, str.c_str());
		return result;
	}
	return "?";
}
