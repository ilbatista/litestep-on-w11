/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

class VWM
{
public:
	VWM();
	~VWM();
	
	void initDesktops();
	void saveState(std::ostringstream &stream);
	void restoreState(std::istream &stream);
	
	int numDesktops() const;
	VirtualDesktop *getDesk(int index);
	VirtualDesktop *getLastFocusedDesktop();
	VirtualDesktop *createDesktop(int index);
	
	void gather();
	RECT getGatherTarget(RECT source, DeskSlot *target);
	VirtualDesktop *deskFromLocation(Rect pos);
	VirtualDesktop *getDeskFromWnd(HWND window);
	
	bool destroyDesktop(VirtualDesktop *desk);
	bool mergeDesk(VirtualDesktop *deletedDesktop, VirtualDesktop *mergeTarget);
	void separateDesk(VirtualDesktop *desk);
	void moveDesk(int oldIndex, int newIndex);
	void switchDesk(VirtualDesktop *newDesk, Monitor *switchingMonitor=NULL, bool skipFocus=false);
	void moveApp(WindowData *representative, VirtualDesktop *dest);
	void moveWindow(WindowData *window, VirtualDesktop *desk);
	void raiseWindow(WindowData *window);
	void deleteEmptyDesktops();
	
	// Window tracking
	VirtualDesktop *rescueOffscreenWindow(WindowData *window, Rect *pos);

	// Window moving
	void beginMovingWindows();
	void transferWindow(WindowData *window, DeskSlot *source, DeskSlot *dest);
	void finishMovingWindows();
	
private:
	vector<VirtualDesktop*> desktops;
	StorageManager storageManager;
	
	int getMinDesktops();
	
	VirtualDesktop *lastFocusedDesktop;
	
	RECT transferRect(RECT rect, DeskSlot *source, DeskSlot *dest);
	typedef map<WindowData*, pair<DeskSlot*,DeskSlot*>> MovedWindowMap;
	MovedWindowMap movedWindows;
};
extern VWM *vwm;

set<VirtualDesktop*> deskByDescription(string keyword, string arg);
