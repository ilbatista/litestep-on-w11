/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"

VirtualDesktop::VirtualDesktop(int index, StorageArea *storage)
{
	this->index = index;
	monitor = NULL;
	this->offScreenStorage = storage;
}

VirtualDesktop::~VirtualDesktop()
{
	offScreenStorage->release();
}

string VirtualDesktop::getName()
{
	char buf[32];
	sprintf(buf, "Desktop %i", index+1);
	return buf;
}

string VirtualDesktop::getLabel()
{
	char buf[16];
	_itoa(index+1, buf, 10);
	return buf;
}

void VirtualDesktop::show(Monitor *monitor)
{
	vector<WindowData*> windows;
	windowTracker->getWindows(this, windows);
	
	for(unsigned ii=0; ii<windows.size(); ii++)
	{
		WindowData *window = windows[ii];
		if(window->tempSticky)
			continue;
		
		vwm->transferWindow(window, currentSlot(), monitor);
	}
	
	lastMaximizeArea = monitor->getMaximizeArea();
	monitor->unstoreRect(lastMaximizeArea);
	
	this->monitor = monitor;
	monitor->setDesk(this);
}

void VirtualDesktop::hide()
{
	// Can't hide if already hidden
	if(!monitor)
		return;
	
	lastMaximizeArea = monitor->getMaximizeArea();
	monitor->unstoreRect(lastMaximizeArea);
	
	vector<WindowData*> windows;
	windowTracker->getWindows(this, windows);
	
	for(unsigned ii=0; ii<windows.size(); ii++)
	{
		WindowData *window = windows[ii];
		if(window->tempSticky)
			continue;
		vwm->transferWindow(window, monitor, offScreenStorage);
	}
	
	monitor = NULL;
}

void VirtualDesktop::switchWith(VirtualDesktop *otherDesk)
{
	if(!otherDesk)
		return;
	
	swap(lastMaximizeArea, otherDesk->lastMaximizeArea);
	
	vector<WindowData*> myWindows;
	vector<WindowData*> otherWindows;
	windowTracker->getWindows(this, myWindows);
	windowTracker->getWindows(otherDesk, otherWindows);
	
	for(unsigned ii=0; ii<myWindows.size(); ii++)
	{
		WindowData *window = myWindows[ii];
		if(window->tempSticky)
			continue;
		vwm->transferWindow(window, currentSlot(), otherDesk->currentSlot());
	}
	for(unsigned ii=0; ii<otherWindows.size(); ii++)
	{
		WindowData *window = otherWindows[ii];
		if(window->tempSticky)
			continue;
		vwm->transferWindow(window, otherDesk->currentSlot(), currentSlot());
	}
	
	swap(monitor, otherDesk->monitor);
	otherDesk->monitor->setDesk(otherDesk);
	monitor->setDesk(this);
}

void VirtualDesktop::moveWindowTo(WindowData *window, VirtualDesktop *target)
{
	if(window->desk == target)
		return;
	
	vwm->transferWindow(window, currentSlot(), target->currentSlot());
	window->desk = target;
}

Monitor *VirtualDesktop::getMonitor()
{
	return monitor;
}

DeskSlot *VirtualDesktop::currentSlot()
{
	if(monitor)
		return monitor;
	else
		return offScreenStorage;
}

DeskSlot *VirtualDesktop::getOffScreenStorage()
	{ return offScreenStorage; }