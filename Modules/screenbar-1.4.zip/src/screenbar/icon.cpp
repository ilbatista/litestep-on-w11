/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"

TaskIconElement::TaskIconElement(string prefix)
	:RectLayoutElement(prefix)
{
	offsetX = getConfigFloat("OffsetX", 0, prefix.c_str());
	offsetY = getConfigFloat("OffsetY", 0, prefix.c_str());
	
#ifdef USE_LSPAINT
	iconPainter = LSPaint_CreateIconPainter(prefix.c_str(), NULL);
#else
	useXPaintClass = getConfigBool("UseXPaintClass", false, prefix.c_str());
	
	if(useXPaintClass) {
		iconPainter = Create_xIconClass();
		iconPainter->configure(prefix.c_str(), "", FALSE, FALSE, NULL, NULL);
	} else {
		iconPainter = NULL;
	}
#endif
}

TaskIconElement::~TaskIconElement()
{
	if(iconPainter) {
	#ifdef USE_LSPAINT
		LSPaint_FreeIconPainter(iconPainter);
	#else
		Destroy_xIconClass(iconPainter);
	#endif
		iconPainter = NULL;
	}
}

void TaskIconElement::draw(HDC drawContext, const LayoutCacheNode *layout)
{
	WindowData *task = layout->context.getTask();
	if(!task)
		task = windowTracker->getForegroundWindow();
	if(!task)
		return;
	
	RECT rect = getRect(layout->boundingRect);
	int width = rect.right - rect.left;
	int height = rect.bottom - rect.top;
	
	IntersectClipRect(drawContext, rect.left, rect.top, rect.right, rect.bottom);
	SetBkMode(drawContext, TRANSPARENT);
	
	int iconSize = max(width, height);
	
	HICON icon = task->getIcon(iconSize);
	
#ifdef USE_LSPAINT
	rect.left   += width*offsetX;
	rect.right  += width*offsetX;
	rect.top    += height*offsetY;
	rect.bottom += height*offsetY;
	
	LSPaint_PaintIcon(iconPainter, icon, drawContext, rect);
#else
	if(useXPaintClass) {
		iconPainter->apply(drawContext,
			rect.left + width*offsetX, rect.top + height*offsetY,
			width, height, icon);
	} else {
		DrawIconEx(drawContext,
			rect.left + width*offsetX, rect.top + height*offsetY,
			icon, width, height,
			0, NULL, DI_NORMAL);
	}
#endif
	SelectClipRgn(drawContext, NULL);
}
