#ifndef PAINTCLASS_HPP
#define PAINTCLASS_HPP

#ifdef USE_LSPAINT

	#include <lspaint.h>

#else

	#include "xExports.h"

	// From xPaintClass/SDK/PaintTexture.h, these were given as a comment instead
	// of an enum or defines, but desperately need to be #defined.
	#define PAINTMODE_NONE -1
	#define PAINTMODE_IMAGE 0
	#define PAINTMODE_ICON 1
	#define PAINTMODE_MULTICOLOR 2
	#define PAINTMODE_COLOR 3
	#define PAINTMODE_BORDERBUTTON 4

#endif

#endif