/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"

StartButtonElement::StartButtonElement(string prefix)
	:LayoutElement(prefix)
{
	string raisedChildName = getConfigString("Raised", "null", prefix.c_str());
	string pressedChildName = getConfigString("Pressed", raisedChildName.c_str(), prefix.c_str());
	raisedChild = layoutPool->getElement(raisedChildName);
	pressedChild = layoutPool->getElement(pressedChildName);
	
	command = getConfigLine("Command", "!popup", prefix.c_str());
	
	onPress[mouseLeft] = "!sbPopup";
	
	childrenCanChange = true;
}

bool isStartButton(LayoutCacheNode *node, void *ignored)
{
	if(dynamic_cast<StartButtonElement*>(node->element))
		return true;
	else
		return false;
}

BangCommand(Popup)
{
	LayoutCacheNode *startButton = NULL;
	
	if(clickContext)
	{
		LayoutCacheNode *node = clickContext->getNode();
		LayoutElement *element = node->element;
		
		if(dynamic_cast<StartButtonElement*>(element))
			startButton = node;
	}
	
	if(!startButton)
	{
		Monitor *preferredMonitor = monitors->findMonitor(getCursorPos());
		LayoutReference *ref = findLayoutNodeMatching(preferredMonitor, isStartButton, NULL);
		if(ref) {
			LayoutCacheNode *node = ref->getNode();
			if(node && dynamic_cast<StartButtonElement*>(node->element))
				startButton = node;
		}
	}
	
	if(startButton)
	{
		StartButtonElement *element = dynamic_cast<StartButtonElement*>(startButton->element);
		element->press(startButton);
	}
}

StartButtonElement::~StartButtonElement()
{
}

void StartButtonElement::deleteElementData(LayoutCacheNode *node, void *elementData)
{
}

void StartButtonElement::press(LayoutCacheNode *node)
{
	ScreenbarWindow *window = node->context.window;
	ScreenbarPanel *panel = dynamic_cast<ScreenbarPanel*>(window);
	if(panel)
		panel->unhide();
	
	Point pos = panel->getMenuPos(node->boundingRect);
	string edge = panel->getMenuEdgeName();
	
	// HACK: Negative coordinates are treated as relative to the right edge
	// of the screen, so subtract the main monitor width to cancel that out
	if(pos.x < 0) pos.x -= monitors->getPrimaryMonitor()->getRect().width;
	if(pos.y < 0) pos.y -= monitors->getPrimaryMonitor()->getRect().height;
	
	string fullCommand = retprintf("%s %s %i %i", command.c_str(), edge.c_str(), pos.x, pos.y);
	LSExecute(node->context.window->getWindow(), fullCommand.c_str(), SW_SHOWNORMAL);
	
	node->elementData = (void*)GetForegroundWindow();
	
	updateLayouts();
}

void StartButtonElement::getChildren(LayoutCacheNode *node, vector<LayoutLocation> &outChildren)
{
	LayoutLocation ret;
	ret.context = node->context;
	
	// If the menu was open but its window is gone, move the button back to its 'up' state
	if(node->elementData && !IsWindowVisible((HWND)node->elementData)) {
		node->elementData = NULL;
	}
	
	if(node->elementData) {
		ret.element = pressedChild;
	} else {
		ret.element = raisedChild;
	}
	
	outChildren.push_back(ret);
}

bool StartButtonElement::allowAutoHide(LayoutCacheNode *node)
{
	if(node->elementData != 0)
		return false;
	else
		return true;
}