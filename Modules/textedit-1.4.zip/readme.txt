Text Edit (v1.4) by WhiteShadow (changty@muohio.edu) on 7-03-00
*******************************************************************

This is a small module that can be used to edit text files.  It 
could be useful in allowing you to edit your step.rc file on the 
fly.  However, it could also be very dangerous if used on the wrong 
file.

Installation:

	1. Copy textedit.dll into your litestep folder
	2. Add the line 

		LoadModule c:\litestep\textedit.dll

	   to your step.rc (with the appropriate drive letter and 
	   path)
	3. Recycle Litestep

Usage:

	Bang Commands
	-------------

	!textappend "filename" text to be added

	   This will add the line "text to be added" to the bottom of
	   the file "filename".  Use quotes around the filename if it
	   contains spaces.  If the file does not exist, nothing
	   happens.  NOTE: this used to be !textadd.  Currently either
	   !textadd or !textappend will work, !text add will be 
	   removed in the next release.


	!textdel "filename" text to be deleted

	   This will delete every line in "filename" that matches
	   "text to be deleted".  This means that if it occurs more
	   than once in the file, every case of it will be removed.


	!textdelsingle "filename" number text to be deleted

	   This will delete a single occurance of "text to be deleted".
	   Number specifies which occurance to delete (1 = first time
	   it appears in the file, 2 = second time, etc).


	!textinsert "filename" number text to insert

	   This will insert "text to insert" into the line number
	   specified.  It will push lines below it down by one.


	!textreplace "filename" "string1" "string2"

	   You must use quotes for this one.  If you need to use " in
	   either string1 or string2, use the ^".  This replaces
	   anything matching string1 to string2 (you can use *'s in
	   string1).


	!textcomment "filename" numbers

	   This adds a comment to the line numbers specified.  The
	   comment character is a ; by default, but this can be 
	   changed with !textsetcommentchar.  Numbers is a list of
	   line numbers separated by commas or spaces.


	!textsetcommentchar text

	   This sets the comment character to text.  By default the
	   comment char is a ; (litestep comment).


	!textcopyfile "source file" "destination file"

	   Copies ASCII files.


	Step.rc Options
	---------------

	TextSubst
	   If you have this line in your step.rc, all ^ will be replaced 
	   with !.  This could be useful for scripting since litestep
	   tries to execute anything that has a !.

	TextNotCaseSensitive
	   Turns off case sensitivity for deletion.

	TextCalculate
	   If this is on, then any math expression enclosed in {}'s will
	   be evaluated.  There are are also variables for height and 
	   width, which are the height and width of the desktop.  See
	   below for examples.

	Other notes
	-----------

	Also, you can add a * at the end of the string to delete to
	delete everything begining with the string.  There are 
	examples of this below.

Examples:

	1. !textappend c:\litestep\step.rc *Hotkey CTRL+ALT Q !quit

	   This adds the line "*Hotkey CTRL+ALT Q !quit" to your
	   step.rc file.


	2. !textdel c:\mirc\logs\#litestep.log <someguy> poop

	   This would open up your #litestep log file and remove every 
	   line where someguy says poop.


	3. !textdel c:\litestep\step.rc *shortcut *
	
	   This will delete every shortcut line in your step.rc


	4. !textdel c:\mirc\logs\somechan.log *

	   This will delete every line in somechan.log.


	5. !textdelsingle c:\litestep\step.rc 3 *hotkey *

	   This will delete the third hotkey in your step.rc.


	6. !textdelsingle c:\someotherfile.txt 8 *

	   This will delete the 8th line in someotherfile.txt.


	7. !textinsert c:\litestep\step.rc 5 ; hello world

	   This inserts "; hello world" as the 5th line of your
	   step.rc.


	8. !textcomment c:\litestep\step.rc 4,1,5 6

	   This comments lines 1, 4, 5 and 6 in your step.rc.


	9. !textsetcommentchar //

	   This sets the comment character as //.


	10. !textappend "c:\litestep\step.rc" "CommandX {width/2-50}"

	   If TextCalculate is in the step.rc and you are at 1024x768, 
	   then this would append the line "CommandX 462" to your
	   step.rc.


	11. !textcopyfile "c:\litestep\step.rc" "c:\litestep\step.rc.bak"

	   Makes a backup copy of your step.rc.


History:

	v1.4 (07-03-00)
	+Added !textcopyfile
	+Added TextCalculate

	v1.3 (04-30-00)
	-Changed !textadd to !textappend
	+Added !textinsert
	+Added !textreplace
	+Added !textcomment and !textsetcommentchar
	+Added TextNotCaseSensitive

	v1.2 (04-10-00)
	+Added * at end of strings
	+Added !textdelsingle

	v1.1 (04-04-00)
	+Added TextSubst

 	v1.0 (04-02-00)
	-initial release

Anyway, that's all, enjoy!
Feel free to send me comments or bugs.
WhiteShadow
