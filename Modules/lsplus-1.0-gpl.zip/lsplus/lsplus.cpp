/****************************************************************
This sourcecode is part of:
LSPlus.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)

The program mentioned above is copyrighted freeware
for any noncommercial use or distribution.

The text you are reading now must be included with the program
when distributing.

The copyright holder retains all rights and copyright to all his
works in this program.

You can use it freely for your own personal use, and can
distribute it to anyone as long as the original file remains
intact, including this text. However, you cannot put any part
of this program onto web pages, BBSs, CD-ROMs, books, magazines
or other media without my written permission.

This program may not be altered for redistribution without
my written permission.

The program is provided "as is", without warranty of any kind,
express or implied, including but not limited to warranties of
merchantability, fitness for a particular purpose and
non-infringement. In no event shall I, the author and copyright
holder be liable, whether in action of contract, tort or otherwise,
arising from, out of or in connection with the program or the use
or other dealings in the software.

Mike Edward Moras
e-sushi@gmx.net

This sourcecode is part of:
LSPlus.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/

/****************************************************************
12OCT02: e-sushi
    - released this thing under GNU GPL v2

15SEP02: by Mike Edward Moras (e-sushi@gmx.net)	
	- got feedback all working fine, also on purels!

15SEP02: by Mike Edward Moras (e-sushi@gmx.net)	
	- testing

15SEP02: by Mike Edward Moras (e-sushi@gmx.net)	
	- tuning the code a bit for a first release
****************************************************************/

#include "lsplus.h"


int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	AddBangCommand("!THEME", bangTHEME);
	AddBangCommand("!WALL", bangWALL); 
	AddBangCommand("!WINDOWS", bangWINDOWS);
	AddBangCommand("!FILE",bangFILE);
	AddBangCommand("!PLAYWAV",bangPLAYWAV);
	AddBangCommand("!CLEAN",bangCLEAN);
	AddBangCommand("!CRYPT",bangCRYPT);
	AddBangCommand("!WAIT",bangWAIT);
	


	char one[1024] = "";
	if (GetRCBool("lsplusplaystartsound", true) == TRUE) {
		GetRCString("lsplusstartsound", one, "", MAX_PATH);
		PlaySound(one, NULL, SND_SYNC | SND_FILENAME );
	}
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!THEME");
	RemoveBangCommand("!WALL");
	RemoveBangCommand("!WINDOWS");
	RemoveBangCommand("!FILE");
	RemoveBangCommand("!PLAYWAV");
	RemoveBangCommand("!CLEAN");
	RemoveBangCommand("!CRYPT");
	RemoveBangCommand("!WAIT");


}



/****************************************************************
 QuickSort and Partition for theme and wall sorting
****************************************************************/

void QuickSort (char** szArray, int nLower, int nUpper)
{
	if (nLower < nUpper) {
		int nSplit = Partition (szArray, nLower, nUpper);
		QuickSort (szArray, nLower, nSplit - 1);
		QuickSort (szArray, nSplit + 1, nUpper);
	}
}

int Partition (char** szArray, int nLower, int nUpper)
{
	int nLeft = nLower + 1;
	char* szPivot = szArray[nLower];
	int nRight = nUpper;
	char* szSwap;
	while (nLeft <= nRight) {
		while (nLeft <= nRight && strcmp (szArray[nLeft], szPivot) <= 0)
			nLeft = nLeft + 1;
		while (nLeft <= nRight && strcmp (szArray[nRight], szPivot) > 0)
			nRight = nRight - 1;
		if (nLeft < nRight) {
			szSwap = szArray[nLeft];
			szArray[nLeft] = szArray[nRight];
			szArray[nRight] = szSwap;
			nLeft = nLeft + 1;
			nRight = nRight - 1;
		}
	}
	szSwap = szArray[nLower];
	szArray[nLower] = szArray[nRight];
	szArray[nRight] = szSwap;
	return nRight;
}


/****************************************************************
 code: bangTHEME
****************************************************************/

void bangTHEME(HWND caller, LPCSTR args)
{
	char one[1024] = "", two[1024] = "";
	GetToken(args, one, &args, true);
	GetToken(args, two, &args, true);
	
	if(!stricmp(one,"set")) {
		char szTHEME[MAX_PATH]="";
		LSGetLitestepPath(szTHEME, MAX_PATH);
		strcat(szTHEME, "\\theme.rc");
		FILE *stream;
		stream = fopen( szTHEME, "w" );
		fprintf(stream,"DIRTHEME \"%s\"\n",two);
		fprintf(stream,"THEMEDIR \"%s\"\n",two);
		fprintf(stream,"DIRTHEMES \"%s\"\n",two);
		fprintf(stream,"THEMESDIR \"%s\"\n",two);
		fprintf(stream,"include \"%sstep.rc\"\n",two);
		fclose( stream );
		LSExecuteEx(GetLitestepWnd(), NULL, "!Recycle", NULL, NULL, 0);
	} else if (!stricmp(one, "get")) {
		char szSCAN[MAX_PATH]="";
		strcat(szSCAN, two);
		strcat(szSCAN, "*.*");
		char szTHEMES[MAX_PATH]="", PATHfound[MAX_PATH]="";
		LSGetLitestepPath(szTHEMES, MAX_PATH);
		strcat(szTHEMES, "\\themes.rc");
		FILE *stream;
		stream = fopen( szTHEMES, "w" );
		struct _finddata_t c_file;
		long hFile;
		if((hFile = _findfirst(szSCAN, &c_file)) != -1L)
			_findnext(hFile, &c_file);
		while(_findnext(hFile, &c_file) == 0){
			if((c_file.attrib & _A_SUBDIR )){
				strcpy(PATHfound,two);
				strcat(PATHfound,c_file.name);
				strcat(PATHfound,"\\");
				fprintf(stream,"*popup \"%s\" !theme \"set\" \"%s\"\n", c_file.name,PATHfound);
			}
		}
		fclose( stream );
		char szSRC[MAX_PATH]="", szDEST[MAX_PATH]="";
		LSGetLitestepPath(szSRC, MAX_PATH);
		LSGetLitestepPath(szDEST, MAX_PATH);
		strcat(szSRC, "\\themes.rc");
		strcat(szDEST, "\\themes.tmp");

		const int nGrow = 8;
		int nAlloc = nGrow, nSize = 0;
		char** szContents = new char* [nAlloc];
		char szSRCLine [1024]="";
		FILE* pStream = fopen (szSRC, "rt");
		while (fgets (szSRCLine, 1024, pStream)) {
			char* pszCheck = szSRCLine;
			while (*pszCheck != '\0') {
				if (*pszCheck == '\n' && *(pszCheck + 1) == '\0')
					*pszCheck = '\0';
				pszCheck++;
			}
			szContents[nSize] = new char [strlen (szSRCLine) + 1];
			strcpy (szContents[nSize], _strlwr(szSRCLine));
			nSize = nSize + 1;
			if (nSize % nGrow == 0) {
				char** szPrev = szContents;
				nAlloc += nGrow;
				szContents = new char* [nAlloc];
				memcpy (szContents, szPrev, nSize * sizeof(char*));
				delete szPrev;
			}
		}
		fclose (pStream);
		QuickSort (szContents, 0, nSize - 1);
		pStream = fopen (szDEST, "wt");
		for (int nIndex = 0; nIndex < nSize; nIndex++) {
			fprintf (pStream, "%s\n", szContents[nIndex]);
		}
		fclose (pStream);
		
		for (nIndex = 0; nIndex < nSize; nIndex++) {
			delete szContents[nIndex];
		}
		delete szContents;
		szContents = NULL;
		DeleteFile(szSRC);
		CopyFile(szDEST,szSRC,NULL);
		DeleteFile(szDEST);
		LSExecuteEx(GetLitestepWnd(), NULL, "!Recycle", NULL, NULL, 0);
	} 
}


/****************************************************************
 code: bangWALL
****************************************************************/
			char WallpaperFileName[MAX_PATH] = "";	

void bangWALL(HWND caller, LPCSTR args)
{
	char one[1024] = "", two[1024] = "";
	GetToken(args, one, &args, true);
	GetToken(args, two, &args, true);
	
	if(!stricmp(one,"set")) {
		//
	HKEY hKey;
	char szValue1[2]="", szValue2[2]="",chkHOW[MAX_PATH]="";
	GetRCString("wallzstyle", chkHOW, "", MAX_PATH);

	//check for bmp or png conversion first... two holds file!!!
	
		char *wk = strrchr(two, '.');
		if( wk ){
			++wk;

			char ext[4] = "";
			for( int k=0; k<3; k++){
				ext[k] = wk[k];
			}
			char CurDir[MAX_PATH]="";
			strcpy(CurDir,two);
			int nLen;
			nLen = lstrlen( CurDir) - 1;
					while ( nLen > 0 && CurDir[nLen] != '\\' )
						nLen--;
					CurDir[nLen + 1] = 0;


		//	::GetModuleFileName(caller, CurDir, MAX_PATH);
			char *dir = strrchr(CurDir, '\\');
			*dir = '\0';

			wsprintf(WallpaperFileName, "%s\\wallz.bmp", CurDir);

			 if(!::lstrcmpi(ext, "png")){
				PngConvert(two, WallpaperFileName);
			}
			else if(!::lstrcmpi(ext, "bmp")){
				lstrcpy(WallpaperFileName, two);
			}
		}


		if (!stricmp(chkHOW, "tile")) {
		
			if(RegOpenKeyEx(HKEY_CURRENT_USER, "Control Panel\\Desktop", 0, KEY_WRITE, &hKey) == ERROR_SUCCESS) {
				strcpy(szValue1, "1");
				strcpy(szValue2, "1");
				RegSetValueEx(hKey, "WallpaperStyle", 0, REG_SZ, (unsigned char *)szValue1, strlen(szValue1) + 1);
				RegSetValueEx(hKey, "TileWallpaper", 0, REG_SZ, (unsigned char *)szValue2, strlen(szValue2) + 1);
				RegCloseKey(hKey);
			}
			SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, (void*)WallpaperFileName, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
		
		} else if (!stricmp(chkHOW, "center")) {
			if(RegOpenKeyEx(HKEY_CURRENT_USER, "Control Panel\\Desktop", 0, KEY_WRITE, &hKey) == ERROR_SUCCESS) {
				strcpy(szValue1, "0");
				strcpy(szValue2, "0");
				RegSetValueEx(hKey, "WallpaperStyle", 0, REG_SZ, (unsigned char *)szValue1, strlen(szValue1) + 1);
				RegSetValueEx(hKey, "TileWallpaper", 0, REG_SZ, (unsigned char *)szValue2, strlen(szValue2) + 1);
				RegCloseKey(hKey);
			}
			SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, (void*)WallpaperFileName, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
		} else {
			if(RegOpenKeyEx(HKEY_CURRENT_USER, "Control Panel\\Desktop", 0, KEY_WRITE, &hKey) == ERROR_SUCCESS) {
				strcpy(szValue1, "2");
				strcpy(szValue2, "0");
				RegSetValueEx(hKey, "WallpaperStyle", 0, REG_SZ, (unsigned char *)szValue1, strlen(szValue1) + 1);
				RegSetValueEx(hKey, "TileWallpaper", 0, REG_SZ, (unsigned char *)szValue2, strlen(szValue2) + 1);
				RegCloseKey(hKey);
			}
			SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, (void*)WallpaperFileName, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );	
		}

	} else if (!stricmp(one, "get")) {


		char szSCAN[MAX_PATH]="";
		strcat(szSCAN, two);
		strcat(szSCAN, "*.*");
		char szTHEMES[MAX_PATH]="", PATHfound[MAX_PATH]="";
		LSGetLitestepPath(szTHEMES, MAX_PATH);
		strcat(szTHEMES, "\\wallz.rc");
		FILE *stream;
		stream = fopen( szTHEMES, "w" );
		struct _finddata_t c_file;
		long hFile;
		if((hFile = _findfirst(szSCAN, &c_file)) == 0)
			_findnext(hFile, &c_file);//always fetches first file, so the "."
			_findnext(hFile, &c_file);//quick-fix to sort out the ".."
		while(_findnext(hFile, &c_file) == 0){
			if((c_file.attrib)){	
				strcpy(PATHfound,two);
				strcat(PATHfound,c_file.name);
				if(!stricmp(PATHfound + strlen(PATHfound) - 4, ".bmp")) {
					if(stricmp(PATHfound + strlen(PATHfound) - 9, "wallz.bmp")) {
						fprintf(stream,"*popup \"%s\" !wall \"set\" \"%s\"\n", c_file.name,PATHfound);
					}
				}
				if(!stricmp(PATHfound + strlen(PATHfound) - 4, ".png")) {
						fprintf(stream,"*popup \"%s\" !wall \"set\" \"%s\"\n", c_file.name,PATHfound);
				}
			}
		}

		fclose( stream );


		char szSRC[MAX_PATH]="", szDEST[MAX_PATH]="";
		LSGetLitestepPath(szSRC, MAX_PATH);
		LSGetLitestepPath(szDEST, MAX_PATH);
		strcat(szSRC, "\\wallz.rc");
		strcat(szDEST, "\\wallz.tmp");

		const int nGrow = 8;
		int nAlloc = nGrow, nSize = 0;
		char** szContents = new char* [nAlloc];
		char szSRCLine [1024]="";
		FILE* pStream = fopen (szSRC, "rt");
		while (fgets (szSRCLine, 1024, pStream)) {
			char* pszCheck = szSRCLine;
			while (*pszCheck != '\0') {
				if (*pszCheck == '\n' && *(pszCheck + 1) == '\0')
					*pszCheck = '\0';
				pszCheck++;
			}
			szContents[nSize] = new char [strlen (szSRCLine) + 1];
			strcpy (szContents[nSize], _strlwr(szSRCLine));
			nSize = nSize + 1;
			if (nSize % nGrow == 0) {
				char** szPrev = szContents;
				nAlloc += nGrow;
				szContents = new char* [nAlloc];
				memcpy (szContents, szPrev, nSize * sizeof(char*));
				delete szPrev;
			}
		}
		fclose (pStream);
		QuickSort (szContents, 0, nSize - 1);
		pStream = fopen (szDEST, "wt");
		for (int nIndex = 0; nIndex < nSize; nIndex++) {
			fprintf (pStream, "%s\n", szContents[nIndex]);
		}
		fclose (pStream);
		
		for (nIndex = 0; nIndex < nSize; nIndex++) {
			delete szContents[nIndex];
		}
		delete szContents;
		szContents = NULL;
		DeleteFile(szSRC);
		CopyFile(szDEST,szSRC,NULL);
		DeleteFile(szDEST);
		LSExecuteEx(GetLitestepWnd(), NULL, "!Recycle", NULL, NULL, 0);

	} 
}



/****************************************************************
 bangWINDOWS
****************************************************************/

BOOL CALLBACK WindowsEnumProc(HWND hwnd, LPARAM lParam)
{
	if(IsWindow(hwnd)){
		if(GetWindowLong(hwnd,GWL_USERDATA) != magicDWord){
			if(!(GetWindowLong(hwnd, GWL_STYLE) & WS_CHILD) && (GetWindowLong(hwnd, GWL_STYLE) & WS_VISIBLE)){
				if(!(GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)){
					ShowWindow(hwnd, (UINT)lParam);
				}
			}
		}
	}
	return TRUE;
}

BOOL CALLBACK WindowsKillProc( HWND hwnd, LPARAM lParam)
{
    long style;
    if(IsWindowVisible(hwnd)) {
        style=GetWindowLong(hwnd,GWL_STYLE);
        if(style & WS_OVERLAPPEDWINDOW && (style & WS_POPUP)== false) {
			PostMessage(hwnd,WM_CLOSE,0,0);
        }
    }
    return true;
}


void bangWINDOWS(HWND caller, LPCSTR args)
{
	BOOL (WINAPI *SwitchToThisWindow)(HWND, BOOL) = (BOOL (WINAPI *)(HWND, BOOL)) GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");
	HWND hWnd = NULL;
	char one[1024] = "", two[1024]="",three[1024] = "",four[1024]="";
	GetToken(args, one, &args, true);
	GetToken(args, two, &args, true);
	GetToken(args, three, &args, true);
	GetToken(args, four, &args, true);

	if (!stricmp(one, "single")) {
		if(!strlen(three)) {
			if(strlen(four)) {
				hWnd = FindWindow(four, NULL);
			}
		} else {
			if(!strlen(four)) {
				hWnd = FindWindow(NULL, three);
			} else {
				hWnd = FindWindow(four, three);
			}
		}
		if(!stricmp(two, "focus")) {
			SwitchToThisWindow(hWnd, TRUE);
		}
		else if(!stricmp(two, "minimize")) {
			SendMessage(hWnd, WM_SYSCOMMAND, SC_MINIMIZE, NULL);
		}
		else if(!stricmp(two, "maximize")) {
			SendMessage(hWnd, WM_SYSCOMMAND, SC_MAXIMIZE, NULL);
		}
		else if(!stricmp(two, "restore")) {
			SendMessage(hWnd, WM_SYSCOMMAND, SC_RESTORE, NULL);
		}
		else if(!stricmp(two, "close")) {
			SendMessage(hWnd, WM_SYSCOMMAND, SC_CLOSE, NULL);
		}
	//	else if(!stricmp(two, "show")) {
	//		ShowWindow(hWnd,SW_SHOW);
	//	}
	//	else if(!stricmp(two, "hide")) {
	//		ShowWindow(hWnd,SW_HIDE);
	//	}
	} else if (!stricmp(one, "close")) {
		EnumWindows(WindowsKillProc,0);
	} else if (!stricmp(one, "minimize")) {
		EnumWindows(WindowsEnumProc, (LPARAM)SW_MINIMIZE);
	} else if (!stricmp(one, "maximize")) {
		EnumWindows(WindowsEnumProc, (LPARAM)SW_MAXIMIZE);
	} else if (!stricmp(one, "restore")) {
		EnumWindows(WindowsEnumProc, (LPARAM)SW_RESTORE);
	} else if (!stricmp(one, "htile")) {
		TileWindows(NULL, MDITILE_HORIZONTAL, NULL, 0, NULL);
	} else if (!stricmp(one, "vtile")) {
		TileWindows(NULL, MDITILE_VERTICAL, NULL, 0, NULL);
	} else if (!stricmp(one, "cascade")) {
		CascadeWindows(NULL, MDITILE_SKIPDISABLED, NULL, 0, NULL);
	//} else if (!stricmp(one, "show")) {
	//	EnumWindows(WindowsEnumProc, (LPARAM)SW_SHOW);
	//} else if (!stricmp(one, "hide")) {
	//	EnumWindows(WindowsEnumProc, (LPARAM)SW_HIDE);
	} 
}

/****************************************************************
 code: bangFILE
****************************************************************/

void bangFILE(HWND caller, LPCSTR args)
{
	char one[1024] = "", two[1024] = "", three[1024] = "",four[1024] = "",five[1024] = "";
	GetToken(args, one, &args, true);
	GetToken(args, two, &args, true);
	GetToken(args, three, &args, true);
	GetToken(args, four, &args, true);
	GetToken(args, five, &args, true);

	if (!stricmp(one, "move")) {
		if(!MoveFile(two,three)){
			LSExecute(NULL, five, 0);
			//MessageBox(NULL,two,"file not found",MB_OK);
		} else {
			LSExecute(NULL, four, 0);
		}
	} else if (!stricmp(one, "copy")) {
		if(!CopyFile(two,three,false)) {
			LSExecute(NULL, five, 0);
			//MessageBox(NULL,two,"file not found",MB_OK);
		} else {
			LSExecute(NULL, four, 0);
		}
	} else if (!stricmp(one, "delete")) {
		if(!DeleteFile(two)) {
			LSExecute(NULL, four, 0);
			//MessageBox(NULL,two,"file not found",MB_OK);
		} else {
			LSExecute(NULL, three, 0);
		}
	} else if (!stricmp(one, "open")) {
		if (!stricmp(three,"maximized")) {
			if(!ShellExecute(NULL,"open",two,NULL,NULL,SW_SHOWMAXIMIZED )) {
				LSExecute(NULL, four, 0);
				//MessageBox(NULL,two,"file not found",MB_OK);
			} else {
				LSExecute(NULL, three, 0);
			}
		} else if (!stricmp(three,"normal")) {
			if(!ShellExecute(NULL,"open",two,NULL,NULL,SW_SHOWNORMAL )) {
				LSExecute(NULL, four, 0);
				//MessageBox(NULL,two,"file not found",MB_OK);
			} else {
				LSExecute(NULL, three, 0);
			}
		}
	} else if (!stricmp(one, "explore")) {
		if (!stricmp(three,"maximized")) {
			if(!ShellExecute(NULL,"explore",two,NULL,NULL,SW_SHOWMAXIMIZED )) {
				MessageBox(NULL,two,"not found",MB_OK);
			}
		} else if (!stricmp(three,"normal")) {
			if(!ShellExecute(NULL,"explore",two,NULL,NULL,SW_SHOWNORMAL )) {
				MessageBox(NULL,two,"not found",MB_OK);
			}
		}
	}
}

/****************************************************************
 code: bangPLAYWAV
****************************************************************/

void bangPLAYWAV(HWND caller, LPCSTR args)
{
	char one[1024] = "";
	GetToken(args, one, &args, true);
	PlaySound(one, NULL, SND_SYNC | SND_FILENAME );
	
}

/****************************************************************
 code: bangCLEAN
****************************************************************/

void bangCLEAN(HWND caller, LPCSTR args)
{
	
	char one[1024] = "";
	GetToken(args, one, &args, true);
	
	if (!stricmp(one, "clipboard")) {
		OpenClipboard(NULL);
		EmptyClipboard();
		CloseClipboard();
	} else if (!stricmp(one, "trashbin")) {
		SHEmptyRecycleBin(0, "", SHERB_NOCONFIRMATION );
	}
}

/****************************************************************
 code: bangCRYPT
****************************************************************/

void bangCRYPT(HWND caller, LPCSTR args)
{
	
	char one[1024] = "",two[1024] = "";
	
	GetToken(args, one, &args, true);
	GetToken(args, two, &args, true);

	
	FILE *oneFILE,*tmpFILE;
	
	if ((oneFILE = fopen(one, "rb")) == NULL) {
		_fcloseall();
		return;
	}
	
	char tmpPATH[MAX_PATH];
	LSGetLitestepPath(tmpPATH, MAX_PATH);
	strcat(tmpPATH,"0.0");
	
	if ((tmpFILE = fopen(tmpPATH, "wb")) == NULL) {
		_fcloseall();
		return;
	}

	int outCHAR;
	strcat(two," 7zX 7yX z7x Yz7 BeO7wUlF 7zX cRyO7yX z7xgEnEtIc 01Yz7 ");
	int twoCHARLEN=strlen(two);
	int twoCHARNUM=0;
	
	int mixCHAR;
	int mixER=0;

		while(( outCHAR = getc(oneFILE)) != EOF) { 
			// ****my 2-block  XOR thingy
			outCHAR ^= two[twoCHARNUM];
			mixCHAR = (mixER*twoCHARNUM)+1;
			mixER++;
			if(mixER>7){
				mixER=0;
			}
			outCHAR ^= mixCHAR;
			putc(outCHAR, tmpFILE);
			twoCHARNUM++;
			if(twoCHARNUM>twoCHARLEN){
				twoCHARNUM=0;
			}
		}
	
	fclose(oneFILE); 
	fclose(tmpFILE); 
	
	DeleteFile(one);
	CopyFile(tmpPATH,one,NULL);
	DeleteFile(tmpPATH);
}

/****************************************************************
 code: bangWAIT
/****************************************************************/

void bangWAIT(HWND caller, LPCSTR args)
{
	char one[1024] = "";
	GetToken(args, one, &args, true);
	Sleep(atoi(one));
}




/****************************************************************
This sourcecode is part of:
LSPlus.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/