#include "lsplus.h"


int check_if_png(char* file_name, FILE** fp){
	unsigned char buf[PNG_BYTES_TO_CHECK];
	*fp = fopen(file_name, "rb");
	if( fp == NULL )		return 0;

	if( fread(buf, 1, PNG_BYTES_TO_CHECK, *fp) != PNG_BYTES_TO_CHECK )	return 0;

	return (!png_sig_cmp(buf, (png_size_t)0, PNG_BYTES_TO_CHECK) );
}



png_bytepp row_pointers = NULL;
png_colorp color_palette = NULL;
unsigned g_width = 0, g_height = 0, g_bsize = 0, g_palette = 0;


int PngConvert(const char* file_name, const char* outfile){
	FILE* fp;
	if( (fp= fopen(file_name, "rb")) == NULL )	return 1;

	png_structp png_ptr
		= png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if( png_ptr == NULL){
		fclose(fp);
		return 1;
	}

	png_infop info_ptr
		= png_create_info_struct(png_ptr);
	if( info_ptr == NULL || setjmp(png_jmpbuf(png_ptr)) ){
		png_destroy_read_struct( &png_ptr, &info_ptr, (png_infopp)NULL );
		fclose(fp);
		return 1;
	}

	unsigned sig_read = 0;

	png_init_io( png_ptr, fp );
	png_set_sig_bytes( png_ptr, sig_read );
 	png_read_png( png_ptr, info_ptr, PNG_TRANSFORM_BGR, NULL );
 	row_pointers = png_get_rows(png_ptr, info_ptr);
		// ���̕ӂ�܂ł́Alibpng��exsample.c�Q��(^^;;)
		// �ڍׂ�libpng.txt�����Ă��������B

	if( info_ptr->pixel_depth == 8 ){		// 256�F�̏���;
		int nigoro = 256;
		png_get_PLTE(png_ptr, info_ptr, &color_palette, &nigoro);
			//	�p���b�g�̏����B
	}
	else {
		color_palette = NULL;
	}		//	24bit�̏ꍇ�́A�p���b�g�͕s�v

 	g_width = info_ptr->width;
 	g_height = info_ptr->height;
	g_bsize = info_ptr->channels;
	SavePng2Bmp(outfile);

	png_destroy_read_struct( &png_ptr, &info_ptr, (png_infopp)NULL );
		// �\���̂Ȃǂ̔j��
	fclose(fp);
	return 0;
}



int SavePng2Bmp(const char* filepath){
	FILE* outfile;
	BITMAPFILEHEADER BmpFH;
	BITMAPINFOHEADER BmpIH;
	unsigned fhs = sizeof(BITMAPFILEHEADER),
			 ihs = sizeof(BITMAPINFOHEADER);

	if( ( outfile = fopen(filepath, "wb") )== NULL )	return 1;

	unsigned width = g_width;
	if( int rowd = g_width % 4 )	width += 4-rowd;
			// �r�b�g�}�b�v�̕�������Ȃ��Ƃ��ɕ⊮����
	int bmp_size = g_height*width*g_bsize;

	memset( &BmpFH, 0, fhs );
	BmpFH.bfType = 0x4D42;	// BM
	BmpFH.bfSize = fhs + ihs + bmp_size;
	BmpFH.bfOffBits = fhs + ihs;

	memset( &BmpIH, 0, ihs );
	BmpIH.biSize = ihs;
	BmpIH.biWidth = width;
	BmpIH.biHeight = g_height;
	BmpIH.biPlanes = 1;
	BmpIH.biBitCount = 0x18; // 24bit
	BmpIH.biCompression = BI_RGB;
	BmpIH.biSizeImage = bmp_size;


	if( color_palette == NULL ){
		fwrite(&BmpFH, fhs, (size_t)1, outfile);
		fwrite(&BmpIH, ihs, 1, outfile );
			// �p���b�g���Ȃ��ꍇ(24bit)�͂��̂܂܏�������
	}
	else {	// �p���b�g���L��ꍇ(256)�̓w�b�_�������ύX
		BmpFH.bfSize += 4*256;
		BmpFH.bfOffBits += 4*256;
			// �p���b�g�̃T�C�Y���S
		fwrite(&BmpFH, fhs, (size_t)1, outfile);

		BmpIH.biBitCount = 8;	// 8bit = 256�F;
		BmpIH.biClrImportant = 256;
		BmpIH.biClrUsed = 256;
		fwrite( &BmpIH, ihs, 1, outfile );

		png_byte nl = 0;
		for( int i=0; i<=255; ++i ){
				// png_color�\���̂́ARGB�̏��Ɋm�ۂ���Ă��邩��A����ւ���K�v����
			fwrite( &color_palette[i].blue, 1, 1, outfile );
			fwrite( &color_palette[i].green, 1, 1, outfile );
			fwrite( &color_palette[i].red, 1, 1, outfile );
			fwrite( &nl, 1, 1, outfile );
		}
	}

	for( int j=g_height-1; j>=0; --j ){
		fwrite( row_pointers[j], width*g_bsize, 1, outfile);
	}	//	�C���[�W�̏�������

	fclose(outfile);
	return 0;
}

/*
int main(int argc, char* argv[]){
	if( argc == 2 ){
		char out[255] = "";
		strcpy( out, argv[1] );

		char *ext = strrchr(out, '.');
		if( ext ){
			strcpy( ext, ".bmp" );
			PngConvert(argv[1], out);
		}
	}

	if( argc == 3 ){
		PngConvert(argv[1], argv[2]);
	}
	return 0;
}
*/