#ifndef _PNG_READER_H_
#define _PNG_READER_H_

#define PNGLIB_HEADER	"../libpng/png.h"
#define PNGLIB_LIBPNG	"../libpng/Release/libpng.lib"
#define PNGLIB_ZLIB 	"../zlib/Release/zlib.lib"

#include PNGLIB_HEADER

#pragma comment(lib, PNGLIB_LIBPNG)
#pragma comment(lib, PNGLIB_ZLIB)

#define PNG_BYTES_TO_CHECK 4

int SavePng2Bmp(const char*);
int PngConvert(const char*, const char*);

#endif // _PNG_READER_H_
