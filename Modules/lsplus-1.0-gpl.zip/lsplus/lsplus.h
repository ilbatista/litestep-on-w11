/****************************************************************
This sourcecode is part of:
LSPlus.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)

The program mentioned above is copyrighted freeware
for any noncommercial use or distribution.

The text you are reading now must be included with the program
when distributing.

The copyright holder retains all rights and copyright to all his
works in this program.

You can use it freely for your own personal use, and can
distribute it to anyone as long as the original file remains
intact, including this text. However, you cannot put any part
of this program onto web pages, BBSs, CD-ROMs, books, magazines
or other media without my written permission.

This program may not be altered for redistribution without
my written permission.

The program is provided "as is", without warranty of any kind,
express or implied, including but not limited to warranties of
merchantability, fitness for a particular purpose and
non-infringement. In no event shall I, the author and copyright
holder be liable, whether in action of contract, tort or otherwise,
arising from, out of or in connection with the program or the use
or other dealings in the software.

Mike Edward Moras
e-sushi@gmx.net

This sourcecode is part of:
LSPlus.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/

#define WIN32_LEAN_AND_MEAN

#include "../current/lsapi/lsapi.h"
#include <shellapi.h>
#include <stdlib.h>
#include "io.h"
#include "stdio.h"
#include "mmsystem.h"
#include "png_reader.h"


void bangTHEME(HWND caller, LPCSTR args);
void bangWALL(HWND caller, LPCSTR args);
void bangWINDOWS(HWND caller, LPCSTR args);
void bangFILE(HWND caller, LPCSTR args);
void bangPLAYWAV(HWND caller, LPCSTR args);
void bangCLEAN(HWND caller, LPCSTR args);
void bangCRYPT(HWND caller, LPCSTR args);
void bangWAIT(HWND caller, LPCSTR args);
void bangABOUTLSPLUS(HWND caller, LPCSTR args);

void QuickSort (char** szArray, int nLower, int nUpper);
int Partition (char** szArray, int nLower, int nUpper);



extern "C" {
    __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
    __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

/****************************************************************
This sourcecode is part of:
LSPlus.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/