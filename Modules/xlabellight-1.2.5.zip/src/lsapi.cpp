//---------------------------------------------------------------------------
// LSAPI Function Stubs for Building lsapi.lib
//---------------------------------------------------------------------------

#include <windows.h>
#include "Litestep.h"

BOOL AddBangCommand(LPCSTR pszBangCommand, PFNBANGCOMMAND pfnCallback)
{
	return FALSE;
}

BOOL AddBangCommandEx(LPCSTR pszBangCommand, PFNBANGCOMMANDEX pfnCallback)
{
	return FALSE;
}

HRGN BitmapToRegion(HBITMAP hbmBitmap, COLORREF crTransparent, COLORREF crTolerance, int xOffset, int yOffset)
{
	return NULL;
}

int CommandTokenize(LPCSTR pszInput, LPSTR *ppszBuffers, UINT cBuffers, LPSTR pszExtraBuffer)
{
	return 0;
}

HWND GetLitestepWnd()
{
	return NULL;
}

void GetLSBitmapSize(HBITMAP hbmBitmap, int *pnWidth, int *pnHeight)
{

}

BOOL GetRCBool(LPCSTR pszKey, BOOL fIfFound)
{
	return FALSE;
}

BOOL GetRCBoolDef(LPCSTR pszKey, BOOL fDefault)
{
	return FALSE;
}

COLORREF GetRCColor(LPCSTR pszKey, COLORREF crDefault)
{
	return 0;
}

int GetRCCoordinate(LPCSTR pszKey, int nDefault, int nMax)
{
	return 0;
}

int GetRCInt(LPCSTR pszKey, int nDefault)
{
	return 0;
}

BOOL GetRCLine(LPCSTR pszKey, LPSTR pszBuffer, UINT cbBuffer, LPCSTR pszDefault)
{
	return FALSE;
}

BOOL GetRCString(LPCSTR pszKey, LPSTR pszBuffer, LPCSTR pszDefault, UINT cbBuffer)
{
	return FALSE;
}

BOOL GetToken(LPCSTR pszInput, LPSTR pszBuffer, LPCSTR *ppszNextToken, BOOL fUseBrackets)
{
	return FALSE;
}

BOOL LCClose(LPVOID pvHandle)
{
	return FALSE;
}

LPVOID LCOpen(LPCSTR pszFile)
{
	return NULL;
}

BOOL LCReadNextCommand(LPVOID pvHandle, LPSTR pszBuffer, UINT cbBuffer)
{
	return FALSE;
}

BOOL LCReadNextConfig(LPVOID pvHandle, LPCSTR pszPrefix, LPSTR pszBuffer, UINT cbBuffer)
{
	return FALSE;
}

BOOL LCReadNextLine(LPVOID pvHandle, LPSTR pszBuffer, UINT cbBuffer)
{
	return FALSE;
}

int LCTokenize(LPCSTR pszInput, LPSTR *ppszBuffers, UINT cBuffers, LPSTR pszExtraBuffer)
{
	return 0;
}

HBITMAP LoadLSImage(LPCSTR pszFile, LPCSTR pszReserved)
{
	return NULL;
}

HINSTANCE LSExecute(HWND hwndOwner, LPCSTR pszFile, int nCmdShow)
{
	return NULL;
}

HINSTANCE LSExecuteEx(HWND hwndOwner, LPCSTR pszOperation, LPCSTR pszFile, LPCSTR pszArgs, LPCSTR pszDirectory, int nCmdShow)
{
	return NULL;
}

BOOL LSGetVariable(LPCSTR pszVariable, LPSTR pszBuffer)
{
	return FALSE;
}

BOOL LSGetVariableEx(LPCSTR pszVariable, LPSTR pszBuffer, UINT cbBuffer)
{
	return FALSE;
}

BOOL WINAPI LSLog(int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	return FALSE;
}

BOOL WINAPIV LSLogPrintf(int nLevel, LPCSTR pszModule, LPCSTR pszFormat, ...)
{
	return FALSE;
}

void LSSetVariable(LPCSTR pszVariable, LPCSTR pszValue)
{

}

BOOL ParseBangCommand(HWND hwndCaller, LPCSTR pszBangCommand, LPCSTR pszArgs)
{
	return FALSE;
}

BOOL RemoveBangCommand(LPCSTR pszBangCommand)
{
	return FALSE;
}

void TransparentBltLS(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, COLORREF crTransparent)
{

}

void VarExpansion(LPSTR pszBuffer, LPCSTR pszInput)
{

}

void VarExpansionEx(LPSTR pszBuffer, LPCSTR pszInput, UINT cbBuffer)
{

}
