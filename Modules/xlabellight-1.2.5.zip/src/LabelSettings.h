#if !defined(__LABELSETTINGS_H)
#define __LABELSETTINGS_H

class LabelSettings
{
private:

	bool isDefault;

public:

	LabelSettings();
	LabelSettings(const char *name);
	virtual ~LabelSettings();

	bool alwaysOnTop;
	bool startHidden;
	bool bUseFahrenheit;

	Texture *skin;
	Font *font;

	int leftBorder;
	int topBorder;
	int rightBorder;
	int bottomBorder;

	int align;
	int vertAlign;
	int updateInterval;
	bool alwaysUpdateContent;

	int width;
	int height;
	int x;
	int y;

	int scrollInterval;
	int scrollSpeed;
	int scrollPadLength;
	int scroll;
	
	int autoWidthMode;
	int autoHeightMode;
	int autoMaxWidth;
	int autoMaxHeight;

	int transparencyMode;
	int alphaTransparency;
	bool alphaFade;
	bool ghosted;

	string text;
	string tooltip;

	bool lineBreak;

	string leftClickCommand;
	string leftDoubleClickCommand;
	string middleClickCommand;
	string middleDoubleClickCommand;
	string rightClickCommand;
	string rightDoubleClickCommand;
	string wheelDownCommand;
	string wheelUpCommand;
	string enterCommand;
	string leaveCommand;
	string dropCommand;
	string textChangeCommand;
	string resizeCommand;

    bool moveable;
	int moveKey;
	int moveButton;

	StringList labelLeftClickRegions;
	StringList labelRightClickRegions;
	StringList labelMiddleClickRegions;

	string enterleaveRegion;

	string labelGroup;

	//Animations
	int imageLoop;
	int imageFrameDelay;
	int imageFrameCount;
	int hoverimageLoop;
	int hoverimageFrameDelay;
	int hoverimageFrameCount;

	int overblendStyle;
};

extern LabelSettings* defaultSettings;

#endif
