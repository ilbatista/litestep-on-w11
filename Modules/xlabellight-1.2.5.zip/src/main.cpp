#include "common.h"
#include "Label.h"
#include "SystemInfo.h"
#include "LabelSettings.h"
#include "Font.h"

#include "Texture.h"
#include "Font.h"

#define _MERGE_RDATA_
#include "AggressiveOptimize.h"

// Bang commands
void BangAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs);
void BangClipboardCopy(HWND hwndCaller, LPCSTR pszArgs);
void BangClipboardPaste(HWND hwndCaller, LPCSTR pszArgs);
void BangCreate(HWND hwndCaller, LPCSTR pszArgs);
void BangDebug(HWND hwndCaller, LPCSTR pszArgs);
void BangDestroy(HWND hwndCaller, LPCSTR pszArgs);
void BangHide(HWND hwndCaller, LPCSTR pszArgs);
void BangLSBoxHook(HWND hwndCaller, LPCSTR pszArgs);
void BangMove(HWND hwndCaller, LPCSTR pszArgs);
void BangNext(HWND hwndCaller, LPCSTR pszArgs);
void BangPinToDesktop(HWND hwndCaller, LPCSTR pszArgs);
void BangPrevious(HWND hwndCaller, LPCSTR pszArgs);
void BangRefresh(HWND hwndCaller, LPCSTR pszArgs);
void BangReposition(HWND hwndCaller, LPCSTR pszArgs);
void BangResize(HWND hwndCaller, LPCSTR pszArgs);
void BangScroll(HWND hwndCaller, LPCSTR pszArgs);
void BangSetFontColor(HWND hwndCaller, LPCSTR pszArgs);
void BangSetFontShadowColor(HWND hwndCaller, LPCSTR pszArgs);
void BangSetText(HWND hwndCaller, LPCSTR pszArgs);
void BangShow(HWND hwndCaller, LPCSTR pszArgs);
void BangShowHide(HWND hwndCaller, LPCSTR pszArgs);
void BangToggleAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs);
void BangToggle(HWND hwndCaller, LPCSTR pszArgs);
void BangUpdate(HWND hwndCaller, LPCSTR pszArgs);
void BangSetAlpha(HWND hwndCaller, LPCSTR pszArgs);
void BangToggleGhosted(HWND hwndCaller, LPCSTR pszArgs);

void BangAdjustWidth(HWND hwndCaller, LPCSTR pszArgs);
void BangAdjustHeight(HWND hwndCaller, LPCSTR pszArgs);

void BangmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs);
void BangPosmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs);
void BangSizemzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs);

void BangSetAnimation(HWND hwndCaller, LPCSTR pszArgs);

void BangShrink(HWND hwndCaller, LPCSTR pszArgs);
void BangGrow(HWND hwndCaller, LPCSTR pszArgs);
void BangMoveBy(HWND hwndCaller, LPCSTR pszArgs);

void BangParseEvars(HWND hwndCaller, LPCSTR pszArgs);
void BangSetEvars(HWND hwndCaller, LPCSTR pszArgs);

//LPCTSTR szLogName = "xLabel";

//LSLog(LOG_NOTICE, szLogName, "Message");
//LSLog(LOG_DEBUG, szLogName, "Message");
//LSLog(LOG_WARNING, szLogName, "Message");
//LSLog(LOG_ERROR, szLogName, "Message");
//LSLogPrintf(LOG_DEBUG, szLogName, "Hidden icons (%d):", hiddenIcons.size());

HINSTANCE hInstance;
HWND messageHandler;

LabelList labelList;

int lsMessages[] = {
	LM_GETREVID,
	LM_REFRESH,
	0
};

#define LM_UPDATEBG (WM_USER + 1)

Label *lookupLabel( const string &name );

LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case LM_GETREVID:
		{
			UINT uLength;
			StringCchPrintf((char*)lParam, 64, "%s %s", V_NAME, V_VERSION);
			
			if (SUCCEEDED(StringCchLength((char*)lParam, 64, &uLength)))
				return uLength;

			lParam = NULL;
			return 0;
		}
		
		case LM_REFRESH:
		{
			StringList labelNames = GetRCNameList("*Label");

			// refresh the "AllLabels" configuration
			delete defaultSettings;
			defaultSettings = new LabelSettings();

			for(LabelListIterator iter = labelList.begin(); iter != labelList.end(); iter++)
			{
				if(!(*iter)->getBox())
				{
					// destroy all labels that no longer exist and that are not in a box
					for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
					{
						if(stricmp((*it).c_str(), (*iter)->getName().c_str()) == 0)
							break;
					}
					if (it == labelNames.end())
					{
						labelList.remove(*iter);
						delete *iter;
						continue;
					}
				}

				// we can reconfigure all other labels, even if they are "boxed"
				(*iter)->reconfigure();
				(*iter)->repaint(true);
			}

			// create the rest
			for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
			{
				Label *label = lookupLabel(*it);
				
				if (!label) 
				{
					label = new Label(*it);

					label->load(hInstance);
				
					labelList.insert(labelList.end(), label);
				}
			}
			return 0;
		}

		case LM_UPDATEBG:
		{
			PaintDesktopEx(0, 0, 0, 0, 0, 0, 0, TRUE);

			LabelListIterator i;
			for(i = labelList.begin(); i != labelList.end(); i++)
			{
				Label *label = *i;

				if(label->getBox() == 0)
					label->repaint(true);
			}

			return 0;
		}

		case WM_DISPLAYCHANGE:

		case WM_SETTINGCHANGE:
		{
			PostMessage(hWnd, LM_UPDATEBG, 0, 0);
			return 0;
		}
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	WNDCLASSEX wc;

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS | CS_DBLCLKS;
	wc.lpfnWndProc = Label::windowProcedure;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = sizeof(Label *);
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = LoadCursor(0, IDC_ARROW);
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "xLabel";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = MessageHandlerProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = 0;
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "xLabelMessageHandler";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	messageHandler = CreateWindowEx(WS_EX_TOOLWINDOW,
		"xLabelMessageHandler",
		0,
		WS_POPUP,
		0, 0, 0, 0, 
		0,
		0,
		hInstance,
		0);

	if (!messageHandler)
		return 1;
	
	SendMessage(GetLitestepWnd(),
		LM_REGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	::hInstance = hInstance;

	defaultSettings = new LabelSettings();
	systemInfo = new SystemInfo();

	StringList labelNames = GetRCNameList("*Label");

	for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
	{
		Label *label = new Label(*it);
	
		labelList.insert(labelList.end(), label);
		
		label->load(hInstance);
	}

	AddBangCommand("!LabelAlwaysOnTop", BangAlwaysOnTop);
	AddBangCommand("!LabelClipboardCopy", BangClipboardCopy);
	AddBangCommand("!LabelClipboardPaste", BangClipboardPaste);
	AddBangCommand("!LabelCreate", BangCreate);
	AddBangCommand("!LabelDebug", BangDebug);
	AddBangCommand("!LabelDestroy", BangDestroy);
	AddBangCommand("!LabelHide", BangHide);
	AddBangCommand("!LabelLSBoxHook", BangLSBoxHook);
	AddBangCommand("!LabelMove", BangMove);
	AddBangCommand("!LabelNext", BangNext);
	AddBangCommand("!LabelPinToDesktop", BangPinToDesktop);
	AddBangCommand("!LabelPrevious", BangPrevious);
	AddBangCommand("!LabelRefresh", BangRefresh);
	AddBangCommand("!LabelReposition", BangReposition);
	AddBangCommand("!LabelResize", BangResize);
	AddBangCommand("!LabelScroll", BangScroll);
	AddBangCommand("!LabelSetFontColor", BangSetFontColor);
	AddBangCommand("!LabelSetFontShadowColor", BangSetFontShadowColor);
	AddBangCommand("!LabelSetText", BangSetText);
	AddBangCommand("!LabelShow", BangShow);
	AddBangCommand("!LabelShowHide", BangShowHide);
	AddBangCommand("!LabelToggleAlwaysOnTop", BangToggleAlwaysOnTop);
	AddBangCommand("!LabelToggle", BangToggle);
	AddBangCommand("!LabelUpdate", BangUpdate);
	if(IsOS(OS_2KXP))
		AddBangCommand("!LabelSetAlpha", BangSetAlpha);
	AddBangCommand("!LabelToggleGhosted", BangToggleGhosted);

	AddBangCommand("!LabelAutoWidth", BangAdjustWidth);
	AddBangCommand("!LabelAutoHeight", BangAdjustHeight);

	AddBangCommand("!LabelmzscriptVarCopy", BangmzscriptVarCopy);
	AddBangCommand("!LabelPosmzscriptVarCopy", BangPosmzscriptVarCopy);
	AddBangCommand("!LabelSizemzscriptVarCopy", BangSizemzscriptVarCopy);

	AddBangCommand("!LabelSetAnimation", BangSetAnimation);

	AddBangCommand("!LabelShrink", BangShrink);
	AddBangCommand("!LabelGrow", BangGrow);
	AddBangCommand("!LabelMoveBy", BangMoveBy);

	AddBangCommand("!ParseEvars", BangParseEvars);
	AddBangCommand("!SetEvar", BangSetEvars);

	//OnResize one time after all are loaded
	for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
	{
		if( !(*i)->resizeCommand.empty() )
			LSExecute(NULL, (*i)->resizeCommand.c_str(), SW_SHOWNORMAL);
	}

	return 0;
}

extern HDC hdcDesktop;
extern HBITMAP hbmDesktop;

void quitModule(HINSTANCE hInstance)
{
	RemoveBangCommand("!LabelAlwaysOnTop");
	RemoveBangCommand("!LabelClipboardCopy");
	RemoveBangCommand("!LabelClipboardPaste");
	RemoveBangCommand("!LabelCreate");
	RemoveBangCommand("!LabelDebug");
	RemoveBangCommand("!LabelDestroy");
	RemoveBangCommand("!LabelHide");
	RemoveBangCommand("!LabelLSBoxHook");
	RemoveBangCommand("!LabelMove");
	RemoveBangCommand("!LabelNext");
	RemoveBangCommand("!LabelPinToDesktop");
	RemoveBangCommand("!LabelPrevious");
	RemoveBangCommand("!LabelRefresh");
	RemoveBangCommand("!LabelReposition");
	RemoveBangCommand("!LabelResize");
	RemoveBangCommand("!LabelScroll");
	RemoveBangCommand("!LabelSetFontColor");
	RemoveBangCommand("!LabelSetFontShadowColor");
	RemoveBangCommand("!LabelSetText");
	RemoveBangCommand("!LabelShow");
	RemoveBangCommand("!LabelShowHide");
	RemoveBangCommand("!LabelToggleAlwaysOnTop");
	RemoveBangCommand("!LabelToggle");
	RemoveBangCommand("!LabelUpdate");
	if(IsOS(OS_2KXP))
		RemoveBangCommand("!LabelSetAlpha");
	RemoveBangCommand("!LabelToggleGhosted");

	RemoveBangCommand("!LabelAutoWidth");
	RemoveBangCommand("!LabelAutoHeight");

	RemoveBangCommand("!LabelmzscriptVarCopy");
	RemoveBangCommand("!LabelPosmzscriptVarCopy");
	RemoveBangCommand("!LabelSizemzscriptVarCopy");

	RemoveBangCommand("!LabelSetAnimation");

	RemoveBangCommand("!LabelShrink");
	RemoveBangCommand("!LabelGrow");
	RemoveBangCommand("!LabelMoveBy");

	RemoveBangCommand("!ParseEvars");
	RemoveBangCommand("!SetEvar");

	for(LabelListIterator it = labelList.begin(); it != labelList.end(); it++)
		delete *it;

	labelList.clear();
	
	SendMessage(GetLitestepWnd(),
		LM_UNREGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	DestroyWindow(messageHandler);

	UnregisterClass("xLabel", hInstance);
	UnregisterClass("xLabelMessageHandler", hInstance);

	delete systemInfo;
	delete defaultSettings;

	hbmDesktop = (HBITMAP) SelectObject(hdcDesktop, hbmDesktop);
	DeleteDC(hdcDesktop);
	DeleteObject(hbmDesktop);
}

Label *lookupLabel(const string &name)
{
	LabelListIterator it;

	for(it = labelList.begin(); it != labelList.end(); it++)
	{
		if(stricmp(name.c_str(), (*it)->getName().c_str()) == 0)
			return *it;
	}

	//LSLogPrintf(LOG_WARNING, szLogName, "Label \"%s\" not found!\nCheck Bang Command.", name.c_str());
	return 0;
}

BOOL APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	if(dwReason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hInstance);
	}

	return TRUE;
}

// !Labelmzscriptvarcopy <label> <mzscript var>
void BangmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], var[64];
	char *buffers[] = {name, var};

	if(LCTokenize(pszArgs, buffers, 2, NULL) == 2)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->mzscriptvarcopy(var);
	}
}

// !LabelPosmzscriptvarcopy <label> <mzscript var xpos> <mzscript var ypos>
void BangPosmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], varx[64], vary[64];
	char *buffers[] = {name, varx, vary};

	if(LCTokenize(pszArgs, buffers, 3, NULL) == 3)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->posmzscriptvarcopy(varx, vary);
	}
}

// !LabelSizemzscriptvarcopy <label> <mzscript var cx> <mzscript var cy>
void BangSizemzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], varcx[64], varcy[64];
	char *buffers[] = {name, varcx, varcy};

	if(LCTokenize(pszArgs, buffers, 3, NULL) == 3)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->sizemzscriptvarcopy(varcx, varcy);
	}
}

// !LabelSetAnimation <label> <on | off> [<loops>]
void BangSetAnimation(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], option[16], loops[16];
	char *buffers[] = {name, option, loops};

	int numTokens = LCTokenize(pszArgs, buffers, 3, NULL);
	if (numTokens >= 2)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			if (numTokens == 2)
			{
				if(stricmp(option, "off") == 0)
					label->setAnimation(false);
				else if(stricmp(option, "on") == 0)
					label->setAnimation(true);
			}
			else if  (numTokens == 3)
			{
				if(stricmp(option, "off") == 0)
					label->setAnimation(false);
				else if(stricmp(option, "on") == 0)
					label->setAnimation(true, atoi(loops));
			}
		}
	}
}

// !LabelAlwaysOnTop <label>
void BangAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->setAlwaysOnTop(true);
	else
	{
		for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setAlwaysOnTop(true);
		}
	}
}

// !LabelClipboardCopy <label> <prefix>
void BangClipboardCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], prefix[256];
	char *buffers[] = {name, prefix};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->clipboardCopy((numTokens >= 2) ? prefix : "");
	}
}

// !LabelClipboardPaste <label> <prefix>
void BangClipboardPaste(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], prefix[256];
	char *buffers[] = {name, prefix};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->clipboardPaste((numTokens >= 2) ? prefix : "");
	}
}

// !LabelCreate <label>
void BangCreate(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = new Label(pszArgs);
	labelList.insert(labelList.end(), label);
	label->load(hInstance);
}

// !LabelDebug
void BangDebug(HWND hwndCaller, LPCSTR pszArgs)
{
	string message = "Normal Labels: (*label)\r\n";

	for(LabelListIterator it = labelList.begin(); it != labelList.end(); it++)
	{
		message.append((*it)->getName());
		message.append(", ");
	}

	MessageBox(NULL, message.c_str(), "xLabel Debug Informations", MB_SETFOREGROUND);
}

// !LabelDestroy <label>
void BangDestroy(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
	{
		labelList.remove(label);
		delete label;
	}
}

// !LabelHide <label>
void BangHide(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->hide();
	else
	{
		for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->hide();
		}
	}
}

// !LabelLSBoxHook <labelname>
void BangLSBoxHook(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64];
	char *buffers[] = {name};

	if(LCTokenize(pszArgs, buffers, 1, 0) == 1)
	{
		const char *handle = strrchr(pszArgs,' ');
	    HWND hwndBox = (HWND)atoi(handle+1);

		Label *label = lookupLabel(name);

		if(label)
		{
			label->setBox(hwndBox);
			label->update();
		}
		else
		{
			label = new Label(name);
			labelList.insert(labelList.end(), label);
			label->load(hInstance, hwndBox);
		}
	}
}

// !LabelMove <label> <x> <y> [<steps> <time>]
void BangMove(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16];
	char *buffers[] = {name, A, B, C, D};

	if(LCTokenize(pszArgs, buffers, 5, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int x = ParseCoord(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int y = ParseCoord(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int step = atoi( C );
			int time = atoi( D );

			label->move(x, y, step, time);
		}
	}
}

// !LabelMoveBy <label> <x> <y>
void BangMoveBy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16];
	char *buffers[] = {name, A, B};

	if(LCTokenize(pszArgs, buffers, 3, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int x = atoi( A );
			int y = atoi( B );

			label->move(x, y, 0, 0, true);
		}
	}
}

// !LabelNext <label>
void BangNext(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->next();
}

// !LabelPinToDesktop <label>
void BangPinToDesktop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->setAlwaysOnTop(false);
	else
	{
		LabelListIterator i;
		for( i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setAlwaysOnTop(false);
		}
	}
}

// !LabelPrevious <label>
void BangPrevious(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->previous();
}

// !LabelRefresh <label>
void BangRefresh(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);

	if(label)
		label->reconfigure();
	else
	{
		for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->reconfigure();
		}
	}
}

// !LabelReposition <label> <x> <y> <width> <height> [<steps>] [<time>]
void BangReposition(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16], E[16], F[16];
	char *buffers[] = {name, A, B, C, D, E, F};

	if(LCTokenize(pszArgs, buffers, 7, NULL) >= 5)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int x = ParseCoord(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int y = ParseCoord(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int w = ParseDimen(C, 0, GetSystemMetrics(SM_CXSCREEN));
			int h = ParseDimen(D, 0, GetSystemMetrics(SM_CYSCREEN));
			int step = atoi( E );
			int time = atoi( F );

			label->reposition(x, y, w, h, step, time);
		}
	}
}

// !LabelResize <label> <width> <height> [<steps> <time>]
void BangResize(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16];
	char *buffers[] = {name, A, B, C, D};

	if(LCTokenize(pszArgs, buffers, 5, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int w = ParseDimen(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int h = ParseDimen(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int step = atoi( C );
			int time = atoi( D );

			label->resize(w, h, step, time);
		}
	}
}

// !LabelShrink <label> <cx> <cy>
void BangShrink(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16];
	char *buffers[] = {name, A, B};

	if(LCTokenize(pszArgs, buffers, 3, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int cx = atoi( A );
			int cy = atoi( B );

			label->resize(cx, cy, 0, 0, -1);
		}
	}
}

// !LabelGrow <label> <cx> <cy>
void BangGrow(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16];
	char *buffers[] = {name, A, B};

	if(LCTokenize(pszArgs, buffers, 3, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int cx = atoi( A );
			int cy = atoi( B );

			label->resize(cx, cy, 0, 0, 1);
		}
	}
}

// !LabelScroll <label> <'on', 'off', 'toggle', 'freeze', limit> <scrollMode(1-4)>
void BangScroll(HWND hwndCaller, LPCSTR pszArgs)
{
	// FIXME: This should be split into multiple bang commands
	char name[64], option[16], mode[16];
	char *buffers[] = {name, option, mode};

	if(LCTokenize(pszArgs, buffers, 3, NULL) >= 2)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			if(stricmp(option, "off") == 0)
				label->setScrolling(0);
			else if(stricmp(option, "on") == 0)
			{
				int scrollmode = atoi(mode);
				if (scrollmode > 0 && scrollmode <= 4)
					label->setScrolling(scrollmode);
				else
					label->setScrolling(label->scrollBackup);
			}
			else if(stricmp(option, "toggle") == 0)
			{
				if (label->getScrolling() > 0)
					label->setScrolling(0);
				else
				{
					int scrollmode = atoi(mode);
					if (scrollmode > 0 && scrollmode <= 4)
						label->setScrolling(scrollmode);
					else
						label->setScrolling(label->scrollBackup);
				}
			}
			else if(stricmp(option, "freeze") == 0)
			{
				if (label->frozen)
					label->frozen = false;
				else
					label->frozen = true;
			}
			else
			{
				int limit = atoi(option);
				if(limit >= 0) label->setScrollLimit(limit);
			}
		}
	}
}

// !LabelSetFontColor <label> <red> <green> <blue> OR !LabelSetFontColor <label> <hexcolor>
void BangSetFontColor(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16];
	char *buffers[] = {name, A, B, C};
	int numTokens = LCTokenize(pszArgs, buffers, 4, NULL);
	int color;

	if(numTokens >= 2)
	{
		Label *label = lookupLabel(name);

		if (label)
		{
			if(numTokens >= 4)
			{
				int r = atoi(A);
				int g = atoi(B);
				int b = atoi(C);

				color = RGB(r, g, b);
			}
			else
			{
				color = strtol(A, NULL, 16);
				color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
			}

			label->getFont()->setColor(color);
			label->repaint();
		}
		else
		{
			for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
			{			
				if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
				{
					if(numTokens >= 4)
					{
						int r = atoi(A);
						int g = atoi(B);
						int b = atoi(C);

						color = RGB(r, g, b);
					}
					else
					{
						color = strtol(A, NULL, 16);
						color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
					}

					(*i)->getFont()->setColor(color);
					(*i)->repaint();
				}
			}
		}
	}
}

// !LabelSetFontShadowColor <label> <red> <green> <blue> OR !LabelSetFontColor <label> <hexcolor>
void BangSetFontShadowColor(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16];
	char *buffers[] = {name, A, B, C};
	int numTokens = LCTokenize(pszArgs, buffers, 4, NULL);
	int color;

	if (numTokens == 1)
	{
		Label *label = lookupLabel(name);

		if (label)
		{
			label->getFont()->setShadow(false);
			label->repaint();
		}
		else
		{
			for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
				{
					(*i)->getFont()->setShadow(false);
					(*i)->repaint();
				}
			}
		}
	}
	else if(numTokens >= 2)
	{
		Label *label = lookupLabel(name);

		if (label)
		{
			if(numTokens >= 4)
			{
				int r = atoi(A);
				int g = atoi(B);
				int b = atoi(C);

				color = RGB(r, g, b);
			}
			else
			{
				color = strtol(A, NULL, 16);
				color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
			}

			label->getFont()->setColor(color, true);
			label->getFont()->setShadow(true);
			label->repaint();
		}
		else
		{
			for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
				{
					if(numTokens >= 4)
					{
						int r = atoi(A);
						int g = atoi(B);
						int b = atoi(C);

						color = RGB(r, g, b);
					}
					else
					{
						color = strtol(A, NULL, 16);
						color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
					}

					(*i)->getFont()->setColor(color, true);
					(*i)->getFont()->setShadow(true);
					(*i)->repaint();
				}
			}
		}
	}
}

// !LabelSetText <label> <text>
void BangSetText(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], text[1024];
	char *buffers[] = {name, text};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->setText((numTokens >= 2) ? text : "");
	}
}

// !LabelShow <label>
void BangShow(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->show();
	else
	{
		for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->show();
		}
	}
}

// !LabelShowHide <label> <timeout>
void BangShowHide(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[64];
	char *buffers[] = {name, A};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 2)
	{
		int timeout = atof(A);

		Label *label = lookupLabel(name);

		if(label)
			label->showHide(timeout);
		else
		{
			for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
					(*i)->showHide(timeout);
			}
		}
	}
}

// !LabelToggleAlwaysOnTop <label>
void BangToggleAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->setAlwaysOnTop(!label->isAlwaysOnTop());
	else
	{
		for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setAlwaysOnTop(!(*i)->isAlwaysOnTop());
		}
	}
}

// !LabelToggle <label>
void BangToggle(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
	{
		if(label->isVisible())
			label->hide();
		else
			label->show();
	}
	else
	{
		for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
			{
				if((*i)->isVisible())
					(*i)->hide();
				else
					(*i)->show();
			}
		}
	}
}

// !LabelUpdate <label>
void BangUpdate(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);

	if(label)
		label->update();
	else
	{
		for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->update();
		}
	}
}

// !LabelSetAlpha <label> <value>
void BangSetAlpha(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], factor[16];
	char *buffers[] = {name, factor};

	if(LCTokenize(pszArgs, buffers, 2, NULL) == 2)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->setAlpha(atoi( factor ));
		else
		{
			for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
					(*i)->setAlpha(atoi( factor ));
			}
		}
	}
}

// !LabelToggleGhosted <label>
void BangToggleGhosted(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);

	if(label)
		label->setGhosted(!label->isGhosted());
	else
	{
		for(LabelListIterator i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setGhosted(!(*i)->isGhosted());
		}
	}
}

// !LabelAutoWidth <label> [<left|right|center|off>] //blank is off!!
void BangAdjustWidth(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], mode[32];
	char *buffers[] = {name, mode};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 1)
	{
		Label *label = lookupLabel(name);
		if(label)
		{
			if ( stricmp(mode, "left") == 0 )
				label->autoWidthMode = 1;
			else if ( stricmp(mode, "right") == 0 )
				label->autoWidthMode = 2;
			else if ( stricmp(mode, "center") == 0 || stricmp(mode, "centered") == 0)
				label->autoWidthMode = 3;
			else 
				label->autoWidthMode = 0;
			label->repaint();
		}
	}
}

// !LabelAutoHeight <label> [<top|bottom|center|off>] //blank is off!!
void BangAdjustHeight(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], mode[32];
	char *buffers[] = {name, mode};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 1)
	{
		Label *label = lookupLabel(name);
		if(label)
		{
			if ( stricmp(mode, "top") == 0 )
				label->autoHeightMode = 1;
			else if ( stricmp(mode, "bottom") == 0 )
				label->autoHeightMode = 2;
			else if ( stricmp(mode, "center") == 0 || stricmp(mode, "centered") == 0)
				label->autoHeightMode = 3;
			else 
				label->autoHeightMode = 0;
			label->repaint();
		}
	}
}

//Parse Current Evars In Bang
//!ParseEvars !anybang with evars escape code '%#'
void BangParseEvars(HWND hwndCaller, LPCSTR pszArgs)
{
	string result = pszArgs;
	while ( strstr(result.c_str(), "%#") != NULL )
		result.replace(result.find("%#"), 2, "$", 1);
	
	LSExecute(NULL, result.c_str(), SW_SHOWNORMAL);
}

//Set Evar
//!SetEvar "'$'evar'$'" "value"
void BangSetEvars(HWND hwndCaller, LPCSTR pszArgs)
{
	char evar[64], value[128];
	char *buffers[] = {evar, value};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 2)
		PrefixedLSSetVariable( (string)evar, "", (string)value );
}
