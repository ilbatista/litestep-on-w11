#include "common.h"
#include "Label.h"
#include "LabelSettings.h"
#include "Font.h"
#include "Texture.h"
#include "SystemInfo.h"

#include "ShowStyle.h"

#include <shellapi.h>
#include <shlobj.h>

#define TIMER_MOUSETRACK 1
#define TIMER_UPDATE 2
#define TIMER_SCROLL 3
#define TIMER_AUTOHIDE 4
#define TIMER_MOUSETRACK_MOVE 5
#define TIMER_ALPHAFADEIN 6
#define TIMER_ALPHAFADEOUT 7
#define TIMER_FRAMEANIMATION 8

extern LabelList labelList;

Label::Label(const string &name):actualheight(0),actualwidth(0),actualx(0),actualy(0)
{
	this->name = name;

	hWnd = 0;
	hInstance = 0;
	box = 0;

	background = 0;
	font = 0;

	backgroundDC = 0;
	bufferDC = 0;
	backgroundBitmap = 0;
	bufferBitmap = 0;

	hoverActive = false;
	pressedActive = false;

	useHover = false;
	usePressed = false;
	
	mousePressed = false;
	mouseInside = false;

	movemodifierkeyPressed = false;
	moveButtonPressed = 0;

	visible = false;

	bUsingDefSkin = false;

	originalText.push_back("");
	current = 0;

	textChange = false;
	newlineCounter = 1;

	autoWidthMode = 0;
	autoHeightMode = 0;

	scroll = 0;
	scrollBackup = 1;
	scrollLimit = 0;
	scrollPosition = 0;
	frozen = false;

	alphaEnabled = false;
	
	//Animations
	frameCounter = 0;
	loopCounter = -1;
	normalAnim = false;
	hoverAnim = false;

	paintInProgress = false;
	reallyOverBlend = false;

	transparencyNeeded = true;
}

Label::~Label()
{
	if (hWnd && TooltipHints)
	{
		removeHint(hWnd);
		DestroyWindow(TooltipHints);
	}

	if(IsWindow(hWnd))
	{
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
		KillTimer(hWnd, TIMER_MOUSETRACK);
		KillTimer(hWnd, TIMER_UPDATE);
		KillTimer(hWnd, TIMER_SCROLL);
		KillTimer(hWnd, TIMER_AUTOHIDE);
		KillTimer(hWnd, TIMER_ALPHAFADEIN);
		KillTimer(hWnd, TIMER_ALPHAFADEOUT);
		KillTimer(hWnd, TIMER_FRAMEANIMATION);

		DestroyWindow(hWnd);
	}

	if(backgroundBitmap)
	{
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
		DeleteObject(backgroundBitmap);
	}
	if (backgroundDC)
		DeleteDC(backgroundDC);

	if(bufferBitmap)
	{
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
		DeleteObject(bufferBitmap);
	}
	if (bufferDC)
		DeleteDC(bufferDC);

	if(!bUsingDefSkin)
		delete background;

	if(font != defaultSettings->font)
		delete font;
}

void Label::load(HINSTANCE hInstance, HWND box)
{
	this->hInstance = hInstance;
	
	if (IsWindow(box))
	{
		this->box = box;
	}
	else
	{
		this->box = NULL;
	}
	
	if (IsWindow(hWnd))	// window already exists...
		return;

	hWnd = CreateWindowEx(box ? 0 : WS_EX_TOOLWINDOW,
		"xLabel",
		name.c_str(),
		box ? WS_CHILD : WS_POPUP,
		actualx, actualy,		
		actualwidth, actualheight,
		box ? box : GetLitestepWnd(), 
		0,
		hInstance,
		this);
		
	if (hWnd)
	{
		SetWindowLong(hWnd, GWL_USERDATA, MAGIC_DWORD);

		//ToolTips for Labels
		if ( !(GetRCString(name.c_str(), "Tooltip", "")).empty() )
		{
			TooltipHints = CreateWindow(TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP,
										  CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
										  NULL, NULL, hInstance, NULL);
			if (TooltipHints)
				SetWindowPos(TooltipHints, HWND_TOPMOST, 0, 0, 0, 0,
							 SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
		}

		reconfigure();
		repaint();
		if (autoWidthMode != 0 || autoHeightMode != 0)
			autoSize();
	}
	else
		delete this;
}

void Label::reconfigure()
{
	LabelSettings settings(name.c_str());
	
	//Module Hook
	moduleHook = settings.moduleHook;

	//Normal Label = Type 0
	labelType = 0;

	//Transparency Settings
	transparencyMode = settings.transparencyMode;
	alphaTransparency = settings.alphaTransparency;
	if (alphaTransparency != 255 && box == NULL)
		alphaEnabled = true;
	alphaFade = settings.alphaFade;
	if (alphaFade && box == NULL)
		alphaEnabled = true;

	//Painting Background
	setBackground(settings.skin);	
	transparencyNeeded = background->isTransparencyNeeded();

	//AutoSize
	autoWidthMode = settings.autoWidthMode;
	autoHeightMode = settings.autoHeightMode;
	autoMinWidth = settings.width;
	autoMinHeight = settings.height;
	autoMaxWidth = settings.autoMaxWidth;
	autoMaxHeight = settings.autoMaxHeight;
	startCenterX = settings.x+(settings.width/2);
	startCenterY = settings.y+(settings.height/2);

	//Hover/Pressed Images
	if ( !(GetRCString(name.c_str(), "HoverImage", "")).empty() || !(GetRCString(name.c_str(), "HoverFrames", "")).empty())
		useHover = true;
	if ( !(GetRCString(name.c_str(), "PressedImage", "")).empty() )
		usePressed = true;

	//Animations
	overblendStyle = settings.overblendStyle;

	imageLoop = settings.imageLoop;
	imageFrameCount = settings.imageFrameCount;
	if (imageFrameCount != 0)
		normalAnim = true;
	imageFrameDelay = settings.imageFrameDelay;

	hoverimageLoop = settings.hoverimageLoop;
	hoverimageFrameCount = settings.hoverimageFrameCount;
	if (hoverimageFrameCount != 0)
		hoverAnim = true;
	hoverimageFrameDelay = settings.hoverimageFrameDelay;

	if (normalAnim)
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);

	//Painting Text
	setFont(settings.font);			
	setAlign(settings.align);
	setVertAlign(settings.vertAlign);
	lineBreak = settings.lineBreak;
	setLeftBorder(settings.leftBorder);
	setTopBorder(settings.topBorder);
	setRightBorder(settings.rightBorder);
	setBottomBorder(settings.bottomBorder);
	setText(settings.text);

	smooth = settings.smooth;
	
	//Scrolling
	scrollPadLength = settings.scrollPadLength;
	scrollInterval = settings.scrollInterval;
	scrollSpeed = settings.scrollSpeed;
	setScrolling(settings.scroll);

	//Updates
	alwaysUpdateContent = settings.alwaysUpdateContent;
	setUpdateInterval(settings.updateInterval);

	//Extra Settings
	labelGroup = settings.labelGroup;
	bUseFahrenheit = settings.bUseFahrenheit;

	tooltip = settings.tooltip;
	if (!tooltip.empty())
	{
		char tooltiptext[256];
		strcpy(tooltiptext, (systemInfo->processLabelText(tooltip, this, &dynamicText)).c_str());
		addHint(hWnd, tooltiptext);
		strcpy(oldtooltiptext, tooltiptext);
	}

	//Events/Actions
	leftClickCommand = settings.leftClickCommand;
	leftDoubleClickCommand = settings.leftDoubleClickCommand;
	middleClickCommand = settings.middleClickCommand;
	middleDoubleClickCommand = settings.middleDoubleClickCommand;
	rightClickCommand = settings.rightClickCommand;
	rightDoubleClickCommand = settings.rightDoubleClickCommand;
	wheelDownCommand = settings.wheelDownCommand;
	wheelUpCommand = settings.wheelUpCommand;
	enterCommand = settings.enterCommand;
	leaveCommand = settings.leaveCommand;
	dropCommand = settings.dropCommand;
	textChangeCommand = settings.textChangeCommand;
	resizeCommand = settings.resizeCommand;

	//Event Regions
	labelLeftClickRegions = settings.labelLeftClickRegions;
	labelRightClickRegions = settings.labelRightClickRegions;
	labelMiddleClickRegions = settings.labelMiddleClickRegions;

	focusOnEnter = settings.focusOnEnter;

	//Moving
	moveable = settings.moveable;
	moveKey = settings.moveKey;
	moveButton = settings.moveButton;
	
	//Initial Repositioning
	reposition(settings.x, settings.y, settings.width, settings.height);

	if (hWnd)
	{
		if(IsOS(OS_2KXP) && alphaEnabled)
		{
			ModifyStyleEx(hWnd, 0, WS_EX_LAYERED);
			if (alphaFade)
				UpdateWindowTransparent(hWnd, 0);
			else
				UpdateWindowTransparent(hWnd, alphaTransparency);
		}

		setGhosted(settings.ghosted);

		//File Actions
		if (dropCommand.empty())
			DragAcceptFiles(hWnd, false);
		else
			DragAcceptFiles(hWnd, true);

		//AlwaysOnTop
		setAlwaysOnTop(settings.alwaysOnTop);	

		//Initial Show
		settings.startHidden ? hide() : show();
	}

	//Update Region (Magic Pink)
	if (transparencyMode == 1)
		updateRegion();
}

//------------------------------------------------------------
//Copy "LabelText" in mzscript variable
//------------------------------------------------------------
void Label::mzscriptvarcopy(string var)
{
	string bang = ("!varset " + var + " \"" + text + "\"");
	LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
}

//------------------------------------------------------------
//Copy "LabelPosition" in mzscript variables
//Export $..currentwidth$, $..currentheight$
//------------------------------------------------------------
void Label::posmzscriptvarcopy(string varx, string vary, bool setmzscript)
{
	if (box)
		return;

	string bang;
	string posx, posy;

	RECT cr;
	GetWindowRect(hWnd, &cr);

	char buffer[32];
	sprintf(buffer, "%d", cr.left);
	posx = buffer;
	sprintf(buffer, "%d", cr.top);
	posy = buffer;

	if (setmzscript)
	{
		bang = ("!varset " + varx + " \"" + posx + "\"");
		LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);

		bang = ("!varset " + vary + " \"" + posy + "\"");
		LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
	}
		
	PrefixedLSSetVariable(name, "CurrentX", posx);
	PrefixedLSSetVariable(name, "CurrentY", posy);
}

//------------------------------------------------------------
//Copy "LabelSize" in mzscript variables
//Export $..currentwidth$, $..currentheight$
//------------------------------------------------------------
void Label::sizemzscriptvarcopy(string varcx, string varcy, bool setmzscript)
{
	if (box)
		return;

	string bang;
	string cx, cy;

	RECT cr;
	GetWindowRect(hWnd, &cr);

	char buffer[32];
	sprintf(buffer, "%d", cr.right-cr.left);
	cx = buffer;
	sprintf(buffer, "%d", cr.bottom-cr.top);
	cy = buffer;

	if (setmzscript)
	{
		bang = ("!varset " + varcx + " \"" + cx + "\"");
		LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);

		bang = ("!varset " + varcy + " \"" + cy + "\"");
		LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
	}

	PrefixedLSSetVariable(name, "CurrentWidth", cx);
	PrefixedLSSetVariable(name, "CurrentHeight", cy);
}

//------------------------------------------------------------
//Set Background
//------------------------------------------------------------
void Label::setBackground(Texture *background)
{
	if(!bUsingDefSkin)
		delete this->background;

	this->background = background;

	bUsingDefSkin = (background == defaultSettings->skin);
}

//------------------------------------------------------------
//Set Parent Box (nearly never needed/called!)
//------------------------------------------------------------
void Label::setBox(HWND newparent)
{
	if (box == newparent)
		return;

	ModifyStyleEx(hWnd, WS_EX_LAYERED, 0);

	if (alwaysOnTop)
		setAlwaysOnTop(FALSE);
	
	box = newparent;
	
	ModifyStyle(hWnd, WS_POPUP, WS_CHILD);
	SetParent(hWnd, newparent);
}

//------------------------------------------------------------
//"Modify Styles"
//------------------------------------------------------------
void Label::setAlwaysOnTop(bool alwaysOnTop)
{
	this->alwaysOnTop = alwaysOnTop;
	
	if (box)
		return;
	
	if(hWnd)
	{
		ModifyStyle(hWnd, WS_POPUP, WS_CHILD);
		SetParent(hWnd, alwaysOnTop ? 0 : GetLitestepDesktop());
		ModifyStyle(hWnd, WS_CHILD, WS_POPUP);
		
		SetWindowPos(hWnd, alwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
			0, 0, 0, 0,
			SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
	}
}

void Label::setAlpha(int factor)
{
	if (factor >= 0 && factor <= 255 && IsOS(OS_2KXP) && box == NULL)
	{
		if(!alphaEnabled)
		{
			alphaEnabled = true;
			ModifyStyleEx(hWnd, 0, WS_EX_LAYERED);
		}

		UpdateWindowTransparent(hWnd, factor);
		alphaTransparency = factor;
	}
}

void Label::setGhosted(bool ghosted)
{
	this->ghosted = ghosted;
	
	if (box)
		return;
	
	if(hWnd)
	{
		if (ghosted)
			ModifyStyleEx(hWnd, 0, WS_EX_TRANSPARENT);
		else
			ModifyStyleEx(hWnd, WS_EX_TRANSPARENT, 0);
	}
}

//------------------------------------------------------------
//Set Font
//------------------------------------------------------------
void Label::setFont(Font *font)
{
	if(this->font != defaultSettings->font)
		delete this->font;

	this->font = font;
}

//------------------------------------------------------------
//Set Text Settings
//------------------------------------------------------------
void Label::setText(const string &text)
{
	originalText = split(text, ";");
		
	current = 0;
	update();
}

void Label::previous()
{
	current--;
	if(current < 0) current = originalText.size() - 1;
	update();
}

void Label::next()
{
	current++;
	if(current >= originalText.size()) current = 0;
	update();
}

void Label::setAlign(int align)
{
	if (this->align == align)
		return;

	this->align = align;
}

void Label::setVertAlign(int vertAlign)
{
	if (this->vertAlign == vertAlign)
		return;

	this->vertAlign = vertAlign;
}

void Label::setLeftBorder(int leftBorder)
{
	if (this->leftBorder == leftBorder)
		return;

	this->leftBorder = leftBorder;
}

void Label::setTopBorder(int topBorder)
{
	if (this->topBorder == topBorder)
		return;

	this->topBorder = topBorder;
}

void Label::setRightBorder(int rightBorder)
{
	if (this->rightBorder == rightBorder)
		return;

	this->rightBorder = rightBorder;
}

void Label::setBottomBorder(int bottomBorder)
{
	if (this->bottomBorder == bottomBorder)
		return;

	this->bottomBorder = bottomBorder;
}

void Label::setScrolling(int scrolling)
{
	if (scrolling != 0 && scroll == 0)
	{
		scrollPosition = 0;
		SetTimer(hWnd, TIMER_SCROLL, scrollInterval, 0);
	}
	else if (scrolling == 0 && scroll != 0)
	{
		KillTimer(hWnd, TIMER_SCROLL);
		scrollPosition = 0;
		repaint();
	}

	scrollLimit = 0;
	scroll = scrolling;
	if (scrolling != 0)
		scrollBackup = scrolling;
}

void Label::setScrollLimit(int limit)
{
	if (limit >= 0)
	{
		setScrolling(scrollBackup);
		scrollLimit = limit + 1;
	}
	else
		setScrolling(0);
}

void Label::setUpdateInterval(int updateInterval)
{
	this->updateInterval = updateInterval;
	if(hWnd && (dynamicText || alwaysUpdateContent))
		SetTimer(hWnd, TIMER_UPDATE, updateInterval, 0);
}

void Label::update()
{
	bool dynamicTooltip = false;
	string oldText = text;

	//Tooltips
	if (!tooltip.empty() && TooltipHints)
	{
		char tooltiptext[256];
		strcpy(tooltiptext, (systemInfo->processLabelText(tooltip, this, &dynamicText)).c_str());
		if ( stricmp(tooltiptext, oldtooltiptext) != 0 )
		{
			updateHint(hWnd, tooltiptext);
			strcpy(oldtooltiptext, tooltiptext);
		}

		dynamicTooltip = dynamicText;
	}

	text = systemInfo->processLabelText(originalText[current], this, &dynamicText);
	
	//Start: Split in Multilines and check for longest line
	if(text != oldText)
	{
		vector<string> tmpLongest;
		int iter = 0;
		int longest = 0;
		string longestText;

		tmpLongest = split(text, "\n");
		longest = tmpLongest[iter].length();
		longestText = tmpLongest[iter];

		iter++;
		while (iter < tmpLongest.size())
		{
			if (longest < tmpLongest[iter].length())
			{
				longest = tmpLongest[iter].length();
				longestText = tmpLongest[iter];
			}
			iter++;
		}
		longestTextLine = longestText;
		newlineCounter = iter;

		textChange = true;
	}
	//End: Split in Multilines and check for longest line

	if(hWnd)
	{
		if(dynamicText || dynamicTooltip || alwaysUpdateContent)
			SetTimer(hWnd, TIMER_UPDATE, updateInterval, 0);
		else
			KillTimer(hWnd, TIMER_UPDATE);
	}

	repaint();
	
	if(text != oldText)
	{
		if (autoWidthMode != 0 || autoHeightMode != 0)
			autoSize();
		if (transparencyMode == 1)
			updateRegion();
		if(!textChangeCommand.empty())
			LSExecute(NULL, textChangeCommand.c_str(), SW_SHOWNORMAL);
	}
}

//------------------------------------------------------------
//Set Animations
//------------------------------------------------------------
void Label::setAnimation(bool start, int loops)
{
	imageLoop = loops;
	normalAnim = start;

	if (start)
	{
		frameCounter = 1;
		loopCounter = 0;
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
	}
	else
	{
		frameCounter = 0;
		loopCounter = 0;
		KillTimer(hWnd, TIMER_FRAMEANIMATION);
		repaint(true);
	}	
}

//------------------------------------------------------------
//Move/Resize/Reposition
//------------------------------------------------------------
void Label::move(int newx, int newy, int steps, int time, bool moveBy)
{
	if (steps > 0 && time > 0)
	{
		if (time > 50)
			time = 50;

		int counter = 0;
		int deltax = newx - actualx;
		int deltay = newy - actualy;

		bool growx;
		bool growy;
		if (deltax < 0)
			growx = false;
		else
			growx = true;

		if (deltay < 0)
			growy = false;
		else
			growy = true;

		div_t div_result = div( deltax, steps );
		deltax = div_result.quot;
		div_result = div( deltay, steps );
		deltay = div_result.quot;

		if (deltax == 0 && growx)
			deltax = 1;
		else if (deltax == 0 && !growx)
			deltax = -1;

		if (deltay == 0 && growy)
			deltay = 1;
		else if (deltay == 0 && !growy)
			deltay = -1;

		int dynx = actualx;
		int dyny = actualy;

		if(hWnd)
		{
			int stopper = 0;
			while (counter <= steps)
			{
				stopper = 0; // Stop if x and y finished, stopper = 2
				dynx = dynx+deltax;
				if (growx && dynx > newx)
				{
					dynx = newx;
					stopper++;
				}
				else if (!growx && dynx < newx)
				{
					dynx = newx;
					stopper++;
				}

				dyny = dyny+deltay;
				if (growy && dyny > newy)
				{
					dyny = newy;
					stopper++;
				}
				else if (!growy && dyny < newy)
				{
					dyny = newy;
					stopper++;
				}
				
				SetWindowPos(hWnd, 0, dynx, dyny, 0, 0,
					SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);

				SendMessage(hWnd, WM_PAINT, 0, 0);

				if (stopper == 2)
					counter = steps;
				
				counter++;

				Sleep(time);
			}

			actualx = newx;
			actualy = newy;

			SetWindowPos(hWnd, 0, newx, newy, 0, 0,
					SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
		}
	}
	else
	{
		if(hWnd)
		{
			if (moveBy)
			{
				newx = actualx + newx;
				newy = actualy + newy;
			}

			actualx = newx;
			actualy = newy;

			SetWindowPos(hWnd, 0, newx, newy, 0, 0,
				SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
		}
	}

	if (autoWidthMode != 0 || autoHeightMode != 0)
	{
		startCenterX = actualx+(actualwidth/2);
		startCenterY = actualy+(actualheight/2);
	}
}

void Label::resize(int newwidth, int newheight, int steps, int time, int sizeMode)
{
	POINT sizeHolder;
	sizeHolder.x = actualwidth;
	sizeHolder.y = actualheight;
	if (steps > 0 && time > 0)
	{
		if (time > 50)
			time = 50;

		int counter = 0;
		int deltax = newwidth - actualwidth;
		int deltay = newheight - actualheight;

		bool growx;
		bool growy;
		if (deltax < 0)
			growx = false;
		else
			growx = true;

		if (deltay < 0)
			growy = false;
		else
			growy = true;

		div_t div_result = div( deltax, steps );
		deltax = div_result.quot;
		div_result = div( deltay, steps );
		deltay = div_result.quot;

		if (deltax == 0 && growx)
			deltax = 1;
		else if (deltax == 0 && !growx)
			deltax = -1;
		if (deltay == 0 && growy)
			deltay = 1;
		else if (deltay == 0 && !growy)
			deltay = -1;

		int dynwidth = actualwidth;
		int dynheight = actualheight;

		if(hWnd)
		{
			int stopper = 0;
			while (counter <= steps)
			{
				stopper = 0;  // Stop if width and height are finished, stopper = 2
				dynwidth = dynwidth+deltax;
				if (growx && dynwidth > newwidth)
				{
					dynwidth = newwidth;
					stopper++;
				}
				else if (!growx && dynwidth < newwidth)
				{
					dynwidth = newwidth;
					stopper++;
				}

				dynheight = dynheight+deltay;
				if (growy && dynheight > newheight)
				{
					dynheight = newheight;
					stopper++;
				}
				else if (!growy && dynheight < newheight)
				{
					dynheight = newheight;
					stopper++;
				}
				
				SetWindowPos(hWnd, 0, 0, 0, dynwidth, dynheight,
					SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
				
				SendMessage(hWnd, WM_PAINT, 0, 0);

				if (stopper == 2)
					counter = steps;

				counter++;

				Sleep(time);
			}

			actualheight = newheight;
			actualwidth = newwidth;

			SetWindowPos(hWnd, 0, 0, 0, newwidth, newheight,
					SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
		
			//Force Repaint to get correct values for Resize Command (SetEvar must be called befire!)
			SendMessage(hWnd, WM_PAINT, 0, 0);
		}
	}
	else
	{
		if(hWnd)
		{
			if (sizeMode == -1)
			{
				if (newwidth > 0)
					newwidth = actualwidth - newwidth;
				else
					newwidth = actualwidth;
				if (newheight > 0)
					newheight = actualheight - newheight;
				else
					newheight = actualheight;
			}
			else if (sizeMode == 1)
			{
				if (newwidth > 0)
					newwidth = actualwidth + newwidth;
				else
					newwidth = actualwidth;
				if (newheight > 0)
					newheight = actualheight + newheight;
				else
					newheight = actualheight;
			}

			actualheight = newheight;
			actualwidth = newwidth;

			SetWindowPos(hWnd, 0, 0, 0, newwidth, newheight,
				SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);

			//Force Repaint to get correct values for Resize Command (SetEvar must be called befire!)
			SendMessage(hWnd, WM_PAINT, 0, 0);
		}
	}

	if (transparencyMode == 1)
		updateRegion();

	if(resizeCommand.length() > 0 && (actualwidth != sizeHolder.x || actualheight != sizeHolder.y))
		LSExecute(hWnd, resizeCommand.c_str(), SW_SHOWNORMAL);
}

void Label::reposition(int newx, int newy, int newwidth, int newheight, int steps, int time)
{
	POINT sizeHolder;
	sizeHolder.x = actualwidth;
	sizeHolder.y = actualheight;
	if (steps > 0 && time > 0)
	{
		if (time > 50)
			time = 50;

		int counter = 0;
		int deltax = newx - actualx;
		int deltay = newy - actualy;
		int deltasizex = newwidth - actualwidth;
		int deltasizey = newheight - actualheight;

		bool growx;
		bool growy;
		bool growsizex;
		bool growsizey;
		
		if (deltax < 0)
			growx = false;
		else
			growx = true;
		if (deltay < 0)
			growy = false;
		else
			growy = true;
		
		if (deltasizex < 0)
			growsizex = false;
		else
			growsizex = true;
		if (deltasizey < 0)
			growsizey = false;
		else
			growsizey = true;

		div_t div_result;
		div_result = div( deltax, steps );
		deltax = div_result.quot;
		div_result = div( deltay, steps );
		deltay = div_result.quot;

		div_result = div( deltasizex, steps );
		deltasizex = div_result.quot;
		div_result = div( deltasizey, steps );
		deltasizey = div_result.quot;

		if (deltax == 0 && growx)
			deltax = 1;
		else if (deltax == 0 && !growx)
			deltax = -1;
		if (deltay == 0 && growy)
			deltay = 1;
		else if (deltay == 0 && !growy)
			deltay = -1;

		if (deltasizex == 0 && growsizex)
			deltasizex = 1;
		else if (deltasizex == 0 && !growsizex)
			deltasizex = -1;
		if (deltasizey == 0 && growsizey)
			deltasizey = 1;
		else if (deltasizey == 0 && !growsizey)
			deltasizey = -1;

		int dynx = actualx;
		int dyny = actualy;
		int dynwidth = actualwidth;
		int dynheight = actualheight;

		if(hWnd)
		{
			int stopper = 0;
			while (counter <= steps)
			{
				stopper = 0; // Stop if x, y, width and height are finished, stopper = 4
				dynx = dynx+deltax;
				if (growx && dynx > newx)
				{
					dynx = newx;
					stopper++;
				}
				else if (!growx && dynx < newx)
				{
					dynx = newx;
					stopper++;
				}

				dyny = dyny+deltay;
				if (growy && dyny > newy)
				{
					dyny = newy;
					stopper++;
				}
				else if (!growy && dyny < newy)
				{
					dyny = newy;
					stopper++;
				}

				dynwidth = dynwidth+deltasizex;
				if (growsizex && dynwidth > newwidth)
				{
					dynwidth = newwidth;
					stopper++;
				}
				else if (!growsizex && dynwidth < newwidth)
				{
					dynwidth = newwidth;
					stopper++;
				}

				dynheight = dynheight+deltasizey;
				if (growsizey && dynheight > newheight)
				{
					dynheight = newheight;
					stopper++;
				}
				else if (!growsizey && dynheight < newheight)
				{
					dynheight = newheight;
					stopper++;
				}
				
				SetWindowPos(hWnd, 0, dynx, dyny, dynwidth, dynheight,
					SWP_NOACTIVATE | SWP_NOZORDER);
				
				SendMessage(hWnd, WM_PAINT, 0, 0);

				if (stopper == 4)
					counter = steps;

				counter++;

				Sleep(time);
			}

			actualx = newx;
			actualy = newy;
			actualwidth = newwidth;
			actualheight = newheight;

			SetWindowPos(hWnd, 0, newx, newy, newwidth, newheight,
				SWP_NOACTIVATE | SWP_NOZORDER);

			//Force Repaint to get correct values for Resize Command (SetEvar must be called befire!)
			SendMessage(hWnd, WM_PAINT, 0, 0);
		}
	}
	else
	{
		if(hWnd)
		{
			actualx = newx;
			actualy = newy;
			actualheight = newheight;
			actualwidth = newwidth;

			SetWindowPos(hWnd, 0, newx, newy, newwidth, newheight,
				SWP_NOACTIVATE | SWP_NOZORDER);

			//Force Repaint to get correct values for Resize Command (SetEvar must be called befire!)
			SendMessage(hWnd, WM_PAINT, 0, 0);
		}
	}

	if (transparencyMode == 1)
		updateRegion();

	if (autoWidthMode != 0 || autoHeightMode != 0)
	{
		startCenterX = actualx+(actualwidth/2);
		startCenterY = actualy+(actualheight/2);
	}

	if(resizeCommand.length() > 0 && (actualwidth != sizeHolder.x || actualheight != sizeHolder.y))
		LSExecute(hWnd, resizeCommand.c_str(), SW_SHOWNORMAL);
}

//------------------------------------------------------------
//Show/Hide
//------------------------------------------------------------
void Label::show()
{
	if (!hWnd)
		load(hInstance, box);
	
	if(hWnd)
	{
		KillTimer(hWnd, TIMER_AUTOHIDE);

		if (alphaFade && IsOS(OS_2KXP) && box == NULL)
		{
			UpdateWindowTransparent(hWnd, 0);

			// Show it _first_
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);	

			// Redraw contents NOW - no flickering since the window's not visible
			RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW); 
				
			UpdateAlpha = 0;

			SetTimer(hWnd, TIMER_ALPHAFADEIN, 25, NULL);
		}
		else
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);

		visible = true;
		if (transparencyMode == 1)
			updateRegion();

		if (normalAnim)
		{
			frameCounter = 1;
			loopCounter = 0;
			SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
		}
	}
}

void Label::showHide(double timeout)
{
	show();
	SetTimer(hWnd, TIMER_AUTOHIDE, timeout * 1000, NULL);
}

void Label::hide()
{
	if(hWnd)
	{
		if (alphaFade && IsOS(OS_2KXP) && box == NULL)
		{
			UpdateAlpha = alphaTransparency;

			SetTimer(hWnd, TIMER_ALPHAFADEOUT, 25, NULL);
		}
		else
			ShowWindow(hWnd, SW_HIDE);

		visible = false;

		KillTimer(hWnd, TIMER_AUTOHIDE);

		if (normalAnim || hoverAnim)
			KillTimer(hWnd, TIMER_FRAMEANIMATION);
	}
}


//------------------------------------------------------------
//Clipboard Functions
//------------------------------------------------------------
void Label::clipboardCopy(string prefix)
{
	string toCopy = prefix.empty() ? text : (prefix + " " + text);
	SetClipboardText(hWnd, toCopy.c_str());
}

void Label::clipboardPaste(string prefix)
{
	char buffer[256];

	if(GetClipboardText(hWnd, buffer, 256))
	{
		string toPaste = prefix.empty() ? string(buffer) : (prefix + " " + string(buffer));
		setText(toPaste);
	}
}

//------------------------------------------------------------
//Region Events (Checking)
//------------------------------------------------------------
bool Label::checkRegion(int x, int y, StringList inputlist)
{
	bool found = false;
	if (!inputlist.empty())
	{
		for(StringListIterator it = inputlist.begin(); it != inputlist.end(); it++)
		{
			char left[16], top[16], right[16], bottom[16], command[128];
			char *buffers[] = {left, top, right, bottom};

			if(LCTokenize((*it).c_str(), buffers, 4, command) >= 4)
			{
				RECT rc;
				GetClientRect(hWnd, &rc);

				int intleft = ParseCoord(left, 0, rc.right-rc.left);
				int intright = ParseCoord(right, -0, rc.right-rc.left);
				int inttop = ParseCoord(top, 0, rc.bottom-rc.top);
				int intbottom  = ParseCoord(bottom, -0, rc.bottom-rc.top);

				if (intleft < intright && inttop < intbottom)
				{
					POINT pt;
					pt.x = x;
					pt.y = y;

					if(pt.x >= intleft && pt.x <= intright && pt.y >= inttop && pt.y <= intbottom)
					{
						if((*it).length() > 0)
						{	
							string temp = command;
							string bang = ("!execute [" + temp + "]");
							LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
							found = true;
							return found;
						}	
					}
				}
			}
		}
	}
	return found;
}

//------------------------------------------------------------
//Mouse Related Actions (Clicks, Enter, Leave, Move, ...)
//------------------------------------------------------------

void Label::onLButtonDblClk(int x, int y)
{
	if(leftDoubleClickCommand.length() > 0)
		LSExecute(hWnd, leftDoubleClickCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onLButtonDown(int x, int y)
{
	//Silly hack to stop execution on mouseclick emulation
	//FocusOnEnter
	if (focusOnEnter != 2)
	{
	//--------------------------------------------------------------

	//Stop Animation Timer (Normal & Hover)
	KillTimer(hWnd, TIMER_FRAMEANIMATION);

	if(moveable && moveButton == 1)
	{
		if(!mousePressed && !movemodifierkeyPressed)
			mousePressed = true;
		else if (!mousePressed && movemodifierkeyPressed)
		{
			if (box)
				return;
			mousePressed = true;
			moveButtonPressed = 1;
			GetCursorPos(&savedpt);
			ScreenToClient(hWnd, &savedpt);
			SetCapture(hWnd);
		}
	}
	else
	{
		if(!mousePressed)
			mousePressed = true;
	}

	if (usePressed)
	{
		hoverActive = false;
		pressedActive = true;
		reallyOverBlend = true;
		repaint(true);
	
		if (transparencyMode == 1)
			updateRegion();
	}

	//--------------------------------------------------------------
	}
}

	
void Label::onLButtonUp(int x, int y)
{	
	//Silly hack to stop execution on mouseclick emulation
	//FocusOnEnter
	if (focusOnEnter != 2)
	{
	//--------------------------------------------------------------

	if(moveable && moveButton == 1)
	{
		if(mousePressed && !movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			
			if (!checkRegion(x, y, labelLeftClickRegions))
			{
				POINT pt;
				pt.x = x;
				pt.y = y;

				RECT rc;
				GetClientRect(hWnd, &rc);

				if(PtInRect(&rc, pt))
				{
					if(leftClickCommand.length() > 0)
						LSExecute(hWnd, leftClickCommand.c_str(), SW_SHOWNORMAL);
				}
			}

			mousePressed = false;
			moveButtonPressed = 0;
		}
		else if (mousePressed && movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

			mousePressed = false;
			moveButtonPressed = 0;
		}
	}
	else
	{
		//To be on the save side
		ReleaseCapture();
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

		if(mousePressed && !checkRegion(x, y, labelLeftClickRegions))
		{
			POINT pt;
			pt.x = x;
			pt.y = y;

			RECT rc;
			GetClientRect(hWnd, &rc);

			if(PtInRect(&rc, pt))
			{
				if(leftClickCommand.length() > 0)
					LSExecute(hWnd, leftClickCommand.c_str(), SW_SHOWNORMAL);
			}
		}
		mousePressed = false;
		moveButtonPressed = 0;
	}

	if (usePressed)
	{
		hoverActive = true;
		pressedActive = false;
		reallyOverBlend = true;
		repaint(true);

		if (transparencyMode == 1)
			updateRegion();
	}

	//Animation RESTART
	if (useHover)
	{
		//Restart Hover Anim
		if (hoverAnim)
		{
			frameCounter = 1;
			loopCounter = 0;
			SetTimer(hWnd, TIMER_FRAMEANIMATION, hoverimageFrameDelay, NULL);
		}
	}
	//Restart Normal Anim
	else if (normalAnim)
	{
		frameCounter = 1;
		loopCounter = 0;
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
	}

	//--------------------------------------------------------------
	}
	else
		focusOnEnter = 1;
}

void Label::onMButtonDblClk(int x, int y)
{
	if(middleDoubleClickCommand.length() > 0)
		LSExecute(hWnd, middleDoubleClickCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onMButtonDown(int x, int y)
{
	//Stop Animation Timer (Normal & Hover)
	KillTimer(hWnd, TIMER_FRAMEANIMATION);

	if(moveable && moveButton == 3)
	{
		if(!mousePressed && !movemodifierkeyPressed)
			mousePressed = true;
		else if (!mousePressed && movemodifierkeyPressed)
		{
			if (box)
				return;
			mousePressed = true;
			moveButtonPressed = 3;
			GetCursorPos(&savedpt);
			ScreenToClient(hWnd, &savedpt);
			SetCapture(hWnd);
		}
	}
	else
	{
		if(!mousePressed)
			mousePressed = true;
	}

	if (usePressed)
	{
		hoverActive = false;
		pressedActive = true;
		reallyOverBlend = true;
		repaint(true);
	
		if (transparencyMode == 1)
			updateRegion();
	}
}

void Label::onMButtonUp(int x, int y)
{
	if(moveable && moveButton == 3)
	{
		if(mousePressed && !movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			
			if (!checkRegion(x, y, labelMiddleClickRegions))
			{
				POINT pt;
				pt.x = x;
				pt.y = y;

				RECT rc;
				GetClientRect(hWnd, &rc);

				if(PtInRect(&rc, pt))
				{
					if(middleClickCommand.length() > 0)
						LSExecute(hWnd, middleClickCommand.c_str(), SW_SHOWNORMAL);
				}
			}
			
			mousePressed = false;
			moveButtonPressed = 0;
		}
		else if (mousePressed && movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

			mousePressed = false;
			moveButtonPressed = 0;
		}
	}
	else
	{
		//To be on the save side
		ReleaseCapture();
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

		if(mousePressed && !checkRegion(x, y, labelMiddleClickRegions))
		{
			POINT pt;
			pt.x = x;
			pt.y = y;

			RECT rc;
			GetClientRect(hWnd, &rc);

			if(PtInRect(&rc, pt))
			{
				if(middleClickCommand.length() > 0)
					LSExecute(hWnd, middleClickCommand.c_str(), SW_SHOWNORMAL);
			}
		}
		mousePressed = false;
		moveButtonPressed = 0;
	}

	if (usePressed)
	{
		hoverActive = true;
		pressedActive = false;
		reallyOverBlend = true;
		repaint(true);

		if (transparencyMode == 1)
			updateRegion();
	}

	//Animation RESTART
	if (useHover)
	{
		//Restart Hover Anim
		if (hoverAnim)
		{
			frameCounter = 1;
			loopCounter = 0;
			SetTimer(hWnd, TIMER_FRAMEANIMATION, hoverimageFrameDelay, NULL);
		}
	}
	//Restart Normal Anim
	else if (normalAnim)
	{
		frameCounter = 1;
		loopCounter = 0;
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
	}
}

void Label::onRButtonDblClk(int x, int y)
{
	if(rightDoubleClickCommand.length() > 0)
		LSExecute(hWnd, rightDoubleClickCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onRButtonDown(int x, int y)
{
	//Stop Animation Timer (Normal & Hover)
	KillTimer(hWnd, TIMER_FRAMEANIMATION);

	if(moveable && moveButton == 2)
	{
		if(!mousePressed && !movemodifierkeyPressed)
			mousePressed = true;
		else if (!mousePressed && movemodifierkeyPressed)
		{
			if (box)
				return;
			mousePressed = true;
			moveButtonPressed = 2;
			GetCursorPos(&savedpt);
			ScreenToClient(hWnd, &savedpt);
			SetCapture(hWnd);
		}
	}
	else
	{
		if(!mousePressed)
			mousePressed = true;
	}

	if (usePressed)
	{
		hoverActive = false;
		pressedActive = true;
		reallyOverBlend = true;
		repaint(true);
	
		if (transparencyMode == 1)
			updateRegion();
	}
}

void Label::onRButtonUp(int x, int y)
{
	if(moveable && moveButton == 2)
	{
		if(mousePressed && !movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			
			if (!checkRegion(x, y, labelRightClickRegions))
			{
				POINT pt;
				pt.x = x;
				pt.y = y;

				RECT rc;
				GetClientRect(hWnd, &rc);

				if(PtInRect(&rc, pt))
				{
					if(rightClickCommand.length() > 0)
						LSExecute(hWnd, rightClickCommand.c_str(), SW_SHOWNORMAL);
				}
			}
			
			mousePressed = false;
			moveButtonPressed = 0;
		}
		else if (mousePressed && movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

			mousePressed = false;
			moveButtonPressed = 0;
		}
	}
	else 
	{
		//To be on the save side
		ReleaseCapture();
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

		if(mousePressed && !checkRegion(x, y, labelRightClickRegions))
		{
			POINT pt;
			pt.x = x;
			pt.y = y;

			RECT rc;
			GetClientRect(hWnd, &rc);

			if(PtInRect(&rc, pt))
			{
				if(rightClickCommand.length() > 0)
					LSExecute(hWnd, rightClickCommand.c_str(), SW_SHOWNORMAL);
			}
		}
		mousePressed = false;
		moveButtonPressed = 0;
	}

	if (usePressed)
	{
		hoverActive = true;
		pressedActive = false;
		reallyOverBlend = true;
		repaint(true);

		if (transparencyMode == 1)
			updateRegion();
	}

	//Animation RESTART
	if (useHover)
	{
		//Restart Hover Anim
		if (hoverAnim)
		{
			frameCounter = 1;
			loopCounter = 0;
			SetTimer(hWnd, TIMER_FRAMEANIMATION, hoverimageFrameDelay, NULL);
		}
	}
	//Restart Normal Anim
	else if (normalAnim)
	{
		frameCounter = 1;
		loopCounter = 0;
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
	}
}

void Label::onWheelDown(int x, int y)
{
	if(wheelDownCommand.length() > 0)
		LSExecute(hWnd, wheelDownCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onWheelUp(int x, int y)
{
	if(wheelUpCommand.length() > 0)
		LSExecute(hWnd, wheelUpCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onMouseEnter()
{
	if (focusOnEnter == 1)
	{	
		focusOnEnter = 2;
		mouse_event(MOUSEEVENTF_LEFTDOWN, NULL, NULL, NULL, NULL);
		mouse_event(MOUSEEVENTF_LEFTUP, NULL, NULL, NULL, NULL);
	}

	if (useHover)
	{
		//Kill AnimTimer from Normal Animation
		if (normalAnim)
			KillTimer(hWnd, TIMER_FRAMEANIMATION);

		//If HoverAnim is set (hoverframecount != 0)
		if (hoverAnim)
		{
			hoverActive = true;
			pressedActive = false;
			frameCounter = 1;
			loopCounter = 0;
			//Start AnimTimer from Hover Animation
			SetTimer(hWnd, TIMER_FRAMEANIMATION, hoverimageFrameDelay, NULL);
		}
		//If HoverAnim is not set (hoverframecount == 0)
		else
		{
			frameCounter = 0;
			hoverActive = true;
			pressedActive = false;
			reallyOverBlend = true;
			repaint(true);

			if (transparencyMode == 1)
				updateRegion();
		}
	}	
	
	if(enterCommand.length() > 0)
		LSExecute(hWnd, enterCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onMouseLeave()
{
	if (useHover)
	{
		//If HoverAnim was active (hoverframecount != 0)
		if (hoverAnim)
		{
			hoverActive = false;
			pressedActive = false;
			frameCounter = 0;
			//Kill AnimTimer from Hover Animation
			KillTimer(hWnd, TIMER_FRAMEANIMATION);

			//If NormalAnim is set (framecount != 0)
			if (normalAnim)
			{
				frameCounter = 1;
				loopCounter = 0;
				SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
			}
			//If NormalAnim is not set (framecount == 0)
			else
			{
				reallyOverBlend = true;
				repaint(true);
				if (transparencyMode == 1)
					updateRegion();
			}
		}
		else
		{
			hoverActive = false;
			pressedActive = false;
			//If NormalAnim is set (framecount != 0)
			if (normalAnim)
			{
				frameCounter = 1;
				SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
			}
			//If NormalAnim is not set (framecount == 0)
			else
			{
				reallyOverBlend = true;
				repaint(true);
				if (transparencyMode == 1)
					updateRegion();
			}
		}
	}

	if(leaveCommand.length() > 0)
		LSExecute(hWnd, leaveCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onMouseMove(int x, int y)
{
	if(moveable)
	{
		if (mousePressed && movemodifierkeyPressed && moveButtonPressed == moveButton)
			SetTimer(hWnd, TIMER_MOUSETRACK_MOVE, 2, 0);
		else
		{
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			KillTimer(hWnd, TIMER_MOUSETRACK);

			if(!mouseInside)
			{
				mouseInside = true;
				if (alphaEnabled)
					SetFocus(hWnd);
				onMouseEnter();
				SetTimer(hWnd, TIMER_MOUSETRACK, 100, 0);
			}
		}
	}
	else if (!moveable)
	{
		if(!mouseInside)
		{
			mouseInside = true;
			if (alphaEnabled)
				SetFocus(hWnd);
			onMouseEnter();
			SetTimer(hWnd, TIMER_MOUSETRACK, 100, 0);
		}
	}
}

//------------------------------------------------------------
//AutoWidthMode and AutoHeightMode Implementation
//------------------------------------------------------------
void Label::autoSize()
{
	POINT sizeHolder;
	sizeHolder.x = actualwidth;
	sizeHolder.y = actualheight;

	RECT mainRect;
	GetWindowRect(hWnd, &mainRect);

	int width = mainRect.right - mainRect.left;
	int height = mainRect.bottom - mainRect.top;

	long textWidth;
	long textHeight;

	font->measure(bufferDC, longestTextLine, 0, &textWidth, &textHeight);

	int placeHolderWidth;
	int placeHolderHeight;

	placeHolderWidth = textWidth+4;
	placeHolderHeight = newlineCounter*textHeight+4;

	//For AUTOWIDTH/HEIGHT MODE	
	int newx;
	int newy;
	int newwidth;
	int newheight;

	int deltax;
	int deltay;

	if (autoWidthMode != 0)
		deltax = placeHolderWidth - (width - leftBorder - rightBorder);
	else
		deltax = 0;

	if (autoHeightMode != 0)
		deltay = placeHolderHeight - (height - topBorder - bottomBorder);
	else
		deltay = 0;

	newx = mainRect.left;
	newy = mainRect.top;
	newwidth = width + deltax;
	newheight = height + deltay;

	//Check MIN/MAX
	if (newwidth < autoMinWidth || newwidth > autoMaxWidth)
	{
		if (newwidth < autoMinWidth)
		{
			deltax = deltax + (autoMinWidth-newwidth);
			newwidth = autoMinWidth;
		}
		if (newwidth > autoMaxWidth)
		{
			deltax = deltax - (newwidth-autoMaxWidth);
			newwidth = autoMaxWidth;
		}
	}
	if (newheight < autoMinHeight || newheight > autoMaxHeight)
	{
		if (newheight < autoMinHeight)
		{
			deltay = deltay + (autoMinHeight-newheight);
			newheight = autoMinHeight;
		}
		if (newheight > autoMaxHeight)
		{
			deltay = deltay - (newheight-autoMaxHeight);
			newheight = autoMaxHeight;
		}
	}

	if ((autoWidthMode == 0 || autoWidthMode == 1) && (autoHeightMode == 0 || autoHeightMode == 1))
	{
		newx = mainRect.left;
		newy = mainRect.top;
	}
	else if ((autoWidthMode == 0 || autoWidthMode == 1) && autoHeightMode == 2)
	{
		newx = mainRect.left;
		newy = mainRect.top-deltay;
	}
	else if ((autoWidthMode == 0 || autoWidthMode == 1) && autoHeightMode == 3)
	{
		newx = mainRect.left;
		newy = startCenterY-(newheight/2);
	}
	else if (autoWidthMode == 2 && (autoHeightMode == 0 || autoHeightMode == 1))
	{
		newx = mainRect.left-deltax;
		newy = mainRect.top;
	}
	else if (autoWidthMode == 2 && autoHeightMode == 2)
	{
		newx = mainRect.left-deltax;
		newy = mainRect.top-deltay;
	}
	else if (autoWidthMode == 2 && autoHeightMode == 3)
	{
		newx = mainRect.left-deltax;
		newy = startCenterY-(newheight/2);
	}
	else if (autoWidthMode == 3 && (autoHeightMode == 0 || autoHeightMode == 1))
	{
		newx = startCenterX-(newwidth/2);
		newy = mainRect.top;
	}
	else if (autoWidthMode == 3 && autoHeightMode == 2)
	{
		newx = startCenterX-(newwidth/2);
		newy = mainRect.top-deltay;
	}
	else if (autoWidthMode == 3 && autoHeightMode == 3)
	{
		newx = startCenterX-(newwidth/2);
		newy = startCenterY-(newheight/2);
	}

	//Reposition to NEW Pos/Size ( ONLY IN AUTOWIDTH-, AUTOHEIGHT-MODE )
	actualx = newx;
	actualy = newy;
	actualwidth = newwidth;
	actualheight = newheight;

	SetWindowPos(hWnd, 0, newx, newy, newwidth, newheight,
				SWP_NOACTIVATE | SWP_NOZORDER);

	//Force Repaint to get correct values for Resize Command (SetEvar must be called befire!)
	SendMessage(hWnd, WM_PAINT, 0, 0);

	if (transparencyMode == 1)
		updateRegion();

	textChange = false;

	if(resizeCommand.length() > 0 && (actualwidth != sizeHolder.x || actualheight != sizeHolder.y))
		LSExecute(hWnd, resizeCommand.c_str(), SW_SHOWNORMAL);
}

void Label::repaint(bool invalidateCache)
{
	if(hWnd)
	{
		if(invalidateCache)
		{
			if(backgroundDC && backgroundBitmap)
			{
				backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
				DeleteObject(backgroundBitmap);
				backgroundBitmap = 0;
			}

			if(bufferDC && bufferBitmap)
			{
				bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
				DeleteObject(bufferBitmap);
				bufferBitmap = 0;
			}
		}

		InvalidateRect(hWnd, NULL, false);
	}
}

void Label::onPaint(HDC hDC)
{
	bool useFrames = false;
	RECT mainRect;
	GetWindowRect(hWnd, &mainRect);

	int width = mainRect.right - mainRect.left;
	int height = mainRect.bottom - mainRect.top;

	RECT completeFillRect;
	completeFillRect.left = 0;
	completeFillRect.top = 0;
	completeFillRect.right = width;
	completeFillRect.bottom = height;

	// keep a cached rendition of the background
	if(!backgroundBitmap)
	{
		if(!backgroundDC)
			backgroundDC = CreateCompatibleDC(hDC);

		backgroundBitmap = CreateCompatibleBitmap(hDC, width, height);
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);

		//True Transparency
		if (transparencyMode == 1)
		{
			HBRUSH hbrush;
			hbrush = CreateSolidBrush((RGB(255, 0, 255)));
			FillRect(backgroundDC, &completeFillRect, hbrush);
			DeleteObject(hbrush);
		}
		//PrePaint Background (Fake Transparency)
		else if(transparencyMode == 2)
		{
			if(box)
			{
				// save the previous DC contents as the background
				BitBlt(backgroundDC, 0, 0, width, height, hDC, 0, 0, SRCCOPY);
			}
			else
			{
				// paint desktop on display DC and then into background buffer
				PaintDesktopEx(backgroundDC, 0, 0, width, height, mainRect.left, mainRect.top, FALSE);
			}
		}
		//Default Background
		else if (transparencyMode == 3)
		{
			DrawEdge(backgroundDC,
					&completeFillRect,
					EDGE_RAISED,
					BF_RECT | BF_MIDDLE);
		}
		
		//Normal Background Painting if no Animation
		if ( (!normalAnim && !hoverAnim) || frameCounter == 0 || (usePressed && pressedActive))
		{
			if (hoverActive && useHover)
				background->apply(backgroundDC, 0, 0, width, height, transparencyMode, 1);
			else if (pressedActive && usePressed)
				background->apply(backgroundDC, 0, 0, width, height, transparencyMode, 2);
			else
				background->apply(backgroundDC, 0, 0, width, height, transparencyMode, 0);
		}
		//Special Background Painting if Animation (normal or hover)
		else
		{
			useFrames = true;
			if (hoverActive && useHover)
				background->applyAnim(backgroundDC, 0, 0, width, height, transparencyMode, 1, frameCounter);
			else
				background->applyAnim(backgroundDC, 0, 0, width, height, transparencyMode, 0, frameCounter);
		}
	}

	// double buffer for flicker-free paint
	if(!bufferBitmap)
	{
		if(!bufferDC)
			bufferDC = CreateCompatibleDC(hDC);

		bufferBitmap = CreateCompatibleBitmap(hDC, width, height);
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
	}

	// blt background into double buffer
	BitBlt(bufferDC, 0, 0, width, height, backgroundDC, 0, 0, SRCCOPY);

	//--------------------------------------------------------------------------------
	// start rendering text
	//--------------------------------------------------------------------------------
	//Create Region in which text drawing is allowed
	HRGN drawArea = CreateRectRgn( 0, 0, actualwidth, actualheight );
	HRGN allowedArea = CreateRectRgn( leftBorder, topBorder, width - rightBorder, height - bottomBorder );
	SelectClipRgn(bufferDC, allowedArea);
	DeleteObject(allowedArea);
	
	long textWidth;
	long textHeight;

	font->measure(bufferDC, longestTextLine, 0, &textWidth, &textHeight);

	int placeHolderWidth;
	int placeHolderHeight;

	placeHolderWidth = textWidth;
	placeHolderHeight = newlineCounter*textHeight;
	
	if ( ((scroll == 1 || scroll == 3) && placeHolderWidth > width - leftBorder - rightBorder) || ((scroll == 2 || scroll == 4) && placeHolderHeight > height - topBorder - bottomBorder) )
	{			
		if (scroll == 1 || scroll == 3)
		{
			if(scrollPosition <= 0)
			{
				scrollPosition = placeHolderWidth + scrollPadLength;
					
				if (scrollLimit)
				{
					scrollLimit--;
					if (scrollLimit == 0)
						setScrolling(0);
				}
			}

			if(scrollPosition > placeHolderWidth + scrollPadLength )
				scrollPosition = 0;
		}
		else if (scroll == 2 || scroll == 4)
		{
			if(scrollPosition <= 0)
			{
				scrollPosition = placeHolderHeight + scrollPadLength;
					
				if (scrollLimit)
				{
					scrollLimit--;
					if (scrollLimit == 0)
						setScrolling(0);
				}
			}

			if(scrollPosition > placeHolderHeight + scrollPadLength )
				scrollPosition = 0;
		}
		
		if (scroll == 1 || scroll == 3)
		{
			font->apply(bufferDC,
						leftBorder,
						topBorder,
						scrollPosition - scrollPadLength,
						height - topBorder - bottomBorder,
						text,
						DT_RIGHT | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS ,
						vertAlign);

			font->apply(bufferDC,
						scrollPosition + leftBorder,
						topBorder,
						placeHolderWidth,
						height - topBorder - bottomBorder,
						text,
						DT_LEFT | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS ,
						vertAlign);
		}
		else if (scroll == 2 || scroll == 4)
		{
			font->apply(bufferDC,
					leftBorder,
					topBorder,
					width - leftBorder - rightBorder,
					scrollPosition - scrollPadLength,
					text,
					align | DT_NOPREFIX | DT_EXPANDTABS ,
					2);

			font->apply(bufferDC,
					leftBorder,
					scrollPosition + topBorder,
					width - leftBorder - rightBorder,
					placeHolderHeight,
					text,
					align | DT_NOPREFIX | DT_EXPANDTABS ,
					0);
		}
	}
	else
	{
		font->apply(bufferDC,
					leftBorder,
					topBorder,
					width - leftBorder - rightBorder,
					height - topBorder - bottomBorder,
					text,
					align | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS  | (lineBreak ? DT_WORDBREAK : 0),
					vertAlign);
	}

	//Reset Region in which text drawing is allowed
	SelectClipRgn(bufferDC, drawArea);
	DeleteObject(drawArea);
	//--------------------------------------------------------------------------------
	// stop rendering text
	//--------------------------------------------------------------------------------

	//Normal Image Switch
	if (overblendStyle == 0 || useFrames || !reallyOverBlend)
	{
		// blt the double buffer to the display
		BitBlt(hDC, 0, 0, width, height, bufferDC, 0, 0, SRCCOPY);
	}
	//OverblendStyle Image Switch
	else if (overblendStyle == -1)
		MagicShow( bufferDC, 0, 0, hDC, 0, 0, width, height, 5, 2, rand()%20 );
	else
		MagicShow( bufferDC, 0, 0, hDC, 0, 0, width, height, 5, 2, overblendStyle );	

	//Set to idle ;) Only OverBlend on MouseOver or Pressed Events and back to normal
	reallyOverBlend = false;
}

void Label::updateRegion()
{
	if (transparencyNeeded)
	{
		HDC tmpDC = CreateCompatibleDC(bufferDC);
		HBITMAP tmpBmp = CreateBitmap(actualwidth, actualheight, 1, 32, NULL);
		HGDIOBJ tmpObj = SelectObject(tmpDC, tmpBmp);

		//Draw Image
		if (bufferDC && bufferBitmap)
			BitBlt(tmpDC, 0, 0, actualwidth, actualheight, bufferDC, 0, 0, SRCCOPY);
		else
			onPaint(tmpDC);
			
		SelectObject(tmpDC, tmpObj);

		HRGN region = BitmapToRegion(tmpBmp, RGB(255, 0, 255), 0, 0, 0);
		HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(windowRgn, region, NULL, RGN_COPY);

		if (!SetWindowRgn(hWnd, windowRgn, true))
			DeleteObject(windowRgn);	

		DeleteObject(region);
		DeleteObject(tmpBmp);
		DeleteObject(tmpObj);
		DeleteDC(tmpDC);
	}
}

void Label::onWindowPosChanged(WINDOWPOS *windowPos)
{
	repaint(true);
	
	RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW);

	if (labelType == 0)
		posmzscriptvarcopy("", "", false);
}

void Label::onSize(int width, int height)
{
	actualheight = height;
	actualwidth = width;

	repaint(true);

	RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW);

	if (labelType == 0)
		sizemzscriptvarcopy("", "", false);
}

void Label::relayMouseMessageToBox(UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	pt.x = GET_X_LPARAM(lParam);
	pt.y = GET_Y_LPARAM(lParam);

	if (box)
	{
		MapWindowPoints(hWnd, box, &pt, 1);
		PostMessage(box, message, wParam, MAKELPARAM((short) pt.x, (short) pt.y));
	}
	else
	{
		MapWindowPoints(hWnd, GetLitestepDesktop(), &pt, 1);
		PostMessage(GetLitestepDesktop(), message, wParam, MAKELPARAM((short) pt.x, (short) pt.y));
	}
}

void Label::onTimer(int timerID)
{
	switch(timerID)
	{
		case TIMER_MOUSETRACK:

			POINT pt;
			RECT rc;
			GetCursorPos(&pt);
			GetWindowRect(hWnd, &rc);

			if(!PtInRect(&rc, pt))
			{
				KillTimer(hWnd, TIMER_MOUSETRACK);
				mouseInside = false;
				mousePressed = false;
				onMouseLeave();	
			}

		break;

		case TIMER_MOUSETRACK_MOVE:

			POINT newpt;
			GetCursorPos(&newpt);
			
			newpt.x = newpt.x-savedpt.x;
			newpt.y = newpt.y-savedpt.y;
			move(newpt.x, newpt.y, 0, 0);
		
		break;

		case TIMER_UPDATE:

			update();

		break;
		
		case TIMER_SCROLL:

			if (!frozen)
			{
				if (scroll == 1 || scroll == 2)
					scrollPosition -= scrollSpeed;
				else if (scroll == 3 || scroll == 4)
					scrollPosition += scrollSpeed;
				repaint();
			}

		break;

		case TIMER_AUTOHIDE:

			hide();

		break;

		case TIMER_ALPHAFADEIN:

			if (UpdateAlpha < alphaTransparency)
			{
				// Raise the alpha value (towards alphatransparency) and update the window.
				UpdateAlpha += 5;
				UpdateWindowTransparent(hWnd, UpdateAlpha);
			}
			else
			{
				// Reached maximum alpha. Kill the timer
				UpdateAlpha = alphaTransparency;
				UpdateWindowTransparent(hWnd, UpdateAlpha);
				KillTimer(hWnd, TIMER_ALPHAFADEIN);
			}

		break;

		case TIMER_ALPHAFADEOUT:

			if (UpdateAlpha >= 5)
			{
				// Reduce the alpha value (towards transparency) and update the window.
				UpdateAlpha -= 5;
				UpdateWindowTransparent(hWnd, UpdateAlpha);
			}
			else
			{
				// Reached minimum alpha. Kill the timer
				UpdateAlpha = 0;
				UpdateWindowTransparent(hWnd, UpdateAlpha);
				KillTimer(hWnd, TIMER_ALPHAFADEOUT);
				ShowWindow(hWnd, SW_HIDE);
			}

		break;

		case TIMER_FRAMEANIMATION:

			if (hoverActive && useHover)
			{
				if (frameCounter == hoverimageFrameCount)
				{
					frameCounter = 0;
					loopCounter++;
				}
				if (loopCounter == hoverimageLoop)
				{
					frameCounter = -1;
					loopCounter = 0;
					KillTimer(hWnd, TIMER_FRAMEANIMATION);
				}
				
			}
			else
			{
				if (frameCounter == imageFrameCount)
				{
					frameCounter = 0;
					loopCounter++;
				}
				if (loopCounter == imageLoop)
				{
					frameCounter = -1;
					loopCounter = 0;
					KillTimer(hWnd, TIMER_FRAMEANIMATION);
				}
			}
			frameCounter++;
			repaint(true);

		break;
	}
}

bool Label::onWindowMessage(UINT message, WPARAM wParam, LPARAM lParam, LRESULT &lResult)
{
	extern HWND messageHandler;
	
	if (labelType == 0 || labelType == 2)
	{
		if (moveKey == 3)
			movemodifierkeyPressed = (0x8000 & GetKeyState(VK_CONTROL)) && (0x8000 & GetKeyState(VK_SHIFT));
		else if (moveKey == 2)
			movemodifierkeyPressed = (0x8000 & GetKeyState(VK_SHIFT));
		else if (moveKey == 1)
			movemodifierkeyPressed = (0x8000 & GetKeyState(VK_CONTROL));
		else 
			movemodifierkeyPressed = (0x8000 & GetKeyState(VK_CONTROL));
	}
	else if (labelType == 1)
		movemodifierkeyPressed = true;

	if (moveable && !movemodifierkeyPressed)
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

	switch(message)
	{
		case LM_SETLABELTEXT:
		{
			setText(string((const char *) lParam));
			return true;
		}

		case WM_COPYDATA:
		{
			COPYDATASTRUCT *cds = (COPYDATASTRUCT *) lParam;
			
			if(cds->dwData == LM_SETLABELTEXT)
				setText(string((const char *) cds->lpData));

			return false;
		}

		case WM_CLOSE:
		{
			lResult = 0;
			return true;
		}

		case WM_DESTROY:
		{
			if(box)		// FIXME: this is the old workaround
			{
				box = NULL;
				hide();
			}
				
			hWnd = NULL;	// FIXME: dirty hack
			
			return false;
		}

		case WM_DROPFILES:
		{
			if(dropCommand.empty())	// we shouldn't get here... but somehow we did :p
				break;

			char *szSourceFiles = NULL;
			char buffer[MAX_PATH], szTarget[MAX_PATH];
			int numFiles;
			UINT len,scursor = 0;
			int intFileAction;

			char action[32];
			char *buffers[] = {action};

			LCTokenize(dropCommand.c_str(), buffers, 1, szTarget);

			if (stricmp(action, "move") == 0)
				intFileAction = 1;
			else if (stricmp(action, "copy") == 0)
				intFileAction = 2;
			else if (stricmp(action, "delete") == 0)
				intFileAction = 0;

			string targetPath = szTarget;
			targetPath = targetPath.substr(1, targetPath.length() - 2);

			numFiles = DragQueryFile((HDROP) wParam, 0xFFFFFFFF, NULL, NULL);

			szSourceFiles = new char[MAX_PATH*numFiles+1];
			scursor = 0;

			for (int i=0;i<numFiles;i++)
			{
				len = DragQueryFile((HDROP) wParam, i, buffer, MAX_PATH);
				
				strcpy(szSourceFiles+scursor,buffer);
				scursor += len + 1;
			}
				
			DragFinish((HDROP) wParam);

			string check = (targetPath + "*");
			
			//Test Path for Existence
			WIN32_FIND_DATA FindData;
			HANDLE hFindHandle = FindFirstFile(check.c_str(), &FindData);

			if(hFindHandle != INVALID_HANDLE_VALUE)
			{
				szSourceFiles[scursor] = 0;
				strcpy(buffer, targetPath.c_str());
				buffer[strlen(buffer)+1] = 0;
				
				SHFILEOPSTRUCT shfop;
				shfop.hwnd = NULL;
				if (intFileAction == 1)
					shfop.wFunc = FO_MOVE;
				else if (intFileAction == 2)
					shfop.wFunc = FO_COPY;
				else if (intFileAction == 0)
					shfop.wFunc = FO_DELETE;
				shfop.pFrom = szSourceFiles;
				shfop.pTo = buffer;
				shfop.fFlags = FOF_NOCONFIRMMKDIR;
				SHFileOperation(&shfop);
			}
			
			delete[] szSourceFiles;
			
			return 0;
		}
		
		case WM_LBUTTONDBLCLK:
		{
			if(leftDoubleClickCommand.empty())
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onLButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_LBUTTONDOWN:
		{
			if(leftDoubleClickCommand.empty() && leftClickCommand.empty() && labelLeftClickRegions.empty() && !moveable && focusOnEnter == 0)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onLButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_LBUTTONUP:
		{
			if(leftDoubleClickCommand.empty() && leftClickCommand.empty() && labelLeftClickRegions.empty() && !moveable && focusOnEnter == 0)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onLButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONDBLCLK:
		{
			if(middleDoubleClickCommand.empty())
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onMButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONDOWN:
		{
			if(middleDoubleClickCommand.empty() && middleClickCommand.empty() && labelMiddleClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onMButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONUP:
		{
			if(middleDoubleClickCommand.empty() && middleClickCommand.empty() && labelMiddleClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onMButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONDBLCLK:
		{
			if(rightDoubleClickCommand.empty())
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onRButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONDOWN:
		{
			if(rightDoubleClickCommand.empty() && rightClickCommand.empty() && labelRightClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onRButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONUP:
		{
			if(rightDoubleClickCommand.empty() && rightClickCommand.empty() && labelRightClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onRButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MOUSEWHEEL:
		{
			if ((short)(HIWORD(wParam)) < 0)
			{
				if(wheelDownCommand.empty())
				{
					relayMouseMessageToBox(message, wParam, lParam);
					return true;
				}

				onWheelDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
				return true;
			}
			else
			{
				if(wheelUpCommand.empty())
				{
					relayMouseMessageToBox(message, wParam, lParam);
					return true;
				}
				
				onWheelUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
				return true;
			}
		}

		case WM_MOUSEMOVE:
		{
			onMouseMove((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_PAINT:
		{
			//Only Start New PAINT if old is finished ;)
			if (!paintInProgress || overblendStyle == 0)
			{
				paintInProgress = true;

				PAINTSTRUCT ps;
				HDC hDC;

				if(!wParam)
					hDC = BeginPaint(hWnd, &ps);
				else
					hDC = (HDC) wParam;

				onPaint(hDC);

				if(!wParam)
					EndPaint(hWnd, &ps);

				paintInProgress = false;
			}

			return true;
		}

		case WM_SIZE:
		{
			onSize((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_TIMER:
		{
			onTimer((int) wParam);
			return true;
		}

		case WM_WINDOWPOSCHANGED:
		{
			onWindowPosChanged((WINDOWPOS *) lParam);
			return false;
		}
	}

	return false;
}

LRESULT Label::windowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	Label *label = NULL;

	if(message == WM_NCCREATE)
	{
		label = (Label *) ((CREATESTRUCT *) lParam)->lpCreateParams;
		label->hWnd = hWnd;
		SetWindowLong(hWnd, 0, (LONG) label);
	}
	else
		label = (Label *) GetWindowLong(hWnd, 0);

	if(label)
	{
		LRESULT lResult = 0;

		if(label->onWindowMessage(message, wParam, lParam, lResult))
			return lResult;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

//------------------------------------------------------------
//Tooltips (Add, Update, Remove)
//------------------------------------------------------------

void Label::addHint(HWND hWnd, LPSTR caption)
{
	TOOLINFO ti;
	RECT clientRect;

	if (!TooltipHints)
		return ;
	GetClientRect(hWnd, &clientRect);
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = clientRect;
	ti.hinst = hInstance;
	ti.lpszText = caption;
	ti.lParam = 0;
	SendMessage(TooltipHints, TTM_ADDTOOL, 0, LPARAM(&ti));
}

void Label::updateHint(HWND hWnd, LPSTR caption)
{
	TOOLINFO ti;
	RECT clientRect;

	if (!TooltipHints)
		return ;
	GetClientRect(hWnd, &clientRect);
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = clientRect;
	ti.hinst = hInstance;
	ti.lpszText = caption;
	ti.lParam = 0;
	SendMessage(TooltipHints, TTM_UPDATETIPTEXT, 0, LPARAM(&ti));
}

void Label::removeHint(HWND hWnd)
{
	TOOLINFO ti;
	RECT emptyRect = {0, 0, 0, 0};

	if (!TooltipHints)
		return ;
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = emptyRect;
	ti.hinst = hInstance;
	ti.lpszText = NULL;
	ti.lParam = 0;
	SendMessage(TooltipHints, TTM_DELTOOL, 0, LPARAM(&ti));
}

//------------------------------------------------------------
//Initialize and Update AlphaTransparency
//------------------------------------------------------------
BOOL Label::UpdateWindowTransparent(HWND hWnd, unsigned char factor)
{
   /* First, see if we can get the API call we need. If we've tried
    * once, we don't need to try again. */
   if (!initialized)
   {
		HMODULE hDLL = LoadLibrary ("user32");

		pSetLayeredWindowAttributes = 
		  (PSLWA) GetProcAddress(hDLL, "SetLayeredWindowAttributes");

		//pUpdateLayeredWindow = 
		//	(PULW) GetProcAddress(hDLL, "UpdateLayeredWindow");

		initialized = TRUE;
   
	   if (pSetLayeredWindowAttributes == NULL /*|| pUpdateLayeredWindow == NULL*/)
		  return FALSE;
  
	   SetLastError(0);

	   if (GetLastError())
		  return FALSE;
	}

   /* Now, we need to set the 'layered window attributes'. This
    * is where the alpha values get set. */
  
	return pSetLayeredWindowAttributes (hWnd, 0, factor, LWA_ALPHA);
}
