Menu Version Super Alpha (12/3/02)
by Nathan Moore (luthe) 
-----------------------------

*******************************
What:
*******************************
Menu attempts (for the moment at least) to be a drop in replacement for Popup2.

*******************************
Use:
*******************************
add it to your step.rc AFTER popup2.  This way should allow popup2 to handle the shift + left click menu, and any other menus that are defined. As Menu only handles one popup at this time.

*******************************
What works:
*******************************
1) Plan old folders of the type:
	*Popup "Windows" Folder
		~bunch of stuff~
	*Popup ~Folder

2) PopupFolders:
	*Popup "Start Menu" !PopupFolder:"$Programs$|$CommonPrograms$"
Please note that the path given for the PopupFolder MUST have a closing backslash.  Popup2 is much more forgiving, so you migh not have them.
	Good: "C:\Folder\"
	Bad:  "C:\Folder"
When it scans the directory Menu will ignore hidden files, alphabetize the contents, handle entries with multiple directories, remove the extention from shortcuts, and handle collision of directories. This is most complete part of menu. 

Do not try to use a non-dynamic folder on an extreamly large set, something like an whole harddrive.
	*Popup "C:\" !Folder:"C:\"
This will cause menu to attempt to index the whole thing. Litestep will stop responding, and possibly windows, if it does start responding again, menu might not do anything but hold a large amount of memory and nothing else.

3) Normal Entries:
	*Popup "My Computer" "$LiteStepDir$shortcuts\My Computer.lnk"
Most of these will work (I hope). Ones like
	*Popup "Regedit" regedit
will not work.

4) Bang Commands:
	*Popup "Run..." !Run
All bang commands that don't take arguments, and that are not psudeo-bang commands used by Popup2 (!PopupTasks, etc.) if your not sure try it it may work.

5) Separators:
	*Popup !Separator

*******************************
What does not work:
*******************************
1) DynamicFolders:
	*Popup "Programs" !DynamicFolder:$Programs$
	*Popup "Programs" !PopupDynamicFolder:$Programs$
Neither of these is implemented.  Do not try to use a non-dynamic folder on an extreamly large set, something like an whole harddrive.
	*Popup "C:\" !Folder:"C:\"
This will cause menu to attempt to index the whole thing. Litestep will stop responding, and possibly windows, if it does start responding again, menu might not do anything but hold a large amount of memory and nothing else.

2) Icons
Icons are not implemented either.  having the .icons=""s in your RCs will cause no difficultly they are simply ignored.

3) Normal Entries:
See Above

4) Bang Commands
See Above

5) Anything else that does not work:

*******************************
Additional Notes
*******************************
This is a very alpha release.  The current plan is to mimic popup2's functions, but by using the native menu wigets.  I may switch to a different syntax for the menu at some point. The final version may look nothing at like this.

As always if this program should cause unspeakable damage to you compute I take no responsiblity for it. Use at your own risk. Although I don't expect that it will do that, at most I expect it won't work.

-Nathan Moore
