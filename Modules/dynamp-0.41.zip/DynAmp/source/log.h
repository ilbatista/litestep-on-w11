// set this to activate all out logging

//#define DEBUG

#ifdef DEBUG
	const char logName[] = "DynAmp";
#endif