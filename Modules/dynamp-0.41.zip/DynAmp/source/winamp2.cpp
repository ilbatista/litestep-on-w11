#include "winamp2.h"
#include "log.h"
#include "..\current\lsapi\lsapi.h"

// initialize this static variables
int wa2::position = 0;

// constructors:

wa2::wa2()
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, logName, "loading wa2 control");
#endif

	// load string where to launch the program from
	GetRCString("WinampPath", szAmpPath, "c:\\progra~1\\winamp\\winamp.exe", MAX_LINE_LENGTH);

	// load the !bang command for this player
	char szTemp[MAX_LINE_LENGTH];
	GetRCLine("DynAmpOnWA2", szTemp, MAX_LINE_LENGTH, "!NONE"); // WA2 load command
	OnPlayerLoad = new char[strlen(szTemp)+1];
	strcpy(OnPlayerLoad, szTemp);

	// if there is a command to run
	if ( OnPlayerLoad != NULL )
	{
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "Running Command: %s", OnPlayerLoad);
#endif
		LSExecute(GetLitestepWnd(), OnPlayerLoad, NULL);
	}

	// specific wa2 functions, needs to be defined as static and placed in .h
	AddBangCommand("!Amp_StopFade", Bang_StopFade);

	AddBangCommand("!Amp_AddToPlaylist", Bang_AddToPlaylist);
	AddBangCommand("!Amp_StopAfterTrack", Bang_StopAfterTrack);
	AddBangCommand("!Amp_PlayCD", Bang_PlayCD);

	AddBangCommand("!Amp_ReloadSkin", Bang_ReloadSkin);
	AddBangCommand("!Amp_DoubleSize", Bang_DoubleSize);
	AddBangCommand("!Amp_EditID3", Bang_EditID3);
	AddBangCommand("!Amp_AddSong", Bang_AddSong);
	AddBangCommand("!Amp_LoadEQPreset", Bang_LoadEQPreset);
	AddBangCommand("!Amp_HighPriority", Bang_HighPriority);
	AddBangCommand("!Amp_About", Bang_About);
	AddBangCommand("!Amp_EasyMove", Bang_EasyMove);
	AddBangCommand("!Amp_Eq", Bang_Eq);
	AddBangCommand("!Amp_Jump10Back", Bang_Jump10Back);
	AddBangCommand("!Amp_Jump10Fwd", Bang_Jump10Fwd);
	AddBangCommand("!Amp_JumpToFile", Bang_JumpToFile);
	AddBangCommand("!Amp_JumpToTime", Bang_JumpToTime);
	AddBangCommand("!Amp_ListEnd", Bang_ListEnd);
	AddBangCommand("!Amp_ListStart", Bang_ListStart);
	AddBangCommand("!Amp_MainMenuPopup", Bang_MainMenuPopup);
	AddBangCommand("!Amp_Playlist", Bang_Playlist);
	AddBangCommand("!Amp_SelectSkin", Bang_SelectSkin);
	AddBangCommand("!Amp_SetPanning", Bang_SetPanning);
	AddBangCommand("!Amp_SetVolume", Bang_SetVolume);
	AddBangCommand("!Amp_ShadeBoth", Bang_ShadeBoth);
	AddBangCommand("!Amp_ShadePlaylist", Bang_ShadePlaylist);
	AddBangCommand("!Amp_StartPlugin", Bang_StartPlugin);
	AddBangCommand("!Amp_StopPlugin", Bang_StopPlugin);
	AddBangCommand("!Amp_ToggleBrowser", Bang_ToggleBrowser);
	AddBangCommand("!Amp_VisSetup", Bang_VisSetup);
	AddBangCommand("!Amp_WindowShade", Bang_WindowShade);
	AddBangCommand("!Amp_Rew", Bang_Rew);
	AddBangCommand("!Amp_Ffwd10s", Bang_Ffwd10s);
	AddBangCommand("!Amp_Ffwd20s", Bang_Ffwd20s);
	AddBangCommand("!Amp_Rewd10s", Bang_Rew10s);
	AddBangCommand("!Amp_Rewd20s", Bang_Rew20s);
	AddBangCommand("!Amp_Restart", Bang_Restart);
	//AddBangCommand("!Amp_MovePosition", Bang_MovePosition);
	//AddBangCommand("!Amp_FileInfo", Bang_FileInfo);
	AddBangCommand("!Amp_PlayPause", Bang_PlayPause);
	AddBangCommand("!Amp_TimeRemaining", Bang_TimeRemaining);
	AddBangCommand("!Amp_TimeElapsed", Bang_TimeElapsed);

}

wa2::~wa2()
{
	// delete !bang commands
	if (OnPlayerLoad != NULL) {
		delete [] OnPlayerLoad;
		OnPlayerLoad = NULL;
	}

	RemoveBangCommand("!Amp_StopFade");

	RemoveBangCommand("!Amp_AddToPlaylist");
	RemoveBangCommand("!Amp_StopAfterTrack");
	RemoveBangCommand("!Amp_PlayCD");

	RemoveBangCommand("!Amp_ReloadSkin");
	RemoveBangCommand("!Amp_DoubleSize");
	RemoveBangCommand("!Amp_EditID3");
	RemoveBangCommand("!Amp_AddSong");
	RemoveBangCommand("!Amp_LoadEQPreset");
	RemoveBangCommand("!Amp_HighPriority");
	RemoveBangCommand("!Amp_About");
	RemoveBangCommand("!Amp_EasyMove");
	RemoveBangCommand("!Amp_EditID3");
	RemoveBangCommand("!Amp_Eq");
	RemoveBangCommand("!Amp_Ffwd5s");
	RemoveBangCommand("!Amp_Jump10Back");
	RemoveBangCommand("!Amp_Jump10Fwd");
	RemoveBangCommand("!Amp_JumpToFile");
	RemoveBangCommand("!Amp_JumpToTime");
	RemoveBangCommand("!Amp_ListEnd");
	RemoveBangCommand("!Amp_ListStart");
	RemoveBangCommand("!Amp_MainMenuPopup");
	RemoveBangCommand("!Amp_Playlist");
	RemoveBangCommand("!Amp_SelectSkin");
	RemoveBangCommand("!Amp_SetPanning");
	RemoveBangCommand("!Amp_SetVolume");
	RemoveBangCommand("!Amp_ShadeBoth");
	RemoveBangCommand("!Amp_ShadePlaylist");
	RemoveBangCommand("!Amp_StartPlugin");
	RemoveBangCommand("!Amp_StopPlugin");
	RemoveBangCommand("!Amp_ToggleBrowser");
	RemoveBangCommand("!Amp_VisSetup");
	RemoveBangCommand("!Amp_WindowShade");
	RemoveBangCommand("!Amp_Rew");
	RemoveBangCommand("!Amp_Ffwd10s");
	RemoveBangCommand("!Amp_Ffwd20s");
	RemoveBangCommand("!Amp_Rewd10s");
	RemoveBangCommand("!Amp_Rewd20s");
	RemoveBangCommand("!Amp_Restart");
	//RemoveBangCommand("!Amp_MovePosition");
	//RemoveBangCommand("!Amp_FileInfo");
	RemoveBangCommand("!Amp_PlayPause");
	RemoveBangCommand("!Amp_TimeRemaining");
	RemoveBangCommand("!Amp_TimeElapsed");
}


// functions:

void wa2::prev() 
{
	wa2Message(WINAMP_PREVSONG);
}

void wa2::play() {
	if (!PlayNotOpen)
	{
		if (!GetPlayerWnd())
		{
			playerOpen();
		}
	}
	wa2Message(WINAMP_PLAY);
}

void wa2::pause() 
{
	wa2Message(WINAMP_PAUSE);
}

void wa2::stop() 
{
	wa2Message(WINAMP_STOP);
}

void wa2::next() 
{
	wa2Message(WINAMP_NEXTSONG);
}

void wa2::loadFile() 
{
	if (!LoadFileNotOpen) 
	{
		if (!GetPlayerWnd())
			playerOpen();
	}
	SetForegroundWindow(GetPlayerWnd());
	wa2Message(WINAMP_FILE_PLAY); 
}

void wa2::shuffle() {
	wa2Message(WINAMP_FILE_SHUFFLE);
}

void wa2::repeat() {
	wa2Message(WINAMP_FILE_REPEAT);
}

void wa2::powerOff()
{
	wa2Message(WINAMP_FILE_QUIT);
}

void wa2::rewind5s() {
	wa2Message(WINAMP_REW5S);
}

void wa2::forward5s() {
	wa2Message(WINAMP_REW5S);
}

void wa2::volumeDown() {
	wa2Message(WINAMP_VOLUMEDOWN);
}

void wa2::volumeUp() {
	wa2Message(WINAMP_VOLUMEUP);
}

void wa2::onTop() {
	wa2Message(WINAMP_OPTIONS_AOT);
}

void wa2::loadDir() {
	SetForegroundWindow(GetPlayerWnd());
	wa2Message(WINAMP_FILE_DIR);
}

void wa2::openLoc() {
	wa2Message(WINAMP_OPEN_LOC);
}

void wa2::prefs() {
	if (!PrefsNotOpen) {
		if (!GetPlayerWnd())
			playerOpen();
	}
	wa2Message(WINAMP_OPTIONS_PREFS);
}

// This is our main message handler where all winamp message are passed to
void wa2::wa2Message(const int msg)
{
	player::sendMsg(GetPlayerWnd(), msg);
}

// find window handle
HWND wa2::GetPlayerWnd()
{
	return FindWindow(WC_WINAMP2, NULL);
}

// static functions:
void wa2::Bang_AddToPlaylist(HWND caller, LPCSTR args)
{
	plSendKey(WINAMP_ADDFILES2PL);		
}

void wa2::Bang_StopFade(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_BUTTON4_SHIFT);
}

void wa2::Bang_StopAfterTrack(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_BUTTON4_CTRL);
}

void wa2::Bang_PlayCD(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_PLAYCD);
}

void wa2::Bang_ReloadSkin(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_RELOAD_SKIN);
}

void wa2::Bang_DoubleSize(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_OPTIONS_DSIZE);
}

void wa2::Bang_TimeElapsed(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_OPTIONS_ELAPSED);
}

void wa2::Bang_TimeRemaining(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_OPTIONS_REMAINING);
}

void wa2::Bang_AddSong(HWND caller, LPCSTR args) {
	char addSong[MAX_LINE_LENGTH];
	strcat(addSong, szAmpPath);
	strcat(addSong, " /ADD ");
	strcat(addSong, args);
	WinExec(addSong, SW_NORMAL);
	strcpy(addSong, "");
}

void wa2::Bang_About(HWND caller, LPCSTR args) {
	SetForegroundWindow(getWA2wnd()); // You have to push the window forward before sending messages to keep it on top.
	sendMsg(WINAMP_HELP_ABOUT);
}

void wa2::Bang_EasyMove(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_OPTIONS_EASYMOVE);
}

void wa2::Bang_Eq(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_OPTIONS_EQ);
}

void wa2::Bang_Jump10Back(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_JUMP10BACK);
}

void wa2::Bang_Jump10Fwd(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_JUMP10FWD);
}
void wa2::Bang_JumpToFile(HWND caller, LPCSTR args) {
	SetForegroundWindow(getWA2wnd());
	sendMsg(WINAMP_JUMPFILE);
}

void wa2::Bang_JumpToTime(HWND caller, LPCSTR args) {
	SetForegroundWindow(getWA2wnd());
	sendMsg(WINAMP_JUMPTIME);
}

void wa2::Bang_ListEnd(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_LIST_END);
}

void wa2::Bang_ListStart(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_LIST_START);
}

void wa2::Bang_MainMenuPopup(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_MAINMENU);
}

void wa2::Bang_Playlist(HWND caller, LPCSTR args) {
	if (!PlaylistNotOpen) {
		if (!getWA2wnd())
			playerOpen();
	}
	sendMsg(WINAMP_OPTIONS_PLEDIT);
}

void wa2::Bang_SelectSkin(HWND caller, LPCSTR args) {
	SetForegroundWindow(getWA2wnd());
	sendMsg(WINAMP_OPTIONS_SKINS);
}

void wa2::Bang_SetPanning(HWND caller, LPCSTR args) {
	SendMessage(getWA2wnd(), WM_USER, (const int)args, WINAMP_USER_SETPANNING);  // Args = 0 - 255, 0 = all_left, 255 = all_right
}

void wa2::Bang_SetVolume(HWND caller, LPCSTR args) {
	SendMessage(getWA2wnd(), WM_USER, (const int)args, WINAMP_USER_SETVOLUME); 
}

void wa2::Bang_ShadeBoth(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_PLAYLIST_WINDOWSHADE);
	sendMsg(WINAMP_OPTIONS_WINDOWSHADE);
}

void wa2::Bang_ShadePlaylist(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_PLAYLIST_WINDOWSHADE);
}

void wa2::Bang_StartPlugin(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_VISPLUGIN);
}

void wa2::Bang_StopPlugin(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_VISPLUGIN);
}

void wa2::Bang_ToggleBrowser(HWND caller, LPCSTR args) {
	SetForegroundWindow(getWA2wnd());
	sendMsg(WINAMP_MINIBROWSER_TOGGLE);
}

void wa2::Bang_VisSetup(HWND caller, LPCSTR args) {
	SetForegroundWindow(getWA2wnd());
	sendMsg(WINAMP_VISSETUP);
}

void wa2::Bang_WindowShade(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_OPTIONS_WINDOWSHADE);
}

void wa2::Bang_Rew(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_REWIND);
}

void wa2::Bang_HighPriority(HWND caller, LPCSTR args) {
	sendMsg(WINAMP_HIGH_PRIORITY);
}

void wa2::Bang_LoadEQPreset(HWND caller, LPCSTR args) {
	SetForegroundWindow(getWA2wnd());
	sendMsg(IDM_EQ_LOADPRE);
}

void wa2::Bang_PlayPause(HWND caller, LPCSTR args) {
	if (!PlayPauseNotOpen) {
		if (!getWA2wnd())
			playerOpen();
	}
	int status = SendMessage(getWA2wnd(), WM_USER, 0, WINAMP_USER_STATUS);
	(status == 1) ? sendMsg(WINAMP_PAUSE) : sendMsg(WINAMP_PLAY);
}

void wa2::Bang_Ffwd10s(HWND caller, LPCSTR args) {
	MovePositive(10);
}

void wa2::Bang_Ffwd20s(HWND caller, LPCSTR args) {
	MovePositive(20);
}

void wa2::Bang_Rew10s(HWND caller, LPCSTR args) {
	MoveNegative(10);
}

void wa2::Bang_Rew20s(HWND caller, LPCSTR args) {
	MoveNegative(20);
}

void wa2::Bang_Restart(HWND caller, LPCSTR args) {
	SendMessage(getWA2wnd(), WM_USER, 0, WINAMP_USER_RESTART);
}

void wa2::Bang_EditID3(HWND caller, LPCSTR args)
{
	SetForegroundWindow(getWA2wnd());
	sendMsg(WINAMP_EDIT_ID3);
}

/*void wa2::Bang_MovePosition(HWND caller, LPCSTR args) {
	if (args) {
		char* tokens[1]; 
		char modifier[1]; // + or -
		char amount[10]; // amount to change by
		modifier[0] = amount[0] = 0; // nulling the first in the array
			
		tokens[0] = modifier;
		tokens[1] = amount;
			
		LCTokenize(args, tokens, 2, NULL);
		// if modifier is negative send to MoveNegative(), else MovePositive()
		(!strcmp(modifier, "-")) ? MoveNegative((int)amount) : MovePositive((int)amount);
	}
}*/

/*void wa2::fileInfo() {
// Getting the winamp title and removing the "-Winamp" from it
	GetWindowText(getWA2wnd(), song_title, sizeof(song_title));
	p = song_title + strlen(song_title) - 8;
	while (p >= song_title) 
	{
		if (!strnicmp(p, "- Winamp", 8))
			break;
		p--;
	}
	if (p >= song_title)
		p--;
	while (p >= song_title && *p == ' ') 
		p--;
	*++p = 0;
		
	samplerate = SendMessage(getWA2wnd(), WM_USER, 0, WINAMP_USER_BITRATE); // The samplerate of the current song
	bitrate = SendMessage(getWA2wnd(), WM_USER, 1, WINAMP_USER_BITRATE); // The bitrate of the current song
	channels = SendMessage(getWA2wnd(), WM_USER, 2, WINAMP_USER_BITRATE); // The channel status
	
	(channels == 1) ? strcpy(chan, "Mono") : strcpy(chan, "Stereo");
	sprintf(fileProp, "Bitrate: %d kbps\nSampleRate: %d khz\nChannels: %s", bitrate, samplerate, chan);
	MessageBox(GetLitestepWnd(), fileProp, song_title, MB_OK | MB_ICONQUESTION | MB_SETFOREGROUND);
}*/
// These are the main processing functions...

// Moves position backwards
void wa2::MoveNegative(int amount) {
	amount *= 1000;
	position = SendMessage(getWA2wnd(), WM_USER, 0, WINAMP_USER_SONGPOSITION);
	SendMessage(getWA2wnd(), WM_USER, position - amount, WINAMP_USER_SONGSEEK);
}

// Moves position forwards
void wa2::MovePositive(int amount) {
	amount *= 1000;
	position = SendMessage(getWA2wnd(), WM_USER, 0, WINAMP_USER_SONGPOSITION);
	SendMessage(getWA2wnd(), WM_USER, position + amount, WINAMP_USER_SONGSEEK);
}

void wa2::plSendKey(char ckey)
{
	player::sendKey(getWA2PE(), VkKeyScan(ckey));
}

void wa2::sendMsg(const int msg)
{
	player::sendMsg(getWA2wnd(), msg);
}

HWND wa2::getWA2PE()
{
	return FindWindow(WC_WINAMP2_PE, NULL);
}

HWND wa2::getWA2wnd()
{
	return FindWindow(WC_WINAMP2, NULL);
}
