/*
  MonitorFix LiteStep Module - version 1.0
	No C-RunTime Code

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/*	This file tells the linker not to link against the C-RunTime
		library and provides minimal versions of some of the functions
		required.

		You can not use global variables that require initialization
		because the runtime lib handles that, and this doesn't.

		If you pass a pointer to a local variable anywhere, you'll need
		to link to ntdll.lib (not sure what for win9x), which is included
		with the DDK.

		and, of course, you can't use standard C library functions, use
		the appropriate Win32 ones instead.  (or write your own)
*/
 
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#pragma comment(linker,"/nodefaultlib")
#pragma comment(linker,"-entry:DllMain")

extern "C" {
__declspec( dllexport ) BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpReserved );
}

BOOL WINAPI DllMain(
    HINSTANCE hinstDLL,  /* handle to DLL module        */ 
    DWORD fdwReason,     /* reason for calling function */ 
    LPVOID lpReserved )  /* reserved                    */ 
{
	return TRUE;
}


void* __cdecl operator new(unsigned int cb)
{
  return HeapAlloc(GetProcessHeap(),0,cb);
}

void __cdecl operator delete(void* pv)
{
  if(pv)
    HeapFree(GetProcessHeap(),0,pv);
}