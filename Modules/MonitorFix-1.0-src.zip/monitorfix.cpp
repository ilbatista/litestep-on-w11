/*
  MonitorFix LiteStep Module - version 1.0

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
 
#include "monitorfix.h"

const _TCHAR * const ModuleName = _T("MonitorFix");
const _TCHAR * const ModuleVersion = _T("1.0");
const _TCHAR * const ModuleAuthor = _T("RabidCow");

extern "C" {
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

Global Module;

int initModuleEx(HWND ParentWnd, HINSTANCE dll, LPCSTR szPath)
{
	const static UINT Msgs[] = {
		LM_GETREVID,
		LM_WINDOWCREATED,
		0
	};

	ZeroMemory(&Module,sizeof(Global));

	Module.hInstance = dll;

	WNDCLASS wc;
	ZeroMemory(&wc,sizeof(WNDCLASS));
	wc.lpfnWndProc = &WndProc;
	wc.hInstance = Module.hInstance;
	wc.lpszClassName = ModuleName;
	if (!RegisterClass(&wc)) 
	{
		MessageBox(ParentWnd,
			_T("Error registering window class.\n\nPerhaps the module did not unload properly?"),
			ModuleName,MB_OK|MB_ICONERROR);
		return 1;
	}

	Module.hWnd =
		CreateWindowEx(
			WS_EX_TOOLWINDOW,
			ModuleName,
			NULL,
			WS_POPUP,
			0, 0, 0, 0,
			NULL, NULL,
			Module.hInstance,
			NULL);

	SetWindowLong(Module.hWnd,GWL_USERDATA,magicDWord);

	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE,
		(WPARAM) Module.hWnd, (LPARAM) Msgs);

	Module.bAllCorners = GetRCBool("MonitorFixAllCorners",TRUE)!=FALSE;

	return 0;
}

int quitModule(HINSTANCE dll)
{
	DestroyWindow(Module.hWnd);
	UnregisterClass(ModuleName,Module.hInstance);

	return 0;
}

int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	return initModuleEx (ParentWnd, dllInst, (wd) ? wd->lsPath : NULL);
}

int quitWharfModule(HINSTANCE dllInst)
{
	return quitModule(dllInst);
}
