/*
  MonitorFix LiteStep Module - version 1.0

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
 
#include "monitorfix.h"

inline bool IsNormalWindow(HWND hWnd)
{
	LONG WS = GetWindowLong(hWnd,GWL_STYLE);
	LONG WS_EX = GetWindowLong(hWnd,GWL_EXSTYLE);

	if ((WS   &WS_POPUP)==WS_POPUP) return false;
	if ((WS_EX&WS_EX_TOOLWINDOW)==WS_EX_TOOLWINDOW) return false;
	return true;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case LM_WINDOWCREATED:
/*		 HSHELL_WINDOWCREATED:

			A top-level, unowned window has been created. The window exists when
		the system calls this hook.

	wParam: Handle to the created window.
	lParam: Nothing.
*/
		if (IsNormalWindow((HWND)wParam))
		{
			HMONITOR mMouse,mWindow;
			MONITORINFO miMouse,miWindow;
			HMONITOR mCorner[4];
			POINT ptMouse,ptCorner;
			RECT wArea;
			bool bShouldFix = false;

			GetCursorPos(&ptMouse);
			mMouse = MonitorFromPoint(ptMouse,MONITOR_DEFAULTTONEAREST);

			GetWindowRect((HWND)wParam,&wArea);

			if (Module.bAllCorners)
			{
				ptCorner.x = wArea.left; ptCorner.y = wArea.top;
				mCorner[0] = MonitorFromPoint(ptCorner,MONITOR_DEFAULTTONULL);
				ptCorner.x = wArea.right;
				mCorner[1] = MonitorFromPoint(ptCorner,MONITOR_DEFAULTTONULL);
				ptCorner.y = wArea.bottom;
				mCorner[2] = MonitorFromPoint(ptCorner,MONITOR_DEFAULTTONULL);
				ptCorner.x = wArea.left;
				mCorner[3] = MonitorFromPoint(ptCorner,MONITOR_DEFAULTTONULL);

				if (mCorner[0] != mMouse ||
						mCorner[1] != mMouse ||
						mCorner[2] != mMouse ||
						mCorner[3] != mMouse)
				{
					bShouldFix = true;
					mWindow = MonitorFromWindow((HWND)wParam,MONITOR_DEFAULTTONEAREST);
				}
			}
			else
			{
				mWindow = MonitorFromWindow((HWND)wParam,MONITOR_DEFAULTTONULL);

				if (mWindow != mMouse)
					bShouldFix = true;
			}

			if (bShouldFix)
			{
				miMouse.cbSize = miWindow.cbSize = sizeof(MONITORINFO);
				GetMonitorInfo(mMouse,&miMouse);
				GetMonitorInfo(mWindow,&miWindow);
				// get offset from window
				OffsetRect(&wArea,-miWindow.rcWork.left,-miWindow.rcWork.top);
				// make sure it's not in negative space (relative to monitor)
				if (wArea.left<0) OffsetRect(&wArea,-wArea.left,0);
				if (wArea.top<0) OffsetRect(&wArea,0,-wArea.top);
				// make it relative to final monitor
				OffsetRect(&wArea,miMouse.rcWork.left,miMouse.rcWork.top);
				// make sure it's on the monitor
				if (wArea.right>miMouse.rcWork.right)
				{
					wArea.left = miMouse.rcWork.right-(wArea.right-wArea.left);
					wArea.right = miMouse.rcWork.right;
					// make sure it fits on the monitor
					if (wArea.left<miMouse.rcWork.left)
						wArea.left = miMouse.rcWork.left;
				}
				if (wArea.bottom>miMouse.rcWork.bottom)
				{
					wArea.top = miMouse.rcWork.bottom-(wArea.bottom-wArea.top);
					wArea.bottom = miMouse.rcWork.bottom;
					if (wArea.top<miMouse.rcWork.top)
						wArea.top = miMouse.rcWork.top;
				}
				// move the window
				SetWindowPos((HWND)wParam,NULL,wArea.left,wArea.top,
					(wArea.right-wArea.left),(wArea.bottom-wArea.top),
					SWP_NOZORDER|SWP_NOACTIVATE);
			}
		}
		return 0;
	case LM_GETREVID: 
		{
			PTSTR buffer = (PTSTR)lParam;
			
			if (wParam == 0)
			{
				_tcscpy(buffer, ModuleName);
				_tcscat(buffer, _T(".dll: "));
				_tcscat(buffer, ModuleVersion);
				_tcscat(buffer, _T(" ("));
				_tcscat(buffer, ModuleAuthor);
				_tcscat(buffer, _T(")"));
			}
			else
			{
				_tcscpy(buffer, _T(""));
			}
			return _tcslen(buffer);
		}
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}


/*		 HCBT_CREATEWND:

			A window is about to be created. The system calls the hook procedure
		before sending the WM_CREATE or WM_NCCREATE message to the window. If
		the hook procedure returns a nonzero value, the system destroys the
		window; the CreateWindow function returns NULL, but the WM_DESTROY
		message is not sent to the window. If the hook procedure returns zero,
		the window is created normally.

			At the time of the HCBT_CREATEWND notification, the window has been
		created, but its final size and position may not have been determined
		and its parent window may not have been established. It is possible to
		send messages to the newly created window, although it has not yet
		received WM_NCCREATE or WM_CREATE messages. It is also possible to
		change the position in the z-order of the newly created window by
		modifying the hwndInsertAfter member of the CBT_CREATEWND structure.

	wParam: Specifies the handle to the new window.
	lParam: Specifies a long pointer to a CBT_CREATEWND structure containing
					initialization parameters for the window. The parameters include
					the coordinates and dimensions of the window. By changing these
					parameters, a CBTProc hook procedure can set the initial size and
					position of the window.
*/
