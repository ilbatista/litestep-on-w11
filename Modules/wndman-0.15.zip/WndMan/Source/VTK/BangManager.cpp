#include "BangManager.h"


void InsertBangs(const Bang banglist[], const int nrofbangs)
{
	if (banglist == NULL)
		return;

	for (int i = 0; i < nrofbangs; i++)
		AddBangCommand(banglist[i].bangName, *banglist[i].bangFunc);
}

void RemoveBangs(const Bang banglist[], const int nrofbangs)
{
	if (banglist == NULL)
		return;

	for (int i = 0; i < nrofbangs; i++)
		RemoveBangCommand(banglist[i].bangName);
}


BangManager::BangManager() :
	bInserted(false)
{
}

BangManager::~BangManager()
{
	if (bInserted)
		RemoveAllBangs();
}

void BangManager::AddBang(LPCSTR bangName, BangCommand* func)
{
	SafeString temp;
	temp.assign(bangName);
	bangs.insert(std::make_pair(bangName, (void*)func));
}

void BangManager::RemoveBang(LPCSTR bangName)
{
	for (BangStore::iterator i = bangs.begin(); i != bangs.end(); ++i)
	{
		if ( (*i).first == bangName )
			bangs.erase(i);
	}
}

void BangManager::InsertBangs()
{
	for (BangStore::iterator i = bangs.begin(); i != bangs.end(); ++i)
	{
		BangCommand* bangFunc = (BangCommand*) (*i).second;
		AddBangCommand( (*i).first.c_str(), bangFunc );
	}
	bInserted = true;
}

void BangManager::RemoveAllBangs()
{
	for (BangStore::iterator i = bangs.begin(); i != bangs.end(); ++i)
	{
		RemoveBangCommand( (*i).first.c_str() );
	}
	bInserted = false;
}