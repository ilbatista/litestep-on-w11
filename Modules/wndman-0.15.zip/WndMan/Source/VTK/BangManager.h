/*

	BangManager

	Author:	Vendicator

	Description:
	Simple functions & structs for handling the adding/removal of bangs into LiteStep.

	Requires:

	Changelog:
	[2003-05-28 - Vendicator]
	- First work?

*/

#ifndef __BANGMANAGER_H
#define __BANGMANAGER_H

#include <map>
#include <windows.h>
#include "lsapi_location.h"
#include "SafeString.h"

/*

EXAMPLE:

const Bang BangList[] =
{
	{ "!WndForeground", BangWndForeground }
};

// calculate how many bangs there are
const int NrOfBangs = sizeof(BangList) / sizeof(BangList[0]);

 */

struct Bang
{
	const char* bangName;
	BangCommand* bangFunc;
};

void InsertBangs(const Bang banglist[], const int nrofbangs);

void RemoveBangs(const Bang banglist[], const int nrofbangs);

class BangManager
{
public:
	BangManager();
	~BangManager();

	void AddBang(LPCSTR bangName, BangCommand* func);

	void RemoveBang(LPCSTR bangName);

	void InsertBangs();

	void RemoveAllBangs();
	
protected:
	typedef std::map<SafeString, void*> BangStore;
	BangStore bangs;
	bool bInserted;

};

#endif
