#ifndef __CLICKABLE_H
#define __CLICKABLE_H

#include <windows.h>
#include "SafeString.h"

enum MouseKey {
	LEFT_DBL,
	LEFT_DOWN,
	LEFT_UP,
	RIGHT_DBL,
	RIGHT_DOWN,
	RIGHT_UP,
	MIDDLE_DBL,
	MIDDLE_DOWN,
	MIDDLE_UP
};

class Clickable
{
public:
	Clickable(LPCTSTR prefix);
	~Clickable();

	void ReadClickSettings();
	bool MouseExecute(const int i);
	void SetMouseDefaults();
	void SetMouseKey(MouseKey key, LPCTSTR action);
	virtual HWND GetHWND() = 0;

private:
	SafeString Prefix;

	SafeString OnLeftDBL;
	SafeString OnLeftDown;
	SafeString OnLeftUp;
	SafeString OnRightDBL;
	SafeString OnRightDown;
	SafeString OnRightUp;
	SafeString OnMiddleDBL;
	SafeString OnMiddleDown;
	SafeString OnMiddleUp;

};

#endif