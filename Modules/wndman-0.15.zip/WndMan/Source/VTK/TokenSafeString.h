/*

	TokenSafeString

	Author:	Vendicator

	Description:
	This adds tokenizing to the SafeString class

	Changelog:
	[2003-07-01 - Vendicator]
	- First work.

*/

#ifndef __TOKENSAFESTRING_H
#define __TOKENSAFESTRING_H

#include "lsapi_location.h"
#include "SafeString.h"
#include <tchar.h>

#define MAX_STRING_LENGTH STRSAFE_MAX_CCH - 1
#define MAX_NUMBER_LENGTH 64

#ifndef _T
#define _T(str) TEXT(str)
#endif

class TokenSafeString : public SafeString
{
public:
	TokenSafeString() :
		nTokens(0)
	{
	}

	TokenSafeString(LPCTSTR str) :
		SafeString(str),
		nTokens(0)
	{
		assign(str);
	}

	TokenSafeString(size_t size) :
		SafeString(size),
		nTokens(0)
	{
	}

	~TokenSafeString()
	{
		ClearTokens();
	}

#define TOKENSIZE 256
	int Tokenize(int nr_tokens)
	{
		if (nTokens != 0)
			ClearTokens();

		nTokens = nr_tokens;
		tokens = new char*[nTokens];
		for (int i = 0; i < nTokens; ++i)
		{
			tokens[i] = new char[TOKENSIZE];
		}
		
		extra_text[0] = '\0';
		
		int count = LCTokenize(char_str(), tokens, nr_tokens, extra_text);		
		return count;
	}

	char* GetToken(int nr)
	{
		if (nr >= 0 && nr < nTokens)
		{
			return tokens[nr];
		}
		else
			return NULL;
	}

	char* GetExtra()
	{
		return extra_text;
	}

	void ClearTokens()
	{
		for (int i = 0; i < nTokens; ++i)
		{
			delete [] tokens[i];
		}
		delete tokens;
		nTokens = 0;
	}

protected:
	char extra_text[MAX_LINE_LENGTH];
	char** tokens;
	int nTokens;

};

#endif