/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __WNDMAN_H
#define __WNDMAN_H

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <stdlib.h>
#include <shellapi.h>

#include "..\current\lsapi\lsapi.h"
#include "..\current\lsapi\lswinbase.h"
#include "../VTK/SafeString.h"
#include "WndIdentifier.h"

#include <map>
#include <list>
using namespace std;

class Wndman : public Window
{
// data
protected:
	typedef map<WndIdentifier*, SafeString*> WndSettings;
	WndSettings wnd_create;
	map<HWND, RECT> shadedWindows;
	list<HWND> trayedWindows;
	list<HWND> createdWindows;

// functions
public:
	Wndman(HWND parentWnd, int& code);
	~Wndman();

	// window finders:
	HWND getFocusHWND();
	HWND getActiveHWND();
	HWND getForegroundHWND();

	HWND getHWNDBelow(HWND window);
	HWND getHWNDAbove(HWND window);
	HWND getHWNDhelper(LPCSTR args);
	BOOL returnHWNDAndCoords(HWND *window, int *x, int *y, LPCSTR args);

	// trayfunctions
	BOOL TraySend(HWND window);
	BOOL TrayRestore(HWND window);
	BOOL TrayRestoreAll();

	void WindowInfo(HWND window, BOOL alert);

	// opacity functions
	void setHWNDAlpha(HWND window, int Alpha);
	int getHWNDAlpha(HWND window);

	// size & positioning
	void getWndSize(HWND window, int* x, int* y);
	void WndSize(HWND window, const int sizeProp, int x, int y);
	void WndPos(HWND window, const int moveProp, int x, int y);
	void UnShadeAll();
	void ShadeToggle(HWND window);
	BOOL IsWindowShaded(HWND window);

	// bang functions
	void WindowForeground(HWND wnd);
	void WindowPushBottom(HWND wnd);
	void WindowPushBack(HWND wnd);
	void WindowSetOpacity(LPCSTR args);
	void WindowOnTop(HWND, LPCSTR);
	void WindowHide(HWND window);
	void WindowRestore(HWND window);
	void WindowMaxToggle(HWND window);
	void WindowMaximize(HWND window);
	void WindowMinimize(HWND window);
	void WindowClose(HWND window);
	void WindowDestroy(HWND window);

	void WindowAllInfo(HWND, LPCSTR);

protected:

	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
	void onTray(Message& message);
	void onNewWindow(Message& message);
	void onCreate(Message& message);
	void onDestroy(Message& message);

	// helpers
	HWND GetAppWindow(HWND window);
	HWND getTargetHWND(int window_code);
	char *isToolTipHWND(HWND window);

	void setHWNDNoAlpha(HWND window);
	void setHWNDAcceptAlpha(HWND window);
	void hideHWNDVWM(HWND window);

	HICON GetIconFromWindow( HWND hWnd, BOOL bBigIcon );

};

void BangWndForeground(HWND caller, LPCSTR args);
void BangWndPushBottom(HWND caller, LPCSTR args);
void BangWndPushBack(HWND caller, LPCSTR args);
void BangWndSetOpacity(HWND caller, LPCSTR args);
void BangWndOnTop(HWND caller, LPCSTR args);
void BangWndHide(HWND caller, LPCSTR args);
void BangWndRestore(HWND caller, LPCSTR args);
void BangRestoreAll(HWND caller, LPCSTR args);
void BangWndMaxToggle(HWND caller, LPCSTR args);
void BangWndMaximize(HWND caller, LPCSTR args);
void BangWndMinimize(HWND caller, LPCSTR args);
void BangMinimizeAll(HWND caller, LPCSTR args);
void BangWndDestroy(HWND caller, LPCSTR args);
void BangWndClose(HWND caller, LPCSTR args);

// info
void BangWndInfo(HWND caller, LPCSTR args);
void BangWndAllInfo(HWND caller, LPCSTR args);

// sizing (shade)
void BangWndShade(HWND caller, LPCSTR args);
void BangWndUnShade(HWND caller, LPCSTR args);
void BangUnShadeAll(HWND caller, LPCSTR args);
void BangWndToggleShade(HWND caller, LPCTSTR args);

// sizing
void BangWndSize(HWND caller, LPCSTR args);
void BangWndSizeGrow(HWND caller, LPCSTR args);
void BangWndSizeMax(HWND caller, LPCSTR args);

// moving
void BangWndMoveHome(HWND caller, LPCSTR args);
void BangWndMoveCenter(HWND caller, LPCSTR args);
void BangWndMove(HWND caller, LPCSTR args);
void BangWndMoveDelta(HWND caller, LPCSTR args);

// traying
void BangSendToTray(HWND caller, LPCSTR args);
void BangRestoreFromTray(HWND caller, LPCSTR args);
void BangRestoreAllFromTray(HWND caller, LPCSTR args);

void BangHideModules(HWND caller, LPCSTR args);
void BangShowModules(HWND caller, LPCSTR args);


extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
