#ifndef __AUTOWNDHANDLER_H
#define __AUTOWNDHANDLER_H

#include "WindowDefines.h"
#include <windows.h>

class AutomatedWndHandler
{
public:
	virtual BOOL WorkOn(HWND hWnd) = 0;
};

class LSModuleHider : public AutomatedWndHandler
{
public:
	BOOL WorkOn(HWND hWnd)
	{
		if (IsWindow(hWnd) &&
			IsWindowVisible(hWnd) &&
			(GetWindowLong(hWnd, GWL_USERDATA) == magicDWord)
		)
		{
			SetWindowLong(hWnd, GWL_USERDATA, HIDEmagicDWord);
			ShowWindow(hWnd, SW_HIDE);
		}
		return TRUE;
	}

};

class LSModuleShower : public AutomatedWndHandler
{
public:
	BOOL WorkOn(HWND hWnd)
	{
		if (IsWindow(hWnd) &&
			(GetWindowLong(hWnd, GWL_USERDATA) == HIDEmagicDWord)
		)
		{
			SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
			ShowWindow(hWnd, SW_SHOW);
		}
		return TRUE;
	}

};

class WndMinimizer : public AutomatedWndHandler
{
public:
	BOOL WorkOn(HWND hWnd)
	{
		if ( GetWindowLong(hWnd, GWL_USERDATA) != magicDWord &&
		        !(GetWindowLong(hWnd, GWL_STYLE) & WS_CHILD) &&
		         (GetWindowLong(hWnd, GWL_STYLE) & WS_VISIBLE) &&
		        !(GetWindowLong(hWnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
		)
		{
			ShowWindow(hWnd, SW_MINIMIZE);
		}
		return TRUE;
	}

};

class WndRestorer : public AutomatedWndHandler
{
public:
	BOOL WorkOn(HWND hWnd)
	{
		if ( GetWindowLong(hWnd, GWL_USERDATA) != magicDWord &&
		        !(GetWindowLong(hWnd, GWL_STYLE) & WS_CHILD) &&
		        (GetWindowLong(hWnd, GWL_STYLE) & WS_VISIBLE) &&
		        !(GetWindowLong(hWnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
		)
		{
			ShowWindow(hWnd, SW_RESTORE);
		}
		return TRUE;
	}

};

class WndHandlerHolder
{
public:
	AutomatedWndHandler* GetLSHider()
	{
		return &ls_hider;
	}

	AutomatedWndHandler* GetLSShower()
	{
		return &ls_shower;
	}

	AutomatedWndHandler* GetWndMinimizer()
	{
		return &wnd_minimizer;
	}

	AutomatedWndHandler* GetWndRestorer()
	{
		return &wnd_restorer;
	}

protected:
	LSModuleHider ls_hider;
	LSModuleShower ls_shower;
	WndMinimizer wnd_minimizer;
	WndRestorer wnd_restorer;
};

#endif