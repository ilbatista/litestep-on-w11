#ifndef __WINDOWDEFINES_H
#define __WINDOWDEFINES_H

// if this hasn't been defined from lsapi

#ifndef HIDEmagicDWord
#define HIDEmagicDWord 0x59474541
#endif // HIDEmagicDWord

#ifndef magicDWord
#define magicDWord 0x49474541
#endif // magicDWord

enum
{
	ACTIVE_WINDOW	=	1,
	FOREGROUND_WINDOW,
	FOCUS_WINDOW
} WINDOWTYPES;

// for alpha trans
#define WS_EX_LAYERED           0x00080000
#define LWA_COLORKEY            0x00000001
#define LWA_ALPHA               0x00000002

// size properties:
enum
{
	SIZE_DELTA	=	101,
	SIZE_SET,
	SIZE_SHADE,
	SIZE_UNSHADE,
	SIZE_MAX
} SIZE_PROPS;

enum
{
	MOVE_DELTA	=	201,
	MOVE_SET,
	MOVE_HOME,
	MOVE_CENTER
} MOVE_PROPS;

#define WM_ICON_NOTIFY	WM_USER+10

#endif

