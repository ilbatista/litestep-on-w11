#ifndef __WNDIDENTIFIER_H
#define __WNDIDENTIFIER_H

#include "../VTK/SafeString.h"
#include "../VTK/apis.h"
#include <windows.h>

class WndIdentifier
{
public:
	WndIdentifier(SafeString classname, SafeString title) :
		sClassname(classname),
		sTitle(title)
	{
	}

	~WndIdentifier()
	{
	}

	bool Match(const HWND& window)
	{
		TCHAR cname[128];
		TCHAR* buffer;

		GetClassName(window, cname, sizeof(cname)/sizeof(cname[0]) );
		//_LSLogPrintf(LOG_DEBUG, "match", "check on: %s, %s %d", sClassname.c_str(), sTitle.c_str(), sTitle.length());

		if ( sClassname.str_find(cname) )
		{
			if (sTitle.length() > 0)
			{
				bool match;
				int length = GetWindowTextLength(window);
				buffer = new TCHAR[length+1];				
				GetWindowText(window, buffer, length+1); // copy length inc. NULL
				match = (_tcsstr(buffer, sTitle.c_str()) != NULL);
				//_LSLogPrintf(LOG_DEBUG, "match", "check: %s, %s, res: %d", sTitle.c_str(), buffer, match);
				delete [] buffer;
				return match;
			}
			else
				return true;
		}
		else
		{
			return false;
		}
	}

	bool operator== (const HWND& window)
	{
		return Match(window);
	}

public:
	SafeString sClassname;
	SafeString sTitle;
};

#endif