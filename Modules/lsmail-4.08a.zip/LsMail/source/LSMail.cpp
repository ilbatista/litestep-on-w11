/* Changelog:
 * 2002-07-24 (Vendicator):
 * - More move to OOP
 * - Fixed memleak in !bang commands removal when recycling
 * - Added !LsMailHook for lsbox support
 * - Added LSMailNoMessageBoxes, which sends errors as warnings to log file
 * - Started rewrite to a more OOP layout, will make it easier to add other server types
 * - Added LSMailDoneCheckCmd, per request of Maestr0
 *
 * 2002-05-29 (Vendicator):
 * - Added a check so that the password actually is set in .rc if not old style is used
 * - LsMail no longer shows up in taskmanager
 * - Added killing of lsmail thread on quit, might fix the ls crash on recycle when lsmail was checking.
 * - Added LSMailCheckMailCmd, per request of morph, originally added by ilmcuts
 *
 * 2002-05-11 (Jesus_mjjg):
 * - now it is possible to specify the password in the step.rc
 *
 * 2002-04-18 (Vendicator):
 * - Added a !bang for when there is no mail (LSMailNoMailCmd	!bang)
 *
 * 2002-04-17 (Vendicator):
 * - Implemented bitmap for checking state (LSMailCheckingBmp)
 * - Fixed clearing/setting of new mail flag (was only taking one server into account before)
 * - Added ability to execute a !bang command on new mail (LSMailNewMailCmd	!bang)
 * 
 * 2002-04-16 (Vendicator):
 * - Clear new mail in popup now works again (was tied to left click action)
 * 
 * 2002-04-16 (Vendicator):
 *	- Since the mail checking routine also clears the new mail flag when
 *    there is no mail on server, left click action is now checkmail.
 *
 * 2002-04-15 (Vendicator):
 *  - Added X,Y reading through GetRCCooridinate
 *  - Now clears new mail flag if 0 mail found on server
 */

// Includes
#include <windows.h>
#include <wininet.h>
#include "../current/lsapi/lsapi.h"
#include "exports.h"
#include "resource.h"

// Definitions
#define POPUP_CHECKMAIL 200
#define POPUP_CLEARNEWMAIL 201
//#define POPUP_ZEROACCOUNTS 202
#define POPUP_LAUNCHCLIENT 203
#define POPUP_DISPLAYERROR 204
#define POPUP_SERVER 220

enum {
	MAIL_NO,
	MAIL_EXISTS,
	MAIL_NEW
};

#define WC_SHELLDESKTOP		"DesktopBackgroundClass"

// Function Definitions
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CheckMail();
char* encrypt(char* pass);
void LoadSetup();
char* ReceiveData(SOCKET conn_socket);
void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp);

// Module Name
const char szAppName[] = "LSMail"; // Our window class, etc

const char rcsRevision[] = "4.0a$"; // Our Version*/
const char rcsId[] = "LSMail v4.08a (MrJukes / Vendicator / Jesus_mjjg)"; // The Full RCS ID.*/

int ScreenX, ScreenY;
char lsdir[256] = "";
int msgs[] = {LM_GETREVID, 0};

HMENU popup=NULL;
HFONT font;

char TEMP_PASS[256] = "";
char TEMP_SERVER[256] = "";
DWORD threadID;
char MAILCLIENT[MAX_PATH] = "";
char *NewMailCmd, *NoMailCmd, *CheckMailCmd, *DoneCheckCmd;
char ERR[256] = "";

class LSMAIL
{
public:
	LSMAIL();
	~LSMAIL();
	int Status();

	HINSTANCE hInstance;
	HANDLE CheckThread;
	HWND hWnd;
	HWND hWndParent;

	BOOL lsboxed;
	BOOL bNoMessageBoxes;

	COLORREF color, nmcolor, checkcolor, bgcolor;
	HBRUSH bgbrush, nmbgbrush, checkbgbrush;
	HBITMAP bgbmp, newmailbmp, checkingbmp;
	BOOL USEBGCOLOR;
	int TIMER;

	int x, y, w, h;

	BOOL CHECKING;
	BOOL NEWMAIL;
	int MAIL_STATUS;
	int NumServers;
};

LSMAIL::LSMAIL()
{
	CHECKING = FALSE;
	NEWMAIL = FALSE;
	MAIL_STATUS = MAIL_NO;
	NumServers = 0;
}

LSMAIL::~LSMAIL()
{
}

LSMAIL *mail;

class SERVER
{
public:
	SERVER();
	~SERVER();

	POP3Check();

	char* name;
	char* host;
	char* login;
	char* password;
	int ID, x, y, port, num, newnum, MAIL_STATUS;
	BOOL bERROR;
	HMENU menu;

	SERVER* next;
} *Servers;

SERVER::SERVER()
{
	ID=mail->NumServers++;
	newnum=num=0; 
	MAIL_STATUS = MAIL_NO;
	bERROR=FALSE;
	next=NULL;
	name = host = login = password = NULL;

	menu = CreatePopupMenu();
	AppendMenu(menu, MF_ENABLED | MF_STRING, POPUP_SERVER+ID+1, "&Change Password");
}

SERVER::~SERVER()
{
	DestroyMenu(menu);
}

void BangHook(HWND caller, LPCTSTR szArgs)
{
	LSLog(LOG_DEBUG, szAppName, "Attempting to hook to LSBox");
	char *handle = strrchr(szArgs,' ');
	if (handle) 
	{
		HWND boxwnd = (HWND)atoi(handle+1);
		if (boxwnd) 
		{
			mail->lsboxed = TRUE;
			if (boxwnd != GetParent(mail->hWnd))
			{
				SetWindowLong(mail->hWnd, GWL_STYLE, (GetWindowLong(mail->hWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
				SetParent(mail->hWnd, boxwnd);
			}
			LSLog(LOG_DEBUG, szAppName, "Hooking to LSBox successful");
		}
		else
			LSLog(LOG_DEBUG, szAppName, "Hooking to LSBox failed");
	}
	return;
}

void BangShow(HWND caller, const char* args)
{
	ShowWindow(mail->hWnd, SW_SHOW);
}

void BangHide(HWND caller, const char* args)
{ 
	ShowWindow(mail->hWnd, SW_HIDE);
}

void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(mail->hWnd))
		BangHide(caller, args);
	else
		BangShow(caller, args);
}

void BangCheckMail(HWND caller, const char* args)
{
	mail->CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
}

void LoadSetup()
{
	int size;
	char temp[256];

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	mail->bNoMessageBoxes = GetRCBool("LSMailNoMessageBoxes", TRUE);

	mail->x = GetRCCoordinate("LSMailX", 0, GetSystemMetrics(SM_CXSCREEN));
	mail->y = GetRCCoordinate("LSMailY", 0, GetSystemMetrics(SM_CYSCREEN));
	mail->w = GetRCInt("LSMailW", 400);
	mail->h = GetRCInt("LSMailH", 25);

	mail->TIMER=GetRCInt("LSMailTimer", 5);
	size = GetRCInt("LSMailFontSize", 12);
	GetRCString("LSMailFont", temp, "Arial", 256);
	font = CreateFont(size, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);
	mail->color = GetRCColor("LSMailFontColor", 0x00FFFFFF);
	mail->nmcolor = GetRCColor("LSMailNewMailFontColor", 0x000000FF);
	mail->checkcolor = GetRCColor("LSMailCheckingFontColor", 0x000000FF);

	mail->USEBGCOLOR = GetRCBool("LSMailBackColor", TRUE);
	if (mail->USEBGCOLOR) 
	{
		mail->bgcolor = GetRCColor("LSMailBackColor", 0x00000000);
		mail->bgbrush = CreateSolidBrush(mail->bgcolor);

		mail->bgcolor = GetRCColor("LSMailBackNewMailColor", 0x00FF0000);
		mail->nmbgbrush = CreateSolidBrush(mail->bgcolor);

		mail->bgcolor = GetRCColor("LSMailBackCheckingColor", 0x00000000);
		mail->checkbgbrush = CreateSolidBrush(mail->bgcolor);
	}
	else {
		GetRCString("LSMailBackBmp", temp, "", 256);
		mail->bgbmp = LoadLSImage(temp, temp);

		GetRCString("LSMailNewMailBmp", temp, "", 256);
		mail->newmailbmp = LoadLSImage(temp, temp);

		GetRCString("LSMailCheckingBmp", temp, "", 256);
		mail->checkingbmp = LoadLSImage(temp, temp);
	}

	GetRCString("LSMailEMailClient", MAILCLIENT, "", MAX_PATH);
	
	GetRCLine("LSMailCheckMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // new mail command
	CheckMailCmd = new char[strlen(temp)+1];
	strcpy(CheckMailCmd, temp);

	GetRCLine("LSMailNewMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // new mail command
	NewMailCmd = new char[strlen(temp)+1];
	strcpy(NewMailCmd, temp);

	GetRCLine("LSMailNoMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // no mail command
	NoMailCmd = new char[strlen(temp)+1];
	strcpy(NoMailCmd, temp);

	GetRCLine("LSMailDoneCheckCmd", temp, MAX_LINE_LENGTH, "!NONE"); // done check command
	DoneCheckCmd = new char[strlen(temp)+1];
	strcpy(DoneCheckCmd, temp);

	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CHECKMAIL, "&Check Mail");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_LAUNCHCLIENT, "&Launch E-Mail Client");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CLEARNEWMAIL, "Clear &New Mail");
	//AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_ZEROACCOUNTS, "&Zero All Accounts");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_DISPLAYERROR, "&Display Last Error");
	AppendMenu(popup, MF_SEPARATOR, 0, "");

	//
	// *LSMailServer X Y Name host:<port> login
	FILE* step;
	char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], token6[4096], extra_text[4096];
	char*	tokens[6];

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	tokens[5] = token6;
	
	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);
	
	while (LCReadNextConfig(step, "*LSMailServer", temp, 256)) 
	{ 
		int count;

		token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = extra_text[0] = '\0';
		count = LCTokenize (temp, tokens, 6, extra_text);

		if (count == 6)
		{
			SERVER* s = new SERVER;
			s->x = atoi(token2);
			s->y = atoi(token3);
			s->name = _strdup(token4);
			
			// blah.blah.blah.blah:80
			char* p = strtok(token5, ":");
			s->host = _strdup(p);
			p = strtok(NULL, "");
			if (p) s->port = atoi(p);
			else s->port = 110;
			
			s->login = _strdup(token6);
			if (extra_text[0] != '\0')
			{
				LSLog(LOG_DEBUG, szAppName, "Found password for mail server in config");
				s->password = _strdup(extra_text); //jesus_mjjg
			}

			AppendMenu(popup, MF_ENABLED | MF_STRING | MF_POPUP, (int)s->menu, s->name);

			if (Servers)
				s->next = Servers;
			Servers = s;
		}
	}
	LCClose(step);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	strcpy(lsdir, szPath);

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}

	mail = new LSMAIL();
	mail->lsboxed = false;
	mail->hWndParent = parent;
	mail->hInstance = dllInst;

	AddBangCommand("!LSMailShow", BangShow);
	AddBangCommand("!LSMailHide", BangHide);
	AddBangCommand("!LSMailToggle", BangToggle);
	AddBangCommand("!LSMailCheckMail", BangCheckMail);
	AddBangCommand("!LSMailHook", BangHook);

	LoadSetup();

	HWND desktop;
    desktop = FindWindow(WC_SHELLDESKTOP, NULL);
    if (!desktop)
		desktop = GetDesktopWindow();

	mail->hWnd = CreateWindowEx(WS_EX_TOOLWINDOW, 
		szAppName, szAppName, 
		WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 
		mail->x, mail->y, 
		mail->w, mail->h, 
		desktop, NULL, dllInst, NULL);
		
	if (!mail->hWnd) return 1;
	
	if (mail->bgbmp && !mail->USEBGCOLOR) SetWindowBitmapRgn(mail->hWnd, mail->bgbmp);

	if (GetRCBool("LSMailStartHidden", FALSE)) ShowWindow(mail->hWnd, SW_SHOW);
	if (GetRCBool("LSMailAlwaysOnTop", TRUE)) SetWindowPos(mail->hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);

	SetWindowLong(mail->hWnd, GWL_USERDATA, magicDWord);
	SendMessage(mail->hWndParent, LM_REGISTERMESSAGE, (WPARAM)mail->hWnd, (LPARAM)msgs);
	
	if (mail->TIMER)
		SetTimer(mail->hWnd, 0, mail->TIMER*60000, NULL);
	mail->CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);

	return 0;
}

int quitModule(HINSTANCE dll)
{
	if (mail->CHECKING) // what about this? wait for module to close, or does it lock everything...
	{
		TerminateThread(mail->CheckThread, NULL); // kill the checking thread.
		//Sleep(1000);
	}	

	RemoveBangCommand("!LSMailShow");
	RemoveBangCommand("!LSMailHide");
	RemoveBangCommand("!LSMailToggle");
	RemoveBangCommand("!LSMailCheckMail");
	RemoveBangCommand("!LSMailHook");
	
	SendMessage(mail->hWndParent, LM_UNREGISTERMESSAGE, (WPARAM)mail->hWnd, (LPARAM)msgs);
	KillTimer(mail->hWnd, 0);

	DestroyMenu(popup);

	while (Servers)
	{
		SERVER* s = Servers;
		Servers=Servers->next;
		delete s;
	}

	if (NewMailCmd != NULL) {
		delete [] NewMailCmd;
		NewMailCmd = NULL;
	}
	if (NoMailCmd != NULL) {
		delete [] NoMailCmd;
		NoMailCmd = NULL;
	}
	if (CheckMailCmd != NULL) {
		delete [] CheckMailCmd;
		CheckMailCmd = NULL;
	}
	if (DoneCheckCmd != NULL) {
		delete [] DoneCheckCmd;
		DoneCheckCmd = NULL;
	}

	DestroyWindow(mail->hWnd);
	UnregisterClass(szAppName, dll);

	DeleteObject(mail->bgbrush);
	DeleteObject(mail->nmbgbrush);
	DeleteObject(mail->checkbgbrush);
	DeleteObject(mail->bgbmp);
	DeleteObject(mail->newmailbmp);
	DeleteObject(mail->checkingbmp);
	DeleteObject(font);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_ERASEBKGND: return 0;

		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);
			strcpy(buf, rcsId);
			return strlen(buf);
		}
		break;

		case WM_RBUTTONDOWN:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
		}
		return 0;

		case WM_LBUTTONUP: // changed to check mail
		{
			/*NEWMAIL=FALSE;
			for (SERVER* s=Servers; s; s=s->next) 
			{
				s->num=s->newnum;
				s->NEWMAIL=FALSE;
			}
			*/
			mail->CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
			InvalidateRect(mail->hWnd, NULL, TRUE);
		}
		break;

		case WM_COMMAND:
		{
			switch (wParam)
			{
				case POPUP_CHECKMAIL: mail->CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID); break;
				
				case POPUP_LAUNCHCLIENT: 
				{
					WinExec(MAILCLIENT, SW_SHOWNORMAL);
					break;
				}
				case POPUP_DISPLAYERROR:
				{
					MessageBox(mail->hWnd, ERR, "LSMail Error", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
					break;
				}

			/*	case POPUP_ZEROACCOUNTS:
				{
					for (SERVER* s=Servers; s; s=s->next) 
					{
						s->NEWMAIL=FALSE;
						s->num=s->newnum=0;
					}
					InvalidateRect(mail->hWnd, NULL, TRUE);
				}
				break;*/
				
				case POPUP_CLEARNEWMAIL:
				{
					mail->NEWMAIL=FALSE;
					for (SERVER* s=Servers; s; s=s->next) 
					{
						//s->num=s->newnum; //V
						s->MAIL_STATUS = MAIL_NO;
					}
					InvalidateRect(mail->hWnd, NULL, TRUE); // needed for redraw
				}
				break;
				
				default:
				{
					for (SERVER* s=Servers; s; s=s->next) 
					{
						if ((int)wParam == (POPUP_SERVER+s->ID+1)) // Change Password
						{
							strcpy(TEMP_SERVER, s->name);
							DialogBox(mail->hInstance, MAKEINTRESOURCE(IDD_GETPASS), mail->hWnd, GetPassProc);
							if (strlen(TEMP_PASS)) 
							{
								char temp[256] = "";
								if (s->password) memset(&s->password, 0, sizeof(s->password));
								s->password = NULL;
								s->password = _strdup(TEMP_PASS);
								sprintf(temp, "%s/%s", s->host, s->login);
								WriteProfileString("LSMail", temp, encrypt(s->password));
							}
							break;
						}
					}
				}
				break;
			}
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, mail->w, mail->h);
			HBITMAP oldbuf, oldsrc;
			RECT r;

			GetClientRect(hwnd, &r);

			if (!mail->bgbmp && !mail->USEBGCOLOR)
			{
				mail->bgbmp = CreateCompatibleBitmap(hdc, mail->w, mail->h);
				oldbuf = (HBITMAP)SelectObject(buf, mail->bgbmp);
				BitBlt(buf, 0, 0, mail->w, mail->h, hdc, 0, 0, SRCCOPY);
				SelectObject(buf, oldbuf);
			}

			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			
			if (!mail->USEBGCOLOR)
			{
				if (mail->CHECKING && mail->checkingbmp)
					oldsrc = (HBITMAP)SelectObject(src, mail->checkingbmp);
				else if (mail->NEWMAIL && mail->newmailbmp)
					oldsrc = (HBITMAP)SelectObject(src, mail->newmailbmp);
				else
					oldsrc = (HBITMAP)SelectObject(src, mail->bgbmp);
				BitBlt(buf, 0, 0, mail->w, mail->h, src, 0, 0, SRCCOPY);
			}
			else
			{
				if (mail->CHECKING)
					FillRect(buf, &r, (HBRUSH)mail->checkbgbrush);
				else if (mail->NEWMAIL)
					FillRect(buf, &r, (HBRUSH)mail->nmbgbrush);
				else
					FillRect(buf, &r, (HBRUSH)mail->bgbrush);
			}

			SelectObject(buf, font);
			SetBkMode(buf, TRANSPARENT);

			for (SERVER* s=Servers; s; s=s->next)
			{
				char temp[256] = "";
				
				if (s->bERROR) sprintf(temp, "%s: Error!", s->name);
				else sprintf(temp, "%s: %d", s->name, s->newnum-s->num);

				SetRect(&r, s->x, s->y, mail->w, mail->h);

				if (mail->CHECKING)
					SetTextColor(buf, mail->checkcolor);
				else
				{
					if (s->MAIL_STATUS != MAIL_NO)
					{
						SetTextColor(buf, mail->nmcolor);
						LSLogPrintf(LOG_DEBUG, szAppName, "new mail on server: %s", s->host);
					}
					else
					{
						SetTextColor(buf, mail->color);
						LSLogPrintf(LOG_DEBUG, szAppName, "no new mail on server: %s", s->host);
					}
				}

				DrawText(buf, temp, strlen(temp), &r, DT_CALCRECT | DT_LEFT | DT_VCENTER);
				DrawText(buf, temp, strlen(temp), &r, DT_LEFT | DT_VCENTER);
			}

			BitBlt(hdc, 0, 0, mail->w, mail->h, buf, 0, 0, SRCCOPY);

			SelectObject(src, oldsrc);
			DeleteDC(src);
			SelectObject(buf, oldbuf);
			DeleteDC(buf);
			DeleteObject(bufbmp);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_TIMER:
		{
			mail->CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG: 
		{
			char temp[256] = "";
			sprintf(temp, "%s Password", TEMP_SERVER);
			SetWindowText(hwnd, temp);
			return TRUE;
		}

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDOK:
						{
							GetDlgItemText(hwnd, IDC_PASSWORD, TEMP_PASS, 256);
						}
						case IDCANCEL:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}

	return FALSE;
}

void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp)
{
	if (hwnd && bmp)
	{
		int x=0, y=0;
		HDC hdc = CreateCompatibleDC(NULL);
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;

		GetObject(bmp, sizeof(bitmap), &bitmap);
		SelectObject(hdc, bmp);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y < bitmap.bmHeight; x=0, y++)
		{
			for (x=0; x < bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == 0x00FF00FF)
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hwnd, hMainRgn, FALSE);

		DeleteDC(hdc);
		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hwnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hwnd, rgn, FALSE);
	}
}

BOOL CheckMail()
{
	int i = 0;
	if (mail->CHECKING) {
		mail->CHECKING = FALSE;
		return FALSE;
	}

	LSLog(LOG_DEBUG, szAppName, "starting mail check");

	mail->CHECKING=TRUE;
	InvalidateRect(mail->hWnd, NULL, TRUE);
	LSExecute(mail->hWnd, CheckMailCmd, 0); // check !bang

	__try 
	{
		for (SERVER* s=Servers; s; s=s->next)
		{
			s->POP3Check();
		}
	} __except(1) { }

	mail->MAIL_STATUS = mail->Status();

	if (mail->MAIL_STATUS == MAIL_NEW) {
		mail->NEWMAIL = TRUE;
		LSExecute(mail->hWnd, NewMailCmd, 0);
	}
	else if (mail->MAIL_STATUS == MAIL_NO) {
		mail->NEWMAIL = FALSE;
		LSExecute(mail->hWnd, NoMailCmd, 0);
	}

	mail->CHECKING=FALSE;
	LSExecute(mail->hWnd, DoneCheckCmd, 0); // check !bang
	InvalidateRect(mail->hWnd, NULL, TRUE);
	return TRUE;
}

int LSMAIL::Status()
{
	int status = MAIL_NO;
	for (SERVER* s=Servers; s; s=s->next)
	{
		status = max(status, s->MAIL_STATUS);
	}
	return status;
}

SERVER::POP3Check()
{
	LSLogPrintf(LOG_DEBUG, szAppName, "trying server %s@%s", login, host);
	unsigned int addr; 
	int	socket_type = SOCK_STREAM; 
	struct sockaddr_in server; 
	struct hostent *hp; 
	WSADATA wsaData; 
	SOCKET  conn_socket;
	char temp[256] = "";
	if (!password)
	{
		sprintf(temp, "%s/%s", host, login);
		GetProfileString("LSMail", temp, "", temp, 256);
		if (!strlen(temp))
		{
			strcpy(TEMP_SERVER, name);
			DialogBox(mail->hInstance, MAKEINTRESOURCE(IDD_GETPASS), mail->hWnd, GetPassProc);
			if (strlen(TEMP_PASS)) 
			{
				password = _strdup(TEMP_PASS);
				sprintf(temp, "%s/%s", host, login);
				WriteProfileString("LSMail", temp, encrypt(password));
			}
			memset(&TEMP_PASS, 0, sizeof(TEMP_PASS));
		}
		else
		{
			password=_strdup(encrypt(temp));
		}
	}

	// Startup Sockets
	if (WSAStartup(0x202,&wsaData) == SOCKET_ERROR)
	{ 
		sprintf(ERR, "Could not initialize Windows Sockets");
		bERROR=TRUE;
		WSACleanup(); 
		//continue;
	} 

	// Check to see if server_name is an alpha or ip
	if (isalpha(host[0]))
		hp = gethostbyname(host); 
	else  
	{
		addr = inet_addr(host); 
		hp = gethostbyaddr((char *)&addr,4,AF_INET); 
	} 

	// Couldn't resolve
	if (hp == NULL) 
	{	
		sprintf(ERR, "Could not resolve %s", host);
		//SERVER->ERR=TRUE;
		WSACleanup();
		//continue;
	} 

	// Copy the resolved information into the sockaddr_in structure 
	memset(&server,0,sizeof(server)); 
	memcpy(&(server.sin_addr),hp->h_addr,hp->h_length); 
	server.sin_family = hp->h_addrtype; 
	server.sin_port = htons((u_short)port); 

	// Open a socket
	conn_socket = socket(AF_INET,socket_type,0);
	if (conn_socket < 0 ) 
	{ 
		sprintf(ERR, "Could not open a socket");
		bERROR=TRUE;
		WSACleanup(); 
		//continue;
	}

	// Connect to the server
	if (connect(conn_socket,(struct sockaddr*)&server,sizeof(server)) == SOCKET_ERROR)
	{
		sprintf(ERR, "Could not connect to %s:%d, socket error", host, port);
		bERROR=TRUE;
		WSACleanup(); 
		//continue;
	}

	char* recvd=NULL;
	if (!ReceiveData(conn_socket)) 
	{ 
		sprintf(ERR, "No data received from server");
		bERROR=TRUE; 
		//continue; 
	}

	sprintf(temp, "USER %s\r\n", login);
	send(conn_socket, temp, strlen(temp), 0);
	if (!ReceiveData(conn_socket)) 
	{
		sprintf(ERR, "%s: Invalid Login", login);
		bERROR=TRUE; 
		//continue; 
	}
	sprintf(temp, "PASS %s\r\n", password);
	send(conn_socket, temp, strlen(temp), 0);
	if (!ReceiveData(conn_socket)) 
	{
		sprintf(ERR, "%s: Invalid password", password);
		sprintf(temp, "Invalid password for user %s on %s", login, host);
		if (!mail->bNoMessageBoxes)
			MessageBox(mail->hWnd, temp, "LSMail Error, no data received after sending password", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
		else
			LSLog(LOG_WARNING, szAppName, "LSMail Error, no data received after sending password");
		bERROR=TRUE; 
		//continue; 
	}
	sprintf(temp, "STAT\r\n");
	send(conn_socket, temp, strlen(temp), 0);
	if (!(recvd=ReceiveData(conn_socket))) 
	{
		sprintf(ERR, "Could not execute STAT. No data received.");
		bERROR=TRUE; 
		//continue; 
	}
	else
	{
		char* p = strtok(recvd, " ");
		int ReportedNum=-1;
		p = strtok(NULL, " ");
		ReportedNum = atoi(p);
		// new mail if:
		// 1. we have more mail than before
		// 2. we have more than zero mail, and less than before
		//    meaning we've fetched the mail, but before refresh, we've gotten even more
		//    what about when we get exactly the same amount of mail again?
		if ( ReportedNum > newnum || (ReportedNum > 0 && ReportedNum < newnum) ) 
		{
			MAIL_STATUS = MAIL_NEW;
		}
		else if (ReportedNum == newnum && ReportedNum != 0) {
			MAIL_STATUS = MAIL_EXISTS;
		}
		else if (ReportedNum == 0) {
			/*if (mail->MAIL_STATUS == MAIL_NO) {
				mail->MAIL_STATUS = MAIL_NO;
			}*/
			num=newnum=0;
			MAIL_STATUS = MAIL_NO;
		}
		newnum=ReportedNum;

		if (newnum < num)
			num=newnum;
	}

	sprintf(temp, "QUIT\r\n");
	send(conn_socket, temp, strlen(temp), 0);
	if (!ReceiveData(conn_socket)) 
	{ 
		sprintf(ERR, "Error disconnecting from server");
		//s->ERR=TRUE; 
		//continue; 
	}

	bERROR=FALSE;
	closesocket(conn_socket);
	WSACleanup();

	LSLog(LOG_DEBUG, szAppName, "server done");

}

char* ReceiveData(SOCKET conn_socket)
{
	int retval;
	int nStatus;
	struct timeval timeout = {0, 0};
	struct fd_set fds;
	DWORD dwStartTicks = GetTickCount();
	char temp[256] = "";

	while (1)
	{
		if ((GetTickCount() - dwStartTicks) > 60000)
		{
			if (!mail->bNoMessageBoxes)
				MessageBox(mail->hWnd, "Receive Timed Out", szAppName, MB_SYSTEMMODAL);
			else
				LSLog(LOG_WARNING, szAppName, "Receive Timed Out");
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}

		FD_ZERO(&fds);
		FD_SET(conn_socket, &fds);
		nStatus = select(0, &fds, NULL, NULL, &timeout);
		if (nStatus == SOCKET_ERROR) 
		{
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}
		else
		{
			if (!nStatus) 
			{
				Sleep(250);
				continue;
			}
		}

		retval = recv(conn_socket, temp, 256, 0); 
		if (retval == SOCKET_ERROR) 
		{ 
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}
		else
		{
			if (_strnicmp(temp, "+OK", 3))
			{
				closesocket(conn_socket);
				WSACleanup();
				return NULL;
			}
			else return _strdup(temp);
		}
	}

	return _strdup(temp);
}

char* encrypt(char* pass)
{
	char* ret=_strdup(pass);
	char* p=ret;
	for (; *pass; *pass++, *ret++)
	{
		*ret=*pass ^ 0x5405;
	}
	return p;
}