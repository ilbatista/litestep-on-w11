modified popup by Chaku
2000.10.26

Here're the additions:

NOTE:
This module requires that you're using the latest ckvwm (1.2 or later),
since the additional features in this build are meant specifically for
ckvwm.

Make these changes/additions to your step.rc config:

PopupckVWMPath $ModulePath$ckvwm.dll
(the path to ckvwm)


New bang commands:
!PopupTasksAll which will list all the tasks running
!PopupTasks# (where # is the number of the desktop)
or just !PopupTasks, which only shows the active tasks on that specific desktop


--
thanks to [steve] in #ls_help on efnet for the info on this module
thanks to chaku for the code :)
contact chaku: chaokuo@iname.com

--
this "readme" was written by rootrider of FPN
http://floach.pimpin.net/