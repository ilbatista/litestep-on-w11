import LSAPI

def InitModule (hwnd, dllinst, szpath):
	return 0