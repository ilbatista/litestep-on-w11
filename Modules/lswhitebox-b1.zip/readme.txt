While I'm at it, I've uploaded another useless module that I've been
working on for a while now called "lsWhitebox"  (based off of lsnothing
actually)

http://www.technoirotica.com/~rabidcow/litestep/lswhitebox-b1-src.zip
http://www.technoirotica.com/~rabidcow/litestep/lswhitebox-b1-bin.zip

It's basically intended to be a base for other modules, at least that's
what I plan to use it for.  (I should probly post this to the
shell-coding list instead, but oh well)  I don't think it's really
finished, and right now it will require my named monitor build.  It
creates a single window (I plan to have an "lsWhiteboxes" version) that
will display as a white box, and supports moving, resizing, multimonitor,
fake and real alpha (just got that to work) transparency, and should work
with lsbox.

let's see, it supports:

WhiteBoxInBox [bool]
WhiteboxOnMonitor monitor
WhiteboxX x
WhiteboxY y
WhiteboxWidth width
WhiteboxHeight height
WhiteboxAlpha amount
WhiteboxFakeAlpha [bool]
WhiteboxOnTop [bool]
WhiteboxHidden [bool]
!WhiteboxMove [monitor] x y
!WhiteboxSize width height
!WhiteboxOnTop [true|false|toggle]
!WhiteboxAlpha amount
!WhiteboxShow [true|false|toggle]
!WhiteboxLoadBoxHook

All values (x,y,width,height,alpha) use ParseCoordinate, so you can use
1-255 or 0%-100% for alpha, etc.  Also, you can use relative coords like
!WhiteboxSize 10r -10r

So any modules based off of it will get all this for free.  (but for now
require my custom ugly-code build)
