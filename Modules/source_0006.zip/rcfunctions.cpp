/*
This is a part of the LSECS Module Source code.

  Copyright (C) 2002-2006 Mike Edward Moras.
  
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	  This program is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
		You should have received a copy of the GNU General Public License
		along with this program; if not, write to the Free Software
		Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "ecs.h"



void ParseRC(void)
{	
	BOOL iLL = FALSE;
	HMODULE hUX = GetModuleHandle("UxTheme.dll");
	if(hUX == NULL)
	{
		hUX = LoadLibrary("UxTheme.dll");
		iLL = TRUE;
	}
	if(hUX != NULL)
	{
		HRESULT (__stdcall * EnableTheming)(BOOL) = NULL;
		EnableTheming = (HRESULT (__stdcall *)(BOOL))GetProcAddress(hUX, "EnableTheming");
		if (EnableTheming)
		{
			EnableTheming(GetRCBoolDef("ecskeepvisualstyles", FALSE));
		}
		if(iLL)
		{
			FreeLibrary(hUX);
		}
	}
	
	
	char szPath[4096];
	if(GetRCString("ecssavetorc", szPath, "ecstheme.rc", 4096))
	{
		ecssavecurrentsettings(szPath);
	}
	
	INT colornum[31];
	for(INT i = 0; i< 31; i++)
	{
		colornum[i] = i;
	}
	COLORREF colorref[31];
	colorref[0] = GetRCColor("ecsscrollbarcolor", GetSysColor(0));
	/* stub */
	colorref[1] = GetRCColor("ecsbackgroundcolor", RGB(255,0,255));
	if(colorref[1] == RGB(255,0,255))
	{
		colorref[1] = GetRCColor("ecsdesktopcolor", GetSysColor(1));
	}
	colorref[2] = GetRCColor("ecsactivecaptioncolor", GetSysColor(2));
	colorref[3] = GetRCColor("ecsinactivecaptioncolor", GetSysColor(3));
	colorref[4] = GetRCColor("ecsmenucolor", GetSysColor(4));
	colorref[5] = GetRCColor("ecswindowcolor", GetSysColor(5));
	colorref[6] = GetRCColor("ecswindowframecolor", GetSysColor(6));
	colorref[7] = GetRCColor("ecsmenutextcolor", GetSysColor(7));
	colorref[8] = GetRCColor("ecswindowtextcolor", GetSysColor(8));
	colorref[9] = GetRCColor("ecscaptiontextcolor", GetSysColor(9));
	colorref[10] = GetRCColor("ecsactivebordercolor", GetSysColor(10));
	colorref[11] = GetRCColor("ecsinactivebordercolor", GetSysColor(11));
	colorref[12] = GetRCColor("ecsappworkspacecolor", GetSysColor(12));
	colorref[13] = GetRCColor("ecshighlightcolor", GetSysColor(13));
	colorref[14] = GetRCColor("ecshighlighttextcolor", GetSysColor(14));
	/* stub */	    
	colorref[15] = GetRCColor("ecsbtnfacecolor", RGB(255,0,255));
	if(colorref[15] == RGB(255,0,255))
	{
		colorref[15] = GetRCColor("ecs3dfacecolor", GetSysColor(15));
	}
	/* stub */
	colorref[16] = GetRCColor("ecsbtnshadowcolor", RGB(255,0,255));
	if(colorref[16] == RGB(255,0,255))
	{
		colorref[16] = GetRCColor("ecs3dshadowcolor", GetSysColor(16));
	}	
	colorref[17] = GetRCColor("ecsgraytextcolor", GetSysColor(17));
	colorref[18] = GetRCColor("ecsbtntextcolor", GetSysColor(18));
	colorref[19] = GetRCColor("ecsinactivecaptiontextcolor", GetSysColor(19));
	/* stub */
	colorref[20] = GetRCColor("ecsbtnhighlightcolor", RGB(255,0,255));
	if(colorref[20] == RGB(255,0,255))
	{
		colorref[20] = GetRCColor("ecs3dhighlightcolor", RGB(255,0,255));
		if(colorref[20] == RGB(255,0,255))
		{
			colorref[20] = GetRCColor("ecs3dhilightcolor", RGB(255,0,255));
			if(colorref[20] == RGB(255,0,255))
			{
				colorref[20] = GetRCColor("ecsbtnhilightcolor", GetSysColor(20));
			}	
		}	
	}	
	colorref[21] = GetRCColor("ecs3ddkshadowcolor", GetSysColor(21));
	colorref[22] = GetRCColor("ecs3dlightcolor", GetSysColor(22));
	colorref[23] = GetRCColor("ecsinfotextcolor", GetSysColor(23));
	colorref[24] = GetRCColor("ecsinfobkcolor", GetSysColor(24));
	/* 25 not officially known according to Microsoft */
	colorref[25] = GetSysColor(25);
	colorref[26] = GetRCColor("ecshotlightcolor", GetSysColor(26));
	colorref[27] = GetRCColor("ecsgradientactivecaptioncolor", GetSysColor(27));
	colorref[28] = GetRCColor("ecsgradientinactivecaptioncolor", GetSysColor(28));
	colorref[29] = GetRCColor("ecsmenuhilightcolor", GetSysColor(29));
	colorref[30] = GetRCColor("ecsmenubarcolor", GetSysColor(30));
	
	int iPushedTheColors = 0;
	
	// NONCLIENTMETRICS from now on
	char szI[32];
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
	{
		ncm.iBorderWidth = GetRCInt("ecsborderwidth", ncm.iBorderWidth);
		ncm.iScrollWidth = GetRCInt("ecsscrollwidth", ncm.iScrollWidth);
		ncm.iScrollHeight = GetRCInt("ecsscrollheight", ncm.iScrollHeight);
		ncm.iCaptionWidth = GetRCInt("ecscaptionwidth", ncm.iCaptionWidth);
		ncm.iCaptionHeight = GetRCInt("ecscaptionheight", ncm.iCaptionHeight);
		ncm.iSmCaptionWidth = GetRCInt("ecssmallcaptionwidth", ncm.iSmCaptionWidth);
		ncm.iSmCaptionHeight = GetRCInt("ecssmallcaptionheight", ncm.iSmCaptionHeight);
		ncm.iMenuWidth = GetRCInt("ecsmenuwidth", ncm.iMenuWidth);
		ncm.iMenuHeight = GetRCInt("ecsmenuheight", ncm.iMenuHeight);
		if(GetRCString("ecscaptionfontfacename", szI, ncm.lfCaptionFont.lfFaceName, 32))
			lstrcpy(ncm.lfCaptionFont.lfFaceName, szI);

		int i = GetRCInt("ecscaptionfontheight", ncm.lfCaptionFont.lfHeight);
		if(i > 0) {	i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
		ncm.lfCaptionFont.lfHeight = i;

		ncm.lfCaptionFont.lfWeight = GetRCInt("ecscaptionfontweight", ncm.lfCaptionFont.lfWeight);
		ncm.lfCaptionFont.lfItalic = GetRCInt("ecscaptionfontitalic", ncm.lfCaptionFont.lfItalic);
		if(GetRCString("ecssmallcaptionfontfacename", szI, ncm.lfSmCaptionFont.lfFaceName, 32))
			lstrcpy(ncm.lfSmCaptionFont.lfFaceName, szI);

		i = GetRCInt("ecssmallcaptionfontheight", ncm.lfSmCaptionFont.lfHeight);
		if(i > 0) {	i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
		ncm.lfSmCaptionFont.lfHeight = i;


		ncm.lfSmCaptionFont.lfWeight = GetRCInt("ecssmallcaptionfontweight", ncm.lfSmCaptionFont.lfWeight);
		ncm.lfSmCaptionFont.lfItalic = GetRCInt("ecssmallcaptionfontitalic", ncm.lfSmCaptionFont.lfItalic);
		if(GetRCString("ecsmenufontfacename", szI, ncm.lfMenuFont.lfFaceName, 32))
			lstrcpy(ncm.lfMenuFont.lfFaceName, szI);
	
		i = GetRCInt("ecsmenufontheight", ncm.lfMenuFont.lfHeight);
		if(i > 0) {	i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
		ncm.lfMenuFont.lfHeight = i;

		ncm.lfMenuFont.lfWeight = GetRCInt("ecsmenufontweight", ncm.lfMenuFont.lfWeight);
		ncm.lfMenuFont.lfItalic = GetRCInt("ecsmenufontitalic", ncm.lfMenuFont.lfItalic);
		if(GetRCString("ecsstatusfontfacename", szI, ncm.lfStatusFont.lfFaceName, 32))
			lstrcpy(ncm.lfStatusFont.lfFaceName, szI);

		
		i = GetRCInt("ecsstatusfontheight", ncm.lfStatusFont.lfHeight);
		if(i > 0) {	i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
		ncm.lfStatusFont.lfHeight = i;


		ncm.lfStatusFont.lfWeight = GetRCInt("ecsstatusfontweight", ncm.lfStatusFont.lfWeight);
		ncm.lfStatusFont.lfItalic = GetRCInt("ecsstatusfontitalic", ncm.lfStatusFont.lfItalic);
		
		if(GetRCString("ecsmessagefontfacename", szI, ncm.lfMessageFont.lfFaceName, 32))
			lstrcpy(ncm.lfMessageFont.lfFaceName, szI);
		
		i = GetRCInt("ecsmessagefontheight", ncm.lfMessageFont.lfHeight);
		if(i > 0) {	i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
		ncm.lfMessageFont.lfHeight = i;

		ncm.lfMessageFont.lfWeight = GetRCInt("ecsmessagefontweight", ncm.lfMessageFont.lfWeight);
		ncm.lfMessageFont.lfItalic = GetRCInt("ecsmessagefontitalic", ncm.lfMessageFont.lfItalic);
		
		SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, /*SPIF_UPDATEINIFILE |*/ SPIF_SENDCHANGE);
	}
	
	/* update the colors last... looks nicer since the font stuff takes more time than the color inits! */
	SetSysColors(31,colornum, colorref);
}


