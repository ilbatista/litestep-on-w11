/*
This is a part of the LSECS Module Source code.

  Copyright (C) 2002-2006 Mike Edward Moras.
  
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	  This program is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
		You should have received a copy of the GNU General Public License
		along with this program; if not, write to the Free Software
		Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "ecs.h"

/*********************************************************************/
lsBangCmdDef Bangs[] = {
	{ "scrollbarcolor", bang_ecssetcolorscrollbar },
	{ "backgroundcolor", bang_ecssetcolorbackground },
	{ "activecaptioncolor", bang_ecssetcoloractivecaption },
	{ "inactivecaptioncolor", bang_ecssetcolorinactivecaption },
	{ "menucolor", bang_ecssetcolormenu },
	{ "windowcolor", bang_ecssetcolorwindow },
	{ "windowframecolor", bang_ecssetcolorwindowframe },
	{ "menutextcolor", bang_ecssetcolormenutext },
	{ "windowtextcolor", bang_ecssetcolorwindowtext },
	{ "captiontextcolor", bang_ecssetcolorcaptiontext },
	{ "activebordercolor", bang_ecssetcoloractiveborder },
	{ "inactivebordercolor", bang_ecssetcolorinactiveborder },
	{ "appworkspacecolor", bang_ecssetcolorappworkspace },
	{ "highlightcolor", bang_ecssetcolorhighlight },
	{ "highlighttextcolor", bang_ecssetcolorhighlighttext },
	{ "btnfacecolor", bang_ecssetcolorbtnface },
	{ "btnshadowcolor", bang_ecssetcolorbtnshadow },
	{ "graytextcolor", bang_ecssetcolorgraytext },
	{ "btntextcolor", bang_ecssetcolorbtntext },
	{ "inactivecaptiontextcolor", bang_ecssetcolorinactivecaptiontext },
	{ "btnhighlightcolor", bang_ecssetcolorbtnhighlight },
	{ "3ddkshadowcolor", bang_ecssetcolor3ddkshadow },
	{ "3dlightcolor", bang_ecssetcolor3dlight },
	{ "infotextcolor", bang_ecssetcolorinfotext },
	{ "infobkcolor", bang_ecssetcolorinfobk },
	{ "hotlightcolor", bang_ecssetcolorhotlight },
	{ "gradientactivecaptioncolor", bang_ecssetcolorgradientactivecaption },
	{ "gradientinactivecaptioncolor", bang_ecssetcolorgradientinactivecaption },
	{ "menuhilightcolor", bang_ecssetcolormenuhilight },
	{ "menubarcolor", bang_ecssetcolormenubar },
	// Microsoft stubs
	{ "desktopcolor", bang_ecssetcolordesktop },
	{ "3dfacecolor", bang_ecssetcolor3dface },
	{ "3dshadowcolor", bang_ecssetcolorbtnshadow },
	{ "3dhighlightcolor", bang_ecssetcolorbtnhighlight },
	{ "3dhilightcolor", bang_ecssetcolorbtnhighlight },
	{ "btnhilightcolor", bang_ecssetcolorbtnhighlight },
	
	// NONCLIENTMETRICS from now on
	{ "borderwidth", bang_ecssetncmborderwidth },
	{ "scrollwidth", bang_ecssetncmscrollwidth },
	{ "scrollheight", bang_ecssetncmscrollheight },
	{ "captionwidth", bang_ecssetncmcaptionwidth },
	{ "captionheight", bang_ecssetncmcaptionheight },
	{ "smallcaptionwidth", bang_ecssetncmsmallcaptionwidth },
	{ "smallcaptionheight", bang_ecssetncmsmallcaptionheight },
	{ "menuwidth", bang_ecssetncmmenuwidth },
	{ "menuheight", bang_ecssetncmmenuheight },
	{ "captionfontfacename", bang_ecssetncmcaptionfontfacename },
	{ "captionfontheight", bang_ecssetncmcaptionfontheight },
	{ "captionfontweight", bang_ecssetncmcaptionfontweight },
	{ "captionfontitalic", bang_ecssetncmcaptionfontitalic },
	{ "smallcaptionfontfacename", bang_ecssetncmsmallcaptionfontfacename },
	{ "smallcaptionfontheight", bang_ecssetncmsmallcaptionfontheight },
	{ "smallcaptionfontweight", bang_ecssetncmsmallcaptionfontweight },
	{ "smallcaptionfontitalic", bang_ecssetncmsmallcaptionfontitalic },
	{ "menufontfacename", bang_ecssetncmmenufontfacename },
	{ "menufontheight", bang_ecssetncmmenufontheight },
	{ "menufontweight", bang_ecssetncmmenufontweight },
	{ "menufontitalic", bang_ecssetncmmenufontitalic },
	{ "statusfontfacename", bang_ecssetncmstatusfontfacename },
	{ "statusfontheight", bang_ecssetncmstatusfontheight },
	{ "statusfontweight", bang_ecssetncmstatusfontweight },
	{ "statusfontitalic", bang_ecssetncmstatusfontitalic },
	{ "messagefontfacename", bang_ecssetncmmessagefontfacename },
	{ "messagefontheight", bang_ecssetncmmessagefontheight },
	{ "messagefontweight", bang_ecssetncmmessagefontweight },
	{ "messagefontitalic", bang_ecssetncmmessagefontitalic },
	// and some combinations
	{ "captionfont", bang_ecssetncmcaptionfont},
	{ "smallcaptionfont", bang_ecssetncmsmallcaptionfont },
	{ "menufont", bang_ecssetncmmenufont },
	{ "statusfont", bang_ecssetncmstatusfont },
	{ "messagefont", bang_ecssetncmmessagefont },
	// and some combinations
	{ "savetorc", bang_ecssavetorc},
	{ "disablevisualstyles", bang_ecsdisablevisualstyles},
	
	{ NULL, NULL }
};


int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	LSRegisterBangList("!ecs",-1,Bangs);
	if(GetRCInt("ecsignorerc", 1) == 0)
	{
		ParseRC();
	}
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	LSRemoveBangList("!ecs",-1,Bangs);
}

