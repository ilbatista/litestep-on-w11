/*
This is a part of the LSECS Module Source code.

  Copyright (C) 2002-2006 Mike Edward Moras.
  
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	  This program is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
		You should have received a copy of the GNU General Public License
		along with this program; if not, write to the Free Software
		Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __bangfunctions_H
#define __bangfunctions_H

#include "ecs.h"

void ecssavecurrentsettings(LPCSTR szI);


void bang_ecssetcolorscrollbar(HWND caller, LPCSTR args);
void bang_ecssetcolorbackground(HWND caller, LPCSTR args);
void bang_ecssetcoloractivecaption(HWND caller, LPCSTR args);
void bang_ecssetcolorinactivecaption(HWND caller, LPCSTR args);
void bang_ecssetcolormenu(HWND caller, LPCSTR args);
void bang_ecssetcolorwindow(HWND caller, LPCSTR args);
void bang_ecssetcolorwindowframe(HWND caller, LPCSTR args);
void bang_ecssetcolormenutext(HWND caller, LPCSTR args);
void bang_ecssetcolorwindowtext(HWND caller, LPCSTR args);
void bang_ecssetcolorcaptiontext(HWND caller, LPCSTR args);
void bang_ecssetcoloractiveborder(HWND caller, LPCSTR args);
void bang_ecssetcolorinactiveborder(HWND caller, LPCSTR args);
void bang_ecssetcolorappworkspace(HWND caller, LPCSTR args);
void bang_ecssetcolorhighlight(HWND caller, LPCSTR args);
void bang_ecssetcolorhighlighttext(HWND caller, LPCSTR args);
void bang_ecssetcolorbtnface(HWND caller, LPCSTR args);
void bang_ecssetcolorbtnshadow(HWND caller, LPCSTR args);
void bang_ecssetcolorgraytext(HWND caller, LPCSTR args);
void bang_ecssetcolorbtntext(HWND caller, LPCSTR args);
void bang_ecssetcolorinactivecaptiontext(HWND caller, LPCSTR args);
void bang_ecssetcolorbtnhighlight(HWND caller, LPCSTR args);
void bang_ecssetcolor3ddkshadow(HWND caller, LPCSTR args);
void bang_ecssetcolor3dlight(HWND caller, LPCSTR args);
void bang_ecssetcolorinfotext(HWND caller, LPCSTR args);
void bang_ecssetcolorinfobk(HWND caller, LPCSTR args);
void bang_ecssetcolorhotlight(HWND caller, LPCSTR args);
void bang_ecssetcolorgradientactivecaption(HWND caller, LPCSTR args);
void bang_ecssetcolorgradientinactivecaption(HWND caller, LPCSTR args);
void bang_ecssetcolormenuhilight(HWND caller, LPCSTR args);
void bang_ecssetcolormenubar(HWND caller, LPCSTR args);
// Microsoft stubs
void bang_ecssetcolordesktop(HWND caller, LPCSTR args);
void bang_ecssetcolor3dface(HWND caller, LPCSTR args);
void bang_ecssetcolor3dshadow(HWND caller, LPCSTR args);
void bang_ecssetcolor3dhighlight(HWND caller, LPCSTR args);
void bang_ecssetcolor3dhilight(HWND caller, LPCSTR args);
void bang_ecssetcolorbtnhilight(HWND caller, LPCSTR args);

// NONCLIENTMETRICS from now on
void bang_ecssetncmborderwidth(HWND caller, LPCSTR args);
void bang_ecssetncmscrollheight(HWND caller, LPCSTR args);
void bang_ecssetncmscrollwidth(HWND caller, LPCSTR args);
void bang_ecssetncmcaptionwidth(HWND caller, LPCSTR args);
void bang_ecssetncmcaptionheight(HWND caller, LPCSTR args);
void bang_ecssetncmsmallcaptionwidth(HWND caller, LPCSTR args);
void bang_ecssetncmsmallcaptionheight(HWND caller, LPCSTR args);
void bang_ecssetncmmenuwidth(HWND caller, LPCSTR args);
void bang_ecssetncmmenuheight(HWND caller, LPCSTR args);
void bang_ecssetncmcaptionfontfacename(HWND caller, LPCSTR args);
void bang_ecssetncmcaptionfontheight(HWND caller, LPCSTR args);
void bang_ecssetncmcaptionfontweight(HWND caller, LPCSTR args);
void bang_ecssetncmcaptionfontitalic(HWND caller, LPCSTR args);
void bang_ecssetncmsmallcaptionfontfacename(HWND caller, LPCSTR args);
void bang_ecssetncmsmallcaptionfontheight(HWND caller, LPCSTR args);
void bang_ecssetncmsmallcaptionfontweight(HWND caller, LPCSTR args);
void bang_ecssetncmsmallcaptionfontitalic(HWND caller, LPCSTR args);
void bang_ecssetncmmenufontfacename(HWND caller, LPCSTR args);
void bang_ecssetncmmenufontheight(HWND caller, LPCSTR args);
void bang_ecssetncmmenufontweight(HWND caller, LPCSTR args);
void bang_ecssetncmmenufontitalic(HWND caller, LPCSTR args);
void bang_ecssetncmstatusfontfacename(HWND caller, LPCSTR args);
void bang_ecssetncmstatusfontheight(HWND caller, LPCSTR args);
void bang_ecssetncmstatusfontweight(HWND caller, LPCSTR args);
void bang_ecssetncmstatusfontitalic(HWND caller, LPCSTR args);
void bang_ecssetncmmessagefontfacename(HWND caller, LPCSTR args);
void bang_ecssetncmmessagefontheight(HWND caller, LPCSTR args);
void bang_ecssetncmmessagefontweight(HWND caller, LPCSTR args);
void bang_ecssetncmmessagefontitalic(HWND caller, LPCSTR args);
// and some combinations
void bang_ecssetncmcaptionfont(HWND caller, LPCSTR args);
void bang_ecssetncmsmallcaptionfont(HWND caller, LPCSTR args);
void bang_ecssetncmmenufont(HWND caller, LPCSTR args);
void bang_ecssetncmstatusfont(HWND caller, LPCSTR args);
void bang_ecssetncmmessagefont(HWND caller, LPCSTR args);

// general stuff
void bang_ecssavetorc(HWND caller, LPCSTR args);
void bang_ecsdisablevisualstyles(HWND caller, LPCSTR args);

#endif