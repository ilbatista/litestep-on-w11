/*
This is a part of the LSECS Module Source code.

  Copyright (C) 2002 rabidcow
  
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	  This program is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
		You should have received a copy of the GNU General Public License
		along with this program; if not, write to the Free Software
		Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __jssupport_H
#define __jssupport_H

#include "ecs.h"

#ifndef LSTOOLS_REV

typedef struct _lsBangCmdDef {
	const char *Name;
	BangCommand *Command;
} lsBangCmdDef;

LSAPI void LSRegisterBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs);
LSAPI void LSRemoveBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs);

#ifndef ASSERT
#ifndef NDEBUG
#ifdef NOISY_ASSERT
#define ASSERT(n) if (!(n)) {char buf[MAX_LINE_LENGTH];\
	sprintf(buf,"Assert failed at line %d of %s:\n  %s\nBreak to debug?",__LINE__,__FILE__,#n);\
if(MessageBox(NULL,buf,MODULE,MB_YESNO)==IDYES) DebugBreak();}
#else
#define ASSERT(n) if (!(n)) LSLogPrintf(LOG_ERROR,MODULE,"Assert failed at line %d of %s: %s",__LINE__,__FILE__,#n)
#endif
#else
#define ASSERT(n) (void)0
#endif
#endif
#ifndef WRITEABLE
#define WRITEABLE(ptr,len) (ptr!=NULL && !IsBadWritePtr(ptr,len))
#define READABLE(ptr,len) (ptr!=NULL && !IsBadReadPtr(ptr,len))
#define EXECABLE(ptr) (ptr!=NULL && !IsBadCodePtr(ptr))
#endif

#endif

#endif
