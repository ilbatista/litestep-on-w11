/*
This is a part of the LSECS Module Source code.

  Copyright (C) 2002 rabidcow
  
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	  This program is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	  GNU General Public License for more details.
	  
		You should have received a copy of the GNU General Public License
		along with this program; if not, write to the Free Software
		Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "ecs.h"

#ifndef LSTOOLS_REV

/***************************************************************
Register/Unregister a list of bang commands. [js]
****************************************************************/


/*	Bang commands must be 63 chars or fewer.
I believe this is a restriction in the LS code,
but I don't wanna look it up right now. */
#define MAX_BANGCMD_LENGTH 64

void LSRegisterBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs)
{
	lsBangCmdDef *pBang;
	char BangString[MAX_BANGCMD_LENGTH];
	
	ASSERT(READABLE(prefix,(prefixlen+1)*sizeof(char)));
	ASSERT(READABLE(Bangs,sizeof(lsBandCmdDef)));
	
	lstrcpy(BangString,prefix);
	
	if (prefixlen<0) prefixlen = lstrlen(prefix);
	
	/* actually, it should be much less, since */ 
	/* we paste the bang names on after this   */ 
	ASSERT(prefixlen<MAX_BANGCMD_LENGTH);
	
	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+prefixlen,pBang->Name);
		AddBangCommand(BangString, pBang->Command);
		pBang++;
	}
}
void LSRemoveBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs)
{
	lsBangCmdDef *pBang;
	char BangString[MAX_BANGCMD_LENGTH];
	
	ASSERT(READABLE(prefix,(prefixlen+1)*sizeof(char)));
	ASSERT(READABLE(Bangs,sizeof(lsBandCmdDef)));
	
	lstrcpy(BangString,prefix);
	
	if (prefixlen<0) prefixlen = lstrlen(prefix);
	
	ASSERT(prefixlen<MAX_BANGCMD_LENGTH);
	
	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+prefixlen,pBang->Name);
		RemoveBangCommand(BangString);
		pBang++;
	}
}

#endif
