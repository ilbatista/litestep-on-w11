/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

set<WindowData*> windowByDescription(string keyword, string arg)
{
	set<WindowData*> ret;
	
	if(keyword=="all")
	{
		if(arg=="")
			arg="all";
		set<VirtualDesktop*> desks = findDesks(arg);
		
		vector<WindowData*> windows;
		vwm->getWindowList(windows);
		for(unsigned ii=0; ii<windows.size(); ii++)
		{
			if(desks.find(windows[ii]->desk) == desks.end())
				continue;
			ret.insert(windows[ii]);
		}
	}
	else if(keyword=="tasks")
	{
		if(arg=="")
			arg="all";
		set<VirtualDesktop*> desks = findDesks(arg);
		
		vector<WindowData*> windows;
		vwm->getWindowList(windows);
		for(unsigned ii=0; ii<windows.size(); ii++)
		{
			if(desks.find(windows[ii]->desk) == desks.end())
				continue;
			if(!windows[ii]->isTask)
				continue;
			ret.insert(windows[ii]);
		}
	}
	else if(keyword==""
	   || keyword=="foreground"
	   || keyword=="focused")
	{
		ret.insert(vwm->getForegroundWindow());
	}
	else if(keyword=="clicked")
	{
		if(clickContext)
			ret.insert(clickContext->task);
	}
	else if(keyword=="dragged")
	{
		if(drag)
			ret.insert(drag->elementContext.task);
	}
	else if(keyword=="dropped")
	{
		if(droppedContext)
			ret.insert(droppedContext->task);
	}
	else if(keyword=="hovered")
	{
		Point mousePos = getCursorPos();
		VWMPanel *panel = vwm->findPanel(mousePos.x, mousePos.y);
		mousePos.x -= panel->x;
		mousePos.y -= panel->y;
		LayoutLocation hovered = panel->elementAtPoint(mousePos.x, mousePos.y);
		ret.insert(hovered.context.task);
	}
	
	return ret;
}
