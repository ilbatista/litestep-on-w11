/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

void VWM::initDesktops()
{
	if(!settings->autoGather) {
		if(restoreDesktops()>=0)
			return;
	}
	
	// Start with one desktop for each monitor
	for(int ii=0; ii<monitors->numMonitors(); ii++)
	{
		Monitor *monitor = monitors->getMonitor(ii);
		VirtualDesktop *newDesk = new VirtualDesktop(ii, storageManager.getStorageArea());
		
		newDesk->monitor = monitor;
		monitor->setDesk(newDesk);
		
		desktops.push_back(newDesk);
	}
	
	lastDesktop = desktops[desktops.size()-1];
	
	updateTaskLists(false);
}

int VWM::restoreDesktops()
{
	/*char buf[4096];
	
	if(!SendMessage(GetLitestepWnd(), LM_RESTOREDATA, MAKEWPARAM(sizeof(buf), MODULE_ID), (LPARAM)buf)) {
		return -1;
	}
	
	vector<StorageArea*> deskAreas;
	int focus = storageManager.restore((void*)buf, deskAreas);
	
	for(unsigned ii=0; ii<deskAreas.size(); ii++)
	{
		desktops.push_back(new VirtualDesktop(ii, deskAreas[ii]));
	}
	
	currentDesktop = desktops[focus];
	lastDesktop = currentDesktop;
	desktops[focus]->focused = true;
	
	updateTaskLists(true);
	
	return focus;*/
	// TODO: Redo desk save/restore for multimonitor
	return -1;
}

void VWM::saveDesktops()
{
	/*vector<StorageArea*> deskAreas;
	int focus = 0;
	for(unsigned ii=0; ii<desktops.size(); ii++) {
		deskAreas.push_back(desktops[ii]->offScreenStorage);
		if(desktops[ii]->focused)
			focus = ii;
	}
	
	int len;
	void *data = storageManager.save(&len, focus, deskAreas);
	SendMessage(GetLitestepWnd(), LM_SAVEDATA, MAKEWPARAM(len, MODULE_ID), (LPARAM)data);
	free(data);*/
	// TODO: Redo desk save/restore for multimonitor
}

/////////////////////////////////////////////////////////////////////////////

VirtualDesktop::VirtualDesktop(int index, StorageArea *storage)
{
	this->index = index;
	monitor = NULL;
	this->offScreenStorage = storage;
	numTasks = 0;
}

VirtualDesktop::~VirtualDesktop()
{
	delete offScreenStorage;
}

string VirtualDesktop::getName()
{
	char buf[32];
	sprintf(buf, "Desktop %i", index+1);
	return buf;
}

string VirtualDesktop::getLabel()
{
	char buf[16];
	itoa(index+1, buf, 10);
	return buf;
}

/// Retrieve all the tasks on this desk, in order from top (foreground) to
/// bottom. Where tasks include multiple windows, only the root window will
/// be returned.
void VirtualDesktop::getTasks(vector<WindowData*> *outTasks)
{
	for(vector<HWND>::iterator ii=vwm->zOrder.begin(); ii!=vwm->zOrder.end(); ii++)
	{
		HWND handle = *ii;
		WindowData *window = vwm->windowsByHandle[handle];
		
		if(!window)
			continue;
		if(window->desk!=this)
			continue;
		if(!window->isTask)
			continue;
		
		outTasks->push_back(window);
	}
}

/// Retrieve all the windows on this desk, in order from top (foreground) to
/// bottom. Where tasks which include multiple windows, all of the windows
/// will be included, not necessarily together and in Z-order.
void VirtualDesktop::getWindows(vector<WindowData*> *outWindows)
{
	for(vector<HWND>::iterator ii=vwm->zOrder.begin(); ii!=vwm->zOrder.end(); ii++)
	{
		if(vwm->windowsByHandle.find(*ii) == vwm->windowsByHandle.end())
			continue;
		WindowData *window = vwm->windowsByHandle[*ii];
		if(!window || window->desk!=this)
			continue;
		outWindows->push_back(window);
	}
}

void VirtualDesktop::show(Monitor *monitor)
{
	vector<WindowData*> windows;
	getWindows(&windows);
	
	for(unsigned ii=0; ii<windows.size(); ii++)
	{
		WindowData *window = windows[ii];
		if(window->tempSticky)
			continue;
		
		monitor->storageArea->transferFrom(window->screenPos, currentStorage());
		vwm->setWindowPos(window, window->screenPos);
	}
	
	lastMaximizeArea = monitor->getMaximizeArea();
	monitor->storageArea->unstoreRect(lastMaximizeArea);
	
	this->monitor = monitor;
	monitor->setDesk(this);
}

void VirtualDesktop::hide()
{
	// Can't hide if already hidden
	if(!monitor)
		return;
	
	lastMaximizeArea = monitor->getMaximizeArea();
	monitor->storageArea->unstoreRect(lastMaximizeArea);
	
	vector<WindowData*> windows;
	getWindows(&windows);
	
	for(unsigned ii=0; ii<windows.size(); ii++)
	{
		WindowData *window = windows[ii];
		if(window->tempSticky)
			continue;
		
		Rect pos = window->screenPos;
		offScreenStorage->transferFrom(window->screenPos, monitor->storageArea);
		vwm->setWindowPos(window, window->screenPos);
	}
	
	monitor = NULL;
}

void VirtualDesktop::moveWindowTo(WindowData *window, VirtualDesktop *target)
{
	if(window->desk == target)
		return;
	
	target->currentStorage()->transferFrom(window->screenPos, currentStorage());
	vwm->setWindowPos(window, window->screenPos);
	window->desk = target;
}

Monitor *VirtualDesktop::getMonitor()
{
	return monitor;
}

StorageArea *VirtualDesktop::currentStorage()
{
	if(monitor)
		return monitor->storageArea;
	else
		return offScreenStorage;
}
