/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

set<VirtualDesktop*> deskByDescription(string keyword, string arg)
{
	set<VirtualDesktop*> ret;
	
	if(keyword=="")
		return ret;
	
	if(isdigit(keyword[0])) {
		int index = atoi(keyword.c_str()) - 1;
		if(index>0 && index<(int)vwm->desktops.size())
			ret.insert(vwm->desktops[index]);
		else if(index < 0 && -index<(int)vwm->desktops.size())
			ret.insert(vwm->desktops[vwm->desktops.size()+index]);
	}
	
	if(keyword=="all")
	{
		for(unsigned ii=0; ii<vwm->desktops.size(); ii++)
			ret.insert(vwm->desktops[ii]);
	}
	else if(keyword=="current")
	{
		for(unsigned ii=0; ii<vwm->desktops.size(); ii++)
			if(vwm->desktops[ii]->monitor)
				ret.insert(vwm->desktops[ii]);
	}
	else if(keyword=="next"
	     || keyword=="down"
	     || keyword=="right")
	{
		Monitor *contextMonitor = findSingleMonitor(arg);
		if(!contextMonitor) return ret;
		VirtualDesktop *contextDesk = contextMonitor->getDesk();
		
		if(contextDesk->index+1 < vwm->desktops.size())
			ret.insert(vwm->desktops[contextDesk->index+1]);
	}
	else if(keyword=="prev"
	     || keyword=="up"
	     || keyword=="left")
	{
		Monitor *contextMonitor = findSingleMonitor(arg);
		if(!contextMonitor) return ret;
		VirtualDesktop *contextDesk = contextMonitor->getDesk();
		
		if(contextDesk->index > 0)
			ret.insert(vwm->desktops[contextDesk->index-1]);
	}
	else if(keyword=="first")
	{
		ret.insert(vwm->desktops[0]);
	}
	else if(keyword=="last")
	{
		ret.insert(vwm->desktops[vwm->desktops.size()-1]);
	}
	else if(keyword=="other")
	{
		if(vwm->lastDesktop && !vwm->lastDesktop->monitor)
			ret.insert(vwm->lastDesktop);
	}
	else if(keyword=="newfirst")
	{
		VirtualDesktop *newDesk = new VirtualDesktop(0, vwm->storageManager.getStorageArea());
		vwm->desktops.insert(vwm->desktops.begin(), newDesk);
		for(int ii=1; ii<(int)vwm->desktops.size(); ii++)
			vwm->desktops[ii]->index = ii;
		ret.insert(newDesk);
	}
	else if(keyword=="newlast")
	{
		VirtualDesktop *newDesk = new VirtualDesktop(vwm->desktops.size(), vwm->storageManager.getStorageArea());
		vwm->desktops.push_back(newDesk);
		ret.insert(newDesk);
	}
	else if(keyword=="newnext")
	{
		Monitor *contextMonitor = findSingleMonitor(arg);
		if(!contextMonitor) return ret;
		VirtualDesktop *contextDesk = contextMonitor->getDesk();
		if(!contextDesk) return ret;
		
		// Create a new desk after the context desk, and return it
		VirtualDesktop *newDesk = new VirtualDesktop(contextDesk->index+1, vwm->storageManager.getStorageArea());
		vwm->desktops.insert(vwm->desktops.begin()+contextDesk->index+1, newDesk);
		for(int ii=contextDesk->index; ii<(int)vwm->desktops.size(); ii++)
			vwm->desktops[ii]->index = ii;
		ret.insert(newDesk);
	}
	else if(keyword=="newprev")
	{
		Monitor *contextMonitor = findSingleMonitor(arg);
		if(!contextMonitor) return ret;
		VirtualDesktop *contextDesk = contextMonitor->getDesk();
		if(!contextDesk) return ret;
		
		VirtualDesktop *newDesk = new VirtualDesktop(contextDesk->index, vwm->storageManager.getStorageArea());
		vwm->desktops.insert(vwm->desktops.begin()+contextDesk->index, newDesk);
		for(int ii=contextDesk->index; ii<(int)vwm->desktops.size(); ii++)
			vwm->desktops[ii]->index = ii;
		ret.insert(newDesk);
	}
	else if(keyword=="clicked")
	{
		if(clickContext)
			ret.insert(clickContext->desk);
	}
	else if(keyword=="dragged")
	{
		if(drag)
			ret.insert(drag->elementContext.desk);
	}
	else if(keyword=="dropped")
	{
		if(droppedContext)
			ret.insert(droppedContext->desk);
	}
	else if(keyword=="hovered")
	{
		Point mousePos = getCursorPos();
		VWMPanel *panel = vwm->findPanel(mousePos.x, mousePos.y);
		if(panel) {
			mousePos.x -= panel->x;
			mousePos.y -= panel->y;
			LayoutLocation hovered = panel->elementAtPoint(mousePos.x, mousePos.y);
			ret.insert(hovered.context.desk);
		}
	}
	else
	{
		for(unsigned ii = 0; ii < vwm->desktops.size(); ii++)
		{
			if (keyword==vwm->desktops[ii]->getName()) {
				ret.insert(vwm->desktops[ii]);
				break;
			}
		}
	}

	return ret;
}
