/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

StorageArea::StorageArea(Rect &rect)
{
	this->x = rect.left;
	this->y = rect.top;
	
	this->owner = NULL;
	this->index = 0;
}

StorageArea::StorageArea(StorageManager *owner, int index, int x, int y)
	:owner(owner), index(index), x(x), y(y)
{
}

StorageArea::~StorageArea()
{
	owner->releaseStorageArea(this);
}

RECT StorageArea::getRect()
{
	RECT ret;
	ret.left = x + SCREEN_LEFT;
	ret.top = y + SCREEN_TOP;
	ret.right = ret.left + SCREEN_WIDTH;
	ret.bottom = ret.top + SCREEN_HEIGHT;
	return ret;
}

void StorageArea::storeRect(Rect &rect)
{
	rect.left += x;
	rect.top += y;
}

void StorageArea::unstoreRect(Rect &rect)
{
	rect.left -= x;
	rect.top -= y;
}

void StorageArea::storePoint(POINT &point)
{
	point.x += x;
	point.y += y;
}

void StorageArea::unstorePoint(POINT &point)
{
	point.x -= x;
	point.y -= y;
}

void StorageArea::transferFrom(Rect &rect, StorageArea *prev)
{
	prev->unstoreRect(rect);
	storeRect(rect);
}

StorageManager::StorageManager()
{
	maxArea = 0;
	spacingX = SCREEN_WIDTH*2;
	spacingY = SCREEN_HEIGHT*2;
}

StorageManager::~StorageManager()
{
}

StorageArea *StorageManager::getStorageArea()
{
	int index;
	set<int>::iterator unusedAreaIt = unusedAreas.begin();
	if(unusedAreaIt != unusedAreas.end()) {
		index = *unusedAreaIt;
		unusedAreas.erase(unusedAreaIt);
	} else {
		index = maxArea++;
	}
	
	int x = spacingX * (index+1);
	int y = 0;
	
	// If there are tons of VWMs, we might get a position that's long enough to
	// overflow a signed short, and that causes bad things. Keep a nice big
	// safety margin between the rightmost offscreen-storage area and
	// SSHORT_MAX.
	const int rightSideLimit = 31000 - SCREEN_WIDTH*2;
	while(x >= rightSideLimit) {
		x -= rightSideLimit;
		y += spacingY;
	}
	
	return new StorageArea(this, index, x, y);
}

void StorageManager::releaseStorageArea(StorageArea *area)
{
	unusedAreas.insert(area->index);
}

struct StorageManagerPOD
{
	int desks;
	int focus;
	int screenWidth;
	int screenHeight;
};
struct StorageAreaPOD
{
	int x;
	int y;
};

void *StorageManager::save(int *stateSize, int focus, vector<StorageArea*> deskAreas)
{
	*stateSize = sizeof(StorageManagerPOD) + deskAreas.size() * sizeof(StorageAreaPOD);
	void *ret = malloc(*stateSize);
	
	StorageManagerPOD *header = (StorageManagerPOD*)ret;
	StorageAreaPOD *desks = (StorageAreaPOD*)(header+1);
	
	header->desks = deskAreas.size();
	header->focus = focus;
	header->screenWidth = SCREEN_WIDTH;
	header->screenHeight = SCREEN_HEIGHT;
	
	for(unsigned ii=0; ii<deskAreas.size(); ii++)
	{
		desks[ii].x = deskAreas[ii]->x;
		desks[ii].y = deskAreas[ii]->y;
	}
	
	return ret;
}

int StorageManager::restore(void *state, vector<StorageArea*> &deskAreas)
{
	unusedAreas.clear();
	
	StorageManagerPOD *header = (StorageManagerPOD*)state;
	
	StorageAreaPOD *desks = (StorageAreaPOD*)(header+1);
	
	for(int ii=0; ii<header->desks; ii++)
	{
		deskAreas.push_back(new StorageArea(this, ii, desks[ii].x, desks[ii].y));
	}
	
	maxArea = header->desks;
	return header->focus;
}
