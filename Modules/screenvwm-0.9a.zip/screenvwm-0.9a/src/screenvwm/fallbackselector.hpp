/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

/*template<class PickedType>
class FallbackSelector
{
public:
	FallbackSelector(string expr);
	
	static PickedType evaluateSingle(string desc, PickedType notsingle, const ElementContext *context=NULL);
	
	set<PickedType> evaluate(const ElementContext *context);
	
	set<PickedType> evalKeyword(string keyword, string arg);
	string defaultSelectors();
	
protected:
	struct Selector {
		string keyword;
		string arg;
	};
	vector<Selector> selectors;
};

typedef FallbackSelector<VirtualDesktop*> DeskSelector;
typedef FallbackSelector<WindowData*> WindowSelector;
typedef FallbackSelector<Monitor*> MonitorSelector;


template<class PickedType>
FallbackSelector<PickedType>::FallbackSelector(string expr)
{
	if(expr=="")
		expr=defaultSelectors();
	
	vector<string> tokens;
	tokenizeString(expr, tokens, "/");
	
	for(unsigned ii=0; ii<tokens.size(); ii++)
	{
		Selector selector;
		// TODO: Parse selectors with args
		selector.keyword = tokens[ii];
		selector.arg = "";

		for(unsigned ii=0; ii<selector.keyword.length(); ii++)
			selector.keyword[ii] = tolower(selector.keyword[ii]);
		
		selectors.push_back(selector);
	}
}

template<class PickedType>
PickedType FallbackSelector<PickedType>::evaluateSingle(string desc, PickedType notsingle, const ElementContext *context)
{
	FallbackSelector<PickedType> selector(desc);
	set<PickedType> results = selector.evaluate(context);
	if(results.size() != 1)
		return notsingle;
	else
		return *results.begin();
}

template<class PickedType>
set<PickedType> FallbackSelector<PickedType>::evaluate(const ElementContext *context)
{
	for(size_t ii=0; ii<selectors.size(); ii++)
	{
		// Putting 'none' at the end of a list of selectors prevents using the
		// default fallbacks.
		if(selectors[ii].keyword == "none")
			break;
		
		set<PickedType> results = evalKeyword(selectors[ii].keyword, selectors[ii].arg);
		if(results.size() > 0)
			return results;
	}
	
	return set<PickedType>();
}
*/

set<VirtualDesktop*> findDesks(string description);
set<Monitor*> findMonitors(string description);
set<WindowData*> findWindows(string description);
VirtualDesktop* findSingleDesk(string description);
Monitor* findSingleMonitor(string description);
WindowData* findSingleWindow(string description);

set<VirtualDesktop*> deskByDescription(string desc, string arg);
set<Monitor*> monitorByDescription(string desc, string arg);
set<WindowData*> windowByDescription(string desc, string arg);
