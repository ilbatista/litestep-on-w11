/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

void VWM::updateTaskLists(bool keepEmpties)
{
	// Match tasks up to VWMs
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		desktops[ii]->tasks.clear();
	}
	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
	{
		WindowData *window = ii->second;
		
		if(!window || !window->desk)
			continue;
		if(!window->isTask)
			continue;
		
		window->desk->tasks.push_back(window);
	}
	
	// If any desk has no tasks on it, delete it, try to delete it. This will
	// fail if that would mean there weren't enough desks to cover every
	// monitor.
	if(!settings->keepEmptyDesktops && !keepEmpties)
	{
		for(unsigned ii=0; ii<desktops.size(); ii++)
		{
			if(desktops[ii]->tasks.size())
				continue;
			if(desktops[ii]->monitor && settings->keepEmptyFocusedDesktop)
				continue;
			
			if(destroyDesktop(desktops[ii])) {
				ii--;
			}
		}
	}
}



RECT VWM::getGatherTarget(RECT source, Monitor *targetMonitor)
{
	Rect ret = source;
	Rect maximizeArea = targetMonitor->getMaximizeArea();
	
	// If this is inside a VWM's storage area, first bring it in
	VirtualDesktop *desk = deskFromLocation(source);
	if(desk && !desk->monitor)
		desk->offScreenStorage->unstoreRect(ret);
	targetMonitor->storageArea->storeRect(ret);
	
	// TODO: Get the window-maximize region, rather than using (0,0,w,h).
	
	int offsetX=0;
	int offsetY=0;
	
	// If a window is wider or taller than the screen, center it. Otherwise,
	// match an edge. (This happens more often than you'd think, because
	// maximized windows are a few pixels bigger than the maximize-area so
	// that their borders fall offscreen.)
	if(ret.width > maximizeArea.width) {
		if(ret.left > maximizeArea.left || ret.getRight() < maximizeArea.getRight())
			ret.left = maximizeArea.left - (ret.width-maximizeArea.width)/2;
	} else if(ret.getRight() > maximizeArea.getRight()) {
		ret.left -= ret.getRight() - maximizeArea.getRight();
	} else if(ret.left < maximizeArea.left) {
		ret.left = maximizeArea.left;
	}
	
	if(ret.height > maximizeArea.height) {
		if(ret.top > maximizeArea.top || ret.getBottom() < maximizeArea.getBottom())
			ret.top = maximizeArea.top - (ret.height-maximizeArea.height)/2;
	} else if(ret.getBottom() > maximizeArea.getBottom()) {
		ret.top += maximizeArea.getBottom() - ret.getBottom();
	} else if(ret.top < maximizeArea.top) {
		ret.top = maximizeArea.top;
	}
	
	return ret;
}


VirtualDesktop *VWM::deskFromLocation(Rect pos)
{
	// If it's on-screen, it's on the focused desk
	/*Rect screenRect(SCREEN_LEFT, SCREEN_TOP, SCREEN_WIDTH, SCREEN_HEIGHT);
	if(pos.overlaps(screenRect))
		return currentDesktop;*/
	vector<Monitor*> monitorsShownOn = monitors->findMonitor(pos);
	if(monitorsShownOn.size())
		return monitorsShownOn[0]->getDesk();
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		Rect storageRect = desk->offScreenStorage->getRect();
		if(storageRect.overlaps(pos)) {
			return desk;
		}
	}
	
	//trace << "Found off-screen window at "<<pos.toString()<<"\n";
	//for(unsigned ii=0; ii<desktops.size(); ii++)
	//	trace << "\tOff-screen desk: " << desktops[ii]->offScreenStorage->getRect()<<"\n";//DEBUG
	
	return NULL;
}
