/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

GroupElement::GroupElement(string prefix)
	:LayoutElement(prefix)
{
	string elementList = getConfigLine("Elements", NULL, prefix.c_str());
	layoutPool->parseElementList(elementList, &children);
	baseLength = getConfigInt("BaseLength", 0, prefix.c_str());
}

GroupElement::~GroupElement()
{
}

LayoutCacheNode *GroupElement::buildLayout(ElementContext *context, LayoutCacheNode *prev)
{
	LayoutCacheNode *ret = LayoutElement::buildLayout(context, prev);
	ret->element = this;
	
	if(prev) {
		// Verify that all the children are as they should be (only reason
		// they wouldn't is if the configured list of elements changed)
		bool sameChildren = true;
		if(children.size() != ret->children.size()) {
			sameChildren = false;
		} else {
			for(unsigned ii=0; ii<children.size(); ii++) {
				if(ret->children[ii]->element != children[ii]) {
					sameChildren = false;
					break;
				}
			}
		}
		
		if(sameChildren) {
			// Update the childrens' layouts to the new context
			for(unsigned ii=0; ii<ret->children.size(); ii++) {
				ret->children[ii] = children[ii]->buildLayout(context, ret->children[ii]);
				ret->children[ii]->parent = ret;
			}
			return ret;
		} else {
			// If there was a previous layout but it's mismatched, we get here
			// and continue on to rebuild the children from scratch.
			ret->children.clear();
		}
	}
	
	for(unsigned ii=0; ii<children.size(); ii++) {
		LayoutCacheNode *child = children[ii]->buildLayout(context, NULL);
		child->parent = ret;
		ret->children.push_back(child);
	}
	return ret;
}

pair<int,int> GroupElement::getLength(ElementContext *context, bool vertical)
{
	int minLength = 0;
	int preferredLength = 0;
	
	for(unsigned ii=0; ii<children.size(); ii++) {
		pair<int,int> childLength = children[ii]->getLength(context, vertical);
		if(childLength.first > minLength) minLength = childLength.first;
		if(childLength.second > preferredLength) preferredLength = childLength.second;
	}
	return pair<int,int>(minLength+baseLength, preferredLength+baseLength);
}
