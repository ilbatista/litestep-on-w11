/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

void printLayout(LayoutCacheNode *node, int indentLevel);

/////////////////////////////////////////////////////////////////////////////

struct ElementContext
{
	ElementContext();
	ElementContext(VWMPanel *panel, Monitor *monitor, VWM *vwm, VirtualDesktop *desk, WindowData *task, const Rect &boundingRect);
	
	/// True ifef all fields match, except boundingRect, which may differ
	bool match(const ElementContext &rhs) const;
	
	VWMPanel *panel;
	Monitor *monitor;
	VWM *vwm;
	VirtualDesktop *desk;
	WindowData *task;
	void *childData;
	Rect boundingRect;
};
extern ElementContext *clickContext;
extern ElementContext *droppedContext;

struct LayoutLocation
{
	LayoutElement *element;
	ElementContext context;
};

/////////////////////////////////////////////////////////////////////////////

class LayoutCacheNode
{
public:
	LayoutCacheNode(LayoutElement *element, ElementContext *context);
	~LayoutCacheNode();
	LayoutCacheNode *elementAtPoint(int x, int y);
	void traverse(vector<LayoutCacheNode*> &visited);
	
	/// Find the bottom-most element which has this node as a descendant and
	/// which has a variable [element-prefix][suffix] defined. Being defined as
	/// the empty string doesn't count. If there is no such element, returns
	/// NULL.
	LayoutCacheNode *findSuffix(string suffix);
	
	bool visited;
	
	LayoutElement *element;
	LayoutElement *origElement;
	ElementContext context;
	
	LayoutCacheNode *parent;
	vector<LayoutCacheNode*> children;
};

/////////////////////////////////////////////////////////////////////////////

static const int mouseNumButtons = 3;
enum MouseButton {
	mouseLeft=0,
	mouseRight,
	mouseMiddle,
};
enum MouseAction {
	mouseMove = 0,
	mouseDown,
	mouseUp,
};

/////////////////////////////////////////////////////////////////////////////

class LayoutElement
{
public:
	LayoutElement(string prefix);
	virtual ~LayoutElement();
	
	virtual LayoutCacheNode *buildLayout(ElementContext *context, LayoutCacheNode *prevLayout);
	
	/// Returns the minimum (first) and preferred (second) length of this
	/// element. In flow layouts, size along one axis (thickness) is fixed
	/// while size on the other axis (length) may vary. Layout may be built
	/// with length less than preferred because total length is limited by the
	/// size of the screen.
	virtual pair<int,int> getLength(ElementContext *context, bool vertical)=0;
	
	virtual void draw(HDC drawContext, LayoutCacheNode *layout);
	virtual bool changed(LayoutCacheNode *node);
	
	virtual bool isModule();
	string toString() const;
	
	string prefix;
	
	string onPress[mouseNumButtons];
	string onRelease[mouseNumButtons];
	string onClick[mouseNumButtons];
	bool draggable;
	LayoutElement *dragPlaceholder;
};

/////////////////////////////////////////////////////////////////////////////

class LayoutPool
{
public:
	~LayoutPool();
	
	void parseElementList(const string &elements, vector<LayoutElement*> *elementList);
	LayoutElement *getElement(string prefix);
	
protected:
	map<string, LayoutElement*> elements;
};
extern LayoutPool *layoutPool;

