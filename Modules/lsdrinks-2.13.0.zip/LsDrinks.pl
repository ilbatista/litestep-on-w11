# e:\Perl\ -w
#############################################################################
# lsDrinks 2.13.0                                                              
# Hacked up by : nf0 <nf0@10500bc.org>                                       
#                                                                           
# Thanks to Charlie <ishamael@orodruin.ddns.org> for making asDrinks        
# Thanks to Flip for making flipsthing.
# Thanks to Spawn@desktopz.org for helping out and making suggestions
# Thanks to Tin_Omin <desktopian.org> for the best site on the net and
# helping the community with with some backends.                           
# Thanks to MrJukes and geekMASTR for provinding community backends.
# Thanks to Aemergin for submitting some code to help under Win2k and IE 5.                                                                                                               
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to:
#   the Free Software Foundation, Inc.
#   59 Temple Place - Suite 330
#   Boston, MA  02111-1307, USA.
###############################################################################

require 5.004;
use strict;
use Socket;

my $rcfile   = "lsdrinks.rc";
my %drinkvals;
my $drinkvals = "$rcfile";
open(DRINKVALS, $drinkvals);
  while (<DRINKVALS>) {
    chomp;
    next if /^\s*\#/;
    next unless /=/;
    my ($key, $value) = split(/=/, $_, 2);
    $value =~ s/(\$(\w+))/$drinkvals{$2}/g;
    $drinkvals{$key} = $value;
  }
close(DRINKVALS);

my $startdir    = $drinkvals{maindir};
my $style       = $drinkvals{style};
my $feedback    = $drinkvals{feedback};
my $folderval   = $drinkvals{folderval};
my $pageval     = $drinkvals{pageval};
my $pagename    = $drinkvals{pagename};
my $slashdir 	= $drinkvals{slashdot_dir};
my $fmdir 	= $drinkvals{freshmeat_dir};
my $segdir 	= $drinkvals{segfault_dir};
my $ltdir 	= $drinkvals{linuxtoday_dir};
my $dtdir 	= $drinkvals{desktopian_dir};
my $ttdir 	= $drinkvals{technotronic_dir};
my $gndir 	= $drinkvals{geeknews_dir};
my $bitsdir 	= $drinkvals{bits32_dir};
my $bndir 	= $drinkvals{betanews_dir};
my $atdir 	= $drinkvals{arstechnica_dir};
my $fldir 	= $drinkvals{floach_dir};
my $bendir 	= $drinkvals{benews_dir};
my $becdir 	= $drinkvals{beoscentral_dir};
my $thodir 	= $drinkvals{themesorg_dir};
my $scdir 	= $drinkvals{solariscentral_dir};
my $lgdir 	= $drinkvals{linuxgames_dir};
my $ladir 	= $drinkvals{linuxapps_dir};
my $hndir 	= $drinkvals{hackernews_dir};
my $hpndir 	= $drinkvals{happypenguinnews_dir};
my $hpudir 	= $drinkvals{happypenguinupdates_dir};
my $hpadir 	= $drinkvals{happypenguinadd_dir};
my $lqdir 	= $drinkvals{linuxquake_dir};
my $agdir  	= $drinkvals{absolutegamers_dir};
my $l3ddir 	= $drinkvals{linux3d_dir};
my $f3ddir 	= $drinkvals{fullon3d_dir};
my $g3ddir      = $drinkvals{gizmo3d_dir};
my $blndir      = $drinkvals{bluesnews_dir};
my $vedir	= $drinkvals{voodooextreme_dir};
my $cmdir       = $drinkvals{chunkymunky_dir};
my $podir 	= $drinkvals{python_dir};
my $ufdir       = $drinkvals{uf_dir};
my $apoddir     = $drinkvals{apod_dir};
my $fileforumdir= $drinkvals{fileforum_dir};
my $dilbertdir  = $drinkvals{dilbert_dir};
my $shellcitydir= $drinkvals{shellcity_dir};
my $aftery2kdir = $drinkvals{aftery2k_dir};
my $litestepnetdir   = $drinkvals{litestepnet_dir};
my $litestepnetssdir = $drinkvals{litestepnetss_dir};
my $litestepnettdir  = $drinkvals{litestepnett_dir};
my $geeknewsorgdir   = $drinkvals{geeknewsorg_dir};
my $demonewsdir = $drinkvals{demonews_dir};
my $pvponlinedir     = $drinkvals{pvponline_dir};
my $scifiwiredir = $drinkvals{scifiwire_dir};
my $techreportdir = $drinkvals{techreport_dir};
my $ultimateosdir = $drinkvals{ultimateos_dir};
my $tughousedir = $drinkvals{tughouse_dir};
my $graphitedir = $drinkvals{graphite_dir};
my $shellscapedir = $drinkvals{shellscape_dir};
my $darkstepdir = $drinkvals{darkstep_dir};
my $fileclicksdir = $drinkvals{fileclicks_dir};
my $pennyarcadedir = $drinkvals{pennyarcade_dir};
my $geeknikdir = $drinkvals{geeknik_dir};
my $newscomdir = $drinkvals{newscom_dir};
my $wirednewsdir = $drinkvals{wirednews_dir};
my $pmsnippetsdir=$drinkvals{pmsnippets_dir};
my $pmcoolusesdir=$drinkvals{pmcooluses_dir};
my $pmpoetrydir=$drinkvals{pmpoetry_dir};
my $pmobfusdir=$drinkvals{pmobfus_dir};
my $pmcraftdir=$drinkvals{pmcraft_dir};
my $pmmeddir=$drinkvals{pmmed_dir};
my $mjnewsdir=$drinkvals{mjnews_dir};
my $mjideasdir=$drinkvals{mjideas_dir};
my $mjsnipsdir=$drinkvals{mjsnips_dir};
my $tekreviewdir=$drinkvals{tekreview_dir};
my $ebgdir=$drinkvals{ebg_dir};
my $aicndir=$drinkvals{aicn_dir};
my $epocnewsdir=$drinkvals{epocnews_dir};
my $sinfestdir=$drinkvals{sinfest_dir};
my $roadwafflesdir=$drinkvals{roadwaffles_dir};
my $joeaveragedir=$drinkvals{joeaverage_dir};
my $avalonhighdir=$drinkvals{avalonhigh_dir};
my $houndsdir=$drinkvals{hounds_dir};
my $goatsdir=$drinkvals{goats_dir};
my $sitspindir=$drinkvals{sitspin_dir};
my $funnyfarmdir=$drinkvals{funnyfarm_dir};
my $brunodir=$drinkvals{bruno_dir};
my $newshoundsdir=$drinkvals{newshounds_dir};
my $gpfdir=$drinkvals{gpf_dir};
my $elflifedir=$drinkvals{elflife_dir};
my $cmptrdir=$drinkvals{cmptr_dir};
my $linux2000dir=$drinkvals{linux2000_dir};
my $palmstationdir=$drinkvals{palmstation_dir};
my $pdabuzzdir=$drinkvals{pdabuzz_dir};
my $palminfocenterdir=$drinkvals{palminfocenter_dir};
my $appwatchdir=$drinkvals{appwatch_dir};
my $daemonnewsdir=$drinkvals{daemonnews_dir};
my $icewalkersdir=$drinkvals{icewalkers_dir};
my $thenewosdir=$drinkvals{thenewos_dir};
my $wonkoslicedir=$drinkvals{wonkoslice_dir};
my $neofluxdir=$drinkvals{neoflux_dir};
my $digitaltheatredir=$drinkvals{digitaltheatre_dir};
my @which       = ($drinkvals{slashdot},$drinkvals{freshmeat},$drinkvals{segfault},$drinkvals{linuxtoday},$drinkvals{desktopian},
                   $drinkvals{technotronic},$drinkvals{geeknews},$drinkvals{bits32},$drinkvals{betanews},$drinkvals{arstechnica},
                   $drinkvals{floach},$drinkvals{benews},$drinkvals{beoscentral},$drinkvals{themesorg},$drinkvals{solariscentral},
                   $drinkvals{linuxgames},$drinkvals{linuxapps},$drinkvals{hackernews},$drinkvals{happypenguinnews},
                   $drinkvals{happypenguinupdates},$drinkvals{happypenguinadd},$drinkvals{linuxquake},$drinkvals{absolutegamers},
                   $drinkvals{linux3d},$drinkvals{fullon3d},$drinkvals{gizmo3d},$drinkvals{bluesnews},$drinkvals{voodooextreme},
                   $drinkvals{chunkymunky},$drinkvals{python},$drinkvals{userfriendly},$drinkvals{apod},$drinkvals{fileforum},
                   $drinkvals{dilbert},$drinkvals{shellcity},$drinkvals{aftery2k},$drinkvals{litestepnet},
                   $drinkvals{litestepnetss},$drinkvals{litestepnett},$drinkvals{geeknewsorg},$drinkvals{demonews},
                   $drinkvals{pvponline},$drinkvals{scifiwire},$drinkvals{techreport},$drinkvals{ultimateos},
                   $drinkvals{tughouse},$drinkvals{graphite},$drinkvals{shellscape},$drinkvals{darkstep},
                   $drinkvals{fileclicks},$drinkvals{pennyarcade},$drinkvals{geeknik},$drinkvals{newscom},$drinkvals{wirednews},
                   $drinkvals{pmsnippets},$drinkvals{pmcooluses},$drinkvals{pmpoetry},$drinkvals{pmobfus},
                   $drinkvals{pmcraft},$drinkvals{pmmed},$drinkvals{mjnews},$drinkvals{mjideas},$drinkvals{mjsnips},
                   $drinkvals{tekreview},$drinkvals{ebg},$drinkvals{aicn},$drinkvals{epocnews},$drinkvals{sinfest},
                   $drinkvals{roadwaffles},$drinkvals{joeaverage},$drinkvals{avalonhigh},$drinkvals{hounds},$drinkvals{goats},
                   $drinkvals{sitspin},$drinkvals{funnyfarm},$drinkvals{bruno},$drinkvals{newshounds},$drinkvals{gpf},
                   $drinkvals{elflife},$drinkvals{cmptr},$drinkvals{linux2000},$drinkvals{palmstation},$drinkvals{pdabuzz},
                   $drinkvals{palminfocenter},$drinkvals{appwatch},$drinkvals{daemonnews},$drinkvals{icewalkers},
                   $drinkvals{thenewos},$drinkvals{wonkoslice},$drinkvals{neoflux},$drinkvals{digitaltheatre},
                   );
my $border	= $drinkvals{border};
my $back	= $drinkvals{back};
my $entryback	= $drinkvals{entryback};
my $bodyback	= $drinkvals{bodyback};
my $bodytext	= $drinkvals{bodytext};
my $bodylink	= $drinkvals{bodylink};
my $bodyvlink	= $drinkvals{bodyvlink};
my $bodyalink   = $drinkvals{bodyalink};
my $limit       = $drinkvals{limit};
my @order       = ($drinkvals{1},$drinkvals{2},$drinkvals{3},$drinkvals{4},$drinkvals{5},
                   $drinkvals{6},$drinkvals{7},$drinkvals{8},$drinkvals{9},$drinkvals{10},
                   $drinkvals{11},$drinkvals{12},$drinkvals{13},$drinkvals{14},$drinkvals{15},
                   $drinkvals{16},$drinkvals{17},$drinkvals{18},$drinkvals{19},$drinkvals{20},
                   $drinkvals{21},$drinkvals{22},$drinkvals{23},$drinkvals{24},$drinkvals{25},
                   $drinkvals{26},$drinkvals{27},$drinkvals{28},$drinkvals{29},$drinkvals{30},
                   $drinkvals{31},$drinkvals{32},$drinkvals{33},$drinkvals{34},$drinkvals{35},
                   $drinkvals{36},$drinkvals{37},$drinkvals{38},$drinkvals{39},$drinkvals{40},
                   $drinkvals{41},$drinkvals{42},$drinkvals{43},$drinkvals{44},$drinkvals{45},
                   $drinkvals{46},$drinkvals{47},$drinkvals{48},$drinkvals{49},$drinkvals{50},
                   $drinkvals{51},$drinkvals{52},$drinkvals{53},$drinkvals{54},$drinkvals{55},
                   $drinkvals{56},$drinkvals{57},$drinkvals{58},$drinkvals{59},$drinkvals{60},
                   $drinkvals{61},$drinkvals{62},$drinkvals{63},$drinkvals{64},$drinkvals{65},
                   $drinkvals{66},$drinkvals{67},$drinkvals{68},$drinkvals{69},$drinkvals{70},
                   $drinkvals{71},$drinkvals{72},$drinkvals{73},$drinkvals{74},$drinkvals{75},
                   $drinkvals{76},$drinkvals{77},$drinkvals{78},$drinkvals{79},$drinkvals{80},
                   $drinkvals{81},$drinkvals{82},$drinkvals{83},$drinkvals{84},$drinkvals{85},
                   $drinkvals{86},$drinkvals{87},$drinkvals{88},$drinkvals{89},$drinkvals{90},
                   $drinkvals{91});


my ($remote,$file,$backend,$port,$iaddr,$paddr,$proto);
my ($line,$first,$second,$third,$fourth,$fifth,$sixth,$seventh,$eighth,$ninth,$tenth,$pattern,$pattern1,$pattern2,$pattern3,$pattern4,$flag);
my ($linecount,$linenumber,$topic,$blocklength,$num,$fromtop,$topicline,$linkline,$dir,$x,$y);
my ($header1,$header2,$i,$a);


# Get the news.

if($pageval == 1){
  createpage();
  header();
}

if ($style == 0){
  for($i = 0; $i < @which; $i++){
    if($which[$i] == 1){
      if($i == 0){
        lsVodka();
      }elsif($i == 1){
        lsWhiskey();
      }elsif($i == 2){
        lsRum();  
      }elsif($i == 3){
        lsGin();  
      }elsif($i == 4){
        lsHotDamn();  
      }elsif($i == 5){
        lsBeer();
      }elsif($i == 6){
        lsJolt();  
      }elsif($i == 7){
        lsWine();  
      }elsif($i == 8){
        lsAfterShock();  
      }elsif($i == 9){
        lsButterScotch();  
      }elsif($i == 10){
        lsScotch();  
      }elsif($i == 11){
        lsMartini();
      }elsif($i == 12){
        lsAbsolut();
      }elsif($i == 13){
        lsMalibu();
      }elsif($i == 14){
        lsSouthernComfort();
      }elsif($i == 15){
        lsLG();
      }elsif($i == 16){
        lsLA();
      }elsif($i == 17){
        lsHN();
      }elsif($i == 18){
        lsHPN();
      }elsif($i == 19){
        lsHPU();
      }elsif($i == 20){
        lsHPA();
      }elsif($i == 21){
        lsLQ();
      }elsif($i == 22){
        lsAGF();
      }elsif($i == 23){
        lsL3D();
      }elsif($i == 24){
        lsF3D();
      }elsif($i == 25){
        lsG3D();
      }elsif($i == 26){
        lsBLN();
      }elsif($i == 27){
        lsVE();
      }elsif($i == 28){
        lsCM();
      }elsif($i == 29){
        lsPO();
      }elsif($i == 30){
        lsUF();
      }elsif($i == 31){
        lsAPOD();
      }elsif($i == 32){
        lsff();
      }elsif($i == 33){
        lsDil();
      }elsif($i == 34){
        lsSCity();
      }elsif($i == 35){
        lsAY2k();
      }elsif($i == 36){
        lsLSnet();
      }elsif($i == 37){
        lsLSnetss();
      }elsif($i == 38){
        lsLSnett();
      }elsif($i == 39){
        lsGeekNewsOrg();
      }elsif($i == 40){
        lsDemoNews();
      }elsif($i == 41){
      	lsPVPonline();
      }elsif($i == 42){
        lsSciFiWire();
      }elsif($i == 43){
        lsTechReport();
      }elsif($i == 44){
        lsUltimateOS();
      }elsif($i == 45){
        lsTugHouse();
      }elsif($i == 46){
        lsGraphite();
      }elsif($i == 47){
        lsShellScape();
      }elsif($i == 48){
        lsDarkStep();
      }elsif($i == 49){
        lsFileClicks();
      }elsif($i == 50){
        lsPennyArcade();
      }elsif($i == 51){
        lsGeekNik();
      }elsif($i == 52){
        lsNewsCom();
      }elsif($i == 53){
        lsWiredNews();
      }elsif($i == 54){
        lsPMSnippets();
      }elsif($i == 55){
        lsPMCoolUses();
      }elsif($i == 56){
        lsPMPoetry();
      }elsif($i == 57){
        lsPMObfus();
      }elsif($i == 58){
        lsPMCraft();
      }elsif($i == 59){
        lsPMMed();
      }elsif($i == 60){
        lsMJnews();
      }elsif($i == 61){
        lsMJideas();
      }elsif($i == 62){
        lsMJsnips();
      }elsif($i == 63){
        lsTekReview();
      }elsif($i == 64){
        lsEBG();
      }elsif($i == 65){
        lsAICN();
      }elsif($i == 66){
        lsEPOCnews();
      }elsif($i == 67){
        lsSinFest();
      }elsif($i == 68){
        lsRoadWaffles();
      }elsif($i == 69){
        lsJoeAverage();
      }elsif($i == 70){
        lsAvalonHigh();
      }elsif($i == 71){
        lsHounds();
      }elsif($i == 72){
        lsGoats();
      }elsif($i == 73){
        lsSitSpin();
      }elsif($i == 74){
        lsFunnyFarm();
      }elsif($i == 75){
        lsBruno();
      }elsif($i == 76){
        lsNewsHounds();
      }elsif($i == 77){
        lsGPF();
      }elsif($i == 78){
        lsElfLife();
      }elsif($i == 79){
        lsCMPTR();
      }elsif($i == 80){
        lsLinux2000();
      }elsif($i == 81){
        lsPalmStation();
      }elsif($i == 82){
        lsPDABuzz();
      }elsif($i == 83){
        lsPalmInfoCenter();
      }elsif($i == 84){
        lsAppWatch();
      }elsif($i == 85){
        lsDaemonNews();
      }elsif($i == 86){
        lsIceWalkers();
      }elsif($i == 87){
        lsTheNewOS();
      }elsif($i == 88){
        lsWonkoSlice();
      }elsif($i == 89){
        lsNeoFlux();
      }elsif($i == 90){
        lsDigitalTheatre();
      }
    }
  }
}elsif($style == 1){
  for($a = 0; $a < (@order); $a++){
    $x = $order[$a];
    if($x eq "slashdot"){lsVodka();}
    if($x eq "freshmeat"){lsWhiskey();}
    if($x eq "segfault"){lsRum();}
    if($x eq " linuxtoday"){lsGin();}  
    if($x eq "desktopian"){lsHotDamn();}  
    if($x eq "technotronic"){lsBeer();}
    if($x eq "geeknews"){lsJolt();}  
    if($x eq "bits32"){lsWine();}  
    if($x eq "betanews"){lsAfterShock();}  
    if($x eq "arstechnica"){lsButterScotch();}  
    if($x eq "floach"){lsScotch();}  
    if($x eq "benews"){lsMartini();}
    if($x eq "beoscentral"){lsAbsolut();}
    if($x eq "themesorg"){lsMalibu();}
    if($x eq "solariscentral"){lsSouthernComfort();}
    if($x eq "linuxgames"){lsLG();}
    if($x eq "linuxapps"){lsLA();}
    if($x eq "hackernews"){lsHN();}
    if($x eq "happypenguinnews"){lsHPN();}
    if($x eq "happypenguinupdates"){lsHPU();}
    if($x eq "happypenguinadd"){lsHPA();}
    if($x eq "linuxquake"){lsLQ();}
    if($x eq "absolutegamers"){lsAGF();}
    if($x eq "linux3d"){lsL3D();}
    if($x eq "fullon3d"){lsF3D();}
    if($x eq "gizmo3d"){lsG3D();}
    if($x eq "bluesnews"){lsBLN();}
    if($x eq "voodooextreme"){lsVE();}
    if($x eq "chunkymunky"){lsCM();}
    if($x eq "python"){lsPO();}
    if($x eq "userfriendly"){lsUF();}
    if($x eq "apod"){lsAPOD();}
    if($x eq "fileforum"){lsff();}
    if($x eq "dilbert"){lsDil();}
    if($x eq "shellcity"){lsSCity();}
    if($x eq "aftery2k"){lsAY2k();}
    if($x eq "litestepnet"){lsLSnet();}
    if($x eq "litestepnetss"){lsLSnetss();}
    if($x eq "litestepnett"){lsLSnett();}
    if($x eq "geeknewsorg"){lsGeekNewsOrg();}
    if($x eq "demonews"){lsDemoNews();}
    if($x eq "pvponline"){lsPVPonline();}
    if($x eq "scifiwire"){lsSciFiWire();}
    if($x eq "techreport"){lsTechReport();}
    if($x eq "ultimateos"){lsUltimateOS();}
    if($x eq "tughouse"){lsTugHouse();}
    if($x eq "graphite"){lsGraphite();}
    if($x eq "shellscape"){lsShellScape();}
    if($x eq "darkstep"){lsDarkStep();}
    if($x eq "fileclicks"){lsFileClicks();}
    if($x eq "pennyarcade"){lsPennyArcade();}
    if($x eq "geeknik"){lsGeekNik();}
    if($x eq "newscom"){lsNewsCom();}
    if($x eq "wirednews"){lsWiredNews();}
    if($x eq "pmsnippets"){lsPMSnippets();}
    if($x eq "pmcooluses"){lsPMCoolUses();}
    if($x eq "pmpoetry"){lsPMPoetry();}
    if($x eq "pmobfus"){lsPMObfus();}
    if($x eq "pmcraft"){lsPMCraft();}
    if($x eq "pmmed"){lsPMMed();}
    if($x eq "mjnews"){lsMJnews();}
    if($x eq "mjideas"){lsMJideas();}
    if($x eq "mjsnips"){lsMJsnips();}
    if($x eq "tekreview"){lsTekReview();}
    if($x eq "ebg"){lsEBG();}
    if($x eq "aicn"){lsAICN();}
    if($x eq "epocnews"){lsEPOCnews();}
    if($x eq "sinfest"){lsSinFest();}
    if($x eq "roadwaffles"){lsRoadWaffles();}
    if($x eq "joeaverage"){lsJoeAverage();}
    if($x eq "avalonhigh"){lsAvalonHigh();}
    if($x eq "hounds"){lsHounds();}
    if($x eq "goats"){lsGoats();}
    if($x eq "sitspin"){lsSitSpin();}
    if($x eq "funnyfarm"){lsFunnyFarm();}
    if($x eq "bruno"){lsBruno();}
    if($x eq "newshounds"){lsNewsHounds();}
    if($x eq "gpf"){lsGPF();}
    if($x eq "elflife"){lsElfLife();}
    if($x eq "cmptr"){lsCMPTR();}
    if($x eq "linux2000"){lsLinux2000();}
    if($x eq "palmstation"){lsPalmStation();}
    if($x eq "pdabuzz"){lsPDABuzz();}
    if($x eq "palminfocenter"){lsPalmInfoCenter();}
    if($x eq "appwatch"){lsAppWatch();}
    if($x eq "daemonnews"){lsDaemonNews();}
    if($x eq "icewalkers"){lsIceWalkers();}
    if($x eq "thenewos"){lsTheNewOS();}
    if($x eq "wonkoslice"){lsWonkoSlice();}
    if($x eq "neoflux"){lsNeoFlux();}
    if($x eq "digitaltheatre"){lsDigitalTheatre();}
  }
}
         

if ($pageval == 1){
	footer();
}

#############################################################################
# lsVodka section Slashdot
sub lsVodka {	
  if($feedback == 1) {	
    print "Getting Slashdot headlines.\n";
  }
  $header1 = "Slashdot";
  $header2 = "slashdot.org";
  $remote = "Slashdot.org";
  $file   = "ultramode.txt";
  $backend= "backend.slashdot";
  getbackend();
  $fromtop = 1;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 10;
  $dir = $slashdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;    	
}
#
#############################################################################

#############################################################################
# lsWhiskey section freshmeat
sub lsWhiskey {
  if($feedback == 1) {	
    print "Getting Freshmeat headlines.\n";
  }
  $header1 = "Freshmeat";
  $header2 = "freshmeat.net";
  $remote = "Freshmeat.net";
  $file   = "backend/recentnews.txt";
  $backend= "backend.freshmeat";
  getbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 3;
  $dir = $fmdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsRum section Segfault
sub lsRum {
  if($feedback == 1) {	
    print "Getting Segfault news.\n";
  }
  $header1 = "Segfault";
  $header2 = "segfault.org";
  $remote = "segfault.org";
  $file   = "stories.txt HTTP/1.1\nHost: segfault.org:80";
  $backend= "backend.segfault";
  getbackend();
  $fromtop = 20;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 7;
  $dir = $segdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsGin section LinuxToday
sub lsGin {
  if($feedback == 1) {	
    print "Getting Linux Today headlines.\n";
  }
  $header1 = "LinuxToday";
  $header2 = "linuxtoday.com";
  $remote = "63.236.72.248";
  $file   = "lthead.txt";
  $backend= "backend.linuxtoday";
  getbackend();
  $fromtop = 4;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 4;
  $dir = $ltdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsHotDamn section Desktopian
sub lsHotDamn {
  if($feedback == 1) {	
    print "Getting Desktopian News.\n";
  }      
  $header1 = "Desktopian";
  $header2 = "www.desktopian.org";
  $remote = "www.desktopian.org";
  $file   = "/includes/recentnews.txt";
  $backend= "backend.desktopian";
  getbackend();
  $fromtop = 4;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 4;
  $dir = $dtdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsBeer section Technotronic
sub lsBeer {
  if($feedback == 1) {	
    print "Getting Technotronic News.\n";
  }	      
  $header1 = "Technotronic";
  $header2 = "www.technotronic.com";
  $remote = "www.technotronic.com";
  $file   = "backend/headlines.txt HTTP/1.1\nHost: www.technotronic.com:80";
  $backend= "backend.technotronic";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $ttdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsJolt section Geeknews
sub lsJolt {
  if($feedback == 1) {	
    print "Getting Geeknews.\n";
  }	
  $header1 = "Geeknews";
  $header2 = "geeknews.net";
  $remote = "geeknews.net";
  $file   = "news/backend.txt";
  $backend= "backend.geeknews";
  getbackend();
  $fromtop = 0;
  $topicline = 6;
  $linkline = 7;
  $blocklength = 7;
  $dir = $gndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsWine  32BitsOnline
sub lsWine {
  if($feedback == 1) {	
    print "Getting 32bits Online news.\n";
  }	
  $header1 = "32BitsOnline";
  $header2 = "www.32bitsonline.com";
  $remote = "www.32bitsonline.com";
  $file   = "index.php3";
  $backend= "backend.32bits";
  $pattern = "<a href=\"http:\/\/www.32bitsonline.com\/article.php3";
  $pattern2 = "<br><b><font size=";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $bitsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsAfterShock section betanewsnews
sub lsAfterShock {
  if($feedback == 1) {
    print "Getting BetaNews.\n";
  }	
  $header1 = "Betanews";
  $header2 = "betanews.efront.com";
  $remote = "betanews.efront.com";
  $file   = "backend.php3 HTTP/1.1\nHost: betanews.efront.com:80";
  $backend= "backend.betanews";
  getbackend();
  $fromtop = 8;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 3;
  $dir = $bndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsButterScotch section arsTechnica
sub lsButterScotch {
  if($feedback == 1) {	
    print "Getting Ars Technica headlines.\n";
  }
  $header1 = "arsTechnica";
  $header2 = "arstechnica.com";
  $remote = "arstechnica.com";
  $file   = "heads.txt";
  $backend= "backend.ars";
  getbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $atdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsScotch Floach
sub lsScotch {
  if($feedback == 1) {	
    print "Getting Floach headlines. \n";
  }	
  $header1 = "Floach";
  $header2 = "floach.pimpin.net";
  $remote = "floach.pimpin.net";
  $file = "index.php3";
  $backend= "backend.floach";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $fldir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsMartini BeNews
sub lsMartini {
  if($feedback == 1) {	
    print "Getting BeNews. \n";
  }	
  $header1 = "BeNews";
  $header2 = "www.benews.com";
  $remote = "www.benews.com";
  $file   = "/story/headlines/10 HTTP/1.1\nHost: www.benews.com:80\n";
  $backend= "backend.ben";
  getbackend();
  $fromtop = 8;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 3;
  $dir = $bendir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsAbsolut BeOS Central
sub lsAbsolut {
  if ($feedback == 1) {	
    print "Getting BeOS Central News. \n";
  }	
  $header1 = "BeOS Central";
  $header2 = "www.beoscentral.com";
  $remote = "www.beoscentral.com";
  $file   = "powerbosc.txt HTTP/1.1\nHost: www.beoscentral.com:80\n";
  $backend= "backend.bec";
  getbackend();
  $fromtop = 9;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 4;
  $dir = $becdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsMalibu Themes.Org
sub lsMalibu {
  if($feedback == 1) {	
    print "Getting Themes.Org. \n";
  }
  $header1 = "Themes.org";
  $header2 = "www.themes.org";
  $remote = "www.themes.org";
  $file   = "news.rdf.phtml HTTP/1.1\nHost: www.themes.org:80";
  $backend= "backend.tho";
  getbackend();
  fixbackend();
  $fromtop = 17;
  $topicline = 2;
  $linkline = 4;
  $blocklength = 12;
  $dir = $thodir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsSouthernComfort  Solaris Central
sub lsSouthernComfort {
  if($feedback == 1) {	
    print "Getting Solaris Central News. \n";
  }
  $header1 = "Solaris Central";
  $header2 = "www.solariscentral.rog";
  $remote = "www.solariscentral.org";
  $file   = "news/ultramode.txt HTTP/1.1\nHost: www.solariscentral.org:80";
  $backend= "backend.sc";
  getbackend();
  $fromtop = 16;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $scdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Linux Games
sub lsLG {
  if($feedback == 1) {
    print "Getting LinuxGames.com News. \n";
  }
  $remote = "www.linuxgames.com";
  $header1 = "Linux Games";
  $header2 = "www.linuxgames.com";
  $file   = "index.shtml HTTP/1.1\nHost: www.linuxgames.com:80";
  $backend= "backend.lg";
  $pattern = "<B><A NAME=\"";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $lgdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsLA section Linux Apps
sub lsLA {
  if($feedback == 1) {	
    print "Getting LinuxApps.com.  \n";
  }
  $header1 = "Linux Apps";
  $header2 = "www.linuxapps.com";
  $remote = "www.linuxapps.com";
  $file   = "backend/detailed.txt HTTP/1.1\nHost: www.linuxapps.com:80";
  $backend= "backend.la";
  getbackend();
  $fromtop = 9;
  $topicline = 2;
  $linkline = 8;
  $blocklength = 9;
  $dir = $ladir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsHN section Hackernews
sub lsHN {
  if($feedback == 1) {	
    print "Getting Hacker News.  \n";
  }
  $header1 = "Hackernews";
  $header2 = "www.hackernews.com";
  $remote = "www.hackernews.com";
  $file   = "misc/hnn.xml";
  $backend= "backend.hn";
  $pattern = "<item>";
  $pattern2 = "</channel>";
  $x = 0;
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 3;
  $linkline = 2;
  $blocklength = 3;
  $dir = $hndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Happypenguin Org News
sub lsHPN {
  if($feedback == 1) {	
    print "Getting Happy Penguin News. \n";
  }
  $header1 = "Happy Penguin News";
  $header2 = "happypenguin.org";
  $remote = "happypenguin.org";
  $file   = "html/news.txt HTTP/1.1\nHost: happypenguin.org:80";
  $backend= "backend.hpn";
  $pattern = "Content-Type: text/plain";
  $x = 0;
  getbackend();
  fixbackend();
  $fromtop = 8;
  $topicline = 2;
  $linkline = 4;
  $blocklength = 4;
  $dir = $hpndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Happy Penguin Updates
sub lsHPU {
  if($feedback == 1) {	
    print "Getting Happy Penguin Updates. \n";
  }      
  $header1 = "Happy Penquin Updates";
  $header2 = "happypenguin.org";
  $remote = "happypenguin.org";
  $file   = "html/updates.txt HTTP/1.1\nHost: happypenguin.org:80";
  $backend= "backend.hpu";
  getbackend();
  fixbackend();
  $fromtop = 36;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 4;
  $dir = $hpudir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Happy Penguin Adds
sub lsHPA {
  if($feedback == 1) {	
    print "Getting Happy Penguin Additions. \n";
  }
  $header1 = "Happy Penguin Adds";
  $header2 = "happypenguin.org";
  $remote = "happypenguin.org";
  $file   = "html/additions.txt HTTP/1.1\nHost: happypenguin.org:80";
  $backend= "backend.hpa";
  getbackend();
  fixbackend();
  $fromtop = 36;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 4;
  $dir = $hpadir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Linux Quake
sub lsLQ {
  if($feedback == 1) {	
    print "Getting Linux Quake News. \n";
   }
   $remote = "linuxquake.com";
   $header1 = "LinuxQuake";
   $header2 = "linuxquake.com";
   $file   = "last20.txt";
   $backend= "backend.lq";
   getbackend();
   fixbackend();
   $fromtop = 0;
   $topicline = 1;
   $linkline = 3;
   $blocklength = 4;
   $dir = $lqdir;
   addfolder();
   if($pageval == 1){
     tabletitle();
     tablerow();
   }
   return;
}
#
#############################################################################

#############################################################################
# Absolute Gamers
sub lsAGF {
  if($feedback == 1) {	 
    print "Getting Absolute Gamers Files. \n";
  }
  $header1 = "Absolute Gamers";
  $header2 = "files.gameaholic.com";
  $remote = "files.gameaholic.com";
  $file   = "agfa.rdf HTTP/1.1\nHost: files.gameaholic.com:80";
  $backend= "backend.ag";
  getbackend();
  fixbackend();
  $fromtop = 4;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $agdir;
  addfolder();
  if($pageval == 1){
     tabletitle();
     tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# Linux 3d
sub lsL3D {
  if($feedback == 1) {	
    print "Getting Linux3D News. \n";
  }
  $header1 = "Linux 3d";
  $header2 = "www.linux3d.net";
  $remote = "www.linux3d.net";
  $file   = "index.shtml";
  $backend= "backend.l3d";
  $pattern = "<font face=\"Arial, Helvetica\" size=\"2\"><a href=\"http:\/\/www.linux3d.net\/index.shtml";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $l3ddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Fullon 3d
sub lsF3D {
  if($feedback == 1) {	
    print "Getting FullON3D News. \n";
  }
  $header1 = "Fullon 3d";
  $header2 = "www.fullon3d.com";
  $remote = "www.fullon3d.com";
  $file   = "index.shtml";
  $backend= "backend.f3d";
  $pattern = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/hardware\/";
  $pattern2 = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/games\/";
  $pattern3 = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/opinionated\/";
  $pattern4 = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/general\/";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $f3ddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsG3D {
  if($feedback == 1) {	
    print "Getting Gizmo 3D News. \n";
  }
  $header1 = "Gizmo 3d";
  $header2 = "www.linux3d.net/gizmo3d/";
  $remote = "www.linux3d.net";
  $file   = "/gizmo3d/main.shtml";
  $backend= "backend.g3d";
  $pattern = "<p><strong><font face=\"Lucida Console\" size=\"3\" color=\"\#";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $g3ddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsBLN {
  if($feedback == 1) {	
    print "Getting BluesNews. \n";
  }
  $header1 = "BluesNews";
  $header2 = "www.bluesnews.com";
  $remote = "www.bluesnews.com";
  $file = "/cgi-bin/blammo.pl?mode=headlines";
  $backend= "backend.bln";
  $pattern = "HREF=\"http:\/\/www.bluesnews.com\/cgi-bin\/blammo.pl?display=";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 3;
  $linkline = 2;
  $blocklength = 3;
  $dir = $blndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsVE {
  if($feedback == 1) {	
    print "Getting VodooExtreme. \n";
  }
  $header1 = "VooDoo Extreme";
  $header2 = "www.voodooextreme.com";
  $remote = "www.voodooextreme.com";
  $file   = "/quick_load.mv?1";
  $backend= "backend.ve";
  $pattern = "<input type=\"checkbox\" name=\"x";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $vedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsCM {
  if($feedback == 1) {	
    print "Getting ChunkyMunky.com. \n";
  }
  $header1 = "ChunkyMunky";
  $header2 = "www.chunkymunky.com";
  $remote = "www.chunkymunky.com";
  $file   = "index.shtml";
  $backend= "backend.cm";
  $pattern = "<font face=\"Verdana,Arial,Geneva\" size=\"4\"><b>";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $cmdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPO {
  if($feedback == 1) {	
    print "Getting Python.org. \n";
  }
  $header1 = "Python";
  $header2 = "www.python.org";
  $remote = "www.python.org";
  $file   = "channews.rdf";
  $backend= "backend.po";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $podir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsUF {
   if($feedback == 1) {	
     print "Getting Userfriendly. \n";
   }
   $header1 = "UserFriendly";
   $header2 = "www.userfriendly.org";
   $remote = "www.userfriendly.org";
   $file   = "static/index.html";
   $backend= "backend.uf";
   getbackend();
   fixbackend();
   $dir = $ufdir;
   addfolder();
   if($pageval == 1){
     tabletitle();
     tablerow();
   }
   return;
}
#
#############################################################################

#############################################################################
# 
sub lsAPOD {
  if($feedback == 1) {	
    print "Getting Astronomy Picture of the Day. \n";
  }
  $header1 = "Astronomy Picture of the Day";
  $header2 = "antwrp.gsfc.nasa.gov/apod/ap.html";
  $remote = "antwrp.gsfc.nasa.gov";
  $file   = "apod/ap.html";
  $backend= "backend.apod";
  getbackend();
  fixbackend();
  $dir = $apoddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsff {
  if($feedback == 1) {	
    print "Getting FileForum. \n";
   }
   $header1 = "File Forum";
   $header2 = "fileforum.efront.com";
   $remote = "fileforum.efront.com";
   $file   = "backend.php3 HTTP/1.1\nHost: fileforum.efront.com:80";
   $backend= "backend.fileforum";
   getbackend();
   $fromtop = 8;
   $topicline = 1;
   $linkline = 5;
   $blocklength = 5;
   $dir = $fileforumdir;
   addfolder();
   if($pageval == 1){
     tabletitle();
     tablerow();
   }
   return;
}
#
#############################################################################

#############################################################################
# 
sub lsDil {
  if($feedback == 1) {	
    print "Getting Dilbert. \n";
  }
  $header1 = "Dilbert";
  $header2 = "www.unitedmedia.com/comics/dilbert/index.html";
  $remote = "www.unitedmedia.com";
  $file   = "comics/dilbert/index.html";
  $backend= "backend.dilbert";
  getbackend();
  fixbackend();
  $dir = $dilbertdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsSCity {
  if($feedback == 1) {	
    print "Getting ShellCity. \n";
  }
  $header1 = "Shell City";
  $header2 = "www.shellcity.net";
  $remote = "www.shellcity.net";
  $file   = "citynews.txt HTTP/1.1\nHost: www.shellcity.net:80";
  $backend= "backend.shellcity";
  getbackend();
  $fromtop = 15;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 4;
  $dir = $podir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAY2k {
  if($feedback == 1){
    print "Getting After Y2k. \n";
  }
  $header1 = "After Y2K";
  $header2 = "www.geekculture.com/geekycomics/Aftery2k/aftery2kmain.html";
  $remote = "www.geekculture.com";
  $file   = "geekycomics/Aftery2k/aftery2kmain.html";
  $backend= "backend.ay2k";
  getbackend();
  fixbackend();
  $dir = $aftery2kdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsLSnet {
  if($feedback == 1){
    print "Getting Litestep.Net. \n";
  }
  $header1 = "LiteStep.Net News";
  $header2 = "www.litestep.net";
  $remote = "www.litestep.net";
  $file   = "index.php3?ls_session=f6c817a19f349dd4a711f8210a297b1f HTTP/1.1\nHost: www.litestep.net:80";
  $backend= "backend.lsLSnet";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $litestepnetdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsLSnetss {
  if($feedback == 1){
    print "Getting Litestep.Net Screen Shots. \n";
  }
  $header1 = "LiteStep.Net Screen Shots";
  $header2 = "www.litestep.net";
  $remote = "www.litestep.net";
  $file   = "sshots.php3?ls_session=ee8dc49ae942a7127d6a65bd3d2bfd91 HTTP/1.1\nHost: www.litestep.net:80";
  $backend= "backend.lsLSnetss";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $litestepnetssdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsLSnett {
  if($feedback == 1){
    print "Getting Litestep.Net Themes. \n";
  }
  $header1 = "LiteStep.Net Themes";
  $header2 = "www.litestep.net";
  $remote = "www.litestep.net";
  $file   = "themes.php3?ls_session=ee8dc49ae942a7127d6a65bd3d2bfd91 HTTP/1.1\nHost: www.litestep.net:80";
  $backend= "backend.lsLSnett";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $litestepnettdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsGeekNewsOrg {
  if($feedback == 1){
    print "Getting Geek News Org. \n";
  }
  $header1 = "GeekNews.Org";
  $header2 = "www.geeknews.org";
  $remote = "www.geeknews.org";
  $file   = "headlines.txt HTTP/1.1\nHost: www.geeknews.org:80";
  $backend= "backend.geeknewsorg";
  getbackend();
  $fromtop = 9;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 3;
  $dir = $geeknewsorgdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsDemoNews {
  if($feedback == 1){
    print "Getting DemoNews. \n";
  }
  $header1 = "DemoNews";
  $header2 = "www.demonews.com";
  $remote = "www.demonews.com";
  $file   = "index.html HTTP/1.1\nHost: www.demonews.com:80";
  $backend= "backend.demonews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $demonewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPVPonline {
   if($feedback == 1) {	
     print "Getting PVPonline. \n";
   }
   $header1 = "PVPonline";
   $header2 = "www.pvponline.com";
   $remote = "www.pvponline.com";
   $file   = "index.shtml";
   $backend= "backend.pvponline";
   getbackend();
   fixbackend();
   $dir = $pvponlinedir;
   addfolder();
   if($pageval == 1){
     tabletitle();
     tablerow();
   }
   return;
}
#
#############################################################################

#############################################################################
# 
sub lsSciFiWire {
  if($feedback == 1){
    print "Getting SciFi Wire. \n";
  }
  $header1 = "SciFi Wire";
  $header2 = "www.scifi.com/scifiwire";
  $remote = "www.scifi.com";
  $file   = "scifiwire/index.html HTTP/1.1\nHost: www.scifi.com:80";
  $backend= "backend.scifiwire";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $scifiwiredir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsTechReport {
  if($feedback == 1){
    print "Getting Tech Report News. \n";
  }
  $header1 = "Tech Report";
  $header2 = "www.tech-report.com";
  $remote = "www.tech-report.com";
  $file   = "";
  $backend= "backend.techreport";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $techreportdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsUltimateOS {
  if($feedback == 1){
    print "Getting The Ultimate OS news. \n";
  }
  $header1 = "The Ultimate OS";
  $header2 = "theultimateos.com";
  $remote = "theultimateos.com";
  $file   = "";
  $backend= "backend.ultimateos";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $ultimateosdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsTugHouse {
  if($feedback == 1){
    print "Getting Tug House. \n";
  }
  $header1 = "Tug House";
  $header2 = "tughouse.tuginternet.com";
  $remote = "tughouse.tuginternet.com";
  $file   = "index.html HTTP/1.1\nHost: tughouse.tuginternet.com:80";
  $backend= "backend.tughouse";
  getbackend();
  fixbackend();
  $dir = $tughousedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsGraphite {
  if($feedback == 1){
    print "Getting Graphite news. \n";
  }
  $header1 = "Graphite News";
  $header2 = "www.graphite.sh";
  $remote = "www.graphite.sh";
  $file   = "";
  $backend= "backend.graphite";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $graphitedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsShellScape {
  if($feedback == 1){
    print "Getting ShellScape news. \n";
  }
  $header1 = "ShellScape News";
  $header2 = "www.shellscape.org";
  $remote = "www.shellscape.org";
  $file   = "dariusX/index.php3";
  $backend= "backend.shellscape";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $shellscapedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsDarkStep {
  if($feedback == 1){
    print "Getting DarkStep news. \n";
  }
  $header1 = "DarkStep";
  $header2 = "www.darkstep.com";
  $remote = "www.darkstep.com";
  $file   = "index.shtml";
  $backend= "backend.darkstep";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $darkstepdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsFileClicks {
  if($feedback == 1){
    print "Getting FileClicks. \n";
  }
  $header1 = "FileClicks";
  $header2 = "www.fileclicks.com";
  $remote = "www.fileclicks.com";
  $file   = "index.phtml HTTP/1.1\nHost: www.fileclicks.com:80";
  $backend= "backend.fileclicks";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $fileclicksdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPennyArcade {
  if($feedback == 1){
    print "Getting PennyArcade. \n";
  }
  $header1 = "PennyArcade";
  $header2 = "www.penny-arcade.com";
  $remote = "www.penny-arcade.com";
  $file   = "view.php3 HTTP/1.1\nHost: www.penny-arcade.com:80";
  $backend= "backend.pennyarcade";
  getbackend();
  fixbackend();
  $dir = $pennyarcadedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsGeekNik {
  if($feedback == 1){
    print "Getting GeekNik. \n";
  }
  $header1 = "Geeknik";
  $header2 = "www.geeknik.net";
  $remote = "www.geeknik.net";
  $file   = "index.shtml";
  $backend= "backend.geeknik";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $geeknikdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#

#############################################################################

#############################################################################
# 
sub lsNewsCom {
  if($feedback == 1){
    print "Getting NewsCom. \n";
  }
  $header1 = "News.Com";
  $header2 = "news.cnet.com";
  $remote = "news.cnet.com";
  $file   = "index.html";
  $backend= "backend.newscom";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $newscomdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsWiredNews {
  if($feedback == 1){
    print "Getting Wired News. \n";
  }
  $header1 = "Wired";
  $header2 = "www.wired.com";
  $remote = "www.wired.com";
  $file   = "news_drop/palmpilot/topstories/0,1326,,00.html";
  $backend= "backend.wired";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $newscomdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMSnippets {
  if($feedback == 1){
    print "Getting Perl Monks Snippets. \n";
  }
  $header1 = "Perl Monks Snippets";
  $header2 = "www.perlmonks.org/index.pl?node=Snippets%20Section";
  $remote = "www.perlmonks.org";
  $file   = "index.pl?node=Snippets%20Section HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmsnippets";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmsnippetsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMCoolUses {
  if($feedback == 1){
    print "Getting Perl Monks Cool Uses. \n";
  }
  $header1 = "Perl Monks Cool Uses of Perl";
  $header2 = "www.perlmonks.org/index.pl?node=Cool%20Uses%20for%20Perl";
  $remote = "www.perlmonks.org";
  $file   = "index.pl?node=Cool%20Uses%20for%20Perl HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmcooluses";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmcoolusesdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMPoetry {
  if($feedback == 1){
    print "Getting Perl Monks Poetry. \n";
  }
  $header1 = "Perl Monks Poetry";
  $header2 = "www.perlmonks.org/index.pl?node=Perl%20Poetry";
  $remote = "www.perlmonks.org";
  $file   = "index.pl?node=Perl%20Poetry HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmpoetry";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmpoetrydir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMObfus {
  if($feedback == 1){
    print "Getting Perl Monks Obfuscation. \n";
  }
  $header1 = "Perl Monks Obfuscation";
  $header2 = "www.perlmonks.org/index.pl?node=Obfuscated%20Code";
  $remote = "www.perlmonks.org";
  $file   = "index.pl?node=Obfuscated%20Code HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmobfus";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmobfusdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMCraft {
  if($feedback == 1){
    print "Getting Perl Monks Craft. \n";
  }
  $header1 = "Perl Monks Craft";
  $header2 = "www.perlmonks.org/index.pl?node=Craft";
  $remote = "www.perlmonks.org";
  $file   = "index.pl?node=Craft HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmcraft";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmcraftdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMMed {
  if($feedback == 1){
    print "Getting Perl Monks Meditations. \n";
  }
  $header1 = "Perl Monks Meditations";
  $header2 = "www.perlmonks.org/index.pl?node=Meditations";
  $remote = "www.perlmonks.org";
  $file   = "index.pl?node=Meditations HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmmed";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmmeddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsMJnews {
  if($feedback == 1){
    print "Getting Mind Junction News. \n";
  }
  $header1 = "Mind Junction News";
  $header2 = "www.mindjunction.com";
  $remote = "www.mindjunction.com";
  $file   = " HTTP/1.1\nHost: www.mindjunction.com:80";
  $backend= "backend.mjnews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mjnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsMJideas {
  if($feedback == 1){
    print "Getting Mind Junction Ideas. \n";
  }
  $header1 = "Mind Junction Ideas";
  $header2 = "www.mindjunction.com";
  $remote = "www.mindjunction.com";
  $file   = " HTTP/1.1\nHost: www.mindjunction.com:80";
  $backend= "backend.mjideas";
  $pattern1 = "index";
  $pattern2 = "Ideas";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mjideasdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsMJsnips {
  if($feedback == 1){
    print "Getting Mind CodeSnips. \n";
  }
  $header1 = "Mind Junction Code Snips";
  $header2 = "www.mindjunction.com";
  $remote = "www.mindjunction.com";
  $file   = "snips.php3 HTTP/1.1\nHost: www.mindjunction.com:80";
  $backend= "backend.mjsnip";
  $pattern1 = "snips";
  $pattern2 = "Snip";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mjsnipsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsTekReview {
  if($feedback == 1){
    print "Getting TekReview. \n";
  }
  $header1 = "TekReview";
  $header2 = "www.tekreview.com";
  $remote = "www.tekreview.com";
  $file   = "main.shtml HTTP/1.1\nHost: www.tekreview.com:80";
  $backend= "backend.tekreview";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $tekreviewdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsEBG {
  if($feedback == 1){
    print "Getting Everything But Gaming. \n";
  }
  $header1 = "Everything But Gaming";
  $header2 = "www.shlonglor.com";
  $remote = "www.shlonglor.com";
  $file   = "index.shtml HTTP/1.1\nHost: www.shlonglor.com:80";
  $backend= "backend.ebg";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $ebgdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAICN {
  if($feedback == 1){
    print "Getting Aint It Cool News. \n";
  }
  $header1 = "Aint It Cool News";
  $header2 = "www.aint-it-cool-news.com";
  $remote = "www.aint-it-cool-news.com";
  $file   = "index.html";
  $backend= "backend.aicn";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $aicndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsEPOCnews {
  if($feedback == 1){
    print "Getting EPOC News. \n";
  }
  $header1 = "EPOC News";
  $header2 = "www.epocnews.com";
  $remote = "www.epocnews.com";
  $file   = "index.php3?days=  HTTP/1.1\nHost: www.epocnews.com:80";
  $backend= "backend.epocnews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $epocnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsSinFest {
  if($feedback == 1){
    print "Getting Sinfest Comic. \n";
  }
  $header1 = "Sinfest Daily Comic";
  $header2 = "sinfest.net";
  $remote = "sinfest.net";
  $file   = "index.htm";
  $backend= "backend.sinfest";
  getbackend();
  fixbackend();
  $dir = $sinfestdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsRoadWaffles {
  if($feedback == 1){
    print "Getting RoadWaffles Comic. \n";
  }
  $header1 = "Road Waffles Daily Comic";
  $header2 = "www.roadwaffles.com";
  $remote = "www.roadwaffles.com";
  $file   = "index.html";
  $backend= "backend.roadwaffles";
  getbackend();
  fixbackend();
  $dir = $roadwafflesdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsJoeAverage {
  if($feedback == 1){
    print "Getting Joe Average Comic. \n";
  }
  $header1 = "Joe Average Daily Comic";
  $header2 = "www.joeaverage.org";
  $remote = "www.joeaverage.org";
  $file   = "index.html";
  $backend= "backend.joeaverage";
  getbackend();
  fixbackend();
  $dir = $joeaveragedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAvalonHigh {
  if($feedback == 1){
    print "Getting Avalon High Comic. \n";
  }
  $header1 = "Avalon High Daily Comic";
  $header2 = "www.avalonhigh.com";
  $remote = "www.avalonhigh.com";
  $file   = "index.html";
  $backend= "backend.avalonhigh";
  getbackend();
  fixbackend();
  $dir = $avalonhighdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsHounds {
  if($feedback == 1){
    print "Getting Hounds Home Comic. \n";
  }
  $header1 = "Hounds Home Daily Comic";
  $header2 = "www.houndshome.com";
  $remote = "www.houndshome.com";
  $file   = "index.html";
  $backend= "backend.hounds";
  getbackend();
  fixbackend();
  $dir = $houndsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsGoats {
  if($feedback == 1){
    print "Getting Goats Comic. \n";
  }
  $header1 = "Goats Daily Comic";
  $header2 = "www.goats.com";
  $remote = "www.goats.com";
  $file   = "index.html";
  $backend= "backend.goats";
  getbackend();
  fixbackend();
  $dir = $goatsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsSitSpin {
  if($feedback == 1){
    print "Getting Sit and Spin Comic. \n";
  }
  $header1 = "Sit and Spin Daily Comic";
  $header2 = "www.narisma.nu/sitandspin/index.html";
  $remote = "www.narisma.nu";
  $file   = "sitandspin/index.html";
  $backend= "backend.sitspin";
  getbackend();
  fixbackend();
  $dir = $sitspindir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsFunnyFarm {
  if($feedback == 1){
    print "Getting Funny Farm Comic. \n";
  }
  $header1 = "Funny Farm Daily Comic";
  $header2 = "www.funnyfarmcomics.com";
  $remote = "www.funnyfarmcomics.com";
  $file   = "index.html";
  $backend= "backend.funnyfarm";
  getbackend();
  fixbackend();
  $dir = $funnyfarmdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsBruno {
  if($feedback == 1){
    print "Getting Bruno The Bandit Comic. \n";
  }
  $header1 = "Bruno The Bandit Daily Comic";
  $header2 = "www.brunothebandit.com";
  $remote = "www.brunothebandit.com";
  $file   = "index.html";
  $backend= "backend.bruno";
  getbackend();
  fixbackend();
  $dir = $brunodir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsNewsHounds {
  if($feedback == 1){
    print "Getting News Hounds Comic. \n";
  }
  $header1 = "News Hounds Daily Comic";
  $header2 = "www.newshounds.com";
  $remote = "www.newshounds.com";
  $file   = "index.html";
  $backend= "backend.newshounds";
  getbackend();
  fixbackend();
  $dir = $newshoundsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsGPF {
  if($feedback == 1){
    print "Getting GPF Comic. \n";
  }
  $header1 = "GPF Daily Comic";
  $header2 = "www.gpf-comics.com";
  $remote = "www.gpf-comics.com";
  $file   = "index.html";
  $backend= "backend.gpf";
  getbackend();
  fixbackend();
  $dir = $gpfdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsElfLife {
  if($feedback == 1){
    print "Getting Elf Life Comic. \n";
  }
  $header1 = "Elf Life Daily Comic";
  $header2 = "www.elflife.com";
  $remote = "www.elflife.com";
  $file   = "index.html";
  $backend= "backend.elflife";
  getbackend();
  fixbackend();
  $dir = $elflifedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsCMPTR {
  if($feedback == 1){
    print "Getting CMPTR News. \n";
  }
  $header1 = "CMPTR News";
  $header2 = "www.cmptr.com";
  $remote = "www.cmptr.com";
  $file   = "dump/fontframe.txt";
  $backend= "backend.cmptr";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $cmptrdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsLinux2000 {
  if($feedback == 1){
    print "Getting Linux 2000 News. \n";
  }
  $header1 = "Linux 2000 News";
  $header2 = "www.linux-2000.org";
  $remote = "www.linux-2000.org";
  $file   = "news/newswire.txt";
  $backend= "backend.linux2000";
  getbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 5;
  $dir = $linux2000dir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPalmStation {
  if($feedback == 1){
    print "Getting PalmStation News. \n";
  }
  $header1 = "PalmStation News";
  $header2 = "www.palmstation.com";
  $remote = "www.palmstation.com";
  $file   = "index.shtml HTTP/1.1\nHost: www.palmstation.com:80";
  $backend= "backend.palmstation";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $palmstationdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPDABuzz {
  if($feedback == 1){
    print "Getting PDABuzz News. \n";
  }
  $header1 = "PDABuzz News";
  $header2 = "www.pdabuzz.com";
  $remote = "www.pdabuzz.com";
  $file   = "index.html";
  $backend= "backend.pdabuzz";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pdabuzzdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPalmInfoCenter {
  if($feedback == 1){
    print "Getting Palm Infocenter News. \n";
  }
  $header1 = "Palm Infocenter News";
  $header2 = "www.palminfocenter.com";
  $remote = "www.palminfocenter.com";
  $file   = "index.asp";
  $backend= "backend.palminfocenter";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $palminfocenterdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAppWatch {
  if($feedback == 1){
    print "Getting AppWatch Files. \n";
  }
  $header1 = "AppWatch Files";
  $header2 = "appwatch.com";
  $remote = "appwatch.com";
  $file   = "appwatch.rdf";
  $backend= "backend.appwatch";
  getbackend();
  fixbackend();
  $fromtop = 24;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 6;
  $dir = $appwatchdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsDaemonNews {
  if($feedback == 1){
    print "Getting Daemon News. \n";
  }
  $header1 = "Deamon News";
  $header2 = "daily.daemonnews.org";
  $remote = "daily.daemonnews.org";
  $file   = "index.php3";
  $backend= "backend.daemonnews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $daemonnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsIceWalkers {
  if($feedback == 1){
    print "Getting IceWalkers Files. \n";
  }
  $header1 = "IceWalkers";
  $header2 = "www.icewalkers.com";
  $remote = "www.icewalkers.com";
  $file   = "backend/lastheaders.txt";
  $backend= "backend.icewalkers";
  getbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 3;
  $dir = $daemonnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsTheNewOS {
  if($feedback == 1){
    print "Getting TheNewOS. \n";
  }
  $header1 = "The New OS";
  $header2 = "www.thenewos.com";
  $remote = "www.thenewos.com";
  $file   = "index.htm HTTP/1.1\nHost: www.thenewos.com:80";
  $backend= "backend.thenewos";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $thenewosdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsWonkoSlice {
  if($feedback == 1){
    print "Getting WonkoSlice News. \n";
  }
  $header1 = "WonkoSlice News";
  $header2 = "wonko.com";
  $remote = "wonko.com";
  $file   = "ultramode.asp";
  $backend= "backend.wonkoslice";
  getbackend();
  $fromtop = 20;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 10;
  $dir = $wonkoslicedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsNeoFlux {
  if($feedback == 1){
    print "Getting Neoflux News. \n";
  }
  $header1 = "NeoFlux News";
  $header2 = "www.neoflux.com";
  $remote = "www.neoflux.com";
  $file   = "index.shtml HTTP/1.1\nHost: www.neoflux.com:80";
  $backend= "backend.neoflux";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $neofluxdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsDigitalTheatre {
  if($feedback == 1){
    print "Getting Digital Theatre. \n";
  }
  $header1 = "Digital Theatre";
  $header2 = "www.dtheatre.com";
  $remote = "www.dtheatre.com";
  $file   = "backend.php3";
  $backend= "backend.digitaltheatre";
  getbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 3;
  $dir = $dititaltheatredir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub getbackend{
  $port = 80;
  $iaddr = inet_aton($remote) ||  "no host: $remote"; #return;
  $paddr = sockaddr_in($port, $iaddr);
  $proto = getprotobyname('tcp');
  socket(SOCK, PF_INET, SOCK_STREAM, $proto) ||  "socket: $!"; #return;
  connect(SOCK, $paddr) || "couldn't connect: $remote";#die "connect: $!";
  select(SOCK); $| = 1; select(STDOUT);
  if($remote ne "www.desktopian.org"){
    print SOCK "GET /$file\n\n";
  }else{
    print SOCK "GET http://$remote$file\n\n";
  }
  unlink($backend);
  open(BACKEND,">>$backend");
    while(<SOCK>){
      print BACKEND "$_";
    }
  close(BACKEND);
  close(SOCK) || die "close: $!";
  return;
  
}
#
############################################################################# 

sub fixbackend{
  open(BACKEND,"<$backend") || "Can't open $backend\n"; 
     while(<BACKEND>) {  
      $line = $_;
      $line=~ s/\]|\[//gi;
      my $i;
      $i = 0;
      if("$backend" eq "backend.technotronic"){
        $line =~ s/<b>/x&&/;
        $line =~ s/<\/b>/&&/;
        ($first,$second,$third) = split(/&&/ , $line);
        chomp($second);
        if($second ne ""){
          open(TEMP,">>temp");
            print TEMP "$second\n";
            print TEMP "http://$remote\n";
          close(TEMP);  
        }
      }elsif("$backend" eq "backend.32bits"){
        if($line =~ /^$pattern|$pattern2/) {
          $flag = 0;
          $line=~ s/issues/&&/;
          $line=~ s/\">/&&/g;
          $line=~ s/<\/a>/&&/;
          ($first,$second,$third,$fourth,$fifth) = split(/&&/ , $line,5);
          open(TEMP,">>temp");
            if($fifth =~ /<\/font>/){
              print TEMP "$fourth\n";
              print TEMP "http://$remote/article.php3?file=issues$third\n";
              $flag = 1
            }elsif($fourth=~ /.../ && $flag ne 1){
              print TEMP "$third\n";
              print TEMP "http://$remote/article.php3?file=issues$second\n";
            }
          close(TEMP);
        }
      }
      elsif("$backend" eq "backend.lg"){
        if($line =~ /$pattern/) {
          $line =~ s/<B><A NAME=\"/xx&&/;
          $line =~ s/\"><\/A>/ &&/;
          ($first, $second, $third) = split(/&&/,$line);
          $third = $second;
          open(TEMP, ">>temp");
            print TEMP "$third\n";
            print TEMP "http://$remote/index.shtml\n";
          close(TEMP);
        }        
      }elsif("$backend" eq "backend.hn"){
        if($line =~ /^$pattern/)  { 
	  $x = 1;
	}
        if($line =~ /^$pattern2/) {
          $x = 0;
        }
        if($x == 1){
          open(TEMP, ">>temp");
            $line =~ s/<item>/&&/;
            $line =~ s/<\/item>//;
            $line =~ s/<link>//;
            $line =~ s/<\/link>//;
            $line =~ s/<title>//;
            $line =~ s/<\/title>//;
            if($line ne "\n"){
              print TEMP $line;
            }
          close(TEMP);
         }
       }elsif("$backend" eq "backend.hpn"){
         if($line =~ /^$pattern/)  { 
           $line =~ s/^$pattern//;
	   $x = 1;
	 }
	 if($x == 1){
           $line =~ s/\n//;
           ($first, $second, $third) = split(/~@~#~/,$line);
           open(TEMP, ">>temp");
             $first =~ s/\n//;
             print TEMP "&&\n$first\n";
             print TEMP "$second\n";
             print TEMP "http://$remote\n";
           close(TEMP);
         }
       }elsif(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu") or ("$backend" eq "backend.lq")){
         ($first, $second, $third) = split(/~@~#~/,$line);
         open(TEMP, ">>temp");
           print TEMP "$first\n";
           print TEMP "$second\n";
           print TEMP "$third\n";
         close(TEMP);
       }elsif("$backend" eq "backend.ag"){
         if($line =~ /<title>|<link>/){
           $line =~ s/<link>//gi; $line =~ s/<\/link>//;
	   $line =~ s/<title>//;  $line =~ s/<\/title>//;
	   $line =~ s/\s//;
           open(TEMP, ">>temp");
             print TEMP $line;
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.l3d"){
         if($line =~ /$pattern/){
           $line =~ s/$pattern/xx&/;
           $line =~ s/\">/&/;
           $line =~ s/<\/a>/&/;
           ($first, $second, $third) = split(/&/,$line);
           open(TEMP, ">>temp");
             print TEMP "&&\n";
             print TEMP "$third\n";
             print TEMP "http://$remote/$file$second\n";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.f3d"){
         if($line =~ /$pattern|$pattern2|$pattern3|$pattern4/) {
           $line =~ s/href=\"/xx&/;
           $line =~ s/\">/&/;
           $line =~ s/<\/a>/&/;
           ($first, $second, $third) = split(/&/,$line);
           open(TEMP, ">>temp");
             print TEMP "$third\n";
             print TEMP "$second\n";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.g3d"){
         if($line =~ /$pattern/){
           $line =~ s/\">/xx&/;
           $line =~ s/<\/font>/&/;
           ($first, $second, $third) = split(/&/,$line);
           chomp($second);
           open(TEMP, ">>temp");
             print TEMP "$second\n";
             print TEMP "http://$remote$file\n";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.x11"){
         if($line =~ /^$pattern/)  {
           $line =~ s/<strong>\[Messages\]<br>//;
           $line =~ s/<strong>\[Screenshots\]<br>//;
           $flag = 1;
           $line =~ s/\">/xx&/;
           $line =~ s/<\/font>/&/;
           $line =~ s/\//_/;
           $line =~ s/\//_/;
           $line =~ s/\(//;
           $line =~ s/\)//;
           $line =~ s/://;
           $line =~ s/\s//;
           ($first, $second, $third) = split(/&/,$line);
           chomp($second);
           if("$second" ne ""){
             open(TEMP, ">>temp");
         	print TEMP "$second\n";
         	print TEMP "http://$remote$file\n";
             close(TEMP);
           }
         }  
       }elsif("$backend" eq "backend.mdt"){
         if($line =~ /$pattern/){
           $line =~ s/"><B>/&&/;
           $line =~ s/<\/B>/&&/;
           ($first, $third, $second) = split(/&&/,$line,3);
           chomp($third);
           if("$second" ne ""){
             open(TEMP, ">>temp");
               print TEMP "$third\n";
               print TEMP "http://$remote/$file\n";
             close(TEMP);
           }
         }  
       }elsif("$backend" eq "backend.bln"){
         if($line =~ /<\/strong><\/font><font face=\"Arial, Helvetica\" size=\"1\">/){
           $line =~ s/<\/strong><\/font><font face=\"Arial, Helvetica\" size=\"1/&&/;
           $line =~ s/<A HREF=\"//g;
           $line =~ s/\">/\n/g;
           $line =~ s/<\/A><BR>/\n&&\n/g;
           $line =~ s/<\/font><\/p>//;
           open(TEMP, ">>temp");
             print  TEMP $line;
           close(TEMP);
         }
       }elsif("$backend" eq "backend.ve"){
         if($line =~ /$pattern/){
           $line =~ s/$pattern//;
           $line =~ s/\"> <a href=\"/&&/;
           $line =~ s/\" target=\"new\">/&&/;
           $line =~ s/<\/a>/&&/;
           ($first, $second, $third, $fourth) = split(/&&/,$line,4);
           chomp($second);
           chomp($third);
           open(TEMP, ">>temp");
             print  TEMP "&&\n";
             print  TEMP "$third\n";
             print  TEMP "http://$remote/$second\n";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.cm"){
         if($line =~ /^$pattern/){
           $line =~ s/$pattern/xx&&/;
           $line =~ s/<\/b>/&&/;
           ($first, $third, $second) = split(/&&/,$line);
           chomp($third);
           open(TEMP, ">>temp");
             print  TEMP "$third\n";
             print  TEMP "http://$remote/$file\n";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.po"){
         if($line =~ /<link>/){
           $line =~ s/    <link>//gi; $line =~ s/<\/link>//gi;
           $second = $line;
         }
         if($line =~ /<title>/){
           $line =~ s/    <title>//gi; $line =~ s/<\/title>//gi;
           $first = $line;
           chomp $first; chomp $second;
           open(TEMP, ">>temp");
             print  TEMP "&&\n";
             print  TEMP "$first\n";
             print  TEMP "$second\n";
           close(TEMP);
         }
       }elsif("$backend" eq "backend.tho"){
          $line =~ s/<title>//gi; $line =~ s/<\/title>//gi;
	  $line =~ s/<link>//gi; $line =~ s/<\/link>//gi;
	  chomp $line;
          open(TEMP, ">>temp");
            print  TEMP "$line\n";
          close(TEMP);
       }elsif("$backend" eq "backend.uf"){
         if ($line =~ /<IMG ALT=\"Latest Strip\".*?/){
           chomp $line;
           open(TEMP, ">>temp");
             print  TEMP "$line";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.apod"){
         if($line =~ /<IMG SRC=\"image/){
           $line=~ s/<IMG SRC=\"//;
           $line=~ s/\"><\/a>//;
           chomp $line;
           $line= "<IMG ALT=\"Latest Image\"  BORDER=0 SRC=\"http:\/\/$remote\/apod\/$line\"></A>";
           chomp $line;
           open(TEMP, ">>temp");
             print  TEMP "$line";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.dilbert"){
          if($line =~ /<IMG SRC=\"\/comics\/dilbert\/archive\/images\//){
            $line =~ s/\"//gi;
            $line =~ s/<IMG SRC=/&&/;
            $line =~ s/.gif/.gif&&/gi;
            ($first, $second, $third) = split(/&&/,$line);
            chomp($third);
            open(TEMP, ">>temp");
              print  TEMP "<IMG ALT=\"Latest Strip\" BORDER=0 SRC=\"http:\/\/$remote$third\"></A>";
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.floach"){
           #$line =~ s/<description><\/description>//gi;
           #$line =~ s/<title>//gi; 
           #$line =~ s/<\/title>//gi; 
           #$line =~ s/<link>//gi; 
           #$line =~ s/<\/link>//gi; 
           if($line =~ /<font color=A9BC9E size=3><b>.*?<\/b><\/font><br>/){
              $line =~ s/<\/b><\/font><br>/<\/b><\/font><br>\n/gi;
           open(TEMP, ">>temp");
             print TEMP $line;
           close(TEMP);
           }
         }elsif("$backend" eq "backend.ay2k"){
           if($line =~ /<\/font><font face=\"Arial,Helvetica,Geneva,Swiss,SunSans-Regular\" size=\"2\"><img src=\"y2Kimages\//){
                
             $line=~ s/			<\/font><font face=\"Arial,Helvetica,Geneva,Swiss,SunSans-Regular\" size=\"2\"><img src=\"y2Kimages\///;
             $line=~ s/\" border=\"0\"/&&/;
             ($first,$second) = split(/&&/,$line);
             chomp $first;
             $first = "<IMG ALT=\"Latest After Y2K Image\"  BORDER=0 SRC=\"http://www.geekculture.com/geekycomics/Aftery2k/y2Kimages/$first\"></A>";
             chomp $first;
             open(TEMP, ">>temp");
               print  TEMP "$first";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.demonews"){
           if($line =~ /<font class='News_Headline'><font color='#9999CC'><b>.*?<\/b><\/font><br>/){
             $line =~ s/<font class='News_Headline'><font color='#9999CC'><b>/&&&/;
             $line =~ s/<\/b><\/font><br>/&&&/;
             ($first,$second,$third) = split(/&&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote/\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.lsLSnet"){
           if($line =~ /<td align=left valign=middle><font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/){
             $line =~ s/<td align=left valign=middle><font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/xx&&&/;
             $line =~ s/<\/b><\/font><\/td>/&&&/;
             ($first,$second,$third) = split(/&&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote/\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.lsLSnetss"){
           if($line =~ /		<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/){
             $line =~ s/		<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/xx&&&/;
             $line =~ s/<\/b><\/font>/&&&/;
             ($first,$second,$third) = split(/&&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote/sshots.php3\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.lsLSnett"){
           if($line =~ /		<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/){
             if($line =~ /        				<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>Showing Themes 0-5<\/b><\/font>/){
             }else{    
               $line =~ s/		<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/xx&&&/;
               $line =~ s/<\/b><\/font>/&&&/;
               ($first,$second,$third) = split(/&&&/,$line);
               chomp($second);
               open(TEMP, ">>temp");
         	 print  TEMP "&&\n";
         	 print  TEMP "$second\n";
         	 print  TEMP "http://$remote/themes.php3\n";
               close(TEMP);
              }
           }
         }elsif("$backend" eq "backend.pvponline"){
           if ($line =~ /<IMG src=\"archive\/2000\//){
               $line =~ s/				<IMG src=\"archive\/2000\///;
               $line =~ s/\"><br>//;	
             chomp $line;
             open(TEMP, ">>temp");
               print  TEMP "<IMG ALT=\"Latest Strip\" width=576 BORDER=0 SRC=\"http:\/\/$remote\/archive\/2000\/$line\"></A>";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.scifiwire"){
           if($line =~ /<!-- HEADLINE:/){
             $line =~ s/<!-- HEADLINE://;
             $line =~ s/ -->//;
             chomp($line);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$line\n";
               print  TEMP "http://$remote/scifiwire/index.html\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.techreport"){
           if($line =~ /<b><font face=\"Arial,Helvetica\" size=\"5\" color=\"#FFFFFF\"><a NAME=\"article_.*?\" href=\"\/onearticle.x\/.*?\" class=headline>.*?<\/a><\/font><\/b><br>/){
             $line =~ s/<b><font face=\"Arial,Helvetica\" size=\"5\" color=\"#FFFFFF\"><a NAME=\"article_.*?\" href=\"\/onearticle.x\/.*?\" class=headline>/xx&&/;
             $line =~ s/<\/a><\/font><\/b><br>/&&xx/;
             ($first,$second,$third) = split(/&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.ultimateos"){
           if($line =~ /TARGET=\"_blank\">/){
             $line =~ s/TARGET=\"_blank\">/&&/;
             $line =~ s/<\/A><BR>/&&xx/;
             ($first,$second,$third) = split(/&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.tughouse"){
          if($line =~ /<img src=\"images\/.*?.jpg\"/){
            $line =~ s/<img src=\"images/&&/gi;
            $line =~ s/\" width=/&&/;
            ($first, $second, $third) = split(/&&/,$line);
            chomp($third);
            open(TEMP, ">>temp");
              print  TEMP "<IMG ALT=\"Latest Strip\" BORDER=0 SRC=\"http:\/\/$remote\/images$second\"></A>";
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.graphite"){
           if($line =~ /<font color=\"#FFCC00\" size=\"\+1\">/){
             $line =~ s/<font color=\"#FFCC00\" size=\"\+1\">/xx&&/;
             $line =~ s/<\/font>/&&xx/;
             ($first,$second,$third) = split(/&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.shellscape"){
           if($line =~ /<font face=\"arial,helvetica\" size=4 color=\"#008F44\"><b>/){
             $line =~ s/<font face=\"arial,helvetica\" size=4 color=\"#008F44\"><b>/xx&&/;
             $line =~ s/<\/b><\/font><br>/&&xx/;
             ($first,$second,$third) = split(/&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.darkstep"){
           if($line =~ /<h3>.*?<br>/){
             $line =~ s/<h3>/xx&&/;
             $line =~ s/<br>/&&xx/;
             ($first,$second,$third) = split(/&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.fileclicks"){
           if($line =~ /software.phtml\?id=/){
             $line =~ s/software.phtml\?id=/&&/;
             $line =~ s/<\/a><\/b><font size=\"-2\" color=\"#999999\"><br>/&&xx/;
             $line =~ s/\">/&&/gi;
             ($first,$second,$third,$fourth,$fifth) = split(/&&/,$line);
             chomp($fourth);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$fourth\n";
               print  TEMP "http://$remote/software.phtml?id=$third\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.pennyarcade"){
          if($line =~ /<img src=\"images\/2000\/.*?.jpg\">/){
            $line =~ s/<img src=\"images\/2000\///gi;
            $line =~ s/\">//;
            chomp($line);
            open(TEMP, ">>temp");
              print  TEMP "<IMG ALT=\"Latest Strip\" BORDER=0 SRC=\"http:\/\/$remote\/images\/2000\/$line\"></A>";
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.geeknik"){
           if($line =~ /<td align=\"left\" valign=\"top\" width=\"62%\"><a name=\".*?\"><\/a><font color=\"#333366\" face=\"Verdana, Arial, Helvetica, Sans-serif\"><b>/){
             $line =~ s/.*<td align=\"left\" valign=\"top\" width=\"62%\"><a name=\".*?\"><\/a><font color=\"#333366\" face=\"Verdana, Arial, Helvetica, Sans-serif\"><b>//gis;
             $line =~ s/<\/b>.*/\n/gis; 
             chomp($line);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$line\n";
               print  TEMP "http://$remote\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.newscom"){
           if($line =~ /\?tag=st.cn.1.lthdne\">/){
             $line =~ s/\?tag=st.cn.1.lthdne\">/&&/gi;
             $line =~ s/<br><font face=\"Arial, Helvetica\" size=\"-1\"><a href=\"\/news\///gi;
             $line =~ s/<\/a><P><a href="\/news\//&&/gi;
             $line =~ s/<\/a><P><\/font>//gi;
             ($first,$second,$third,$fourth,$fifth,$sixth,$seventh,$eighth,$ninth,$tenth) = split(/&&/,$line);
             #chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote/news/$first\n";
               print  TEMP "&&\n";
               print  TEMP "$fourth\n";
               print  TEMP "http://$remote/news/$third\n";
               print  TEMP "&&\n";
               print  TEMP "$sixth\n";
               print  TEMP "http://$remote/news/$fifth\n";
               print  TEMP "&&\n";
               print  TEMP "$eighth\n";
               print  TEMP "http://$remote/news/$seventh\n";
               print  TEMP "&&\n";
               print  TEMP "$tenth\n";
               print  TEMP "http://$remote/news/$ninth\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.wired"){
           if($line =~ /<a href=\"\/news_drop\/palmpilot\/story\/.*?.html\">/){
             $line =~ s/<a href=\"\/news_drop\/palmpilot\/story\/.*?.html\">//;
             $line =~ s/<\/a><br>//;
             chomp($line);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$line\n";
               print  TEMP "http://$remote\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.pmsnippets"){
           if($line =~ /<li><A HREF="\/index.pl\?node_id=.*?&lastnode_id=.*?\">/){
             $line =~ s/<UL><li><A HREF=\"\///;
             $line =~ s/<\/a><\/B><li><A HREF=\"\//\n/gi;
             $line =~ s/<\/a><\/B><\/UL><BR><BR>//;
             $line =~ s/\">/&&/gi;
             open(TEMP, ">>temp");
               print  TEMP $line;
             close(TEMP);
             
           }  
         }elsif("$backend" eq "backend.pmcooluses"){
           if($line =~ /<TR width=100% BGCOLOR=cccccc><TD><a href=\"\/index.pl\?node=.*?lastnode_id.*?lastnode_id=.*?\"><A HREF=\"\/index.pl\?node_id=.*?lastnode_id=.*?\">.*?<\/a><\/a>/){
             $line =~ s/<TR width=100% BGCOLOR=cccccc><TD><a href=\"\/index.pl\?node=.*?lastnode_id.*?lastnode_id=.*?\"><A HREF=\"\///gi;
             $line =~ s/<\/a><\/a>//gi;
             $line =~ s/<TABLE.*?cellpadding=2>//;
             $line =~ s/\">/&&/gi;
             open(TEMP, ">>temp");
               print  TEMP $line;
             close(TEMP);
             
           }
         }elsif("$backend" eq "backend.pmpoetry" or "$backend" eq "backend.pmobfus" or "$backend" eq "backend.pmmed" or "$backend" eq "backend.pmcraft"){
           if($line =~ /<A HREF=\"\/index.pl\?title=/){
             $line =~ s/<A HREF=\"\/index.pl\?title=/&&\n/gi;
             $line =~ s/&lastnode_id=.*?<\/a>//gi;
             $line =~ s/%20/ /gi;
             $line =~ s/%21//gi;$line =~ s/%22//gi;$line =~ s/%23//gi;$line =~ s/%24//gi;
             $line =~ s/%25//gi;$line =~ s/%26//gi;$line =~ s/%27//gi;$line =~ s/%28//gi;
             $line =~ s/&parent=/\nhttp:\/\/$remote\/index.pl\?node_id=/gi;
             open(TEMP, ">>temp");
               print  TEMP $line;
             close(TEMP);
             
           }
         }elsif("$backend" eq "backend.mjideas" or "$backend" eq "backend.mjsnip"){
           if($line =~ /.*?$pattern1.php3\?item=.*?&main=$pattern2>.*?/){
             $line =~ s/.*?<font face=verdana size=1/<font face=verdana size=1/;
             $line =~ s/.*?item=//gi;
             $line =~ s/&.*?1>/&&/gi;
             $line =~ s/<\/font><\/a><\/font><br>//gi;
             open(TEMP, ">>temp");
               print  TEMP $line;
             close(TEMP);
             
           }
         }elsif("$backend" eq "backend.mjnews"){
           if($line =~ /<tr><td valign=top align=left   width=60% bgcolor=#081951>&nbsp;<font face=tahoma,verdana,arial size=2 color=FFFFFF><b>.*?<\/b>/){
             $line =~ s/size=2 color=FFFFFF><b>/\n/gi;
             $line =~ s/<\/b>.*//gi;
             $line =~ s/<table.*?\n//s;
             chop($line);
             open(TEMP, ">>temp");
               if ( length($line) > 1 ){
                 print  TEMP "$line";
               }
             close(TEMP);
           }
         }elsif("$backend" eq "backend.tekreview"){
           if($line =~ /<font face=verdana size=3><font color=\"blue\"><b>/){
             $line =~ s/.*<b>//gi;
             $line =~ s/<\/b>.*//gi;
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP $line;
               print  TEMP "http://$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.ebg"){
           if($line =~ /<font face=\"arial,helvetica\" size=3 color=00cc66><b>/){
             $line =~ s/.*<b>//gi;
             $line =~ s/<\/b>.*//gi;
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP $line;
               print  TEMP "http://$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.aicn"){
           if($line =~ /<TD CLASS=\"hlist\"><B><FONT SIZE=2><A HREF=\"display.cgi\?id=/){
             $line =~ s/<TD CLASS=\"hlist\"><B><FONT SIZE=2><A HREF=\"display.cgi\?id=//gi;
             $line =~ s/\"><H2>/&&/gi;
             $line =~ s/<\/H2>.*//gi;
             
             ($first,$second) = split(/&&/,$line);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP $second;
               print  TEMP "http://$remote/display.cgi?id=$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.epocnews"){
           if($line =~ /<P><A HREF=\"http:\/\/www.epoczone.com\/details.php3\?id=.*?">.*?<\/A>.*?<BR>/){
             $line =~ s/<P><A HREF=\"http:\/\/www.epoczone.com\/details.php3\?id=//gi;
             $line =~ s/<\/A>//gi;
             $line =~ s/<BR>//gi;
             $line =~ s/\">/&&/gi;
             ($first,$second) = split(/&&/,$line);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP $second;
               print  TEMP "http://www.epoczone.com/details.php3?id=$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.sinfest"|"$backend" eq "backend.roadwaffles"|"$backend" eq "backend.joeaverage"|"$backend" eq "backend.avalonhigh"|"$backend" eq "backend.hounds"|"$backend" eq "backend.bruno"|"$backend" eq "backend.newshounds"|"$backend" eq "backend.gpf"|"$backend" eq "backend.elflife"){
          if($line =~ /<IMG ALT=\"Today's Comic\" BORDER=0 SRC=\"\/comics\//){
            $line =~ s/.*\"#000000\">//;
            $line =~ s/<\/font>//;
            $line =~ s/SRC=\"\//SRC=\"http:\/\/$remote\//;
            chop($line);
            open(TEMP, ">>temp");
              print  TEMP $line;
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.goats"){
          if($line =~ /<IMG SRC=\"\/comix\//){
            $line =~ s/.*<IMG/<IMG ALT="Today's Comic"/;
            $line =~ s/SRC=\"\//SRC=\"http:\/\/$remote\//;
            chop($line);
            open(TEMP, ">>temp");
              print  TEMP $line;
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.sitspin"){
          if($line =~ /<img src=\"comics\//){
            $line =~ s/.*<img/<IMG ALT="Today's Comic"/;
            $line =~ s/src=\"/SRC=\"http:\/\/$remote\/sitandspin\//;
            chop($line);
            open(TEMP, ">>temp");
              print  TEMP $line;
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.funnyfarm"){
          if($line =~ /<IMG ALT=\"Today's Comics\" BORDER=0 SRC=\"\/comics\//){
            $line =~ s/<p align=\"center\">//;
            $line =~ s/<\/p>//;
            $line =~ s/SRC=\"\//SRC=\"http:\/\/$remote\//;
            chop($line);
            open(TEMP, ">>temp");
              print  TEMP $line;
            close(TEMP);
           } 
         }elsif("$backend" eq "backend.cmptr"){
           if($line =~ /<li>/){
             $line =~ s/<\/li>/\n/gi;
             $line =~ s/<li><a href=\"//gi;
             $line =~ s/<\/a>//gi;
             $line =~ s/\">/&&/gi;
             open(TEMP, ">>temp");
              print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.palmstation"){
           if($line =~ /<\/b><\/font><\/td>/){
             $line =~ s/<\/b><\/font><\/td>//gi;
             $line =~ s/          //gis;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.pdabuzz"){
           if($line =~ /<a href=\"#newsitem/){
             $line =~ s/.*<a href=\"//gi;
             $line =~ s/<\/A>.*//gi;
             $line =~ s/\" class=\"c\">/&&/gi;
             ($first,$second) = split(/&&/,$line);
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $second;
              print TEMP "http:\/\/$remote/$file$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.palminfocenter"){
           if($line =~ /<td bgcolor=\"#a0a0a0\" class=\"Sub\">/){
             $line =~ s/.*Sub\">//gi;
             $line =~ s/<\/td>//gi;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote/$file\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.appwatch"){
             $line =~ s/<.*?>//gis;
             $line =~ s/        //gis;
             open(TEMP, ">>temp");
              print TEMP $line;
             close(TEMP);
           
         }elsif("$backend" eq "backend.daemonnews"){
           if($line =~ /<STRONG><FONT COLOR=\"#FFFFFF\" CLASS=\"normal\">/){
             $line =~ s/<.*?>//gis;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote/$file\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.thenewos"){
           if($line =~ /<font size=\"3\" face=\"Arial\" color=\"#E0E2F7\">/){
             $line =~ s/.*<font size=\"3\" face=\"Arial\" color=\"#E0E2F7\">//gi;
             $line =~ s/<\/font>.*//gi;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.neoflux"){
           if($line =~ /\"><\/a><span class=\"headlines\"><font size=\"2\">/){
             $line =~ s/.*\"><\/a><span class=\"headlines\"><font size=\"2\">//gi;
             $line =~ s/<\/font>.*//gi;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }
         
  }
  
  if("$backend" eq "backend.pmsnippets" or "$backend" eq "backend.pmcooluses"){
    open(TEMP, "<temp");
      while(<TEMP>){
        ($first,$second) = split(/&&/,$_);
        open(TEMP2, ">>temp2");
          print TEMP2 "&&\n";
          print TEMP2 "$second";
          print TEMP2 "http://$remote\/$first\n";
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }
  if( "$backend" eq "backend.mjnews"){
    open(TEMP, "<temp");
      while(<TEMP>){
        $line = $_;
        $line =~ s/.*&nbsp.*//s;
        chomp $line;
        chop $line;
        open(TEMP2, ">>temp2");
          if ( length($line) > 1 ){
            print TEMP2 "&&\n";
            print TEMP2 "$line\n";
            print TEMP2 "http://$remote\n";
          }
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }     
  if( "$backend" eq "backend.mjideas" or "$backend" eq "backend.mjsnip"){
    open(TEMP, "<temp");
      while(<TEMP>){
        ($first,$second) = split(/&&/,$_);
        open(TEMP2, ">>temp2");
          print TEMP2 "&&\n";
          print TEMP2 "$second";
          print TEMP2 "http://$remote\/$pattern1.php3\?item=$first&main=$pattern2\n";
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }     
  if( "$backend" eq "backend.floach"){
    open(TEMP, "<temp");
      while(<TEMP>){
        $line = $_;
        if($line =~ /.*?<font color=A9BC9E size=3><b>.*?<\/b><\/font><br>/){
           $line =~ s/.*?<font color=A9BC9E size=3><b>/&&\n/gi;
           $line =~ s/<\/b><\/font><br>/\nhttp:\/\/$remote/gi;     
           open(TEMP2, ">>temp2");
             print TEMP2 "$line";
           close(TEMP2);
        }
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }
  if("$backend" eq "backend.cmptr"){
    open(TEMP, "<temp");
      while(<TEMP>){
        ($first,$second) = split(/&&/,$_);
        open(TEMP2, ">>temp2");
          print TEMP2 "&&\n";
          print TEMP2 "$second";
          print TEMP2 "$first\n";
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }     
  close(BACKEND);
  unlink($backend);
  rename("temp",$backend);
  unlink("temp");
  return;
}

sub addfolder{
  unlink <*.h>;
  if($folderval == 1){
    checkdir();
    chdir ("$startdir$dir");
    unlink <*.*>;
    chdir ("$startdir");
    $linecount = 0;
    $linenumber = 0;
    my $topiccount = 0;
    open(BACKEND,"<$backend") || "Can't open $backend\n"; #return;
      while(<BACKEND>) {  
        ++$linecount;
        if($backend eq "backend.uf"|$backend eq "backend.apod"|$backend eq "backend.dilbert"|$backend eq "backend.ay2k"|$backend eq "backend.pvponline"|$backend eq "backend.tughouse"|$backend eq "backend.pennyarcade"|$backend eq "backend.sinfest"|$backend eq "backend.roadwaffles"|$backend eq "backend.joeaverage"|$backend eq "backend.avalonhigh"|$backend eq "backend.hounds"|"$backend" eq "backend.goats"|"$backend" eq "backend.sitspin"|"$backend" eq "backend.funnyfarm"|"$backend" eq "backend.bruno"|"$backend" eq "backend.newshounds"|"$backend" eq "backend.gpf"|"$backend" eq "backend.elflife"){
          $_=~ s/.*http/http/;
          $_=~ s/gif.*/gif/;
          $_=~ s/jpg.*/jpg/;
          $topic = $header1;
          Format_SC($topic,$dir,$_)
        }else{
          if($linecount>$fromtop){
	    ++$linenumber;
	  }
	  if($linenumber == $topicline){
	    ++$topiccount;
	    if(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu")){
	    }
	    else{
	      chop;
	    }
	    $topic="$_";$topic=~ s/\"|:|>|<|\/|\|*|\?|\||\=|\)|\(//gi;$topic=~ s/\+/"plus"/gi;#$topic=~ s/\s//;
	    $topic =~ s/\]|\[//gi;
	    $topic=~ s/(.*?\/.*?)//gi;
	    if("$backend" eq "backend.ag"){
	    }
	    else{
	      $topic=~ s/$topic/$topic /;
	    }
	  }  
	  elsif($linenumber == $linkline && $topic ne "" && $topiccount <= $limit){
	    Format_SC($topic,$dir,$_)	    
	  }  
	  if($linenumber == $blocklength) {
	    $linenumber=0;
	  }
        }	        
      }
    close(BACKEND);
  }
  return;
}
sub Format_SC {
  open(NUMFILE, ">$dir/$topic.url");
    print  NUMFILE <<SHORT;
[DEFAULT]
BASEURL=$_
[InternetShortcut]
URL=$_

SHORT
  close(NUMFILE);
  
}

#############################################################################
# Checkdir

sub checkdir {

 if (-e $dir) {
  return;
 }
 mkdir("$dir",0777) || die "Cannot mkdir $dir: $!";
 return;
}

#############################################################################

sub createpage {
    open(FILE,">$pagename.htm");
    close(FILE);
    return;
}

sub header{
  open(FILE,">>$pagename.htm");
  print FILE <<HEADER;
<html>

<head>
<title>$pagename</title>
<base TARGET="_self">
</head>
<body BGCOLOR="#$back" TEXT="#$bodytext" LINK="#$bodylink" LEFTMARGIN="0" VLINK="#$bodyvlink" ALINK="#$bodyalink">

<table BORDER="0" WIDTH="100%">
  <tr>
    <td WIDTH="8%"></td>
    <td WIDTH="83%">
HEADER
  close(FILE);
  return;
}



sub footer{
  open(FILE,">>$pagename.htm");
  print FILE <<FOOTER;

    </td>
    <td WIDTH="9%"></td>
  </tr>
</table>

<p>&nbsp;</p>
</body>
</html>


FOOTER
close(FILE);
return;
}



sub tabletitle{
  open(FILE,">>$pagename.htm");
  print FILE <<TITLE;
   <div align="center">
            <center>
               <table BORDER="1" WIDTH="536"
                      BORDERCOLOR="#$border" CELLSPACING="0" BORDERCOLORLIGHT="#$border" BORDERCOLORDARK="#$border"
                      BGCOLOR="#$entryback">
                      <tr>
                         <td WIDTH="100%">
                            
                              <big>
                                 <strong><A href=http:\/\/$header2>$header1</a></strong>
                             </big>
                         </td>
                      </tr>
               </table>
            </center>
        </div>

TITLE
  close(FILE);
return;
}

sub tablerow{
  open(FILE,">>$pagename.htm");
  print FILE<<TROWT;
<div align="center">
             <center>
                <table BORDER="1" WIDTH="536"
                       BGCOLOR="#$bodyback" BORDERCOLOR="#$border" CELLSPACING="0" BORDERCOLORLIGHT="#$border" BORDERCOLORDARK="#$border">
                       <tr>
                          <td>
                            
TROWT

  $linecount = 0;
  $num = 0;
  $linenumber = 0;
  
  my $topiccount = 0;
  
  open(BACKEND,"<$backend") || print "Can't open $backend\n"; 
       while(<BACKEND>) {  
             ++$linecount;
             ++$num;
             if($backend eq "backend.uf"){
                print FILE $_;
             }elsif($backend eq "backend.apod"){
                print FILE $_;
             }elsif($backend eq "backend.dilbert"){
                print FILE $_;
             }elsif($backend eq "backend.ay2k"){
                print FILE $_;
             }elsif($backend eq "backend.pvponline"){
                print FILE $_;
             }elsif($backend eq "backend.tughouse"){
                print FILE $_;
             }elsif($backend eq "backend.pennyarcade"){
                print FILE $_;
             }elsif($backend eq "backend.sinfest"|$backend eq "backend.roadwaffles"|$backend eq "backend.joeaverage"|$backend eq "backend.avalonhigh"|$backend eq "backend.hounds"|"$backend" eq "backend.goats"|"$backend" eq "backend.sitspin"|"$backend" eq "backend.funnyfarm"|"$backend" eq "backend.bruno"|"$backend" eq "backend.newshounds"|"$backend" eq "backend.gpf"|"$backend" eq "backend.elflife"){
                print FILE $_;
             }
             else{
	             if($linecount>$fromtop){
		              ++$linenumber;
	             }
	             if($linenumber == $topicline){
	     	          ++$topiccount;
	     	          if(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu")){
                  }
		              else{
		                chop;
		              }
		              $topic="$_";
		              #$topic=~ s/:|>|<|\/|\|*|\?|\||\=|\(|\)//gi;
		              $topic=~ s/\/||\(|\)//gi;
		              $topic=~ s/\+/\+ /gi;
		              $topic=~ s/\*/\* /gi;
		              $topic =~ s/\]|\[//gi;
		              #$topic=~ s/\s//;
                          if("$backend" eq "backend.ag"){
		              }
	                else{
	                  $topic=~ s/$topic/$topic /;
	                }
	            }
	     
	            elsif($linenumber == $linkline && $topic ne "" && $topiccount <= $limit){
		            chop;
		            print  FILE "<li><A href='$_'>$topic</a></li>\n";
              }  
	            if($linenumber == $blocklength){
	               $linenumber=0;
	            }
	          }  
       }
  close(BACKEND);

print FILE <<TROWB;  
                        </td>
                      </tr>
               </table>
             </center>
       </div><p>&nbsp;

TROWB
close(FILE);
return;
}

# 2.13.0 Change:  No longer are the folder vales auto-refreshing .htm files they are of the new .url
#                 format. This works better wiht IE 5 and Win2K. Thanks for the suggestion and code
#                 samples from :Aemergin.
#        Change:  Big overhaul to the images links in the folders made things a little bit easier.
# 2.12.0 Added:   Palm Station.
#        Added:   PDA Buzz
#        Added:   Palm InfoCenter
#        Added:   AppWatch
#        Added:   Daemon News
#        Added:   Ice Walkers
#        Added:   The New OS
#        Added:   Wonko Slice
#        Added:   neoFlus
#        Added:   Digital Theatre
# 2.11.0 Added:   SinFest Comic.
#        Added:   RoadWaffles Comic.
#	 Added:   Joe Average Comic
#	 Added:   Avalon High Comic
#	 Added:   Hounds Home Comic.
#	 Added:   Goats Comic
#	 Added:   Sit and Spin Comic.
#	 Added:   Funny Farm Comic.
#	 Added:   Bruno the Bandit Comic.
#	 Added:   News Hounds Comic.
#	 Added:   GPF Comic
#	 Added:   Elf life Comic.
#	 Added:   CMPTR
#	 Added:   Linux 2000
# 2.10.1 Fixed:   Shell City
# 2.10.0 Added:   Tekreview
#        Added:   Everything But Gaming
#        Added:   Aint it cool news.
#        Added:   EPCO News.
# 2.9.3  Fixed:   All Mind Junction Folders.
# 2.9.2  Fixed:   Mind Junction News.
#        Fixed:   GeekNik
#        News:    Segfault seems to be down. Thats all i know.
# 2.9.1  Fixed:   Floach.
#        Fixed:   SciFi Wire.
#        News:    Linux Game Tome back up. Thats all the Happy Penguin News.
#        News:    DemoNews looks broken (server side) at the moment.
#        News:    Linux Quake backup.
# 2.9.0  Added:   MindJunction News, MindJunction Snips, MindJunction Ideas
# 2.8.4  Fixed:   After Y2k
# 2.8.3  Fixed:   SciFi Wire
#        News:    DarkStep Down for a while. (waiting for a new server)
#        Fixed:   Perl Monks Craft
# 2.8.2  Fixed:   Floach. Now parsing in lsDrinks doesn't use the Desktopian backend anylonger.
#        News:    All the HappyPenguin Sites are currently down due to server outages and changes.
#        News:    I have no idea whats happened to LinuxQuke it maybe dead i'll give it more time.
# 2.8.1  Fixed:   Userfriendly
# 2.8.0  Added:   Perl Monks Cool Uses of Perl
#        Added:   Perl Monks Poetry
#        Added:   Perl Monks Obfuscation
#        Added:   Perl Monks Craft
#        Added:   Perl Monks Meditations
# 2.7.0  Added:   Perl Monks Code Snippets
# 2.6.0  Added:   Cnet News
#                 Wired News
# 2.5.0  Added:   Fileclicks.
#        Added:   Penny Arcade.
#        Added:   Geeknik.net.
# 2.4.1  Fixed:   Geeknews.org.
# 2.4.0  Added:   SciFi News Wire
#        Added:   The Tech Report
#        Added:   The Ultimate OS.
#        Added:   Tug House Comic.
#        Added:   ShellScape
#        Added:   Graphite.
#        Added:   DarkStep.
# 2.3.0  Added:   PVPonline comic
# 2.2.0  Added:   A whole new way to organize the HTM page. you can use the classic view
#                 to add sites in the order they were introduced or you can use the new
#                 style to display sites in a certain order. This works with the folders
#                 as well but doesn't really change anything other than the order sites are
#                 checked.
# 2.1.9  Changed: Liststep.Net,ScreenShots,Themes to parse in this file.(no longer using pimpin.net backends)
#        Fixed:   Problem with Feedback not working when folders were turned off
#        Changed: Reformated alot of the Code to make it more readable
#        Fixed:   Technotronic.
#        Removed: Litestep.com, Litestep.org,LancedNet. This dead code has been in 2 long.
#        Fixed:   Some of the Funky spelling problems like jumbling everything together.
# 2.1.8  Added:   Demonews.com
#        Fixed:   BeNews
# 2.1.7  Fixed:   Parsing problem with ) or (
#        Fixed:   LinuxToday - Page Moved
#        Fixed:   BetaNews   - Formatting Changed
#        Fixed:   File Forum - Formatting Changed
#        Fixed:   Shell City - Formatting Changed
# 2.1.6  Added:   Geeknews.org, Fixed Segfault
# 2.1.5  Added:   After Y2k Cartoon
#        Added:   LiteStep.Net,Litestep.net Screen Shots (using backends from MrJukes and geekMASTR)
#        Added:   the ability for the script to create a directory if one doesn't exist so in including
#                 as the sub dirs is no longer needed.
# 2.1.4  Changed: floach to read from Desktopian * Thanks Tin_Omen *, Changed Tin_Toys to Desktopian
#        Changed: the htm page to added a differnt header and url, Added Shell City
# 2.1.3  Added:   Astronomy Pic of the Day, Dilbert.FileForum Changed the Way Floach Works.
# 2.1.2  Added:   User Friendly Strip