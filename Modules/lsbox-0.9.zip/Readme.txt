Lsbox pre-release version 0.9
-{handle with care}-

*Installation & use:

Load LsBox.dll as a Loadmodule
  (LoadModule C:\LITESTEP\LsBox.dll)
and then Call !LsBoxCreate
  (!LsBoxCreate C:\litestep\blueheart.rc)
to open a LsBox.  

To destroy a LsBox from call !LsBoxDestroy and the 
name of the LsBox to destroy.
  
For more details read the included blueheart.rc file.

*NOTE:
 The known Issuses are:
   *Bug(s) in the Cfg pointer list destroy/create mechanism
   *Shortcuts not 100% compatible to Ls-standard
   *several dissablitys:
    -You cannot call !LsBoxCreate from a LsBox
    -You can only destroy the current LsBox from a LsBox
     (Self-destructing only)


If you have Question or a Suggestion mail me @:
     blkhawk@blkhawk.de
 -Have Phun!