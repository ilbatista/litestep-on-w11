// DO NOT DELETE NEXT LINE
// LMA1.0 
/*
LiteStep Module AppWizard
*/

#ifndef __LogConsole_H
#define __LogConsole_H

#include <windows.h>
#include "guiwindow.h"
#include "..\current\lsapi\lsapi.h"

#include <deque>
using namespace std;

#define MAX_LINE_LENGTH 4096

class LogMsg
{
public:
	char* date;
	char* level;
	char* module;
	char* text;
};

class LogConsole : public GuiWindow
{
private:
	deque<LogMsg> MessageList;

	int nLogLevel;
	HWND hListView;
	bool bListViewStarted;

public:
	LogConsole(HWND parentWnd, int& code);
	~LogConsole();

	void EnterMessage(LogMsg* msg, int nLevel, LPCSTR pszModule, LPCSTR pszMessage);
	void RemoveMessages();
	BOOL Log(int nLevel, LPCSTR pszModule, LPCSTR pszMessage);

	void Bangclear(HWND, LPCSTR);
	void Bangsave(HWND, LPCSTR);
	HWND GetList();

private:
	void ReadConsoleSettings();
	void ReadSizeAndPos();
	void ReadGUIProps();

	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onNotify(Message& message);
	void onCreate(Message& message);
	void onPaint(Message& message);
	void onSysCommand(Message& message);
	void onLMRecycle(Message& message);
};

void BangclearFunction(HWND, LPCSTR);
void BangsaveFunction(HWND, LPCSTR);
void BangToggle(HWND, LPCSTR);
void BangHook(HWND, LPCSTR);
void BangSetOnTop(HWND, LPCSTR);
void BangToggleOnTop(HWND, LPCSTR);
void BangShow(HWND, LPCSTR);
void BangHide(HWND, LPCSTR);
void BangMove(HWND, LPCSTR);
void BangSize(HWND, LPCSTR);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
