=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    Crash 1.0 (simple crash module ;) )
    Copyright(c) Sergey Gagarin a.k.a. Seg@
    Kirov, Russia  2004
    README
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

=========================
The Table of Content
-------------------------
  I. REQUIREMENTS
 II. INSTALLATION
III. CONFIGURATION
 IV. SOURCES
  V. CONTACTS

=====================
I. REQUIREMENTS
---------------------
The module would work only on NT family.
If your OS is Windows 95, 98 or Me,
you can still load crash.dll, but !crash bang
would be disabled, so there is no reason to do so :)

=====================
II. INSTALLATION
---------------------

Simple use the following line in the theme.rc:
*NetLoadModule crash-1.0
Then you'll be able to use something like this:
*Hotkey WIN C !crash
or just type !crash in lsxcommand box.

=====================
III. CONFIGURATION
---------------------

There is no configuration. Just use !crash bang.

=====================
IV. SOURCES
---------------------

Yeah, I can share them with you. Just drop me a line :)
See the next section for detailed information.

=====================
V. CONTACTS
---------------------

If you want to beat my face or have any other reason
to contact me, I am available:
 - in ICQ network: 162261148
 - at the Chuvi's website: http://www.litestep.bip.ru/
                                     (only in Russian)
 - or via mail: inform-sega@freemail.ru


Ok, that's all what I needed to say.
Wish you luck with a playing this toy.
