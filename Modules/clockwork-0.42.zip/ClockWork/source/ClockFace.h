#ifndef __CLOCKFACE_H
#define __CLOCKFACE_H

#include <windows.h>
#include "TrigBuffer.h"

// for hands & drawing
class ClockHand
{
public:
	ClockHand(COLORREF ci, COLORREF co, int l, int w);
	int GetLength();
	int GetWeight();
	COLORREF GetColor();
	COLORREF GetInnerColor();

	static int GetCenterX();
	static int GetCenterY();
	static void SetCenter(int, int);
	static SinBuffer *sinus;
	static CosBuffer *cosinus;

	virtual void DrawHand(HDC hdc, HRGN hrgn, const int index) = 0;

private:
	static int nCenterX;
	static int nCenterY;

	COLORREF clrOut;
	COLORREF clrIn;
	int nWeight;
	int nLength;

};

class TriHand : public ClockHand
{
public:
	TriHand(COLORREF ci, COLORREF co, int l, int w);
	void DrawHand(HDC hdc, HRGN hrgn, const int index);
};

class BoxHand : public ClockHand
{
public:
	BoxHand(COLORREF ci, COLORREF co, int l, int w);
	void DrawHand(HDC hdc, HRGN hrgn, const int index);
};

class LineHand : public ClockHand
{
public:
	LineHand(COLORREF ci, COLORREF co, int l, int w);
	void DrawHand(HDC hdc, HRGN hrgn, const int index);
};

class ClockFace
{
public:
	ClockFace(LPCSTR prefix);
	~ClockFace();
	void DrawClock(HDC hdc, HRGN hrgn);
	void CalcCenter(int, int);
	void ReadClockSettings();
	ClockHand* LoadHand(LPCSTR type, COLORREF ci, COLORREF co, int l, int w);
	ClockHand* LoadHand(LPCSTR type, COLORREF c, int l, int w);
	int GetRefresh();

private:
	const char *Prefix;

	char order[3];

	BOOL bNoSeconds;

	int nResolution;
	int nRefresh;

	ClockHand *second;
	ClockHand *minute;
	ClockHand *hour;

	/*
	COLORREF clrSecond;
	COLORREF clrMinute;
	COLORREF clrHour;

	int nHourWeight;
	int nMinuteWeight;
	int nSecondWeight;

	int nHourLength;
	int nMinuteLength;
	int nSecondLength;
	*/

};

#endif