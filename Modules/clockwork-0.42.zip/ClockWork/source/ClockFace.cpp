/*

	ClockFace Class that handles all the clock functions

*/

#include <math.h>
#include "ClockFace.h"
#include "LSUtils.h"
#include "..\current\lsapi\lsapi.h"
#include "TrigBuffer.h"

//#define DEBUG
//#define SPAMDEBUG


/* ClockFace */

ClockFace::ClockFace(LPCSTR prefix) :
	bNoSeconds(false),
	Prefix(prefix),
	nResolution(60)
{
	order[0] = 'h';
	order[1] = 'm';
	order[2] = 's';
}

ClockFace::~ClockFace()
{
	delete minute;
	delete hour;
	if (!bNoSeconds)
		delete second;

	delete ClockHand::sinus;
	delete ClockHand::cosinus;
}

int ClockFace::GetRefresh()
{
	return nRefresh;
}

// drawing function, originally from aLsClock
void ClockFace::DrawClock(HDC hdc, HRGN hrgn)
{
	int index = 0;
	SYSTEMTIME time;
	GetLocalTime(&time);

	for (int i=0; i<3; i++)
	{
		switch(order[i])
		{
			#ifdef SPAMDEBUG
				LSLogPrintf(LOG_DEBUG, Prefix, "order: %s, t: %d", order[i], time.wSecond);
			#endif

			case 'h':
				//hours

				// calc hour&minute to base of the given buffer precision
				index = (double)(time.wHour % 12 + (double)time.wMinute/60) * nResolution / 12;
				#ifdef SPAMDEBUG
					LSLogPrintf(LOG_DEBUG, Prefix, "hi: %d", index);
				#endif
				hour->DrawHand(hdc, hrgn, index);

			break;

			case 'm':
				// minutes (update to use seconds)
				index = (double)(time.wMinute + (double)time.wSecond/60) * nResolution / 60;
				#ifdef SPAMDEBUG
					LSLogPrintf(LOG_DEBUG, Prefix, "mi: %d", index);
				#endif
				minute->DrawHand(hdc, hrgn, index);
			break;

			case 's':
				//seconds (update to use milliseconds)
				if (!bNoSeconds)
				{
					index = (double)(time.wSecond + (double)time.wMilliseconds/1000) * nResolution / 60;
					#ifdef SPAMDEBUG
						LSLogPrintf(LOG_DEBUG, Prefix, "si: %d", index);
					#endif
					second->DrawHand(hdc, hrgn, index);
				}
			break;
		}
	}
}

void ClockFace::CalcCenter(int width, int height)
{
	// calculate center
	ClockHand::SetCenter(width / 2, height / 2);
}

void ClockFace::ReadClockSettings()
{
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "Looking for prefix: %s", Prefix);
#endif

	char szTemp[MAX_LINE_LENGTH];
	COLORREF ci, co;
	int w, l;
	int nCenterX = ClockHand::GetCenterX();
	int nCenterY = ClockHand::GetCenterY();

	LSUtils::PrefixedGetRCString(Prefix, "HandType", szTemp, "line" , MAX_LINE_LENGTH);

	// seconds:
	bNoSeconds = LSUtils::PrefixedGetRCBool(Prefix, "NoSeconds", TRUE);
	if (!bNoSeconds)
	{
		co = LSUtils::PrefixedGetRCColor(Prefix, "SecondColor", RGB(255, 0, 0));
		ci = LSUtils::PrefixedGetRCColor(Prefix, "SecondInnerColor", co);
		w = LSUtils::PrefixedGetRCInt(Prefix, "SecondWeight", 1);
		l = LSUtils::PrefixedGetRCInt(Prefix, "SecondLength", 0.9*min(nCenterX, nCenterY));
		second = LoadHand(szTemp, ci, co, l, w);
	}
	
	// minutes:
	co = LSUtils::PrefixedGetRCColor(Prefix, "MinuteColor", RGB(0, 255, 0));
	ci = LSUtils::PrefixedGetRCColor(Prefix, "MinuteInnerColor", co);
	l = LSUtils::PrefixedGetRCInt(Prefix, "MinuteLength", 0.9*min(nCenterX, nCenterY));
	w = LSUtils::PrefixedGetRCInt(Prefix, "MinuteWeight", 2);
	minute = LoadHand(szTemp, ci, co, l, w);

	// hours:
	co = LSUtils::PrefixedGetRCColor(Prefix, "HourColor", RGB(0, 0, 255));
	ci = LSUtils::PrefixedGetRCColor(Prefix, "HourInnerColor", co);
	l = LSUtils::PrefixedGetRCInt(Prefix, "HourLength", 0.7*min(nCenterX, nCenterY));
	w = LSUtils::PrefixedGetRCInt(Prefix, "HourWeight", 3);
	hour = LoadHand(szTemp, ci, co, l, w);

	nResolution = LSUtils::PrefixedGetRCInt(Prefix, "Resolution", 60);
	nRefresh = LSUtils::PrefixedGetRCInt(Prefix, "Refresh", 60000/nResolution);

	ClockHand::sinus = new SinBuffer(nResolution, 0);
	ClockHand::cosinus = new CosBuffer(nResolution, -(nResolution)/2);

	char t1[MAX_LINE_LENGTH], t2[MAX_LINE_LENGTH], t3[MAX_LINE_LENGTH];
	char* tokens[3] = {t1, t2, t3};

	LSUtils::PrefixedGetRCLine(Prefix, "DrawOrder", szTemp, MAX_LINE_LENGTH, "h m s");
	int count = LCTokenize(szTemp, tokens, 3, NULL);

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "order string: %s, c: %d", szTemp, count);
#endif

	for (int i = 0; i < count; i++)// count
	{
		order[i] = tokens[i][0];
	}

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "order: %s, c: %d", order, count);
	LSLogPrintf(LOG_DEBUG, Prefix, "lengths: h %d, m %d s %d", hour->GetLength(), minute->GetLength(), second->GetLength());
#endif

}


/* ClockHand */

ClockHand* ClockFace::LoadHand(LPCSTR type, COLORREF ci, COLORREF co, int l, int w)
{
	if (stricmp(type, "box") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading boxhand");
#endif
		return new BoxHand(ci, co, l, w);
	}
	else if (stricmp(type, "triangle") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading trihand");
#endif
		return new TriHand(ci, co, l, w);
	}
	else 
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading Linehand (default)");
#endif
		return new LineHand(ci, co, l, w);
	}
}

ClockHand* ClockFace::LoadHand(LPCSTR type, COLORREF c, int l, int w)
{
	return LoadHand(type, c, c, l, w);
}

SinBuffer* ClockHand::sinus = NULL;
CosBuffer* ClockHand::cosinus = NULL;
int ClockHand::nCenterX = 0;
int ClockHand::nCenterY = 0;


ClockHand::ClockHand(COLORREF ci, COLORREF co, int l, int w) :
	clrIn(ci),
	clrOut(co),
	nLength(l),
	nWeight(w)
{

}

COLORREF ClockHand::GetColor()
{
	return clrOut;
}

COLORREF ClockHand::GetInnerColor()
{
	return clrIn;
}

int ClockHand::GetWeight()
{
	return nWeight;
}

int ClockHand::GetLength()
{
	return nLength;
}

void ClockHand::SetCenter(int cx, int cy)
{
	nCenterX = cx;
	nCenterY = cy;
}

int ClockHand::GetCenterX()
{
	return nCenterX;
}

int ClockHand::GetCenterY()
{
	return nCenterY;
}


/* LineHand, for drawing using lines */
LineHand::LineHand(COLORREF ci, COLORREF co, int l, int w) : ClockHand(ci, co, l, w)
{
}

void LineHand::DrawHand(HDC hdc, HRGN hrgn, const int index)
{
	HPEN hpen;
	HPEN hpenold;
	int end_x, end_y;

	end_x = GetCenterX() + GetLength() * (*sinus)[index];
	end_y = GetCenterY() + GetLength() * (*cosinus)[index];

	hpen = CreatePen(PS_SOLID, GetWeight(), GetColor());
	hpenold = (HPEN) SelectObject(hdc, hpen);

	MoveToEx(hdc, GetCenterX(), GetCenterY(), NULL);
	LineTo(hdc, end_x, end_y);
	SelectObject(hdc, hpenold);
	DeleteObject(hpen);
}


/* BoxHand, for drawing using boxes and adding the region */
BoxHand::BoxHand(COLORREF ci, COLORREF co, int l, int w) : ClockHand(ci, co, l, w)
{
}

void BoxHand::DrawHand(HDC hdc, HRGN hrgn, const int index)
{
	HPEN hpen;
	HPEN hpenold;
	HBRUSH hbrush;
	HBRUSH hbrushold;

	int lwidth = (GetWeight()/2) + (GetWeight()%2);
	int rwidth = GetWeight()/2;

	POINT points[4];
	points[0].x = GetCenterX() - lwidth * (*cosinus)[index];
	points[0].y = GetCenterY() + lwidth * (*sinus)[index];

	points[1].x = points[0].x + GetLength() * (*sinus)[index];
	points[1].y = points[0].y + GetLength() * (*cosinus)[index];

	points[3].x = GetCenterX() + rwidth * (*cosinus)[index];
	points[3].y = GetCenterY() - rwidth * (*sinus)[index];

	points[2].x = points[3].x + GetLength() * (*sinus)[index];
	points[2].y = points[3].y + GetLength() * (*cosinus)[index];

	SetPolyFillMode(hdc, WINDING);
	hpen = CreatePen(PS_SOLID, 1, GetColor());
	hpenold = (HPEN) SelectObject(hdc, hpen);

	hbrush = CreateSolidBrush( GetInnerColor() );
	hbrushold = (HBRUSH) SelectObject(hdc, hbrush);

	// draw using box polygon
	Polygon(hdc, points, 4);
	// adapt region to it as well
	HRGN add = CreatePolygonRgn(points, 4, WINDING);
	CombineRgn(hrgn, hrgn, add, RGN_OR);
	DeleteObject(add);

	SelectObject(hdc, hbrushold);
	DeleteObject(hbrush);

	SelectObject(hdc, hpenold);
	DeleteObject(hpen);
}


/* TriHand, for drawing using a triangle polygon and adding the region */
TriHand::TriHand(COLORREF ci, COLORREF co, int l, int w) : ClockHand(ci, co, l, w)
{
}

void TriHand::DrawHand(HDC hdc, HRGN hrgn, const int index)
{
	HPEN hpen;
	HPEN hpenold;
	HBRUSH hbrush;
	HBRUSH hbrushold;

	int lwidth = (GetWeight()/2) + (GetWeight()%2);
	int rwidth = GetWeight()/2;

	POINT points[3];
	points[0].x = GetCenterX() - lwidth * (*cosinus)[index];
	points[0].y = GetCenterY() + lwidth * (*sinus)[index];

	points[1].x = GetCenterX() + GetLength() * (*sinus)[index];
	points[1].y = GetCenterY() + GetLength() * (*cosinus)[index];

	points[2].x = GetCenterX() + rwidth * (*cosinus)[index];
	points[2].y = GetCenterY() - rwidth * (*sinus)[index];

	SetPolyFillMode(hdc, WINDING);
	hpen = CreatePen(PS_SOLID, 1, GetColor());
	hpenold = (HPEN) SelectObject(hdc, hpen);

	hbrush = CreateSolidBrush( GetInnerColor() );
	hbrushold = (HBRUSH) SelectObject(hdc, hbrush);

	// draw using box polygon
	Polygon(hdc, points, 3);
	// adapt region to it as well
	HRGN add = CreatePolygonRgn(points, 3, WINDING);
	CombineRgn(hrgn, hrgn, add, RGN_OR);
	DeleteObject(add);

	SelectObject(hdc, hbrushold);
	DeleteObject(hbrush);

	SelectObject(hdc, hpenold);
	DeleteObject(hpen);
}