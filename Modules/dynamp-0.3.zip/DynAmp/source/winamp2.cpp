#include "winamp2.h"
#include "log.h"
#include "..\current\lsapi\lsapi.h"


// constructors:

wa2::wa2()
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, logName, "loading wa2 control");
#endif

	// load string where to launch the program from
	GetRCString("WinampPath", szAmpPath, "c:\\progra~1\\winamp\\winamp.exe", MAX_LINE_LENGTH);

	// load the !bang command for this player
	char szTemp[MAX_LINE_LENGTH];
	GetRCLine("DynAmpOnWA2", szTemp, MAX_LINE_LENGTH, "!NONE"); // WA2 load command
	OnPlayerLoad = new char[strlen(szTemp)+1];
	strcpy(OnPlayerLoad, szTemp);

	// if there is a command to run
	if ( OnPlayerLoad != NULL )
	{
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "Running Command: %s", OnPlayerLoad);
#endif
		LSExecute(GetLitestepWnd(), OnPlayerLoad, NULL);
	}

	// specific wa2 functions, needs to be defined as static and placed in .h
	AddBangCommand("!Amp_StopFade", Bang_StopFade);
	AddBangCommand("!Amp_ReloadSkin", Bang_ReloadSkin);
	AddBangCommand("!Amp_DoubleSize", Bang_DoubleSize);
	AddBangCommand("!Amp_EditID3", Bang_EditID3);
	AddBangCommand("!Amp_AddSong", Bang_AddSong);
	AddBangCommand("!Amp_LoadEQPreset", Bang_LoadEQPreset);
	AddBangCommand("!Amp_HighPriority", Bang_HighPriority);
	AddBangCommand("!Amp_About", Bang_About);
	AddBangCommand("!Amp_EasyMove", Bang_EasyMove);
	AddBangCommand("!Amp_Eq", Bang_Eq);
	AddBangCommand("!Amp_Jump10Back", Bang_Jump10Back);
	AddBangCommand("!Amp_Jump10Fwd", Bang_Jump10Fwd);
	AddBangCommand("!Amp_JumpToFile", Bang_JumpToFile);
	AddBangCommand("!Amp_JumpToTime", Bang_JumpToTime);
	AddBangCommand("!Amp_ListEnd", Bang_ListEnd);
	AddBangCommand("!Amp_ListStart", Bang_ListStart);
	AddBangCommand("!Amp_MainMenuPopup", Bang_MainMenuPopup);
	AddBangCommand("!Amp_Playlist", Bang_Playlist);
	AddBangCommand("!Amp_SelectSkin", Bang_SelectSkin);
	AddBangCommand("!Amp_SetPanning", Bang_SetPanning);
	AddBangCommand("!Amp_SetVolume", Bang_SetVolume);
	AddBangCommand("!Amp_ShadeBoth", Bang_ShadeBoth);
	AddBangCommand("!Amp_ShadePlaylist", Bang_ShadePlaylist);
	AddBangCommand("!Amp_StartPlugin", Bang_StartPlugin);
	AddBangCommand("!Amp_StopPlugin", Bang_StopPlugin);
	AddBangCommand("!Amp_ToggleBrowser", Bang_ToggleBrowser);
	AddBangCommand("!Amp_VisSetup", Bang_VisSetup);
	AddBangCommand("!Amp_WindowShade", Bang_WindowShade);
	AddBangCommand("!Amp_Rew", Bang_Rew);
	AddBangCommand("!Amp_Ffwd10s", Bang_Ffwd10s);
	AddBangCommand("!Amp_Ffwd20s", Bang_Ffwd20s);
	AddBangCommand("!Amp_Rewd10s", Bang_Rew10s);
	AddBangCommand("!Amp_Rewd20s", Bang_Rew20s);
	AddBangCommand("!Amp_Restart", Bang_Restart);
	//AddBangCommand("!Amp_MovePosition", Bang_MovePosition);
	//AddBangCommand("!Amp_FileInfo", Bang_FileInfo);
	AddBangCommand("!Amp_PlayPause", Bang_PlayPause);
	AddBangCommand("!Amp_TimeRemaining", Bang_TimeRemaining);
	AddBangCommand("!Amp_TimeElapsed", Bang_TimeElapsed);

}

wa2::~wa2()
{
	// delete !bang commands
	if (OnPlayerLoad != NULL) {
		delete [] OnPlayerLoad;
		OnPlayerLoad = NULL;
	}

	RemoveBangCommand("!Amp_StopFade");
	RemoveBangCommand("!Amp_ReloadSkin");
	RemoveBangCommand("!Amp_DoubleSize");
	RemoveBangCommand("!Amp_EditID3");
	RemoveBangCommand("!Amp_AddSong");
	RemoveBangCommand("!Amp_LoadEQPreset");
	RemoveBangCommand("!Amp_HighPriority");
	RemoveBangCommand("!Amp_About");
	RemoveBangCommand("!Amp_EasyMove");
	RemoveBangCommand("!Amp_EditID3");
	RemoveBangCommand("!Amp_Eq");
	RemoveBangCommand("!Amp_Ffwd5s");
	RemoveBangCommand("!Amp_Jump10Back");
	RemoveBangCommand("!Amp_Jump10Fwd");
	RemoveBangCommand("!Amp_JumpToFile");
	RemoveBangCommand("!Amp_JumpToTime");
	RemoveBangCommand("!Amp_ListEnd");
	RemoveBangCommand("!Amp_ListStart");
	RemoveBangCommand("!Amp_MainMenuPopup");
	RemoveBangCommand("!Amp_Playlist");
	RemoveBangCommand("!Amp_SelectSkin");
	RemoveBangCommand("!Amp_SetPanning");
	RemoveBangCommand("!Amp_SetVolume");
	RemoveBangCommand("!Amp_ShadeBoth");
	RemoveBangCommand("!Amp_ShadePlaylist");
	RemoveBangCommand("!Amp_StartPlugin");
	RemoveBangCommand("!Amp_StopPlugin");
	RemoveBangCommand("!Amp_ToggleBrowser");
	RemoveBangCommand("!Amp_VisSetup");
	RemoveBangCommand("!Amp_WindowShade");
	RemoveBangCommand("!Amp_Rew");
	RemoveBangCommand("!Amp_Ffwd10s");
	RemoveBangCommand("!Amp_Ffwd20s");
	RemoveBangCommand("!Amp_Rewd10s");
	RemoveBangCommand("!Amp_Rewd20s");
	RemoveBangCommand("!Amp_Restart");
	//RemoveBangCommand("!Amp_MovePosition");
	//RemoveBangCommand("!Amp_FileInfo");
	RemoveBangCommand("!Amp_PlayPause");
	RemoveBangCommand("!Amp_TimeRemaining");
	RemoveBangCommand("!Amp_TimeElapsed");
}


// functions:

void wa2::prev() 
{
	wa2Message(WINAMP_PREVSONG);
}

void wa2::play() {
	if (!PlayNotOpen)
	{
		if (!GetPlayerWnd())
		{
			playerOpen();
		}
	}
	wa2Message(WINAMP_PLAY);
}

void wa2::pause() 
{
	wa2Message(WINAMP_PAUSE);
}

void wa2::stop() 
{
	wa2Message(WINAMP_STOP);
}

void wa2::next() 
{
	wa2Message(WINAMP_NEXTSONG);
}

void wa2::loadFile() 
{
	if (!LoadFileNotOpen) 
	{
		if (!GetPlayerWnd())
			playerOpen();
	}
	SetForegroundWindow(GetPlayerWnd());
	wa2Message(WINAMP_FILE_PLAY); 
}

void wa2::shuffle() {
	wa2Message(WINAMP_FILE_SHUFFLE);
}

void wa2::repeat() {
	wa2Message(WINAMP_FILE_REPEAT);
}

void wa2::powerOff()
{
	wa2Message(WINAMP_FILE_QUIT);
}

void wa2::rewind5s() {
	wa2Message(WINAMP_REW5S);
}

void wa2::forward5s() {
	wa2Message(WINAMP_REW5S);
}

void wa2::volumeDown() {
	wa2Message(WINAMP_VOLUMEDOWN);
}

void wa2::volumeUp() {
	wa2Message(WINAMP_VOLUMEUP);
}

void wa2::onTop() {
	wa2Message(WINAMP_OPTIONS_AOT);
}

void wa2::loadDir() {
	SetForegroundWindow(GetPlayerWnd());
	wa2Message(WINAMP_FILE_DIR);
}

void wa2::openLoc() {
	wa2Message(WINAMP_OPEN_LOC);
}

void wa2::prefs() {
	if (!PrefsNotOpen) {
		if (!GetPlayerWnd())
			playerOpen();
	}
	wa2Message(WINAMP_OPTIONS_PREFS);
}

// This is our main message handler where all winamp message are passed to
void wa2::wa2Message(const int msg)
{
	player::sendMsg(GetPlayerWnd(), msg);
}

// find window handle
HWND wa2::GetPlayerWnd()
{
	return FindWindow(WC_WINAMP2, NULL);
}
