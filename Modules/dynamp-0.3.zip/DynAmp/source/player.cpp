#include "player.h"
#include "log.h"
#include "..\current\lsapi\lsapi.h"


player::player()
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, "player", "constructor");
#endif

	WinampStartNormal = GetRCBoolDef("WinampStartNormal", FALSE);
	PlayNotOpen = GetRCBoolDef("PlayNotOpen", FALSE);
	PlayPauseNotOpen = GetRCBoolDef("PlayPauseNotOpen", FALSE);
	PlaylistNotOpen = GetRCBoolDef("PlaylistNotOpen", FALSE);
	PrefsNotOpen = GetRCBoolDef("PrefsNotOpen", FALSE);
	LoadFileNotOpen = GetRCBoolDef("LoadFileNotOpen", FALSE);
	ShowNotOpen = GetRCBoolDef("ShowNotOpen", FALSE);

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, "player", "winamp start normal: %d", WinampStartNormal);
	LSLogPrintf(LOG_DEBUG, "player", "play not open: %d", PlayNotOpen);
	LSLogPrintf(LOG_DEBUG, "player", "playpause not open: %d", PlayPauseNotOpen);
	LSLogPrintf(LOG_DEBUG, "player", "playlist not open: %d", PlaylistNotOpen);
	LSLogPrintf(LOG_DEBUG, "player", "prefs not open: %d", PrefsNotOpen);
	LSLogPrintf(LOG_DEBUG, "player", "loadfile not open: %d", LoadFileNotOpen);
	LSLogPrintf(LOG_DEBUG, "player", "show not open: %d", ShowNotOpen);
#endif

}

void player::power()
{
	(!GetPlayerWnd()) ? playerOpen() : powerOff();
}

void player::powerOn()
{
	(!GetPlayerWnd()) ? playerOpen() : SetForegroundWindow(GetPlayerWnd());
}

void player::show() {
	if (!ShowNotOpen) {
		if (!GetPlayerWnd())
			playerOpen();
	}
	if (!IsIconic(GetPlayerWnd()))
		PostMessage(GetPlayerWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
	else {
		PostMessage(GetPlayerWnd(), WM_SYSCOMMAND, SC_RESTORE, 0);
		SetForegroundWindow(GetPlayerWnd());
	}
}

void player::hide() {
	PostMessage(GetPlayerWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
}

void player::display() {
	PostMessage(GetPlayerWnd(), WM_SYSCOMMAND, SC_RESTORE, 0);
}