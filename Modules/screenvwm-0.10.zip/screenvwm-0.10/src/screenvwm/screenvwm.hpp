/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

#define PROJECT_NAME "screenvwm"
#define VERSION_MAJOR 0
#define VERSION_MINOR 7

#define _stringify(x) #x
#define VERSION_NUMBER _stringify(VERSION_MAJOR) "." _stringify(VERSION_MINOR)
#define VERSION_STRING (PROJECT_NAME " " VERSION_NUMBER)

/// This is a basically arbitrary number which identifies this module for
/// purposes of saving/restoring Litestep state; the only requirement is that
/// it be in the range if an unsigned short and not be the same as any other
/// Litestep module. So this was basically chosen at random. And yes, it's
/// entirely possible that there is a collision I don't know about (it should
/// only take 256 modules before E(collisions)=1).
#define MODULE_ID 0xC153

#define _WIN32_WINNT 0x0501
#define WINVER 0x0501
#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>

#define MAX_LINE_LENGTH 4096
#pragma warning (disable: 4800) // Conversion from int to bool
#pragma warning (disable: 4244) // Implicit conversion from int to float

#include <vector>
using std::vector;
#include <map>
using std::map;
using std::pair;
#include <string>
using std::string;
#include <set>
using std::set;
#include <assert.h>

#include "classproto.hpp"

#include "paintclass.hpp"
#include "wrappingflow.hpp"
#include "util.hpp"
#include "rcsettings.hpp"
#include "windowstorage.hpp"
#include "windowtracking.hpp"
#include "layout.hpp"
#include "elements.hpp"
#include "flow.hpp"
#include "trace.hpp"
#include "virtualdesktop.hpp"
#include "vwmpanel.hpp"
#include "vwm.h"
#include "dragndrop.hpp"
#include "monitor.hpp"
#include "fallbackselector.hpp"

extern HINSTANCE dllInstance;

void initBangs();
void cleanupBangs();

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

string statsClassEval(string str, ElementContext *context);
