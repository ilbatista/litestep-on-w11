/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

LinearFlow::LinearFlow(string prefix)
	:FlowElement(prefix)
{
	vertical = getConfigBool("Vertical", false, prefix.c_str());
	
	// These settings aren't yet used properly, but will be implemented at
	// some point in the future
	thickness = getConfigString("Thickness", "-0", prefix.c_str());
	rows = getConfigInt("Rows", 1, prefix.c_str());
	flowDirection = directionFromString(getConfigString("FlowDirection", "right", prefix.c_str()).c_str());
	numRows = getConfigInt("NumRows", 1, prefix.c_str());
}

LinearFlow::~LinearFlow()
{
}

void LinearFlow::arrangeElements(ElementContext *context, vector<FlowCache> &children)
{
	int rowThickness = getRowThickness(context);
	
	int x = context->boundingRect.left;
	int y = context->boundingRect.top;
	
	// Find the total size
	int totalMinLength = 0;
	int totalPreferredLength = 0;
	for(unsigned ii=0; ii<children.size(); ii++)
	{
		totalMinLength += children[ii].minLength;
		totalPreferredLength += children[ii].preferredLength;
	}
	
	int availableLength = vertical ? context->boundingRect.height : context->boundingRect.width;
	vector<int> lengths;
	
	if(totalPreferredLength <= availableLength)
	{
		for(unsigned ii=0; ii<children.size(); ii++)
			lengths.push_back(children[ii].preferredLength);
		
		int excess = availableLength - totalPreferredLength;
		vector<int> expandingElements;
		for(unsigned ii=0; ii<children.size(); ii++)
		{
			if(children[ii].expanding)
				expandingElements.push_back(ii);
		}
		if(expandingElements.size())
		{
			int expansion = excess / expandingElements.size();
			excess -= expansion*expandingElements.size();
			for(unsigned ii=0; ii<expandingElements.size(); ii++)
				lengths[expandingElements[ii]] += expansion;
			for(unsigned ii=0; ii<min(expandingElements.size(), excess); ii++)
				lengths[expandingElements[ii]]++;
		}
	}
	else if(totalMinLength >= availableLength || totalMinLength==totalPreferredLength)
	{
		for(unsigned ii=0; ii<children.size(); ii++)
			lengths.push_back(children[ii].minLength);
	}
	else
	{
		// There is some space available for children to be bigger than their
		// minimum size, but not enough to satisfy everyone's preferred size.
		// Give every child a size in between its min and pref making sure that
		//  - The full length is filled
		//  - Everything gets at least its minimum length
		//  - Lengths are as close to equal as possible
		set<int> childrenWantingMore;
		
		// First, give everything its minimum size, and note which elements
		// want more than that.
		for(unsigned ii=0; ii<children.size(); ii++)
		{
			lengths.push_back(children[ii].minLength);
			if(children[ii].preferredLength > children[ii].minLength)
				childrenWantingMore.insert(ii);
		}
		
		int spaceLeft = availableLength - totalMinLength;
		
		while(spaceLeft > 0)
		{
			// Find the smallest requested expansion
			int smallestRequest = -1;
			for(set<int>::iterator ii=childrenWantingMore.begin(); ii!=childrenWantingMore.end(); ii++)
			{
				int request = children[*ii].preferredLength - lengths[*ii];
				if(request<smallestRequest || smallestRequest<0)
					smallestRequest = request;
			}
			
			// If there is enough space to give smallestRequest to every child
			// that still wants more, do so.
			if(smallestRequest * childrenWantingMore.size() <= spaceLeft)
			{
				spaceLeft -= smallestRequest * childrenWantingMore.size();
				
				for(set<int>::iterator ii=childrenWantingMore.begin(); ii!=childrenWantingMore.end(); )
				{
					lengths[*ii] += smallestRequest;
					if(lengths[*ii] == children[*ii].preferredLength)
						ii = childrenWantingMore.erase(ii);
					else
						ii++;
				}
			}
			// There is not enough space left to satisfy the smallest request
			// for everything, so divide the remaining space among the children
			// that still want it
			else
			{
				// First give an equal amount to all
				int spaceGiven = (int)(spaceLeft / childrenWantingMore.size());
				for(set<int>::iterator ii=childrenWantingMore.begin(); ii!=childrenWantingMore.end(); ii++)
					lengths[*ii] += spaceGiven;
				spaceLeft -= spaceGiven * childrenWantingMore.size();
				// Give out the last few pixels of space, to have a clean right edge
				for(set<int>::iterator ii=childrenWantingMore.begin(); ii!=childrenWantingMore.end(); ii++) {
					lengths[*ii]++;
					spaceLeft--;
					if(spaceLeft<=0)
						break;
				}
			}
		}
	}
	
	// Position children
	for(unsigned ii=0; ii<children.size(); ii++)
	{
		children[ii].context.boundingRect.left = x;
		children[ii].context.boundingRect.top = y;
		
		if(vertical) {
			children[ii].context.boundingRect.width = rowThickness;
			children[ii].context.boundingRect.height = lengths[ii];
			y += children[ii].context.boundingRect.height;
		} else {
			children[ii].context.boundingRect.height = rowThickness;
			children[ii].context.boundingRect.width = lengths[ii];
			x += children[ii].context.boundingRect.width;
		}
	}
	// TODO: Handle multiple rows
}

pair<int,int> LinearFlow::getLength(ElementContext *context, bool vertical)
{
	vector<FlowCache> children;
	ElementContext childContext = getChildContext(context);
	getChildren(children, &childContext);
	
	// TODO: Handle multiple rows
	int minLength = 0;
	int preferredLength = 0;
	for(unsigned ii=0; ii<children.size(); ii++) {
		minLength += children[ii].minLength;
		preferredLength += children[ii].preferredLength;
	}
	return pair<int,int>(minLength, preferredLength);
}

ElementContext LinearFlow::getChildContext(ElementContext *parentContext)
{
	int rowThickness = getRowThickness(parentContext);
	ElementContext ret = *parentContext;
	
	if(vertical)
		ret.boundingRect.width = rowThickness;
	else
		ret.boundingRect.height = rowThickness;
	return ret;
}

bool LinearFlow::isVertical()
{
	return vertical;
}

int LinearFlow::getRowThickness(ElementContext *context)
{
	int maxThickness;
	if(vertical) maxThickness = context->boundingRect.width;
	else         maxThickness = context->boundingRect.height;
	int totalThickness = ParseCoordinate(thickness.c_str(), maxThickness, maxThickness);
	
	return totalThickness / rows;
}

bool LinearFlow::verticalChildren()
{
	return vertical;
}