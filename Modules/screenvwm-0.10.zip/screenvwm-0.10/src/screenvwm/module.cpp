/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

HINSTANCE dllInstance;
VWM *vwm = NULL;
const char *traceFilename = "screenvwm.log";

//=========================================================
// Module initialization and cleanup
//=========================================================
int initModuleEx(HWND parentWindow, HINSTANCE dllInstance, LPCSTR szPath)
{
	::dllInstance = dllInstance;
	
	if(getConfigBool("Trace", false))
		trace.enable();
	
	DragWindow::registerWindowClass();
	layoutPool = new LayoutPool();
	monitors = new MonitorPool();
	loadDefaultSettings();
	
	if(parentWindow == GetLitestepWnd())
		parentWindow = NULL;
	
	vwm = new VWM(parentWindow);
	vwm->finalize();
	
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	vwm->saveDesktops();
	delete vwm;
	DragWindow::unregisterWindowClass();
	delete layoutPool;
	delete monitors;
	delete settings;
	trace.close();
}
