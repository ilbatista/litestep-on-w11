/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

TextLabelElement::TextLabelElement(string prefix)
	:LayoutElement(prefix)
{
	alignHoriz = parseAlign(getConfigString("AlignHoriz", "center", prefix.c_str()));
	alignVert  = parseAlign(getConfigString("AlignVert", "center", prefix.c_str()));
	
	string defaultX, defaultY;
	switch(alignHoriz) {
		case alignLeft:   defaultX = "0"; break;
		case alignCenter: defaultX = "50%"; break;
		case alignRight:  defaultX = "-0"; break;
	}
	switch(alignVert) {
		case alignTop:    defaultY = "0"; break;
		case alignCenter: defaultY = "50%"; break;
		case alignBottom: defaultY = "-0"; break;
	}
	
	x = getConfigString("X", defaultX.c_str(), prefix.c_str());
	y = getConfigString("Y", defaultY.c_str(), prefix.c_str());
	minLength = getConfigString("MinLength", "0", prefix.c_str());
	maxLength = getConfigString("MaxLength", "250", prefix.c_str());
	
	allowAbbrev = getConfigBool("AllowAbbrev", false, prefix.c_str());
	
	useStatsClass = getConfigBool("UseXStats", false, prefix.c_str());
	
	PaintTextDefaults textDefaults;
	textDefaults.m_iFontHeight = 8;
	font = Create_xTextClass();
	font->configure(prefix.c_str(), "", 0, NULL, &textDefaults);
	
	string textString = getConfigLine("Text", ".auto", prefix.c_str());
	if(textString == ".auto")
		text = labelAuto;
	else if(textString == ".desknum")
		text = labelDeskNum;
	else if(textString == ".taskname")
		text = labelTaskName;
	else {
		text = labelCustom;
		customText = textString;
	}
}

TextLabelElement::~TextLabelElement()
{
	Destroy_xTextClass(font);
}

string TextLabelElement::getText(ElementContext *context)
{
	if(useStatsClass)
	{
		return statsClassEval(customText, context);
	}
	
	switch(text)
	{
		default:
		case labelAuto:
			if(context->task)
				return context->task->getTitle();
			else if(context->desk)
				return context->desk->getLabel();
			else
				return "?";
		case labelTaskName:
			if(context->task)
				return context->task->getTitle();
			else
				return "?";
		case labelDeskNum:
			if(context->desk)
				return context->desk->getLabel();
			else
				return "?";
		case labelCustom:
			return customText;
	}
}

void TextLabelElement::draw(HDC drawContext, LayoutCacheNode *layout)
{
	string text = getText(&layout->context);
	Rect rect = layout->context.boundingRect;
	
	font->apply(drawContext,
		rect.left, rect.top,
		rect.width, rect.height,
		text.c_str());
}

bool TextLabelElement::changed(LayoutCacheNode *node)
{
	// TODO
	return false;
}

LayoutCacheNode *TextLabelElement::buildLayout(ElementContext *context, LayoutCacheNode *prev)
{
	LayoutCacheNode *ret = LayoutElement::buildLayout(context, prev);
	ret->element = this;
	Rect &rect = ret->context.boundingRect;
	
	string text = getText(context);
	POINT textSize = font->measure(context->panel->backBuffer, 0, 0, text.c_str());
	
	switch(alignHoriz)
	{
		default:
		case alignLeft: {
			int offsetX = ParseCoordinate(x.c_str(), 0, rect.width);
			rect.left += offsetX;
			rect.width -= offsetX;
			break;
		}
		case alignRight: {
			int rightX = ParseCoordinate(x.c_str(), 0, rect.width);
			int leftX = rightX - textSize.x;
			if(leftX < 0) leftX = 0;
			rect.left = leftX;
			rect.width = rightX - leftX;
			break;
		}
		case alignCenter: {
			int offsetX = ParseCoordinate(x.c_str(), 0, rect.width) - textSize.x/2;
			if(offsetX > 0) {
				rect.left += offsetX;
				rect.width -= offsetX;
			}
			break;
		}
	}
	
	switch(alignVert)
	{
		default:
		case alignTop: {
			int offsetY = ParseCoordinate(y.c_str(), 0, rect.height);
			rect.top += offsetY;
			rect.height -= offsetY;
			break;
		}
		case alignBottom: {
			int bottomY = ParseCoordinate(y.c_str(), 0, rect.height);
			int topY = bottomY - textSize.y;
			if(topY < 0) topY = 0;
			rect.top = topY;
			rect.height = bottomY - topY;
			break;
		}
		case alignCenter: {
			int offsetY = ParseCoordinate(y.c_str(), 0, rect.height) - textSize.y/2;
			if(offsetY > 0) {
				rect.top += offsetY;
				rect.height = textSize.y;
			}
			break;
		}
	}
	
	return ret;
}

pair<int,int> TextLabelElement::getLength(ElementContext *context, bool vertical)
{
	string text = getText(context);
	// FIXME: Don't poke through private data structures like this
	POINT textSize = font->measure(context->panel->backBuffer, 0, 0, text.c_str());
	
	int minSize, preferredSize;
	int maxSize;
	if(vertical) {
		minSize = ParseCoordinate(minLength.c_str(), textSize.y, context->boundingRect.height);
		preferredSize = ParseCoordinate(maxLength.c_str(), textSize.y, context->boundingRect.height);
		maxSize = ParseCoordinate(maxLength.c_str(), context->boundingRect.height, context->boundingRect.height);
		if(maxSize > textSize.y)
			maxSize = textSize.y;
		
		int ypos = ParseCoordinate(y.c_str(), 0, 0);
		if(ypos>=0) {
			minSize += ypos;
			preferredSize += ypos;
			maxSize += ypos;
		}
	} else {
		minSize = ParseCoordinate(minLength.c_str(), textSize.x, context->boundingRect.width);
		preferredSize = ParseCoordinate(maxLength.c_str(), textSize.x, context->boundingRect.width);
		maxSize = ParseCoordinate(maxLength.c_str(), context->boundingRect.width, context->boundingRect.width);
		if(maxSize > textSize.x)
			maxSize = textSize.x;
		
		int xpos = ParseCoordinate(x.c_str(), 0, 0);
		if(xpos>=0) {
			minSize += xpos;
			preferredSize += xpos;
			maxSize += xpos;
		}
	}
	
	if(maxSize < minSize)
		maxSize = minSize;
	if(preferredSize > maxSize)
		preferredSize = maxSize;
	
	if(!allowAbbrev)
	{
		minSize = preferredSize;
	}
	
	return pair<int,int>(minSize, preferredSize);
}
