/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

RectLayoutElement::RectLayoutElement(string prefix)
	:LayoutElement(prefix)
{
	x = getConfigString("X", "0", prefix.c_str());
	y = getConfigString("Y", "0", prefix.c_str());
	width = getConfigString("Width", "-0", prefix.c_str());
	height = getConfigString("Height", "-0", prefix.c_str());
}

LayoutCacheNode *RectLayoutElement::buildLayout(ElementContext *context, LayoutCacheNode *prev)
{
	LayoutCacheNode *ret = LayoutElement::buildLayout(context, prev);
	ret->element = this;
	
	int contextWidth = context->boundingRect.width;
	int contextHeight = context->boundingRect.height;
	ret->context.boundingRect.left   = context->boundingRect.left + ParseCoordinate(x.c_str(), 0, contextWidth);
	ret->context.boundingRect.top    = context->boundingRect.top + ParseCoordinate(y.c_str(), 0, contextHeight);
	ret->context.boundingRect.width  = ParseCoordinate(width.c_str(), contextWidth, contextWidth);
	ret->context.boundingRect.height = ParseCoordinate(height.c_str(), contextHeight, contextHeight);

	return ret;
}

pair<int,int> RectLayoutElement::getLength(ElementContext *context, bool vertical)
{
	int ret;
	if(vertical) {
		int xpos = ParseCoordinate(x.c_str(), 0, 0);
		if(xpos<0) xpos=0;
		ret = xpos + ParseCoordinate(height.c_str(), 0, 0);
	} else {
		int ypos = ParseCoordinate(x.c_str(), 0, 0);
		if(ypos<0) ypos=0;
		ret = ypos + ParseCoordinate(width.c_str(), 0, 0);
	}
	return pair<int,int>(ret, ret);
}
