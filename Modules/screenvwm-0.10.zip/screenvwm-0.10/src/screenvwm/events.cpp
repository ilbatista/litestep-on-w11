/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"
#include <CommCtrl.h>

static const int litestepMessageTypes[] = {
	LM_GETREVID,
	LM_BRINGTOFRONT,
	LM_SWITCHTON,
	LM_WINDOWACTIVATED,
	LM_LISTDESKTOPS,
	LM_GETDESKTOPOF,
	LM_WINDOWCREATED,
	LM_WINDOWDESTROYED,
	LM_GETMINRECT,
	LM_REPAINT,
	0
};

//=========================================================
// Message handling
//=========================================================
void VWMFirstPanel::registerEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)window, (LPARAM)litestepMessageTypes);
}

void VWMFirstPanel::unregisterEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)window, (LPARAM)litestepMessageTypes);
}

void VWM::windowProc(Message& message, HWND window)
{
	switch (message.uMsg)
	{
		case WM_SYSCOMMAND:        onSysCommand     (message); break;
		
		case WM_TIMER:
			if(updateWindowList())
				forceRedraw(false);
			break;
			
		case WM_DROPFILES:
			onDropFiles(message);
			break;
		
		case WM_DISPLAYCHANGE:
			// TODO: Reposition panels, refresh and update storage rects
			break;
		
		case WM_KEYDOWN:
		case WM_KEYUP:
		case WM_HOTKEY:
			PostMessage(getDesktopWindow(), message.uMsg, message.wParam, message.lParam);
			break;
			
		case LM_GETREVID:          onGetRevId       (message); break;
		
		case LM_BRINGTOFRONT:
			trace << "LM_BRINGTOFRONT\n"; //DEBUG
			onBringToFront(message);
			break;
			
		case LM_SWITCHTON:         onSwitchToN      (message); break;
		case LM_LISTDESKTOPS:      onListDesktops   (message); break;
		case LM_GETDESKTOPOF:      onGetDesktopOf   (message); break;
		
		// TODO: Observe window *movement*, too
		case LM_WINDOWCREATED: {
			if(updateWindowList())
				forceRedraw(false);
			break;
		}
			
		case LM_WINDOWDESTROYED: {
			if(updateWindowList()) // FIXME: The window still exists, so it won't properly go away
				forceRedraw(false);
			break;
		}
			
		case LM_WINDOWACTIVATED: {
			if(updateWindowList())
				forceRedraw(false);
			
			if(windowsByHandle.find(foregroundHandle)==windowsByHandle.end())
				break;
			WindowData *foregroundWindow = windowsByHandle[foregroundHandle];
			
			if(foregroundWindow->desk && !foregroundWindow->desk->monitor)
			{
				Monitor *monitor = findSingleMonitor(settings->altTabMonitor);
				if(!monitor) monitor = monitors->getPrimaryMonitor();
				switchDesk(foregroundWindow->desk, monitor, true);
			}
			
			break;
		}
		
		case LM_GETMINRECT:
		{
			LPSHELLHOOKINFO shellHookInfo = (LPSHELLHOOKINFO)message.wParam;
			HWND windowHandle = shellHookInfo->hwnd;
			RECT *rect = &shellHookInfo->rc;
			
			// Find any panels on the same monitor as this window
			VirtualDesktop *desk = getDeskFromWnd(windowHandle);
			if(!desk) break;
			Monitor *monitor = desk->monitor;
			if(!monitor) break;
			vector<VWMPanel*> panels = monitor->getPanels();
			
			// Find a layout element with the <prefix>IsMinimizeTarget
			// attribute set on one of those panels
			vector<LayoutCacheNode*> elements;
			for(unsigned ii=0; ii<panels.size(); ii++)
			{
				LayoutCacheNode *layout = panels[ii]->getCachedLayout();
				if(layout)
					layout->traverse(elements);
			}
			for(unsigned ii=0; ii<elements.size(); ii++)
			{
				if(elements[ii]->element->isMinimizeTarget)
				{
					VWMPanel *panel = elements[ii]->context.panel;
					// FIXME TODO: Figure out what's up with the target rect
					break;
				}
			}
			
			break;
		}
		
		default:
			message.lResult = DefWindowProc(window, message.uMsg, message.wParam, message.lParam);
			break;
	}
}

void VWM::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);
	sprintf(buf, VERSION_STRING);
	message.lResult = strlen(buf);
}

void VWM::onSysCommand(Message& message)
{
	/*if (message.wParam == SC_CLOSE)
		PostMessage(getDesktopWindow(), WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);*/
}

void VWM::onWindowActivated(Message& message)
{
}

// TODO: Test and rewrite this
void VWM::onDropFiles(Message& message)
{
	/*POINT pt;
	DragQueryPoint( (HDROP)message.wParam, &pt );
	
	VirtualDesktop *newDesk = panelPointToDesk(pt.x, pt.y);
	if(!newDesk) return;
	switchDesk(newDesk);

	int numFiles = DragQueryFile( (HDROP)message.wParam, 0xFFFFFFFF, NULL, 0 );
	for(int i=0; i<numFiles; i++)
	{
		char filename[_MAX_PATH];
		DragQueryFile( (HDROP)message.wParam, i, filename, _MAX_PATH);
		if (filename && *filename)
			LSExecute(NULL, filename, SW_SHOWNORMAL);
	}
	DragFinish( (HDROP)message.wParam );
	forceRedraw(true);*/
}

void VWM::onBringToFront(Message &message)
{
	HWND hWnd = (HWND) message.lParam;
	VirtualDesktop *desk = getDeskFromWnd(hWnd);

	if(!desk->monitor)
		switchDesk(desk, NULL, true);

	SwitchToThisWindow(hWnd, TRUE);
	message.lResult = TRUE;
}

void VWM::onSwitchToN(Message &message)
{
	message.lResult = TRUE;
	int desk = (int) message.wParam;
	if(desk < 0 || desk >= (int)desktops.size())
		return;
	
	VirtualDesktop *newDesk = desktops[desk];
	switchDesk(newDesk, NULL, true);
}

void VWM::onListDesktops(Message &message)
{
	LSDESKTOPINFO deskInfo;

	for (unsigned ii = 0; ii < desktops.size(); ii++)
	{
		deskInfo.size = sizeof(LSDESKTOPINFO);
		deskInfo.icon = 0;
		deskInfo.isCurrent = desktops[ii]->monitor?1:0;
		deskInfo.number = ii;
		
		string deskname = desktops[ii]->getName();
		strcpy(deskInfo.name, deskname.c_str());

		SendMessage((HWND) message.wParam, LM_DESKTOPINFO, 0, (LPARAM) &deskInfo);
	}

	message.lResult = TRUE;
}

void VWM::onGetDesktopOf(Message &message)
{
	VirtualDesktop *desk = getDeskFromWnd((HWND) message.wParam);
	message.lResult = desk->index;
}
