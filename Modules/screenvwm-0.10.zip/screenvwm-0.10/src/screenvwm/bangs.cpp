/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"
#include <winuser.h>

void bangCreate(HWND sender, const char *args);
void bangDestroy(HWND sender, const char *args);
void bangMerge(HWND sender, const char *args);

void bangGather(HWND sender, const char *args);
void bangSeparate(HWND sender, const char *args);
void bangSeparateAll(HWND sender, const char *args);
void bangMoveDesk(HWND sender, const char *args);

void bangDesk(HWND sender, const char *args);
void bangNext(HWND sender, const char *args);
void bangPrev(HWND sender, const char *args);
void bangOther(HWND sender, const char *args);

void bangToggle(HWND sender, const char *args);
void bangShow(HWND sender, const char *args);
void bangHide(HWND sender, const char *args);
void bangOpen(HWND sender, const char *args);
void bangMoveApp(HWND sender, const char *args);
void bangOntopToggle(HWND sender, const char *args);

void bangRaiseWindow(HWND sender, const char *args);
void bangMinimizeWindow(HWND sender, const char *args);
void bangMaximizeWindow(HWND sender, const char *args);
void bangMoveWindow(HWND sender, const char *args);
void bangResizeWindow(HWND sender, const char *args);
void bangWindowContextMenu(HWND sender, const char *args);

struct BangCommandInfo {
	const char *name;
	void (*func)(HWND sender, const char *args);
};

// All commands exist with both 'vwm' prefix (for compatibility with hotkeys
// that people might put in their shared-config files, which other VWMs will
// also respect) and 'swm' prefix (for hotkeys that other VWMs can't't or
// shouldn't recognize, and for consistency with variables).
#define BANG_COMMAND(name, func) \
    { "!swm"##name, func }, \
    { "!vwm"##name, func } \

static BangCommandInfo bangCommands[] = {
	BANG_COMMAND("Create", bangCreate),
	BANG_COMMAND("Destroy", bangDestroy),
	BANG_COMMAND("Merge", bangMerge),
	BANG_COMMAND("Gather", bangGather),
	BANG_COMMAND("Separate", bangSeparate),
	BANG_COMMAND("SeparateAll", bangSeparateAll),
	BANG_COMMAND("MoveDesk", bangMoveDesk),

	BANG_COMMAND("Desk", bangDesk),
	BANG_COMMAND("Next", bangNext),
	BANG_COMMAND("Prev", bangPrev),
	BANG_COMMAND("Other", bangOther),
	
	BANG_COMMAND("Toggle", bangToggle),
	BANG_COMMAND("Show", bangShow),
	BANG_COMMAND("Hide", bangHide),
	BANG_COMMAND("Open", bangOpen),
	BANG_COMMAND("MoveApp", bangMoveApp),
	BANG_COMMAND("OntopToggle", bangOntopToggle),

	BANG_COMMAND("RaiseWindow", bangRaiseWindow),
	BANG_COMMAND("MinimizeWindow", bangMinimizeWindow),
	BANG_COMMAND("MaximizeWindow", bangMaximizeWindow),
	BANG_COMMAND("MoveWindow", bangMoveWindow),
	BANG_COMMAND("ResizeWindow", bangResizeWindow),
	BANG_COMMAND("WindowContextMenu", bangWindowContextMenu),

	// For backwards compatibility with other VWMs, !vwmUp and !vwmLeft are
	// aliased to !vwmPrev, and !vwmRight and !vwmDown are aliased to !vwmNext.
	BANG_COMMAND("Up", bangPrev),
	BANG_COMMAND("Down", bangNext),
	BANG_COMMAND("Left", bangPrev),
	BANG_COMMAND("Right", bangNext),
};
static const int numBangCommands = sizeof(bangCommands) / sizeof(*bangCommands);

void initBangs()
{
	for(int ii=0; ii<numBangCommands; ii++)
	{
		BangCommandInfo *cmd = &bangCommands[ii];
		AddBangCommand(cmd->name, cmd->func);
	}
}

void cleanupBangs()
{
	for(int ii=0; ii<numBangCommands; ii++)
	{
		BangCommandInfo *cmd = &bangCommands[ii];
		RemoveBangCommand(cmd->name);
	}
}


//////////////////////////////////////////////////////////////////////////////

void bangCreate(HWND sender, const char *args)
{
	vwm->createDesktop();
}

void bangDestroy(HWND sender, const char *args)
{
	VirtualDesktop *desk = findSingleDesk(args);
	if(desk)
		vwm->destroyDesktop(desk);
}

void bangMerge(HWND sender, const char *args)
{
	VirtualDesktop *currentDesk = monitors->findMonitor(getCursorPos())->getDesk();
	VirtualDesktop *desk = findSingleDesk(args);
	if(desk)
		vwm->mergeDesk(currentDesk, desk);
}

void bangGather(HWND caller , const char *args)
{
	vwm->gather();
}

void bangSeparate(HWND caller, const char *args)
{
	VirtualDesktop *desk = findSingleDesk(args);
	if(desk)
		vwm->separateDesk(desk);
}

void bangSeparateAll(HWND caller, const char *args)
{
	vwm->separateDesk(NULL);
}

void bangMoveDesk(HWND caller, const char *args)
{
	VirtualDesktop *currentDesk = monitors->getPrimaryMonitor()->getDesk();
	VirtualDesktop *swapDesk = findSingleDesk(args);
	if(currentDesk && swapDesk)
		vwm->moveDesk(currentDesk->index, swapDesk->index);
}

//////////////////////////////////////////////////////////////////////////////

void bangDesk(HWND sender, const char *args)
{
	VirtualDesktop *desk = findSingleDesk(args);
	if(desk)
		vwm->switchDesk(desk);
}

void bangNext(HWND sender, const char *args)
{
	VirtualDesktop *desk = findSingleDesk("next");
	if(desk)
		vwm->switchDesk(desk);
}

void bangPrev(HWND sender, const char *args)
{
	VirtualDesktop *desk = findSingleDesk("prev");
	if(desk)
		vwm->switchDesk(desk);
}

void bangOther(HWND sender, const char *args)
{
	VirtualDesktop *desk = findSingleDesk("other");
	if(desk)
		vwm->switchDesk(desk);
}

//////////////////////////////////////////////////////////////////////////////

void bangToggle(HWND sender, const char *args)
{
	set<VWMPanel*> panels = findPanels(args);
	for(set<VWMPanel*>::iterator ii=panels.begin(); ii!=panels.end(); ii++)
		(*ii)->setVisible(!(*ii)->getVisible());
}

void bangShow(HWND sender, const char *args)
{
	set<VWMPanel*> panels = findPanels(args);
	for(set<VWMPanel*>::iterator ii=panels.begin(); ii!=panels.end(); ii++)
		(*ii)->setVisible(true);
}

void bangHide(HWND sender, const char *args)
{
	set<VWMPanel*> panels = findPanels(args);
	for(set<VWMPanel*>::iterator ii=panels.begin(); ii!=panels.end(); ii++)
		(*ii)->setVisible(false);
}

void bangOpen(HWND sender, const char *args)
{
	char deskName[MAX_LINE_LENGTH], cmd[MAX_LINE_LENGTH];
	char *tokens[1] = {deskName};

	if (LCTokenize(args, tokens, 1, cmd))
	{
		VirtualDesktop *desk = findSingleDesk(deskName);
		if(desk) vwm->switchDesk(desk);
		LSExecute(NULL, cmd, SW_SHOWNORMAL);
	}
}

void bangMoveApp(HWND sender, const char *args)
{
	char arg1[MAX_LINE_LENGTH], arg2[MAX_LINE_LENGTH];
	char *tokens[2] = {arg1, arg2};
	int numArgs = LCTokenize(args, tokens, 2, NULL);
	
	char *deskName, *taskName;
	if(!numArgs) {
		taskName = NULL;
		deskName = "other";
	} else if(numArgs==1) {
		taskName = NULL;
		deskName = arg1;
	} else {
		taskName = arg1;
		deskName = arg2;
	}
	
	VirtualDesktop *desk = findSingleDesk(deskName);
	
	WindowData *task;
	if(taskName)
		task = findSingleWindow(taskName);
	else
		task = vwm->getForegroundWindow();
	
	if(desk && task)
		vwm->moveApp(task, desk);
}

void bangOntopToggle(HWND sender, const char *args)
{
	set<VWMPanel*> panels = findPanels(args);
	for(set<VWMPanel*>::iterator ii=panels.begin(); ii!=panels.end(); ii++)
		(*ii)->setAlwaysOnTop(!(*ii)->getAlwaysOnTop());
}

void bangRaiseWindow(HWND sender, const char *args)
{
	WindowData *window = findSingleWindow(args);
	if(window) {
		if(!window->desk->monitor)
			vwm->switchDesk(window->desk);
		vwm->raiseWindow(window);
	}
}

void bangMinimizeWindow(HWND sender, const char *args)
{
	WindowData *window = findSingleWindow(args);
	if(window)
		window->minimize();
}

void bangMaximizeWindow(HWND sender, const char *args)
{
	WindowData *window = findSingleWindow(args);
	if(window) {
		if(IsZoomed(window->handle))
			window->restore();
		else
			window->maximize();
	}
}

void bangMoveWindow(HWND sender, const char *args)
{
	WindowData *window = findSingleWindow(args);
	if(window) {
		SendMessage(window->handle, WM_SYSCOMMAND, SC_MOVE, 0);
	}
}

void bangResizeWindow(HWND sender, const char *args)
{
	WindowData *window = findSingleWindow(args);
	if(window) {
		SendMessage(window->handle, WM_SYSCOMMAND, SC_SIZE, 0);
	}
}

void bangWindowContextMenu(HWND sender, const char *args)
{
	WindowData *window = findSingleWindow(args);
	if(window) {
		trace << "Opening context menu for "<<window->getTitle()<<"\n";
		Message msg;
		Point cursorPos = getCursorPos();
		msg.lParamLo = cursorPos.x;
		msg.lParamHi = cursorPos.y;
		PostMessage(window->handle, 0x313, 0, msg.lParam);
	}
}