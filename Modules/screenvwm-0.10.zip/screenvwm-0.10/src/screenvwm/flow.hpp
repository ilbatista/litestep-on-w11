/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

/////////////////////////////////////////////////////////////////////////////

class FlowElement
	:public RectLayoutElement
{
public:
	FlowElement(string prefix);
	~FlowElement();
	
	struct FlowCache
	{
		LayoutElement *element;
		LayoutCacheNode *node;
		ElementContext context;
		int minLength;
		int preferredLength;
		bool expanding;
	};
	
	LayoutCacheNode *buildLayout(ElementContext *context, LayoutCacheNode *prev);
	virtual void arrangeElements(ElementContext *context, vector<FlowCache> &elements)=0;
	void draw(HDC drawContext, LayoutCacheNode *layout);
	bool changed(LayoutCacheNode *node);
	void parseChildTypes();
	
	virtual bool isVertical()=0;
	
	struct FlowChild {
		FlowChild(LayoutElement *childType);
		virtual void append(vector<FlowCache> &children, ElementContext *context)=0;
		LayoutElement *childType;
	};
	
protected:
	vector<FlowChild*> childTypes;
	
	virtual ElementContext getChildContext(ElementContext *parentContext)=0;
	virtual bool verticalChildren()=0;
	
	/// Generate a vector of all the children of this element (desks or tasks)
	void getChildren(vector<FlowCache> &children, ElementContext *childContext, bool minimal=false);
};

/////////////////////////////////////////////////////////////////////////////

class LinearFlow
	:public FlowElement
{
public:
	LinearFlow(string prefix);
	~LinearFlow();
	
	void arrangeElements(ElementContext *context, vector<FlowCache> &elements);
	pair<int,int> getLength(ElementContext *context, bool vertical);
	ElementContext getChildContext(ElementContext *parentContext);
	bool isVertical();
	
	/// Get the per-row thickness of this flow in a given context
	int getRowThickness(ElementContext *context);
	
	bool verticalChildren();
	
protected:
	FlowDirection flowDirection;
	int numRows;
	
	string thickness;
	int rows;
	bool vertical;
};
