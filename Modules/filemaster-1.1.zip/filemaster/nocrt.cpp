#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#pragma comment(linker,"/nodefaultlib")
#pragma comment(linker,"-entry:DllMain")

/*
  This source file will remove the basic dependencies on the
  C-Runtime Library and tell the linker to leave it out.  To
  complete the job, you'll have to remove all standard C calls
  from your code.

  If you get a linker error about __chkstk, add -Gs<n> to your
  project settings, where <n> is a number in bytes larger than
  the greatest amount of local variables in any function.  If
  you've got a lot of nested calls taking lots of variables,
  this might make it run out of stack space and crash, but I
  don't know.
*/

extern "C" {
__declspec( dllexport ) BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpReserved );
}

BOOL WINAPI DllMain(
    HINSTANCE hinstDLL,  /* handle to DLL module        */ 
    DWORD fdwReason,     /* reason for calling function */ 
    LPVOID lpReserved )  /* reserved                    */ 
{
	return TRUE;
}


void* __cdecl operator new(unsigned int cb)
{
  return HeapAlloc(GetProcessHeap(),0,cb);
}

void __cdecl operator delete(void* pv)
{
  if(pv)
    HeapFree(GetProcessHeap(),0,pv);
}
