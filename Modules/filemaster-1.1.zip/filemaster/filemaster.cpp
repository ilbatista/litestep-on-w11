/****************************************************************
This sourcecode is part of:
filemaster.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)

The program mentioned above is copyrighted freeware
for any noncommercial use or distribution.

The program is provided "as is", without warranty of any kind,
express or implied, including but not limited to warranties of
merchantability, fitness for a particular purpose and
non-infringement. In no event shall I, the author and copyright
holder be liable, whether in action of contract, tort or otherwise,
arising from, out of or in connection with the program or the use
or other dealings in the software.

Mike Edward Moras
e-sushi@gmx.net

This sourcecode is part of:
filemaster.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/

/***************************************************************
changes:

2002-10-12: rabidcow
   - now using LSRegister/RemoveBangList
   - rearranged to use default of FALSE and no ifs
   - grouped common code to reduce size
   - using GetFileAttributesEx to test for exists
   - using TRUE/FALSE for BOOLs instead of true/false (for bools)
   - removed dependency on CRT, added nocrt.cpp and /Gs16384

12OCT02: e-sushi
   - released this as GNU GPL v2
   - NTFS could have bugs, I could not check before release.

****************************************************************/

#include "filemaster.h"

lsBangCmdDef Bangs[] = {
  { "FILEEXIST", bangFileExist },
  { "FILEMOVE", bangFileMove },
  { "FILECOPY", bangFileCopy },
  { "FILEDELETE", bangFileDelete },
  { "DIREXIST", bangDirExist },
  { "DIRCREATE", bangDirCreate },
  { NULL, NULL }
};

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  LSRegisterBangList("!",1,Bangs);
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
  LSRemoveBangList("!",1,Bangs);
}


/***************************************************************
  Register/Unregister a list of bang commands. [js]
****************************************************************/

#ifndef LSTOOLS_REV

/*	Bang commands must be 63 chars or fewer.
		I believe this is a restriction in the LS code,
		but I don't wanna look it up right now. */
#define MAX_BANGCMD_LENGTH 64

void LSRegisterBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs)
{
	lsBangCmdDef *pBang;
	char BangString[MAX_BANGCMD_LENGTH];

	ASSERT(READABLE(prefix,(prefixlen+1)*sizeof(char)));
	ASSERT(READABLE(Bangs,sizeof(lsBandCmdDef)));

	lstrcpy(BangString,prefix);

	if (prefixlen<0) prefixlen = lstrlen(prefix);

	/* actually, it should be much less, since */ 
	/* we paste the bang names on after this   */ 
	ASSERT(prefixlen<MAX_BANGCMD_LENGTH);

	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+prefixlen,pBang->Name);
		AddBangCommand(BangString, pBang->Command);
		pBang++;
	}
}

void LSRemoveBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs)
{
	lsBangCmdDef *pBang;
	char BangString[MAX_BANGCMD_LENGTH];

	ASSERT(READABLE(prefix,(prefixlen+1)*sizeof(char)));
	ASSERT(READABLE(Bangs,sizeof(lsBandCmdDef)));

	lstrcpy(BangString,prefix);

	if (prefixlen<0) prefixlen = lstrlen(prefix);

	ASSERT(prefixlen<MAX_BANGCMD_LENGTH);

	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+prefixlen,pBang->Name);
		RemoveBangCommand(BangString);
		pBang++;
	}
}

#endif


/****************************************************************
  GetTokenNameTrueFalse - read three tokens
****************************************************************/
void GetTokenNameTrueFalse(LPCSTR args, char *szFileName, char *bngtrue, char *bngfalse)
{
  ASSERT(READABLE(args,sizeof(char)));
  ASSERT(WRITEABLE(szFileName,1024*sizeof(char)));
  ASSERT(WRITEABLE(bngtrue,1024*sizeof(char)));
  ASSERT(WRITEABLE(bngfalse,1024*sizeof(char)));

	GetToken(args, szFileName, &args, TRUE);
	GetToken(args, bngtrue, &args, TRUE);
	GetToken(args, bngfalse, &args, TRUE);
}

/****************************************************************
  CallBangIf - execute a bang based on a condition
****************************************************************/
void CallBangIf(BOOL condition,HWND caller,LPCSTR bngtrue,LPCSTR bngfalse)
{
  ASSERT(READABLE(bngtrue,sizeof(char)));
  ASSERT(READABLE(bngfalse,sizeof(char)));

  /* LSExecute returns immediately if the command is NULL or empty */ 

  if (condition)
	  LSExecute(caller, bngtrue, NULL);
  else
	  LSExecute(caller, bngfalse, NULL);
}


/****************************************************************
 code: bangFileExist
 bang: !FILEEXIST "c:\path\file.txt" "!bangiffound" "!bangifnotfound"
****************************************************************/

void bangFileExist(HWND caller, LPCSTR args)
{
	char szFileName[1024] = "", bngtrue[1024] = "", bngfalse[1024] = "";

  GetTokenNameTrueFalse(args,szFileName,bngtrue,bngfalse);

	BOOL bResult = FALSE;
	WIN32_FILE_ATTRIBUTE_DATA ignored;

	try
	{
    /* Windows NT/2000/XP: In the ANSI version of this function, the   */ 
    /* name is limited to MAX_PATH characters. To extend this limit to */ 
    /* 32,767 wide characters, call the Unicode version of the         */ 
    /* function and prepend "\\?\" to the path.                        */ 
    /* Windows 98/Me: This string must not exceed MAX_PATH characters. */ 
    ASSERT(lstrlen(szFileName)<MAX_PATH);

	  bResult = GetFileAttributesEx(szFileName,GetFileExInfoStandard,&ignored);
	}
	catch(...)
	{
		;
	}

  CallBangIf(bResult,caller,bngtrue,bngfalse);
}

/****************************************************************
 code: bangFileMove
 bang: !FILEMOVE "c:\oldpath\oldfile.txt" "d:\newpath\newfile.txt" "!bangifmoved" "!bangifnotmoved"
****************************************************************/

void bangFileMove(HWND caller, LPCSTR args)
{
	char szFileName[1024] = "", szNewFileName[1024] = "", bngtrue[1024] = "", bngfalse[1024] = "";

	GetToken(args, szFileName, &args, TRUE);
  GetTokenNameTrueFalse(args,szNewFileName,bngtrue,bngfalse);

	BOOL bResult = FALSE;
	try
	{
    /* Windows NT/2000/XP: In the ANSI version of this function, the   */ 
    /* name is limited to MAX_PATH characters. To extend this limit to */ 
    /* 32,767 wide characters, call the Unicode version of the         */ 
    /* function and prepend "\\?\" to the path.                        */ 
    /* Windows 98/Me: This string must not exceed MAX_PATH characters. */ 
    ASSERT(lstrlen(szFileName)<MAX_PATH);
    ASSERT(lstrlen(szNewFileName)<MAX_PATH);

	  bResult = MoveFile(szFileName,szNewFileName);
	}
	catch(...)
	{
		;
	}

  CallBangIf(bResult,caller,bngtrue,bngfalse);
}

/****************************************************************
 code: bangFileCopy
 bang: !FILECOPY "c:\oldpath\oldfile.txt" "d:\newpath\newfile.txt" "!bangifcopied" "!bangifnotcopied"
****************************************************************/

void bangFileCopy(HWND caller, LPCSTR args)
{
	char szFileName[1024] = "", szNewFileName[1024] = "", bngtrue[1024] = "", bngfalse[1024] = "";

	GetToken(args, szFileName, &args, TRUE);
  GetTokenNameTrueFalse(args,szNewFileName,bngtrue,bngfalse);

	BOOL bResult = FALSE;
	try
	{
    /* Windows NT/2000/XP: In the ANSI version of this function, the   */ 
    /* name is limited to MAX_PATH characters. To extend this limit to */ 
    /* 32,767 wide characters, call the Unicode version of the         */ 
    /* function and prepend "\\?\" to the path.                        */ 
    /* Windows 98/Me: This string must not exceed MAX_PATH characters. */ 
    ASSERT(lstrlen(szFileName)<MAX_PATH);
    ASSERT(lstrlen(szNewFileName)<MAX_PATH);

  	bResult = CopyFile(szFileName,szNewFileName,FALSE);
	}
	catch(...)
	{
		;
	}

  CallBangIf(bResult,caller,bngtrue,bngfalse);
}

/****************************************************************
 code: bangFileDelete
 bang: !FILEDELETE "c:\path\file.txt" "!bangifdeleted" "!bangifnotdeleted"
****************************************************************/

void bangFileDelete(HWND caller, LPCSTR args)
{
	char szFileName[1024] = "", bngtrue[1024] = "", bngfalse[1024] = "";

  GetTokenNameTrueFalse(args,szFileName,bngtrue,bngfalse);

	BOOL bResult = FALSE;
	try
	{
    /* Windows NT/2000/XP: In the ANSI version of this function, the   */ 
    /* name is limited to MAX_PATH characters. To extend this limit to */ 
    /* 32,767 wide characters, call the Unicode version of the         */ 
    /* function and prepend "\\?\" to the path.                        */ 
    /* Windows 98/Me: This string must not exceed MAX_PATH characters. */ 
    ASSERT(lstrlen(szFileName)<MAX_PATH);

  	bResult = DeleteFile(szFileName);
	}
	catch(...)
  {
    ;
  }

  CallBangIf(bResult,caller,bngtrue,bngfalse);
}
/****************************************************************
 code: bangDirExist
 bang: !DIREXIST "c:\path" "!bangiffound" "!bangifnotfound"
****************************************************************/

void bangDirExist(HWND caller, LPCSTR args)
{
	char szDirName[1024] = "", bngtrue[1024] = "", bngfalse[1024] = "";

  GetTokenNameTrueFalse(args,szDirName,bngtrue,bngfalse);

	BOOL bResult = FALSE;
	WIN32_FILE_ATTRIBUTE_DATA ignored;

	try
	{
    /* Windows NT/2000/XP: In the ANSI version of this function, the   */ 
    /* name is limited to MAX_PATH characters. To extend this limit to */ 
    /* 32,767 wide characters, call the Unicode version of the         */ 
    /* function and prepend "\\?\" to the path.                        */ 
    /* Windows 98/Me: This string must not exceed MAX_PATH characters. */ 
    ASSERT(lstrlen(szDirName)<MAX_PATH);

	  bResult = GetFileAttributesEx(szDirName,GetFileExInfoStandard,&ignored);
	}
	catch(...)
	{
		;
	}
	
  CallBangIf(bResult,caller,bngtrue,bngfalse);
}

/****************************************************************
 code: bangDirCreate
 bang: !DIRCREATE "c:\path" "!bangifcreated" "!bangifnotcreated"
****************************************************************/

void bangDirCreate(HWND caller, LPCSTR args)
{
	char szDirName[1024] = "", bngtrue[1024] = "", bngfalse[1024] = "";

  GetTokenNameTrueFalse(args,szDirName,bngtrue,bngfalse);

	BOOL bResult = FALSE;
	try
	{
    int DirNameLen = lstrlen(szDirName);

    /* remove ending \ if there is one */ 
    while (DirNameLen>1 && szDirName[DirNameLen-1]=='\\')
      szDirName[DirNameLen--] = 0;

    /* There is a default string size limit for paths of  */ 
    /* 248 characters. This limit is related to how the   */ 
    /* CreateDirectory function parses paths.             */ 
    /* Windows NT/2000/XP: To extend this limit to 32,767 */ 
    /* wide characters, call the Unicode version of the   */ 
    /* function and prepend "\\?\" to the path.           */ 
    ASSERT(DirNameLen<MAX_PATH);

    bResult = CreateDirectory(szDirName,NULL);
	}
	catch(...)
	{
		;
	}

  CallBangIf(bResult,caller,bngtrue,bngfalse);
}

/****************************************************************
This sourcecode is part of:
filemaster.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/
