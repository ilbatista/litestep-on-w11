/****************************************************************
This sourcecode is part of:
filemaster.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)

The program is provided "as is", without warranty of any kind,
express or implied, including but not limited to warranties of
merchantability, fitness for a particular purpose and
non-infringement. In no event shall I, the author and copyright
holder be liable, whether in action of contract, tort or otherwise,
arising from, out of or in connection with the program or the use
or other dealings in the software.

Mike Edward Moras
e-sushi@gmx.net

This sourcecode is part of:
filemaster.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/

#define WIN32_LEAN_AND_MEAN
#include "old\lsapi.h"
#include "AggressiveOptimize.h"

void bangFileExist(HWND caller, LPCSTR args);
void bangFileMove(HWND caller, LPCSTR args);
void bangFileCopy(HWND caller, LPCSTR args);
void bangFileDelete(HWND caller, LPCSTR args);

void bangDirExist(HWND caller, LPCSTR args);
void bangDirCreate(HWND caller, LPCSTR args);


HWND hWnd = NULL;
WIN32_FIND_DATA m_DataFind;
HANDLE m_hFind;

extern "C" {
    __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
    __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}


/**** support stuff [js] ****/ 

#ifndef LSTOOLS_REV
typedef struct _lsBangCmdDef {
	const char *Name;
	BangCommand *Command;
} lsBangCmdDef;

LSAPI void LSRegisterBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs);
LSAPI void LSRemoveBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs);
#endif

#ifndef ASSERT
#ifndef NDEBUG
#ifdef NOISY_ASSERT
#define ASSERT(n) if (!(n)) {char buf[MAX_LINE_LENGTH];\
sprintf(buf,"Assert failed at line %d of %s:\n  %s\nBreak to debug?",__LINE__,__FILE__,#n);\
if(MessageBox(NULL,buf,MODULE,MB_YESNO)==IDYES) DebugBreak();}
#else
#define ASSERT(n) if (!(n)) LSLogPrintf(LOG_ERROR,MODULE,"Assert failed at line %d of %s: %s",__LINE__,__FILE__,#n)
#endif
#else
#define ASSERT(n) (void)0
#endif
#endif

#ifndef WRITEABLE
#define WRITEABLE(ptr,len) (ptr!=NULL && !IsBadWritePtr(ptr,len))
#define READABLE(ptr,len) (ptr!=NULL && !IsBadReadPtr(ptr,len))
#define EXECABLE(ptr) (ptr!=NULL && !IsBadCodePtr(ptr))
#endif

/**** end support stuff [js] ****/ 

/****************************************************************
This sourcecode is part of:
filemaster.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/
