-----------------------
I. Viewing Information
-----------------------
To view this readme.txt in all its glory please change your display font to
either courier, or courier new. While other fixed-width fonts may render it
somewhat formatted correctly courier is the one it was written with.

II. About nexDeskIcon
-----------------------
nexDeskIcon is a module that allows users to place explorer icons on their
desktop. It supports explorer context menus, extended drag and drop, and a
few other toys. By extended drag and drop depending on if the control key
is pressed when file(s) are dragged to an icon they are copied. Otherwise
they are moved. nexDeskIcon uses some shell 4.71 features as such it requires
Internet Explorer 4 or higher. nexDeskIcon also uses the litestep logging
routines and it also requires a 02/13/2002 or newer litestep build.

-----------------------
III. Installation
-----------------------
Just copy nexDeskIcon.dll to your LiteStep modules directory and add the 
following line to your step.rc: 

	LoadModule	C:\LiteStep\nexDeskIcon.dll

Assuming C:\LiteStep is your LiteStep directory

-----------------------
IV. Settings
-----------------------
nexDeskIcon is configured much like any other module, and uses the following commands:

nexDeskIconTextColor		Sets:		The icon caption text color
				Default:	FFFFFF
				Required:	No
				Notes:		None
				Example:	nexDeskIconTextColor		FFFFFF
	
nexDeskIconShadowColor		Sets:		The icon caption text shadow color
				Default: 	000000
				Required:	No
				Notes:		None
				Example:	nexDeskIconShadowColor		000000

nexDeskIconBackgoundColor	Sets: 		The icon caption background color
				Default:	000000
				Required:	No
				Notes:		Ignored if nexDeskIconTransparent is 
						set to true
				Example:	nexDeskIconBackgoundColor	000000

nexDeskIconTransparent		Sets:		The icon caption background state
				Default:	True
				Required:	No
				Notes:		If this is set to true the background 
						color is ignored.
				Example:	nexDeskIconTransparent		True

nexDeskIconFontShadow		Sets:		The icon caption text shadow state
				Default:	True
				Required:	No
				Notes:		None
				Example:	nexDeskIconFontShadow		True

nexDeskIconFontBold		Sets:		The icon caption text weight
				Default:	False
				Required:	No
				Notes:		None
				Example:	nexDeskIconFontBold		False

nexDeskIconFontItalic		Sets:		The icon caption text shift state
				Default:	False
				Required:	No
				Notes:		None
				Example:	nexDeskIconFontItalic		False

nexDeskIconFontFace		Sets:		The icon caption font name
				Default:	Tahoma
				Required:	No
				Notes:		None
				Example:	nexDeskIconFontFace		Tahoma

nexDeskIconFontSize		Sets:		The icon caption font height in pixels
				Default:	8
				Required:	No
				Notes:		None
				Example:	nexDeskIconFontSize		8

-----------------------
V. Configuration Lines
-----------------------
nexDeskIcon uses configuration lines much like hotkey.dll, popup2.dll, and shortcut2.dll.
Depending on the icon type the configuration line should contain the following items.
The Type, Point, Update, Left position, and Top Position. The syntax is as follows:

*nexDeskIcon Type(*):Point(**):Update(***) Group Left Top

Where * is either "Drive", "Directory", "RecycleBin", or "Link". ** is the mount point. The Mount
Point should be either the drive letter followed by colon and backslash for Drive, or the
directory path minus final backslash for Directory, or the fully qualified file name for Link. 
Currently link does not support quoted links such as 'This is the link that never ends'. If the 
Type is RecycleBin the Point is ignored. *** is the update interval in milliseconds. If the Type
is Directory this is ignored. Below are some example nexDeskIcon configuration lines. nexDeskIcon
-requires- a group id for each line just like shortcut2.dll does. It does not support group flags.

*nexDeskIcon	Type(Drive):Point(C:\):Update(1000)	#1 100 100
*nexDeskIcon	Type(Directory):Point(C:\Windows)	#1  200 100
*nexDeskIcon	Type(RecycleBin):Update(1000)		#99  300 100
*nexDeskIcon	Type(Directory):Point($LiteStepDir$)	#99  400 100
*nexDeskIcon	Type(Link):Point(C:\LiteSTEP\LiteSTEP.lnk):Update(1000) #99  500 100

nexDeskIcon does support litestep variables such as $LiteStepDir$. nexDeskIcon also
supports negative cordinates.

-----------------------
VI. Bang Commands
-----------------------
nexDeskIcon currently supports !nexDeskIconGroupHide, !nexDeskIconGroupShow, and 
!nexDeskIconGroupToggle. All three of these bangs require a valid group id as a parameter. If a 
valid group id isn't specified nothing happens.

-----------------------
VII. Example Step.rc
-----------------------
nexDeskIconTextColor		FFFFFF
nexDeskIconShadowColor		000000
nexDeskIconBackgoundColor	000000
nexDeskIconTransparent		True
nexDeskIconFontShadow		True
nexDeskIconFontBold		False
nexDeskIconFontItalic		False
nexDeskIconFontFace		Tahoma
nexDeskIconFontSize		8

*nexDeskIcon	Type(Drive):Point(C:\):Update(1000)			#1	64	100
*nexDeskIcon	Type(Directory):Point($LiteStepDir$)			#1	192	100
*nexDeskIcon	Type(RecycleBin):Update(1000)				#1	-64	100
*nexDeskIcon	Type(Link):Point(C:\LiteSTEP\LiteSTEP.lnk):Update(1000) #1	500	100

-----------------------
VIII. Versions 
-----------------------
rel. 0.1.3
	- fixed a few bugs and introduced a few new ones:
		1: Bug) Icons flicker when repainting themselves.
		1: Fix) I'm working on a fix for this maybe converting over to WM_TIMER will
			do it but I'm not sure.
		2: Bug) Icons don't overlay themselves properly when repainting themselves.
		2: Fix) This also only happens when the state timer is accessed. Changing over
			to WM_TIMER should fix this.
		3: Bug) Shortcuts/Links (.lnk files) don't have context menus.
		3: Fix) I'm working on it honestly I have no idea why it doesn't work right
			if anyone has any ideas let me know.
rel. 0.1
	- initial release
	- no visible bugs ;-)

-----------------------
IX. Future Features
-----------------------
rel. 0.1.5/0.2
	- bug fixes (if/when bugs are found)
	- full context menu support
	- icon selection overlay: implimented but disabled - Win95 doesn't like it
	- window region usage: implimented but disabled - NT 4 doesn't like it
	- .rc position modification depending on settings: implimented but disabled
	  LiteStep doesn't like it when nexDeskIcon saves settings while a recycle
	  is going on. 
	- Nearly anything requested by the community ;)

-----------------------
X. Thanks
-----------------------
I'd like to thank Murphy for releasing the Delphi SDK, and NeXTer for updating it.
Borland for Delphi, and Microsoft for Visual Basic and the time it took to wipe it
from my mind. Finally I'd like to thank the LSDev crew, and the mod developers out
there for keeping the flow. 

-----------------------
XI. License
-----------------------
Copyright (c) 2002 Nexistenz

This software is provided 'as-is', without any express or implied warranty. In no
event will the authors be held liable for any damages arising from the use of this
software.

Permission is granted to anyone to use this software for any purpose, including
commercial applications, and to alter it and redistribute it freely, subject to the
following restrictions:

1. The origin of this software must not be misrepresented; you must not claim that
you wrote the original software. If you use this software in a product, an
acknowledgment in the product documentation would be appreciated but is not required.

2. Altered source versions must be plainly marked as such, and must not be 
misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.

--------------
XI. Contact me
--------------
Have a feature request, general question, report a bug, or want the source if I 
still have an up to date copy? Feel free to contact me at:

	nexistenz@alltel.net