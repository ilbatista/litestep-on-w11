mIRC Command (v1.0) by WhiteShadow (changty@muohio.edu) on 12-11-99
*******************************************************************

This is a small module that adds a single bang command !mirccommand
which sends a command to mIRC.

Installation:

	1. Copy mirc.dll into your litestep folder
	2. Add the line 

		LoadModule c:\litestep\mirc.dll

	   to your step.rc (with the appropriate drive letter and 
	   path)
	3. Make sure that you have DDE server enabled in mIRC.  It is
	   found in Options->General->Servers
	4. Add the line

		mIRCDDEName <service_name>

	   to your step.rc if you want to use a service name other
	   than mIRC (the default value if the mIRCDDEName is
	   omitted).


Usage:

	!mirccommand <mirc_command>

	   mIRC will execute whatever follows !mirccommand.

Examples:

	1. !mirccommand hi everybody!

		This will have you say "hi everybody!" in whatever
		channel is on top

	2. !mircommand /me waves

		This will have you do the /me action in whatever
		channel is on top

	3. !mirccommand /server irc.mindspring.com

		This will have you change servers to irc.mindspring.com


Anyway, you could then bind any mIRC command to a hotkey or a shortcut.

Feel free to send me comments or bugs.
WhiteShadow