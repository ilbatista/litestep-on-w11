/*

This is a part of the LiteStep Shell Source code.
  
Copyright (C) 1997-98 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
		
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
		  
*/

/****************************************************************************
01/04/01 - TrOgI (b0.71)
	Fixed .extract to work properly with dll's again (thanks to Michael Schwab-Trapp for the quich bug report)
	Changed separating character between normal and mouseover images from a colon to braces around the mouseover image
	Added mouseclick image to tiles
01/04/01 - TrOgI (b0.7)
	Removed the double click moving stuff (you can do this with bangs now)
	Cleaned up the sound playing code
01/02/01 - TrOgI
	Added mouseover image to tiles
12/24/00 - TrOgI
	Added ability to set each wharf as vertical/horizontal
	Added WharfNoMoveOnResChange setting
	Added ability to set a WharfCap image for each wharf
	Added ability to set default/default folder/folder images for each wharf
12/22/00 - TrOgI
	Fixed WharfAutoClose and WharfCloseOnSwitch
	Fixed !WharfShow to work again (thanks to warren for the bug report)
	Fixed !WharfMoveTo to accept negative values
	Added wharf groups and changed bang commands to accept groups
	Added ability to set each wharf as topmost and hidden on startup
12/18/00 - TrOgI
	More recoding.....wharfType class inherits wharfFolderType class........smaller dll size
12/15/00 - TrOgI (b0.6)
	Removed the SetDesktopArea stuff
	Added AddImage function to wharfTileType class
	Cleaned up image combining code in wharfTileType class
	Added option to not use transparency in a tile (put a + before the image but after the * if used)
	Added Execute function to wharfFolderType class and moved some code from wharfTileType Execute function
12/13/00 - TrOgI
	Fixed problems with default images being smaller than the wharf width and height
	Fixed problem with transparency in the folders (thanks to dmaestr0 for pointing this out)
	Images smaller than width/height will now be centered in the tile
12/10/00 - TrOgI (b0.5)
	Fixed autohide from closing when in a folder/subfolder
12/02/00 - TrOgI
	More recoding.......multiple subfolders are now possible
11/30/00 - TrOgI
	Fixed bang commands to support multiple wharves
11/29/00 - TrOgI
	Added wharfFolderType class and window procedure
	Added code to allow multiple wharfs
	Added code back in for wharf position in modules.ini for compatibility with old themes
	Wharf position set in step.rc takes presidence over modules.ini
	Fixed bug in !WharfMove and !WharfMoveTo that caused only diagonal movement (thanks to xnowfall for pointing this out)
11/10/00 - TrOgI
	Lots of recoding........smaller dll size
	Folder tiles now press like the main wharf tiles.
11/08/00 - TrOgI
	Added wharfHiddenType class
	Moved hidden window creation into wharfHiddenType class
11/06/00 - TrOgI
	Added wharfType class
	Moved wharf creation into wharfType class
	Added Tile Window Procedure
09/26/00 - TrOgI
	Moved wharf tile creation and execution into wharfTileType class
	Changed wharf shade/unshade to right click on wharfcap instead of left click
	Added width and height to WharfData structure so wharf modules know what size tile they are in.
09/23/00 - TrOgI
	Added WharfX and WharfY settings
	Wharf gets its position from step.rc now instead of modules.ini
09/18/00 - TrOgI
	Added bang commands !WharfToggle, !WharfMove, !WharfMoveTo
	Added WharfStartHidden setting
09/09/00 - TrOgI
	Added ability to set the tile size for each folder
09/08/00 - TrOgI
	Fixed the move on resolution change to work with WharfHorizontal
	Added ability to set the folder direction to the same as the wharf with WharfFolderWharfDirection setting
	Added bang commands !WharfShow and !WharfHide
09/06/00 - TrOgI
	Fixed the wharf autohide feature to work correctly in horizontal mode
	Added WharfTileWidth and WharfTileHeight settings to use for any size tiles
09/04/00 - TrOgI
	Added ability to set wharf horizontal with WharfHorizontal setting
	Changed some width and height variables to make different size tiles easier to code later
08/26/00 - Joachim Calvert (NeXTer)
  - Added the setting WharfAlwaysOnTop
08/25/00 - Charles Oliver Nutter (Headius)
	Rewrote the wharf types to be classes, subwharfType extends wharfType
	Moved painting code into wharf type classes
	Restructured paint handling to call class methods
	Fixed the immovable wharf bug
	Fixed (re-implemented) the right-click popup
07/21/00 - Bobby G. Vinyard (Message)
	Add LM_REGISTER/UNREGISTER message handler. (Using LSWinbase, hParent was 
    being set to the hwnd of the wharf and not LiteStep its self, therefore
    the LM_REGISTER msgs were being sent to the wharf, the wharf no fowards
    these msgs to LiteStep's main exe)
04/16/00 - Joachim Calvert (NeXTer)
	Fixed a bug where the wharf wouldn't hide properly when the following
	settings where used:
    AutoHideWharf
    WharfCloseOnSwitch
    ;WharfNoAnim  (swithed off)
	(Courtesy of Sergey Popov)
	The message handling was radically overhauled to prepare the code for
	a convertion to proper C++ style.
04/12/00 - Joachim Calvert (NeXTer)
	It moves itself on resolution changes.
04/06/00 - Joachim Calvert (NeXTer)
	Now notices changes in screen resolution.
01/17/00 - Charles Nutter (Headius)
	Fixes to remove dependency on the great winList array.
	Note: Not thread-safe yet.
11/16/98 - Bug*Killer added by Fahim
	Added facility for popup menu to open when right clicked on wharf
	Divided the title bar in two parts : drag the left one to move the
	bar, click on the right one to shade/unshade the bar. When the wharf
	bar is not shaded, a double click on the left part puts it in shaded
	mode & then moves it to a special position :
	ScreenWidth - "WharfDblClickXPosition",0. When the wharf bar is
	shaded, a double click on the left part unshades the bar, then docks
	it on the right, or on the left if the "WharfDblClickDockOnLeft"
	step.rc entry is specified.
11/15/98 - cael
	Added checks in SetWorkArea() to not change the work area if
	SetDesktopArea is true
11/03/98 - W. Konkel
	Added the better wharf movement as well as sound to !WharfTasks
11/02/98 - W. Konkel
	Added wharf open/close/min/max sounds (with the help/request
	of snowchyld)
11/01/98 - T. Engel
	Added back WharfTitleFont, WharfTitleFontSize, and a new
	option WharfTitleFontWeight
11/01/98 - W. Konkel
	Added better wharf movement (fixed a few small bugs)
	Made WharfCloseOnSwitch work much much better
10/31/98 - Cyberian
	Fixed crashing on recycle when WharfCloseOnSwitch is enabled
10/29/98 - Cyberian (Fahim Farook)
	Added WharfCloseOnSwitch to step.rc so that you can have the
	subwharf folders auto-close when focus is lost if you desire
	Added support for wharf hints
10/10/98 - W. Konkel
	Added snap-to-edge wharf and the ability to not include the
	default.bmp and 3dots.bmp in wharf layer.
10/09/98 - C. Boyda
	Made the trans titlebar much more efficent in speed
10/03/98 - J. Vaughn
	Added fully functional, working transparency to the wharf
	titlebar (why was it left out to begin with?? :P)
09/03/98 - C. Boyda
	Added fully functional, working transparency to the wharf
	D. Hodgkiss
	Folders support is now in
08/31/98 - D. Hodgkiss
	Added ability to move the wharf anywhere on the screen
	Added a titlebar to the wharf
	Added hide/unhide support
08/25/98 - D. Hodgkiss
	This file contains the source for the wharf bar

****************************************************************************/

#include <windows.h>
#include <mmsystem.h>
#include <malloc.h>
#include <stdio.h>
#include <tchar.h>
#include <commctrl.h>
#include "../lsapi/lswinbase.h"
#include "../lsapi/lsapi.h"
#include "wharf.h"
#include "../core/ifcs.h"

// -------------------------------------------------------------------------------------------------------

const LPCTSTR   szMainWindowClass = _T("TWharfGlobalContainer");
const LPCTSTR   szHiddenWindowClass = _T("LineDownSide");
const LPCTSTR   szTileWindowClass = _T("TileContainer");
const LPCTSTR   szFolderWindowClass = _T("FolderContainer");
const char rcsRevision[] = "$Revision: 0.71 $"; // Our Version
const char rcsId[] = "$Id: wharfx.cpp,v 0.71 2001/01/04 TrOgI Exp $"; // The Full RCS ID.

FARPROC (__stdcall *SwitchToThisWindow)(HWND, int);

// our window procedures
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK HiddenWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK TileWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK FolderWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// -------------------------------------------------------------------------------------------------------

void CreateWharfs();
void DestroyWharfs();
void GetWharfData(wharfDataType *wd, int width, int height);
void ShowWharf(HWND sender, LPCSTR args);
void HideWharf(HWND sender, LPCSTR args);
void ToggleWharf(HWND sender, LPCSTR args);
void MoveWharf(HWND sender, LPCSTR args);
void MoveWharfTo(HWND sender, LPCSTR args);
void CreateWharfhints(HWND hWnd, char *txt, RECT *r);
void RemoveWharfhints(HWND hWnd);
void WharfSound(LPCSTR sound);

char wharfOpenSound[256];
char wharfCloseSound[256];
char wharfMinSound[256];
char wharfMaxSound[256];

HINSTANCE dll;
HWND hParent;
HWND wharfHints = NULL;
int ScreenWidth, ScreenHeight;
WharfVector MainWharf;
int numMainWharfs = 0;
int wharfAnimTime;
int wharfStep = 64;
int autoHideDelay = 300;
int autoShowDelay = 300;
int hiddenWidth = 1;
//int OpenFolders = 0;
int wharfPressOffset = 1;
BOOL wharfNoAnim = FALSE;
BOOL wharfAutoClose = TRUE;
BOOL wharfTitles = FALSE;
BOOL wharfCloseOnSwitch = FALSE;
BOOL snapTo = FALSE;
BOOL wharfAutoHide = FALSE;
//BOOL wharfAutoUnpress = FALSE;
BOOL wharfNoHints = TRUE;
BOOL wharfNoResMove = FALSE;
int snapToSensitivity = 16;
int bevelWidth;
COLORREF titleFore, titleBack;
char szTitleFont[256] = "Arial";
int iTitleFontSize = 8, iTitleFontWeight = 400;

// -------------------------------------------------------------------------------------------------------
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	dll = dllInst;

	AddBangCommand("!WharfShow", ShowWharf);
	AddBangCommand("!WharfHide", HideWharf);
	AddBangCommand("!WharfToggle", ToggleWharf);
	AddBangCommand("!WharfMove", MoveWharf);
	AddBangCommand("!WharfMoveTo", MoveWharfTo);

	hParent = GetLitestepWnd();

	if(!wharfNoHints)
	{
		wharfHints = CreateWindow
			(TOOLTIPS_CLASS,
			"LSWharfHints",
			TTS_ALWAYSTIP,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			NULL,
			(HMENU) NULL,
			dll,
			NULL
			);

		if(!wharfHints)
		{
			MessageBox(hParent, "Error creating hints window", "Wharf Hints Error", MB_OK | MB_TOPMOST);
			return 1;
		}
		SetWindowPos(wharfHints, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
	}
	
	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = MainWndProc;				  // our window procedure
		wc.hInstance = dllInst; 				// hInstance of DLL
		wc.cbWndExtra = 8;
		wc.lpszClassName = szMainWindowClass;	   // our window class name
		wc.style = CS_DBLCLKS;

		if(!RegisterClass(&wc)) 
		{
			MessageBox(hParent,"Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
			return 1;
		}
		
		if(wharfAutoHide)
		{
			WNDCLASS wc;
			memset(&wc,0,sizeof(wc));
			wc.lpfnWndProc = HiddenWndProc;				  // our window procedure
			wc.hInstance = dllInst; 				// hInstance of DLL
			wc.cbWndExtra = 8;
			wc.lpszClassName = szHiddenWindowClass;	   // our window class name
			wc.style = 0;
			
			if(!RegisterClass(&wc)) 
			{
				MessageBox(hParent,"Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
				return 1;
			}
		}	
	}

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = TileWndProc;				  // our window procedure
		wc.hInstance = dllInst; 				// hInstance of DLL
		wc.cbWndExtra = 8;
		wc.lpszClassName = szTileWindowClass;	   // our window class name
		wc.style = CS_DBLCLKS;

		if(!RegisterClass(&wc)) 
		{
			MessageBox(hParent,"Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
			return 1;
		}	
	}

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = FolderWndProc;				  // our window procedure
		wc.hInstance = dllInst; 				// hInstance of DLL
		wc.cbWndExtra = 8;
		wc.lpszClassName = szFolderWindowClass;	   // our window class name
		wc.style = CS_DBLCLKS;

		if(!RegisterClass(&wc)) 
		{
			MessageBox(hParent,"Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
			return 1;
		}	
	}

	CreateWharfs();
	return 0;
}


// -------------------------------------------------------------------------------------------------------

void OnEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void OnSysCommand(HWND hWnd, Message& message)
{
	if(message.wParam == SC_CLOSE)
		PostMessage(hParent,WM_KEYDOWN,LM_SHUTDOWN,0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

LRESULT CALLBACK HiddenWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;
	wharfHiddenType *pHidden = (wharfHiddenType *)GetWindowLong(hWnd, 4);

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch(uMsg)
	{
    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
		OnEndSession(message);
		break;
    case WM_SYSCOMMAND:
		OnSysCommand(hWnd, message);
		break;
    case WM_PAINT:
		pHidden->OnPaint(message);
		break;
    case WM_TIMER:
		pHidden->OnTimer(message);
		break;
    default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}

void MainWnd_GetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch(message.wParam)
	{
    case 0:
		strcpy(buf, "wharfx.dll: ");
		strcat(buf, &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
    case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
    default:
		strcpy(buf, "");
	}
}

void MainWnd_Recycle(Message& message)
{
	SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void MainWnd_NCRButtonDown(HWND hWnd, Message& message)
{
	SendMessage(hWnd, LM_SHADETOGGLE, 0, 0);
}

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;
	wharfType *pWharf = (wharfType *)GetWindowLong(hWnd, 4);

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch(uMsg)
	{
    case LM_GETREVID:
		MainWnd_GetRevId(message);
		break;
    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
		OnEndSession(message);
		break;
    case WM_SYSCOMMAND:
		OnSysCommand(hWnd, message);
		break;
    case LM_RECYCLE:
		MainWnd_Recycle(message);
		break;
    case LM_SHADETOGGLE:
		pWharf->OnShadeToggle(message);
		break;
    case WM_TIMER:
		pWharf->OnTimer(message);
		break;
    case WM_NCRBUTTONDOWN:
		MainWnd_NCRButtonDown(hWnd, message);
		break;
	case WM_NCLBUTTONDOWN:
		pWharf->OnNCLButtonDown(message);
		break;
    case WM_WINDOWPOSCHANGING:
		pWharf->OnPosChanging(message);
		break;
    case WM_NCHITTEST:
		pWharf->OnNCHitTest(message);
		break;
    case WM_CREATE:
		break;
    case WM_ERASEBKGND:
		break;
    case WM_DISPLAYCHANGE:
		pWharf->OnDisplayChange(message);
		break;
    case WM_PAINT:
		pWharf->OnPaint(message);
		break;
    case WM_ACTIVATE:
		pWharf->OnActivate(message);
		break;
	case WHARF_CLOSEFOLDERS:
		pWharf->CloseAllFolders();
		break;
	case WHARF_PARTOF:
		if(!pWharf->PartOfWharf((HWND)(message.lParam)))
			pWharf->CloseAllFolders();
		break;
    case LM_REGISTERMESSAGE:
    case LM_UNREGISTERMESSAGE:
		SendMessage(GetLitestepWnd(), uMsg, wParam, lParam);
		break;
    default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}

LRESULT CALLBACK TileWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;
	wharfTileType *pTile = (wharfTileType *)GetWindowLong(hWnd, 4);

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch(uMsg)
	{
    case WM_TIMER:
		pTile->OnTimer(message);
		break;
    case WM_CREATE:
		break;
    case WM_ERASEBKGND:
		break;
    case WM_PAINT:
		pTile->OnPaint(message);
		break;
    case WM_LBUTTONDOWN:
		pTile->OnLButtonDown(message);
		break;
    case WM_LBUTTONUP:
		pTile->OnLButtonUp(message);
		break;
    case WM_MOUSEMOVE:
		pTile->OnMouseMove(message);
		break;
	case WM_RBUTTONDOWN:
		SendMessage(GetLitestepWnd(), LM_POPUP, 0, 0);
		break;
	case WM_ACTIVATE:
		pTile->OnActivate(message);
		break;
	case WHARF_CLOSEFOLDERS:
		SendMessage(pTile->parentWnd, WHARF_CLOSEFOLDERS, 0, 0);
		break;
	case WHARF_PARTOF:
		SendMessage(pTile->parentWnd, WHARF_PARTOF, 0, message.lParam);
		break;
    default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}

LRESULT CALLBACK FolderWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;
	wharfFolderType *pFolder = (wharfFolderType *)GetWindowLong(hWnd, 4);

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch(uMsg)
	{
    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
		OnEndSession(message);
		break;
    case WM_SYSCOMMAND:
		OnSysCommand(hWnd, message);
		break;
    //case WM_TIMER:
	//	pFolder->OnTimer(message);
	//	break;
    case WM_CREATE:
		break;
    case WM_ERASEBKGND:
		break;
	case WM_ACTIVATE:
		pFolder->OnActivate(message);
		break;
	case WHARF_CLOSEFOLDERS:
		pFolder->CloseAllFolders();
		if(!wParam)
			SendMessage(pFolder->parentTileWnd, WHARF_CLOSEFOLDERS, 0, 0);
		break;
	case WHARF_PARTOF:
		SendMessage(pFolder->parentTileWnd, WHARF_PARTOF, 0, message.lParam);
		break;
    case LM_REGISTERMESSAGE:
    case LM_UNREGISTERMESSAGE:
		SendMessage(GetLitestepWnd(), uMsg, wParam, lParam);
		break;
    default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}

void ShowWharf(HWND sender, LPCSTR args)
{
	if(!strcmpi("", args))
	{
		MainWharf[0]->Show();
		return;
	}

	for(int i = 0; i <= numMainWharfs; i++)
	{
		if(!strcmpi("ALL", args) || (MainWharf[i]->group == args[0]))
			MainWharf[i]->Show();
	}
}

void HideWharf(HWND sender, LPCSTR args)
{
	if(!strcmpi("", args))
	{
		MainWharf[0]->Hide();
		return;
	}

	for(int i = 0; i <= numMainWharfs; i++)
	{
		if(!strcmpi("ALL", args) || (MainWharf[i]->group == args[0]))
			MainWharf[i]->Hide();
	}
}

void ToggleWharf(HWND sender, LPCSTR args)
{
	if(!strcmpi("", args))
	{
		if(!MainWharf[0]->visible)
			MainWharf[0]->Show();
		else
			MainWharf[0]->Hide();
		return;
	}

	for(int i = 0; i <= numMainWharfs; i++)
	{
		if(!strcmpi("ALL", args) || (MainWharf[i]->group == args[0]))
		{
			if(!MainWharf[i]->visible)
				MainWharf[i]->Show();
			else
				MainWharf[i]->Hide();
		}
	}
}

void WharfMove(BOOL moveTo, LPCSTR args)
{
	char *buf, *val1, *val2, *val3;

	buf = (char *)malloc(strlen(args)+1);
	strcpy(buf, args);
	val1 = strtok(buf, " \t");
	val2 = strtok(NULL, " \t");
	val3 = strtok(NULL, "");

	if(!val3)
	{
		MainWharf[0]->Move(val1, val2, moveTo);
		return;
	}

	for(int i = 0; i <= numMainWharfs; i++)
	{
		if(!strcmpi("ALL", val3) || (MainWharf[i]->group ==  val3[0]))
			MainWharf[i]->Move(val1, val2, moveTo);
	}

	free(buf);
}

void MoveWharf(HWND sender, LPCSTR args)
{
	WharfMove(FALSE, args);
}

void MoveWharfTo(HWND sender, LPCSTR args)
{
	WharfMove(TRUE, args);
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!WharfShow");
	RemoveBangCommand("!WharfHide");
	RemoveBangCommand("!WharfToggle");
	RemoveBangCommand("!WharfMove");
	RemoveBangCommand("!WharfMoveTo");

	DestroyWharfs();

	UnregisterClass(szTileWindowClass,dllInst); // unregister window class
	UnregisterClass(szMainWindowClass,dllInst); // unregister window class
	UnregisterClass(szFolderWindowClass,dllInst); // unregister window class
	if(wharfAutoHide)
		UnregisterClass(szHiddenWindowClass, dllInst);
}

void GetWharfData(wharfDataType *wd, int width, int height)
{
	char szImagePath[256], lsPath[256], szDefPixmap[256];

	LSGetImagePath(szImagePath, 256);
	GetRCString("DefaultBackPix", szDefPixmap, "", 256);

	LSGetLitestepPath(lsPath, 256);
	if(lsPath[strlen(lsPath)] != '\\')
		strcat(lsPath, "\\");
	
	wd->trayIconSize = GetRCInt("TrayIconSize", 16);
	wd->taskBarFore = GetRCColor("LSTaskBarFore", 0x000000);
	wd->taskBarBack = GetRCColor("LSTaskBarBack", 0x7f7f7f);
	wd->taskBarText = GetRCColor("LSTaskBarText", 0xffffff);
	wd->taskBarFore2 = GetRCColor("LSTaskBarFore2", 0x3f3f3f3f);
	wd->taskBar = GetRCBool("NoTaskBar", FALSE);
	wd->showBeta = GetRCBool("NoShowBeta", TRUE);;
	wd->usClock = GetRCBool("UsClock", TRUE);
	wd->vwmVelocity = GetRCInt("VWMVelocity", 300);
	wd->VWMDistance = GetRCInt("VWMSecurityDistance", 5);
	wd->VWMNoAuto = GetRCBool("VWMNoAuto", TRUE);
	wd->pixmapDir = szImagePath;
	wd->defaultBmp = szDefPixmap;
	wd->vwmBackColor = GetRCColor("VWMBackColor", 0x000000);
	wd->vwmSelBackColor = GetRCColor("VWMSelBackColor", 0x3f3f3f);
	wd->vwmForeColor = GetRCColor("VWMForeColor", 0x906090);
	wd->vwmBorderColor = GetRCColor("VWMBorderColor", 0xffffff);
	wd->lsPath = lsPath;
	wd->borderSize = bevelWidth;
	wd->width = width;
	wd->height = height;
}

void WharfSound(LPCSTR sound)
{
	sndPlaySound(sound, SND_ASYNC|SND_NODEFAULT);
}

/*
void ExecuteWharfTasks(wharfTileType *tile)
{
	IWindowList *windowList;
	char capt[256];
	int xPos, yPos;
		
	{
		if(tile->folder->wharfs.size())
		{
			for(int x = 0; x < tile->folder->numWharfs; x++)
			{
				DeleteObject(tile->folder->wharfs[x]->backImage);
				DeleteObject(tile->folder->wharfs[x]->frontImage);
				DestroyWindow(tile->folder->wharfs[x]->hWnd);
				delete tile->folder->wharfs[x];
			}
			DestroyWindow(tile->folder->hMainWnd);
			tile->folder->wharfs.clear();
		}

		if(tile->folder->direction == WHARF_RIGHT)
		{
			tile->folder->width = 0;
			tile->folder->height = tile->height;
		}
		else if(tile->folder->direction == WHARF_DOWN)
		{
			tile->folder->width = tile->width;
			tile->folder->height = 0;
		}
		
		tile->folder->numWharfs = 0;
		tile->folder->open = FALSE;
		tile->folder->hMainWnd = CreateWindowEx(
			WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
			szFolderWindowClass,
			"LSWharflet",
			WS_CLIPCHILDREN | WS_POPUP,
			0, 0,
			0, 0,
			hParent,
			NULL,
			dll,
			NULL
			);
		
		SetWindowLong(tile->folder->hMainWnd, GWL_USERDATA, magicDWord);
		SetWindowLong(tile->folder->hMainWnd, 4, (LONG)tile->folder);
		ShowWindow(tile->folder->hMainWnd, SW_SHOWNORMAL);
		
		windowList = (IWindowList *)SendMessage(hParent, LM_WINDOWLIST, 0, 0);
		long count;

		windowList->GetWindowCount(&count);

		for(int n = 0; n < count; n++)
		{
			HICON hIcon = NULL;
			HWND hParent, window;

			windowList->GetWindow(n, (OLE_HANDLE*)&window);

			if(GetWindowLong(window, GWL_USERDATA) == magicDWord) continue;
			if(GetWindowLong(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) continue;
			hParent = GetParent(window);
			if(GetWindowLong(hParent, GWL_USERDATA) == magicDWord) continue;
		
			if(tile->folder->direction == WHARF_RIGHT)
			{
				xPos = tile->folder->width;
				yPos = 0;
				tile->folder->width += tile->width;
			}
			else if(tile->folder->direction == WHARF_DOWN)
			{
				xPos = 0;
				tile->folder->height;
				tile->folder->height += tile->height;
			}

			capt[0] = 0;
			if(window != NULL)
			{
				GetWindowText(window, (char *)&capt, sizeof(capt));
				//strcpy(wharfs[i]->folder->wharfs[x]->szName, capt);
			}

			tile->folder->wharfs.push_back(new wharfTileType(tile->folder->hMainWnd, tile->folder->hMainRgn, capt, "!task", NULL, NULL, NULL, FALSE, tile->width, tile->height, xPos, yPos, tile->folder->direction, FALSE));

			tile->folder->wharfs[tile->folder->numWharfs]->taskWnd = window;
			SendMessageTimeout(window, WM_GETICON, 1, 0, 0, 250, (unsigned long *)&hIcon);
			if(!hIcon) SendMessageTimeout(window, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long *)&hIcon);
			if(!hIcon) hIcon = (HICON)GetClassLong(window, GCL_HICON);
			if(!hIcon) hIcon = (HICON)GetClassLong(window, GCL_HICONSM);
			if(hIcon) /* not working for some reason *//*
			{
				HBITMAP oldBMP;
				HDC dst = CreateCompatibleDC(NULL);
				HDC tempDC = GetDC(tile->folder->hMainWnd);
				HBRUSH hb = CreateSolidBrush(RGB(255,0,255));
				HBRUSH hb2 = CreateSolidBrush(RGB(0, 0, 128));
				RECT r;
				int nHeight;
				
				tile->folder->wharfs[tile->folder->numWharfs]->frontImage = CreateCompatibleBitmap(tempDC, tile->folder->wharfs[tile->folder->numWharfs]->width, tile->folder->wharfs[tile->folder->numWharfs]->height);
				oldBMP = (HBITMAP)SelectObject(dst, tile->folder->wharfs[tile->folder->numWharfs]->frontImage);
				r.left = 0;
				r.top = 0;
				r.right = tile->folder->wharfs[tile->folder->numWharfs]->width;
				r.bottom = tile->folder->wharfs[tile->folder->numWharfs]->height;
				FillRect(dst, &r, hb);
				//				r.bottom = 10;
				nHeight = MulDiv(iTitleFontSize, GetDeviceCaps(dst, LOGPIXELSY), 72);
				r.bottom = nHeight +2;
				r.right = tile->folder->wharfs[tile->folder->numWharfs]->width;
				FillRect(dst, &r, hb2);
				DrawIconEx(dst, 16, 16, hIcon, 32, 32, 0, NULL, DI_NORMAL);
				ReleaseDC(tile->folder->hMainWnd, tempDC);
				SelectObject(dst, oldBMP);
				DeleteDC(dst);
				DeleteObject(hb);
				DeleteObject(hb2);
				DeleteObject(hIcon);
			}

			tile->folder->wharfs[tile->folder->numWharfs]->Create(NULL, capt, TRUE);
			tile->folder->numWharfs++;
		}
        
		SetWindowRgn(tile->folder->hMainWnd, tile->folder->hMainRgn, TRUE);
	}
}
*/
void CreateWharfhints(HWND hWnd, char *txt, RECT *r)
{
	TOOLINFO ti;    // tool information
	
	if(wharfNoHints)
		return;

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = txt;
	ti.rect = *r;
	
	SendMessage(wharfHints, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

void RemoveWharfhints(HWND hWnd)
{
	TOOLINFO ti;    // tool information
	RECT r={0,0,0,0};
	
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = NULL;
	ti.rect = r;
	
	SendMessage(wharfHints, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

void CreateWharfs()
{
	char szToken[256], szDefPixmap[256], szFolderPixmap[256], lsPath[256];
	FILE *f;
	UINT Msgs[2];
	HWND desktopWnd;
	char szBuf[256], *tmp, szCapImage[256], szDefaultImage[256], szDefaultFolderImage[256], szFolderImage[256];
	int wharfBaseX = 0, wharfBaseY = 0;
	int wharfWidth = 0, wharfHeight = 0;
	int wharfTileWidth, wharfTileHeight;
	BOOL wharfStartHidden = FALSE;
	BOOL wharfAlwaysOnTop = TRUE;
	int wharfDirection = WHARF_DOWN;
	int wharfFolderDirection = WHARF_RIGHT;

	LSGetLitestepPath(lsPath, 256);
	if(lsPath[strlen(lsPath)] != '\\')
		strcat(lsPath, "\\");

	wharfNoResMove = GetRCBool("WharfNoMoveOnResChange", TRUE);
	//wharfAutoUnpress = GetRCBool("WharfAutoUnpress", TRUE);
	wharfAutoClose = GetRCBool("WharfNoAutoClose", FALSE);
	wharfNoAnim = GetRCBool("WharfNoAnim", TRUE);
	wharfTitles = GetRCBool("WharfAllTitles", TRUE);
	titleFore = GetRCColor("WharfTitleFore", 0xFFFFFF);
	titleBack = GetRCColor("WharfTitleBack", 0x802020);
	bevelWidth = GetRCInt("WharfBevelWidth", 1);
	if(bevelWidth < 0) bevelWidth = 0;
	wharfStep = GetRCInt("WharfAnimStep", 64);
	wharfAnimTime = GetRCInt("WharfAnimDelay", 10); 
	wharfAutoHide = GetRCBool("AutoHideWharf", TRUE);
	autoHideDelay = GetRCInt("AutoHideDelay", 300);
	autoShowDelay = GetRCInt("AutoShowDelay", autoHideDelay);
	hiddenWidth = GetRCInt("WharfHiddenWidth", 1);
	wharfPressOffset = GetRCInt("WharfPressOffset", 1);
	wharfNoHints = GetRCBool("WharfNoHints", TRUE);
	wharfCloseOnSwitch = GetRCBool("WharfCloseOnSwitch", TRUE);
	GetRCString("WharfOpenSound", wharfOpenSound, "", 256);
	GetRCString("WharfCloseSound", wharfCloseSound, "", 256);
	GetRCString("WharfMinSound", wharfMinSound, "", 256);
	GetRCString("WharfMaxSound", wharfMaxSound, "", 256);
	snapTo = GetRCBool("SnapToWharf", TRUE);
	snapToSensitivity = GetRCInt("SnapToSensitivity", 16);

	GetRCString("WharfTitleFont", szTitleFont, "Arial", 256);
	iTitleFontSize = GetRCInt("WharfTitleFontSize", 8);
	iTitleFontWeight = GetRCInt("WharfTitleFontWeight", 400);

	ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
	ScreenHeight = GetSystemMetrics(SM_CYSCREEN);

	SwitchToThisWindow = (FARPROC (__stdcall *)(HWND, int))GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");
	
	f = LCOpen(NULL);
	if(f)
	{
		desktopWnd = FindWindow("DesktopBackgroundClass", NULL);
		if(!desktopWnd)
			desktopWnd = GetDesktopWindow();
		sprintf(szBuf, "%sMODULES.INI", lsPath);
		GetPrivateProfileString("Wharf", "Position", "0,0", (char *)&szBuf, sizeof(szBuf), szBuf);
		tmp = strtok(szBuf, ",");
		wharfBaseX = atoi(tmp);
		tmp = strtok(NULL, "");
		wharfBaseY = atoi(tmp);
		wharfTileWidth = GetRCInt("WharfTileWidth", 64);
		wharfTileHeight = GetRCInt("WharfTileHeight", 64);
		wharfBaseX = GetRCInt("WharfX", wharfBaseX);
		wharfBaseY = GetRCInt("WharfY", wharfBaseY);
		if(wharfBaseX < 0)
			wharfBaseX += ScreenWidth;
		if(wharfBaseY < 0)
			wharfBaseY += ScreenHeight;
		wharfStartHidden = GetRCBool("WharfStartHidden", TRUE);
		wharfAlwaysOnTop = GetRCBool("WharfNotAlwaysOnTop", FALSE);
		if(GetRCBool("WharfHorizontal", TRUE))
		{
			wharfDirection = WHARF_RIGHT;
			wharfFolderDirection = WHARF_DOWN;
		}
		if(GetRCBool("WharfFolderWharfDirection", TRUE))
			wharfFolderDirection = wharfDirection;
		GetRCString("WharfTitlebarPix", szCapImage, "", 256);
		GetRCString("DefaultBackPix", szDefaultImage, "", 256);
		GetRCString("FolderBackPix", szDefaultFolderImage, "", 256);
		GetRCString("FolderPix", szFolderImage, "", 256);

		MainWharf.push_back(new wharfType(NULL, '0', wharfBaseX, wharfBaseY, wharfDirection, !wharfStartHidden, szCapImage));
		MainWharf[numMainWharfs]->Create(f, desktopWnd, wharfTileWidth, wharfTileHeight, wharfAlwaysOnTop, wharfFolderDirection, szDefaultImage, szDefaultFolderImage, szFolderImage);

		Msgs[0] = LM_GETREVID;
		Msgs[1] = 0;
		SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM) MainWharf[0]->hMainWnd, (LPARAM) Msgs);

		LCClose(f);
	}
}

void DestroyWharfs()
{
	UINT Msgs[2];

	Msgs[0] = LM_GETREVID;
	Msgs[1] = 0;
	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM) MainWharf[0]->hMainWnd, (LPARAM) Msgs);

	if(!wharfNoHints)
	{
		if(wharfHints)
		{
			DestroyWindow(wharfHints);
			wharfHints = NULL;
		}
	}
	for(int i = 0; i <= numMainWharfs; i++)
	{
		delete MainWharf[i];
	}
	MainWharf.clear();
}

wharfFolderType::wharfFolderType()
{
	hMainWnd = NULL;
	parentTileWnd = NULL;
	width = 0;
	height = 0;
	hMainRgn = NULL;
	numWharfs = 0;
	direction = 0;
	open = FALSE;
	moving = FALSE;
	closing = FALSE;
	isFirst = FALSE;
	movingPos = 0;
}

wharfFolderType::wharfFolderType(HWND tileWnd, int Direction)
{
	hMainWnd = NULL;
	parentTileWnd = tileWnd;
	width = 0;
	height = 0;
	hMainRgn = CreateRectRgn(0, 0, width, height);
	numWharfs = 0;
	direction = Direction;
	open = FALSE;
	moving = FALSE;
	closing = FALSE;
	isFirst = FALSE;
	movingPos = 0;
}

wharfFolderType::~wharfFolderType()
{
	for(int x = 0; x < numWharfs; x++)
	{
		delete wharfs[x];
	}
	wharfs.clear();

	if(hMainWnd)
		DestroyWindow(hMainWnd);
	if(hMainRgn)
		DeleteObject(hMainRgn);
}

BOOL wharfFolderType::Create(FILE *file, int tileWidth, int tileHeight, BOOL topmost, int FolderDirection, LPCSTR szDefaultFolderImage, LPCSTR szFolderImage)
{
	HWND tempWnd;

	tempWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW | (topmost ? WS_EX_TOPMOST : 0),
		szFolderWindowClass,
		"LSWharflet",
		WS_CLIPCHILDREN | WS_POPUP,
		0, 0,
		0, 0,
		hParent,
		NULL,
		dll,
		NULL
		);

	if(!tempWnd)
	{
		MessageBox(hParent, "Error creating wharf", "Wharf", MB_OK | MB_TOPMOST);
		return 1;
	}
	hMainWnd = tempWnd;

	if(direction == WHARF_RIGHT)
	{
		width = 0;
		height = tileHeight;
	}
	else if(direction == WHARF_DOWN)
	{
		width = tileWidth;
		height = 0;
	}
								
	SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(hMainWnd, 4, (LONG)this);

	if(file)
		ParseData(file, NULL, tileWidth, tileHeight, topmost, FolderDirection, NULL, szDefaultFolderImage, szFolderImage);

	ShowWindow(hMainWnd, SW_SHOWNORMAL);

	return 0;
}

void wharfFolderType::ParseData(FILE *file, HWND parentWnd, int tileWidth, int tileHeight, BOOL topmost, int FolderDirection, LPCSTR szDefaultImage, LPCSTR szDefaultFolderImage, LPCSTR szFolderImage)
{
	char buffer[255];
	char token1[255], token2[255], token3[255], token4[255], token5[255], token6[255], token7[255], token8[255], extra_text[255];
	char *tokens[8];

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	tokens[5] = token6;
	tokens[6] = token7;
	tokens[7] = token8;
	buffer[0] = 0;

	while(LCReadNextConfig(file, "*Wharf", buffer, sizeof(buffer)))
	{
		int count;

		token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = token7[0] = token8[0] = extra_text[0] = '\0';
				
		count = LCTokenize(buffer, tokens, 8, extra_text);

		switch(count)
		{
		case 2:
			if(!strcmpi(token2, "~Folder"))
			{
				if(hMainWnd)
				{
					SetWindowRgn(hMainWnd, hMainRgn, TRUE);
					hMainRgn = NULL;
				}
				return;
			}
		case 4:
		case 5:
			{
				// token 1 is "*Wharf", token 2 is the name, token 3 is the
				// graphic, token 4 is the executable, and token 5 is
				// the program arguments.
				char windowName[256];
				BOOL showBack = TRUE, noTrans = FALSE;
				char szTT[1024];
				int xPos, yPos;
						
				windowName[0] = '\0';

				if((token4[0] == '%') && (strrchr(token4, '%') == token4))
				{
					char szTempToken[4096];
					char *tokens2[6];
					tokens2[0] = token1;
					tokens2[1] = token2;
					tokens2[2] = token3;
					tokens2[3] = szTempToken;
					tokens2[4] = token4;
					tokens2[5] = token5;

					strcpy(windowName, token4 + 1);

					extra_text[0] = token4[0] = '\0';
				}
				else
					strcpy(windowName, token2);

				if(token3[0] == '*')
				{
					char *temptoken3;
					temptoken3 = token3;
					if(*temptoken3 == '*')
						temptoken3++;
					strcpy(token3,temptoken3);
					showBack = FALSE;
				}
				if(token3[0] == '+')
				{
					char *temptoken3;
					temptoken3 = token3;
					if(*temptoken3 == '+')
						temptoken3++;
					strcpy(token3,temptoken3);
					noTrans = TRUE;
				}

				if(direction == WHARF_RIGHT)
				{
					xPos = width;
					yPos = 0;
					width += tileWidth;
				}
				else if(direction == WHARF_DOWN)
				{
					xPos = 0;
					yPos = height;
					height += tileHeight;
				}

				if(!strcmpi(token4, "Folder"))
				{
					strcpy(szTT, token2);
				}
				else
				{
					strcpy(szTT, token4);
					if(strnicmp(".extract", token3, 8) && token5 && strlen(token5))
					{
						strcat (szTT, " ");
						strcat (szTT, token5);
					}
				}		
				wharfs.push_back(new wharfTileType(hMainWnd, hMainRgn, token2, token4, token5, noTrans, tileWidth, tileHeight, xPos, yPos, direction));
				wharfs[numWharfs]->Create(file, windowName, token3, szTT, showBack, topmost, FolderDirection, szDefaultImage, szDefaultFolderImage, szFolderImage);
				numWharfs++;
			}
			break;
		case 8:
			{
				if(!strcmpi(token2, "!New"))
				{
					char Group = '0';
					BOOL Visible = TRUE;
					BOOL Topmost = TRUE;
					int Direction = WHARF_DOWN;
					int FoldDirection = WHARF_RIGHT;

					if(extra_text[0] == '#')
					{
						strlwr(extra_text);
						Group = extra_text[1];
						Visible = !strchr(extra_text, 'h');
						Topmost = !strchr(extra_text, 'b');
						if(strchr(extra_text, 'r'))
						{
							Direction = WHARF_RIGHT;
							FoldDirection = WHARF_DOWN;
						}
						if(direction == FolderDirection)
							FoldDirection = Direction;
					}
					numMainWharfs++;
					MainWharf.push_back(new wharfType(NULL, Group, atoi(token3), atoi(token4), Direction, Visible, token5));
					MainWharf[numMainWharfs]->Create(file, parentWnd, tileWidth, tileHeight, Topmost, FoldDirection, token6, token7, token8);
					return;
				}
			}
			break;
		}
	}
}

void wharfFolderType::CloseAllFolders()
{
	for(int i = 0; i < numWharfs; i++)
	{
		if(wharfs[i]->folder->open || wharfs[i]->folder->moving)
		{
			wharfs[i]->folder->CloseAllFolders();
			wharfs[i]->bPressed = FALSE;
			wharfs[i]->TogglePressOffset(FALSE);
			if(wharfNoAnim)
			{
				SetWindowPos(wharfs[i]->folder->hMainWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
				wharfs[i]->folder->open = FALSE;
			}
			else
			{
				wharfs[i]->folder->moving = TRUE;
				wharfs[i]->folder->closing = TRUE;
				SetTimer(wharfs[i]->hWnd, 3, wharfAnimTime, NULL);
			}
			//OpenFolders--;
		}
	}
}

BOOL wharfFolderType::PartOfWharf(HWND myWnd)
{
	if(myWnd == NULL)
		return FALSE;
	if(hParent == myWnd)
		return TRUE;
	if(hMainWnd == myWnd)
		return TRUE;

	for(int i = 0; i < numWharfs; i++)
	{
		if(wharfs[i]->hWnd == myWnd)
			return TRUE;
		if(wharfs[i]->folder)
		{
			if(wharfs[i]->folder->PartOfWharf(myWnd))
				return TRUE;
		}
	}
	return FALSE;
}

void wharfFolderType::OnActivate(Message &message)
{
	if(!wharfCloseOnSwitch)
		return;

	if(message.wParamLo == WA_INACTIVE)
	{
		if(parentTileWnd)
			SendMessage(parentTileWnd, WHARF_PARTOF, 0, message.lParam);
		else if(!PartOfWharf((HWND)(message.lParam)))
			CloseAllFolders();
	}
}
/*
void wharfFolderType::OnTimer(Message &message)
{
	if(message.wParam == 4)
	{
		for(int i = 0; i < numWharfs; i++)
		{
			if(wharfs[i]->bPressed && !wharfs[i]->folder->open)
				wharfs[i]->TogglePressOffset(FALSE);
		}
	}
}
*/
wharfTileType::wharfTileType(HWND pWnd, HRGN pRgn, LPCSTR name, LPCSTR command, LPCSTR params, BOOL noTrans, int Width, int Height, int xPos, int yPos, int Direction)
{
	hInst = NULL;
	hWnd = NULL;
	taskWnd = NULL;
	parentWnd = pWnd;
	backImage[0] = NULL;
	backImage[1] = NULL;
	backImage[2] = NULL;
	szName = new char[strlen(name) + 1];
	strcpy(szName, name);
	szCommand = new char[strlen(command) + 1];
	strcpy(szCommand, command);
	szParameters = new char[strlen(params) + 1];
	strcpy(szParameters, params);
	width = Width;
	height = Height;
	inWharfX = xPos;
	inWharfY = yPos;
	direction = Direction;
	state = 0;
	isOpaque = noTrans;
	bPressed = FALSE;
	bTogglePressed = FALSE;
	initWharfModule = NULL;
	quitWharfModule = NULL;
	GetLSRegion = NULL;
	parentRgn = pRgn;
}

wharfTileType::~wharfTileType()
{
	parentWnd = NULL;
	taskWnd = NULL;
	parentRgn = NULL;
	if(szName)
		delete[] szName;
	szName = NULL;
	if(szCommand)
		delete[] szCommand;
	szCommand = NULL;
	if(szParameters)
		delete[] szParameters;
	szParameters = NULL;

	if(folder)
		delete folder;
	if(hInst)
	{
		(*quitWharfModule)(hInst);
		FreeLibrary(hInst);
	}
	DestroyWindow(hWnd);
	if(backImage[0])
		DeleteObject(backImage[0]);
	if(backImage[1])
		DeleteObject(backImage[1]);
	if(backImage[2])
		DeleteObject(backImage[2]);
}

BOOL wharfTileType::Create(FILE *file, LPCSTR szWindowName, LPSTR image, LPCSTR imageParams, BOOL showbg, BOOL topmost, int FolderDirection, LPCSTR szDefaultImage, LPCSTR szDefaultFolderImage, LPCSTR szFolderImage)
{
	HWND tempWnd;
	RECT r;
	char *token;

	tempWnd = CreateWindowEx(
		WS_EX_TRANSPARENT,
		szTileWindowClass,
		szWindowName,
		WS_CHILD,
		0, 0,
		width, height,
		parentWnd,
		NULL,
		dll,
		NULL);
	
	if(!tempWnd)
	{
		MessageBox(hParent, "Error creating wharf tile", "Wharf", MB_OK | MB_TOPMOST);
		return FALSE;
	}
	hWnd = tempWnd;
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(hWnd, 4, (LONG)this);
	//Wharf hints
	if(!wharfNoHints)
	{
		if(hWnd)
		{
			RECT r;
			GetClientRect (hWnd, &r);
			CreateWharfhints (hWnd, szName, &r);
		}
	}

	SetWindowPos(hWnd, 0, inWharfX, inWharfY, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
	
	if(szCommand[0] == '@')
	{
		int (FAR *FinitWharfModule)(HWND, HINSTANCE, wharfDataType*);
		int (FAR *FquitWharfModule)(HINSTANCE);
		HRGN (FAR *FGetLSRegion)(int, int);
		
		char *module;
		HINSTANCE moduleInst;
		
		module = szCommand;
		if(*module == '@')
			module++;
		moduleInst = LoadLibrary(module);
		if((UINT)moduleInst > HINSTANCE_ERROR)
		{
			FinitWharfModule = (int (FAR *)(HWND, HINSTANCE, wharfDataType*))GetProcAddress(moduleInst, "initWharfModule");
			if(!FinitWharfModule)
				FinitWharfModule = (int (FAR *)(HWND, HINSTANCE, wharfDataType*))GetProcAddress(moduleInst, "_initWharfModule");
			FquitWharfModule = (int (FAR *)(HINSTANCE))GetProcAddress(moduleInst, "quitWharfModule");
			if(!FquitWharfModule)
				FquitWharfModule = (int (FAR *)(HINSTANCE))GetProcAddress(moduleInst, "_quitWharfModule");
			FGetLSRegion = (HRGN (FAR *)(int, int))GetProcAddress(moduleInst, "GetLSRegion");
			if(!FGetLSRegion)
				FGetLSRegion = (HRGN (FAR *)(int, int))GetProcAddress(moduleInst, "_GetLSRegion");
			
			if(!FinitWharfModule || !FquitWharfModule)
			{
				MessageBox(NULL, module, "Invalid Wharf module", MB_OK | MB_TOPMOST);
				FreeLibrary(moduleInst);
				hInst = NULL;
			}
			else
			{
				hInst = moduleInst;
				initWharfModule = FinitWharfModule;
				quitWharfModule = FquitWharfModule;
				GetLSRegion = FGetLSRegion;
				Execute();
			}
		}
		else
		{
			hInst = NULL;
			MessageBox(NULL, module, "Error loading module", MB_OK | MB_TOPMOST);
		}
	}
	
	token = strtok(image, "{}");
	/* Combine our images into one */
	for(int i = 0; i < 3; i++)
	{
	if(token)
	{
		HBITMAP oldBMP1, oldBMP2 = NULL;
		HBITMAP frontImage = LoadLSImage(token, imageParams);
		HDC src = CreateCompatibleDC(NULL);
		HDC dst = CreateCompatibleDC(NULL);
		HBRUSH hb = CreateSolidBrush(RGB(255,0,255));
		HDC tempDC = GetDC(hWnd);
		RECT r;
		
		backImage[i] = CreateCompatibleBitmap(tempDC, width, height);
		oldBMP1 = (HBITMAP)SelectObject(dst, backImage[i]);
		r.left = 0;
		r.top = 0;
		r.right = width;
		r.bottom = height;
		FillRect(dst, &r, hb);
		if(wharfTitles && !hInst)
		{
			HBRUSH hb2 = CreateSolidBrush(RGB(0,0,128));
			r.bottom = 10;
			FillRect(dst, &r, hb2);
			DeleteObject(hb2);
		}
		if(hInst && !GetLSRegion)
		{
			HDC ddc = GetDC(GetDesktopWindow());
			POINT p;
			
			p.x = 0;
			p.y = 0;
			ClientToScreen(hWnd, &p);
			BitBlt(dst, 0, 0, width, height, ddc, p.x, p.y, SRCCOPY);
			ReleaseDC(GetDesktopWindow(), ddc);
		}
		if(showbg == TRUE)
		{
			if(szDefaultImage)
			{
				HBITMAP defaultImage = LoadLSImage(szDefaultImage, NULL);
				AddImage(dst, src, defaultImage);
				DeleteObject(defaultImage);
			}
			else if(szDefaultFolderImage)
			{
				HBITMAP defaultFolderImage = LoadLSImage(szDefaultFolderImage, NULL);
				AddImage(dst, src, defaultFolderImage);
				DeleteObject(defaultFolderImage);
			}
		}
		if(frontImage)
		{
			oldBMP2 = AddImage(dst, src, frontImage);
			DeleteObject(frontImage);
		}
		if(szFolderImage && (showbg == TRUE) && ((!strcmpi(szCommand, "Folder")) || (!strcmpi(szCommand, "!WharfTasks"))))
		{
			HBITMAP folderImage = LoadLSImage(szFolderImage, NULL);
			if(oldBMP2)
				AddImage(dst, src, folderImage);
			else
				oldBMP2 = AddImage(dst, src, folderImage);
			DeleteObject(folderImage);
		}
		
		ReleaseDC(hWnd, tempDC);
		SelectObject(src, oldBMP2);
		DeleteDC(src);
		SelectObject(dst, oldBMP1);
		DeleteDC(dst);
		DeleteObject(hb);

		token = strtok(NULL, "{}");
	}
	}
	/* Calculate transparent regions for hMainWnd here, compile regions per bitmap/tile and add together
	* for a full transparent parent window - <toasty@iav.com>  */
	{
		HRGN wharfRgn;

		if((backImage && !hInst && !isOpaque) || (GetLSRegion))
			wharfRgn = BitmapToRegion(backImage[0], RGB(255,0,255), 0x101010, inWharfX, inWharfY);
		else
			wharfRgn = CreateRectRgn(inWharfX, inWharfY, width+inWharfX, height+inWharfY);

		if(GetLSRegion)
		{
			HRGN rgn = NULL;

			rgn = GetLSRegion(inWharfX, inWharfY);
			
			if(rgn)
			{
				CombineRgn(wharfRgn, wharfRgn, rgn, RGN_OR);
			}
			DeleteObject(rgn);
		}
		if(parentRgn)
		{
      		CombineRgn(parentRgn, parentRgn, wharfRgn, RGN_OR);
    	}
		else
		{
			parentRgn = wharfRgn;
		}
		DeleteObject(wharfRgn);
	}

	folder = new wharfFolderType(hWnd, FolderDirection);

	if(!strcmpi(szCommand, "Folder"))
	{
		char *val1 = NULL, *val2 = NULL;

		val1 = strtok(szParameters, " ");
		val2 = strtok(NULL, "");

		folder->Create(file, (val1) ? atoi(val1) : width, (val2) ? atoi(val2) : height, topmost, direction, szDefaultFolderImage, szFolderImage);
	}

	ShowWindow(hWnd, SW_SHOWNORMAL);
	GetClientRect(hWnd, &r);
	InvalidateRect(hWnd, &r, TRUE);
	
	return TRUE;
}

void wharfTileType::Execute()
{
	if(!strcmpi(szCommand, "Folder") || !strcmpi(szCommand, "!WharfTasks"))
	{
		if(folder->moving)
		{
			if(folder->closing)
			{
				folder->closing = FALSE;
				if(wharfOpenSound) WharfSound(wharfOpenSound);
			}
			else
			{
				folder->closing = TRUE;
				if(wharfCloseSound) WharfSound(wharfCloseSound);
			}
		}
		else if(folder->open == FALSE)
		{
			if(wharfOpenSound) WharfSound(wharfOpenSound);
			if(wharfAutoClose)
				SendMessage(parentWnd, WHARF_CLOSEFOLDERS, TRUE, 0);

			if(wharfNoAnim)
			{
				if(folder->direction == WHARF_RIGHT)
					folder->movingPos = folder->width;
				else if(folder->direction == WHARF_DOWN)
					folder->movingPos = folder->height;
			}
			folder->moving = TRUE;
			folder->closing = FALSE;
			SetTimer(hWnd, 2, wharfAnimTime, NULL);
			//OpenFolders++;
		}
		else if(folder->open)
		{
			if(wharfCloseSound) WharfSound(wharfCloseSound);
			folder->CloseAllFolders();

			if(wharfNoAnim)
				folder->movingPos = 0;
			folder->moving = TRUE;
			folder->closing = TRUE;
			SetTimer(hWnd, 3, wharfAnimTime, NULL);
			//OpenFolders--;
		}
		return;
	}
	
	if(szCommand[0] == '@')
	{
		wharfDataType wharfData;
		memset(&wharfData, 0, sizeof (wharfData));
		GetWharfData(&wharfData, width, height);

		(*initWharfModule)(hWnd, hInst, &wharfData);
	}
	else if(szCommand[0] == '!')
	{
		/*if(!strcmpi(szCommand, "!task"))
		{
			if(!SendMessage(hParent, LM_BRINGTOFRONT, 0, (long)taskWnd))
				SwitchToThisWindow(taskWnd, 1);
		}
		else if(!strcmpi(szCommand, "!WharfTasks"))
		{
			for(q = 0; q < numWharfs; q++)
				if(MainWharf[0]->wharfs[q]->hWnd == hWnd)
					ExecuteWharfTasks(q);
		}
		else*/
			ParseBangCommand(hWnd, szCommand, szParameters);
	}
	else
	{
		char workDirectory[MAX_PATH];
		char drive[_MAX_DRIVE];
		char dir[_MAX_DIR];

		_splitpath(szCommand, drive, dir, NULL, NULL);
		strcpy(workDirectory, drive);
		strcat(workDirectory, dir);
		
		LSExecuteEx(NULL, NULL, szCommand, szParameters, workDirectory, SW_SHOWNORMAL);
	}
	if(backImage[2])
	{
		RECT r;

		state = 1;
		GetClientRect(hWnd, &r);
		InvalidateRect(hWnd, &r, TRUE);
	}
	else
	{
		bPressed = FALSE;
		TogglePressOffset(FALSE);
	}

	if(wharfAutoClose)
		SendMessage(parentWnd, WHARF_CLOSEFOLDERS, 0, 0);
}

HBITMAP wharfTileType::AddImage(HDC dst, HDC src, HBITMAP image)
{
	int w, h;
	HBITMAP oldBMP = NULL;
			
	GetLSBitmapSize(image, &w, &h);
	if(w > width) w = width;
	if(h > height) h = height;
	oldBMP = (HBITMAP)SelectObject(src, image);
	TransparentBltLS(dst, (width/2)-(w/2), (height/2)-(h/2), w, h, src, 0, 0, RGB(255,0,255));

	return oldBMP;
}

void wharfTileType::TogglePressOffset(BOOL bToggle)
{
	if(bTogglePressed != bToggle) // redundancy check...see below comment
	{
		SetWindowPos(hWnd,							 
			0, 
			bToggle ? inWharfX + wharfPressOffset : inWharfX, 
			bToggle ? inWharfY + wharfPressOffset : inWharfY, 
			bToggle ? width-1 : width, 
			bToggle ? height-1 : height, 
			SWP_NOZORDER);
		
		bTogglePressed = bToggle; // could this be replaced by checking the windows current position for a 1, 1 offset?
	}
}

void wharfTileType::AnimateOpen()
{
	if(folder->closing)
	{
		KillTimer(hWnd, 2);
		SetTimer(hWnd, 3, wharfAnimTime, NULL);
	}
	else
	{
//		if(!strcmpi(szCommand, "!WharfTasks"))
//			ExecuteWharfTasks(this);

		RECT r;
		GetWindowRect(hWnd, &r);
		if(bPressed)
		{
			r.bottom--;
			r.left--;
			r.right--;
			r.top--;
		}

		if(direction == WHARF_DOWN)
		{
			if(folder->direction == WHARF_RIGHT)
			{
				if(folder->movingPos + wharfStep >= folder->width)
					folder->movingPos = folder->width;
				else
					folder->movingPos += wharfStep;
				//KillTimer(parentWnd, 4);

				if((r.left + (width/2)) > ScreenWidth/2)
					SetWindowPos(folder->hMainWnd, 0, r.left - folder->movingPos, r.top, folder->movingPos, folder->height, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.right, r.top, folder->movingPos, folder->height, SWP_NOZORDER);

				if(folder->movingPos >= folder->width)
				{
					folder->open = TRUE;
					folder->moving = FALSE;
					folder->closing = TRUE;
					KillTimer(hWnd, 2);
				}
			}
			else if(folder->direction == WHARF_DOWN)
			{
				if(folder->movingPos + wharfStep >= folder->height)
					folder->movingPos = folder->height;
				else
					folder->movingPos += wharfStep;
				//KillTimer(parentWnd, 4);

				if((r.left + ( width/2)) > ScreenWidth/2)
					SetWindowPos(folder->hMainWnd, 0, r.left - folder->width, r.top, folder->width, folder->movingPos, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.right, r.top, folder->width, folder->movingPos, SWP_NOZORDER);

				if(folder->movingPos >= folder->height)
				{
					folder->open = TRUE;
					folder->moving = FALSE;
					folder->closing = TRUE;
					KillTimer(hWnd, 2);
				}
			}
		}
		else if(direction == WHARF_RIGHT)
		{
			if(folder->direction == WHARF_DOWN)
			{
				if(folder->movingPos + wharfStep >= folder->height)
					folder->movingPos = folder->height;
				else
					folder->movingPos += wharfStep;
			  	//KillTimer(parentWnd, 4);

				if((r.top + (height/2)) > ScreenHeight/2)
					SetWindowPos(folder->hMainWnd, 0, r.left, r.top - folder->movingPos, folder->width, folder->movingPos, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.left, r.bottom, folder->width, folder->movingPos, SWP_NOZORDER);
	
				if(folder->movingPos >= folder->height)
				{
					folder->open = TRUE;
					folder->moving = FALSE;
					folder->closing = TRUE;
					KillTimer(hWnd, 2);
				}
			}
			else if(folder->direction == WHARF_RIGHT)
			{
				if(folder->movingPos + wharfStep >= folder->width)
					folder->movingPos = folder->width;
				else
					folder->movingPos += wharfStep;
			  	//KillTimer(parentWnd, 4);

				if((r.top + (height/2)) > ScreenHeight/2)
					SetWindowPos(folder->hMainWnd, 0, r.left, r.top - folder->height, folder->movingPos, folder->height, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.left, r.bottom, folder->movingPos, folder->height, SWP_NOZORDER);
	
				if(folder->movingPos >= folder->width)
				{
					folder->open = TRUE;
					folder->moving = FALSE;
					folder->closing = TRUE;
					KillTimer(hWnd, 2);
				}
			}
		}
	}
}

void wharfTileType::AnimateClose()
{
	if(!folder->closing)
	{
		KillTimer(hWnd, 3);
		SetTimer(hWnd, 2, wharfAnimTime, NULL);
	}
	else
	{
		RECT r;
		GetWindowRect(hWnd, &r);
		if(bPressed)
		{
			r.bottom--;
			r.left--;
			r.right--;
			r.top--;
		}

		if(backImage[2])
		{
			RECT r;

			state = 1;
			GetClientRect(hWnd, &r);
			InvalidateRect(hWnd, &r, TRUE);
		}
		else
		{
			bPressed = FALSE;
			TogglePressOffset(FALSE);
		}

		if(folder->movingPos - wharfStep <= 0)
			folder->movingPos = 0;
		else
			folder->movingPos -= wharfStep;
		//KillTimer(parentWnd, 4);
		//SetTimer(folder->hMainWnd, 4, 50, NULL);

		if(direction == WHARF_DOWN)
		{
			if(folder->direction == WHARF_RIGHT)
			{
				if((r.left + (width/2)) > ScreenWidth/2)
					SetWindowPos(folder->hMainWnd, 0, r.left - folder->movingPos, r.top, folder->movingPos, folder->height, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.right, r.top, folder->movingPos, folder->height, SWP_NOZORDER);
			}
			else if(folder->direction == WHARF_DOWN)
			{
				if((r.left + (width/2)) > ScreenWidth/2)
					SetWindowPos(folder->hMainWnd, 0, r.left - folder->width, r.top, folder->width, folder->movingPos, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.right, r.top, folder->width, folder->movingPos, SWP_NOZORDER);
			}
		}
		else if(direction == WHARF_RIGHT)
		{
			if(folder->direction == WHARF_DOWN)
			{
				if((r.top + (height/2)) > ScreenHeight/2)
					SetWindowPos(folder->hMainWnd, 0, r.left, r.top - folder->movingPos, folder->width, folder->movingPos, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.left, r.bottom, folder->width, folder->movingPos, SWP_NOZORDER);
			}
			else if(folder->direction == WHARF_RIGHT)
			{
				if((r.top + (height/2)) > ScreenHeight/2)
					SetWindowPos(folder->hMainWnd, 0, r.left, r.top - folder->height, folder->movingPos, folder->height, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.left, r.bottom, folder->movingPos, folder->height, SWP_NOZORDER);
			}
		}

		if(folder->movingPos <= 0)
		{
			folder->open = FALSE;
			folder->moving = FALSE;
			folder->closing = FALSE;
			KillTimer(hWnd, 3);
			//KillTimer(folder->hMainWnd, 4);
		}
	}
}

void wharfTileType::OnActivate(Message &message)
{
	if(!wharfCloseOnSwitch)
		return;

	if(message.wParamLo == WA_INACTIVE)
		SendMessage(parentWnd, WHARF_PARTOF, 0, message.lParam);
}

void wharfTileType::OnMouseMove(Message &message)
{
	MSG TooltipMessage;

	if(state == 0)
	{
		if(backImage[1])
		{
			RECT r;

			state = 1;
			GetClientRect(hWnd, &r);
			InvalidateRect(hWnd, &r, TRUE);
			SetTimer(hWnd, 5, 20, NULL);
		}
	}

	if(!wharfNoHints)
	{
		TooltipMessage.hwnd=hWnd;
		TooltipMessage.message=message.uMsg;
		TooltipMessage.wParam=message.wParam;
		TooltipMessage.lParam=message.lParam;
		SendMessage(wharfHints,TTM_RELAYEVENT,0,(LPARAM)&TooltipMessage);
		SetWindowPos(wharfHints, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
	}
}

void wharfTileType::OnPaint(Message &message)
{
	HBITMAP oldBMP = NULL;
	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd,&ps);
	HDC src = CreateCompatibleDC(hdc);

	if(isOpaque)
	{
		HDC ddc = GetDC(GetDesktopWindow());
		POINT p;
			
		p.x = 0;
		p.y = 0;
		ClientToScreen(hWnd, &p);
		BitBlt(hdc, 0, 0, width, height, ddc, p.x, p.y, SRCCOPY);
		ReleaseDC(GetDesktopWindow(), ddc);
	}
	if(backImage[state])
	{
		oldBMP = (HBITMAP)SelectObject(src, backImage[state]);
		TransparentBltLS(hdc, 0, 0, width, height, src, 0, 0, RGB(255,0,255));
	}
	if((wharfTitles && !hInst)||(!strcmpi(szCommand, "!task")))
	{
		PaintTitle(hdc, src);
	}
	if(bevelWidth)
	{
		RECT r = {0, 0, width, height};
		Frame3D(hdc, r, RGB(255,255,255), RGB(0,0,0), bevelWidth);
	}

	if(oldBMP)
	{
		SelectObject(src, oldBMP);
	}

	EndPaint(hWnd,&ps);
	DeleteDC(src);
}

void wharfTileType::PaintTitle(HDC hdc, HDC src)
{
	RECT r;
	HBRUSH back;
	HFONT titleFont, oldFont;
	int nHeight;
	int len = lstrlen(szName);
	
	back = CreateSolidBrush(titleBack);
	GetClientRect(hWnd, &r);
	//					r.bottom = 10;
	//					FillRect(hdc, &r, back);
	nHeight = MulDiv(iTitleFontSize, GetDeviceCaps(src, LOGPIXELSY), 72);
	r.bottom = nHeight +2;
	FillRect(src, &r, back);
	titleFont = CreateFont(
		nHeight, // 8,
		0, // 6,
		0,
		0,
		iTitleFontWeight, // 0,
		FALSE,
		FALSE,
		FALSE,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_DONTCARE, // DEFAULT_PITCH,
		szTitleFont
		);
	oldFont = (HFONT)SelectObject(src, titleFont);
	SetBkMode(src, TRANSPARENT);
	SetTextColor(src, titleFore);
	TextOut(src, 2, 1, szName, len);
	BitBlt(hdc, 0, 0, width, height, src, 0, 0, SRCCOPY);
	SelectObject(src, oldFont);
	DeleteObject(titleFont);
	DeleteObject(back);
}

void wharfTileType::OnLButtonDown(Message &message)
{
	if(backImage[2])
	{
		RECT r;

		state = 2;
		GetClientRect(hWnd, &r);
		InvalidateRect(hWnd, &r, TRUE);
	}
	else
	{
		//SetTimer(parentWnd, 4, 50, NULL);
		bPressed = TRUE;
		TogglePressOffset(TRUE);
	}
}

void wharfTileType::OnLButtonUp(Message &message)
{
	if(bPressed || state == 2)
	{
		//KillTimer(parentWnd, 4);
		Execute();
	}
	
}

void wharfTileType::OnTimer(Message &message)
{
	if(message.wParam == 2)   //sub wharf opening
	{
		AnimateOpen();
	}
	if(message.wParam == 3)  // sub wharf closing
	{
		AnimateClose();
	}
	if(message.wParam == 5)  // sub wharf closing
	{
		if(state && !folder->open)
		{
			POINT pos;
			RECT r, rect;
			HRGN h = CreateRectRgn(0, 0, 0, 0);

			GetCursorPos(&pos);
			GetWindowRect(hWnd, &rect);

			if(!PtInRect(&rect, pos))
			{
				state = 0;
				GetClientRect(hWnd, &r);
				InvalidateRect(hWnd, &r, TRUE);
				KillTimer(hWnd, 5);
			}
			DeleteObject(h);
		}
	}
}

wharfHiddenType::wharfHiddenType(wharfType *p)
{
	parent = p;
	HiddenWnd = NULL;
	hideTimerActive = FALSE;
	showTimerActive = FALSE;
	docked = 0;
}

wharfHiddenType::~wharfHiddenType()
{
	DestroyWindow(HiddenWnd);
}

BOOL wharfHiddenType::Create()
{
	HiddenWnd = CreateWindowEx(
		WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
		szHiddenWindowClass,
		"LSWharfHidden",
		WS_POPUP,
		(parent->x == 0) ? 0 : (parent->x+parent->width == ScreenWidth) ? parent->x+parent->width-hiddenWidth : parent->x,
		(parent->y == 0) ? 0 : (parent->y+parent->height == ScreenHeight) ? parent->y+parent->height-hiddenWidth : parent->y,
		(parent->direction == WHARF_DOWN) ? hiddenWidth : parent->width,
		(parent->direction == WHARF_RIGHT) ? hiddenWidth : parent->height,
		hParent,
		NULL,
		dll,
		NULL
		);
		
	if(!HiddenWnd)
	{
		MessageBox(hParent, "Error creating wharf", "Wharf", MB_OK | MB_TOPMOST);
		return 1;
	}

	SetWindowLong(HiddenWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(HiddenWnd, 4, (LONG)this);

	return 0;
}

void wharfHiddenType::OnPaint(Message& message)
{
	PAINTSTRUCT ps;
	RECT r;
	HDC hdc = BeginPaint(HiddenWnd,&ps);
	HBRUSH hb = CreateSolidBrush(0xFFFFFF);

	GetClientRect(HiddenWnd, &r);
	r.right += 1;
	r.bottom += 1;

	FillRect(hdc, &r, hb);

	DeleteObject(hb);
	EndPaint(HiddenWnd, &ps);
}

void wharfHiddenType::OnTimer(Message& message)
{
	if(parent->x == 0 && parent->direction == WHARF_DOWN) 
		docked = 1;
	else if(parent->x + parent->width == ScreenWidth && parent->direction == WHARF_DOWN) 
		docked = 2;
	else if(parent->y == 0 && parent->direction == WHARF_RIGHT) 
		docked = 3;
	else if(parent->y + parent->height == ScreenHeight && parent->direction == WHARF_RIGHT) 
		docked = 4;
	else
		docked = 0;

	if(docked)
	{
		switch(docked)
		{
		case 1:
			SetWindowPos(HiddenWnd, 0, 0, parent->y, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
		case 2:
			SetWindowPos(HiddenWnd, 0, ScreenWidth - hiddenWidth, parent->y, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
		case 3:
			SetWindowPos(HiddenWnd, 0, parent->x, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
		case 4:
			SetWindowPos(HiddenWnd, 0, parent->x, ScreenHeight - hiddenWidth, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
		}

		switch(message.wParam)
		{
		case 0:
			if(wharfAutoHide)
			{
				if(parent->visible)
				{
					parent->Hide();
					ShowWindow(HiddenWnd, SW_SHOWNORMAL);
				}
			}
			KillTimer(HiddenWnd, 0);
			hideTimerActive = FALSE;
			break;
		case 1:
			if(wharfAutoHide && parent->visible && !hideTimerActive)
			{
				POINT pt;
				RECT r;
				GetCursorPos(&pt);
				GetWindowRect(parent->hMainWnd, &r);
				if(!parent->PartOfWharf(WindowFromPoint(pt)) && (wharfNoAnim || wharfCloseOnSwitch ? TRUE : FALSE))
				{
					SetTimer(HiddenWnd, 0, autoHideDelay, NULL);
					hideTimerActive = TRUE;
				}
			}
			else
			{
				if(wharfAutoHide && !parent->visible && !showTimerActive)
				{
					POINT pt;
					RECT r;
					GetCursorPos(&pt);
					GetWindowRect(HiddenWnd, &r);
					if(pt.x >= r.left && pt.x <= r.right && pt.y >= r.top && pt.y <= r.bottom)
					{
						SetTimer(HiddenWnd, 2, autoShowDelay, NULL);
						showTimerActive = TRUE;
					}

				}
				else if(!parent->visible && showTimerActive)
				{
					POINT pt;
					RECT r;
					GetCursorPos(&pt);
					GetWindowRect(HiddenWnd, &r);
					if(pt.x < r.left || pt.x > r.right || pt.y < r.top || pt.y > r.bottom)
					{
						KillTimer(HiddenWnd, 2);
						showTimerActive = FALSE;
					}
				}
			}
			break;
		case 2:
			if(wharfAutoHide)
			{
				if(!parent->visible)
				{
					ShowWindow(HiddenWnd, SW_HIDE);
					parent->Show();
				}
			}
			KillTimer(HiddenWnd, 2);
			showTimerActive = FALSE;
			break;
		}
	}
	else
	{
		if(hideTimerActive)
		{
			KillTimer(HiddenWnd, 0);
			hideTimerActive = FALSE;
		}
	}
}

wharfType::wharfType(HWND tileWnd, char Group, int xPos, int yPos, int Direction, BOOL Visible, LPCSTR szCapImage)
{
	hMainWnd = NULL;
	parentTileWnd = tileWnd;
	hMainRgn = NULL;
	x = xPos;
	y = yPos;
	width = 0;
	height = 0;
	group = Group;
	direction = Direction;
	numWharfs = 0;
	movingPos = 0;
	open = TRUE;
	moving = FALSE;
	closing = FALSE;
	isFirst = TRUE;
	visible = Visible;
	capImage = LoadLSImage(szCapImage, NULL);
	capWidth = 0;
	capHeight = 0;
	
	hiddenWharf = NULL;
}

wharfType::~wharfType()
{
	UINT Msgs[2];

	if(wharfAutoHide)
	{
		KillTimer(hiddenWharf->HiddenWnd, 1);
		delete hiddenWharf;
	}
	if(capImage)
		DeleteObject(capImage);

	Msgs[0] = LM_SHADETOGGLE;
	Msgs[1] = 0;
	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
}

BOOL wharfType::Create(FILE *file, HWND parentWnd, int tileWidth, int tileHeight, BOOL topmost, int FolderDirection, LPCSTR szDefaultImage, LPCSTR szDefaultFolderImage, LPCSTR szFolderImage)
{
	UINT Msgs[2];
	HWND tempWnd;

	tempWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW | (topmost ? WS_EX_TOPMOST : 0),
		szMainWindowClass,
		"LSWharf",
		WS_CLIPCHILDREN | WS_POPUP,
		x,
		y,
		0,
		0,
		parentWnd,
		NULL,
		dll,
		NULL
		);

	if(!tempWnd)
	{
		MessageBox(hParent, "Error creating wharf", "Wharf", MB_OK | MB_TOPMOST);
		return 1;
	}
	hMainWnd = tempWnd;

	if(capImage)
	{
		GetLSBitmapSize(capImage, &capWidth, &capHeight);
		if(capWidth > tileWidth) capWidth = tileWidth;
		if(capHeight > tileHeight) capHeight = tileHeight;
	}

	if(direction == WHARF_DOWN)
	{
		width = tileWidth;
		height += capHeight;
	}
	else if(direction == WHARF_RIGHT)
	{
		width += capWidth;
		height = tileHeight;
	}

	hMainRgn = CreateRectRgn(0, 0, 0, 0);

	SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(hMainWnd, 4, (LONG)this);

	if(file)
		ParseData(file, parentWnd, tileWidth, tileHeight, topmost, FolderDirection, szDefaultImage, szDefaultFolderImage, szFolderImage);

	Msgs[0] = LM_SHADETOGGLE;
	Msgs[1] = 0;
	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);

	SetWindowPos(hMainWnd, 0, x, y, width, height, SWP_NOZORDER);

	/* transparent titlebar */
	if(capImage)
	{
		HRGN hCapRgn;

		hCapRgn = BitmapToRegion(capImage, RGB(255,0,255), 0x101010, 0, 0);
		
		if(hMainRgn)
			CombineRgn(hMainRgn, hMainRgn, hCapRgn, RGN_OR);

		DeleteObject(hCapRgn);
	}
	SetWindowRgn(hMainWnd, hMainRgn, TRUE);
	hMainRgn = NULL;

	if(visible)
		ShowWindow(hMainWnd, SW_SHOWNORMAL);
	
	// If we are autohiding, set the autohide delay.
	if(wharfAutoHide)
	{
		hiddenWharf = new wharfHiddenType(this);
		hiddenWharf->Create();

		SetTimer(hiddenWharf->HiddenWnd, 1, 50, NULL);
	}

	return 0;
}

void wharfType::Show()
{
	if(!visible)
	{
		ShowWindow(hMainWnd, SW_SHOWNORMAL);
		visible = TRUE;
	}
}

void wharfType::Hide()
{
	if(visible)
	{
		ShowWindow(hMainWnd, SW_HIDE);
		visible = FALSE;
	}
}

void wharfType::Move(LPCSTR arg1, LPCSTR arg2, BOOL moveTo)
{
	int sw, sh;

	if(arg1)
	{
		sw = GetSystemMetrics(SM_CXSCREEN);

		if(moveTo)
		{
			x = atoi(arg1);
			if(x < 0)
				x += sw;
		}
		else
			x += atoi(arg1);

		if(x < 0)
			x = 0;
		else if(x > (sw - width))
			x = sw - width;
	}
	if(arg2)
	{
		sh = GetSystemMetrics(SM_CYSCREEN);

		if(moveTo)
		{
			y = atoi(arg2);
			if(y < 0)
				y += sh;
		}
		else
			y += atoi(arg2);

		if(y < 0)
			y = 0;
		else if(y > (sh - height))
			y = sh - height;
	}
	SetWindowPos(hMainWnd, NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
}

void wharfType::AnimateOpen()
{
	if(direction == WHARF_DOWN)
	{
		movingPos += wharfStep;
		SetWindowPos(hMainWnd, 0, x, y, width, movingPos, SWP_NOZORDER);
		if(movingPos >= height)
		{
			closing = FALSE;
			open = TRUE;
			KillTimer(hMainWnd, 0);
		}
	}
	else if(direction == WHARF_RIGHT)
	{
		movingPos += wharfStep;
		SetWindowPos(hMainWnd, 0, x, y, movingPos, height, SWP_NOZORDER);
		if(movingPos >= width)
		{
			closing = FALSE;
			open = TRUE;
			KillTimer(hMainWnd, 0);
		}
	}
}

void wharfType::AnimateClose()
{
	if(direction == WHARF_DOWN)
	{
		if(movingPos - wharfStep <= capHeight )
			movingPos = capHeight;
		else
			movingPos -= wharfStep;
		SetWindowPos(hMainWnd, 0, x, y, width, movingPos, SWP_NOZORDER);
		if(movingPos <= capHeight)
		{
			closing = FALSE;
			open = FALSE;
			KillTimer(hMainWnd, 1);
		}
	}
	else if(direction == WHARF_RIGHT)
	{
		if(movingPos - wharfStep <= capWidth )
			movingPos = capWidth;
		else
			movingPos -= wharfStep;
		SetWindowPos(hMainWnd, 0, x, y, movingPos, height, SWP_NOZORDER);
		if(movingPos <= capWidth)
		{
			closing = FALSE;
			open = FALSE;
			KillTimer(hMainWnd, 1);
		}
	}
}

void wharfType::OnDisplayChange(Message &message)
{
	if(!wharfNoResMove)
	{
		int RelativeX = ScreenWidth - x;
		int RelativeY = ScreenHeight - y;
		bool MoveRelativeX = RelativeX > (ScreenWidth / 2);
		bool MoveRelativeY = RelativeY > (ScreenHeight / 2);
		CloseAllFolders();
		ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
		ScreenHeight = GetSystemMetrics(SM_CYSCREEN);
		if(MoveRelativeX)
			x = ScreenWidth - RelativeX;
		if(MoveRelativeY)
			y = ScreenHeight - RelativeY;
		SetWindowPos(hMainWnd, HWND_TOPMOST, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
	}
}

void wharfType::OnShadeToggle(Message &message)
{
	if(closing)
		return;
	CloseAllFolders();
	if(open)
	{
		if(wharfMinSound)
			WharfSound(wharfMinSound);
		if(wharfNoAnim)
		{
			SetWindowPos(hMainWnd, 0, x, y, capWidth, capHeight, SWP_NOZORDER);
			open = FALSE;
			return;
		}
		closing = TRUE;
		if(direction == WHARF_DOWN)
			movingPos = height;
		else if(direction == WHARF_RIGHT)
			movingPos = width;
		SetTimer(hMainWnd, 1, wharfAnimTime, NULL);
	}
	else
	{
		if(wharfMaxSound)
			WharfSound(wharfMaxSound);
		if(wharfNoAnim)
		{
			SetWindowPos(hMainWnd, 0, x, y, width, height, SWP_NOZORDER);
			open = TRUE;
			return;
		}
		closing = FALSE;
		if(direction == WHARF_DOWN)
			movingPos = capHeight;
		else if(direction == WHARF_RIGHT)
			movingPos = capWidth;
		SetTimer(hMainWnd, 0, wharfAnimTime, NULL);
	}
}

void wharfType::OnNCHitTest(Message &message)
{
	if(capImage)
		message.lResult = HTCAPTION;
	else
		message.lResult = DefWindowProc(hMainWnd, message.uMsg, message.wParam, message.lParam);
}

void wharfType::OnNCLButtonDown(Message &message)
{
	CloseAllFolders();
	message.lResult = DefWindowProc(hMainWnd, message.uMsg, message.wParam, message.lParam);
}

void wharfType::OnPaint(Message &message)
{
	HBITMAP oldBMP = NULL;
	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hMainWnd,&ps);
	HDC src = CreateCompatibleDC(hdc);

	if(capImage)
	{
		oldBMP = (HBITMAP)SelectObject(src, capImage);
		BitBlt(hdc, 0, 0, capWidth, capHeight, src, 0, 0, SRCCOPY);
		SelectObject(src, oldBMP);
	}

	EndPaint(hMainWnd,&ps);
	DeleteDC(src);
}

void wharfType::OnPosChanging(Message &message)
{
	LPWINDOWPOS lpwp = (LPWINDOWPOS)(message.lParam);

	if(lpwp->x <= (snapTo ? snapToSensitivity : 0))
		lpwp->x = 0;
	else if(lpwp->x >= ScreenWidth - width - (snapTo ? snapToSensitivity : 0))
		lpwp->x = ScreenWidth - width;

	if(lpwp->y <= (snapTo ? snapToSensitivity : 0))
		lpwp->y = 0;
	else if(lpwp->y >= ScreenHeight - height - (snapTo ? snapToSensitivity : 0))
		lpwp->y = ScreenHeight - height;

	x = lpwp->x;
	y = lpwp->y;
}

void wharfType::OnTimer(Message &message)
{
	if(!closing && message.wParam == 0)
	{
		AnimateOpen();
	}
	if(closing && message.wParam == 1)
	{
		AnimateClose();
	}
/*	if(message.wParam == 4)
	{
		for(int i = 0; i < numWharfs; i++)
		{
			POINT pt;
			GetCursorPos(&pt);
			if(wharfs[i]->bPressed && !wharfs[i]->folder->open && !PtInRegion(hMainRgn, pt.x, pt.y))
				wharfs[i]->TogglePressOffset(FALSE);
		}
	}*/
}

/*
$Log: wharf.cpp,v $
Revision 1.11.2.4  2000/08/25 22:40:32  NeXTer
See changes.txt

Revision 1.11.2.3  2000/08/25 19:56:44  headius
fixes and rewrites in wharf

Revision 1.11.2.2  2000/08/03 21:35:38  NeXTer
- Added the ability to pause a recycle by holding the shift key
- Added the MB_TOPMOST flag to all messageboxes

Revision 1.11.2.1  2000/07/22 03:37:24  message
*** empty log message ***

Revision 1.11  2000/04/22 04:57:37  message
*** empty log message ***

Revision 1.5  2000/02/24 20:54:13  headius
see changes.txt

Revision 1.1.1.1  2000/01/28 05:57:39  headius
Import of Litestep into new cvs

Revision 1.2  2000/01/21 06:16:15  headius
Tabifying

Revision 1.1  2000/01/17 10:23:25  headius
Update of wharf to be .cpp and to use the new WindowList class
Not thread-safe yet.

  Revision 1.112  2000/01/06 05:26:15  message
  Changed source files back to dos format, somehow had become unix format, updated
  dependencies of desktopWnd to include lsutil, wasn't linking properly because lsutil
  was not being built first.
  
	Revision 1.92  1998/11/17 19:27:39  bryan
	Some more mods and fixes.
	
	  Revision 1.91  1998/11/17 15:13:28  cyberian
	  *** empty log message ***
	  
*/
