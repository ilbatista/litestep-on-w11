#ifndef __WHARF_H
#define __WHARF_H

#include <vector>
#include "../litestep/wharfdata.h"

#define WHARF_UP                0
#define WHARF_DOWN              1
#define WHARF_LEFT              2
#define WHARF_RIGHT             3

#define WHARF_CLOSEFOLDERS		11
#define WHARF_PARTOF			12

// forward decl
class wharfTileType;
class wharfType;

typedef std::vector< wharfTileType* > WharfTileVector;

class wharfFolderType
{
public:
	wharfFolderType();
	wharfFolderType(HWND tileWnd, int Direction);
	~wharfFolderType();

	virtual BOOL Create(FILE *file, int tileWidth, int tileHeight, BOOL topmost, int FolderDirection, LPCSTR szDefaultFolderImage, LPCSTR szFolderImage);
	void ParseData(FILE *file, HWND parentWnd, int tileWidth, int tileHeight, BOOL topmost, int FolderDirection, LPCSTR szDefaultImage, LPCSTR szDefaultFolderImage, LPCSTR szFolderImage);
	void CloseAllFolders();
	BOOL PartOfWharf(HWND myWnd);
	void OnActivate(Message &message);
	//virtual void OnTimer(Message &message);

	HWND hMainWnd;
	HWND parentTileWnd;
	HRGN hMainRgn;
	int width;
	int height;
	int numWharfs;
	int direction;
	BOOL open;
	BOOL moving;
	BOOL closing;
	BOOL isFirst;
	int movingPos;

	WharfTileVector wharfs;
};

class wharfTileType
{
public:
	wharfTileType(HWND pWnd, HRGN pRgn, LPCSTR name, LPCSTR command, LPCSTR params, BOOL noTrans, int Width, int Height, int xPos, int yPos, int Direction);
	~wharfTileType();

	BOOL Create(FILE *file, LPCSTR szWindowName, LPSTR image, LPCSTR imageParams, BOOL showbg, BOOL topmost, int FolderDirection, LPCSTR szDefaultImage, LPCSTR szDefaultFolderImage, LPCSTR szFolderImage);
	void Execute();
	HBITMAP AddImage(HDC dst, HDC src, HBITMAP image);
	void TogglePressOffset(BOOL bToggle);
	void AnimateOpen();
	void AnimateClose();
	void PaintTitle(HDC hdc, HDC src);
	void OnActivate(Message &message);
	void OnMouseMove(Message &message);
	void OnPaint(Message &message);
	void OnLButtonDown(Message &message);
	void OnLButtonUp(Message &message);
	void OnTimer(Message &message);

	HINSTANCE hInst;
	HWND hWnd;
	HWND taskWnd;
	HWND parentWnd;
	HBITMAP backImage[3];
	LPSTR szName;
	LPSTR szCommand;
	LPSTR szParameters;
	int width;
	int height;
	int inWharfX;
	int inWharfY;
	int direction;
	int state;
	BOOL isOpaque;
	BOOL bPressed;
	BOOL bTogglePressed;
	int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
	int (FAR *quitWharfModule)(HINSTANCE);
	HRGN (FAR *GetLSRegion)(int, int);
	HRGN parentRgn;

	wharfFolderType *folder;
};

class wharfHiddenType
{
	wharfType *parent;

public:
	wharfHiddenType(wharfType *p);
	~wharfHiddenType();

	BOOL Create();
	void OnPaint(Message &message);
	void OnTimer(Message &message);

	HWND HiddenWnd;
	BOOL hideTimerActive;
	BOOL showTimerActive;
	int docked;
};

class wharfType : public wharfFolderType
{
public:
	wharfType(HWND tileWnd, char Group, int xPos, int yPos, int Direction, BOOL Visible, LPCSTR szCapImage);
	~wharfType();

	virtual BOOL Create(FILE *file, HWND parentWnd, int tileWidth, int tileHeight, BOOL topmost, int FolderDirection, LPCSTR szDefaultImage, LPCSTR szDefaultFolderImage, LPCSTR szFolderImage);
	void Show();
	void Hide();
	void Move(LPCSTR arg1, LPCSTR arg2, BOOL moveTo);
	void AnimateOpen();
	void AnimateClose();
	void OnDisplayChange(Message &message);
	void OnShadeToggle(Message &message);
	void OnNCHitTest(Message &message);
	void OnNCLButtonDown(Message &message);
	void OnPaint(Message &message);
	void OnPosChanging(Message &message);
	virtual void OnTimer(Message &message);

	int x;
	int y;
	char group;
	BOOL visible;

	HBITMAP capImage;
	int capWidth;
	int capHeight;

	wharfHiddenType *hiddenWharf;
};

typedef std::vector< wharfType* > WharfVector;

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif