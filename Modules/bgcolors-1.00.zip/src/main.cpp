
/********************************************/
/*											*/
/*	main.cpp								*/
/*											*/
/*	Version	1.00							*/
/*											*/
/*	2 nov 2003								*/
/*											*/
/*	This file is the main file for 			*/
/*	the BGColors module for LiteStep.		*/
/*											*/
/*	This module should work on most 		*/
/*	LiteStep versions and on any version	*/
/*	of Windows.								*/
/*											*/
/*	This module should use less than 5%		*/
/*	of your cpu time even on old computers	*/
/*	and with really high resolutions.		*/
/*											*/
/*	Made by Antoine Wells Campagna			*/
/*	aka AntAgna								*/
/*	send questions, comments, etc... to :	*/
/*	AntoineW@Campagna.org					*/
/*											*/
/********************************************/

#include "lsapi.h"
#include <math.h>

#define MAXHBRS		2000	//Size of brushes buffer
#define EVENT_NAME	"LSBGCOLORS"

struct WNDINFO
{
	HDC hdc;		//Device context of the background
	double Change[3];	//Numbers on which the color will be calculated
	unsigned char Couleur[3];	//Colors
	int nbhbrs;		//Nunber of brushes waiting to be cleaned
	HBRUSH hbrs[MAXHBRS];	//Brushes buffer
	RECT rect;		//Screen coordinates
};

HANDLE hEvent;		//Need this to exit

void Draw(WNDINFO * gwnd)//This calculate colors and draw the color on the background
{
	int i;
	for (i=0; i<3; i++)		//Calcutale new color
	{
		gwnd->Change[i] += 0.01;
		gwnd->Couleur[i] = (unsigned char) (sin(gwnd->Change[i]) * 120 + 128);
	}

	HBRUSH hbr = CreateSolidBrush(RGB(gwnd->Couleur[0], gwnd->Couleur[1],
		gwnd->Couleur[2]));		//Create the new brush
	if (gwnd->nbhbrs >= MAXHBRS || !hbr)	//Can't create anymore brushes
	{
		for (i=0; i<gwnd->nbhbrs; i++)	//Clean all brushes
		{
			DeleteObject(gwnd->hbrs[i]);
		}

		gwnd->nbhbrs = 0;		//Reset counter
	}
	else
	{
		FillRect(gwnd->hdc, &gwnd->rect, hbr);	//Draws to the screen
		gwnd->hbrs[gwnd->nbhbrs++] = hbr;		//Save brush for cleaning
	}

}

unsigned long __stdcall TheThread(void *)	//This is the thread used by this module
{	//Makes initialisations and 
	int cnt = 1;	//Declares and inits
	HANDLE hCurThread = GetCurrentThread();
	HWND backgroundhwnd = FindWindow("DesktopBackgroundClass", "");
	WNDINFO wndi;
	wndi.hdc = GetDC(backgroundhwnd);
	GetWindowRect(backgroundhwnd, &wndi.rect);
	wndi.nbhbrs = 0;
	wndi.Change[0] = 0;
	wndi.Change[1] = 1.5;
	wndi.Change[2] = 4.5;
	//Force thread to idle (so it uses less CPU time)
	SetThreadPriority(hCurThread, THREAD_PRIORITY_IDLE);
	CloseHandle(hCurThread);		//Clean up

	hEvent = CreateEvent(0, 1, 0, EVENT_NAME);	//Initialize the event
	ResetEvent(hEvent);		//Makes sure the event isn't signaled
	//Main loop
	while (WaitForSingleObject(hEvent, 50) == WAIT_TIMEOUT)	//Wait 50 ms or exit
	{						//If the event is not signaled
		Draw(&wndi);		//Do the work
		if (cnt++ > 300)	//After a few seconds
		{	//Check the config again
			backgroundhwnd = FindWindow("DesktopBackgroundClass","");
			ReleaseDC(backgroundhwnd, wndi.hdc);		//Clean up
			GetWindowRect(backgroundhwnd, &wndi.rect);	//If screen res changed
			wndi.hdc = GetDC(backgroundhwnd);	//Makes sure the hdc stays correct
		}

	}

	CloseHandle(hEvent);	//If the event is signaled, quit
	return 0;	//Here, the thread exits
}

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	DWORD thID;
	CreateThread(0, 0, TheThread, 0, 0, &thID);	//Starts the thread
	return 0;
}

void quitModule(HINSTANCE hInstance)
{
	SetEvent(hEvent);		//Make the thread exit
	CloseHandle(hEvent);	//Clean up
}

BOOL APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	return TRUE;
}
