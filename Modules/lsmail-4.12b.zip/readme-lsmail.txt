
LSMail 4.12
===========
Written By: MrJukes
Updated by: Vendicator, Jesus_mjjg
Released: 2002-11-15


What is it?
This is LiteSTEP's longest running third-party module.  It checks for new mail on multiple
POP3 accounts and lets the user know when they have new mail.


Usage
Left clicking will check for new mail on server (if 0 found, clears new mail flag)
Right clicking will bring up a menu that is fairly self-explanatory.
  Check Mail will check the mail
  Launch E-Mail Client will launch your e-mail client
  Clear New Mail will clear the new mail flag and switch back to normal mode
  Dispaly Last Error will display the last error that LSMail encountered
    - Include this if you feel the need to e-mail me a trouble report
  

LoadModule $LiteStepDir$lsmail.dll / $ModulesDir$lsmail.dll


Step.rc
===========
LSMailX 0			; Can use center coordinates as "70C"
LSMailY -34
LSMailW 125
LSMailH 16
LSMailTimer 1			; How often to check for mail (in minutes)
				; If this is 0 no timer will be set and all checking
				; will have to be done manually
LSMailNoMessageBoxes true/false ; suppresses all messageboxes and sends them as warnings to log file
				; so you won't have to see them popup all the time
LSMailDisableCheck		; Disables LsMail from trying to check mail until you let it
LSMailStartHidden		; Doesn't show the lsmail window until you tell it via !bang
LSMailAlwaysOnTop		; Sets if the lsmail window should be on top

LSMailEMailClient "C:\Program Files\Outlook Express\msimn.exe"

LSMailFont Courier
LSMailFontSize 14
LSMailFontColor FFFFFF		; Normal font color
LSMailNewMailFontColor FF0000	; Font color when there is new mail
LSMailCheckingFontaColor C8C8C8	; Font color when checking mail
LSMailErrorFontaColor C8C8C8	; Font color if an error has occured while checking server

; *NOTE*
; If you do not specify a background color or a background image
; LSMail will use the desktop as its background.

LSMailBackColor 00FF00		; Normal background color
LSMailBackNewMailColor FF0000	; Background color when there is new mail
LSMailBackCheckingColor 000000	; Background color when checking mail
LSMailBackErrorColor 000000	; Background color if an error has occured
LSMailBackBmp lsmail.bmp	; Normal Background image
LSMailNewMailBmp lsmail-newmail.bmp	; Background image when there is new mail
LSMailCheckingBmp lsmail-checking.bmp	; Background image when LsMail is checking
LSMailErrorBmp lsmail-error.bmp	; Background image to display if an error has occured

LSMailNewMailCmd !bang		; Bang to be executed when there is new mail
LSMailNoMailCmd !bang		; Bang to be executed when you don't have any mail
LSMailCheckMailCmd !bang	; Bang to be executed when lsmail checks for new mail
LSMailDoneCheckCmd !bang	; Bang to be executed when lsmail is done checking
LSMailErrorCmd !bang		; Bang to be executed if an error has occured

; Server Configuration
; You can have as many of these are you would like
; The format is as follows:
;   *LSMailServer X Y "Display Name" host.name.com<:port> login (password-optional)
;  Where:
;    X = x offset for displaying the text inside the main window
;    Y = y offset for displaying the text inside the main window
;    Display Name = What to display for the server name
;    host.name.com = Host to connect to
;    <:port> = This is optional, leave it off and it defaults to 110
;    login = Your login
;    password = mail accounts password, not required here, lsmail will ask for password and save it to
;    registry for safe keeping

Examples:
*LSMailServer 0 0 Purdue postoffice.purdue.edu:110 mrjukes
*LSMailServer 0 16 Interaccess mail.interaccess.com mrjukes


Bangs
===========
!LSMailShow		; Shows the window
!LSMailHide		; Hides the window
!LSMailToggle		; Toggles visibility
!LSMailCheckMail	; Checks the mail
!LSMailHook		; Hooks lsmail to lsbox
!LSMailToggleCheck	; Toggles whether LsMail should be allowed to check for mail
!LSMailEnableCheck	; Enables LsMail to check for mail
!LSMailDisableCheck	; Disables LsMail from checking for mail
!LSMailMove x y		; Move LsMail to position x,y on screen


Evars
===========

LsMail sets the following evars after each mail check:

$LsMailNumMessages$ [total nr messages]		; Total number of messages that lsmail found on all servers
$LsMailServer[nr]$ [nr messages]		; Number of messages on each individual server
						; ie for 2 configed server: 
						; $LsMailServer1$ [nr msgs] and $LsMailServer2$ [nr msgs]

Changelog:
===========
4.12b -
2002-11-15 (jesus_mjjg):
        - minor change:
	  if you don't put a display name in the step.rc, there were still the ':' in the module
	  *LSMailServer 26 6 "display name" $popserver$ $popusername$ $poppassword$
          now, if there isn't a display name, no more ':', if there is, it acts like before.

4.12 -
2002-08-25 (Vendicator):
	- Fixed startup window paint before a mail check has been run.
	- Other shells without LSSetvar() in lsapi should be working again, PureLS and others.
	- Also added check for log support in lsapi.dll to be on the safe side
	- Also reduced mem usage some by removing some redunant ints

4.11 -
2002-08-19 (Vendicator):
	- Fixed stupid timer mistake causing lsmail not to do interval mail checking
	- Sets the following vars after a mail check:
	  LsMailNumMessages [total nr messages], LsMailServer[nr] [nr messages]
	  ie for 2 configed server: LsMailNumMessages 10, LsMailServer1 2 and LsMailServer2 8

4.1 -
2002-08-18 (Vendicator):
	- Big push towards more OOP
	- Even more code cleaning
	- Filesize slashed with about 50k, had to use ugly hack by adding hWnd2 as a public HWND for external funtions
	- Added setting to disable mail check "LSMailDisableCheck", use bangs to enable
	  in runtime: !LSMailToggleCheck, !LSMailEnableCheck, !LSMailDisableCheck
	- Added !LsMailMove x y
	- Added LSMailErrorBmp, LSMailBackErrorColor, LSMailErrorFontColor, LSMailErrorCmd per request of... sorry I forgot...
	- !Refresh support
	- Cleaner Readme format

4.08a -
2002-07-24 (Vendicator)
	- Fixed a memleak on recycle from not removing the status !bang commands correctly
	- More stuff moved into the OOP layout

4.08 -
2002-07-24 (Vendicator):
	- Added !LsMailHook for lsbox support
	- Added LSMailNoMessageBoxes, which sends errors as warnings to log file
	- Started rewrite to a more OOP layout, will make it easier to add other server types
	- Added LSMailDoneCheckCmd, per request of Maestr0

4.07 - 
2002-05-29 (Vendicator):
	- Fixed so that it defaults to old password style if none is present in the .rc config
	- LsMail no longer shows up in taskmanager
	- Added killing of lsmail thread on quit, might fix the ls crash on recycle when lsmail was checking.
	- Added LSMailCheckMailCmd, per request of morph, originally added by ilmcuts

4.06 -
2002-05-11 (Jesus_mjjg):
	- Now it is possible to specify the password in the step.rc:
	  *LSMailServer X Y "Display Name" host.name.com<:port> login password
	  But it seems to be better to use ears to configure lsmail:
	  *LSMailServer 5 6 Mail $mailPop1$ $mailLogin1$ $mailPassword1$
	  You have been warned! Don't tell me that because of me someone took your password.
	  If you don't want to put your password, don't put it, it'll work like before.

4.05 -
2002-04-17 (Vendicator):
	- Can show a separate bitmap when checking mail (LSMailCheckingBmp)
	- You can now specify a !bang to run when you have new mail/no mail (LSMailNewMailCmd/LSMailNoMailCmd)
	- Zero account is removed since it really didn't do anything useful now.

4.02 -
2002-04-16 (Vendicator):
	- Clearing new mail flag made previous left click action abundant, changed to check mail.

4.01 -
2002-04-15 (Vendicator):
	- Centered coordinates support
	- Clearing of new mail flag when server reports no mail.

4.0 -
XXXX-XX-XX (MrJukes)
	- Complete rewrite

==================================================================
E-mail mrjukes at mrjukes@purdue.edu with comments/suggestions/bugs.
Alternatively vendicator@mail.com.

Have fun,
	MrJukes, Vendicator