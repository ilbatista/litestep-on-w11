popen  by tnl (tnl ta asia tod com)


Introduction:
    popen is a module for LiteStep that, like other popen implementations,
    lets you run a command-line command without showing a command prompt.

    The popen function itself was lifted from 
    http://home.mweb.co.za/sd/sdonovan/popen.zip


Installation/loading:
  classic:
    Put this somewhere in step.rc or its included files..

    LoadModule "x:\path to\the\popen.dll"

  NetLoadModule:

    *NetLoadModule popen-0.1


Usage:
    !popen <command>

  Example:
    !popen dir /b /on /ad "$ThemesDir$">"$ConfigDir$themeslist.txt"


Versions:
    0.1: initial version.
