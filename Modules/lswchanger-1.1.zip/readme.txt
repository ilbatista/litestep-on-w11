		*************************************************
		* Wallpaper Changer module - Version 1.1 readme *
		*************************************************

	0. Contents
*******************

	1. Introduction
	2. Installation
	3. Reference
	   3.1. step.rc configuration
	   3.2, !bang commands
	4. About
	
	1. Introduction
***********************
	
	First of all, sorry for my bad grammatical errors, I hope you'll understand 
this piece! 

	This is yet another wallpaper changer module, with some extended features:

	- it can use a list with images in .BMP, .PCX, .JPG and .PNG file formats
	- it can change the current picture at a specified interval of time
	- and it can be controlled by using of !bang commands

	2. Installation
***********************

	1) Unzip lswchanger.dll
	2) Copy the file in Your LiteStep modules path
	3) Add lswchanger.dll to the list with modules loaded with LiteStep in step.rc
	4) Add images for Your desktop
	5) Recycle LiteStep

	This is a sample configuration of step.rc for use with lswchanger.dll:

LoadModule c:\LiteStep\Modules\lswchanger.dll

WallpaperEnabled true
WallpaperTimeOut 3
WallpaperDisplayMethod tile
WallpaperSelectMethod random

*wallpaper .tile c:\windows

	You can also add the flowing lines to Your popup configuration:

*Popup "Wallpaper" Folder
	*Popup "Backgrounds" Folder
		*Popup "Use blank" !wallpaper .none
		*Popup "Black Thatch.bmp" !wallpaper .tile c:\windows\Black Thatch.bmp
		*Popup "Blue Rivets.bmp" !wallpaper .tile c:\windows\Blue Rivets.bmp
		*Popup "Bubbles.bmp" !wallpaper .tile c:\windows\Bubbles.bmp
		*Popup "Carved Stone.bmp" !wallpaper .tile c:\windows\Carved Stone.bmp
		*Popup "Circles.bmp" !wallpaper .tile c:\windows\Circles.bmp
		*Popup "Clouds.bmp" !wallpaper .stretch c:\windows\Clouds.bmp
		*Popup "Forest.bmp" !wallpaper .stretch c:\windows\Forest.bmp
		*Popup "Gold Weave.bmp" !wallpaper .tile c:\windows\Gold Weave.bmp
		*Popup "Houndstooth.bmp" !wallpaper .tile c:\windows\Houndstooth.bmp
		*Popup "Metal Links.bmp" !wallpaper .tile c:\windows\Metal Links.bmp
		*Popup "Pinstripe.bmp" !wallpaper .tile c:\windows\Pinstripe.bmp
		*Popup "Red Blocks.bmp" !wallpaper .tile c:\windows\Red Blocks.bmp
		*Popup "Sandstone.bmp" !wallpaper .tile c:\windows\Sandstone.bmp
		*Popup "Setup.bmp" !wallpaper .stretch c:\windows\Setup.bmp
		*Popup "Stitches.bmp" !wallpaper .tile c:\windows\Stitches.bmp
		*Popup "Straw Mat.bmp" !wallpaper .tile c:\windows\Straw Mat.bmp
		*Popup "Tiles.bmp" !wallpaper .tile Red c:\windows\Tiles.bmp
		*Popup "Triangles.bmp" !wallpaper .tile c:\windows\Triangles.bmp
		*Popup "Waves.bmp" !wallpaper .tile c:\windows\Waves.bmp
	*Popup ~Folder
	*Popup "View" Folder
		*Popup "Tiled" !wallpaper .tile
		*Popup "Centered" !wallpaper .center
		*Popup "Stretched" !wallpaper .stretch
	*Popup ~Folder
	*Popup  "TimeOut" Folder
		*Popup "1 minute" !wallpaper .timeout 1
		*Popup "2 minutes" !wallpaper .timeout 2
		*Popup "3 minutes" !wallpaper .timeout 3
		*Popup "4 minutes" !wallpaper .timeout 4
		*Popup "5 minutes" !wallpaper .timeout 5
	*Popup ~Folder
	*Popup "Change" !wallpaper .change
	*Popup "Mix" !wallpaper .mix
	*Popup "Enable" !wallpaper .on
	*Popup "Disable" !wallpaper .off
*Popup ~Folder
	
	3. Reference
********************

	3.1. step.rc configuration
        **************************

WallpaperEnabled <false>|<true>   		    - Disables/Enables wallpaper 
						      changing at specified interval 
						      of time

WallpaperTimeOut <integer>			    - Sepcifies the timeout interval

WallpaperSelectMethod <normal>|<sorted>|<random>    - Specifies how to select the 
						      pictures from the list

*Wallpaper <.tile>|<.center>|<.stretch> <path>	    - Adds image(s) to the list, where 
						      path can be a single file or a 
						      directory with pictures

	3.2. !bang commands
        *******************

!wallpaper <.on>|<.off>				    - Disables/Enables wallpaper 
						      changing at specified interval 
						      of time

!wallpaper <.timeout> <integer>			    - Sepcifies the timeout interval

!wallpaper <.change>				    - Changes the wallpaper immediately

!wallpaper <.none>				    - Disables the background image

!wallpaper <.tile>|<.center>|<.stretch> [path]	    - Sets the display method for the 
                                                      current image, when a file is 
                                                      specified the wallpaper is set 
                                                      to him

!wallpaper <.clear>				    - Clears the images list in the memory

!wallpaper <.mix>				    - Mixes the images list

!wallpaper <.sort>				    - Sorts the images list

	4. About
****************

	I am Tzvetan Raikov, I am from Bulgaria and now I am study at Sofia university. To 
send a bug reports, when you have good ideas, or to contact with me you can use:

	e-mail:	craikov@hotmail.com
	www:	http://www.geocities.com/wchangerbg
