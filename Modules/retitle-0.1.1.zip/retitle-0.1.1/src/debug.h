#ifndef __RETITLE_DEBUG_
#define __RETITLE_DEBUG_

#ifdef _DEBUG
#  ifdef _MSC_VER
#    define _CRTDBG_MAP_ALLOC 
# endif
#endif

#include <assert.h>
#include <crtdbg.h>

#ifdef _DEBUG

# define _DPRINT _dprint_debug
# define ASSERT_PROMPT(x) do { if (!(x)) assert_prompt(x) } while (0)
# define DMALLOC_CHECK() 
# ifndef ASSERT
#  define ASSERT(x) assert(x)
# endif

#else

# define _DPRINT _dprint_debug
# define ASSERT_PROMPT(x) 
# define DMALLOC_CHECK()
# ifndef ASSERT
#  define ASSERT(x) 
# endif

#endif

#ifdef __cplusplust
extern "C" {
#endif

static void _assert_prompt(const char * fmt)
{
	int i;
	i = MessageBox(NULL, fmt, "Drop to debugger?", MB_YESNO | MB_TASKMODAL  | MB_ICONQUESTION );
	if (i == IDYES) {
#ifdef _M_IX86
		__asm { int 3 };
#else
		assert(0);
#endif
	}
}

static void _dprint_dummy(const char * fmt, ... )
{
}

static void _dprint_debug(const char * fmt, ... )
{
	va_list args;
	char dbuf[1024]; 

	va_start(args, fmt);
	
	_vsnprintf(dbuf, 1024, fmt, args);
	dbuf[1023] = 0;
	
	OutputDebugString(dbuf);
	
	va_end(args);

}

#ifdef __cplusplust
}
#endif

#endif