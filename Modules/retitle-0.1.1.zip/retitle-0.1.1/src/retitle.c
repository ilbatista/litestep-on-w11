/*
 * retitle.c
 * Copyright 2001, Mudiaga Obada
 *
 *	Permission is granted to anyone to use this software for any
 *	purpose on any computer system, and to redistribute it freely,
 *	subject to the following restrictions:
 *
 *	1. The author is not responsible for the consequences of use of
 *		this software, no matter how awful, even if they arise
 *		from defects in it.
 *
 *	2. The origin of this software must not be misrepresented, either
 *		by explicit claim or by omission.
 *
 *	3. Altered versions must be plainly marked as such, and must not
 *		be misrepresented as being the original software.
 *
 */

#include <windows.h>
#include <stdlib.h>
#include <string.h>

#include <lsapi/lsapi.h>

#include "debug.h"

#include <regexp.h>


#undef STORE_MATCH_RE /* compile match string but store in memory. don't know why yet */


/* 
 * lame that ls wants a window for callbacks
 * to display module info - retro will fix that.
 */
static const char app_name[] = "reTitle";
static const char about_str[] = "reTitle 0.1 (c) 2001, Mudiaga Obada";

static CRITICAL_SECTION retitle_mutex;

/* 
 * if we take up mem, we sould be useful ;-)
 */
static const char * freebeer_re[] = {
		
		"(.*)Microsoft (.*-|[a-zA-Z]*)([- ])*(.*)", "\\1\\4",
		"(.*)Mozilla ({.*})?(.*)", "moz \\1\\3",
		"(.*) *-( *)?$", "\\1", /* strip trailing junk */
		NULL
};


#define __RETITLE_PRIVATE_

#include "retitle.h"

#define RETITLE_ITEM_MAGIC 0xEE441199

typedef struct re_item re_item;


typedef struct settings_data_t {

	int one_match_only;

} settings_data_t;

static settings_data_t settings_data = { FALSE };
static settings_data_t * settings = &settings_data;


typedef struct context_data_t {
	re_item * re_list_head;
	re_item * re_list_tail;
} context_data_t;
static context_data_t context_data = { NULL, NULL};
static context_data_t * context = &context_data;


typedef struct re_item {
	int magic;
	re_item * next;
	regexp * re;		   /* precompiled re - no vars in re so all we need ...*/
	const char * subst_re;

#ifdef STORE_MATCH_RE
	const char * match_re; /* debug */
#endif

};

BOOL (WINAPI * _TryEnterCriticalSection)(LPCRITICAL_SECTION p);

/* some win9x user fix this... ms hates you, i don't want events */
static BOOL WINAPI winTryEnterCriticalSection(LPCRITICAL_SECTION p) 
{
	EnterCriticalSection(p);
	return TRUE;
}


static struct re_item * 
re_item_alloc()
{
	struct re_item * p = (struct re_item *) malloc(sizeof(struct re_item));
	if (p) {
		p->magic = RETITLE_ITEM_MAGIC;
		p->next = NULL;
	}
	return p;
}

static void
re_item_free(re_item * item)
{
	ASSERT(item);
	if (!item) {
		return;
	}
	
	ASSERT(item->magic == RETITLE_ITEM_MAGIC);	
	ASSERT(item->subst_re);

	regfree(item->re);

	free((void *)item->subst_re);		

#ifdef STORE_MATCH_RE
	if (item->match_re) {
		free((char *)item->match_re);
	}
#endif

	free(item);

}


static void
re_list_destroy() 
{
	
	re_item * item;
	re_item * next_item;

	if (! context->re_list_head) {
		return;
	}
	
	for (item = context->re_list_head; item; item = next_item) {
		next_item = item->next;
		re_item_free(item);		
	}

	context->re_list_head = NULL;
	context->re_list_tail = NULL;

}

static void 
re_list_init()
{
	ASSERT(context);
	ASSERT(context->re_list_head == NULL);
	ASSERT(context->re_list_tail == NULL);

	context->re_list_head = NULL;
	context->re_list_tail = NULL;

}


static struct re_item *
re_list_append(const char * match_expr, const char * subst_expr) 
{
	struct re_item * item;
	char * s = NULL;
	char * m = NULL;
	int i, ii;

	ASSERT(match_expr);
	ASSERT(subst_expr);

	if (! (match_expr && subst_expr)) {
		return NULL;
	}

	do {

		item = re_item_alloc();
		if (! item) {
			break;
		}

		i = strlen(match_expr);
		ii = strlen(subst_expr);
		if (i == 0 || ii == 0) {
			/* DOC: substituting everything with null is invalid */
			break;
		}

		s = malloc(ii+sizeof(*subst_expr));
		if (! s) {
			break;
		}
		strcpy(s, subst_expr);
		item->subst_re = (const char *)s;

		item->re = regcomp(match_expr);
        if (! item->re) {
			//litelog(MODULE_NAME, "crit", "bad regex");
			break;
		}


#ifdef STORE_MATCH_RE
		m = malloc(ii+sizeof(*match_expr));
		if (m) {
			strcpy(m, match_expr);
		}
		item->match_re = m;
#endif

		if (context->re_list_head == NULL) {
			context->re_list_head = item;
		}
		if (context->re_list_tail != NULL) {
			context->re_list_tail->next = item;
		}
		context->re_list_tail = item;

		return item;

	} while (0);

	/* clean up */
	if (item) free(item);
	if (s) free(s);
	if (m) free(m);

	return NULL;
}


/*
 * tokenize lbuf s/p0/p1/ , set in p0 and p1
 * return true of all goes well
 */

static int
parse_s_line(char * lbuf, int lineno, char ** p0, char ** p1)
{

	char * p = lbuf;

	do {
		/*
		 * m/".*?", "[^\"]*"/
		 */		
		if (! *p ) {
			_DPRINT("retitle:parse_s_line() got zero length string. why?");
		}

		if (*p != '"') {
			_DPRINT("retitle: ignoring line %d that doesn't start with '\"' - %s", lineno, lbuf);
			break;	
		}
		
		*p0 = ++p;
		p = strstr(p+1, "\", ");
		if (! p) {
			_DPRINT("retitle: ignoring line %d without '\", \"' - %s", lineno, lbuf);
			break;	
		}
		*p = '\0';

		p += 2;
		p += strspn(p, " \t");
		if (*p != '"') {
			_DPRINT("retitle: ignoring line %d without '\"' after '\", \"' - %s", lineno, lbuf);
			break;	
		}
		
		*p1 = ++p;
		p += strcspn(p, "\"");
		if (! (p > *p1)) {
			_DPRINT("retitle: ignoring line %d unexpected EOS - %s", lineno, lbuf);
			break;
		}
		*p = '\0';
		// warn about trailing junk?

		return TRUE;

	} while (0);

	return FALSE;
}

static void
read_config()
{
	
	FILE * f = NULL;
	char fnbuf[MAX_LINE_LENGTH+MAX_LINE_LENGTH]; 
	char lbuf[512];
	char * p, * p0, * p1;
	int lineno = 0;
	int ii = MAX_LINE_LENGTH;


	strcpy(fnbuf, "");
	lbuf[sizeof(lbuf)] = 0;
	

	// NOTE: mscrt debug_malloc goes crazy when fnbuf is malloc'ed...
	// and it's not VarExpansion's fault..
		

	VarExpansion(fnbuf, "$reTitleFile$");
	if (fnbuf[0] == '\0') {
		VarExpansion(fnbuf, "$LiteStepDir$");
		strcat(fnbuf, "retitle.ini");
	}


	do {

		
		if (strlen(fnbuf) == 0) {
			_DPRINT("retitle: config file path not set in $reTitleFile$");
			break;
		}

		f = fopen(fnbuf, "rt");
		if (! f) {
			_DPRINT("retitle: can't open your config file %s", fnbuf);
			break;;
		}

		_DPRINT("retitle: parsing config file '%s'", fnbuf);
		while ((p = fgets(lbuf, sizeof(lbuf) - 1, f)) != NULL) {

			lineno++;
			p += strspn(p, " \t\n\r");
			if (*p == 0 || *p == '#' || *p == ';') {
				continue;
			}

			if (parse_s_line(lbuf, lineno, &p0, &p1)) {
				re_list_append(p0, p1);	
			} else {
				continue;
			}

		}


	} while (0);

	if (! GetRCBool("ReTitleNoFreeBeer", TRUE)) { /* DOC */
		int i;		
		for (i = 0; freebeer_re[i] != NULL; i += 2) {
			re_list_append(freebeer_re[i], freebeer_re[i+1]);
		}

	}
	
	if (f) {
		fclose(f);
	}
	
	
	return;
}

static void 
do_reload()
{
	re_list_destroy();	
	re_list_init();	
	read_config();
}


/*
 * this thing will go in own DLL
 * we also need it for tasks.dll
 * but it's not even LS specific...
 */

/* 
  - returns true if dsbuf contains new string 
  - else there where no matches
 */

static int
retitle_entry(const char * real_title, char * dstbuf, size_t dstbuf_sz) 
{

	const char * title;
	re_item * item;    
	int i, x;
        
	ASSERT(dstbuf);

	if (! dstbuf) {
        return 0;
    }

	/* we're not important enuf to wait for */
	for (i = 0; i < 2; i++) {
		x = _TryEnterCriticalSection(&retitle_mutex);
		if (x) {
			break;
		}
		Sleep(100);
	}
	if (!x) {
		return FALSE;
	}


	title = real_title;

    for (item = context->re_list_head; item != NULL; item = item->next) {
		
        ASSERT(item->magic == RETITLE_ITEM_MAGIC);
		ASSERT(item->re);
		
        if (!item->re) {
			continue;
		}
		
		if (regexec(item->re, title)) {
			
			regsubn(item->re, item->subst_re, dstbuf, dstbuf_sz);

			if (title != dstbuf) {
				/* futher regexec on dstbuf, and also our 'matched' flag */
				title = dstbuf;
			}			
		
			if (settings->one_match_only) {
				/* we usually don't break on 1st match */
				break;
			}
		}		
    }

	LeaveCriticalSection(&retitle_mutex);

	return (title == dstbuf);

}

#pragma warning(disable:4100)

void make_retitle_public(retitle_pointer_t retitle_addr_or_null) 
{
	char var[64];
	char buf[64];

	DWORD pid = GetCurrentProcessId();

	if (retitle_addr_or_null) {
		/* LM_ not to be considered... */
		sprintf(var, "RETITLE_ADDRESS_0x%X", pid);
		sprintf(buf, "retitle@0x%X", retitle_entry);
		SetEnvironmentVariable(var, buf);
	} else {

		sprintf(var, "RETITLE_ADDRESS_0x%X", pid);
		SetEnvironmentVariable(var, NULL);

	}
}


int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, const char* szPath)
{
	int i;
	int ret;
	HANDLE hlib;

	ASSERT(settings);
	ASSERT(context);

	InitializeCriticalSection(&retitle_mutex);

	do {
		hlib = LoadLibrary("kernel32.dll");  /* no, we won't be unloading it.. */
		if (hlib) {
			_TryEnterCriticalSection = (BOOL (WINAPI *)(LPCRITICAL_SECTION p)) GetProcAddress(hlib, "TryEnterCriticalSection");
		}
		if (_TryEnterCriticalSection) {
			break;
		}
		_TryEnterCriticalSection = winTryEnterCriticalSection;
	} while (0);
	
	
	i = _TryEnterCriticalSection(&retitle_mutex);
	if (! i) {
		/* we want to be thread safe */
		_DPRINT("retitle: can't EnterCriticalSection");
		return TRUE;
	}

	do {
		if (retitle_get_pointer() != NULL) {
			_DPRINT("retitle: hook in place - won't load");
			ret = TRUE;
			break;
		}
	
		/* hook into system */	
		make_retitle_public(retitle_entry);
		if (retitle_get_pointer() != retitle_entry) {
			_DPRINT("can't hook self - won't init");
			ASSERT(0);
			ret = TRUE;
			break;
		}
	
		/*
		 * DOC:
		 * you set this when you want only one rule to match
		 */
		settings->one_match_only = GetRCBool("ReTitleOneMatchOnly", TRUE);

		re_list_init();	
		read_config();
		
		AddBangCommand("!retitleReload", (void *)do_reload);

	} while (0);

	LeaveCriticalSection(&retitle_mutex);

	return ret;

}

void quitModule(HINSTANCE dllInst)
{
	int i, x;
	
	/* if we can't get it in 1 sec - go ahead all the same */
	for (i = 0; i < 4; i++) {
		x = _TryEnterCriticalSection(&retitle_mutex);
		if (x) {
			break;
		}
		Sleep(250);
	}
	if (! x) {
		_DPRINT("retitle:quit(); can't EnterCriticalSection");
	}

	make_retitle_public(NULL);

	if (retitle_get_pointer() != NULL) {
		_DPRINT("retitle:quit() can't unhook self");
	}

	re_list_destroy();

	DeleteCriticalSection(&retitle_mutex);

	return;

}
