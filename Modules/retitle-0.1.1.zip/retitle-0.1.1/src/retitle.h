/*
 * retitle.h
 * Copyright 2001, Mudiaga Obada
 *
 *	Permission is granted to anyone to use this software for any
 *	purpose on any computer system, and to redistribute it freely,
 *	subject to the following restrictions:
 *
 *	1. The author is not responsible for the consequences of use of
 *		this software, no matter how awful, even if they arise
 *		from defects in it.
 *
 *	2. The origin of this software must not be misrepresented, either
 *		by explicit claim or by omission.
 *
 *	3. Altered versions must be plainly marked as such, and must not
 *		be misrepresented as being the original software.
 *
 */

#ifndef __RETITLE_H_
#define __RETITLE_H_

/*
 * we have static functions in here
 * include now.
 */
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

#define API_EXPORT __declspec(dllexport)
#define API_IMPORT __declspec(dllimport)

#ifdef __RETITLE_PRIVATE_
#define API_FUNC API_EXPORT
#else
#define API_FUNC API_IMPORT
#endif


#ifdef __RETITLE_PRIVATE_

#define API_FUNC API_EXPORT

API_FUNC int initModuleEx( HWND, HINSTANCE, LPCTSTR);
API_FUNC void quitModule( HINSTANCE );

#endif

typedef BOOL (*retitle_pointer_t)(const char * title, char * newtitle, size_t newtitle_sz);

static retitle_pointer_t 
retitle_get_pointer() 
{

	/*
	 * reads out address from ENVIRONMENT
     * almost anybody can fool you you know...
     */

   /* 
    * unfortunately i haven't yet found the lsapi for this ... 
	* what?! there isn't any? ony LM_*?
	* the idea is to save loadlib, {load}, getproc..
	* are allow reloads... 
	*/

	retitle_pointer_t ptr;
	char var[64];
	char buf[64];
	char junk;
	int i;
	DWORD pid = GetCurrentProcessId();

	sprintf(var, "RETITLE_ADDRESS_0x%X", pid);
	i = GetEnvironmentVariable(var, buf, sizeof(buf));
	if (i > sizeof("retitle")) {
		i = sscanf(buf, "retitle@0x%X%c", &ptr, & junk);
		if (i == 1) {
			return ptr;
		}	
	}

	return NULL;

}

static __inline int
retitle_caller(const char * title, char * newtitle, size_t newtitle_sz) 
{


	retitle_pointer_t ptr;
	
	/* no, we do not cache the pointer.. */
	ptr = retitle_get_pointer();
	if (ptr != NULL) {
		return ptr(title, newtitle, newtitle_sz);		
	}	
	
	return FALSE;
}


#ifdef __cplusplus
}
#endif


#endif /*__ACTIVETASKS_H_*/

