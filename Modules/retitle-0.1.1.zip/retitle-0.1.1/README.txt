retitle-0.1.1 

Ever been happy about your taskbar entries showing only unless information
like application or company name although you can see the application icon?

The solution is here. Are you ready? You need to know what regular expressions
are. If you know grep, sed, perl, etc... then you are at home here.
If not, it's easy to learn.

1. see tasks.dll in screenshot tasks-0.92-retitle.gif for what retitle.dll does

2. read src/retitle.txt for more information

3. LoadModule the supplied tasks.dll and retitle.dll
   and be happy ever after... or whatever!

This archive very probably came from
Mudiaga Obada <mudi@obada.de>
