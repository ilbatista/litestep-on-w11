                    *************************
                    *      LSWallPaper      *
                    *      by Visigoth      *
                    *    ==============     *
                    *     Version: 1.0      *
                    *************************

Table of Contents
=================
I.   About LSWallPaper
II.  How to Use LSWallPaper

     II.1 Installation
     II.2 RC Commands
          - WallPaperBitmapPath
          - WallPaperTimeDelay
          - WallPaperListPath
          - WallPaperSequenced
          - WallPaperStartup
     II.3 !Bang Commands
          - !NextWallPaper
          - !PreviousWallPaper
          - !RescanWallPaperList
          - !AboutLSWallPaper
     II.4 The wallpapers.list File

III. Known Bugs/Limitations

     III.1 Bitmaps ONLY
     III.2 LSWallPaper doesn't Check Existance
     III.3 Random doesn't always work

IV.  Future Enhancements

     IV.1 Wharf Bar Integration
     IV.2 Specific Wallpaper Selection

V.   Comments/Questions/Flames/Bug Reports
VI.  Source Code
VII. Source Code License


I. About LSWallPaper
====================
   LSWallPaper is a Litestep module which changes, sequentially or
   randomly, your desktop wallpaper.  It was originally created by
   Visigoth (aka Shaheen Gandhi) because I had a program that did
   this for me, but I just wanted to get rid of another system
   tray icon!  Just a quick note: I'd really like to know if
   people are using this thing.  Just drop me an e-mail at
   gandhimail@worldnet.att.net  or  sgandhi@andrew.cmu.edu


II. How to Use LSWallPaper
==========================

   II.1 Installation
   -----------------
   There's actually a lot to do for installing this thing, so pay
   attention!

   First, extract lswallpaper.dll to your modules directory.

   Second, your step.rc must be edited to load the module.  Add the
   following line to your step.rc.  To be safe, I added it after
   the desktop.dll, because, well, without a desktop, there's no
   wallpaper.

     LoadModule <ModuleDirectory>\lswallpaper.dll     ; LSWallPaper

   The next few sections detail the commands and !bang commands
   available to you.


   II.2 RC Commands
   ----------------
   The following is a list of RCCommands you may add to your step.rc
   to control certain LSWallPaper properties.

     WallPaperBitmapPath
     ```````````````````
     Description: The path LSWallPaper uses as the place to find
     wallpapers.  ie. C:\Litestep\Wallpapers...

     Default: PixmapPath

     Note: If PixmapPath is not available, LSWallPaper will not be
     able to use any of your wallpapers, unless you specify all
     of your wallpapers with absolute paths in your wallpapers.list
     (see below for more information about wallpapers.list).
     IMPORTANT: This path must be absolute.

     Example: WallPaperBitmapPath   C:\Litestep\Wallpapers


     WallPaperTimeDelay
     ``````````````````
     Description: The time interval used between wallpaper changes.

     Default: 00:00:00  (hours:minutes:seconds)

     Note: The default time interval (00:00:00) means the wallpaper
     stays constant.  There is no change of wallpaper after
     LSWallPaper has initialized.  IMPORTANT: I strongly recommend
     keeping this above 30 seconds (00:00:30).  It gets annoying
     and potentially dangerous to Windows.

     Example: WallPaperTimeDelay    6:00:00   ; Change every 6 hours


     WallPaperListPath
     `````````````````
     Description: The path to your list of wallpapers.

     Default: <ModulesDirectory>\wallpapers.list

     Note: The default occurs because LSWallPaper assumes the list of
     wallpapers is in its own directory.  This file does not have to
     be wallpapers.list.  It may be wallpapers.txt, for instance.
     IMPORTANT: This path must be absolute.

     Example: WallPaperListPath     C:\Litestep\wallpapers.list


     WallPaperSequenced
     ``````````````````
     Description: Turns on In-Sequence processing of the wallpaper
     list.  If left off, your wallpapers will change randomly with
     respect to the list of wallpapers.  If on, your wallpaper list
     will be followed line by line.

     Default: 0 (If it is left out of step.rc, it is considered off)

     Example: WallPaperSequenced


     WallPaperStartup
     ````````````````
     Description: Change the wallpaper at startup.

     Default: 0 (If it is left out of step.rc, it is considered off)

     Note: If WallPaperTimeDelay is left to be 00:00:00, you will
     probably want to use this.  If not, LSWallPaper would do
     nothing.

     Example: WallPaperStartup


   II.3 !Bang Commands
   -------------------
   !Bang Commands can be bound to keys, shortcuts, wharf items, etc.
   The following is a description of all the !Bang Commands
   LSWallPaper can handle.

     !NextWallPaper
     ``````````````
     Description: Change to the Next WallPaper and resets the Timer.

     Note: If you have not specified WallPaperSequenced in your
     step.rc, this will use a random wallpaper from the list of
     wallpapers.


     !PreviousWallPaper
     ``````````````````
     Description: Change to the Previous Wallpaper and resets the
     Timer.

     Note: As with !NextWallPaper, if you have not specified
     WallPaperSequenced in your step.rc, this will use a random
     wallpaper from the list of wallpapers.  Meaning, if it is
     random, it will *not* be the same wallpaper you had before.


     !RescanWallPaperList
     ````````````````````
     Description: Rescans the list of wallpapers.

     Note: This does not change the wallpaper, but only retrieves
     the path and tile information about wallpapers. 


     !AboutLSWallPaper
     `````````````````
     Description: Brings up a message box with a little information
     about LSWallPaper.  Nothing special, for now :)


   II.4 The wallpapers.list File
   -----------------------------
   Note: This file does not have to be named wallpapers.list.  It may
   be called anything else, this is just descriptive.

   This file tells LSWallPaper how to use each file in your
   BitmapPath.  Also, each wallpaper you want to use must be listed
   in this file.

   Comments: Comments may be done in the C++ fashion: by starting the
   comment with '//'.  The rest of the line is ignored.

   File Setup: Basically, each line is a new wallpaper.  And each
   line is structured like this:

     [Path to Wallpaper]       [Tiled]

   Note: [Path to Wallpaper] may be an absolute or relative path. So,
   if you have one wallpaper that is not in your BitmapPath, you can
   just specify the entire path here instead of a relative one.

     Sample wallpapers.list File
     ```````````````````````````
     The following is a small list file.

       //This is a comment, and the beginning of the file
       Wallpaper1.bmp      0  //Relative path, no tiling.
       C:\Windows\tileable.bmp     1  //Absolute path, tiled.


III. Known Bugs/Limitations
===========================

   III.1 Bitmaps ONLY
   ------------------
   LSWallPaper can only accept bitmap files at this point.  This is
   because the file is passed directly to windows, which only
   understands bitmap files, unless Active Desktop is on.  And we all
   hate Active Desktop, right?


   III.2 LSWallPaper Doesn't Check Existance
   -----------------------------------------
   If you specify, in wallpapers.list, a file that does not exist,
   your desktop will become the background color.  This is because
   of two reasons:  1) Windows doesn't check that the wallpaper
   exists, and 2) LSWallPaper doesn't check that the wallpaper
   exists.  I plan to add this in future revisions.


   III.3 Switching from Random to Sequenced doesn't work
   -----------------------------------------------------
   If you switch from Random to Sequenced, it will not work the first
   time around that you recycle/reboot.  I don't know why yet, but am
   working on it.  The second time, however, it will continue normal
   operation under the mode you selected (sequenced or random).


IV. Future Enhancements
=======================

   IV.1 Wharf Bar Integration
   --------------------------
   I'm looking for a way to integrate this into the Wharf Bar.
   If any of you who know good UI development and such want to do
   something like this, here's an idea I've had:  The module could
   be something like LSCDPlay (or other skinnable wharf cd players).

   Basically, there would be an area for the time left until the next
   wallpaper change.  Also, there would be three buttons attached to
   the !Bang Commands: Next, Previous, and About Box.  That's all
   there really is, but more might come up...

   If you decide to do something like this, READ SECTIONS VI AND VII
   of this readme.


   IV.2 Specific Wallpaper Selection
   ---------------------------------
   Another thing I'm looking into is a way to specifically pick a
   wallpaper.  I'm not sure how to make !Bang Commands accept
   arguments.  If there is a way, then it could be made the way
   AfterStep works - by passing the name of the wallpaper to the
   !Bang Command.  However, another way would be to add a feature to
   the wharf bar integration I described above; maybe a drop down
   list of the available wallpapers that the user selects from.


V. Comments/Questions/Flames/Bug Reports
========================================
   All of these should be sent directly to me, visigoth.  My e-mail
   address is:  gandhimail@worldnet.att.net

   Seriously, though, I really would like to know if people are using
   this thing.  It'll help me determine whether it's worth comtinuing
   the development of it.


VI. Source Code
===============
   Yes, source code is available.  All you have to do is send me an
   e-mail for it.  My e-mail is gandhimail@worldnet.att.net
   However, if you are going to edit the code, *please* read the
   Source Code License below.  There are certain restrictions.


VII. Source Code License
========================

   Article I. Sure, Have the Code!
   -------------------------------
   I don't want to stop progress on this module.  So, I'm going to
   let anyone who wants to edit the code, do so at his/her free will.
   However, there are restrictions, as noted by the rest of the
   license.

   Article II. Redistribution
   --------------------------
   This file *must* be redistributed with the source code, with duly
   noted changes to sections I, II, III, and IV.  However, I request
   that my name be left in Section I as the original author of the
   module

   Article III. Leave Credit where It's Due!
   -----------------------------------------
   All I ask is that Section I still have my name in it as the
   original author.  And, that the !AboutLSWallPaper be renamed
   if it must, but the original about box should still be in the
   module and associated with a !Bang command.

   Article IV. Send Me Your Cool Stuff
   -----------------------------------
   I'd like to know about your ideas for LSWallPaper!  If you are
   working on an idea, I would like to know what it is.  I'm not like
   Microsoft (ie. I'm going to steal your idea, throw my time at it,
   and come out with a shoddier version first).  I'd just like to
   know what people are doing with my original code base.  So, if you
   do edit code for a purpose, please drop me a line as to what you
   are doing.

   Article V. Have Fun
   -------------------
   Remember, I'm not going to stop progress on this module, so go
   ahead and do what you want to it.  Just don't take credit for
   what I've already done.