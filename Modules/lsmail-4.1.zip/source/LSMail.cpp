/****************************************************************************

Todo:
	- Multiple settings, bitmaps a la label?
	- Test !refresh

Changelog:

2002-08-18 (Vendicator):
	- Filesize slashed with about 50k, had to use ugly hack by adding hWnd2 as a public HWND for external funtions
	- Added setting to disable mail check "LSMailDisableCheck", use bangs to enable
	  in runtime: !LSMailToggleCheck, !LSMailEnableCheck, !LSMailDisableCheck
	- Added !LsMailMove x y
	- Added LSMailErrorBmp, LSMailBackErrorColor, LSMailErrorFontColor, LSMailErrorCmd per request of... sorry I forgot...
	- !Refresh support

2002-08-13 (Vendicator):
	- Big push towards more OOP
	- Even more code cleaning

2002-07-24 (Vendicator):
	- More move to OOP
	- Fixed memleak in !bang commands removal when recycling
	- Added !LsMailHook for lsbox support
	- Added LSMailNoMessageBoxes, which sends errors as warnings to log file
	- Started rewrite to a more OOP layout, will make it easier to add other server types
	- Added LSMailDoneCheckCmd, per request of Maestr0

2002-05-29 (Vendicator):
	- Added a check so that the password actually is set in .rc if not old style is used
	- LsMail no longer shows up in taskmanager
	- Added killing of lsmail thread on quit, might fix the ls crash on recycle when lsmail was checking.
	- Added LSMailCheckMailCmd, per request of morph, originally added by ilmcuts

2002-05-11 (Jesus_mjjg):
	- now it is possible to specify the password in the step.rc

2002-04-18 (Vendicator):
	- Added a !bang for when there is no mail (LSMailNoMailCmd	!bang)

2002-04-17 (Vendicator):
	- Implemented bitmap for checking state (LSMailCheckingBmp)
	- Fixed clearing/setting of new mail flag (was only taking one server into account before)
	- Added ability to execute a !bang command on new mail (LSMailNewMailCmd	!bang)

2002-04-16 (Vendicator):
	- Clear new mail in popup now works again (was tied to left click action)

2002-04-16 (Vendicator):
	- Since the mail checking routine also clears the new mail flag when
	there is no mail on server, left click action is now checkmail.

2002-04-15 (Vendicator):
	- Added X,Y reading through GetRCCooridinate
	- Now clears new mail flag if 0 mail found on server

****************************************************************************/

// for server debugging:
//#define DEBUG_SERVER

// for message debugging:
//#define DEBUG_SPAM

#include "LsMail.h"

LsMail *mail; // The module

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	mail = new LsMail(ParentWnd, code, dllInst);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
  delete mail;
}


//=========================================================
// Bang commands
//=========================================================

void BangHook(HWND caller, LPCTSTR szArgs)
{
	LSLog(LOG_DEBUG, szAppName, "Attempting to hook to LSBox");
	char *handle = strrchr(szArgs,' ');
	if (handle) 
	{
		HWND boxwnd = (HWND)atoi(handle+1);
		if (boxwnd) 
		{
			mail->lsboxed = TRUE;
			if (boxwnd != GetParent(mail->hWnd2))
			{
				SetWindowLong(mail->hWnd2, GWL_STYLE, (GetWindowLong(mail->hWnd2, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
				SetParent(mail->hWnd2, boxwnd);
			}
			LSLog(LOG_DEBUG, szAppName, "Hooking to LSBox successful");
		}
		else
			LSLog(LOG_DEBUG, szAppName, "Hooking to LSBox failed");
	}
	return;
}

void BangShow(HWND caller, const char* args)
{
	ShowWindow(mail->hWnd2, SW_SHOW);
}

void BangHide(HWND caller, const char* args)
{ 
	ShowWindow(mail->hWnd2, SW_HIDE);
}

void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(mail->hWnd2))
		BangHide(caller, args);
	else
		BangShow(caller, args);
}

void BangCheckMail(HWND caller, const char* args)
{
	mail->CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &mail->threadID);
}

void BangToggleCheck(HWND caller, const char* args)
{
	mail->bDisableCheck = !mail->bDisableCheck;
}

void BangEnableCheck(HWND caller, const char* args)
{
	mail->bDisableCheck = TRUE;
}

void BangDisableCheck(HWND caller, const char* args)
{
	mail->bDisableCheck = FALSE;
}

void BangMove(HWND caller, const char *args)
{
	char szX[MAX_LINE_LENGTH], szY[MAX_LINE_LENGTH];
	char *tokens[2] = {szX, szY};
	LCTokenize( args, tokens, 2, NULL );
	mail->Move(atoi(szX), atoi(szY));
}

//=========================================================
// Module code
//=========================================================

void LsMail::Size(int x_size, int y_size)
{
	SetWindowPos(hWnd, NULL, 0, 0, x_size, y_size, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
}

void LsMail::Move(int x_pos, int y_pos)
{
	if (x_pos < 0) x += GetSystemMetrics(SM_CXSCREEN);
	if (y_pos < 0) y += GetSystemMetrics(SM_CYSCREEN);

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "new pos: x:%d,y:%d", x_pos, y_pos);
#endif

	SetWindowPos(hWnd, NULL, x_pos, y_pos, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}

void LsMail::SetWindowBitmapRgn(HBITMAP bmp)
{
	if (hWnd && bmp)
	{
		int x=0, y=0;
		HDC hdc = CreateCompatibleDC(NULL);
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;

		GetObject(bmp, sizeof(bitmap), &bitmap);
		SelectObject(hdc, bmp);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y < bitmap.bmHeight; x=0, y++)
		{
			for (x=0; x < bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == 0x00FF00FF)
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hWnd, hMainRgn, FALSE);

		DeleteDC(hdc);
		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hWnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hWnd, rgn, FALSE);
	}
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------

LsMail::LsMail(HWND parentWnd, int& code, HINSTANCE dllInst):
	Window(szAppName),
	popup(NULL),
	lsboxed(FALSE),
	CHECKING(FALSE),
	NEWMAIL(FALSE),
	MAIL_STATUS(MAIL_NO),
	NewMailCmd(NULL),
	NoMailCmd(NULL),
	CheckMailCmd(NULL),
	DoneCheckCmd(NULL),
	NumServers(0)
{

	int msgs[] = {LM_GETREVID, LM_REPAINT, LM_REFRESH, 0};

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_WARNING, szAppName, "*Debug* Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#else
	LSLogPrintf(LOG_DEBUG, szAppName, "Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#endif

	memset(MAILCLIENT, 0, sizeof(MAILCLIENT)/sizeof(MAILCLIENT[0]) );
	memset(TEMP_PASS, 0, sizeof(TEMP_PASS)/sizeof(TEMP_PASS[0]) );
	memset(TEMP_SERVER, 0, sizeof(TEMP_SERVER)/sizeof(TEMP_SERVER[0]) );
	memset(ERR, 0, sizeof(ERR)/sizeof(ERR[0]) );

	hWndParent = parentWnd;
	hInstance2 = dllInst;

	LoadSetup();

	if ( !createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
                    x, y, w, h, parentWnd) )
	{
		LSLog(LOG_ERROR, szAppName, "unable to create window");
		MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
		code = 1;
		return;
	}
	else
	{
		hWnd2 = hWnd;
		LSLogPrintf(LOG_DEBUG, szAppName, "window created, 0x%X", hWnd);
	}

	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	bHidden = GetRCBool("LSMailStartHidden", TRUE);
	if (bHidden)
	{
		LSLog(LOG_DEBUG, szAppName, "Starting as hidden");
		ShowWindow(hWnd, SW_HIDE);
	}
	else
	{
		LSLog(LOG_DEBUG, szAppName, "Starting as shown");
		ShowWindow(hWnd, SW_SHOW);
	}

	bOnTop = GetRCBool("LSMailAlwaysOnTop", TRUE);
	if (bOnTop)
	{
		LSLog(LOG_DEBUG, szAppName, "Setting Ontop");
		SetWindowPos(hWnd2, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
	}
	else
	{
		LSLog(LOG_DEBUG, szAppName, "Normal Window, not ontop");
	}

	if (bgbmp && !USEBGCOLOR)
	{
		SetWindowBitmapRgn(bgbmp);
		LSLog(LOG_DEBUG, szAppName, "Setting window bitmap region");
	}

	AddBangCommand("!LSMailShow", BangShow);
	AddBangCommand("!LSMailHide", BangHide);
	AddBangCommand("!LSMailToggle", BangToggle);
	AddBangCommand("!LSMailCheckMail", BangCheckMail);
	AddBangCommand("!LSMailHook", BangHook);
	AddBangCommand("!LSMailToggleCheck", BangToggleCheck);
	AddBangCommand("!LSMailEnableCheck", BangEnableCheck);
	AddBangCommand("!LSMailDisableCheck", BangDisableCheck);
	AddBangCommand("!LsMailMove", BangMove);
  
	LSLog(LOG_NOTICE, szAppName, "loaded successfully");
	
	code = 0;

	CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
}

void LsMail::LoadSetup()
{
	LSLog(LOG_DEBUG, szAppName, "Loading setup...");

	int size;
	char temp[256];

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	bDisableCheck = GetRCBool("LSMailDisableCheck", TRUE);
	bNoMessageBoxes = GetRCBool("LSMailNoMessageBoxes", TRUE);

	x = GetRCCoordinate("LSMailX", 0, GetSystemMetrics(SM_CXSCREEN));
	y = GetRCCoordinate("LSMailY", 0, GetSystemMetrics(SM_CYSCREEN));
	w = GetRCInt("LSMailW", 400);
	h = GetRCInt("LSMailH", 25);

	TIMER=GetRCInt("LSMailTimer", 5);
	size = GetRCInt("LSMailFontSize", 12);
	GetRCString("LSMailFont", temp, "Arial", 256);
	font = CreateFont(size, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);
	color = GetRCColor("LSMailFontColor", 0x00FFFFFF);
	nmcolor = GetRCColor("LSMailNewMailFontColor", 0x000000FF);
	checkcolor = GetRCColor("LSMailCheckingFontColor", 0x000000FF);
	errorcolor = GetRCColor("LSMailErrorFontColor", 0x00FF0000);

	USEBGCOLOR = GetRCBool("LSMailBackColor", TRUE);
	if (USEBGCOLOR) 
	{
		bgcolor = GetRCColor("LSMailBackColor", 0x00000000);
		bgbrush = CreateSolidBrush(bgcolor);

		bgcolor = GetRCColor("LSMailBackNewMailColor", 0x000000FF);
		nmbgbrush = CreateSolidBrush(bgcolor);

		bgcolor = GetRCColor("LSMailBackCheckingColor", 0x00000000);
		checkbgbrush = CreateSolidBrush(bgcolor);

		bgcolor = GetRCColor("LSMailBackErrorColor", 0x00FF0000);
		errorbgbrush = CreateSolidBrush(bgcolor);
	}
	else {
		GetRCString("LSMailBackBmp", temp, "", 256);
		bgbmp = LoadLSImage(temp, temp);

		GetRCString("LSMailNewMailBmp", temp, "", 256);
		newmailbmp = LoadLSImage(temp, temp);

		GetRCString("LSMailCheckingBmp", temp, "", 256);
		checkingbmp = LoadLSImage(temp, temp);

		GetRCString("LSMailErrorBmp", temp, "", 256);
		errorbmp = LoadLSImage(temp, temp);
	}

	GetRCString("LSMailEMailClient", MAILCLIENT, "", MAX_PATH);

	if (TIMER)
		SetTimer(hWnd, 0, TIMER*60000, NULL);	
}

void LsMail::ReadServers()
{
	LSLog(LOG_DEBUG, szAppName, "Reading mail server configs");

	int i = 0;
	// *LSMailServer X Y Name host:<port> login
	FILE* step;
	char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], token6[4096], extra_text[4096];
	char*	tokens[6];

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	tokens[5] = token6;

	char temp[256];
	char stepRC[MAX_PATH];
	LSGetLitestepPath(stepRC, MAX_PATH);
	strcat(stepRC, "\\step.rc");
#ifdef DEBUG_SERVER
	LSLog(LOG_DEBUG, szAppName, "opening step rc");
#endif
	step = LCOpen(stepRC);
	
	while (LCReadNextConfig(step, "*LSMailServer", temp, 256)) 
	{
		i++;
		int count;
#ifdef DEBUG_SERVER
		LSLogPrintf(LOG_DEBUG, szAppName, "serverconfig %d", i);
#endif

		token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = extra_text[0] = '\0';
		count = LCTokenize (temp, tokens, 6, extra_text);

#ifdef DEBUG_SERVER
		LSLogPrintf(LOG_DEBUG, szAppName, "config parsed, found: %s", token4);
#endif

		if (count == 6)
		{
			NumServers++;
#ifdef DEBUG_SERVER
			LSLog(LOG_DEBUG, szAppName, "new server nr: %d", NumServers);
#endif
			
			SERVER* s = new SERVER(NumServers);

#ifdef DEBUG_SERVER
			LSLog(LOG_DEBUG, szAppName, "reading text pos");
#endif
			s->x = atoi(token2);
			s->y = atoi(token3);
			s->name = _strdup(token4);
			
			// blah.blah.blah.blah:80
			char* p = strtok(token5, ":");
			s->host = _strdup(p);
			p = strtok(NULL, "");
			if (p) s->port = atoi(p);
			else s->port = 110;
			
			s->login = _strdup(token6);
			if (extra_text[0] != '\0')
			{
#ifdef DEBUG_SERVER
				LSLog(LOG_DEBUG, szAppName, "Found password for mail server in config");
#endif
				s->password = _strdup(extra_text); //jesus_mjjg
			}

#ifdef DEBUG_SERVER
			LSLog(LOG_DEBUG, szAppName, "adding to menu");
#endif
			if (Servers)
				s->next = Servers;
			Servers = s;

#ifdef DEBUG_SERVER
			LSLog(LOG_DEBUG, szAppName, "checking for next server");
#endif
		}
	}
	LCClose(step);
	LSLogPrintf(LOG_DEBUG, szAppName, "Read %d servers", i);
}

void LsMail::onCreate(Message& message)
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "OnCreate accessed");
#endif

	ReadCommands();
	ReadServers();

	CreatePopup();
}

void LsMail::CreatePopup()
{
	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CHECKMAIL, "&Check Mail");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_LAUNCHCLIENT, "&Launch E-Mail Client");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CLEARNEWMAIL, "Clear &New Mail");
	//AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_ZEROACCOUNTS, "&Zero All Accounts");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_DISPLAYERROR, "&Display Last Error");
	AppendMenu(popup, MF_SEPARATOR, 0, "");

	for (SERVER* s=Servers; s; s=s->next)
	{
		s->menu = CreatePopupMenu();
		AppendMenu(s->menu, MF_ENABLED | MF_STRING, POPUP_SERVER+s->ID+1, "&Change Password");

		AppendMenu(popup, MF_ENABLED | MF_STRING | MF_POPUP, (int)s->menu, s->name);
	}
}

void LsMail::ReadCommands()
{
	char temp[MAX_LINE_LENGTH];
	memset(temp, 0, MAX_LINE_LENGTH);

	GetRCLine("LSMailCheckMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // new mail command
	CheckMailCmd = new char[strlen(temp)+1];
	strcpy(CheckMailCmd, temp);

	GetRCLine("LSMailNewMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // new mail command
	NewMailCmd = new char[strlen(temp)+1];
	strcpy(NewMailCmd, temp);

	GetRCLine("LSMailNoMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // no mail command
	NoMailCmd = new char[strlen(temp)+1];
	strcpy(NoMailCmd, temp);

	GetRCLine("LSMailDoneCheckCmd", temp, MAX_LINE_LENGTH, "!NONE"); // done check command
	DoneCheckCmd = new char[strlen(temp)+1];
	strcpy(DoneCheckCmd, temp);

	GetRCLine("LSMailErrorCmd", temp, MAX_LINE_LENGTH, "!NONE"); // error command
	ErrorCmd = new char[strlen(temp)+1];
	strcpy(ErrorCmd, temp);

}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
LsMail::~LsMail()
{
	int msgs[] = {LM_GETREVID, LM_REPAINT, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	RemoveBangCommand("!LSMailShow");
	RemoveBangCommand("!LSMailHide");
	RemoveBangCommand("!LSMailToggle");
	RemoveBangCommand("!LSMailCheckMail");
	RemoveBangCommand("!LSMailHook");
	RemoveBangCommand("!LSMailToggleCheck");
	RemoveBangCommand("!LSMailEnableCheck");
	RemoveBangCommand("!LSMailDisableCheck");
	RemoveBangCommand("!LsMailMove");

	destroyWindow();
}

void LsMail::onDestroy(Message& message)
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "OnDestroy accessed");
#endif

	if (CHECKING) // what about this? wait for module to close, or does it lock everything...
	{
		TerminateThread(CheckThread, NULL); // kill the checking thread.
		//Sleep(1000);
	}

	DeleteCommands();
	CleanUp();

}

void LsMail::DeleteCommands()
{
	if (NewMailCmd != NULL) {
		delete [] NewMailCmd;
		NewMailCmd = NULL;
	}
	if (NoMailCmd != NULL) {
		delete [] NoMailCmd;
		NoMailCmd = NULL;
	}
	if (CheckMailCmd != NULL) {
		delete [] CheckMailCmd;
		CheckMailCmd = NULL;
	}
	if (DoneCheckCmd != NULL) {
		delete [] DoneCheckCmd;
		DoneCheckCmd = NULL;
	}
	if (ErrorCmd != NULL) {
		delete [] ErrorCmd;
		ErrorCmd = NULL;
	}
}

void LsMail::CleanUp()
{
	DeleteObject(bgbrush);
	DeleteObject(nmbgbrush);
	DeleteObject(checkbgbrush);
	DeleteObject(errorbgbrush);
	DeleteObject(bgbmp);
	DeleteObject(newmailbmp);
	DeleteObject(checkingbmp);
	DeleteObject(errorbmp);
	DeleteObject(font);

	if (TIMER)
		KillTimer(hWnd, 0);

	SERVER *next;
	for (SERVER* s=Servers; s; s=next)
	{
		DestroyMenu(s->menu);
		next = s->next;
		delete s;
	}
	Servers = NULL;

	DestroyMenu(popup);
}

//=========================================================
// Registered messages
//=========================================================

void LsMail::windowProc(Message& message)
{

#ifdef DEBUG_SPAM
	LSLogPrintf(LOG_DEBUG, szAppName, "Message: %X", message.uMsg) ;
#endif

	BEGIN_MESSAGEPROC
		MESSAGE(onEraseBg,		WM_ERASEBKGND)
		MESSAGE(onEndSession,	WM_ENDSESSION)
		MESSAGE(onEndSession,	WM_QUERYENDSESSION)
		MESSAGE(onGetRevId,		LM_GETREVID)
		MESSAGE(onMouse,		WM_RBUTTONDOWN)
		MESSAGE(onMouse,		WM_LBUTTONUP)
		MESSAGE(onCreate,		WM_CREATE)
		MESSAGE(onDestroy,		WM_DESTROY)
		MESSAGE(onRefresh,		LM_REFRESH)
		MESSAGE(onSysCommand,	WM_SYSCOMMAND)
		MESSAGE(onCommand,		WM_COMMAND)
		MESSAGE(onPaint,		WM_PAINT)
		MESSAGE(onPaint,		LM_REPAINT)
		MESSAGE(onTimer,		WM_TIMER)
	END_MESSAGEPROC
}

//=========================================================
// Message handlers
//=========================================================

void LsMail::onRefresh(Message& message)
{
	LSLog(LOG_DEBUG, szAppName, "Refreshing");
	CleanUp();
	DeleteCommands();

	ReadCommands();
	
	LoadSetup();
	ReadServers();
	CreatePopup();

	// handling for new size & bitmap?
	Move(x, y);
	Size(w, h);

	bHidden = GetRCBool("LSMailStartHidden", TRUE);
	if (bHidden)
	{
		LSLog(LOG_DEBUG, szAppName, "Starting as hidden");
		ShowWindow(hWnd, SW_HIDE);
	}
	else
	{
		LSLog(LOG_DEBUG, szAppName, "Starting as shown");
		ShowWindow(hWnd, SW_SHOW);
	}

	bOnTop = GetRCBool("LSMailAlwaysOnTop", TRUE);
	if (bOnTop)
	{
		LSLog(LOG_DEBUG, szAppName, "Setting Ontop");
		SetWindowPos(hWnd2, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
	}
	else
	{
		LSLog(LOG_DEBUG, szAppName, "Normal Window, not ontop");
	}

	if (bgbmp && !USEBGCOLOR)
	{
		SetWindowBitmapRgn(bgbmp);
		LSLog(LOG_DEBUG, szAppName, "Setting window bitmap region");
	}

	LSLog(LOG_DEBUG, szAppName, "Refresh done");

	CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);

}

void LsMail::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void LsMail::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "LsMail.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


void LsMail::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void LsMail::onMouse(Message& message)
{
	LSLog(LOG_DEBUG, szAppName, "OnMouse accessed");
	if (message.uMsg == WM_LBUTTONUP)
	{
			/*NEWMAIL=FALSE;
			for (SERVER* s=Servers; s; s=s->next) 
			{
				s->num=s->newnum;
				s->NEWMAIL=FALSE;
			}
			*/
		CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
		InvalidateRect(hWnd, NULL, TRUE);
	}
	else if (message.uMsg == WM_RBUTTONDOWN)
	{
		LSLog(LOG_DEBUG, szAppName, "open popup");
		DWORD dw = GetMessagePos();
		TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hWnd, NULL); // hwnd?
	}
	message.lResult = DefWindowProc(hWnd2, message.uMsg, message.wParam, message.lParam);
}

void LsMail::onCommand(Message& message)
{
	switch (message.wParam)
	{
		case POPUP_CHECKMAIL:
		{
			CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
		}
		break;
	
		case POPUP_LAUNCHCLIENT: 
		{
			WinExec(MAILCLIENT, SW_SHOWNORMAL);
		}
		break;
		case POPUP_DISPLAYERROR:
		{
			MessageBox(hWnd, ERR, "LSMail Error", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
		}
		break;
		/*	case POPUP_ZEROACCOUNTS:
		{
			for (SERVER* s=Servers; s; s=s->next) 
			{
				s->NEWMAIL=FALSE;
				s->num=s->newnum=0;
			}
			InvalidateRect(hWnd, NULL, TRUE);
		}
		break;*/
		
		case POPUP_CLEARNEWMAIL:
		{
			NEWMAIL=FALSE;
			for (SERVER* s=Servers; s; s=s->next) 
			{
				//s->num=s->newnum; //V
				s->MAIL_STATUS = MAIL_NO;
			}
			InvalidateRect(hWnd, NULL, TRUE); // needed for redraw
		}
		break;
		
		default:
		{
			for (SERVER* s=Servers; s; s=s->next) 
			{
				if ((int)message.wParam == (POPUP_SERVER+s->ID+1))
				{
					// Change Password
					strcpy(TEMP_SERVER, s->name);
					DialogBox(hInstance, MAKEINTRESOURCE(IDD_GETPASS), hWnd, GetPassProc);
					if (strlen(TEMP_PASS)) 
					{
						char temp[256] = "";
						if (s->password) memset(&s->password, 0, sizeof(s->password));
						s->password = NULL;
						s->password = _strdup(TEMP_PASS);
						sprintf(temp, "%s/%s", s->host, s->login);
						WriteProfileString("LSMail", temp, encrypt(s->password));
					}
					break;
				}
			}
		}
		break;
	}

}

void LsMail::onPaint(Message& message)
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "onpaint accessed");
#endif

	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd, &ps);
	HDC buf = CreateCompatibleDC(NULL);
	HDC src = CreateCompatibleDC(NULL);
	HBITMAP bufbmp = CreateCompatibleBitmap(hdc, w, h);
	HBITMAP oldbuf, oldsrc;
	RECT r;

	GetClientRect(hWnd, &r);

	if (!bgbmp && !USEBGCOLOR)
	{
		bgbmp = CreateCompatibleBitmap(hdc, w, h);
		oldbuf = (HBITMAP)SelectObject(buf, bgbmp);
		BitBlt(buf, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		SelectObject(buf, oldbuf);
	}

	oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			
	if (!USEBGCOLOR)
	{
		if (ERRORS && errorbmp)
			oldsrc = (HBITMAP)SelectObject(src, errorbmp);
		else if (CHECKING && checkingbmp)
			oldsrc = (HBITMAP)SelectObject(src, checkingbmp);
		else if (NEWMAIL && newmailbmp)
			oldsrc = (HBITMAP)SelectObject(src, newmailbmp);
		else
			oldsrc = (HBITMAP)SelectObject(src, bgbmp);

		BitBlt(buf, 0, 0, w, h, src, 0, 0, SRCCOPY);
	}
	else
	{
		if (ERRORS)
			FillRect(buf, &r, (HBRUSH)errorbgbrush);
		else if (CHECKING)
			FillRect(buf, &r, (HBRUSH)checkbgbrush);
		else if (NEWMAIL)
			FillRect(buf, &r, (HBRUSH)nmbgbrush);
		else
			FillRect(buf, &r, (HBRUSH)bgbrush);
	}

	SelectObject(buf, font);
	SetBkMode(buf, TRANSPARENT);

	for (SERVER* s=Servers; s; s=s->next)
	{
		char temp[256] = "";
				
		if (s->bERROR)
			sprintf(temp, "%s: Error!", s->name);
		else
			sprintf(temp, "%s: %d", s->name, s->newnum-s->num);

		SetRect(&r, s->x, s->y, w, h);

		if (CHECKING)
			SetTextColor(buf, checkcolor);
		else
		{
			if (s->MAIL_STATUS != MAIL_NO)
			{
				SetTextColor(buf, nmcolor);
#ifdef DEBUG_SERVER
				LSLogPrintf(LOG_DEBUG, szAppName, "new mail on server: %s", s->host);
#endif
			}
			else
			{
				if (s->bERROR)
				{
					SetTextColor(buf, errorcolor);
				}
				else
				{

				SetTextColor(buf, color);
#ifdef DEBUG_SERVER
				LSLogPrintf(LOG_DEBUG, szAppName, "no new mail on server: %s", s->host);
#endif
				}

			}
		}

		DrawText(buf, temp, strlen(temp), &r, DT_CALCRECT | DT_LEFT | DT_VCENTER);
		DrawText(buf, temp, strlen(temp), &r, DT_LEFT | DT_VCENTER);
	}

	BitBlt(hdc, 0, 0, w, h, buf, 0, 0, SRCCOPY);

	SelectObject(src, oldsrc);
	DeleteDC(src);
	SelectObject(buf, oldbuf);
	DeleteDC(buf);
	DeleteObject(bufbmp);
	EndPaint(hWnd, &ps);
}

void LsMail::onEraseBg(Message& message)
{
	return;
}

void LsMail::onTimer(Message& message)
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "OnTimer accessed, checking mail");
#endif
	CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
}


// Server functions


// mail checking, not possible to thread class functions?
BOOL CheckMail()
{
	int i = 0;
	// abort on these conditions
	if (mail->CHECKING || mail->bDisableCheck) {
		//mail->CHECKING = FALSE;
		return FALSE;
	}

#ifdef DEBUG_SERVER
		LSLog(LOG_DEBUG, szAppName, "starting mail check");
#endif

	mail->CHECKING=TRUE;
	mail->ERRORS = FALSE;

	InvalidateRect(mail->hWnd2, NULL, TRUE);
	LSExecute(mail->hWnd2, mail->CheckMailCmd, 0); // check !bang

	__try 
	{
		for (SERVER* s=Servers; s; s=s->next)
		{
			s->POP3Check();
		}
	} __except(1) { }

	mail->MAIL_STATUS = mail->Status();

	if (mail->MAIL_STATUS == MAIL_NEW) {
		mail->NEWMAIL = TRUE;
		LSExecute(mail->hWnd2, mail->NewMailCmd, 0);
	}
	else if (mail->MAIL_STATUS == MAIL_NO) {
		mail->NEWMAIL = FALSE;
		LSExecute(mail->hWnd2, mail->NoMailCmd, 0);
	}

	for (SERVER* s=Servers; s; s=s->next)
	{
		if (s->bERROR)
			mail->ERRORS = TRUE;
	}
	if (mail->ERRORS)
		LSExecute(mail->hWnd2, mail->ErrorCmd, 0); // error !bang

	mail->CHECKING=FALSE;
	LSExecute(mail->hWnd2, mail->DoneCheckCmd, 0); // check !bang
	InvalidateRect(mail->hWnd2, NULL, TRUE);

#ifdef DEBUG_SERVER
	LSLog(LOG_DEBUG, szAppName, "mail check done");
#endif
	return TRUE;
}


BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG: 
		{
			char temp[256] = "";
			sprintf(temp, "%s Password", mail->TEMP_SERVER);
			SetWindowText(hwnd, temp);
			return TRUE;
		}

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDOK:
						{
							GetDlgItemText(hwnd, IDC_PASSWORD, mail->TEMP_PASS, 256);
						}
						case IDCANCEL:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}

	return FALSE;
}

char* LsMail::encrypt(char* pass)
{
	char* ret=_strdup(pass);
	char* p=ret;
	for (; *pass; *pass++, *ret++)
	{
		*ret=*pass ^ 0x5405;
	}
	return p;
}

int LsMail::Status()
{
	int status = MAIL_NO;
	for (SERVER* s=Servers; s; s=s->next)
	{
		status = max(status, s->MAIL_STATUS);
	}
	return status;
}

SERVER::SERVER(int NumServers)
{
#ifdef DEBUG_SERVER
	LSLogPrintf(LOG_DEBUG, szAppName, "creating server: %d", NumServers);
#endif
	//ID=mail->NumServers++;
	ID=NumServers;
#ifdef DEBUG_SERVER
	LSLog(LOG_DEBUG, szAppName, "ID set, setting startup values");
#endif
	newnum=num=0; 
	MAIL_STATUS = MAIL_NO;
	bERROR=FALSE;
	next=NULL;
	name = host = login = password = NULL;

#ifdef DEBUG_SERVER
	LSLog(LOG_DEBUG, szAppName, "server created");
#endif
}

SERVER::~SERVER()
{
}

SERVER::POP3Check()
{
#ifdef DEBUG_SERVER
	LSLogPrintf(LOG_DEBUG, szAppName, "trying server %s@%s", login, host);
#endif

	BOOL Error = FALSE;
	unsigned int addr; 
	int	socket_type = SOCK_STREAM; 
	struct sockaddr_in server; 
	struct hostent *hp; 
	WSADATA wsaData; 
	SOCKET conn_socket;
	char temp[256] = "";
	if (!password)
	{
		sprintf(temp, "%s/%s", host, login);
		GetProfileString("LSMail", temp, "", temp, 256);
		if (!strlen(temp))
		{
			strcpy(mail->TEMP_SERVER, name);
			DialogBox(mail->hInstance2, MAKEINTRESOURCE(IDD_GETPASS), mail->hWnd2, GetPassProc);
			if (strlen(mail->TEMP_PASS)) 
			{
				password = _strdup(mail->TEMP_PASS);
				sprintf(temp, "%s/%s", host, login);
				WriteProfileString("LSMail", temp, mail->encrypt(password));
			}
			memset(&mail->TEMP_PASS, 0, sizeof(mail->TEMP_PASS));
		}
		else
		{
			password=_strdup(mail->encrypt(temp));
		}
	}

	// Startup Sockets
	if (WSAStartup(0x202,&wsaData) == SOCKET_ERROR)
	{ 
		sprintf(mail->ERR, "Could not initialize Windows Sockets");
		Error=TRUE;
		WSACleanup(); 
		//continue;
	} 

	// Check to see if server_name is an alpha or ip
	if (isalpha(host[0]))
		hp = gethostbyname(host); 
	else  
	{
		addr = inet_addr(host); 
		hp = gethostbyaddr((char *)&addr,4,AF_INET); 
	} 

	// Couldn't resolve
	if (hp == NULL) 
	{	
		sprintf(mail->ERR, "Could not resolve %s", host);
		//SERVER->ERR=TRUE;
		WSACleanup();
		//continue;
	} 

	// Copy the resolved information into the sockaddr_in structure 
	memset(&server,0,sizeof(server)); 
	memcpy(&(server.sin_addr),hp->h_addr,hp->h_length); 
	server.sin_family = hp->h_addrtype; 
	server.sin_port = htons((u_short)port); 

	// Open a socket
	conn_socket = socket(AF_INET,socket_type,0);
	if (conn_socket < 0 ) 
	{ 
		sprintf(mail->ERR, "Could not open a socket");
		Error=TRUE;
		WSACleanup(); 
		//continue;
	}

	// Connect to the server
	if (connect(conn_socket,(struct sockaddr*)&server,sizeof(server)) == SOCKET_ERROR)
	{
		sprintf(mail->ERR, "Could not connect to %s:%d, socket error", host, port);
		Error=TRUE;
		WSACleanup(); 
		//continue;
	}

	char* recvd=NULL;
	if (!ReceiveData(conn_socket)) 
	{ 
		sprintf(mail->ERR, "No data received from server");
		Error=TRUE; 
		//continue; 
	}

	sprintf(temp, "USER %s\r\n", login);
	send(conn_socket, temp, strlen(temp), 0);
	if (!ReceiveData(conn_socket)) 
	{
		sprintf(mail->ERR, "%s: Invalid Login", login);
		Error=TRUE; 
		//continue; 
	}
	sprintf(temp, "PASS %s\r\n", password);
	send(conn_socket, temp, strlen(temp), 0);
	if (!ReceiveData(conn_socket)) 
	{
		sprintf(mail->ERR, "%s: Invalid password", password);
		sprintf(temp, "Invalid password for user %s on %s", login, host);
		if (!mail->bNoMessageBoxes)
			MessageBox(mail->hWnd2, temp, "LSMail Error, no data received after sending password", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
		else
			LSLog(LOG_WARNING, szAppName, "LSMail Error, no data received after sending password");
		Error=TRUE; 
		//continue; 
	}
	sprintf(temp, "STAT\r\n");
	send(conn_socket, temp, strlen(temp), 0);
	if (!(recvd=ReceiveData(conn_socket))) 
	{
		sprintf(mail->ERR, "Could not execute STAT. No data received.");
		Error=TRUE; 
		//continue; 
	}
	else
	{
		char* p = strtok(recvd, " ");
		int ReportedNum=-1;
		p = strtok(NULL, " ");
		ReportedNum = atoi(p);
		// new mail if:
		// 1. we have more mail than before
		// 2. we have more than zero mail, and less than before
		//    meaning we've fetched the mail, but before refresh, we've gotten even more
		//    what about when we get exactly the same amount of mail again?
		if ( ReportedNum > newnum || (ReportedNum > 0 && ReportedNum < newnum) ) 
		{
			MAIL_STATUS = MAIL_NEW;
		}
		else if (ReportedNum == newnum && ReportedNum != 0) {
			MAIL_STATUS = MAIL_EXISTS;
		}
		else if (ReportedNum == 0) {
			/*if (mail->MAIL_STATUS == MAIL_NO) {
				mail->MAIL_STATUS = MAIL_NO;
			}*/
			num=newnum=0;
			MAIL_STATUS = MAIL_NO;
		}
		newnum=ReportedNum;

		if (newnum < num)
			num=newnum;
	}

	sprintf(temp, "QUIT\r\n");
	send(conn_socket, temp, strlen(temp), 0);
	if (!ReceiveData(conn_socket)) 
	{ 
		sprintf(mail->ERR, "Error disconnecting from server");
		Error=TRUE; 
		//continue; 
	}

	// set server error if a new error has been found
	if (Error)
		bERROR = TRUE;
	else
		bERROR=FALSE;

	closesocket(conn_socket);
	WSACleanup();

#ifdef DEBUG_SERVER
	LSLog(LOG_DEBUG, szAppName, "server done");
#endif

}

char* SERVER::ReceiveData(SOCKET conn_socket)
{
	int retval;
	int nStatus;
	struct timeval timeout = {0, 0};
	struct fd_set fds;
	DWORD dwStartTicks = GetTickCount();
	char temp[256] = "";

	while (1)
	{
		if ((GetTickCount() - dwStartTicks) > 60000)
		{
			if (!mail->bNoMessageBoxes)
				MessageBox(mail->hWnd2, "Receive Timed Out", szAppName, MB_SYSTEMMODAL);
			else
				LSLog(LOG_WARNING, szAppName, "Receive Timed Out");
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}

		FD_ZERO(&fds);
		FD_SET(conn_socket, &fds);
		nStatus = select(0, &fds, NULL, NULL, &timeout);
		if (nStatus == SOCKET_ERROR) 
		{
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}
		else
		{
			if (!nStatus) 
			{
				Sleep(250);
				continue;
			}
		}

		retval = recv(conn_socket, temp, 256, 0); 
		if (retval == SOCKET_ERROR) 
		{ 
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}
		else
		{
			if (_strnicmp(temp, "+OK", 3))
			{
				closesocket(conn_socket);
				WSACleanup();
				return NULL;
			}
			else return _strdup(temp);
		}
	}

	return _strdup(temp);
}