#ifndef  __LSMAIL
#define  __LSMAIL

// module information
const char szAppName[] = "LsMail"; // Our window class, etc
const char rcsRevision[] = "$Revision: 4.1 $"; // Our Version
const char rcsId[] = "$Id: LsMail.cpp,v 4.1 11:20:37 Vendicator Exp $"; // The Full RCS ID.

// Includes
#include <windows.h>
#include <time.h> // for timers

#include "resource.h"
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/lswinbase.h"
#include "servers.h"

// Definitions
#define POPUP_CHECKMAIL 200
#define POPUP_CLEARNEWMAIL 201
//#define POPUP_ZEROACCOUNTS 202
#define POPUP_LAUNCHCLIENT 203
#define POPUP_DISPLAYERROR 204
#define POPUP_SERVER 220

#define MAX_LINE_LENGTH 4096

#define WC_SHELLDESKTOP		"DesktopBackgroundClass"

class LsMail : public Window
{
public:
	LsMail(HWND parentWnd, int& code, HINSTANCE dllInst);
	~LsMail();
	int Status();
	void LoadSetup();
	void ReadServers();
	char* encrypt(char* pass);

	void Move(int x_pos, int y_pos);
	void Size(int x_size, int y_size);


	HINSTANCE hInstance2;
	HANDLE CheckThread;
	HWND hWnd2;
	HWND hWndParent;

	BOOL bOnTop;
	BOOL bHidden;
	BOOL lsboxed;
	BOOL bNoMessageBoxes;
	BOOL bDisableCheck;

	BOOL CHECKING;
	BOOL NEWMAIL;
	BOOL ERRORS;

	COLORREF color, nmcolor, checkcolor, bgcolor, errorcolor;
	HBRUSH bgbrush, nmbgbrush, checkbgbrush, errorbgbrush;
	HBITMAP bgbmp, newmailbmp, checkingbmp, errorbmp;
	BOOL USEBGCOLOR;
	int TIMER;

	int ScreenX, ScreenY;
	int x, y, w, h;

	HMENU popup;
	HFONT font;

	DWORD threadID;

	char TEMP_PASS[256];
	char TEMP_SERVER[256];
	char ERR[256];
	char MAILCLIENT[MAX_PATH];

	char *NewMailCmd, *NoMailCmd, *CheckMailCmd, *DoneCheckCmd, *ErrorCmd;

	int MAIL_STATUS;
	int NumServers;

private:

	void CleanUp();

	void ReadCommands();
	void DeleteCommands();

	void CreatePopup();
	void SetWindowBitmapRgn(HBITMAP bmp);

	// Event handling:
	virtual void windowProc(Message& message);
	void onTimer(Message& message);
	void onEraseBg(Message& message);
	void onPaint(Message& message);
	void onCommand(Message& message);
	void onMouse(Message& message);
	void onRefresh(Message& message);
	void onGetRevId(Message& message);
	void onDestroy(Message& message);
	void onCreate(Message& message);
	void onSysCommand(Message& message);
	void onEndSession(Message& message);

};

// Function Definitions
//LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CheckMail();

void BangHook(HWND caller, LPCTSTR szArgs);
void BangShow(HWND caller, const char* args);
void BangHide(HWND caller, const char* args);
void BangToggle(HWND caller, const char* args);
void BangCheckMail(HWND caller, const char* args);
void BangToggleCheck(HWND caller, const char* args);
void BangEnableCheck(HWND caller, const char* args);
void BangDisableCheck(HWND caller, const char* args);
void BangMove(HWND caller, const char *args);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
