2006-08-16 - Brian
A small update of Seg@'s umslider-0.2 to fix the muting code (was bustigated),
and to change the volume stepsize from 10 to 1 (not an adjustable step setting
yet). umslider is a C version of BlkHawk's lsslider that fixes some sort of
Delphi-specific conflict under winXP.
