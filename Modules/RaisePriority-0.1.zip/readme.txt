Tiny Module that raises priority of litestep process to abovenormal.

thegeek.