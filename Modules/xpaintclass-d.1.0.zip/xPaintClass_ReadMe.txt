-----------------------------------------------------------------------------
 xPaintClass "ReadMe"
-----------------------------------------------------------------------------

xPaintClass needs Win2000 or newer! :P

 Homepage:
------------
 http://www.ls-universe.info

 xPaintClass Docs:
--------------------
 http://wwww.xdocs.ls-universe.info

-----------------------------------------------------------------------------
 Personal Usage:
-----------------------------------------------------------------------------

Put xPaintClass-1.0.dll in your Litestep Folder!

Simply overwrite an eventually existing older version!

If you have another version in your Module Folder, overwrite it with this one too!

-----------------------------------------------------------------------------
 Theme Release Usage:
-----------------------------------------------------------------------------

Load xPaintClass-1.0 before other modules, at least before every module, that makes use of it!
Otherwise the modules won't load, making your theme unusable!

That's all!

-----------------------------------------------------------------------------
 Changes for xPaintClass 
-----------------------------------------------------------------------------

Major Version 1.0 - Minor Version (0.2) Released on 01-04-2007, Created by Andymon

- Added:   xPaintTexture: PaintingMode .singlecolor/.multicolor
           ...ShapeType .rectangle/.ellipse/.rounded

- Added:   xPaintTexture: PaintingMode .singlecolor/.multicolor
           ...RoundedEdges XY/X Y

- Added:   xPaintTooltip:
           Support for "<tab>", which inserts a Tab.

- Fixed:   xPaintIcon:
           Increased CPU Usage since Update 1 (Especially noticeable in xTray, xTaskbar)

Major Version 1.0 - Minor Version (0.1) Released on 05-03-2007, Created by Andymon

- Fixed:   xPaintTexture: PaintingMode .icon
           Icons with alphachannel were not painted properly
           
- Fixed:   xPaintTexture: PaintingMode .icon
           If ...IconExtractionSize was bigger then the available icon, then the difference
           was painted as a black part on icons with alphachannel.
           
- Fixed:   xPaintTexture: PaintingMode .icon
           Some specific strings/chars in Path/Filenames have broken the Icon Extraction
           
- Fixed:   xPaintTexture: -> only xLabel related
           xLabels Hover and Pressed States are now correctly applied, 
           even if only the following values are modified
           ...TextureX
           ...TextureY
           ...TextureWidth
           ...TextureHeight
           
- Fixed:   xPaintIcon: 
           Icons painted with Colorization or AlphaTransparency and Icons, which are painted on AlphaMap
           modules have now 100% correct AlphaValues.
           
- Fixed:   xPaintText and xPaintHTMLText: 
           Text painted with AlphaTransparency, TextFade or which are painted on AlphaMap modules,
           have now 100% correct AlphaShaded Antialiasing.
           (If you use xLabel's (xPaintHTMLText) "<font ...color=...>" tags, you'll have the old 
           implementation with 90% correct Alpha :P)
           
- Fixed:   xPaintTooltip:
           \t and \n weren't skipped in Tooltips.
           If a module wants a Tab or Linebreak then it must send '\t' or '\n' (<br>).

Initial Major Version 1.0 Released on 25-01-2007, Created by Andymon