LSNetLoad v0.1 - Friday, April 13, 2001
by Peter Grimm
pmg23@columbia.edu

Function:  Displays the current network usage on the wharf.  Both in and out 
           are displayed in a graphical manner.

Requirements:  Windows NT, some sort of network connection, litestep, a 
               computer.

Before you start:
1.� TCP/IP NetBIOS Helper Service needs to be enabled in order for the network 
    connection monitoring to take place, so enable it (Control Panel -> 
    Administrative Tools -> Services)

2.� Open up Performance (Control Panel -> Administrative Tools -> Performance) 
    and right click on the graph area.� Click add counters.� Under performance 
    object, select network interface.� Under select instance from list find 
    your network card's name.� The module will need to know this in order to 
    get the nic performance variables properly.

step.rc settings:

   LSNetLoadGridColor color
   Default: 0x700000

    This is the color of the grid.

   LSNetLoadBackColor color
   Default: 0x500000
   
    This is the color of the background.
   
   LSNetLoadUpColor color
   Default: 0xFF7F00
   
    This is the color of the network out graph.
   
   LSNetLoadDownColor color
   Default: 0xFF0000
   
    This is the color of the network in graph.
   
   LSNetLoadMaxSpeed int
   Default: 1000
   
    This is the maximum value on the graph in bytes.
   
   LSNetLoadInterface string
   Default: PCI Bus Master Adapter

    This is the name of your network adapter.  It is very important that you 
    get this correct or the module will fail miserably!
    
Loading it in the wharf...

   *Wharf "Network Load" ".none" "@LsNetLoad.dll"


Version History:

  0.1 - April 13, 2001
  --------------------------
    Initial Release.

If you have any questions, comments, bugs, and enhancements, please let me know.
My email is pmg23@columbia.edu.

Thanks to Francis Gastellu aka Lone Runner/Aegis for not only making litestep,
but also for making lscpu and releasing the source, which made this release
possible.  Thanks to jugg, noodge, furan and others for help and support.  
Thanks to the devteam and all those people that contribute to the ls community.
If I missed anyone let me know.
