/**
 * Litestep Net Load Meter
 * LsNetLoad.dll
 * 
 * Relies heavily on the code for lscpu...
 * 
 **/

#ifdef UNICODE
#ifndef _UNICODE
#define _UNICODE
#endif
#define tmain wmain
#else
#define tmain main
#endif

#define WIN32_LEAN_AND_MEAN 1

#include <windows.h>
#include <winperf.h>
#include <malloc.h>
#include <stdio.h>
#include <tchar.h>
#include <pdh.h>
#include <string.h>

#include "D:\LiteStep\source\litestep\lsapi\lsapi.h"
#include "C:\Program Files\Microsoft Visual Studio\MyProjects\LsNetLoad\blah.h"

char szAppName[] = "LsNetLoad"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client

DWORD Reserved,dataType,dataLen=8192;
//char dataUp[8192]; // Buffer to communicate with registry. (way bigger than neeeded)
//char dataDown[8192];

HKEY perfKey;		// Registry key to get cpu usage
HKEY startPerfKey;	// Registry key to start cpu usage moinitoring

char upHistory[64];	// history of last n seconds
char downHistory[64];

BOOL init=FALSE;	// Monitor started ?
int width=0;		// Width of monitor (= size of history)

int pointer=0;		// pointer on the rotating history


// Performance Data Helper Variables
PDH_STATUS pdhStatus = ERROR_SUCCESS;
LPTSTR szCounterListBuffer = NULL;
DWORD dwCounterListBuffer = 0;
LPSTR szInstanceListBuffer = NULL;
DWORD dwInstanceListBuffer = 0;
LPSTR szThisInstance = NULL;

HQUERY netLoadDownQuery;
HCOUNTER netLoadDownCounter;
PDH_FMT_COUNTERVALUE netLoadDown;

HQUERY netLoadUpQuery;
HCOUNTER netLoadUpCounter;
PDH_FMT_COUNTERVALUE netLoadUp;

COLORREF gridColor;
COLORREF backColor;
COLORREF upForeColor;
COLORREF downForeColor;

long tempValue;
int maxNetSpeed;
CHAR networkAdapterCurrent1[512];
CHAR networkAdapterCurrent2[512];
CHAR networkAdapter[256];
CHAR networkAdapterUp[] = ")\\Bytes Sent/sec";
CHAR networkAdapterDown[] = ")\\Bytes Received/sec";

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	//MessageBox(parent,"init",szAppName,MB_OK);
	gridColor = GetRCColor("LSNetLoadGridColor", 0x700000);
	backColor = GetRCColor("LSNetLoadBackColor", 0x500000);
	upForeColor = GetRCColor("LSNetLoadUpColor", 0xFF7F00);
	downForeColor = GetRCColor("LSNetLoadDownColor", 0xFF0000);
	maxNetSpeed = GetRCInt("LSNetLoadMaxSpeed",1000);

	//BOOL GetRCString(LPCTSTR lpKeyName, LPSTR value, LPCTSTR defStr, int maxLen); 
	//GetRCString("PixmapPath", szNetworkAdapter, "PCI Bus Master Adapter", 256);
	//MessageBox(parent,"creating arrays",szAppName,MB_OK);
	memset(networkAdapterCurrent1, 0, 512);
	memset(networkAdapterCurrent2, 0, 512);
	memset(networkAdapter, 0, 256);
	//MessageBox(parent,"Created Arrays...getting rc string",szAppName,MB_OK);

	GetRCString("LSNetLoadInterface",networkAdapter, "PCI Bus Master Adapter", 256);
	//MessageBox(parent,"got rc string, cating arrays",szAppName,MB_OK);
	networkAdapterCurrent1[0] = '\\';
	networkAdapterCurrent2[0] = '\\';
	strcat(networkAdapterCurrent1,"Network Interface(");
	strcat(networkAdapterCurrent2,"Network Interface(");
	strcat(networkAdapterCurrent1,networkAdapter);
	strcat(networkAdapterCurrent2,networkAdapter);
	strcat(networkAdapterCurrent1,networkAdapterUp);
	strcat(networkAdapterCurrent2,networkAdapterDown);
	//MessageBox(parent,networkAdapterCurrent1,szAppName,MB_OK);

	pdhStatus = PdhOpenQuery(NULL,0,&netLoadUpQuery);
	//pdhStatus = PdhAddCounter(netLoadUpQuery,"\\Processor(0)\\% Processor Time",0,&netLoadUpCounter);
	pdhStatus = PdhAddCounter(netLoadUpQuery,networkAdapterCurrent1,0,&netLoadUpCounter);

	pdhStatus = PdhOpenQuery(NULL,1,&netLoadDownQuery);
	//pdhStatus = PdhAddCounter(netLoadDownQuery,"\\Processor(1)\\% Processor Time",1,&netLoadDownCounter);
	pdhStatus = PdhAddCounter(netLoadDownQuery,networkAdapterCurrent2,1,&netLoadDownCounter);

	//MessageBox(parent,"should be all set!!!!!",szAppName,MB_OK);

	if(pdhStatus!=ERROR_SUCCESS){
		MessageBox(parent,"Please specify the network interface to capture data from.", szAppName,MB_OK);
		return 1;
	}


    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    wndSize = 64-wharfData.borderSize*2;

	memset(upHistory, 0, 64); // initialize history to 0
	memset(downHistory, 0, 64);

    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }


    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

	SetTimer(hMainWnd, 0, 1000, NULL); // Set a timer for cpu monitor
	
	// Open the cpu usage registry key
	//RegOpenKey(HKEY_DYN_DATA, "PerfStats\\StatData", &perfKey);
	

	// Start monitoring
	//RegOpenKey(HKEY_DYN_DATA, "PerfStats\\StartStat", &startPerfKey);
	//RegQueryValueEx(startPerfKey, "KERNEL\\CPUUsage", &Reserved, &dataType, data, &dataLen);

	//Find the appropriate 

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	KillTimer(hMainWnd, 0);
	//RegCloseKey(startPerfKey);
	//RegCloseKey(perfKey);
    DestroyWindow(hMainWnd);                // delete our window
	
	pdhStatus = PdhCloseQuery(&netLoadUpQuery); // close queries
	pdhStatus = PdhCloseQuery(&netLoadDownQuery);
    
	UnregisterClass(szAppName, dllInst);    // unregister window class
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
			{ 
                PAINTSTRUCT ps;
                RECT r;
                HDC hdc = BeginPaint(hwnd,&ps);
				HBRUSH brush;
				HPEN pen, oldpen;
				int i, j;
                
                //  ********* CPU module drawing ********


                // Get client rect of our window
				GetClientRect(hwnd,&r);
				r.left++; // adjustment

				
				// contract rect used by 4 pixels
				r.top += 4;
				r.bottom -= 4;
				r.left += 4;
				r.right -= 4;

				width = (r.right - r.left)-3; // Width of monitor

				// Draw border
				pen = CreatePen(PS_SOLID, 1, 0);
				oldpen = SelectObject(hdc, pen);

                MoveToEx(hdc, r.left, r.bottom-1, NULL);
                LineTo(hdc, r.left, r.top);
                LineTo(hdc, r.right-1, r.top);

				SelectObject(hdc, oldpen);
				DeleteObject(pen);
				
				pen = CreatePen(PS_SOLID, 1, 0xFFFFFF);
				oldpen = SelectObject(hdc, pen);

                LineTo(hdc, r.right-1, r.bottom-1);
                LineTo(hdc, r.left, r.bottom-1);

				SelectObject(hdc, oldpen);
				DeleteObject(pen);

				// Contract rect by another pixel
				r.top++;
				r.bottom--;
				r.left++;
				r.right--;

				// Paint monitor background
				brush = CreateSolidBrush(backColor);
				FillRect(hdc, &r, brush);
				DeleteObject(brush);

				// Draw grid
				pen = CreatePen(PS_SOLID, 1, gridColor);
				oldpen = SelectObject(hdc, pen);

				for (i=1;i<4;i++)
					{
					MoveToEx(hdc, r.left, r.top + ((r.bottom-r.top)/4)*i, NULL);
					LineTo(hdc, r.right-1, r.top + ((r.bottom-r.top)/4)*i);
					}
				for (i=1;i<4;i++)
					{
					MoveToEx(hdc, r.left+ ((r.right-r.left)/4)*i, r.top, NULL);
					LineTo(hdc, r.left+ ((r.right-r.left)/4)*i, r.bottom-1);
					}

				SelectObject(hdc, oldpen);
				DeleteObject(pen);

                // ---------------------------------------------

				// Draw CPU monitor history curve

				pen = CreatePen(PS_SOLID, 1, upForeColor);
				oldpen = SelectObject(hdc, pen);

				j = (pointer + width) % width;
				MoveToEx(hdc, r.left+1, r.bottom-1- (width * upHistory[j]/100), NULL);
				for (i=1;i<width;i++)
					{
					j++;
					j %= width;
					LineTo(hdc, r.left+1+i, r.bottom-1- (width * upHistory[j]/100));
					}

				SelectObject(hdc, oldpen);
				DeleteObject(pen);

				pen = CreatePen(PS_SOLID, 1, downForeColor);
				oldpen = SelectObject(hdc, pen);

				j = (pointer + width) % width;
				MoveToEx(hdc, r.left+1, r.bottom-1- (width * downHistory[j]/100), NULL);
				for (i=1;i<width;i++)
					{
					j++;
					j %= width;
					LineTo(hdc, r.left+1+i, r.bottom-1- (width * downHistory[j]/100));
					}

				SelectObject(hdc, oldpen);
				DeleteObject(pen);

				init=TRUE;

                EndPaint(hwnd,&ps);
			}
            return 0;
        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
	// Mouse messages are here to ensure we have a good popup menu behaviour. You may insert
        // your own custom actions
        case WM_RBUTTONUP:
                {
                RECT r;
                GetWindowRect(hwnd, &r);
                PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
        case WM_RBUTTONDOWN:
        case WM_LBUTTONDOWN:
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
		case WM_TIMER: // Update cpu monitor
			{
			RECT r;
			if (!init) return 0;
			// Get last cpu usage value
			//RegQueryValueEx(perfKey, "KERNEL\\CPUUsage", &Reserved, &dataType, data, &dataLen);

			pdhStatus=PdhCollectQueryData(netLoadUpQuery);
			pdhStatus=PdhGetFormattedCounterValue(netLoadUpCounter,PDH_FMT_LONG,NULL,&netLoadUp);

			pdhStatus=PdhCollectQueryData(netLoadDownQuery);
			pdhStatus=PdhGetFormattedCounterValue(netLoadDownCounter,PDH_FMT_LONG,NULL,&netLoadDown);

			// Insert it in the rotating buffer
			tempValue = netLoadUp.longValue;
			if(tempValue>maxNetSpeed || tempValue<0) tempValue = maxNetSpeed;

			upHistory[pointer] = 100 * tempValue/maxNetSpeed;
			
			tempValue = netLoadDown.longValue;
			if(tempValue>maxNetSpeed || tempValue<0) tempValue = maxNetSpeed;
			downHistory[pointer] = 100 * tempValue/maxNetSpeed;
			pointer++;
			pointer %= width;

			// Invalidate client. This causes a WM_PAINT message to be sent to our window
			GetClientRect(hMainWnd, &r);
			InvalidateRect(hMainWnd, &r, TRUE);
			}
			return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

