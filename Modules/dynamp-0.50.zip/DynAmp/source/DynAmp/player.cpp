#include "player.h"
#include "../VTK/apis.h"
#include "winamp2.h"
#include "winamp3.h"
#include "foobar2000.h"
#include "..\current\lsapi\lsapi.h"

extern LPCSTR szLogName;

// initialize these static variables
SafeString Player::szAmpPath;
BOOL Player::bStartNormal = FALSE;
BOOL Player::bPlayNotOpen = FALSE;
BOOL Player::bPlayPauseNotOpen = FALSE;
BOOL Player::bPlaylistNotOpen = FALSE;
BOOL Player::bPrefsNotOpen = FALSE;
BOOL Player::bLoadFileNotOpen = FALSE;
BOOL Player::bShowNotOpen = FALSE;


Player::Player()
{
}

Player::~Player()
{
}

void Player::playerOpen()
{
	// simple player opener
	(bStartNormal) ? WinExec(szAmpPath.c_str(), SW_NORMAL) : WinExec(szAmpPath.c_str(), SW_MINIMIZE);
}

void Player::LoadPlayerLocation(LPCSTR defaultLocation)
{
	char szTemp1[MAX_LINE_LENGTH];
	char szTemp2[MAX_LINE_LENGTH];
	GetRCString("WinampPath", szTemp1, defaultLocation, MAX_LINE_LENGTH);
	GetRCString("DynAmpPath", szTemp2, szTemp1, MAX_LINE_LENGTH);

	szAmpPath.assign(szTemp2);
}

void Player::power()
{
	(!GetPlayerWnd()) ? playerOpen() : powerOff();
}

void Player::powerOn()
{
	(!GetPlayerWnd()) ? playerOpen() : SetForegroundWindow(GetPlayerWnd());
}

void Player::show()
{
	if (!bShowNotOpen) {
		if (!GetPlayerWnd())
			playerOpen();
	}
	if (!IsIconic(GetPlayerWnd()))
		PostMessage(GetPlayerWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
	else {
		PostMessage(GetPlayerWnd(), WM_SYSCOMMAND, SC_RESTORE, 0);
		SetForegroundWindow(GetPlayerWnd());
	}
}

void Player::hide()
{
	PostMessage(GetPlayerWnd(), WM_SYSCOMMAND, SC_MINIMIZE, 0);
}

// updated to set foreground with !Amp_Display
void Player::display()
{
	if (IsIconic(GetPlayerWnd()))
		PostMessage(GetPlayerWnd(), WM_SYSCOMMAND, SC_RESTORE, 0);
	else
		SetForegroundWindow(GetPlayerWnd());
}

// static functions:

void Player::LoadProperties()
{
#ifdef _DEBUG
	_LSLog(LOG_DEBUG, szLogName, "Loading Player start properties");
#endif

	bStartNormal = GetRCBoolDef("StartNormal", GetRCBoolDef("WinampStartNormal", FALSE) );
	bPlayNotOpen = GetRCBoolDef("PlayNotOpen", FALSE);
	bPlayPauseNotOpen = GetRCBoolDef("PlayPauseNotOpen", FALSE);
	bPlaylistNotOpen = GetRCBoolDef("PlaylistNotOpen", FALSE);
	bPrefsNotOpen = GetRCBoolDef("PrefsNotOpen", FALSE);
	bLoadFileNotOpen = GetRCBoolDef("LoadFileNotOpen", FALSE);
	bShowNotOpen = GetRCBoolDef("ShowNotOpen", FALSE);

#ifdef _DEBUG
	_LSLogPrintf(LOG_DEBUG, "player", "start normal: %d", bStartNormal);
	_LSLogPrintf(LOG_DEBUG, "player", "play not open: %d", bPlayNotOpen);
	_LSLogPrintf(LOG_DEBUG, "player", "playpause not open: %d", bPlayPauseNotOpen);
	_LSLogPrintf(LOG_DEBUG, "player", "playlist not open: %d", bPlaylistNotOpen);
	_LSLogPrintf(LOG_DEBUG, "player", "prefs not open: %d", bPrefsNotOpen);
	_LSLogPrintf(LOG_DEBUG, "player", "loadfile not open: %d", bLoadFileNotOpen);
	_LSLogPrintf(LOG_DEBUG, "player", "show not open: %d", bShowNotOpen);
#endif
}

HWND Player::GetMainWnd()
{
	if (control)
		return control->GetPlayerWnd();
	else
		return NULL;
}

// This is our main message handler where all winamp message are passed to
void Player::mainSendMessage(const int messagenr, int msgtype)
{
	if (control)
	{
		sendMsg(control->GetPlayerWnd(), messagenr, msgtype);
	}	
}

void Player::mainSendKey(int key, const int mod /* = NONE */)
{
	if (control)
	{
		if (mod == VK)
			sendKey(control->GetPlayerWnd(), (short) key);
		else if (mod == NONE)
			sendKey(control->GetPlayerWnd(), VkKeyScan( (char) key));
		else
			sendKey(control->GetPlayerWnd(), VkKeyScan( (char) key), mod);
	}	
}

// joint player handling functions
void Player::sendMsg(HWND wnd, const int msg, int msgtype)
{
	// msgtype, defaults to WM_COMMAND most often used...
	SendMessage(wnd, msgtype, msg, 0);
}

void Player::sendKey(HWND wnd, short key)
{
	UINT scancode = MapVirtualKey(key, 0);

	PostMessage(wnd, WM_KEYDOWN, key, scancode);
	PostMessage(wnd, WM_CHAR, key, scancode);
	PostMessage(wnd, WM_KEYUP, key, scancode);
}

void Player::sendKey(HWND wnd, short key, const int mod)
{
	short modkey = NULL;
	UINT scancode = MapVirtualKey(key, 0);

	if (mod == CTRL)
		modkey = VK_CONTROL;
	else if (mod == ALT)
		modkey = VK_MENU;
	else if (mod == SHIFT)
		modkey = VK_SHIFT;
	else if (mod == WIN)
		modkey = VK_LWIN;

	UINT modcode = MapVirtualKey(modkey, 0);

	PostMessage(wnd, WM_KEYDOWN, modkey, modcode);
	PostMessage(wnd, WM_KEYDOWN, key, scancode);
	PostMessage(wnd, WM_CHAR, key, scancode);
	PostMessage(wnd, WM_KEYUP, key, scancode);
	PostMessage(wnd, WM_KEYUP, modkey, modcode);
}


extern LPCSTR szLogName;

BangManager Player::CommonBangs;
int Player::nLoadedControl = PLAYER_NONE;
int Player::defaultPlayer = PLAYER_NONE;
Player* Player::control = NULL;

void Player::AddCommonBangs()
{
	// add standard, always active commands
	CommonBangs.AddBang("!Amp_ScanPlayer", Bang_ScanPlayer);

	CommonBangs.AddBang("!Amp_OnTop", Bang_OnTop);
	CommonBangs.AddBang("!Amp_Power", Bang_Power);
	CommonBangs.AddBang("!Amp_PowerOn", Bang_PowerOn);
	CommonBangs.AddBang("!Amp_PowerOff", Bang_PowerOff);
	CommonBangs.AddBang("!Amp_Show", Bang_Show);
	CommonBangs.AddBang("!Amp_Hide", Bang_Hide);
	CommonBangs.AddBang("!Amp_Display", Bang_Display);

	CommonBangs.AddBang("!Amp_Repeat", Bang_Repeat);
	CommonBangs.AddBang("!Amp_Shuffle", Bang_Shuffle);

	CommonBangs.AddBang("!Amp_VolumeDown", Bang_VolumeDown);
	CommonBangs.AddBang("!Amp_VolumeUp", Bang_VolumeUp);
	CommonBangs.AddBang("!Amp_Rewd5s", Bang_Rewind5s);
	CommonBangs.AddBang("!Amp_Ffwd5s", Bang_Forward5s);

	CommonBangs.AddBang("!Amp_Prev", Bang_Prev);
	CommonBangs.AddBang("!Amp_Play", Bang_Play);
	CommonBangs.AddBang("!Amp_Pause", Bang_Pause);
	CommonBangs.AddBang("!Amp_Stop", Bang_Stop);
	CommonBangs.AddBang("!Amp_Next", Bang_Next);

	CommonBangs.AddBang("!Amp_Prefs", Bang_Prefs);
	CommonBangs.AddBang("!Amp_LoadDir", Bang_LoadDir);

	CommonBangs.AddBang("!Amp_LoadFile", Bang_LoadFile);

	CommonBangs.InsertBangs();
}

void Player::RemoveCommonBangs()
{
	CommonBangs.RemoveAllBangs();
}


// checks different step.rc for player, either a force setting, or analyze file in WinampPath
// is only run once at module load (and recycle etc.) to save cpu&disk =)
void Player::stepRCPlayer()
{
	int player = PLAYER_NONE;
	char szTemp[MAX_LINE_LENGTH];
	char playerExe[256];

	LoadPlayerLocation("");

	// DynAmpPlayer Winamp2/Winamp3
	if (GetRCString("DynAmpPlayer", szTemp, "", MAX_LINE_LENGTH))
	{
		if (stricmp(szTemp, "winamp2") == 0)
			player = PLAYER_WA2;
		else if (stricmp(szTemp, "winamp3") == 0)
			player = PLAYER_WA3;
		else if (stricmp(szTemp, "foobar2k") == 0 || stricmp(szTemp, "foobar") == 0)
			player = PLAYER_FOOBAR;
	}
	// identify by path .exe
	else
	{
#ifdef _DEBUG
		LSLog(LOG_DEBUG, szLogName, "checking path");
#endif
		if ( szAmpPath.length() > 0 )
		{
			strcpy(playerExe, strrchr(szAmpPath.char_str(), '\\')+sizeof(char) );

#ifdef _DEBUG
			_LSLogPrintf(LOG_DEBUG, szLogName, "exe: %s", playerExe);
#endif

			if (stricmp(playerExe, "winamp.exe") == 0)
				player = PLAYER_WA2;
			else if (stricmp(playerExe, "studio.exe") == 0 || stricmp(playerExe, "winamp3.exe") == 0)
				player = PLAYER_WA3;
			else if (stricmp(playerExe, "foobar2000.exe") == 0 || stricmp(playerExe, "foobar~1.exe") == 0)
				player = PLAYER_FOOBAR;
		}
	}

	defaultPlayer = player;
}

// checks which control to load, first run scan, then step.rc, then default it
void Player::LoadPlayer()
{
	int foundPlayer = ScanPlayer();

	if (foundPlayer == PLAYER_NONE)
	{
#ifdef _DEBUG
		_LSLog(LOG_DEBUG, szLogName, "have to check step.rc for player setting");
#endif
		foundPlayer = defaultPlayer;
	}

	// load the new control
	if (foundPlayer != PLAYER_NONE)
		LoadControl(foundPlayer);
	else
	{
#ifdef _DEBUG
		_LSLog(LOG_DEBUG, szLogName, "Defaulting to WA2");
#endif
		LoadControl(PLAYER_WA2);
	}
}

// scans for a running player
int Player::ScanPlayer()
{
	if (FindWindow(WC_WINAMP2, NULL))
		return PLAYER_WA2;
	else if (FindWindow(WC_WINAMP3, NULL))
		return PLAYER_WA3;
	else if (FindWindow(WC_FOOBAR, NULL))
		return PLAYER_FOOBAR;
	else
		return PLAYER_NONE;
}

// loads a specific control only if it's different from the current one
void Player::LoadControl(const int player)
{
	// only change if we have a new player
	if (nLoadedControl != player)
	{
		// delete the old control
		if (control != NULL)
		{
#ifdef _DEBUG
			_LSLog(LOG_DEBUG, szLogName, "deleting control");
#endif
			delete control;
		}
			
		// save the new control id
		nLoadedControl = player;

		// load new control
		if (player == PLAYER_WA2)
		{
			control = new wa2();
		}
		else if (player == PLAYER_WA3)
		{
			control = new wa3();
		}
		else if (player == PLAYER_FOOBAR)
		{
			control = new FooBar;
		}
		else
		{
#ifdef _DEBUG
			_LSLog(LOG_DEBUG, szLogName, "no new control");
#endif
			control = NULL;
		}
	}
#ifdef _DEBUG
	else
		_LSLog(LOG_DEBUG, szLogName, "control already loaded");
#endif
}


// Common Bang Commands:

void Player::Bang_ScanPlayer(HWND caller, LPCSTR args) {
	LoadPlayer();
}

void Player::Bang_Forward5s(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->forward5s();
}

void Player::Bang_Rewind5s(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->rewind5s();
}

void Player::Bang_VolumeDown(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->volumeDown();
}

void Player::Bang_VolumeUp(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->volumeUp();
}

// might need special handling, so it's defined in each player
void Player::Bang_PowerOff(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->powerOff();
}

void Player::Bang_Prev(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->prev();
}

void Player::Bang_Play(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->play();
}

void Player::Bang_Pause(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->pause();
}

void Player::Bang_Stop(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->stop();
}

void Player::Bang_Next(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->next();
}

void Player::Bang_Repeat(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->repeat();
}

void Player::Bang_Shuffle(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->shuffle();
}

void Player::Bang_OnTop(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->onTop();
}

void Player::Bang_LoadFile(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->loadFile();
}

void Player::Bang_Prefs(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->prefs();
}

void Player::Bang_LoadDir(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->loadDir();
}

// general player functions, doesn't need to be made in player files
void Player::Bang_Power(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->power();
}

void Player::Bang_PowerOn(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->powerOn();
}

void Player::Bang_Show(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->show();
}

void Player::Bang_Hide(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->hide();
}

void Player::Bang_Display(HWND caller, LPCSTR args) {
	LoadPlayer();
	if (control)
		control->display();
}