#include "FooBar2000.h"
#include "../VTK/apis.h"
#include "../current/lsapi/lsapi.h"

extern LPCSTR szLogName;

FooBar::FooBar()
{
#ifdef _DEBUG
	_LSLog(LOG_DEBUG, szLogName, "loading foobar control");
#endif
	LoadPlayerLocation("c:\\progra~1\\foobar~1\\foobar~1.exe");

	// load the !bang command for this player
	char szTemp[MAX_LINE_LENGTH];
	GetRCLine("DynAmpOnFooBar", szTemp, MAX_LINE_LENGTH, "!NONE"); // FooBar load command
	OnPlayerLoad.assign(szTemp);

#ifdef _DEBUG
	_LSLogPrintf(LOG_DEBUG, szLogName, "Running Command: %s", OnPlayerLoad.char_str());
#endif
	LSExecute(GetLitestepWnd(), OnPlayerLoad.char_str(), NULL);

	//FooBarBangs.AddBang("!Amp_CrossFade", Bang_CrossFade);
	//FooBarBangs.InsertBangs();
}

FooBar::~FooBar()
{
	FooBarBangs.RemoveAllBangs();
}

void FooBar::prev() 
{
	mainSendMessage(FOOBAR_PREV);
}

void FooBar::play()
{
	if (!bPlayNotOpen)
	{
		if (!GetPlayerWnd())
		{
			playerOpen();
		}
	}
	mainSendMessage(FOOBAR_PLAY);
}

void FooBar::pause() 
{
	mainSendMessage(FOOBAR_PAUSE);
}

void FooBar::stop() 
{
	mainSendMessage(FOOBAR_STOP);
}

void FooBar::next() 
{
	mainSendMessage(FOOBAR_NEXT);
}

void FooBar::loadFile() 
{
	if (!bLoadFileNotOpen) 
	{
		if (!GetPlayerWnd())
			playerOpen();
	}
	SetForegroundWindow(GetPlayerWnd());
	mainSendMessage(FOOBAR_OPENFILE); 
}

void FooBar::shuffle() {
	mainSendMessage(FOOBAR_SHUFFLE);
}

void FooBar::repeat() {
	mainSendMessage(FOOBAR_REPEAT);
}

void FooBar::powerOff()
{
	mainSendMessage(FOOBAR_EXIT);
}

void FooBar::rewind5s() {
	mainSendMessage(FOOBAR_REW);
}

void FooBar::forward5s() {
	mainSendMessage(FOOBAR_FWD);
}

void FooBar::volumeDown() {
	mainSendMessage(FOOBAR_VOLUMEDOWN);
}

void FooBar::volumeUp() {
	mainSendMessage(FOOBAR_VOLUMEUP);
}

void FooBar::onTop() {
	mainSendMessage(FOOBAR_ALWAYSONTOP);
	/*LONG ex_style;
	ex_style = GetWindowLong(GetPlayerWnd(), GWL_EXSTYLE);
	if (ex_style & WS_EX_TOPMOST)
	{
		SetWindowPos(GetPlayerWnd(), HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ex_style = ex_style & (~WS_EX_TOPMOST);
	}
	else
	{
		SetWindowPos(GetPlayerWnd(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ex_style = ex_style | WS_EX_TOPMOST;
	}*/
}

void FooBar::loadDir() {
	SetForegroundWindow(GetPlayerWnd());
	mainSendMessage(FOOBAR_ADDDIRECTORY);
}

void FooBar::prefs() {
	if (!bPrefsNotOpen) {
		if (!GetPlayerWnd())
			playerOpen();
	}
	mainSendMessage(FOOBAR_PREFERENCES);
}

// This is our main message handler where all winamp message are passed to
void FooBar::mainSendMessage(const int msg)
{
	sendMsg(GetPlayerWnd(), msg);
}

// find window handle
HWND FooBar::GetPlayerWnd()
{
	return FindWindow(WC_FOOBAR, NULL);
}
