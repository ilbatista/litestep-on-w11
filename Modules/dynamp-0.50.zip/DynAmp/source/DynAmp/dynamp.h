#ifndef __DYNAMP_H
#define __DYNAMP_H

#include <windows.h>
#include "..\current\lsapi\lsapi.h"
#include "../VTK/window.h"


#include "player.h" // base player class, rest is derived from this

#define WIN32_LEAN_AND_MEAN
#define MAX_LINE_LENGTH 4096


class cDynamp : public Window {
protected:
	char names[MAX_LINE_LENGTH];
	char command[MAX_LINE_LENGTH];
	char buffer[MAX_LINE_LENGTH];
	char song_title[MAX_LINE_LENGTH], *p, fileProp[MAX_LINE_LENGTH], chan[7];
	int bitrate, samplerate, channels;
	int usePlayer;


public:
	cDynamp(HWND parentWnd, int& code);
	~cDynamp();

	// on load of control command handlers
	void readCommands();
	void deleteCommands();


protected:
	int ScanPlayer();
	int stepRCPlayer();
	void LoadControl(int player);

	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
};

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
