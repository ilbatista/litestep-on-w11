#include "winamp3.h"
#include "../VTK/apis.h"
#include "..\current\lsapi\lsapi.h"

extern LPCSTR szLogName;

// constructors:

wa3::wa3()
{
#ifdef _DEBUG
	_LSLog(LOG_DEBUG, szLogName, "loading wa3 control");
#endif
	LoadPlayerLocation("c:\\progra~1\\winamp3\\studio.exe");

	// load the !bang command for this player
	char szTemp[MAX_LINE_LENGTH];
	GetRCLine("DynAmpOnWA3", szTemp, MAX_LINE_LENGTH, "!NONE"); // WA2 load command
	OnPlayerLoad.assign(szTemp);

#ifdef _DEBUG
	_LSLogPrintf(LOG_DEBUG, szLogName, "Running Command: %s", OnPlayerLoad.char_str());
#endif
	LSExecute(GetLitestepWnd(), OnPlayerLoad.char_str(), NULL);

	Wa3Bangs.AddBang("!Amp_OpenLoc", Bang_OpenLoc);
	Wa3Bangs.AddBang("!Amp_CrossFade", Bang_CrossFade);
	Wa3Bangs.AddBang("!Amp_ReloadSkin", Bang_ReloadSkin);
	Wa3Bangs.AddBang("!Amp_DoubleSize", Bang_DoubleSize);
	Wa3Bangs.AddBang("!Amp_EditID3", Bang_EditID3);
	Wa3Bangs.AddBang("!Amp_ListEnd", Bang_ListEnd);
	Wa3Bangs.AddBang("!Amp_ListStart", Bang_ListStart);

	if (JumpFileInstalled())
		Wa3Bangs.AddBang("!Amp_JumpToFile", Bang_JumpToFile);

	Wa3Bangs.InsertBangs();
}

wa3::~wa3()
{
	Wa3Bangs.RemoveAllBangs();
}

bool wa3::JumpFileInstalled() 
{ 
	HKEY hLM; 
	bool ret=false; 

	// let's open the Registry key for DAO 
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "Software\\JWinamp3", 0, KEY_QUERY_VALUE, &hLM) == ERROR_SUCCESS)
	{ 
		ret = true; 
		RegCloseKey(hLM); 
	} 
	return ret; 
}

// functions:

void wa3::prev()
{
	wa3KeySequence(WA3_PREVSONG);
}

void wa3::play()
{
	if (!bPlayNotOpen)
	{
		if (!GetPlayerWnd())
		{
			playerOpen();
		}
	}
	wa3KeySequence(WA3_PLAY);
}

void wa3::pause()
{
	wa3KeySequence(WA3_PAUSE);
}

void wa3::stop()
{
	wa3KeySequence(WA3_STOP);
}

void wa3::next()
{
	wa3KeySequence(WA3_NEXTSONG);
}

void wa3::loadFile()
{
	if (!bPlayNotOpen)
	{
		if (!GetPlayerWnd())
		{
			playerOpen();
		}
	}
	wa3KeySequence(WA3_FILEPLAY);
}

void wa3::repeat()
{
	wa3KeySequence(WA3_REPEAT);
}

void wa3::shuffle()
{
	wa3KeySequence(WA3_SHUFFLE);
}

void wa3::powerOff()
{
	SendMessage(GetPlayerWnd(), WM_CLOSE, NULL, NULL);
}

void wa3::onTop()
{
	wa3KeySequence(WA3_ONTOP, CTRL);
}

void wa3::rewind5s() {
	wa3vKeySequence(WA3_RWD5S);
}

void wa3::forward5s() {
	wa3vKeySequence(WA3_FFWD5S);
}

void wa3::volumeDown() {
	wa3vKeySequence(WA3_VOLUMEDOWN);
}

void wa3::volumeUp() {
	wa3vKeySequence(WA3_VOLUMEUP);
}

void wa3::loadDir() {
	SetForegroundWindow(GetPlayerWnd());
	wa3KeySequence(WA3_LOADDIR, SHIFT);
}

void wa3::prefs() {
	if (!bPrefsNotOpen) {
		if (!GetPlayerWnd())
			playerOpen();
	}
	wa3KeySequence(WA3_PREFS, CTRL);
}

// stub for sending single key
void wa3::wa3KeySequence(char ckey)
{
	sendKey(GetPlayerWnd(), VkKeyScan(ckey));
}

void wa3::wa3vKeySequence(short vkey)
{
	sendKey(GetPlayerWnd(), vkey);
}

// main key sender to pass to wa3
void wa3::wa3KeySequence(char ckey, const int mod = NONE)
{
	if (mod == VK)
		sendKey(GetPlayerWnd(), (short) ckey);
	else if (mod == NONE)
		sendKey(GetPlayerWnd(), VkKeyScan(ckey));
	else
		sendKey(GetPlayerWnd(), VkKeyScan(ckey), mod);
}

// find window handle
HWND wa3::GetPlayerWnd()
{
	return FindWindow(WC_WINAMP3, NULL);
}

// static functions

void wa3::Bang_OpenLoc(HWND caller, LPCSTR args) {
	mainSendKey(WA3_OPENLOC, CTRL);
}

void wa3::Bang_JumpToFile(HWND caller, LPCSTR args)
{
	mainSendKey(WA3_JUMPTOFILE);
}

void wa3::Bang_CrossFade(HWND caller, LPCSTR args) {
	mainSendKey(WA3_CROSSFADE);
}

void wa3::Bang_ReloadSkin(HWND caller, LPCSTR args)
{
	mainSendKey(WA3_RELOADSKIN, VK);
}

// no idea why wa3 doesn't respond to this one...
void wa3::Bang_DoubleSize(HWND caller, LPCSTR args) {
	mainSendKey(WA3_DOUBLESIZE, CTRL); // 
}

void wa3::Bang_EditID3(HWND caller, LPCSTR args) {
	mainSendKey(WA3_EDITID3, ALT);
}

void wa3::Bang_ListStart(HWND caller, LPCSTR args) {
	plSendVKey(VK_HOME);
}

void wa3::Bang_ListEnd(HWND caller, LPCSTR args) {
	plSendVKey(VK_END);
}

void wa3::plSendVKey(short vkey)
{
	sendKey(getPlaylist(), vkey);
}

void wa3::plSendKey(char ckey)
{
	sendKey(getPlaylist(), VkKeyScan(ckey));
}

// find PL handle
HWND wa3::getPlaylist()
{
	HWND list = FindWindow("BaseWindow_RootWnd", "Playlist"); 
	if (list != NULL)
	{
		list = GetWindow(list, GW_CHILD);	
		list = GetWindow(list, GW_HWNDLAST);
		return list;
	}
	else return NULL;
}