#ifndef __PLAYER_H
#define __PLAYER_H

// mod keys
#define NONE	0
#define ALT		1
#define CTRL	2
#define SHIFT	3
#define WIN		4
#define VK		5

enum PLAYERS {
	PLAYER_NONE = 0,
	PLAYER_WA2,
	PLAYER_WA3,
	PLAYER_FOOBAR
};


#include <windows.h>
#include "../VTK/BangManager.h"
#include "../VTK/SafeString.h"

/*
	Main class for players, others are derived from this.

	Also includes static functions for managing the controllers.
*/
class Player
{
public:
	Player(); // reads settings for visibility states
	//player(LPCSTR command);
	~Player();

	// pure virtual functions, needs to be implemented in each player control

	// how to find this media players window
	virtual HWND GetPlayerWnd() = 0;
	virtual void powerOff() = 0;

	virtual void prev() = 0;
	virtual void play() = 0;
	virtual void pause() = 0;
	virtual void stop() = 0;
	virtual void next() = 0;

	virtual void repeat() = 0;
	virtual void shuffle() = 0;

	virtual void volumeUp() = 0;
	virtual void volumeDown() = 0;
	virtual void forward5s() = 0;
	virtual void rewind5s() = 0;

	virtual void loadDir() = 0;
	virtual void prefs() = 0;

	virtual void loadFile() = 0;
	virtual void onTop() = 0;

	// general functions:
	static void mainSendKey(int key, const int mod = NONE);
	static void mainSendMessage(const int messagenr, int msgtype = WM_COMMAND);

	void power();
	void powerOn();

	void show();
	void hide();
	void display();


protected:
	static void playerOpen();
	static void LoadPlayerLocation(LPCSTR defaultLocation);
	static void LoadProperties();

	// joint player handling functions
	static void sendMsg(HWND wnd, const int msg, int msgtype = WM_COMMAND);
	static void sendKey(HWND wnd, short key);
	static void sendKey(HWND wnd, short key, const int mod);

	// wrappers function for use in bang commands
	static HWND GetMainWnd();


protected:
	// path to player
	static SafeString szAmpPath;
	SafeString OnPlayerLoad;

	static BOOL bStartNormal; // or minimize
	static BOOL bPlayNotOpen; // true: don't open player, else start player if not running
	static BOOL bPlayPauseNotOpen;
	static BOOL bPlaylistNotOpen;
	static BOOL bPrefsNotOpen;
	static BOOL bLoadFileNotOpen;
	static BOOL bShowNotOpen;


// For managing the different controllers:


public:
	static void AddCommonBangs();
	static void RemoveCommonBangs();

	static void LoadControl(const int player = PLAYER_NONE);
	static int ScanPlayer();
	static void LoadPlayer();
	static void stepRCPlayer();
	
	// Common Bangs
	static void Bang_OnTop(HWND, LPCSTR);
	static void Bang_Show(HWND, LPCSTR);
	static void Bang_Hide(HWND, LPCSTR);
	static void Bang_Display(HWND, LPCSTR);

	static void Bang_Repeat(HWND, LPCSTR);
	static void Bang_Shuffle(HWND, LPCSTR);

	static void Bang_VolumeDown(HWND, LPCSTR);
	static void Bang_VolumeUp(HWND, LPCSTR);
	static void Bang_Rewind5s(HWND, LPCSTR);
	static void Bang_Forward5s(HWND, LPCSTR);

	static void Bang_Prefs(HWND, LPCSTR);
	static void Bang_LoadDir(HWND, LPCSTR);

	static void Bang_LoadFile(HWND, LPCSTR);

	static void Bang_Power(HWND, LPCSTR);
	static void Bang_PowerOn(HWND, LPCSTR);
	static void Bang_PowerOff(HWND, LPCSTR);
	static void Bang_ScanPlayer(HWND, LPCSTR);

	static void Bang_Prev(HWND, LPCSTR);
	static void Bang_Play(HWND, LPCSTR);
	static void Bang_Pause(HWND, LPCSTR);
	static void Bang_Stop(HWND, LPCSTR);
	static void Bang_Next(HWND, LPCSTR);
	static void Bang_FileLoad(HWND, LPCSTR);


protected:
	static BangManager CommonBangs;
	static Player* control;
	static int nLoadedControl;
	static int defaultPlayer;

};

#endif
