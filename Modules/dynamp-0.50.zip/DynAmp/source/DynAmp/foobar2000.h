#ifndef __FOORBAR2000_H
#define __FOORBAR2000_H

#define FOOBAR_STOP					40010
#define FOOBAR_PAUSE				40044
#define FOOBAR_PLAY 				40009
#define FOOBAR_NEXT 				40011
#define FOOBAR_PREV                 40051
#define FOOBAR_FWD					41002
#define FOOBAR_REW					41001
#define FOOBAR_PLAYPAUSE			107
#define FOOBAR_VOLUMEUP				102
#define FOOBAR_VOLUMEDOWN			103
#define FOOBAR_SELECTALL			104
#define FOOBAR_ALWAYSONTOP			40041
#define FOOBAR_PLAYLISTSEARCH		40040
#define FOOBAR_PLAYLISTUNDO			40036
#define FOOBAR_ABOUT				40018
#define FOOBAR_PREFERENCES			40007
#define FOOBAR_SHUFFLE 				40014
#define FOOBAR_FOLLOWCURSOR			40047
#define FOOBAR_REPEAT				40015
#define FOOBAR_REPEATONE			40042
#define FOOBAR_STOPAFTERCURRENT		40045
#define FOOBAR_OPENFILE				40049
#define FOOBAR_ADDDIRECTORY			40035
#define FOOBAR_ADDFILES				40037
#define FOOBAR_ADDPLAYLIST			40038
#define FOOBAR_SORTBYFILEPATH   	40002
#define FOOBAR_SORTBYDISPLAYNAME 	40043
#define FOOBAR_SORTBY				40048
#define FOOBAR_SORTBYARTIST			40003
#define FOOBAR_SORTBYALBUM			40004
#define FOOBAR_SORTBYTRACKNUMBER 	40016
#define FOOBAR_SORTBYTITLE			40017
#define FOOBAR_PLAYLISTRANDOMIZE	40019
#define FOOBAR_REMOVEDUPLICATES     40005
#define FOOBAR_REMOVEDEADENTRIES	40046
#define FOOBAR_CLEAR				40012
#define FOOBAR_REMOVESELECTION		40013
#define FOOBAR_CROP					40027 
#define FOOBAR_SAVEPLAYLIST			40006
#define FOOBAR_EXIT					40008
#define FOOBAR_HIDE					1001

#define WC_FOOBAR		"FOOBAR2000_CLASS"


#include "player.h"
#include "../VTK/BangManager.h"

class FooBar : public Player
{
public:
	FooBar();
	~FooBar();

	HWND GetPlayerWnd();
	void powerOff();

	void repeat();
	void shuffle();

	void prev();
	void play();
	void pause();
	void stop();
	void next();

	void volumeUp();
	void volumeDown();
	void forward5s();
	void rewind5s();

	void loadDir();
	void prefs();

	void onTop();
	void loadFile();

	void mainSendMessage(const int msg);

protected:
	BangManager FooBarBangs;
};


#endif