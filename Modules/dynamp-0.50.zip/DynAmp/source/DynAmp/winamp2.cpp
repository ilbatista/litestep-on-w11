#include "winamp2.h"
#include "../VTK/apis.h"
#include "..\current\lsapi\lsapi.h"

// initialize this static variables
int wa2::position = 0;

extern LPCSTR szLogName;

// constructors:

wa2::wa2()
{
#ifdef _DEBUG
	_LSLog(LOG_DEBUG, szLogName, "loading wa2 control");
#endif

	char szTemp[MAX_LINE_LENGTH];

	// load string where to launch the program from
	LoadPlayerLocation("c:\\progra~1\\winamp\\winamp.exe");

	// load the !bang command for this player
	GetRCLine("DynAmpOnWA2", szTemp, MAX_LINE_LENGTH, "!NONE"); // WA2 load command
	OnPlayerLoad.assign(szTemp);

#ifdef _DEBUG
	_LSLogPrintf(LOG_DEBUG, szLogName, "Running Command: %s", OnPlayerLoad.char_str());
#endif
	LSExecute(GetLitestepWnd(), OnPlayerLoad.char_str(), NULL);

	Wa2Bangs.AddBang("!Amp_OpenLoc", Bang_OpenLoc);
	Wa2Bangs.AddBang("!Amp_StopFade", Bang_StopFade);
	Wa2Bangs.AddBang("!Amp_AddToPlaylist", Bang_AddToPlaylist);
	Wa2Bangs.AddBang( "!Amp_StopAfterTrack", Bang_StopAfterTrack );
	Wa2Bangs.AddBang( "!Amp_PlayCD", Bang_PlayCD );
	Wa2Bangs.AddBang( "!Amp_ReloadSkin", Bang_ReloadSkin );
	Wa2Bangs.AddBang( "!Amp_DoubleSize", Bang_DoubleSize );
	Wa2Bangs.AddBang( "!Amp_EditID3", Bang_EditID3 );
	Wa2Bangs.AddBang( "!Amp_AddSong", Bang_AddSong );
	Wa2Bangs.AddBang( "!Amp_LoadEQPreset", Bang_LoadEQPreset );
	Wa2Bangs.AddBang( "!Amp_HighPriority", Bang_HighPriority );
	Wa2Bangs.AddBang( "!Amp_EasyMove", Bang_EasyMove );
	Wa2Bangs.AddBang( "!Amp_Eq", Bang_Eq );
	Wa2Bangs.AddBang( "!Amp_Jump10Back", Bang_Jump10Back );
	Wa2Bangs.AddBang( "!Amp_Jump10Fwd", Bang_Jump10Fwd );
	Wa2Bangs.AddBang( "!Amp_JumpToFile", Bang_JumpToFile );
	Wa2Bangs.AddBang( "!Amp_JumpToTime", Bang_JumpToTime );
	Wa2Bangs.AddBang( "!Amp_ListEnd", Bang_ListEnd );
	Wa2Bangs.AddBang( "!Amp_ListStart", Bang_ListStart );
	Wa2Bangs.AddBang( "!Amp_MainMenuPopup", Bang_MainMenuPopup );
	Wa2Bangs.AddBang( "!Amp_Playlist", Bang_Playlist );
	Wa2Bangs.AddBang( "!Amp_SelectSkin", Bang_SelectSkin );
	Wa2Bangs.AddBang( "!Amp_SetPanning", Bang_SetPanning );
	Wa2Bangs.AddBang( "!Amp_SetVolume", Bang_SetVolume );
	Wa2Bangs.AddBang( "!Amp_ShadeBoth", Bang_ShadeBoth );
	Wa2Bangs.AddBang( "!Amp_ShadePlaylist", Bang_ShadePlaylist );
	Wa2Bangs.AddBang( "!Amp_StartPlugin", Bang_StartPlugin );
	Wa2Bangs.AddBang( "!Amp_StopPlugin", Bang_StopPlugin );
	Wa2Bangs.AddBang( "!Amp_ToggleBrowser", Bang_ToggleBrowser );
	Wa2Bangs.AddBang( "!Amp_VisSetup", Bang_VisSetup );
	Wa2Bangs.AddBang( "!Amp_WindowShade", Bang_WindowShade );
	Wa2Bangs.AddBang( "!Amp_Rew", Bang_Rew );
	Wa2Bangs.AddBang( "!Amp_Ffwd10s", Bang_Ffwd10s );
	Wa2Bangs.AddBang( "!Amp_Ffwd20s", Bang_Ffwd20s );
	Wa2Bangs.AddBang( "!Amp_Rewd10s", Bang_Rew10s );
	Wa2Bangs.AddBang( "!Amp_Rewd20s", Bang_Rew20s );
	Wa2Bangs.AddBang( "!Amp_PlayPause", Bang_PlayPause );
	Wa2Bangs.AddBang( "!Amp_TimeRemaining", Bang_TimeRemaining );
	Wa2Bangs.AddBang( "!Amp_TimeElapsed", Bang_TimeElapsed );
	Wa2Bangs.AddBang( "!Amp_Restart", Bang_Restart );
	//Wa2Bangs.AddBang( "!Amp_MovePosition", Bang_MovePosition );
	//Wa2Bangs.AddBang( "!Amp_FileInfo", Bang_FileInfo );

	Wa2Bangs.InsertBangs();
}

wa2::~wa2()
{
	Wa2Bangs.RemoveAllBangs();
}

// find window handle
HWND wa2::GetPlayerWnd()
{
	return FindWindow(WC_WINAMP2, NULL);
}

// functions:

void wa2::prev() 
{
	mainSendMessage(WINAMP_PREVSONG);
}

void wa2::play()
{
	if (!bPlayNotOpen)
	{
		if (!GetPlayerWnd())
		{
			playerOpen();
		}
	}
	mainSendMessage(WINAMP_PLAY);
}

void wa2::pause() 
{
	mainSendMessage(WINAMP_PAUSE);
}

void wa2::stop() 
{
	mainSendMessage(WINAMP_STOP);
}

void wa2::next() 
{
	mainSendMessage(WINAMP_NEXTSONG);
}

void wa2::loadFile() 
{
	if (!bLoadFileNotOpen) 
	{
		if (!GetPlayerWnd())
			playerOpen();
	}
	SetForegroundWindow(GetPlayerWnd());
	mainSendMessage(WINAMP_FILE_PLAY); 
}

void wa2::shuffle() {
	mainSendMessage(WINAMP_FILE_SHUFFLE);
}

void wa2::repeat() {
	mainSendMessage(WINAMP_FILE_REPEAT);
}

void wa2::powerOff()
{
	mainSendMessage(WINAMP_FILE_QUIT);
}

void wa2::rewind5s() {
	mainSendMessage(WINAMP_REW5S);
}

void wa2::forward5s() {
	mainSendMessage(WINAMP_FFWD5S);
}

void wa2::volumeDown() {
	mainSendMessage(WINAMP_VOLUMEDOWN);
}

void wa2::volumeUp() {
	mainSendMessage(WINAMP_VOLUMEUP);
}

void wa2::onTop() {
	mainSendMessage(WINAMP_OPTIONS_AOT);
}

void wa2::loadDir() {
	SetForegroundWindow(GetPlayerWnd());
	mainSendMessage(WINAMP_FILE_DIR);
}

void wa2::prefs() {
	if (!bPrefsNotOpen) {
		if (!GetPlayerWnd())
			playerOpen();
	}
	mainSendMessage(WINAMP_OPTIONS_PREFS);
}


// static functions:
void wa2::Bang_OpenLoc(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_OPEN_LOC);
}

void wa2::Bang_AddToPlaylist(HWND caller, LPCSTR args)
{
	plSendKey(WINAMP_ADDFILES2PL);		
}

void wa2::Bang_StopFade(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_BUTTON4_SHIFT);
}

void wa2::Bang_StopAfterTrack(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_BUTTON4_CTRL);
}

void wa2::Bang_PlayCD(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_PLAYCD);
}

void wa2::Bang_ReloadSkin(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_RELOAD_SKIN);
}

void wa2::Bang_DoubleSize(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_OPTIONS_DSIZE);
}

void wa2::Bang_TimeElapsed(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_OPTIONS_ELAPSED);
}

void wa2::Bang_TimeRemaining(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_OPTIONS_REMAINING);
}

void wa2::Bang_AddSong(HWND caller, LPCSTR args) {
	char addSong[MAX_LINE_LENGTH];
	strcat(addSong, szAmpPath.char_str());
	strcat(addSong, " /ADD ");
	strcat(addSong, args);
	WinExec(addSong, SW_NORMAL);
	strcpy(addSong, "");
}

void wa2::Bang_About(HWND caller, LPCSTR args) {
	SetForegroundWindow(GetMainWnd()); // You have to push the window forward before sending messages to keep it on top.
	mainSendMessage(WINAMP_HELP_ABOUT);
}

void wa2::Bang_EasyMove(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_OPTIONS_EASYMOVE);
}

void wa2::Bang_Eq(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_OPTIONS_EQ);
}

void wa2::Bang_Jump10Back(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_JUMP10BACK);
}

void wa2::Bang_Jump10Fwd(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_JUMP10FWD);
}
void wa2::Bang_JumpToFile(HWND caller, LPCSTR args) {
	SetForegroundWindow(GetMainWnd());
	mainSendMessage(WINAMP_JUMPFILE);
}

void wa2::Bang_JumpToTime(HWND caller, LPCSTR args) {
	SetForegroundWindow(GetMainWnd());
	mainSendMessage(WINAMP_JUMPTIME);
}

void wa2::Bang_ListEnd(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_LIST_END);
}

void wa2::Bang_ListStart(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_LIST_START);
}

void wa2::Bang_MainMenuPopup(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_MAINMENU);
}

void wa2::Bang_Playlist(HWND caller, LPCSTR args) {
	if (!bPlaylistNotOpen) {
		if (!GetMainWnd())
			playerOpen();
	}
	mainSendMessage(WINAMP_OPTIONS_PLEDIT);
}

void wa2::Bang_SelectSkin(HWND caller, LPCSTR args) {
	SetForegroundWindow(GetMainWnd());
	mainSendMessage(WINAMP_OPTIONS_SKINS);
}

void wa2::Bang_SetPanning(HWND caller, LPCSTR args) {
	SendMessage(GetMainWnd(), WM_USER, (const int)args, WINAMP_USER_SETPANNING);  // Args = 0 - 255, 0 = all_left, 255 = all_right
}

void wa2::Bang_SetVolume(HWND caller, LPCSTR args) {
	SendMessage(GetMainWnd(), WM_USER, (const int)args, WINAMP_USER_SETVOLUME); 
}

void wa2::Bang_ShadeBoth(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_PLAYLIST_WINDOWSHADE);
	mainSendMessage(WINAMP_OPTIONS_WINDOWSHADE);
}

void wa2::Bang_ShadePlaylist(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_PLAYLIST_WINDOWSHADE);
}

void wa2::Bang_StartPlugin(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_VISPLUGIN);
}

void wa2::Bang_StopPlugin(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_VISPLUGIN);
}

void wa2::Bang_ToggleBrowser(HWND caller, LPCSTR args) {
	SetForegroundWindow(GetMainWnd());
	mainSendMessage(WINAMP_MINIBROWSER_TOGGLE);
}

void wa2::Bang_VisSetup(HWND caller, LPCSTR args) {
	SetForegroundWindow(GetMainWnd());
	mainSendMessage(WINAMP_VISSETUP);
}

void wa2::Bang_WindowShade(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_OPTIONS_WINDOWSHADE);
}

void wa2::Bang_Rew(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_REWIND);
}

void wa2::Bang_HighPriority(HWND caller, LPCSTR args) {
	mainSendMessage(WINAMP_HIGH_PRIORITY);
}

void wa2::Bang_LoadEQPreset(HWND caller, LPCSTR args) {
	SetForegroundWindow(GetMainWnd());
	mainSendMessage(IDM_EQ_LOADPRE);
}

void wa2::Bang_PlayPause(HWND caller, LPCSTR args) {
	if (!bPlayPauseNotOpen) {
		if (!GetMainWnd())
			playerOpen();
	}
	int status = SendMessage(GetMainWnd(), WM_USER, 0, WINAMP_USER_STATUS);
	(status == 1) ? mainSendMessage(WINAMP_PAUSE) : mainSendMessage(WINAMP_PLAY);
}

void wa2::Bang_Ffwd10s(HWND caller, LPCSTR args) {
	MovePositive(10);
}

void wa2::Bang_Ffwd20s(HWND caller, LPCSTR args) {
	MovePositive(20);
}

void wa2::Bang_Rew10s(HWND caller, LPCSTR args) {
	MoveNegative(10);
}

void wa2::Bang_Rew20s(HWND caller, LPCSTR args) {
	MoveNegative(20);
}

void wa2::Bang_Restart(HWND caller, LPCSTR args) {

	SendMessage(GetMainWnd(), WM_USER, 0, WINAMP_USER_RESTART);
}

void wa2::Bang_EditID3(HWND caller, LPCSTR args)
{
	SetForegroundWindow(GetMainWnd());
	mainSendMessage(WINAMP_EDIT_ID3);
}

/*void wa2::Bang_MovePosition(HWND caller, LPCSTR args) {
	if (args) {
		char* tokens[1]; 
		char modifier[1]; // + or -
		char amount[10]; // amount to change by
		modifier[0] = amount[0] = 0; // nulling the first in the array
			
		tokens[0] = modifier;
		tokens[1] = amount;
			
		LCTokenize(args, tokens, 2, NULL);
		// if modifier is negative send to MoveNegative(), else MovePositive()
		(!strcmp(modifier, "-")) ? MoveNegative((int)amount) : MovePositive((int)amount);
	}
}*/

/*void wa2::fileInfo() {
// Getting the winamp title and removing the "-Winamp" from it
	GetWindowText(getWA2wnd(), song_title, sizeof(song_title));
	p = song_title + strlen(song_title) - 8;
	while (p >= song_title) 
	{
		if (!strnicmp(p, "- Winamp", 8))
			break;
		p--;
	}
	if (p >= song_title)
		p--;
	while (p >= song_title && *p == ' ') 
		p--;
	*++p = 0;
		
	samplerate = SendMessage(getWA2wnd(), WM_USER, 0, WINAMP_USER_BITRATE); // The samplerate of the current song
	bitrate = SendMessage(getWA2wnd(), WM_USER, 1, WINAMP_USER_BITRATE); // The bitrate of the current song
	channels = SendMessage(getWA2wnd(), WM_USER, 2, WINAMP_USER_BITRATE); // The channel status
	
	(channels == 1) ? strcpy(chan, "Mono") : strcpy(chan, "Stereo");
	sprintf(fileProp, "Bitrate: %d kbps\nSampleRate: %d khz\nChannels: %s", bitrate, samplerate, chan);
	MessageBox(GetLitestepWnd(), fileProp, song_title, MB_OK | MB_ICONQUESTION | MB_SETFOREGROUND);
}*/
// These are the main processing functions...

// Moves position backwards
void wa2::MoveNegative(int amount) {
	amount *= 1000;
	position = SendMessage(GetMainWnd(), WM_USER, 0, WINAMP_USER_SONGPOSITION);
	SendMessage(GetMainWnd(), WM_USER, position - amount, WINAMP_USER_SONGSEEK);
}

// Moves position forwards
void wa2::MovePositive(int amount) {
	amount *= 1000;
	position = SendMessage(GetMainWnd(), WM_USER, 0, WINAMP_USER_SONGPOSITION);
	SendMessage(GetMainWnd(), WM_USER, position + amount, WINAMP_USER_SONGSEEK);
}

void wa2::plSendKey(char ckey)
{
	sendKey(getWA2PE(), VkKeyScan(ckey));
}

HWND wa2::getWA2PE()
{
	return FindWindow(WC_WINAMP2_PE, NULL);
}
