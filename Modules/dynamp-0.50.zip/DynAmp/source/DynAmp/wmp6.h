#define WC_WMP6			"Media Player 2"

// file:
#define WMP6_OPEN		"CTRL+O"
#define WMP6_SAVEAS		"CTRL+S"

// view:
#define WMP6_STANDARD	"ctrl+1"
#define WMP6_COMPACT	"ctrl+2"
#define WMP6_MINIMAL	"ctrl+3"

#define WMP6_SCREENFULL	"alt+enter"
#define WMP6_SCREEN50	"alt+1"
#define WMP6_SCREEN100	"alt+2"
#define WMP6_SCREEN200	"alt+3"
#define WMP6_AOT		"CTRL+T"

// play:
#define WMP6_PLAY		VK_SPACE
#define WMP6_PAUSE		VK_SPACE
#define WMP6_STOP		VK_ESC / .

#define WMP6_SKIPBACK	VK_PAGEUP
#define WMP6_SKIPFFWD	VK_PAGEDOWN
#define WMP6_REWIND		"ctrl+ VK_LEFT"
#define WMP6_FFWD		"ctrl+ VK_RIGHT"

#define WMP6_PREVIEW	"CTRL+V"
#define WMP6_GOTO		"CTRL+G"

#define WMP6_VOLUMEUP	VK_UP
#define WMP6_VOLUMEDOWN	VK_DOWN
#define WMP6_MUTE		"CTRL+M"

// go:
#define WMP6_BACK "ALT+VK_LEFT"
#define WMP6_NEXT "ALT+VK_RIGHT"
#define WMP6_GORADIO "CTRL+F"
#define WMP6_GOMEDIAGUIDE "CTRL+VK_HOME"
#define WMP6_GOMUSIC "CTRL+U"
