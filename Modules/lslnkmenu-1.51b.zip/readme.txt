Carl (the author of LsLnkMenu) was kind enough to send me his code,
but its been wasting away on my hard drive for about a month.
I coded up quick support for evars (for bitmaps only right now,
PanelMiddleBitmap, MainBitmap, etc...it  doesn't  work with other options).

You have three ways of specifying bitmaps now...

MainBitmap = C:\Path\To\My\Image.bmp ; the old way
MainBitmap = image.bmp    ; assumes LSImageFolder, this is the "normal" way a modle does it
MainBitmap = $MySpecialEvar$image.bmp  ;  you can use whatever evar you like.

http://www.personal.psu.edu/users/j/e/jew208/dl/LsLnkMenu.dll

Later
 - repugnant

===============
'LsLnkMenu 1.51b' modified by repugnant
originally by Carluchi
email from repugnant to the LS Mailing List on Jan 13th, 2002

This modification of LsLnkMenu allows you to use evars ($litestepdir$, etc)
with the PanelMiddleBitmap and MainBitmap options in the step.rc.

----
readme "created" by rootrider
ShellFront - http://www.shellfront.org/