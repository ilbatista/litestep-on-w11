why did you even *follow* that link in the email?
*sigh*