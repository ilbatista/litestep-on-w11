#ifndef __DYNAMP_H
#define __DYNAMP_H

#include <windows.h>
#include "..\current\lsapi\lsapi.h"
#include "..\current\lsapi\lswinbase.h"

#include "player.h" // base player class, rest is derived from this
#include "winamp2.h"
#include "winamp3.h"

#define WIN32_LEAN_AND_MEAN
#define MAX_LINE_LENGTH 4096


class cDynamp : public Window {
private:
	char names[MAX_LINE_LENGTH];
	char command[MAX_LINE_LENGTH];
	char buffer[MAX_LINE_LENGTH];
	char song_title[MAX_LINE_LENGTH], *p, fileProp[MAX_LINE_LENGTH], chan[7];
	int bitrate, samplerate, channels;
	int usePlayer;

public:
	// handle to controller, wa2/3
	player *control;
	int loadedControl;

public:
	cDynamp(HWND parentWnd, int& code);
	~cDynamp();

	// on load of control command handlers
	void readCommands();
	void deleteCommands();

	// find a suitable player
	void LoadPlayer();

private:
	int ScanPlayer();
	int stepRCPlayer();
	void LoadControl(int player);

	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
};

void Bang_Power(HWND, LPCSTR);
void Bang_PowerOn(HWND, LPCSTR);
void Bang_PowerOff(HWND, LPCSTR);
void Bang_ScanPlayer(HWND, LPCSTR);

void Bang_Prev(HWND, LPCSTR);
void Bang_Play(HWND, LPCSTR);
void Bang_Pause(HWND, LPCSTR);
void Bang_Stop(HWND, LPCSTR);
void Bang_Next(HWND, LPCSTR);
void Bang_FileLoad(HWND, LPCSTR);


extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
