#include "winamp3.h"
#include "log.h"
#include "..\current\lsapi\lsapi.h"


// constructors:

wa3::wa3()
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, logName, "loading wa3 control");
#endif
	GetRCString("WinampPath", szAmpPath, "c:\\progra~1\\winamp3\\studio.exe", MAX_LINE_LENGTH);

	// load the !bang command for this player
	char szTemp[MAX_LINE_LENGTH];
	GetRCLine("DynAmpOnWA3", szTemp, MAX_LINE_LENGTH, "!NONE"); // WA2 load command
	OnPlayerLoad = new char[strlen(szTemp)+1];
	strcpy(OnPlayerLoad, szTemp);

	// if there is a command to run
	if ( OnPlayerLoad != NULL )
	{
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "Running Command: %s", OnPlayerLoad);
#endif
		LSExecute(GetLitestepWnd(), OnPlayerLoad, NULL);
	}

	// specific wa3 functions, needs to be defined as static and placed in .h
	AddBangCommand("!Amp_CrossFade", Bang_CrossFade);
	AddBangCommand("!Amp_ReloadSkin", Bang_ReloadSkin);
	AddBangCommand("!Amp_DoubleSize", Bang_DoubleSize);
	AddBangCommand("!Amp_EditID3", Bang_EditID3);
	AddBangCommand("!Amp_ListEnd", Bang_ListEnd);
	AddBangCommand("!Amp_ListStart", Bang_ListStart);
}

wa3::~wa3()
{
	// delete !bang commands
	if (OnPlayerLoad != NULL) {
		delete [] OnPlayerLoad;
		OnPlayerLoad = NULL;
	}

	RemoveBangCommand("!Amp_CrossFade");
	RemoveBangCommand("!Amp_ReloadSkin");
	RemoveBangCommand("!Amp_DoubleSize");
	RemoveBangCommand("!Amp_EditID3");
	RemoveBangCommand("!Amp_ListEnd");
	RemoveBangCommand("!Amp_ListStart");
}


// functions:

void wa3::prev()
{
	wa3KeySequence(WA3_PREVSONG);
}

void wa3::play()
{
	if (!PlayNotOpen)
	{
		if (!GetPlayerWnd())
		{
			playerOpen();
		}
	}
	wa3KeySequence(WA3_PLAY);
}

void wa3::pause()
{
	wa3KeySequence(WA3_PAUSE);
}

void wa3::stop()
{
	wa3KeySequence(WA3_STOP);
}

void wa3::next()
{
	wa3KeySequence(WA3_NEXTSONG);
}

void wa3::loadFile()
{
	if (!PlayNotOpen)
	{
		if (!GetPlayerWnd())
		{
			playerOpen();
		}
	}
	wa3KeySequence(WA3_FILEPLAY);
}

void wa3::repeat()
{
	wa3KeySequence(WA3_REPEAT);
}

void wa3::shuffle()
{
	wa3KeySequence(WA3_SHUFFLE);
}

void wa3::powerOff()
{
	SendMessage(GetPlayerWnd(), WM_CLOSE, NULL, NULL);
}

void wa3::onTop()
{
	wa3KeySequence(WA3_ONTOP, CTRL);
}

void wa3::rewind5s() {
	wa3vKeySequence(WA3_RWD5S);
}

void wa3::forward5s() {
	wa3vKeySequence(WA3_FFWD5S);
}

void wa3::volumeDown() {
	wa3vKeySequence(WA3_VOLUMEDOWN);
}

void wa3::volumeUp() {
	wa3vKeySequence(WA3_VOLUMEUP);
}

void wa3::loadDir() {
	SetForegroundWindow(GetPlayerWnd());
	wa3KeySequence(WA3_LOADDIR, CTRL);
}

void wa3::openLoc() {
	wa3KeySequence(WA3_OPENLOC, SHIFT);
}

void wa3::prefs() {
	if (!PrefsNotOpen) {
		if (!GetPlayerWnd())
			playerOpen();
	}
	wa3KeySequence(WA3_PREFS, CTRL);
}

// stub for sending single key
void wa3::wa3KeySequence(char ckey)
{
	player::sendKey(GetPlayerWnd(), VkKeyScan(ckey));
}

void wa3::wa3vKeySequence(short vkey)
{
	player::sendKey(GetPlayerWnd(), vkey);
}

// main key sender to pass to wa3
void wa3::wa3KeySequence(char ckey, const int mod = NONE)
{
	if (mod == VK)
		player::sendKey(GetPlayerWnd(), (short) ckey);
	else if (mod == NONE)
		player::sendKey(GetPlayerWnd(), VkKeyScan(ckey));
	else
		player::sendKey(GetPlayerWnd(), VkKeyScan(ckey), mod);
}

// find window handle
HWND wa3::GetPlayerWnd()
{
	return FindWindow(WC_WINAMP3, NULL);
}

// static functions

void wa3::Bang_CrossFade(HWND caller, LPCSTR args) {
	mainSendKey(WA3_CROSSFADE);
}

void wa3::Bang_ReloadSkin(HWND caller, LPCSTR args)
{
	mainSendVKey(WA3_RELOADSKIN);
}

// no idea why wa3 doesn't respond to this one...
void wa3::Bang_DoubleSize(HWND caller, LPCSTR args) {
	mainSendKey(WA3_DOUBLESIZE, CTRL); // 
}

void wa3::Bang_EditID3(HWND caller, LPCSTR args) {
	mainSendKey(WA3_EDITID3, ALT);
}

void wa3::Bang_ListStart(HWND caller, LPCSTR args) {
	plSendVKey(VK_HOME);
}

void wa3::Bang_ListEnd(HWND caller, LPCSTR args) {
	plSendVKey(VK_END);
}

void wa3::mainSendVKey(short vkey)
{
	player::sendKey(getMain(), vkey);
}

void wa3::mainSendKey(char ckey, const int mod)
{
	player::sendKey(getMain(), VkKeyScan(ckey), mod);
}

void wa3::mainSendKey(char ckey)
{
	player::sendKey(getMain(), VkKeyScan(ckey));
}

void wa3::plSendVKey(short vkey)
{
	player::sendKey(getPlaylist(), vkey);
}

void wa3::plSendKey(char ckey)
{
	player::sendKey(getPlaylist(), VkKeyScan(ckey));
}

// find main window handle
HWND wa3::getMain()
{
	return FindWindow(WC_WINAMP3, NULL);
}

// find PL handle
HWND wa3::getPlaylist()
{
	HWND list = FindWindow("BaseWindow_RootWnd", "Playlist"); 
	if (list != NULL)
	{
		list = GetWindow(list, GW_CHILD);	
		list = GetWindow(list, GW_HWNDLAST);
		return list;
	}
	else return NULL;
}