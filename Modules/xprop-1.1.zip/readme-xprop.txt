//////////////////////////
// Module: XProp 1.1
// Written By: MrJukes
// Graphics By: AznRomeo
// Released: 8/4/00
//////////////////////////

Description:
XProp is a small window that sits on your desktop that shows the area below
your mouse cursor as magnified, along with colour info etc. Again it`s
totally configurable, even down to the amount of zoom in the magnified area.
(included by rootrider (FPN) and written by jalist (ls2k.org))


//////////////////////////
// Step.rc
//////////////////////////
; XProp starts hidden if present
XPropStartHidden
; XProp starts locked in place at XPropX, XPropY
XPropStartLocked
; XProp will not always be on top
XPropNotAlwaysOnTop

; The starting X position of the XProp window
XPropX 0
; The starting Y position of the XProp window
XPropY 0

; The background image.
; This has Magic Pink(tm) support.
; The width and height of the window are based on this bmp.
XPropBg xprop.bmp

; The x coordinate of the maginfication window
XPropMagWindowX 6
; The y coordinate of the maginfication window
XPropMagWindowY 6
; The width of the maginfication window
XPropMagWindowW 88
; The height of the maginfication window
XPropMagWindowH 88
; The x coordinate of the text area
XPropTextWindowX 8
; The y coordinate of the text area
XPropTextWindowY 96
; The width of the text area
XPropTextWindowW 85
; The height of the text area
XPropTextWindowH 47

; The font XProp uses
XPropFontFace Arial
; The size of that font
XPropFontSize 14
; The color of that font
XPropFontColor 0x00000000
; The string XProp displays
; The order cannot be changed, only the format.
; \n = new line
; %d = the place where the value is inserted
XPropFormat "X: %d Y: %d\nR: %d G: %d\nB: %d - #%06lx"

; The frequency (in ms) that XProp will update its position/contents
XPropTimer 50
; How far the XProp window is from the cursor
XPropOffsetX 25
XPropOffsetY 25
; The size of the crosshair that is drawn in the magnification window
XPropCrosshairSize 10
; The color of the crosshair
XPropCrosshairColor 0x00000000

//////////////////////////
// !Bangs
//////////////////////////

; Zoom in
!XPropZoomIn
; Zoom out
!XPropZoomOut
; Show the XProp window
!XPropShow
; Hide the XProp window
!XPropHide
; Toggle the XProp window's visibility
!XPropToggle
; Set the origin to the current cursor location
!XPropSetOrigin
; Reset the origin back to the top left of the screen (0, 0)
!XPropResetOrigin
; Toggles whether or not the XProp window follows your cursor
!XPropLock
; Toggles whether the contents of the XPropWindow are updated
!XPropFreeze
//////////////////////////

If you find any bugs or have comments and suggestions, e-mail me at mrjukes@purdue.edu.

Have Fun,
	MrJukes