/*
   This is a part of the Niver's Settings IPC LiteStep Module SDK.

   Copyright (C) 2003 Niversoft
   http//niversoft.dyndns.org
   info@niversoft.dyndns.org

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//-------------------------------------------------------------------------------------


// this sample doesn't do anything very cool
// it's just provided to devs to help them use the serttingsipc_client
// It can also be used to verify that the server module if correclty installed and started

#include <windows.h>
#include <stdio.h>

#include "include/settingsipc_client.h"

int main(int argc, char* argv[])
{
   if (settingsipc_client::IsServerPresent())
      // verifies the presence of the server
   {
      // prints LiteStep Hwnd
      printf("Litestep found. HWND: 0x%x\r\n", settingsipc_client::GetLitestepWnd());

      // Gathers an arbitrary bool setting
      BOOL DesktopArea = settingsipc_client::GetRCBool("SetDesktopArea", true);
      printf("DesktopArea: %s\r\n", DesktopArea ? "true" : "false");

      char buf[BUFSIZE];
      settingsipc_client::GetRCString( "PopupEntryFontFace", buf, "not found", BUFSIZE); // Gathers an arbitrary string setting
      printf("PopupEntryFontFace: %s\r\n", buf);

   }
   else
      printf("Server is not present\r\n");

   printf("Press RETURN to exit\r\n");
   getchar(); // wait for input
	return 0;
}

