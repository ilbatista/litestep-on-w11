/*
   This is a part of the Niver's Settings IPC LiteStep Module SDK

   Copyright (C) 2003 Niversoft 
   http//niversoft.dyndns.org
   info@niversoft.dyndns.org

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//-------------------------------------------------------------------------------------

#pragma once

/*
   Client/Server 'Signature' - used to synchronization, named objects, 
   etc. If you modify the server and the client (adding functions), 
   modifying interfaces, etc, or if you change ANYTHING in this file 
   (settingsipcdefs.h), you MUST change this string and recompile both 
   the server and the client.This string must be unique for each set of 
   client/server interfaces. If a client and a server use the same string 
   but doesn't have the same interface, this could lead to a very bad crash 
   or mutex deadlock. You have been warned. If the string is not the same 
   for a client and the server, the communication won't occurs at all, 
   which is probably better than bad communication. 
*/
#define NAME "Niver's Settings IPC LiteStep Module v1.0.0.1"


// Objects name, constructed with NAME value
#define MUTEXNAME       NAME ## " MUTEX"
#define SHAREDMEMNAME   NAME ## " MEMORY"
#define EVENT_EXEC      NAME ## " EVENTEXEC"
#define EVENT_DONE      NAME ## " EVENTDONE"

// Maximum buffer size
#define BUFSIZE 256
#define TIMEOUT 200

// Set of function that can be called by the client to the server
enum eAction
{
   eaNoAction,          // no action - used by IsServerPresent()
   eaGetLitestepWnd,    // returns Litestep Window handle or NULL
   eaGetRCInt,          // GetRC* returns current litestep 
   eaGetRCBool,         //    settings corresponding to a key
   eaGetRCBoolDef,
   eaGetRCColor,
   eaGetRCString,
   eaGetRCLine
};

/*
   Struct that contains info for ALL the functions
   If you add a function, that uses different types,
   try to add a new member as an union of a unused member.
   If you can't, add a new member.
   Always try to avoid increasing this structure size if you
   can do anything else.
   You MUST NOT pass pointers in this structure.
*/
struct TSharedMemory 
{
   eAction Action;
   char szKeyName[BUFSIZE];      // common for all eaGetRC*
   char szRetValue[BUFSIZE];     // return buffer for eaGetRCString and GetRCLine
   char szDefaultValue[BUFSIZE]; // default value for eaGetRCString and GetRCLine
   long nRetValue;               // return value for eaGetRC*
   union
   {
      long nMaxLength;           // maximum length of the return buffer for eaGetRCString and eaGetRCLine
      long nDefaultValue;        // default value for eaGetRCInt, eaGetRCBool, eaGetRCBoolDef and eaGetRCColor 
      HWND hWnd;                 // return value for exGetLitestepWnd
   };
};
