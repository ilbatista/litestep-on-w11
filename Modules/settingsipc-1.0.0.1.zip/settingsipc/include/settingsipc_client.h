/*
   This is a part of the Niver's Settings IPC LiteStep Module SDK

   Copyright (C) 2003 Niversoft 
   http//niversoft.dyndns.org
   info@niversoft.dyndns.org
  
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
    
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
      
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//-------------------------------------------------------------------------------------

/*
   This header file defines the interfaces to the settings IPC client.
   #include this file in your application, and link with 
   settingsipc_client.lib to use it.

   This module can help non-litestep appilication developpers to integrate
   their application with litestep.
  
   see Readme.txt for more information
*/

#pragma once

#ifndef sipc_h
#define sipc_h

#include "settingsipcdefs.h"

class settingsipc_client  
{
public:
   
   static int      GetRCInt(LPCSTR lpKeyName, int nDefault);
   static BOOL     GetRCString(LPCSTR lpKeyName, LPSTR value, LPCSTR defStr, int maxLen);
   static BOOL     GetRCBool(LPCSTR lpKeyName, BOOL ifFound);
   static BOOL     GetRCBoolDef(LPCSTR lpKeyName, BOOL bDefault);
   static BOOL     GetRCLine( LPCSTR, LPSTR, UINT, LPCSTR );
   static COLORREF GetRCColor(LPCSTR lpKeyName, COLORREF colDef);   
   static HWND     GetLitestepWnd();
   static bool     IsServerPresent();   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
/*------ PRIVATE STUFF, DO NOT MODIFY WITHOUT KNOWLEDGE ---------*/

private:
   settingsipc_client();
   
   static settingsipc_client * GetInstance();
   HANDLE m_hFree, m_hExec, m_hDone, hMap;
   TSharedMemory * pMsg;
   
   long SendMessage(eAction MSG, LPCSTR KEY, long def);
   BOOL SendMessage(eAction MSG, LPCSTR KEY, LPSTR BUF, LPCSTR def, int maxLen);
   HWND SendMessage(eAction Msg);
   
   bool Connect(eAction Msg);
   void Disconnect();
   bool Execute();
};


#endif