QCDAmp is written by blind_in_darkness (GothsSecret)
----------------------------------------------------
Note: I wrote this module some time ago, and I realy can't remember some features.
Please be kind or just try them :)

This module is made for Quinnware QCDPlayer.

------------
Changes 1.1:
------------
!Amp_power/on/off is fixed

-------------
Installation:
-------------

All Bangs are exactly the same as geekamp or dynamp, so you only have to load
*NetLoadModule qcdamp-1.0

turn the amp path into

QCDAmpPath "$AudioPlayer$"
or
QCDAmpPath "c:\path\to\player.exe"

------
Bangs:
------

// open window messages
!Amp_Power						// start and shutdown qcd
!Amp_PowerOn					// start qcd
!Amp_PowerOff					// shutdown qcd
!Amp_About						// about
!Amp_OnTop						// toggle 'always on top'
!Amp_Prefs						// preferences
!Amp_PluginSetup				// plugin browser
!Amp_SkinSetup					// skin browser
!Amp_LoadFile					// open file/stream
!Amp_LoadDir					// open folder
!Amp_ToggleBrowser				// browser window
!Amp_EditID3					// edit info
!Amp_FileInfo					// extended info
!Amp_CDSegments					// cd segments
!Amp_Help						// help
!Amp_Show						// shows QCD

// skin control messages
!Amp_NextSkin					// switch to next skin mode
!Amp_SkinBase					// switch to default QCD skin
!Amp_Skin1						// switch to skin mode 1 to 9
!Amp_Skin2
!Amp_Skin3
!Amp_Skin4
!Amp_Skin5
!Amp_Skin6
!Amp_Skin7
!Amp_Skin8
!Amp_Skin9				
!Amp_ReloadSkin					// refresh current skin

// playback control messages
!Amp_Repeat						// toggle repeat all
!Amp_RepeatTrack				// toggle repeat track
!Amp_Shuffle					// toggle shuffle play
!Amp_Prev						// previous track
!Amp_Next						// next track
!Amp_Stop						// stop
!Amp_Pause						// pause
!Amp_Play						// play
!Amp_Ffwd5s						// seek forward 5 seconds
!Amp_Rewd5s						// seek back 5 seconds

// visual effects control messages
!Amp_VisNext					// switch to next visual plugin
!Amp_VisExtern					// open external visual effects window
!Amp_VisIntern					// set visuals to internal (within skin)
!Amp_VisFullScreen				// launch fullscreen visual effects window
!Amp_VisOff						// turn off visuals

// volume control messages
!Amp_VolumeUp					// Volume goes up 1%
!Amp_VolumeDown					// Volume goes down 1%

// playlist control messages
!Amp_PlaylistSave				// open 'save playlist as' window
!Amp_PlaylistMarkAll			// selects all tracks in playlist
!Amp_PlaylistDelMarked			// delete all selected tracks
!Amp_PlaylistDelAll				// delete all tracks
!Amp_PlaylistClearMarked		// deselect all tracks
!Amp_PlaylistDelUnMarked		// delete all unselected tracks
										

!Amp_CDEject					// replace playlist
!Amp_CDOpenAll					// eject all cdroms
!Amp_CDClose					// close all cdroms
!Amp_Playlist					// play index

!Amp_SortNumber					// sort by playlist number
!Amp_SortTrackName				// sort by trackname
!Amp_SortFile					// sort by filename
!Amp_SortPath					// sort by path / filename
!Amp_SortArtist					// sort by artist / track name
!Amp_SortLength					// sort by track length
!Amp_SortTrackNumber			// sort by track number 
!Amp_SortReversePlaylist		// reverse playlist
!Amp_SortRenumber				// renumber playlist
!Amp_SortRandom					// randomize playlist

// timer control messages
!Amp_TimeElapsed				// set timer to elapsed time for current track
!Amp_TimeRemaining				// set timer to remaining time for current track
!Amp_TimeElapsedAll				// set timer to elapsed time for playlist
!Amp_TimeRemainingAll			// set timer to remaining time for playlist
!Amp_ShowHours					// toggle whether timer shows time in hours

// EQ control messages
!Amp_LoadEQPreset				// loads equalizer preset
!Amp_LoadEQNextPreset			// loads next equalizer preset
!Amp_LoadEQPrevPreset			// loads previous equalizer preset



-----------
To Do List:
-----------

-> Adding the bangs:	!amp_cdromeject <cdrom number>
						!amp_cdloadtracks <cdrom number>
						!amp_cdrequery <cdrom number>