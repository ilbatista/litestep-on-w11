
-------------
Taskbar02.dll
-------------

-------------------------------------
2002.Jan.17
mail:allelimo@jumpy.it
web: http://digilander.iol.it/alphaos
-------------------------------------

------------------------------------------------------------------------------------
What is in the zip:

readme.txt 				- this file
taskbar.alc 			- a codefile for alphaLS .rc editor (beta5)
\bmp\taskbar02.dll 	- taskbar without support for .png (source: ls-b24-sf-20010825)
\png\taskbar02.dll	- taskbar with support for .png (source: ls-b24-sf-20020113)
------------------------------------------------------------------------------------



This is just a little change to the core taskbar.dll I needed for a theme: the original taskbar.dll has a fixed height of 32 pixels, but with taskbar02.dll you can specify the borders dimension, so you can get:

with *borders=1 an height of 20 pixels
with *borders=2 an height of 24 pixels
with *borders=3 an height of 28 pixels
with *borders=4 the original behaviour (default)
etc.

if borders is more than 4 the look of the taskbar is not so good, but you can try...

you can also change the size of the icons and the spacing between each button


the command added to step.rc are:

---------------
Taskbar Borders
---------------

TaskbarBorderLeft 	(default:4)
TaskbarBorderTop  	(default:4)
TaskbarBorderRight 	(default:4)
TaskbarBorderBottom 	(default:4)

---------------
Taskbar Buttons
---------------
	
TaskbarButtonBorderLeft  	(default:4)
TaskbarButtonBorderTop 	 	(default:4)
TaskbarButtonBorderRight 	(default:4)
TaskbarButtonBorderBottom	(default:4)


TaskbarSpacing  		(default:3)  - Set the spacing between each button
TaskbarIconSize	 	(default:16)
TaskbarIconSpacing 	(default:3) - ?



-------------------------------------------------------
-------------------------------------------------------
The source is not included, because it is so minimal.

The only changes are:

-------------------------------------------------------
in taskbar.cpp: removed "const" in the following lines:
-------------------------------------------------------

...
#include "../lsapi/macros.h"
#include "taskbar.h"

// from here to ��� changed
int borderLeft = 4;
int borderTop = 4;
int borderRight = 4;
int borderBottom = 4;

int buttonBorderLeft = 4;
int buttonBorderTop = 4;
int buttonBorderRight = 4;
int buttonBorderBottom = 4;
int iconSpacing = 3;
int spacing = 3;
int iconSize = 16;
//���
...

------------------------------
and added the following lines:
------------------------------

...
void Taskbar::ReadConfig()
{

	TCHAR buffer[MAX_PATH];
	TCHAR bufferLeft[MAX_PATH];
	TCHAR bufferRight[MAX_PATH];

	//from here to ��� added
	borderLeft = GetRCInt( TEXT("TaskborderLeft"), 4);
	borderTop = GetRCInt( TEXT("TaskborderTop"), 4);
	borderRight = GetRCInt( TEXT("TaskborderRight"), 4);
	borderBottom = GetRCInt( TEXT("TaskborderBottom"), 4);
	
	buttonBorderLeft = GetRCInt( TEXT("TaskbuttonBorderLeft"), 4);
	buttonBorderTop = GetRCInt( TEXT("TaskbuttonBorderTop"), 4);
	buttonBorderRight = GetRCInt( TEXT("TaskbuttonBorderRight"), 4);
	buttonBorderBottom = GetRCInt( TEXT("TaskbuttonBorderBottom"), 4);
	spacing = GetRCInt( TEXT("Taskspacing"), 3);
	iconSize = GetRCInt( TEXT("TaskiconSize"), 16);
	iconSpacing = GetRCInt( TEXT("TaskiconSpacing"), 3);
	//���

	// autoHide = (GetRCBool("TaskbarAutoHide") || GetRCBool("AutoHideTaskbar")) ? true : false;
	keepDesktopArea = GetRCBool("TaskbarKeepDesktopArea", TRUE) ? true : false;
	...




