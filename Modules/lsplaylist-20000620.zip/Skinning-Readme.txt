How to Skin
===========
The borders and background images are stored in the [Images] section
of the skin.ini.  Here is an example:

[Images]
TopBorder=.\skins\default\border-top.bmp
BottomBorder=.\skins\default\border-bottom.bmp
LeftBorder=.\skins\default\border-left.bmp
RightBorder=.\skins\default\border-right.bmp
MainBackground=.\skins\default\bg-main.bmp
ListBackground=.\skins\default\bg-list.bmp

You use this section to control the main list.
[List]
FontColor=0x00FFFFFF
FontSelColor=0x00FF0000
FontFace=Courier
FontHeight=10
X=57
Y=62
W=297
H=212

Magic Pink(tm) Support:
* Playlist Window
* Progress Bars
* Buttons