/******************************************************************************
You are reading the source for binbox.dll

  Open source visual litestep module to handle the windows native
  recycle bin folder.

  Created and coded by: Mike Edward Moras (e-sushi@gmx.net)
  Tested by: Allesandro Limonta (allelimo@jumpy.it)

  url: http://e-sushi.shellscape.org


	This module was created, using the codebase of pika's open source
	sourcecode to his kclock module. He said it would be nice if he's
	credited... I thought it wouldn't only be fair to do so, but it was
	time to tell you (the one reading this) that without his sourceode,
	I would probably still not be able to code up a visual module fro
	scratch. (guess I'm either to bussy coding other stuff, or - more
	probably - I'm just too lazy. It's more easy if someone else allready
	did most of the job <g>). Thanks pika!!! (http://pika.shellscape.org)			
******************************************************************************/
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

COLORREF StrToCR(char* strColour, bool rgb);
void GetBinString(char *copyString);
void StrToRect(char* tmpString, RECT* tmpRect, int w, int h);

#endif /* FUNCTIONS_H */