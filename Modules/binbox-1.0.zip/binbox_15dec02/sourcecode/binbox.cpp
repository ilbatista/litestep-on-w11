/******************************************************************************
You are reading the source for binbox.dll

  Open source visual litestep module to handle the windows native
  recycle bin folder.

  Created and coded by: Mike Edward Moras (e-sushi@gmx.net)
  Tested by: Allesandro Limonta (allelimo@jumpy.it)

  url: http://e-sushi.shellscape.org


	This module was created, using the codebase of pika's open source
	sourcecode to his kclock module. He said it would be nice if he's
	credited... I thought it wouldn't only be fair to do so, but it was
	time to tell you (the one reading this) that without his sourceode,
	I would probably still not be able to code up a visual module fro
	scratch. (guess I'm either to bussy coding other stuff, or - more
	probably - I'm just too lazy. It's more easy if someone else allready
	did most of the job <g>). Thanks pika!!! (http://pika.shellscape.org)			
******************************************************************************/
#include "../current/lsapi/lsapi.h"
#include <windows.h>
#include "main.h"
#include "Functions.h"
#include "binbox.h"
#include "bangs.h"
#include "AggressiveOptimize.h"

char versionInfo[] = "$Id: binbox.dll: v1.0 (e-sushi@gmx.net)";

LRESULT CALLBACK kProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	int code;
	
	switch ( msg ) {
	case WM_CREATE:
		binBox->onCreate(hWnd, wParam, lParam);
		break;
		
	case WM_PAINT:
		binBox->onPaint(hWnd, wParam, lParam);
		break;
		
	case WM_TIMER:
		binBox->onTimer(hWnd, wParam, lParam);
		break;
		
	case WM_LBUTTONDOWN:
		binBox->onLeftBtnDown(hWnd, wParam, lParam);
		break;
		
	case WM_LBUTTONUP:
		binBox->onLeftBtnUp(hWnd, wParam, lParam);
		break;
		
	case WM_RBUTTONDOWN:
		binBox->onRightBtnDown(hWnd, wParam, lParam);
		break;
		
	case WM_RBUTTONUP:
		binBox->onRightBtnUp(hWnd, wParam, lParam);
		break;
		
	case WM_MBUTTONDOWN:
		binBox->onMiddleBtnDown(hWnd, wParam, lParam);
		break;
		
	case WM_MBUTTONUP:
		binBox->onMiddleBtnUp(hWnd, wParam, lParam);
		break;
		
	case WM_MOUSEMOVE:
		binBox->onMouseMove(hWnd, wParam, lParam);
		break;
		
	case WM_DESTROY:
		code = binBox->onDestroy(hWnd, wParam, lParam);
		
		return code;
		break;
		
	case LM_REFRESH:
		binBox->onRefresh(hWnd, wParam, lParam);
		break;
		
	case LM_GETREVID:
		binBox->onGetRevId(hWnd, wParam, lParam);
		return strlen((char*)lParam);
		break;
		
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
		break;
	}
	
	return 0;
}

binbox::binbox(HINSTANCE dllInst2, int &code) {
	WNDCLASSEX kClass;
	HWND desktopWnd;
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};
	char kClassName[] = "binbox";
	char errorCode[256];
	
	dllInst = dllInst2;
	desktopWnd = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktopWnd)
		desktopWnd = GetDesktopWindow();
	
	Config();
	
	kClass.cbSize		 = sizeof(WNDCLASSEX);
	kClass.hInstance	 = dllInst;
	kClass.lpfnWndProc	 = kProc;
	kClass.lpszClassName = kClassName;
	kClass.lpszMenuName  = NULL;
	kClass.style		 = CS_HREDRAW | CS_VREDRAW;
	kClass.cbClsExtra	 = 0;
	kClass.cbWndExtra	 = 0;
	kClass.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	kClass.hIcon		 = NULL;
	kClass.hIconSm		 = NULL;
	kClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	
	if ( !RegisterClassEx(&kClass) )
		MessageBox(NULL, "Error registering class.", "Error: Constructor", 32);
	
	
	kWnd = CreateWindowEx( ( onTop ? WS_EX_TOPMOST : NULL) | WS_EX_TOOLWINDOW,
		kClassName, kClassName, (onBottom && !onTop ? WS_CHILD : NULL) | WS_POPUP,
		x, y, w, h, (onBottom && !onTop ? desktopWnd : GetLitestepWnd()), NULL, dllInst, NULL);
	
	
	if ( !kWnd ) {
		itoa(GetLastError(), errorCode, 16);
		MessageBox(NULL, errorCode, "Error: Constructor", 32);
	}
	
	SetWindowLong(kWnd, GWL_USERDATA, magicDWord);
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)kWnd, (LPARAM)msgs);
	RegisterBangs();
	
	if ( backBmp )
		SetWindowRgn(kWnd, kRgn, true);
	
	if ( !waitForBox )
		ShowWindow(kWnd, (hidden ? SW_HIDE : SW_SHOWNOACTIVATE));
	
	if ( !SetTimer(kWnd, TIMER_UPDATE, interval, NULL) )
		MessageBox(NULL, "Unable to set timer.", "Error", 32);
}


binbox::~binbox() {
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};
	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)kWnd, (LPARAM)msgs);
	
	KillTimer(kWnd, TIMER_UPDATE);
	
	deleteObjects();
	
	RemoveBangCommand("!binboxHide");
	RemoveBangCommand("!binboxLeftClick");
	RemoveBangCommand("!binboxMiddleClick");
	RemoveBangCommand("!binboxMove");
	RemoveBangCommand("!binboxRightClick");
	RemoveBangCommand("!binboxShow");
	RemoveBangCommand("!binboxToggle");
	RemoveBangCommand("!binboxForceUpdate");
	RemoveBangCommand("!binboxBoxHook");
	RemoveBangCommand("!binboxClean");
	
	
	if ( IsWindow(kWnd) )
		DestroyWindow(kWnd);
	
	if ( !UnregisterClass("binbox", dllInst) )
		MessageBox(NULL, "Could not unregister the class.", "Error: Destructor", 32);
}


void binbox::Config() {
	char  tmpString[MAX_PATH];
	bool tmpBool;
	int tmpInt;
	LOGFONT lFont;
	
	fontFace = NULL;
	leftClick = NULL;
	rightClick = NULL;
	middleClick = NULL;
	backFile = NULL;
	
	GetRCString("binboxX", tmpString, "0", sizeof(tmpString)/sizeof(char));
	if ( strchr(strlwr(tmpString), 'c') )
		x = (GetSystemMetrics(SM_CXSCREEN) / 2) + atoi(tmpString);
	else {
		x = atoi(tmpString);
		if ( x < 0 )
			x += GetSystemMetrics(SM_CXSCREEN);
	}
	
	GetRCString("binboxY", tmpString, "0", sizeof(tmpString)/sizeof(char));
	if ( strchr(strlwr(tmpString), 'c') )
		y = (GetSystemMetrics(SM_CYSCREEN) / 2) + atoi(tmpString);
	else {
		y = atoi(tmpString);
		if ( y < 0 )
			y += GetSystemMetrics(SM_CYSCREEN);
	}
	
	w = GetRCInt("binboxWidth", 100);
	h = GetRCInt("binboxHeight", 25);
	
	interval	  = GetRCInt("binboxInterval", 3000);
	tmpInt		  = GetRCInt("binboxBorder", 1);
	border.left   = GetRCInt("binboxBorderLeft", tmpInt);
	border.top	  = GetRCInt("binboxBorderTop", tmpInt);
	border.right  = GetRCInt("binboxBorderRight", tmpInt);
	border.bottom = GetRCInt("binboxBorderBottom", tmpInt);
	
	onTop	   = GetRCBoolDef("binboxOnTop", false) == 1;
	onBottom   = GetRCBoolDef("binboxOnBottom", false) == 1;
	hidden	   = GetRCBoolDef("binboxHidden", false) == 1;
	textBold   = GetRCBoolDef("binboxBold", false) == 1;
	textItalic = GetRCBoolDef("binboxItalic", false) == 1;
	textShadow = GetRCBoolDef("binboxTextShadow", false) == 1;
	waitForBox = GetRCBoolDef("binboxInBox", false) ==1;
	inBox	   = false;
	mouseOver  = false;
	
	
	bgColor 		= GetRCColor("binboxBg", GetSysColor(COLOR_BTNFACE));
	hilightColor	= GetRCColor("binboxHilight", GetSysColor(COLOR_BTNHILIGHT));
	shadowColor 	= GetRCColor("binboxShadow", GetSysColor(COLOR_BTNSHADOW));
	textColor		= GetRCColor("binboxText", GetSysColor(COLOR_BTNTEXT));
	textShadowColor = GetRCColor("binboxTextShadowClr", GetSysColor(COLOR_BTNSHADOW));
	textShadowOff	= GetRCInt("binboxTextShadowOff", 1);
	
	GetRCString("binboxTextJustify", tmpString, "center", sizeof(tmpString)/sizeof(char));
	strlwr(tmpString);
	if ( !strcmp(tmpString, "left") )
		textJustify = DT_VCENTER | DT_LEFT;
	else if ( !strcmp(tmpString, "right") )
		textJustify = DT_VCENTER | DT_RIGHT;
	else
		textJustify = DT_VCENTER | DT_CENTER;
	
	memset(&lFont, 0, sizeof(LOGFONT));
	
	fontHeight = GetRCInt("binboxFontSize", 12);
	GetRCString("binboxFont", tmpString, "Arial", sizeof(tmpString)/sizeof(char));
	fontFace = new char[32];
	strncpy(fontFace, tmpString, 32);
	strncpy(lFont.lfFaceName, tmpString, 32);
	
	lFont.lfItalic		 = textItalic;
	lFont.lfWeight		 = (textBold ? FW_BOLD : FW_NORMAL);
	lFont.lfHeight		 = fontHeight;
	hFont = CreateFontIndirect(&lFont);
	
	tmpBool = GetRCBoolDef("binboxBack", false) == 1;
	if ( tmpBool ) {
		GetRCString("binboxBack", tmpString, ".none", sizeof(tmpString)/sizeof(char));
		if ( strcmp(tmpString, ".none") ) {
			backFile = new char[strlen(tmpString)+1];
			strcpy(backFile, tmpString);
			backBmp = LoadLSImage(backFile, NULL);
			if ( backBmp ) {
				GetLSBitmapSize(backBmp, &bw, &bh);
				w = bw;
				h = bh;
				kRgn = BitmapToRegion(backBmp, RGB(255, 0, 255), 0x101010, 0, 0);
			}
		}
	}
	else {
		backBmp = NULL;
		kRgn = CreateRectRgn(0, 0, w, h);
	}
	
	display.left   = 0;
	display.top    = 0;
	display.right  = w;
	display.bottom = h;
	
	GetRCLine("binboxDispRect", tmpString, sizeof(tmpString)/sizeof(char), "0 0");
	StrToRect(tmpString, &(this->display), this->w, this->h);
	
	client.left   = border.left;
	client.top	  = border.top;
	client.right  = w - border.right;
	client.bottom = h - border.bottom;
	
	textJustify = textJustify | DT_SINGLELINE;
	
	GetRCString("binboxLeftClick", tmpString, "!none", sizeof(tmpString)/sizeof(char));
	leftClick = new char[strlen(tmpString)+1];
	strcpy(leftClick, tmpString);
	
	GetRCString("binboxRightClick", tmpString, "!popup", sizeof(tmpString)/sizeof(char));
	rightClick = new char[strlen(tmpString)+1];
	strcpy(rightClick, tmpString);
	
	GetRCString("binboxMiddleClick", tmpString, "!none", sizeof(tmpString)/sizeof(char));
	middleClick = new char[strlen(tmpString)+1];
	strcpy(middleClick, tmpString);
	
	GetRCString("binboxMouseEnter", tmpString, "!none", sizeof(tmpString)/sizeof(char));
	mouseEnter = new char[strlen(tmpString)+1];
	strcpy(mouseEnter, tmpString);
	
	GetRCString("binboxMouseExit", tmpString, "!none", sizeof(tmpString)/sizeof(char));
	mouseExit = new char[strlen(tmpString)+1];
	strcpy(mouseExit, tmpString);
}

void binbox::deleteObjects() {
	
	delete fontFace;
	delete leftClick;
	delete rightClick;
	delete middleClick;
	delete mouseEnter;
	delete mouseExit;
	delete backFile;
	
	DeleteObject(backBmp);
	DeleteObject(hFont);
	DeleteObject(kRgn);
}


void binbox::RegisterBangs() {
	AddBangCommand("!binboxHide", bangHide);
	AddBangCommand("!binboxLeftClick", bangLeftClick);
	AddBangCommand("!binboxMiddleClick", bangMiddleClick);
	AddBangCommand("!binboxMove", bangMove);
	AddBangCommand("!binboxRightClick", bangRightClick);
	AddBangCommand("!binboxShow", bangShow);
	AddBangCommand("!binboxToggle", bangToggle);
	AddBangCommand("!binboxForceUpdate", bangForceUpdate);
	AddBangCommand("!binboxBoxHook", bangBoxHook);
	AddBangCommand("!binboxClean", bangClean);
	
}


void binbox::onCreate(HWND hWnd, WPARAM wParam, LPARAM lParam) {
}


int binbox::onDestroy(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	if ( inBox ) {
		SetWindowLong(kWnd, GWL_STYLE, (GetWindowLong(kWnd, GWL_STYLE) &~ WS_CHILD)|WS_POPUP);
		SetParent(kWnd, 0);
		ShowWindow(kWnd, SW_HIDE);
		inBox = false;
		return 0;
	}
	else
		return 1;
}


void binbox::onPaint(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	int i;
	HDC paintDC, bmpDC;
	PAINTSTRUCT ps;
	HBRUSH backBrush;
	HPEN oldPen, hiPen, lowPen;
	HFONT oldFont;
	RECT clientRect, textRect, shadowRect;
	char timeString[128];
	HBITMAP oldBmp;
	
	backBrush = CreateSolidBrush(bgColor);
	hiPen = CreatePen(PS_SOLID, 1, hilightColor);
	lowPen = CreatePen(PS_SOLID, 1, shadowColor);
	
	GetClientRect(hWnd, &clientRect);
	paintDC = BeginPaint(hWnd, &ps);
	
	if ( !backBmp ) {		 
		FillRect(paintDC, &clientRect, backBrush);
		oldPen = (HPEN)SelectObject(paintDC, hiPen);
		for ( i=0; i<binbox::border.left; i++ ) {
			MoveToEx(paintDC, i, 0, NULL);
			LineTo(paintDC, i, clientRect.bottom - i);
		}
		
		for ( i=0; i<border.top; i++ ) {
			MoveToEx(paintDC, 0, i, NULL);
			LineTo(paintDC, clientRect.right, i);
		}
		
		SelectObject(paintDC, lowPen);
		for ( i=0; i<border.right; i++ ) {
			MoveToEx(paintDC, clientRect.right-1-i, i, NULL);
			LineTo(paintDC, clientRect.right-1-i, clientRect.bottom);
		}
		
		for ( i=0; i<border.bottom; i++ ) {
			MoveToEx(paintDC, i, clientRect.bottom-1-i, NULL);
			LineTo(paintDC, clientRect.right, clientRect.bottom-1-i);
		}
		
		SelectObject(paintDC, oldPen);
	}
	
	else {
		bmpDC = CreateCompatibleDC(paintDC);
		oldBmp = (HBITMAP)SelectObject(bmpDC, backBmp);
		
		TransparentBltLS(paintDC, 0, 0, w, h, bmpDC, 0, 0, RGB(255, 0, 255));
		SelectObject(bmpDC, oldBmp);
		DeleteDC(bmpDC);
	}
	
	oldFont = (HFONT)SelectObject(paintDC, hFont);
	
	SetBkMode(paintDC, TRANSPARENT);
	GetBinString(timeString);
	timeString[strlen(timeString)] = '\0';
	
	textRect = display;
	if ( textShadow ) {
		shadowRect = display;
		shadowRect.left += textShadowOff;
		shadowRect.top += textShadowOff;
		
		textRect.right += -(textShadowOff);
		textRect.bottom += -(textShadowOff);
		
		SetTextColor(paintDC, textShadowColor);
		DrawTextEx(paintDC, timeString, strlen(timeString), &shadowRect, textJustify, NULL);
	}
	
	SetTextColor(paintDC, textColor);
	DrawTextEx(paintDC, timeString, strlen(timeString), &textRect, textJustify, NULL);
	
	SelectObject(paintDC, oldFont);
	
	DeleteObject(hiPen);
	DeleteObject(lowPen);
	DeleteObject(backBrush);
	
	EndPaint(hWnd, &ps);
}


void binbox::onTimer(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	InvalidateRect(hWnd, NULL, false);
}


void binbox::onRefresh(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	RECT windowRect;
	deleteObjects();
	Config();
	
	GetWindowRect(kWnd, &windowRect);
	x = windowRect.left;
	y = windowRect.top;
	
	
	if ( ( GetWindowLong(kWnd, GWL_EXSTYLE) & WS_EX_TOPMOST )  ) {
		if ( !onTop )
			SetWindowLong(kWnd, GWL_EXSTYLE, WS_EX_TOOLWINDOW);
	}
	else {
		if ( onTop ) {
			SetWindowLong(kWnd, GWL_EXSTYLE, GetWindowLong(kWnd, GWL_EXSTYLE) | WS_EX_TOPMOST);
			SetWindowLong(kWnd, GWL_STYLE, (GetWindowLong(kWnd, GWL_STYLE) & ~WS_CHILD) | WS_POPUP);
		}
	}
	
	
	if ( ( GetWindowLong(kWnd, GWL_STYLE) & WS_CHILD ) ) {
		if ( !onBottom )
			SetWindowLong(kWnd, GWL_STYLE, (GetWindowLong(kWnd, GWL_STYLE) & ~WS_CHILD) | WS_POPUP);
	}
	else {
		if ( onBottom ) {
			SetWindowLong(kWnd, GWL_STYLE, WS_CHILD | WS_POPUP);
			SetParent(kWnd, desktopWnd);
		}
	}
	
	MoveWindow(kWnd, x, y, w, h, true);
	SetWindowPos(kWnd, (onTop ? HWND_TOPMOST : HWND_NOTOPMOST), 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
	SetWindowRgn(kWnd, kRgn, true);
	
	InvalidateRect(kWnd, NULL, true);
}


void binbox::onGetRevId(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	char* buf;
	buf = (char*)lParam;
	
	switch ( wParam ) {
		
	case 0:
		sprintf(buf, &versionInfo[5]);
		buf[strlen(buf)] = '\0';
		break;
		
	case 1:
		sprintf(buf, versionInfo);
		buf[strlen(buf)] = '\0';
		break;
		
	default:
		strcpy(buf, "");
		break;
	}
	
}


void binbox::onLeftBtnDown(HWND hWnd, WPARAM wParam, LPARAM lParam) {
}


void binbox::onLeftBtnUp(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	if ( leftClick )
		LSExecute(kWnd, leftClick, 0);
}


void binbox::onRightBtnDown(HWND hWnd, WPARAM wParam, LPARAM lParam) {
}


void binbox::onRightBtnUp(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	if ( rightClick )
		LSExecute(kWnd, rightClick, 0);
}


void binbox::onMiddleBtnDown(HWND hWnd, WPARAM wParam, LPARAM lParam) {
}


void binbox::onMiddleBtnUp(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	if ( middleClick )
		LSExecute(kWnd, middleClick, 0);
}


void binbox::onMouseMove(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	POINT mousePosNew;
	RECT windowRect;
	
	GetCursorPos(&mousePosNew);
	
	if ( mouseOver ) {
		GetWindowRect(kWnd, &windowRect);
		
		windowRect.left += border.left;
		windowRect.top += border.top;
		windowRect.right -= border.right;
		windowRect.bottom -= border.bottom;
		
		if ( !PtInRect(&windowRect, mousePosNew) ) {
			ReleaseCapture();
			LSExecute(kWnd, mouseExit, 0);
			mouseOver = false;
		}
	}
	
	else if ( !mouseOver ) {
		GetWindowRect(kWnd, &windowRect);
		
		windowRect.left += border.left;
		windowRect.top += border.top;
		windowRect.right -= border.right;
		windowRect.bottom -= border.bottom;
		
		if ( PtInRect(&windowRect, mousePosNew) ) {
			mouseOver = true;
			SetCapture(kWnd);
			LSExecute(kWnd, mouseEnter, 0);
		}
	}
}

void binbox::binboxClean(HWND caller, LPCSTR args) {
	
	SHEmptyRecycleBin(caller,NULL, /*SHERB_NOCONFIRMATION*/NULL);
}

void binbox::binboxBoxHook(HWND caller, LPCSTR args) {
	if ( waitForBox ) {
		inBox = true;
		char *token, boxFile[MAX_PATH], handle[32];
		HWND boxWnd;
		int msgs[] = {LM_GETREVID, LM_REFRESH, 0};
		
		token = strtok((char*)args, " ");
		while ( token ) {
			strcpy(boxFile, handle);
			strcpy(handle, token);
			token = strtok(NULL, " ");
		}
		
		boxWnd = (HWND)atoi(handle);
		
		if ( IsWindow(boxWnd) ) {
			SetWindowLong(kWnd, GWL_STYLE, (GetWindowLong(kWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
			SetParent(kWnd, boxWnd);
			
			ShowWindow(kWnd, SW_SHOWNOACTIVATE);
			
			InvalidateRect(kWnd, NULL, false);
		}
		
		else {
			MessageBox(NULL, "boxWnd invalid", "binBox2 Error", 32);
		}
		
	}
}


void binbox::binboxHide(HWND caller, LPCSTR args) {
	if ( IsWindowVisible(kWnd) ) {
		ShowWindow(kWnd, SW_HIDE);
		hidden = true;
	}
}

void binbox::binboxLeftClick(HWND caller, LPCSTR args) {
	if ( leftClick )
		LSExecute(NULL, leftClick, 0);
}

void binbox::binboxMiddleClick(HWND caller, LPCSTR args) {
	if ( middleClick )
		LSExecute(NULL, middleClick, 0);
}

void binbox::binboxMove(HWND caller, LPCSTR args) {
	char *token, tmpString[64], cX[8], cY[8], cW[8], cH[8];
	
	token = strtok((char*)args, " ");
	if ( token ) {
		strlwr(token);
		
		if ( strcmp(token, "x") ) {
			
			if ( strchr(token, '+') ) {
				if ( strstr(token, "+-") ) {
					x += atoi(token + sizeof(char));
				}
				else
					x += atoi(token);
			}
			else {
				x = atoi(token);
				if ( x < 0 )
					x += GetSystemMetrics(SM_CXSCREEN);
			}
		}
	}
	
	token = strtok(NULL, " ");
	if ( token ) {
		strlwr(token);
		
		if ( strcmp(token, "y") ) {
			
			if ( strchr(token, '+') ) {
				if ( strstr(token, "+-") )
					y += atoi(token + sizeof(char));
				else
					y += atoi(token);
			}
			else {
				y = atoi(token);
				if ( y < 0 )
					y += GetSystemMetrics(SM_CYSCREEN);
			}
		}
	}
	
	
	if ( !backBmp ) {
		
		token = strtok(NULL, " ");
		if ( token ) {
			strlwr(token);
			
			if ( strcmp(token, "w") ) {
				
				if ( strchr(token, '+') ) {
					if ( strstr(token, "+-") )
						w += atoi(token + sizeof(char));
					else
						w += atoi(token);
				}
				else
					w = atoi(token);
			}
		}
		
		token = strtok(NULL, " ");
		if ( token ) {
			strlwr(token);
			
			if ( strcmp(token, "h") ) {
				
				if ( strchr(token, '+') ) {
					if ( strstr(token, "+-") )
						h += atoi(token + sizeof(char));
					else
						h += atoi(token);
				}
				else
					h = atoi(token);
			}
		}
		
		GetRCLine("binboxDispRect", tmpString, sizeof(tmpString)/sizeof(char), "0 0 0 0");
		StrToRect(tmpString, &(this->display), this->w, this->h);
		
	}
	
	itoa(x, cX, 10);
	LSSetVariable("binboxX", cX);
	
	itoa(y, cY, 10);
	LSSetVariable("binboxY", cY);
	
	itoa(w, cW, 10);
	LSSetVariable("binboxWidth", cW);
	
	itoa(h, cH, 10);
	LSSetVariable("binboxHeight", cH);
	
	if ( IsWindow(kWnd) )
		MoveWindow(kWnd, x, y, w, h, true);
	else
		MessageBox(NULL, "kWnd is an invalid window handle.", "Error: binBox2", 32);
}

void binbox::binboxRightClick(HWND caller, LPCSTR args) {
	if ( rightClick )
		LSExecute(NULL, rightClick, 0);
}


void binbox::binboxShow(HWND caller, LPCSTR args) {
	if ( !IsWindowVisible(kWnd) ) {
		ShowWindow(kWnd, SW_SHOWNOACTIVATE);
		hidden = false;
	}
}


void binbox::binboxToggle(HWND caller, LPCSTR args) {
	if ( IsWindowVisible(kWnd) )
		binboxHide(caller, args);
	else
		binboxShow(caller, args);
}


void binbox::binboxForceUpdate(HWND caller, LPCSTR args) {
	if ( !strcmp(strlwr((char*)args), "full") )
		InvalidateRect(kWnd, NULL, true);
	else
		InvalidateRect(kWnd, NULL, false);
}




void binbox::SetBack(LPCSTR args) {
	char tmpString[MAX_PATH];
	int bw, bh;
	
	delete backFile;
	DeleteObject(backBmp);
	DeleteObject(kRgn);
	
	backFile = new char[strlen(args)+1];
	strcpy(backFile, args);
	
	backBmp = LoadLSImage(backFile, NULL);
	
	if ( backBmp ) {
		kRgn = BitmapToRegion(backBmp, RGB(255, 0, 255), 0x101010, 0, 0);
		SetWindowRgn(kWnd, kRgn, true);
		GetLSBitmapSize(backBmp, &bw, &bh);
		w = bw;
		h = bh;
		MoveWindow(kWnd, x, y, w, h, false);
		
		
		GetRCLine("binboxDispRect", tmpString, sizeof(tmpString)/sizeof(char), "0 0 0 0");
		StrToRect(tmpString, &(this->display), this->w, this->h);
		
	}
	
	else {
		backFile = NULL;
		backBmp = NULL;
		kRgn = NULL;
		SetWindowRgn(kWnd, NULL, true);
	}
	
	InvalidateRect(kWnd, NULL, true);
}


void binbox::SetBgColor(LPCSTR args) {
	char *color;
	
	color = new char[strlen(args)+1];
	strcpy(color, args);
	
	if ( strlen(color) == 6 ) {
		bgColor = StrToCR(color, true);
		InvalidateRect(kWnd, NULL, true);
	}
}





void binbox::SetColor(LPCSTR args) {
	char *color;
	
	color = new char[strlen(args)+1];
	strcpy(color, args);
	
	if ( strlen(color) == 6 ) {
		textColor = StrToCR(color, true);
		InvalidateRect(kWnd, NULL, true);
	}
}




void binbox::SetHilight(LPCSTR argsC) {
	char *args;
	
	args = new char[strlen(argsC)+1];
	strcpy(args, argsC);
	
	if ( strlen(args) == 6 ) {
		hilightColor = StrToCR(args, true);
		InvalidateRect(kWnd, NULL, true);
	}
}


void binbox::SetLeftClick(LPCSTR args) {
	delete leftClick;
	leftClick = new char[strlen(args)+1];
	strcpy(leftClick, args);
}


void binbox::SetMiddleClick(LPCSTR args) {
	delete middleClick;
	middleClick = new char[strlen(args)+1];
	strcpy(middleClick, args);
}


void binbox::SetRightClick(LPCSTR args) {
	delete rightClick;
	rightClick = new char[strlen(args)+1];
	strcpy(rightClick, args);
}


void binbox::SetShadow(LPCSTR argsC) {
	char *args;
	
	args = new char[strlen(argsC)+1];
	strcpy(args, argsC);
	
	if ( strlen(args) == 6 ) {
		shadowColor = StrToCR(args, true);
		InvalidateRect(kWnd, NULL, true);
	}
}


void binbox::SetTextShadow(LPCSTR argsC) {
	char *args;
	
	args = new char[strlen(argsC)+1];
	strcpy(args, argsC);
	
	if ( !strcmp(strlwr(args), "true") )
		textShadow = true;
	else
		textShadow = false;
	
	InvalidateRect(kWnd, NULL, true);
}


void binbox::SetTextShadowClr(LPCSTR argsC) {
	char *args;
	
	args = new char[strlen(argsC)+1];
	strcpy(args, argsC);
	
	if ( strlen(args) == 6 ) {
		textShadowColor = StrToCR(args, true);
		InvalidateRect(kWnd, NULL, true);
	}
}


void binbox::SetTextShadowOff(LPCSTR args) {
	textShadowOff = atoi(args);
	InvalidateRect(kWnd, NULL, true);
}


void binbox::SetOnTop(LPCSTR args) {
	if ( !strcmp(strlwr((char*)args), "true") ) {
		onBottom = false;
		onTop = true;
		
		SetWindowLong(kWnd, GWL_EXSTYLE, GetWindowLong(kWnd, GWL_EXSTYLE) | WS_EX_TOPMOST);
		SetWindowLong(kWnd, GWL_STYLE, (GetWindowLong(kWnd, GWL_STYLE) & ~WS_CHILD) | WS_POPUP);
	}
	else {
		onTop = false;
		SetWindowLong(kWnd, GWL_EXSTYLE, WS_EX_TOOLWINDOW);
	}
	
	SetWindowPos(kWnd, (onTop ? HWND_TOPMOST : HWND_NOTOPMOST), 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
}


void binbox::SetOnBottom(LPCSTR args) {
	if ( !strcmp(strlwr((char*)args), "true") ) {
		onTop = false;
		onBottom = true;
		
		SetWindowLong(kWnd, GWL_EXSTYLE, WS_EX_TOOLWINDOW);
		SetWindowLong(kWnd, GWL_STYLE, WS_CHILD | WS_POPUP);
	}
	else {
		onBottom = false;
		SetWindowLong(kWnd, GWL_STYLE, (GetWindowLong(kWnd, GWL_STYLE) & ~WS_CHILD) | WS_POPUP);
	}
	
	SetWindowPos(kWnd, (onBottom ? HWND_NOTOPMOST : HWND_NOTOPMOST), 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
}



void binbox::SetMouseEnter(LPCSTR args) {
	delete mouseEnter;
	mouseEnter = new char[strlen(args)+1];
	strcpy(mouseEnter, args);
}


void binbox::SetMouseExit(LPCSTR args) {
	delete mouseExit;
	mouseExit = new char[strlen(args)+1];
	strcpy(mouseExit, args);
}




void binbox::SetDispRect(LPCSTR args) {
	StrToRect((char*)args, &(this->display), this->w, this->h);
	InvalidateRect(kWnd, NULL, false);
}