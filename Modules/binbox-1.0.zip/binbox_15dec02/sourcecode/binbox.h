/******************************************************************************
You are reading the source for binbox.dll

  Open source visual litestep module to handle the windows native
  recycle bin folder.

  Created and coded by: Mike Edward Moras (e-sushi@gmx.net)
  Tested by: Allesandro Limonta (allelimo@jumpy.it)

  url: http://e-sushi.shellscape.org


	This module was created, using the codebase of pika's open source
	sourcecode to his kclock module. He said it would be nice if he's
	credited... I thought it wouldn't only be fair to do so, but it was
	time to tell you (the one reading this) that without his sourceode,
	I would probably still not be able to code up a visual module fro
	scratch. (guess I'm either to bussy coding other stuff, or - more
	probably - I'm just too lazy. It's more easy if someone else allready
	did most of the job <g>). Thanks pika!!! (http://pika.shellscape.org)			
******************************************************************************/
#ifndef BINBOX_H
#define BINBOX_H

#define TIMER_UPDATE 1

typedef void (*FUNCPTR)(LPCSTR);

typedef struct SetFunctionsTAG {
	char* setting;
	FUNCPTR function;
} SetFunctions;

LRESULT CALLBACK kProc(HWND, UINT, WPARAM, LPARAM);

class binbox {
public:
	binbox(HINSTANCE, int&);
	~binbox();
	void Config();
	void RegisterBangs();
	
	void onCreate(HWND, WPARAM, LPARAM);
	int  onDestroy(HWND, WPARAM, LPARAM);
	void onPaint(HWND, WPARAM, LPARAM);
	void onTimer(HWND, WPARAM, LPARAM);
	void onLeftBtnDown(HWND, WPARAM, LPARAM);
	void onLeftBtnUp(HWND, WPARAM, LPARAM);
	void onRightBtnDown(HWND, WPARAM, LPARAM);
	void onRightBtnUp(HWND, WPARAM, LPARAM);
	void onMiddleBtnDown(HWND, WPARAM, LPARAM);
	void onMiddleBtnUp(HWND, WPARAM, LPARAM);
	void onMouseMove(HWND, WPARAM, LPARAM);
	void onGetRevId(HWND, WPARAM, LPARAM);
	void onRefresh(HWND, WPARAM, LPARAM);
	
	void binboxClean(HWND, LPCSTR);
	void binboxBoxHook(HWND, LPCSTR);
	void binboxHide(HWND, LPCSTR);
	void binboxLeftClick(HWND, LPCSTR);
	void binboxMiddleClick(HWND, LPCSTR);
	void binboxMove(HWND, LPCSTR);
	void binboxRightClick(HWND, LPCSTR);
	void binboxShow(HWND, LPCSTR);
	void binboxToggle(HWND, LPCSTR);
	void binboxForceUpdate(HWND, LPCSTR);
	
	void SetBack(LPCSTR);
	void SetBgColor(LPCSTR);
	void SetColor(LPCSTR);
	void SetHilight(LPCSTR);
	void SetLeftClick(LPCSTR);
	void SetMiddleClick(LPCSTR);
	void SetRightClick(LPCSTR);
	void SetShadow(LPCSTR);
	void SetTextShadow(LPCSTR);
	void SetTextShadowClr(LPCSTR);
	void SetTextShadowOff(LPCSTR);
	void SetOnTop(LPCSTR);
	void SetOnBottom(LPCSTR);
	void SetMouseEnter(LPCSTR);
	void SetMouseExit(LPCSTR);
	void SetDispRect(LPCSTR);
	
	
private:
	
	bool hidden, onTop, onBottom, textShadow, textBold, textItalic,
		mouseOver, waitForBox, inBox;
	char *fontFace, *leftClick, *rightClick, *middleClick,
		*mouseEnter, *mouseExit, *backFile;
	int x, y, w, h, bw, bh, textJustify, rotateI, fontHeight, textShadowOff,
		winStyle, interval;
	COLORREF bgColor,  hilightColor, shadowColor, textColor, textShadowColor;
	HBITMAP backBmp;
	HFONT hFont;
	RECT border, display, client;
	POINT mousePos;
	HRGN kRgn;
	HWND kWnd, desktopWnd;
	HINSTANCE dllInst;
	void (*SetFunction)(char*);
	SetFunctions SetFunctionsTable[20];
	void deleteObjects();
};

extern binbox* binBox;

#endif /* BINBOX_H */