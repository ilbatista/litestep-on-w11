/******************************************************************************
You are reading the source for binbox.dll

  Open source visual litestep module to handle the windows native
  recycle bin folder.

  Created and coded by: Mike Edward Moras (e-sushi@gmx.net)
  Tested by: Allesandro Limonta (allelimo@jumpy.it)

  url: http://e-sushi.shellscape.org


	This module was created, using the codebase of pika's open source
	sourcecode to his kclock module. He said it would be nice if he's
	credited... I thought it wouldn't only be fair to do so, but it was
	time to tell you (the one reading this) that without his sourceode,
	I would probably still not be able to code up a visual module fro
	scratch. (guess I'm either to bussy coding other stuff, or - more
	probably - I'm just too lazy. It's more easy if someone else allready
	did most of the job <g>). Thanks pika!!! (http://pika.shellscape.org)			
******************************************************************************/

#include <windows.h>
#include "../current/lsapi/lsapi.h"
#include "main.h"
#include "Functions.h"
#include "binbox.h"
#include "bangs.h"
#include "AggressiveOptimize.h"
#include <strsafe.h>

// keeps me from having all of this inside binbox::onPaint()
void GetBinString(char *copyString) {
	SHQUERYRBINFO test;
	SHQueryRecycleBin(NULL,&test );
	if (test.i64NumItems>0)
	{
		LPCTSTR pszFormat = TEXT("%d item(s)");
		StringCbPrintf(copyString, 64, pszFormat, test.i64NumItems);
	} else {
		LPCTSTR pszFormat = TEXT("empty");
		StringCbPrintf(copyString, 64, pszFormat, test.i64NumItems);
	}
}



// function to convert a string to a COLORREF value.
// used for the setting bangs

COLORREF StrToCR(char* strColour, bool rgb) {
	char buffer[11];
	COLORREF colour;
	
	
	if ( rgb )
		StringCbPrintf(buffer, 11, "0x00%c%c%c%c%c%c", strColour[4], strColour[5], strColour[2], strColour[3], strColour[0], strColour[1]);
	else {
		StringCbCopy(buffer,5, "0x00");
		
		strncat(buffer, strColour, 6);
	}
	
	colour = strtol(buffer, '\0', 0);
	
	return colour;
}


void StrToRect(char* tmpString, RECT* tmpRect, int w, int h) {
	char *token;
	token = strtok(tmpString, " ");
	if ( token )
	{
		tmpRect->left = atoi(token);
		if ( tmpRect->left < 0 )
			tmpRect->left += w;
	}
	token = strtok(NULL, " ");
	if ( token ) 
	{
		tmpRect->top = atoi(token);
		if ( tmpRect->top < 0 )
			tmpRect->top += h;
	}
	token = strtok(NULL, " ");
	if ( token )
	{
		tmpRect->right = atoi(token);
		if ( tmpRect->right <= 0 )
			tmpRect->right += w;
	}
	token = strtok(NULL, " ");
	
	if ( token ) {
		tmpRect->bottom = atoi(token);
		if ( tmpRect->bottom <= 0 )
			tmpRect->bottom += h;
	}
}