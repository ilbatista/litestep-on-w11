Lsbox release version 1.0
       -{Stable}-

--------------
I. About LsBox
--------------
LsBox is a skinable easy to customize and 
resource-friendly alternative to the "normal" 
shortcutgroups for a number of applications like 
freefloating menues, messageboxes and 
configuration dialogs.


----------------
II. Requirements
----------------
You  will need a fairly new LS dev build to run LsBox.
I don't know how new, but if you're getting a msg about
a library function that is not found then your build 
is too old.
You will also need to have at least win98 running.
Win2k should work fine, too.

-----------------
III. Installation
-----------------
Just copy Lsbox.dll to your LS dir and add the following 
line to your step.rc: 

   Loadmodule C:\Litestep\Lsbox.dll
(*assuming you have your LS stuff in C:\Litestep*)

-------
IV. Use
-------
To actually use LsBox you have to have a .box 
file and a few gfx to use with it.
I have included two examples with this pre-release.
Modifying them shouldn't be a problem for you if 
you ever customised a theme for your use. The .Box 
file's syntax is plain step.rc code. 

After having placed everything in the right directorys
and editing you can call
      
        !LsBoxCreate [path and filename of the .Box file]

Examples:
	!LsBoxCreate C:\Litestep\recycle.box
	!LsBoxCreate C:\Litestep\Shutdown.box

There are three ways to destroy a Box.......
The first one is to call !LsBoxDestroy without anything
from inside a Box. This Box will be promptly destroyed.
The second one is to call !LsBoxDestroy <Name of the Box to destoy>
from the outside. With LsXcommand for instance. The Box 
with the matching name is then destroyed.
And the last way is to call !LsBoxDestroy <Name of the Box to destoy>
from inside a Box.

I won't tell you more about it, because you already 
knew far too much. 

-----------
V. Features
-----------
  -LsBoxName <Name Of the Box>
   The name of the box is used to identify a box. It's the 
   window title shown in the taskbar and it is needed to 
   destroy a box from the outside 
   ( like calling !LsBoxDestroy from LsXcommand )
   and to destroy a Box from within an other Box.
 
  -LsBoxX <xpos>
   and 
  -LsBoxY <yPos>

  -LsBoxBackGround <Image>
   Can be made transparent with great magic pink(tm)
   This also sets the Width&Height of the box.
  
  -LsBoxDRLeft,
  -LsBoxDRRight, 
  -LsBoxDRTop
   And
  -LsBoxDRBottom
   These set the dragable area of the box.

  -LsBoxSticky
   Shows the Box on all Desktops

  -LsBoxUnique
   This in a unique feature
   it makes a Box unique
   so there can be only one 
   unique box of a kind.

  -LsBoxAlwaysOnTop
   This makes the box AlwaysOnTop

  -*Shortcut <xPos> <yPos> <Normal> <Over> <Clicked> <Bang(s)>
   Use these to toggle bangs. Use Magic Pink(tm) to 
   get transparent ones.
   don't use these to create dummys - use *image instead

  -*Image <xPos> <yPos> <image>
   Resource-friendly dummy images. These will be 
   combined with the background at creation-time.

-----------
VI. History
-----------
rel 1.0
    -Rewrote cfg-destroy mechanism
    -fixed the cfg leak

rel 0.98
    -Added LsBoxSticky
    -Added LsBoxUnique
    -Added LsBoxAlwaysOnTop
    -Added Destroy of other boxes from inside a box
    -Added Creation of a box from inside a box

rel 0.95
    -improved *image painting
    -rewrote *shortcut handeling

rel 0.9
    -first preview release

-----------
VII. Issues
-----------

*Magic pink for *image won't work
