/////////////////////////
// Aurora B1
// Written By: MrJukes
// Released: 12/30/99
/////////////////////////

LoadModule c:\litestep\aurora.dll

/////////////////////////
// Step.rc
/////////////////////////
AuroraTopWidth 3
AuroraTopColorIn FF0000
AuroraTopColorOut 00FF00

AuroraRightWidth 3
AuroraRightColorIn 00FF00
AuroraRightColorOut FF0000

AuroraBottomWidth 3
AuroraBottomColorIn 0000FF
AuroraBottomColorOut 00FFFF

AuroraLeftWidth 3
AuroraLeftColorIn 00FFFF
AuroraLeftColorOut FF0000

Have fun,
	MrJukes