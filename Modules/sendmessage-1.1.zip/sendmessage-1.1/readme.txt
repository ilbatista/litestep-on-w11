Sendmessage 
Nathan Moore 
nem_at_myrealbox.com 
Return Value mod by [thegeek@efnet] 
okrog_at_online.no 


What is it? 
Sendmessage is a Litestep module or win32 executable that wraps the SendMessage windows api call. 

Version History? 
1.0 Initial Version by Nathan Moore 
1.1 thegeek: Added the ability to read the return value for the sendmessage and store it as an evar. This opens up a whole load of possibilites, as basically _all_ modules that use sendmessages only can be replaced by scripts. Lsslider can for example be rewritten using xlabel, some scripting and this module. 

Usage 
!SendMessage "Window Class" "Window Title" "Message" "WPARAM" "LPARAM" "RETURN_VALUE_EVAR" 
Sends the given message to a window described by the given Window class and title.  Both the class and title are not needed but at least on is needed a null token must begiven for a class or title that is not given. The message is the decimal form of the windows message. That is WM_COMMAND will not work, nor will 0x0111 the message needs to be in decimal form 273 for WM_COMMAND.  Both WPARAM and LPARAM are optional and need to be in decimal form as well.  The executable accepts the same arguments as the bang command.
Examples (Only 3 examples are given however any windows message can be sent): 
Make Winamp play (WM_COMMAND) 
!SendMessage "Winamp 1.x" "" 273 40045 
Mute FooBar2000 (Must have it set to use multimedia keys) (WM_APPCOMMAND) 
!SendMessage "FOOBAR2000_CLASS" "" 793 "" 524288 
Minimize the Seventeen or Bust client (WM_SYSCOMMAND) 
!SendMessage "SobWinClient" "SB v1.1.0" 274 61472 
Retrieve the currently played seconds from Foobar2000 w/foo_remote.dll (WM_USER+14) 
!SendMessage frw_cls "" 1038 0 0 PlayedSeconds 
!parseevars !alert %#PlayedSeconds%#