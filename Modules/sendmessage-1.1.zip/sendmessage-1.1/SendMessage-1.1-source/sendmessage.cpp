/* Nathan E. Moore
* October 9, 2003
* 
* Sendmessage.cpp 
* A small program to allow the user to call the windows api function 
* SendMessage.  Compiles to a Litestep dll or to a win32 executable depending
* on the symbol SM_DLL.  Depnends on boost for string tokenization.
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "sendmessage.h"
#include <boost\tokenizer.hpp>
#include <string>
#include <sstream>
#include <windows.h>

#ifdef SM_DLL
#include "..\lssrc\lsapi\lsapi.h"
#else
#include <iostream>
#endif

using namespace std;

#ifdef SM_DLL
void onSendMessage(HWND, const char* pszArgs)
#else
void onSendMessage(string args)
#endif
{	
	using boost::tokenizer;
	using boost::escaped_list_separator;
	typedef escaped_list_separator<char> separator;
	typedef tokenizer<separator> elsTokenizer;

	class SendMessageException
	{
	public:
		SendMessageException(string &str) : msg(str){};
		string msg;
	};

	HWND hwndreceiver = NULL;
	UINT msg = 0;			// unsigned int
	WPARAM wparam = 0;		// unsigned int
	LPARAM lparam = 0;		// long
	LRESULT lresult = 0;	// long
	char ExportReturnValEvar[1024];
#ifdef SM_DLL
	string args(pszArgs);
#endif
	elsTokenizer tok(args, separator("", " ", "\""));
	elsTokenizer::iterator iter = tok.begin();

	try
	{
		if (iter != tok.end())
		{
			const char* wndclass = NULL;
			string strclass = *iter;
			if (strclass.length() > 0)
				wndclass = strclass.c_str();
			iter++; 
			if(iter != tok.end())
			{
				const char* wndtitle = NULL;
				string strtitle = *iter;
				if (strtitle.length() > 0)
					wndtitle = strtitle.c_str();
#ifdef _DEBUG
#ifndef SM_DLL
				cout << "WNDCLASS " << (wndclass != NULL ? wndclass : " ")
					 << "\nWNDTITLE " << (wndtitle != NULL ? wndtitle : " ") << endl;
#endif
#endif
				hwndreceiver = FindWindow(wndclass, wndtitle);
				if (hwndreceiver == NULL)
					throw SendMessageException("Could not find window with class \"" + strclass + "\" and Title \"" + strtitle + "\"");

				
			}
		}
		else
			throw SendMessageException(string("Too Few Tokens"));

		iter++;
		if (iter != tok.end())
		{
			stringstream converter(*iter);
			converter >> msg;
#ifdef _DEBUG
#ifndef SM_DLL
			cout << "MSG " << *iter << " " << msg << endl;
#endif
#endif
		}
		else 
			throw SendMessageException(string("Too Few Tokens"));

		iter++;
		if (iter != tok.end())
		{
			stringstream converter(*iter);
			converter >> wparam;
#ifdef _DEBUG
#ifndef SM_DLL
			cout << "WPARAM " << *iter << " " << wparam << endl;
#endif
#endif
		}

		iter++;
		if (iter != tok.end())
		{
			stringstream converter(*iter);
			converter >> lparam;
#ifdef _DEBUG
#ifndef SM_DLL
			cout  << "LPARAM " << *iter << " " << lparam << endl;
#endif
#endif
		}

		iter++;
		if (iter != tok.end())
		{
			stringstream converter(*iter);
			converter >> ExportReturnValEvar;
#ifdef _DEBUG
#ifndef SM_DLL
			cout  << "ExportReturnValEvar " << *iter << " " << ExportReturnValEvar << endl;
#endif
#endif
		}

		lresult = SendMessage(hwndreceiver, msg, wparam, lparam);
		#ifdef SM_DLL
		sprintf(lresultbuf, "%d", lresult);
		LSSetVariable(ExportReturnValEvar, lresultbuf);
        #endif
		#ifdef _DEBUG
		#ifndef SM_DLL
		cout  << lresult;
		#endif
		#endif
	}
	catch (SendMessageException e)
	{ 
#ifdef SM_DLL
		LSLog(LOG_NOTICE, MODULE_NAME, e.msg.c_str());
#else
		cout << e.msg << endl;
#endif
	}

}

#ifndef SM_DLL
int main(int argc, char** argv)
{
	if (argc <= 1)
		cout << "Usage: sendmessage \"Window Class\" \"Window Title\" Message WParam LParam\n"
		<< "Window Class or Title must be supplied, both are not needed\n"
		<< "message is required however WParam and LParam are both optional\n"
		<< " \"\" is a null token" << endl;
	else
	{
		string args;
		for (int i = 1; i < argc; i++)
		{
			args.append("\"");
			args.append(argv[i], strlen(argv[i]));
			args.append("\"");
			args.append(" ", 1);
		}
		onSendMessage(args);
	}

	return 0;
}
#endif 

#ifdef SM_DLL
int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
	AddBangCommand(BANG_CMD, onSendMessage);
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand(BANG_CMD);
}
#endif