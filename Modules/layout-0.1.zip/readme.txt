=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    Layout 0.1
    (simple keyboard layout switching module)
    Copyright(c) Sergey Gagarin a.k.a. Seg@
    Ekaterinburg, Russia  2005
    README
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

=========================
The Table of Content
-------------------------
  I. REQUIREMENTS
 II. INSTALLATION
III. CONFIGURATION
 IV. SOURCES
  V. CONTACTS

=====================
I. REQUIREMENTS
---------------------
Module has been tested only under WinXP SP1, so
I cannot say will it work under other Windows
version or not.

=====================
II. INSTALLATION
---------------------

Just add the following line to your theme.rc:
*NetLoadModule layout-0.1
Then you'll be able to use something like this:
*Hotkey WIN N !LayoutNext
or
*Label Lng
LngText "[upperCase(skblayout)]"
LngOnLeftClick !LayoutNext

=====================
III. CONFIGURATION
---------------------

There is no configuration and only two bangs:

!LayoutNext
  Switch to the next layout in the cycle
  
!LayoutPrev
  Switch to the prev layout in the cycle

=====================
IV. SOURCES
---------------------

Source code is available under the GNU GPL2 license
(see license.txt for details...)

=====================
V. CONTACTS
---------------------

If you want to beat my face or have any other reason
to contact me, I am available:
 - in the ICQ network: 162261148
 - on #irc at freenode.net (rarely)
 - or via mail: inform-sega@freemail.ru

Ok, that's all.
Wish you luck with a playing this toy.
