*******************************************************************************************
Module: Power Monitor (battery monitor for laptops)

Version: 000001A

Revision: First Release (11/18/01)


Author: Stephen Gregory(Ginsu)
E-Mail: PowerMod@ginsublade.cjb.net
		
*******************************************************************************************

Installation: 
1. put the PowerModule.dll wherever you put your modules as int C:\litestep\modules\ 
2. add the line to the Step.rc: 
	LoadModule "$ModulesDir$PowerMonitor.dll"
3. either copy the the contents of Power.rc into your step.rc or or add the line to your step.rc: Include Power.rc

if you don't want to configure this module yourself you can put the images directory included in your litestep directory.

4. Recycle



	
This is my first module.  It basically just creates a window that displays:
* A battery image if the computer is running on battery,
* A power outlet image  if the computer is running on AC,
* The time left in hours, (is not drawn when plugged in, may take a while to draw after unplugging from AC because it will take the battery a little bit to recalculate how long it has left in it)
* The percent of battery life remaining,
* A powerbar that shows the percentage of battery as a bar graph type thing

this module does support transparency

Bang Commands:
!PwrShow  	- shows the window
!PwrHide  	- hides the window
!PwrToggle	- shows the window if it's hidden; hides the window if it is being shown
!PwrInfo        - displays a message box that says the current battery life

There are a lot of RC values to be configured, but it'll be easier to look at the Power.rc to figure those out. 


notes:
*if you try to have something drawn over where the background image is transparent, it won't be drawn. (working on fixing this)
 
*I've tested pretty much everything, the only thing I'm not very sure about is whether or not the powerbar works correctly 

any bugs, suggetsion, comments, or you just want to say hi, e-mail me at: PowerMod@ginsublade.cjb.net