/*
*This is a Battery monitor  module for the LiteStep shell
*
*without a laptop this probably won't do you any good, unless your desktop runs
*on a battery in which case you have more problems...
*
*as of right now all I can find is a tacky wharf module, I thought this would look better
*plus I don't have to be running wharf now to see my battery life :)
*VERSION: 0001a
*@Author: Ginsu
*
*/

#ifndef __PowerMonitor_H
#define __PowerMonitor_H

#include <windows.h>
#include "C:\lsSource\ls-b24\lsapi\lsapi.h"
#include "C:\lsSource\ls-b24\lsapi\lswinbase.h"

#define MAX_LINE_LENGTH 4096

class Powermonitor : public Window
{
private:
  //member variables
  HWND pWnd;
  //Pointer to the system's power struct
  LPSYSTEM_POWER_STATUS batteryStatus;

  //size of the window
  int pwrWidth;
  int pwrHeight;
  
  //location of the windows
  int pwrX;
  int pwrY;
  

  //location and size of the powerbar;
  boolean hasPowerBar;
  int pwrBarX;
  int pwrBarY;
  int pwrBarWidth;
  int pwrBarHeight;
  int pwrBarColor;
  

  //Bitmaps for the drawing of the module
  HBITMAP pwrBackground, pwrBackOld;
  

  int batteryX;
  int batteryY;
  HBITMAP pwrBattery;
  

  int outletX;
  int outletY;
  HBITMAP pwrOutlet;
	

  //Locations for drawing  timeleft and battery left percentage 
  int percentX;
  int percentY;
  int percentColor;

  int percentHeight;
  int percentWidth;
  char* percentFont;

  int timeLeftX;
  int timeLeftY;
  int timeLeftColor;

  int timeLeftHeight;
  int timeLeftWidth;
  char* timeLeftFont;
 /*
  * ok this may seem like overkill, but I only want to draw the timeleft if the laptop
  * is running off the batteries.  Otherwise the batterylife is undefined  I'm planning 
  * add a bitmap to load when displaying the time left for no other reason than to make 
  * my theme look cool.
  */

/**
  to do:  add timeleft bitmap stuff
  */

public:

	//constructor /deconstructor
  Powermonitor(HWND parentWnd, int& code);
  ~Powermonitor();


  //Memeber methods for bangs
  void BangPwrHide(HWND, LPCSTR);
  void BangPwrInfo(HWND, LPCSTR);
  void BangPwrShow(HWND, LPCSTR);
  void BangPwrToggle(HWND, LPCSTR);
  /*
  TODO:
    Add any Public Functions

  */

private:
  /*
  TODO:
    Add any Private Functions

  */
  virtual void windowProc(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onSysCommand(Message& message);
  void onPowerStatusChange(Message& message);
  void onPaint(Message& message);

  void iconListPaint( HDC hdcDst, HRGN hrgnDst );
  void paintPower(HDC hdcBuffer, HRGN hrgn);
  /*
  TODO:
    Add any Message Handlers

  */

};

void BangPwrHideFunction(HWND, LPCSTR);
void BangPwrInfoFunction(HWND, LPCSTR);
void BangPwrShowFunction(HWND, LPCSTR);
void BangPwrToggleFunction(HWND, LPCSTR);
/*
TODO:
  Add any Bang Command Declarations

*/
extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
