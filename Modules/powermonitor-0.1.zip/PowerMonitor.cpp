
/*
LiteStep Module AppWizard
*/
/****************************************************************************
11/10/82: birth of the creator of this module
11/10/01: finally began work on this module            //first version : 000001a
	!Bang commands working, the usuals !PwrHide, !PwrShow, !PwrToggle,
	!PwrInfo displays a window with battery info
	Drawing the window is beginning to work
	Getting the battery info at least works
11/18/01: everything seems to be working

****************************************************************************/
#include "PowerMonitor.h"
const char szAppName[] = "Powermonitor"; // Our window class, etc
const char Revision[] = "Revision: 000001a"; // Our Version
const char Id[] = "Id: PowerMonitor.cpp,v 000001a 2:38:7  Exp"; // The Full RCS ID.
Powermonitor *powermonitor; // The module


	#define WC_SHELLDESKTOP    TEXT(_TEXT("DesktopBackgroundClass"))

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  int code;
  
	Window::init(dllInst);
  powermonitor = new Powermonitor(ParentWnd, code);
  return code;
	
}

void quitModule(HINSTANCE dllInst)
{
  delete powermonitor;
}


//=========================================================
// Bang commands
//=========================================================
void BangPwrHideFunction(HWND caller, LPCSTR args) {
  /*
  TODO:
    Add Bang Code Here
  */
  powermonitor->BangPwrHide(caller, args);
}


void BangPwrInfoFunction(HWND caller, LPCSTR args) {
  /*
  TODO:
    Add Bang Code Here
  */
  powermonitor->BangPwrInfo(caller, args);
}


void BangPwrShowFunction(HWND caller, LPCSTR args) {
  /*
  TODO:
    Add Bang Code Here
  */
  powermonitor->BangPwrShow(caller, args);
}


void BangPwrToggleFunction(HWND caller, LPCSTR args) {
  /*
  TODO:
    Add Bang Code Here
  */
  powermonitor->BangPwrToggle(caller, args);
}


/*
TODO:
  Add Code for Bang Commands (i.e. void Bang(HWND caller, LPCSTR args)

*/

//=========================================================
// Module code
//=========================================================
/*
TODO:
  Add Code internal to the Class

*/

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Powermonitor::Powermonitor(HWND parentWnd, int& code):
Window(szAppName)
{
  char * szTemp = new char[128];
  int msgs[] = {LM_GETREVID, 0};


pWnd = parentWnd;


  //allocate memory for the power status
   batteryStatus = new _SYSTEM_POWER_STATUS;
  //get pointer to the power status
   GetSystemPowerStatus(batteryStatus);

	HWND desktop = FindWindow(WC_SHELLDESKTOP, NULL);
	if (!desktop)
		desktop = GetDesktopWindow(); 
    


 //load the image files for the module
	GetRCString("PwrBackground", szTemp, ".none", 256);
	pwrBackground = LoadLSImage(szTemp, NULL);
	GetRCString("PwrOutlet", szTemp, ".none", 256);
	pwrOutlet = LoadLSImage(szTemp, NULL);
	GetRCString("PwrBattery", szTemp, ".none", 256);
	pwrBattery = LoadLSImage(szTemp, NULL);

//get information for the powerbar
  hasPowerBar = GetRCBool("ShowPowerBar", TRUE);
  pwrBarX     = GetRCInt("PowerBarX", 0);
  pwrBarY     = GetRCInt("PowerBarY", 0);
  pwrBarWidth = GetRCInt("PowerBarWidth", 100);
  pwrBarHeight= GetRCInt("PowerBarHeight", 10);

  pwrBarColor = GetRCColor("PowerBarColor", 0xffffff);

 //get location for the power graphics
   batteryX= GetRCInt("BatteryX", 0);
   batteryY= GetRCInt("BatteryY", 0); 
  
   outletX = GetRCInt("OutletX", 0);
   outletY = GetRCInt("OutletY", 0);


//get window position from RC file
	pwrX = GetRCInt("PowerX", 500);
    pwrY = GetRCInt("PowerY", 0);

	GetLSBitmapSize( pwrBackground, &pwrWidth, &pwrHeight );

//get position and color of the text being displayed

  //if either of these are -1 don't draw
   percentX = GetRCInt("BatteryPercentX", -1);
   percentY = GetRCInt("BatteryPercentY", -1);
   percentColor = GetRCColor("BatteryPercentColor", 0xffffff);
   percentHeight = GetRCInt("BatteryPercentHeight", 8);
   percentWidth  = GetRCInt("BatteryPercentWidth", 4);
   percentFont   = new char[34];
   GetRCString("BatteryPercentFont", percentFont,  "Times", 256);

   timeLeftHeight = GetRCInt("BatteryTimeHeight", percentHeight);
   timeLeftWidth  = GetRCInt("BatteryTimeWidth", percentWidth);
   timeLeftFont   = new char[34];
   GetRCString("BatteryTimeFont",timeLeftFont, percentFont, 256);



   timeLeftX = GetRCInt("BatteryTimeX", -1);
   timeLeftY= GetRCInt("BatteryTimeY", -1);
   timeLeftColor = GetRCColor("BatteryTimeColor", 0xffffff);



  if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP,
                    pwrX, pwrY, pwrWidth, pwrHeight, desktop))
  {
    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
    code = 1;
    return;
  }

  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);


  SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);




  //add bang commands to the shell
  AddBangCommand("!PwrHide",BangPwrHideFunction);
  AddBangCommand("!PwrInfo",BangPwrInfoFunction);
  AddBangCommand("!PwrShow",BangPwrShowFunction);
  AddBangCommand("!PwrToggle",BangPwrToggleFunction);



  /*
  TODO:
    Add AddBangCommand() statements

  TODO:
    Add Any other initialization code

  */

	//show the window
   ShowWindow( hWnd, SW_SHOWNOACTIVATE );	
   SetWindowPos( hWnd, NULL, pwrX, pwrY, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE );

  
  ValidateRect(parentWnd, NULL);
  code = 0;
  delete[] szTemp;
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
Powermonitor::~Powermonitor()
{
  int msgs[] = {LM_GETREVID, 0};

  SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

  RemoveBangCommand("!PwrHide");
  RemoveBangCommand("!PwrInfo");
  RemoveBangCommand("!PwrShow");
  RemoveBangCommand("!PwrToggle");

  /*
  TODO:
    Add Code to RemoveBangCommand()

  */
  destroyWindow();
  delete batteryStatus;
  delete[] timeLeftFont;
  delete[] percentFont;
}


//=========================================================
// Registered messages
//=========================================================

void Powermonitor::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,          LM_GETREVID)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
	MESSAGE(onPowerStatusChange,             WM_POWERBROADCAST)
	MESSAGE(onPaint,             WM_SETREDRAW)
	MESSAGE(onPaint,             WM_PAINT)
    MESSAGE(onPaint,             LM_REPAINT)

	
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================

/**
*I wasn't really sure how to get this to work well so this is based on(stolen from)
* the systray2 onPaint() method almost(And by almost I mean Completely) word for word
*
*paints the battery monitor's window
*@param the message that said to repaint
*/
void Powermonitor::onPaint(Message& message){
	HDC     hdcBuffer;
	HBITMAP hbmBuffer, hbmBufOld;
	HRGN    hrgn = NULL;
    
	GetSystemPowerStatus(batteryStatus);

	PAINTSTRUCT ps;
	HDC	hdcScreen = BeginPaint(hWnd, &ps);

	hdcBuffer = CreateCompatibleDC(hdcScreen);
	hbmBuffer = CreateCompatibleBitmap(hdcScreen, pwrWidth, pwrHeight);
	hbmBufOld = (HBITMAP)SelectObject(hdcBuffer, hbmBuffer);

	
	hrgn = CreateRectRgn( 0, 0, 0, 0 );

	// blit the skin
	paintPower(hdcBuffer, hrgn);
	iconListPaint( hdcBuffer, hrgn );


		SetWindowRgn(hWnd, hrgn, TRUE);

	// when the region is applied you can use a simple SRCCOPY from the buffer
	BitBlt(hdcScreen, 0, 0, pwrWidth, pwrHeight, hdcBuffer, 0, 0, SRCCOPY);

	// reselect the oldBitmap and kill the new one
	SelectObject(hdcBuffer, hbmBufOld);
	DeleteObject(hbmBuffer);

	// _tremove the memory DC
	DeleteDC(hdcBuffer);
	
	EndPaint(hWnd, &ps);
    ValidateRgn(hWnd, hrgn);
	DeleteObject(hrgn);
}

void Powermonitor::paintPower(HDC hdcDst, HRGN hrgnDst){
	HRGN hrgnBack        = BitmapToRegion(pwrBackground, RGB(255,0,255), 0x101010, 0, 0);
    
	//HDC hdcBattery = CreateCompatibleDC(hdcDst);
	HDC hdcSrc = CreateCompatibleDC(hdcDst);
	pwrBackOld = (HBITMAP)SelectObject(hdcSrc, pwrBackground);
    

	

	TransparentBltLS(hdcDst, 0,0, pwrWidth, pwrHeight, hdcSrc, 0, 0, RGB(255, 0, 255));

	SelectObject(hdcSrc, pwrBackOld);
	DeleteDC(hdcSrc);

	
		CombineRgn(hrgnDst, hrgnBack, NULL, RGN_COPY);
}

/*
DWORD ExtTextOut(LPPDEVICE lpDestDev, WORD wDestXOrg, WORD  wDestYOrg, 
    LPRECT lpClipRect, LPSZ lpString, int wCount, 
    LPFONTINFO lpFontInfo, LPDRAWMODE lpDrawMode, 
    LPTEXTXFORM lpTextXForm, LPSHORT lpCharWidths, 
    LPRECT lpOpaqueRect, WORD wOptions);

  */

/*Draws the icons for the battery and the power
*
*stolen again from the system tray(sorry for the lack of originality)
*/

void Powermonitor::iconListPaint( HDC hdcDst, HRGN hrgnDst )
{

	int cx, cy;
	
	char * szTemp = new char[128];
	
	RECT r;     // The rectangle for the powerbar
    HFONT font; //= CreateFont(-MulDiv(8, GetDeviceCaps(hdcDst, LOGPIXELSY), 72), 3, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DRAFT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Times");  

  

	if(batteryStatus->ACLineStatus)
	GetLSBitmapSize( pwrOutlet, &cx, &cy );
	else 
	GetLSBitmapSize( pwrBattery, &cx, &cy );
	
	//if the user wants to display a percentage bar do this
	if(hasPowerBar)
	{
		HBRUSH brush = CreateSolidBrush(pwrBarColor);	
		
		r.top = pwrBarY;
		r.left = pwrBarX + pwrBarWidth*((100 - batteryStatus->BatteryLifePercent)/100.0);
		r.bottom = pwrBarY + pwrBarHeight;
		r.right = pwrBarWidth + pwrBarX;

    FillRect( hdcDst, &r, brush);
	
	}

	HRGN hrgnBack        = BitmapToRegion(pwrBattery, RGB(255,0,255), 0x101010, 0, 0);
    
	//HBITMAP old;
	//HDC hdcBattery = CreateCompatibleDC(hdcDst);
	HDC hdcSrc = CreateCompatibleDC(hdcDst);

	
	if(batteryStatus->ACLineStatus)
	{
		SelectObject(hdcSrc, pwrOutlet);
		TransparentBltLS(hdcDst, outletX,outletY, cx, cy, hdcSrc, 0, 0, RGB(255, 0, 255));
    
	}
	else
	{
		SelectObject(hdcSrc, pwrBattery);
		TransparentBltLS(hdcDst, batteryX,batteryY, cx, cy, hdcSrc, 0, 0, RGB(255, 0, 255));

	}
    

	//sprintf(szTemp, "%d", batteryStatus->BatteryLifePercent);
	SetBkMode(hdcDst, TRANSPARENT);

	if(percentX != -1)
	{	font =  CreateFont(-MulDiv(percentHeight, GetDeviceCaps(hdcDst, LOGPIXELSY), 72), percentWidth, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DRAFT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, percentFont);  
		SelectObject(hdcDst, font);

		sprintf(szTemp, "%d%%", batteryStatus->BatteryLifePercent);
		SetTextColor(hdcDst, percentColor );
		
		TextOut(hdcDst,percentX,percentY,szTemp,strlen(szTemp));
	}

	if(timeLeftX != -1  && batteryStatus->BatteryLifeTime < 20000 )
	{
		font =  CreateFont(-MulDiv(timeLeftHeight, GetDeviceCaps(hdcDst, LOGPIXELSY), 72), timeLeftWidth, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DRAFT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, timeLeftFont);  
		SelectObject(hdcDst, font);


		sprintf(szTemp, "%.1f", ((int)((float)(batteryStatus->BatteryLifeTime)/(float)360))/10.0);
		SetTextColor(hdcDst, timeLeftColor );
		TextOut(hdcDst,timeLeftX,timeLeftY,szTemp,strlen(szTemp));
	}

	//SelectObject(hdcSrc, old);
	DeleteDC(hdcSrc);

		
		CombineRgn(hrgnDst, hrgnBack, NULL, RGN_OR);
	
	DeleteObject(font);	
	delete szTemp;	
}



/*
*deals with power device changes ie. something getting unplugged	
*
*asks windows for the powerstatus again
*invalidates the window so windows will redraw it
*
*@possible improvements: add ability run commands when ac plugged in/removed
*/
void Powermonitor::onPowerStatusChange(Message& message){


GetSystemPowerStatus(batteryStatus);

RECT r;
r.top = 0;
r.left = 0;
r.right = pwrWidth;
r.bottom = pwrHeight;
InvalidateRect(hWnd, &r, TRUE);


}//end of onPowerStatusChange


void Powermonitor::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void Powermonitor::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "PowerMonitor.dll: %s", &Revision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &Id[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


void Powermonitor::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


//=========================================================
// Bang command handling
//=========================================================
void Powermonitor::BangPwrHide(HWND caller, LPCSTR args) {
ShowWindow( hWnd, SW_HIDE );
}



/*************************************************************
 This method displays a message box that tells what battery percentage
 is left in the battery;
 *********************************************************** */
void Powermonitor::BangPwrInfo(HWND caller, LPCSTR args) {
	char*  message = new char[128];
	
	
	//GetSystemPowerStatus(batteryStatus);
	if(batteryStatus->ACLineStatus)
	sprintf(message, "Battery Life Percentage is %d and running on AC",  batteryStatus->BatteryLifePercent);
	else
	sprintf(message, "Battery Life Percentage is %d and will last for about %.1f hours",  batteryStatus->BatteryLifePercent, ((int)((float)(batteryStatus->BatteryLifeTime)/(float)360))/10.0);
	
	
	

MessageBox(hWnd, message, "Battery life", NULL);
delete[] message;
}


void Powermonitor::BangPwrShow(HWND caller, LPCSTR args) {
ShowWindow( hWnd, SW_SHOWNOACTIVATE );
}


void Powermonitor::BangPwrToggle(HWND caller, LPCSTR args) {
	
	ShowWindow( hWnd, !IsWindowVisible( hWnd )?SW_SHOWNOACTIVATE:SW_HIDE );
}



