This module requires the use of the Borland runtime libraries:
http://www.shellfront.org/cc3250.zip


New settings:
 TasksEndX           ; maximum extent of the tiles, which still begin at
TasksX.
 TasksBorderLeft    ; left portion of task bitmap that is not tiled, stretch
not yet supported.
 TasksBorderRight  ; same for right side
 TasksWidthMax    ; replaces taskswidth, setting the largest size a tile is
ever allowed to be.

Settings that are now irrelevant:
 TasksWrapCount
 TasksWrapDirection
 TasksWidth

Only horizontal task tiling is supported, and there may be odd behaviors if
you use negative coords for both tasksX and tasksEndX. I never got around to
fully finishing and debugging the code. That shoudn't be an issue, since you
can now do things like $resolutionx-100$ and the core will do the dirty
work. Or you could just use taskbar3. =)

-Brian Wolven