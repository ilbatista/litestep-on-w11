This module allows for writing back settings to the .rc files. It uses the exact same parsing code as the LSAPI does. The module has three !bang commands at the moment:

 !RCSetNewEntryFile 	"Path to file for new settings.rc"
 !RCWrite		SettingName	[Value]
 !RCRemove		SettingName

The !RCWrite command overwrites the first instance of the setting if it exists, otherwise it appends it to the file specified for new entries (set with !RCSetNewEntryFile or with the RCNewEntryFile evar). The RCNewEntryFile evar defaults to the main step.rc.