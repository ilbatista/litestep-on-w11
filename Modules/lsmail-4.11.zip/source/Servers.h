#ifndef  __SERVERS
#define  __SERVERS

#include <windows.h>
#include <wininet.h>

enum {
	MAIL_NO,
	MAIL_EXISTS,
	MAIL_NEW
};

class SERVER
{
public:
	SERVER(int NumServers);
	~SERVER();

	POP3Check();
	char* ReceiveData(SOCKET conn_socket);

	char* name;
	char* host;
	char* login;
	char* password;
	int ID, x, y, port, num, newnum, MAIL_STATUS;
	BOOL bERROR;
	HMENU menu;

	SERVER* next;
} *Servers;

#endif