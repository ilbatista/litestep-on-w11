this module is used to control LEGO Mindstorm from within LS
-maduin