#include <stdio.h>
#include <windows.h>
#include <string.h>
#include "change.h"

const char rcsRevision[] = "$Revision: 0.2 $"; 
const char rcsId[] = "$Id: ChangeLine version 0.2 (Two_toNe)  $"; 
char szLitestepPath[256];
char szAppName[] = "ChangeLine";
HWND parent;
HWND hMainWnd;

// Function done by slimer (ola@miranda.org) thnx!
int osncmp(char *str,char *str2, unsigned int l)
{
	unsigned int i;

	if (strlen(str)<l)
		return -1;
	if (strlen(str2)<l)
		return 1;

	for (i=0;i<l;i++)
		if (str[i] != str2[i])
			return -1;

	return 0;
}

// Function done by slimer (ola@miranda.org) thnx!
char *osstr(char *haystack,char *needle)
{
	int i=0;

	while (haystack[i] != '\0') {
		if (osncmp(haystack+i,needle,strlen(needle))==0)
			return haystack+i;
		i++;
	}

	return NULL;
}

cToUpper(char *sPtr)
{
	while (*sPtr != '\0') {
		*sPtr = toupper(*sPtr);
		++sPtr;
	}


}

/* Given a string, replaces all instances of "oldpiece" with "newpiece". 
 * 
 * Modified this routine to eliminate recursion and to avoid infinite 
 * expansion of string when newpiece contains oldpiece. --Byron 
*/ 
char *replace(char *string, char *oldpiece, char *newpiece) 
{ 
   int str_index, newstr_index, oldpiece_index, end, 
      new_len, old_len, cpy_len; 
   char *c; 
   static char newstring[256]; 



   if ((c = (char *) strstr(string, oldpiece)) == NULL) 
      return string; 


   new_len = strlen(newpiece); 
   old_len = strlen(oldpiece); 
   end = strlen(string) - old_len; 
   oldpiece_index = c - string; 


   newstr_index = 0; 
   str_index = 0; 
   while(str_index <= end && c != NULL) 
   { 
      /* Copy characters from the left of matched pattern occurence */ 
      cpy_len = oldpiece_index-str_index; 
      strncpy(newstring+newstr_index, string+str_index, cpy_len); 
      newstr_index += cpy_len; 
      str_index += cpy_len; 


      /* Copy replacement characters instead of matched pattern */ 
      strcpy(newstring+newstr_index, newpiece); 
      newstr_index += new_len; 
      str_index += old_len; 


      /* Check for another pattern match */ 
      if((c = (char *) strstr(string+str_index, oldpiece)) != NULL) 
         oldpiece_index = c - string; 
   } 
   /* Copy remaining characters from the right of last matched pattern */ 
   strcpy(newstring+newstr_index, string+str_index); 


   return newstring; 
} 

void BangChangeLine(HWND caller, LPCTSTR args) {

	FILE *f, *sr;
	char tmpline[256];
	char line[256];
	_TCHAR source[1024];
	char target[256];
	char szToken1[256];
	char szToken2[256];
	char szToken3[256];
	char szToken4[256];
	char tempBuf[256];
	char *loc;
	int mode = 0;
	int numTokens = 0;
	
	LPTSTR rgszTokens[4];
	
	rgszTokens[0] = szToken1;
	rgszTokens[1] = szToken2;		
	rgszTokens[2] = szToken3;
	rgszTokens[3] = szToken4;
	
	numTokens = CommandTokenize(args, rgszTokens, 4, NULL );
	
	if (numTokens == 4) {
		VarExpansion(source, szToken4);
		sr = fopen(source, "r");
	} else {
		strcpy(source, szLitestepPath);
		strcat(source, "\\step.rc");
		sr = fopen(source, "r");
	}

	if(numTokens >= 3) {

		
		if (_stricmp(szToken3,"substring") == 0) {
			mode = 1;
		}


		if (_stricmp(szToken3, "force") == 0) {
			mode = 2;
		}

		strcpy(target, szLitestepPath);
		strcat(target, "\\temp.rc");
		f = fopen(target, "w");

		while (fgets(line,256,sr) != NULL) {
			strcpy(tmpline,line);
			cToUpper(tmpline);
			if (osstr(tmpline, "!CHANGELINE") == NULL) {
				if (mode == 1) {
					if (osstr(line, szToken1) != NULL) {
						fprintf(f,"%s",replace(line, szToken1, szToken2));
					} else {
						fprintf(f, "%s", line);
					}
				} else {
					if (osncmp(line,szToken1,strlen(szToken1)) == 0) {
						if (mode == 2) {
							mode = 0;
						}
						/*Strip comments if needed*/
						if (strlen(line) > strlen(szToken1)){
							strcpy(tempBuf,line);
							loc = strchr(tempBuf,';');
							if (loc != NULL){
								strcat(szToken2," ");
								strcat(szToken2,loc);
								fprintf(f,"%s",szToken2);
							} else {
								fprintf(f,"%s\n",szToken2);
							}
						} else {
							fprintf(f,"%s",szToken2);
						}
					} else {
						fprintf(f, "%s", line);
					}	
				}
			} else {
				fprintf(f, "%s", line);
			}
		}

		fclose(f);
		fclose(sr);
		
		CopyFile(target, source, 0);
		DeleteFile(target);
	}
}


int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd) {
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath) {

	int Msgs[10];
	strcpy(szLitestepPath, szPath);

	parent = ParentWnd;
	{
		WNDCLASS wc;
		memset(&wc, 0, sizeof(wc));
		wc.lpfnWndProc = WndProc;
		wc.hInstance = dllInst;
		wc.lpszClassName = szAppName;
		wc.style = 0;

		if (!RegisterClass(&wc)) {
			MessageBox(hMainWnd, "Error registering window class", szAppName, MB_OK);
			return 1;
		}
	}
	hMainWnd = CreateWindowEx(WS_EX_TOOLWINDOW,szAppName,szAppName,WS_CHILD,0,0,0,0,parent,NULL,dllInst,NULL);

	Msgs[0] = LM_GETREVID;
	Msgs[1] = 0;
	SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);

	AddBangCommand(_TEXT("!CHANGELINE"), BangChangeLine);
	return 0;
}

void quitModule(HINSTANCE dllInst) {
	RemoveBangCommand("!CHANGELINE");
	DestroyWindow(hMainWnd);
	UnregisterClass(szAppName, dllInst);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {

	switch (message) {
		case LM_GETREVID: {
			char *buf = (char *) lParam;

			if (wParam == 0) {
				strcpy(buf, "change.dll (Two_tone): ");
				strcat(buf, &rcsRevision[11]);
				buf[strlen(buf)-1] = '\0';
			}
			else if (wParam == 1) {
				strcpy(buf, &rcsId[1]);
				buf[strlen(buf)-1] = '\0';
			} else {
				strcpy(buf, "");
			}
			return strlen(buf);
		}
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}