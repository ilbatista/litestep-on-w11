// stdafx.h : Includedatei f�r Standardsystem-Includedateien,
// oder projektspezifische Includedateien, die h�ufig benutzt, aber
// in unregelm��igen Abst�nden ge�ndert werden.
//

#pragma once


#define WIN32_LEAN_AND_MEAN		// Selten verwendete Teile der Windows-Header nicht einbinden
// Windows-Headerdateien:
#include <windows.h>
#include <objbase.h>	// CoInitialize(), CoUninitialize()
#include <litestep/lsapi/lsapi.h>

// TODO: Verweisen Sie hier auf zus�tzliche Header, die Ihr Programm erfordert
