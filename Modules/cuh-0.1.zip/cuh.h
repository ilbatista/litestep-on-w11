#if !defined(_CUH_H_INCLUDED_)
#define _CUH_H_INCLUDED_

extern "C" {
	__declspec(dllexport) int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);
	__declspec(dllexport) int quitModule(HINSTANCE dllInst);
}

// Shorten (and idiot-proof) declarations.
typedef void(BANGPROC)(HWND, LPCSTR);
typedef BANGPROC *PFNBANGPROC;

// Bang functions.
BANGPROC BangLockWS;
BANGPROC BangWA5OnlyPause;

struct BANGLIST
{
	LPCSTR sName;
	PFNBANGPROC pfnBang;
};

BANGLIST BangList[];

#endif // _CUH_H_INCLUDED_
