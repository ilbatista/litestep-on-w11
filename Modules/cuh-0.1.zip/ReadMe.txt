cuh-0.1: Add some useful bangs
Copyright (C) 2004 Christian Ullrich <chris@chrullrich.de>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


Notes
=====

- This is my first module. I wouldn't be surprised if 
  it crashed on any system but mine. Please tell me
  how to improve the binary compatibility.
  
- I wrote the bangs just because I couldn't find them
  anywhere else. If you know where I can find them,
  please tell me, so I can retire my own module.

- Please tell me about all the mistakes I have made 
  regarding the lsapi interface (module initialization
  and unloading). I just looked at popup2 and copied
  what appeared to be required.


Instructions for use
====================

There are currently two bangs in this module:

!LockWS

	Locks the workstation. No questions asked, no
	parameters supported.

!Amp5_OnlyPause

	Puts Winamp 5 into pause state, if it's currently
	playing. If it is not playing, nothing happens.
	If it isn't even running, nothing happens either.


The main use for this module, and the reason I wrote
it in the first place, is this:

*Script bang !PauseAndLock
*Script exec |Amp5_OnlyPause
*Script exec |LockWS
*Script ~bang

(For mzscript, from the Hussain installer.)

