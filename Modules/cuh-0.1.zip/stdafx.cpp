// stdafx.cpp : Quelltextdatei, die nur die Standard-Includes einbindet
// cuh.pch ist der vorcompilierte Header
// stdafx.obj enth�lt die vorcompilierte Typinformation

#include "stdafx.h"

// TODO: Verweisen Sie auf zus�tzliche Header, die in STDAFX.H 
// und nicht in dieser Datei erforderlich sind.
