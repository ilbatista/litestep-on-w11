#include "stdafx.h"
#include "cuh.h"

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	CoInitialize(NULL);

	BANGLIST *pBang = BangList;
	while (pBang->sName)
	{
		AddBangCommand(pBang->sName, pBang->pfnBang);
		++pBang;
	}

	return 0;
}

int quitModule(HINSTANCE dllInst)
{
	BANGLIST *pBang = BangList;
	while (pBang->sName)
	{
		RemoveBangCommand(pBang->sName);
		++pBang;
	}
	
	CoUninitialize();

	return 1;
}

// Lifted from Popup2. chris.
// Dummy startup routine that does almost nothing.
// This cuts out all of the standard startup code crud that
// bloats the DLL, and makes it take longer to load
BOOL __stdcall _DllMainCRTStartup(HINSTANCE hInst, DWORD fdwReason, LPVOID lpvRes)
{
	// We don't need thread notifications for what we're doing.  Thus, get
	// rid of them, thereby eliminating some of the overhead of this DLL
	DisableThreadLibraryCalls(hInst);

	return TRUE;
}
