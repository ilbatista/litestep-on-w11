#include "stdafx.h"
#include "cuh.h"

BANGLIST BangList[] = {
	{ "!LockWS",					BangLockWS },
	{ "!Amp5_OnlyPause",	BangWA5OnlyPause },
	{ NULL, NULL }
};

// Lock the workstation (or attempt to). The function
// LockWorkStation() is available only from 2000 on, so
// in order to allow the DLL to load on earlier systems 
// (if it ever come to that), it's late-bound. The bang
// won't work, of course.
void BangLockWS(HWND hCaller, LPCSTR pszArgs)
{
		typedef BOOL (*LPFNLOCKWORKSTATION) (void);

		HMODULE hUser32 = LoadLibrary("user32");
		if (hUser32 != NULL)
		{
			LPFNLOCKWORKSTATION pLWS = 
				(LPFNLOCKWORKSTATION)GetProcAddress(hUser32, 
				"LockWorkStation");

			if (pLWS != NULL)
				(*pLWS)();
		}
}

// Definitions from wa_ipc.h from the 5.02 SDK.
#define WM_WA_IPC				WM_USER
#define IPC_ISPLAYING		104
#define WINAMP_BUTTON3	40046

// Make Winamp 5 pause playback. All existing solutions 
// toggle between play and pause states, probably because
// the Winamp IPC mechanism isn't thought out very well
// in that regard (it's only possible to "push" the pause
// button, but as we know, that'll toggle).
void BangWA5OnlyPause(HWND hCaller, LPCSTR pszArgs)
{
	// That seems to be the proper class name. 
	// It isn't documented anywhere I thought to look, though.
	HWND hWnd = FindWindow("Winamp v1.x", NULL);

	// Inquire as to the playback state. A return value
	// of 1 means "unpaused playback in progress."
	LRESULT l = SendMessage(hWnd, WM_WA_IPC, 0, IPC_ISPLAYING);

	if (l == 1)
		PostMessage(hWnd, WM_COMMAND, WINAMP_BUTTON3, 0);
}
