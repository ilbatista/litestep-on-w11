/*

This is a part of the LiteStep Shell Source code.
  
Copyright (C) 1997-98 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
		
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
		  
*/

/****************************************************************************
12/10/00 - TrOgI
	Fixed autohide from closing when in a folder/subfolder
12/02/00 - TrOgI
	More recoding.......multiple subfolders are now possible
11/30/00 - TrOgI
	Fixed bang commands to support multiple wharves
11/29/00 - TrOgI
	Added wharfFolderType class and window procedure
	Added code to allow multiple wharfs
	Added code back in for wharf position in modules.ini for compatibility with old themes
	Wharf position set in step.rc takes presidence over modules.ini
	Fixed bug in !WharfMove and !WharfMoveTo that caused only diagonal movement (thanks to xnowfall for pointing this out)
11/10/00 - TrOgI
	Lots of recoding........smaller dll size
	Folder tiles now press like the main wharf tiles.
11/08/00 - TrOgI
	Added wharfHiddenType class
	Moved hidden window creation into wharfHiddenType class
11/06/00 - TrOgI
	Added wharfType class
	Moved wharf creation into wharfType class
	Added Tile Window Procedure
09/26/00 - TrOgI
	Moved wharf tile creation and execution into wharfTileType class
	Changed wharf shade/unshade to right click on wharfcap instead of left click
	Added width and height to WharfData structure so wharf modules know what size tile they are in.
09/23/00 - TrOgI
	Added WharfX and WharfY settings
	Wharf gets its position from step.rc now instead of modules.ini
09/18/00 - TrOgI
	Added bang commands !WharfToggle, !WharfMove, !WharfMoveTo
	Added WharfStartHidden setting
09/09/00 - TrOgI
	Added ability to set the tile size for each folder
09/08/00 - TrOgI
	Fixed the move on resolution change to work with WharfHorizontal
	Added ability to set the folder direction to the same as the wharf with WharfFolderWharfDirection setting
	Added bang commands !WharfShow and !WharfHide
09/06/00 - TrOgI
	Fixed the wharf autohide feature to work correctly in horizontal mode
	Added WharfTileWidth and WharfTileHeight settings to use for any size tiles
09/04/00 - TrOgI
	Added ability to set wharf horizontal with WharfHorizontal setting
	Changed some width and height variables to make different size tiles easier to code later
08/26/00 - Joachim Calvert (NeXTer)
  - Added the setting WharfAlwaysOnTop
08/25/00 - Charles Oliver Nutter (Headius)
	Rewrote the wharf types to be classes, subwharfType extends wharfType
	Moved painting code into wharf type classes
	Restructured paint handling to call class methods
	Fixed the immovable wharf bug
	Fixed (re-implemented) the right-click popup
07/21/00 - Bobby G. Vinyard (Message)
	Add LM_REGISTER/UNREGISTER message handler. (Using LSWinbase, hParent was 
    being set to the hwnd of the wharf and not LiteStep its self, therefore
    the LM_REGISTER msgs were being sent to the wharf, the wharf no fowards
    these msgs to LiteStep's main exe)
04/16/00 - Joachim Calvert (NeXTer)
	Fixed a bug where the wharf wouldn't hide properly when the following
	settings where used:
    AutoHideWharf
    WharfCloseOnSwitch
    ;WharfNoAnim  (swithed off)
	(Courtesy of Sergey Popov)
	The message handling was radically overhauled to prepare the code for
	a convertion to proper C++ style.
04/12/00 - Joachim Calvert (NeXTer)
	It moves itself on resolution changes.
04/06/00 - Joachim Calvert (NeXTer)
	Now notices changes in screen resolution.
01/17/00 - Charles Nutter (Headius)
	Fixes to remove dependency on the great winList array.
	Note: Not thread-safe yet.
11/16/98 - Bug*Killer added by Fahim
	Added facility for popup menu to open when right clicked on wharf
	Divided the title bar in two parts : drag the left one to move the
	bar, click on the right one to shade/unshade the bar. When the wharf
	bar is not shaded, a double click on the left part puts it in shaded
	mode & then moves it to a special position :
	ScreenWidth - "WharfDblClickXPosition",0. When the wharf bar is
	shaded, a double click on the left part unshades the bar, then docks
	it on the right, or on the left if the "WharfDblClickDockOnLeft"
	step.rc entry is specified.
11/15/98 - cael
	Added checks in SetWorkArea() to not change the work area if
	SetDesktopArea is true
11/03/98 - W. Konkel
	Added the better wharf movement as well as sound to !WharfTasks
11/02/98 - W. Konkel
	Added wharf open/close/min/max sounds (with the help/request
	of snowchyld)
11/01/98 - T. Engel
	Added back WharfTitleFont, WharfTitleFontSize, and a new
	option WharfTitleFontWeight
11/01/98 - W. Konkel
	Added better wharf movement (fixed a few small bugs)
	Made WharfCloseOnSwitch work much much better
10/31/98 - Cyberian
	Fixed crashing on recycle when WharfCloseOnSwitch is enabled
10/29/98 - Cyberian (Fahim Farook)
	Added WharfCloseOnSwitch to step.rc so that you can have the
	subwharf folders auto-close when focus is lost if you desire
	Added support for wharf hints
10/10/98 - W. Konkel
	Added snap-to-edge wharf and the ability to not include the
	default.bmp and 3dots.bmp in wharf layer.
10/09/98 - C. Boyda
	Made the trans titlebar much more efficent in speed
10/03/98 - J. Vaughn
	Added fully functional, working transparency to the wharf
	titlebar (why was it left out to begin with?? :P)
09/03/98 - C. Boyda
	Added fully functional, working transparency to the wharf
	D. Hodgkiss
	Folders support is now in
08/31/98 - D. Hodgkiss
	Added ability to move the wharf anywhere on the screen
	Added a titlebar to the wharf
	Added hide/unhide support
08/25/98 - D. Hodgkiss
	This file contains the source for the wharf bar

****************************************************************************/

#include <windows.h>
#include <mmsystem.h>
#include <malloc.h>
#include <stdio.h>
#include <tchar.h>
#include <commctrl.h>
#include "../lsapi/lswinbase.h"
#include "../lsapi/lsapi.h"
#include "wharf.h"
#include "../core/ifcs.h"

// -------------------------------------------------------------------------------------------------------

const LPCTSTR   szMainWindowClass = _T("TWharfGlobalContainer");
const LPCTSTR   szHiddenWindowClass = _T("LineDownSide");
const LPCTSTR   szTileWindowClass = _T("TileContainer");
const LPCTSTR   szFolderWindowClass = _T("FolderContainer");
const char rcsRevision[] = "$Revision: 0.4 $"; // Our Version
const char rcsId[] = "$Id: wharfx.cpp,v 0.4 2000/09/06 22:40:32 TrOgI Exp $"; // The Full RCS ID.

FARPROC (__stdcall *SwitchToThisWindow)(HWND, int);

// our window procedures
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK HiddenWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK TileWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK FolderWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// -------------------------------------------------------------------------------------------------------

void GetWharfData(wharfDataType *wd, int width, int height);
void ReadConfig(void);
void ShowWharf(HWND sender, LPCSTR args);
void HideWharf(HWND sender, LPCSTR args);
void ToggleWharf(HWND sender, LPCSTR args);
void MoveWharf(HWND sender, LPCSTR args);
void MoveWharfTo(HWND sender, LPCSTR args);
void CreateWharfhints(HWND hWnd, char *txt, RECT *r);
void RemoveWharfhints(HWND hWnd);
void SoundOpen(void);
void SoundClose(void);
void SoundMin(void);
void SoundMax(void);

char szLitestepPath[256];
char lsPath[256];
char wharfOpenSound[256];
char wharfCloseSound[256];
char wharfMinSound[256];
char wharfMaxSound[256];

char szImagePath[256];
char szDefPixmap[256];
char szFolderPixmap[256];
HBITMAP titlebarImage = NULL;
HBITMAP defaultBackImage = NULL;
HBITMAP folderImage = NULL;
HBITMAP defaultFolderImage = NULL;
HINSTANCE dll;
HWND hParent;
HWND wharfHints = NULL;
int ScreenWidth, ScreenHeight;
WharfVector MainWharf;
int numMainWharfs = 0;
int wharfDblClickXPosition = 120;
int wharfDblClickYPosition = 120;
BOOL wharfDblClickDockOnLeft = FALSE;
int wharfAnimTime;
int wharfStep = 64;
int autoHideDelay = 300;
int autoShowDelay = 300;
int hiddenWidth = 1;
int OpenFolders = 0;
int wharfPressOffset = 1;
BOOL wharfAlwaysOnTop = TRUE;
BOOL wharfTitlebar = TRUE;
BOOL wharfEndCap = FALSE;
BOOL wharfNoAnim = FALSE;
BOOL wharfAutoClose = TRUE;
BOOL wharfTitles = FALSE;
BOOL wharfCloseOnSwitch = FALSE;
BOOL snapTo = FALSE;
BOOL wharfAutoHide = FALSE;
BOOL wharfStartHidden = FALSE;
BOOL wharfAutoUnpress = FALSE;
BOOL wharfNoHints = TRUE;
int snapToSensitivity = 16;
int bevelWidth;
int capHeight = 0;
COLORREF titleFore, titleBack;
char szTitleFont[256] = "Arial";
int iTitleFontSize = 8, iTitleFontWeight = 400;
BOOL setDesktopArea = TRUE;
int wharfDirection = WHARF_DOWN;
int wharfFolderDirection = WHARF_RIGHT;

// -------------------------------------------------------------------------------------------------------
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	RECT r;
	int i;
	char szBuf[256], *tmp;
	HWND desktop;
	int wharfBaseX = 0, wharfBaseY = 0;
	int wharfWidth = 0, wharfHeight = 0;
	int wharfTileWidth, wharfTileHeight;
	
	dll = dllInst;

	AddBangCommand("!WharfShow", ShowWharf);
	AddBangCommand("!WharfHide", HideWharf);
	AddBangCommand("!WharfToggle", ToggleWharf);
	AddBangCommand("!WharfMove", MoveWharf);
	AddBangCommand("!WharfMoveTo", MoveWharfTo);
	
	GetClientRect(GetDesktopWindow(),&r);
	ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
	ScreenHeight = GetSystemMetrics(SM_CYSCREEN);

	hParent = GetLitestepWnd();

	strcpy(szLitestepPath, szPath);
	ReadConfig();

	sprintf(szBuf, "%s\\MODULES.INI", szLitestepPath);
	GetPrivateProfileString("Wharf", "Position", "-64,0", (char *)&szBuf, sizeof(szBuf), szBuf);
	tmp = strtok(szBuf, ",");
	wharfBaseX = atoi(tmp);
	tmp = strtok(NULL, "");
	wharfBaseY = atoi(tmp);

	if(GetRCBool("WharfHorizontal", TRUE))
	{
		wharfDirection = WHARF_RIGHT;
		wharfFolderDirection = WHARF_DOWN;
	}
	if(GetRCBool("WharfFolderWharfDirection", TRUE))
		wharfFolderDirection = wharfDirection;
	wharfTileWidth = GetRCInt("WharfTileWidth", 64);
	wharfTileHeight = GetRCInt("WharfTileHeight", 64);
	wharfBaseX = GetRCInt("WharfX", wharfBaseX);
	wharfBaseY = GetRCInt("WharfY", wharfBaseY);
	if(wharfBaseX < 0)
		wharfBaseX += ScreenWidth;
	if(wharfBaseY < 0)
		wharfBaseY += ScreenHeight;

	if(!wharfNoHints)
	{
		wharfHints = CreateWindow
			(TOOLTIPS_CLASS,
			"LSWharfHints",
			TTS_ALWAYSTIP,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			NULL,
			(HMENU) NULL,
			dll,
			NULL
			);

		if(!wharfHints)
		{
			MessageBox(hParent, "Error creating hints window", "Wharf Hints Error", MB_OK | MB_TOPMOST);
			return 1;
		}
		SetWindowPos(wharfHints, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
	}
	
	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = MainWndProc;				  // our window procedure
		wc.hInstance = dllInst; 				// hInstance of DLL
		wc.cbWndExtra = 8;
		wc.lpszClassName = szMainWindowClass;	   // our window class name
		wc.style = CS_DBLCLKS;

		if(!RegisterClass(&wc)) 
		{
			MessageBox(hParent,"Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
			return 1;
		}
		
		if(wharfAutoHide)
		{
			WNDCLASS wc;
			memset(&wc,0,sizeof(wc));
			wc.lpfnWndProc = HiddenWndProc;				  // our window procedure
			wc.hInstance = dllInst; 				// hInstance of DLL
			wc.cbWndExtra = 8;
			wc.lpszClassName = szHiddenWindowClass;	   // our window class name
			wc.style = 0;
			
			if(!RegisterClass(&wc)) 
			{
				MessageBox(hParent,"Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
				return 1;
			}
		}	
	}

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = TileWndProc;				  // our window procedure
		wc.hInstance = dllInst; 				// hInstance of DLL
		wc.cbWndExtra = 8;
		wc.lpszClassName = szTileWindowClass;	   // our window class name
		wc.style = CS_DBLCLKS;

		if(!RegisterClass(&wc)) 
		{
			MessageBox(hParent,"Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
			return 1;
		}	
	}

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = FolderWndProc;				  // our window procedure
		wc.hInstance = dllInst; 				// hInstance of DLL
		wc.cbWndExtra = 8;
		wc.lpszClassName = szFolderWindowClass;	   // our window class name
		wc.style = CS_DBLCLKS;

		if(!RegisterClass(&wc)) 
		{
			MessageBox(hParent,"Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
			return 1;
		}	
	}

	desktop = FindWindow("DesktopBackgroundClass", NULL);
	if(!desktop)
		desktop = GetDesktopWindow();

	if(!wharfTitlebar)
		capHeight = 0;

	SwitchToThisWindow = (FARPROC (__stdcall *)(HWND, int))GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");
	
	{
		FILE *f;
		UINT Msgs[2];

		f = LCOpen (NULL);
		if(f)
		{
			MainWharf.push_back(new wharfType(desktop, "LSWharf", wharfBaseX, wharfBaseY, wharfTileWidth, wharfTileHeight, wharfDirection));
			MainWharf[numMainWharfs]->Create(f);

			Msgs[0] = LM_GETREVID;
			Msgs[1] = 0;
			SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM) MainWharf[0]->hMainWnd, (LPARAM) Msgs);

			LCClose(f);
		}
	}
	return 0;
}


// -------------------------------------------------------------------------------------------------------

void OnEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void OnSysCommand(HWND hWnd, Message& message)
{
	if(message.wParam == SC_CLOSE)
		PostMessage(hParent,WM_KEYDOWN,LM_SHUTDOWN,0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

LRESULT CALLBACK HiddenWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;
	wharfHiddenType *pHidden = (wharfHiddenType *)GetWindowLong(hWnd, 4);

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch(uMsg)
	{
    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
		OnEndSession(message);
		break;
    case WM_SYSCOMMAND:
		OnSysCommand(hWnd, message);
		break;
    case WM_DISPLAYCHANGE:
		pHidden->OnDisplayChange(message);
		break;
    case WM_PAINT:
		pHidden->OnPaint(message);
		break;
    case WM_TIMER:
		pHidden->OnTimer(message);
		break;
    default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}

void MainWnd_GetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch(message.wParam)
	{
    case 0:
		strcpy(buf, "wharfx.dll: ");
		strcat(buf, &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
    case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
    default:
		strcpy(buf, "");
	}
}

void MainWnd_Recycle(Message& message)
{
	SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void MainWnd_NCRButtonDown(HWND hWnd, Message& message)
{
	SendMessage(hWnd, LM_SHADETOGGLE, 0, 0);
}

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;
	wharfType *pWharf = (wharfType *)GetWindowLong(hWnd, 4);

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch(uMsg)
	{
    case LM_GETREVID:
		MainWnd_GetRevId(message);
		break;
    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
		OnEndSession(message);
		break;
    case WM_SYSCOMMAND:
		OnSysCommand(hWnd, message);
		break;
    case LM_RECYCLE:
		MainWnd_Recycle(message);
		break;
    case LM_SHADETOGGLE:
		pWharf->OnShadeToggle(message);
		break;
    case WM_TIMER:
		pWharf->OnTimer(message);
		break;
    case WM_NCRBUTTONDOWN:
		MainWnd_NCRButtonDown(hWnd, message);
		break;
    case WM_NCLBUTTONDBLCLK:
		pWharf->OnNCLButtonDblClick(message);
		break;
    case WM_WINDOWPOSCHANGING:
		pWharf->OnPosChanging(message);
		break;
    case WM_NCHITTEST:
		pWharf->OnNCHitTest(message);
		break;
	case WM_WINDOWPOSCHANGED:
		pWharf->OnMove(message);
		break;
    case WM_CREATE:
		break;
    case WM_ERASEBKGND:
		break;
    case WM_DISPLAYCHANGE:
		pWharf->OnDisplayChange(message);
		break;
    case WM_PAINT:
		pWharf->OnPaint(message);
		break;
    case WM_ACTIVATE:
		pWharf->OnActivate(message);
		break;
    case LM_REGISTERMESSAGE:
    case LM_UNREGISTERMESSAGE:
		SendMessage(GetLitestepWnd(), uMsg, wParam, lParam);
		break;
	case WHARF_CLOSEFOLDERS:
		pWharf->CloseAllFolders();
    default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}

LRESULT CALLBACK TileWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;
	wharfTileType *pTile = (wharfTileType *)GetWindowLong(hWnd, 4);

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch(uMsg)
	{
    case WM_TIMER:
		pTile->OnTimer(message);
		break;
    case WM_CREATE:
		break;
    case WM_ERASEBKGND:
		break;
    case WM_PAINT:
		pTile->OnPaint(message);
		break;
    case WM_LBUTTONDOWN:
		pTile->OnLButtonDown(message);
		break;
    case WM_LBUTTONUP:
		pTile->OnLButtonUp(message);
		break;
    case WM_MOUSEMOVE:
		pTile->OnMouseMove(message);
		break;
	case WM_RBUTTONDOWN:
		SendMessage(GetLitestepWnd(), LM_POPUP, 0, 0);
		break;
    default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}

LRESULT CALLBACK FolderWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;
	wharfFolderType *pFolder = (wharfFolderType *)GetWindowLong(hWnd, 4);

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch(uMsg)
	{
    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
		OnEndSession(message);
		break;
    case WM_SYSCOMMAND:
		OnSysCommand(hWnd, message);
		break;
    case WM_TIMER:
		pFolder->OnTimer(message);
		break;
    case WM_CREATE:
		break;
    case WM_ERASEBKGND:
		break;
	case WM_ACTIVATE:
		pFolder->OnActivate(message);
    case LM_REGISTERMESSAGE:
    case LM_UNREGISTERMESSAGE:
		SendMessage(GetLitestepWnd(), uMsg, wParam, lParam);
		break;
	case WHARF_CLOSEFOLDERS:
		pFolder->CloseAllFolders();
    default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}

void ShowWharf(HWND sender, LPCSTR args)
{
	if(!strcmpi("", args))
	{
		MainWharf[0]->Show();
		return;
	}

	for(int i = 0; i <= numMainWharfs; i++)
	{
		if(!strcmpi("ALL", args) || !strcmpi(MainWharf[i]->szName, args))
			MainWharf[i]->Show();
	}
}

void HideWharf(HWND sender, LPCSTR args)
{
	if(!strcmpi("", args))
	{
		MainWharf[0]->Hide();
		return;
	}

	for(int i = 0; i <= numMainWharfs; i++)
	{
		if(!strcmpi("ALL", args) || !strcmpi(MainWharf[i]->szName, args))
			MainWharf[i]->Hide();
	}
}

void ToggleWharf(HWND sender, LPCSTR args)
{
	if(!strcmpi("", args))
	{
		if(!MainWharf[0]->visible)
			MainWharf[0]->Show();
		else
			MainWharf[0]->Hide();
		return;
	}

	for(int i = 0; i <= numMainWharfs; i++)
	{
		if(!strcmpi("ALL", args) || !strcmpi(MainWharf[i]->szName, args))
		{
			if(!MainWharf[i]->visible)
				MainWharf[i]->Show();
			else
				MainWharf[i]->Hide();
		}
	}
}

void MoveWharf(HWND sender, LPCSTR args)
{
	char *buf, *val1, *val2, *val3;

	buf = (char *)malloc(strlen(args)+1);
	strcpy(buf, args);
	val1 = strtok(buf, " \t");
	val2 = strtok(NULL, " \t");
	val3 = strtok(NULL, "");

	if(!val3)
	{
		MainWharf[0]->Move(val1, val2, FALSE);
		return;
	}

	for(int i = 0; i <= numMainWharfs; i++)
	{
		if(!strcmpi("ALL", val3) || !strcmpi(MainWharf[i]->szName, val3))
			MainWharf[i]->Move(val1, val2, FALSE);
	}

	free(buf);
}

void MoveWharfTo(HWND sender, LPCSTR args)
{
	char *buf, *val1, *val2, *val3;

	buf = (char *)malloc(strlen(args)+1);
	strcpy(buf, args);
	val1 = strtok(buf, " \t");
	val2 = strtok(NULL, " \t");
	val3 = strtok(NULL, "");

	if(!val3)
	{
		MainWharf[0]->Move(val1, val2, TRUE);
		return;
	}

	for(int i = 0; i <= numMainWharfs; i++)
	{
		if(!strcmpi("ALL", val3) || !strcmpi(MainWharf[i]->szName, val3))
			MainWharf[i]->Move(val1, val2, TRUE);
	}
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quitModule(HINSTANCE dllInst)
{
	UINT Msgs[2];
	RECT deskRect;

	Msgs[0] = LM_GETREVID;
	Msgs[1] = 0;
	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM) MainWharf[0]->hMainWnd, (LPARAM) Msgs);

	RemoveBangCommand("!WharfShow");
	RemoveBangCommand("!WharfHide");
	RemoveBangCommand("!WharfToggle");
	RemoveBangCommand("!WharfMove");
	RemoveBangCommand("!WharfMoveTo");
	
	if(!wharfNoHints)
	{
		if(wharfHints)
		{
			DestroyWindow(wharfHints);
			wharfHints = NULL;
		}
	}
	for(int i = 0; i <= numMainWharfs; i++)
	{
		delete MainWharf[i];
	}
	MainWharf.clear();
	
	if(defaultBackImage)
		DeleteObject(defaultBackImage);
	if(folderImage)
		DeleteObject(folderImage);
	if(defaultFolderImage)
		DeleteObject(defaultFolderImage);
	if(titlebarImage)
		DeleteObject(titlebarImage);
	
	// Reset the work area since we no longer have a docked wharf, or any wharf at all, hah!
	SystemParametersInfo(SPI_GETWORKAREA, 0, &deskRect, 0);
	deskRect.left = 0;
	deskRect.right = ScreenWidth;
	deskRect.top = 0;
	deskRect.bottom = ScreenHeight;
	SystemParametersInfo(SPI_SETWORKAREA, 0, &deskRect, 0);
	
	UnregisterClass(szTileWindowClass,dllInst); // unregister window class
	UnregisterClass(szMainWindowClass,dllInst); // unregister window class
	UnregisterClass(szFolderWindowClass,dllInst); // unregister window class
	if(wharfAutoHide)
		UnregisterClass(szHiddenWindowClass, dllInst);
}

void ReadConfig(void)
{
	char szToken[256];

	wharfEndCap = GetRCBool("WharfEndCap", TRUE);
	wharfStartHidden = GetRCBool("WharfStartHidden", TRUE);
	wharfAlwaysOnTop = GetRCBoolDef("WharfAlwaysOnTop", FALSE);
	setDesktopArea = GetRCBool("SetDesktopArea", TRUE);
	wharfAutoUnpress = GetRCBool("WharfAutoUnpress", TRUE);
	wharfAutoClose = GetRCBool("WharfNoAutoclose", FALSE);
	wharfTitlebar = GetRCBool("WharfNoTitleBar", FALSE);
	wharfNoAnim = GetRCBool("WharfNoAnim", TRUE);
	wharfTitles = GetRCBool("WharfAllTitles", TRUE);
	wharfDblClickXPosition = GetRCInt("WharfDblClickXPosition",120);
	wharfDblClickYPosition = GetRCInt("WharfDblClickYPosition",120);
	wharfDblClickDockOnLeft = GetRCBool("WharfDblClickDockOnLeft", TRUE);
	capHeight = GetRCInt("WharfCapHeight", 16);
	titleFore = GetRCColor("WharfTitleFore", 0xFFFFFF);
	titleBack = GetRCColor("WharfTitleBack", 0x802020);
	bevelWidth = GetRCInt("WharfBevelWidth", 1);
	if (bevelWidth < 0) bevelWidth = 0;
	wharfStep = GetRCInt("WharfAnimStep", 64);
	wharfAnimTime = GetRCInt("WharfAnimDelay", 10); 
	wharfAutoHide = GetRCBool("AutoHideWharf", TRUE);
	autoHideDelay = GetRCInt("AutoHideDelay", 300);
	autoShowDelay = GetRCInt("AutoShowDelay", autoHideDelay);
	hiddenWidth = GetRCInt("WharfHiddenWidth", 1);
	wharfPressOffset = GetRCInt("WharfPressOffset", 1);
	wharfNoHints = GetRCBool("WharfNoHints", TRUE);
	wharfCloseOnSwitch = GetRCBool("WharfCloseOnSwitch", TRUE);
	GetRCString("WharfOpenSound", wharfOpenSound, "c:\\blah.wav", 256);
	GetRCString("WharfCloseSound", wharfCloseSound, "c:\\blah.wav", 256);
	GetRCString("WharfMinSound", wharfMinSound, "c:\\blah.wav", 256);
	GetRCString("WharfMaxSound", wharfMaxSound, "c:\\blah.wav", 256);
	
	
	snapTo = GetRCBool("SnapToWharf", TRUE);
	snapToSensitivity = GetRCInt("SnapToSensitivity", 16);
	
	LSGetImagePath( szImagePath, 256 );
	
	if(GetRCString("DefaultBackPix", szDefPixmap, "", 256))
	{
		defaultBackImage = LoadLSImage (szDefPixmap, NULL);
	}
	
	if(GetRCString("FolderBackPix", szFolderPixmap, "", 256))
	{
		defaultFolderImage = LoadLSImage (szFolderPixmap, NULL);
	}
	
	if(GetRCString("FolderPix", szToken, "", 256))
	{
		folderImage = LoadLSImage (szToken, NULL);
	}
	
	if(GetRCString("WharfTitlebarPix", szToken, "", 256))
	{
		titlebarImage = LoadLSImage (szToken, NULL);
	}

	GetRCString("WharfTitleFont", szTitleFont, "Arial", 256);
	iTitleFontSize = GetRCInt("WharfTitleFontSize", 8);
	iTitleFontWeight = GetRCInt("WharfTitleFontWeight", 400);
}

void GetWharfData(wharfDataType *wd, int width, int height)
{
	strcpy(lsPath, szLitestepPath);
	if(lsPath[strlen(lsPath)] != '\\')
		strcat(lsPath, "\\");
	
	wd->trayIconSize = GetRCInt("TrayIconSize", 16);
	wd->taskBarFore = GetRCColor("LSTaskBarFore", 0x000000);
	wd->taskBarBack = GetRCColor("LSTaskBarBack", 0x7f7f7f);
	wd->taskBarText = GetRCColor("LSTaskBarText", 0xffffff);
	wd->taskBarFore2 = GetRCColor("LSTaskBarFore2", 0x3f3f3f3f);
	wd->taskBar = GetRCBool("NoTaskBar", FALSE);
	wd->showBeta = GetRCBool("NoShowBeta", TRUE);;
	wd->usClock = GetRCBool("UsClock", TRUE);
	wd->vwmVelocity = GetRCInt("VWMVelocity", 300);
	wd->VWMDistance = GetRCInt("VWMSecurityDistance", 5);
	wd->VWMNoAuto = GetRCBool("VWMNoAuto", TRUE);
	wd->pixmapDir = szImagePath;
	wd->defaultBmp = szDefPixmap;
	wd->vwmBackColor = GetRCColor("VWMBackColor", 0x000000);
	wd->vwmSelBackColor = GetRCColor("VWMSelBackColor", 0x3f3f3f);
	wd->vwmForeColor = GetRCColor("VWMForeColor", 0x906090);
	wd->vwmBorderColor = GetRCColor("VWMBorderColor", 0xffffff);
	wd->lsPath = lsPath;
	wd->borderSize = bevelWidth;
	wd->width = width;
	wd->height = height;
}

void SoundOpen(void)
{
	sndPlaySound(wharfOpenSound, SND_ASYNC|SND_NODEFAULT);
}

void SoundClose(void)
{	
	sndPlaySound(wharfCloseSound, SND_ASYNC|SND_NODEFAULT);
}

void SoundMin(void)
{
	sndPlaySound(wharfMinSound, SND_ASYNC|SND_NODEFAULT);
}

void SoundMax(void)
{	
	sndPlaySound(wharfMaxSound, SND_ASYNC|SND_NODEFAULT);
}
/*
void ExecuteWharfTasks(int i)
{
	IWindowList *windowList;
	char capt[256];
	int xPos, yPos;
	int n, q, x;
	
	if (MainWharf[0]->closing) {
		CloseAllFolders();
		return;
	}
	
	
	if (wharfAutoClose) {
		for (q = 0; q < numWharfs; q++)
		{
			if ((MainWharf[0]->wharfs[q]->open || MainWharf[0]->wharfs[q]->moving) && q != i)
			{
				MainWharf[0]->wharfs[q]->bPressed = FALSE;
				MainWharf[0]->wharfs[q]->TogglePressOffset(FALSE);
				if (wharfNoAnim)
				{
					SetWindowPos(MainWharf[0]->wharfs[q]->folder->hMainWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
				} else {
					MainWharf[0]->wharfs[q]->moving = TRUE;
					MainWharf[0]->wharfs[q]->closing = TRUE;
					//wharfs[q]->movingPos = wharfs[q]->folder->numWharfs*64;
					SetTimer(MainWharf[0]->wharfs[q]->folder->hMainWnd, 3, wharfAnimTime, NULL);
				}
				MainWharf[0]->wharfs[q]->open = FALSE;
				OpenFolders--;
			}
		}
	}
	
	if (MainWharf[0]->wharfs[i]->moving) {
		if (MainWharf[0]->wharfs[i]->closing) {
			MainWharf[0]->wharfs[i]->closing = FALSE;
			if (wharfOpenSound) SoundOpen();
		}
		else {
			MainWharf[0]->wharfs[i]->closing = TRUE;
			if (wharfCloseSound) SoundClose();
		}
	} else if (MainWharf[0]->wharfs[i]->open) {
		if (wharfCloseSound) SoundClose();
		if (wharfNoAnim)
		{
			MainWharf[0]->wharfs[i]->open = FALSE;
			MainWharf[0]->wharfs[i]->bPressed = FALSE;
			MainWharf[0]->wharfs[i]->TogglePressOffset(FALSE);
			SetWindowPos(MainWharf[0]->wharfs[i]->folder->hMainWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
		} else {
			MainWharf[0]->wharfs[i]->moving = TRUE;
			MainWharf[0]->wharfs[i]->closing = TRUE;
			SetTimer(MainWharf[0]->wharfs[i]->folder->hMainWnd, 3, wharfAnimTime, NULL);
			OpenFolders--;
		}
	} else {
		if (MainWharf[0]->wharfs[i]->folder->wharfs.size())
		{
			for (x = 0; x < MainWharf[0]->wharfs[i]->folder->numWharfs; x++)
			{
				DeleteObject(MainWharf[0]->wharfs[i]->folder->wharfs[x]->backImage);
				DeleteObject(MainWharf[0]->wharfs[i]->folder->wharfs[x]->frontImage);
				DestroyWindow(MainWharf[0]->wharfs[i]->folder->wharfs[x]->hWnd);
				delete MainWharf[0]->wharfs[i]->folder->wharfs[x];
			}
			DestroyWindow(MainWharf[0]->wharfs[i]->folder->hMainWnd);
			MainWharf[0]->wharfs[i]->folder->wharfs.clear();
		}

		if(MainWharf[0]->wharfs[i]->folderDirection == WHARF_RIGHT)
		{
			MainWharf[0]->wharfs[i]->folder->width = 0;
			MainWharf[0]->wharfs[i]->folder->height = MainWharf[0]->wharfs[i]->folder->tileHeight;
		}
		else if(MainWharf[0]->wharfs[i]->folderDirection == WHARF_DOWN)
		{
			MainWharf[0]->wharfs[i]->folder->width = MainWharf[0]->wharfs[i]->folder->tileWidth;
			MainWharf[0]->wharfs[i]->folder->height = 0;
		}
		
		MainWharf[0]->wharfs[i]->folder->wharfs.clear();
		MainWharf[0]->wharfs[i]->folder->numWharfs = 0;
		MainWharf[0]->wharfs[i]->open = FALSE;
		MainWharf[0]->wharfs[i]->folder->hMainWnd = CreateWindowEx(
			WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
			szMainWindowClass,
			"LSWharflet",
			WS_CLIPCHILDREN | WS_POPUP,
			0, 0,
			0, 0,
			hParent,
			NULL,
			dll,
			NULL
			);
		
		SetWindowLong(MainWharf[0]->wharfs[i]->folder->hMainWnd, GWL_USERDATA, magicDWord);
		ShowWindow(MainWharf[0]->wharfs[i]->folder->hMainWnd, SW_SHOWNORMAL);
		
		windowList = (IWindowList *)SendMessage(hParent, LM_WINDOWLIST, 0, 0);
		long count;

		windowList->GetWindowCount(&count);

		for (n = 0; n < count; n++)
		{
			HICON hIcon = NULL;
			HWND hParent, window;

			windowList->GetWindow(n, (OLE_HANDLE*)&window);

			if (GetWindowLong(window, GWL_USERDATA) == magicDWord) continue;
			if (GetWindowLong(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) continue;
			hParent = GetParent(window);
			if (GetWindowLong(hParent, GWL_USERDATA) == magicDWord) continue;
			
			x = MainWharf[0]->wharfs[i]->folder->numWharfs;
			/*if (!wharfs[i]->folder->wharfs)
			{				
				wharfs[i]->folder->wharfs = (subwharfType *)malloc(sizeof(subwharfType));
			} else {
				wharfs[i]->folder->wharfs = (subwharfType *)realloc(wharfs[i]->folder->wharfs, (x+1)*sizeof(subwharfType));
			}
			memset(&wharfs[i]->folder->wharfs[x], 0, sizeof(wharfs[i]->folder->wharfs[x]));*//*
			//wharfs[i]->folder->wharfs.push_back(new subwharfType(wharfs[i]));

			if(MainWharf[0]->wharfs[i]->folderDirection == WHARF_RIGHT)
			{
				xPos = MainWharf[0]->wharfs[i]->folder->width;
				yPos = 0;
				MainWharf[0]->wharfs[i]->folder->width += MainWharf[0]->wharfs[i]->folder->tileWidth;
			}
			else if(MainWharf[0]->wharfs[i]->folderDirection == WHARF_DOWN)
			{
				xPos = 0;
				yPos = MainWharf[0]->wharfs[i]->folder->height;
				MainWharf[0]->wharfs[i]->folder->height += MainWharf[0]->wharfs[i]->folder->tileHeight;
			}

			capt[0] = 0;
			if (window != NULL)
			{
				GetWindowText(window, (char *)&capt, sizeof(capt));
				//strcpy(wharfs[i]->folder->wharfs[x]->szName, capt);
			}

			//wharfs[i]->folder->wharfs.push_back(new subwharfType(wharfs[i], capt, "!task", "", "", "", TRUE, wharfs[i]->folder->tileWidth, wharfs[i]->folder->tileHeight, xPos, yPos, "", wharfs[i]->folderDirection));
			
			MainWharf[0]->wharfs[i]->folder->wharfs[x]->taskWnd = window;
			SendMessageTimeout(window, WM_GETICON, 1, 0, 0, 250, (unsigned long *)&hIcon);
			if (!hIcon) SendMessageTimeout(window, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long *)&hIcon);
			if (!hIcon) hIcon = (HICON)GetClassLong(window, GCL_HICON);
			if (!hIcon) hIcon = (HICON)GetClassLong(window, GCL_HICONSM);
			if (hIcon) /* not working for some reason *//*
			{
				HBITMAP oldBMP;
				HDC dst = CreateCompatibleDC(NULL);
				HDC tempDC = GetDC(MainWharf[0]->wharfs[i]->folder->hMainWnd);
				HBRUSH hb = CreateSolidBrush(RGB(255,0,255));
				HBRUSH hb2 = CreateSolidBrush(RGB(0, 0, 128));
				RECT r;
				int nHeight;
				
				MainWharf[0]->wharfs[i]->folder->wharfs[x]->frontImage = CreateCompatibleBitmap(tempDC, MainWharf[0]->wharfs[i]->folder->wharfs[x]->width, MainWharf[0]->wharfs[i]->folder->wharfs[x]->height);
				oldBMP = (HBITMAP)SelectObject(dst, MainWharf[0]->wharfs[i]->folder->wharfs[x]->frontImage);
				r.left = 0;
				r.top = 0;
				r.right = MainWharf[0]->wharfs[i]->folder->wharfs[x]->width;
				r.bottom = MainWharf[0]->wharfs[i]->folder->wharfs[x]->height;
				FillRect(dst, &r, hb);
				//				r.bottom = 10;
				nHeight = MulDiv(iTitleFontSize, GetDeviceCaps(dst, LOGPIXELSY), 72);
				r.bottom = nHeight +2;
				r.right = MainWharf[0]->wharfs[i]->folder->wharfs[x]->width;
				FillRect(dst, &r, hb2);
				DrawIconEx(dst, 16, 16, hIcon, 32, 32, 0, NULL, DI_NORMAL);
				ReleaseDC(MainWharf[0]->wharfs[i]->folder->hMainWnd, tempDC);
				SelectObject(dst, oldBMP);
				DeleteDC(dst);
				DeleteObject(hb);
				DeleteObject(hb2);
				DeleteObject(hIcon);
			}
			
			/*capt[0] = 0;
			if (window != NULL)
			{
				GetWindowText(window, (char *)&capt, sizeof(capt));
				strcpy(wharfs[i]->folder->wharfs[x]->szName, capt);
			}
			strcpy(wharfs[i]->folder->wharfs[x]->szCommand, "!none");
			wharfs[i]->folder->wharfs[x]->taskWnd = window;
			wharfs[i]->folder->wharfs[x]->showbg = TRUE;
			//CreateSubWharf(i, wharfs[i]->folder->numWharfs, "");
			wharfs[i]->folder->wharfs.push_back(new subwharfType(wharfs[i], capt, "!none", "", "", "", TRUE, wharfs[i]->folder->tileWidth, wharfs[i]->folder->tileHeight, xPos, yPos, ""));
			*//*MainWharf[0]->wharfs[i]->folder->numWharfs++;
		}
        
		SetWindowRgn(MainWharf[0]->wharfs[i]->folder->hMainWnd, MainWharf[0]->wharfs[i]->folder->hMainRgn, TRUE);
		
		if (wharfOpenSound) SoundOpen();
		MainWharf[0]->wharfs[i]->open = TRUE;
		
		if (wharfNoAnim)
		{
			if(MainWharf[0]->wharfs[i]->direction == WHARF_DOWN)
			{
				if ((MainWharf[0]->x+(MainWharf[0]->width/2)) > ScreenWidth/2)
					SetWindowPos(MainWharf[0]->wharfs[i]->folder->hMainWnd, 0, MainWharf[0]->x-MainWharf[0]->wharfs[i]->folder->width, MainWharf[0]->y+MainWharf[0]->wharfs[i]->inWharfY, MainWharf[0]->wharfs[i]->folder->width, MainWharf[0]->wharfs[i]->folder->height, SWP_NOZORDER);
				else
					SetWindowPos(MainWharf[0]->wharfs[i]->folder->hMainWnd, 0, MainWharf[0]->x+MainWharf[0]->width, MainWharf[0]->y+MainWharf[0]->wharfs[i]->inWharfY, MainWharf[0]->wharfs[i]->folder->width, MainWharf[0]->wharfs[i]->folder->height, SWP_NOZORDER);
			}
			else if(MainWharf[0]->wharfs[i]->direction == WHARF_RIGHT)
			{
				if ((MainWharf[0]->y+(MainWharf[0]->height/2)) > ScreenHeight/2)
					SetWindowPos(MainWharf[0]->wharfs[i]->folder->hMainWnd, 0, MainWharf[0]->x+MainWharf[0]->wharfs[i]->inWharfX, MainWharf[0]->y-MainWharf[0]->wharfs[i]->folder->height, MainWharf[0]->wharfs[i]->folder->width, MainWharf[0]->wharfs[i]->folder->height, SWP_NOZORDER);
				else
					SetWindowPos(MainWharf[0]->wharfs[i]->folder->hMainWnd, 0, MainWharf[0]->x+MainWharf[0]->wharfs[i]->inWharfX, MainWharf[0]->y+MainWharf[0]->height, MainWharf[0]->wharfs[i]->folder->width, MainWharf[0]->wharfs[i]->folder->height, SWP_NOZORDER);
			}
			
			MainWharf[0]->wharfs[i]->open = TRUE;
			return;
		} else {
			MainWharf[0]->wharfs[i]->moving = TRUE;
			MainWharf[0]->wharfs[i]->closing = FALSE;
			SetTimer(MainWharf[0]->wharfs[i]->folder->hMainWnd, 2, wharfAnimTime, NULL);
			OpenFolders++;
		}
	}
	
}
*/
void CreateWharfhints(HWND hWnd, char *txt, RECT *r)
{
	TOOLINFO ti;    // tool information
	
	if(wharfNoHints)
		return;

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = txt;
	ti.rect = *r;
	
	SendMessage(wharfHints, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

void RemoveWharfhints(HWND hWnd)
{
	TOOLINFO ti;    // tool information
	RECT r={0,0,0,0};
	
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = NULL;
	ti.rect = r;
	
	SendMessage(wharfHints, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

wharfFolderType::wharfFolderType(int Direction)
{
	hMainWnd = NULL;
	hMainRgn = NULL;
	width = 0;
	height = 0;
	tileWidth = 0;
	tileHeight = 0;
	numWharfs = 0;
	direction = Direction;
	open = FALSE;
	moving = FALSE;
	closing = FALSE;
	movingPos = 0;
}

wharfFolderType::~wharfFolderType()
{
	for(int x = 0; x < numWharfs; x++)
	{
		delete wharfs[x];
	}
	wharfs.clear();

	if(hMainWnd)
		DestroyWindow(hMainWnd);
	if(hMainRgn)
		DeleteObject(hMainRgn);
}

BOOL wharfFolderType::Create(FILE *file)
{
	HWND tempWnd;

	tempWnd = CreateWindowEx(
		WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
		szFolderWindowClass,
		"LSWharflet",
		WS_CLIPCHILDREN | WS_POPUP,
		0, 0,
		0, 0,
		hParent,
		NULL,
		dll,
		NULL
		);

	if(!tempWnd)
	{
		MessageBox(hParent, "Error creating wharf", "Wharf", MB_OK | MB_TOPMOST);
		return 1;
	}
	hMainWnd = tempWnd;
								
	SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(hMainWnd, 4, (LONG)this);

	ParseData(file);

	ShowWindow(hMainWnd, SW_SHOWNORMAL);

	return 0;
}

void wharfFolderType::ParseData(FILE *file)
{
	char buffer[255];
	char token1[255], token2[255], token3[255], token4[255], extra_text[255];
	char *tokens[4];

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	buffer[0] = 0;

	while(LCReadNextConfig(file, "*Wharf", buffer, sizeof(buffer)))
	{
		int count;

		token1[0] = token2[0] = token3[0] = token4[0] = extra_text[0] = '\0';
				
		count = LCTokenize(buffer, tokens, 4, extra_text);

		switch(count)
		{
		case 2:
			if(!strcmpi(token2, "~Folder"))
			{
				if(hMainWnd)
				{
					SetWindowRgn(hMainWnd, hMainRgn, TRUE);
					hMainRgn = NULL;
				}
				return;
			}
		case 4:
			{
				// token 1 is "*Wharf", token 2 is the name, token 3 is the
				// graphic, token 4 is the executable, and the extra_text are
				// the program arguments.
				char windowName[256];
				BOOL showBack = TRUE;
				char szTT[1024];
				int xPos, yPos;
						
				windowName[0] = '\0';

				if((token4[0] == '%') && (strrchr(token4, '%') == token4))
				{
					char szTempToken[4096];
					char *tokens2[5];
					tokens2[0] = token1;
					tokens2[1] = token2;
					tokens2[2] = token3;
					tokens2[3] = szTempToken;
					tokens2[4] = token4;

					strcpy(windowName, token4 + 1);

					extra_text[0] = token4[0] = '\0';
				}
				else
					strcpy(windowName, token2);

				if(token3[0] == '*')
				{
					char *temptoken3;
					temptoken3 = token3;
					if(*temptoken3 == '*')
						temptoken3++;
					strcpy(token3,temptoken3);
					showBack = FALSE;
				}

				if(direction == WHARF_RIGHT)
				{
					xPos = width;
					yPos = 0;
					width += tileWidth;
				}
				else if(direction == WHARF_DOWN)
				{
					xPos = 0;
					yPos = height;
					height += tileHeight;
				}

				if(!strcmpi (token4, "Folder"))
				{
					strcpy(szTT, token2);
				}
				else
				{
					strcpy(szTT, token4);
					if(strnicmp(".extract", token3, 8) && extra_text && strlen(extra_text))
					{
						strcat (szTT, " ");
						strcat (szTT, extra_text);
					}
				}		
				wharfs.push_back(new wharfTileType(hMainWnd, hMainRgn, token2, token4, extra_text, token3, szTT, showBack, tileWidth, tileHeight, xPos, yPos, windowName, direction, TRUE));

				if(!strcmpi(token4, "Folder"))
				{
					wharfs[numWharfs]->folder->Create(file);
				}

				numWharfs++;
			}
		}
	}
}

void wharfFolderType::CloseAllFolders()
{
	for(int i = 0; i < numWharfs; i++)
	{
		if(wharfs[i]->folder->open || wharfs[i]->folder->moving)
		{
			wharfs[i]->folder->CloseAllFolders();
			wharfs[i]->bPressed = FALSE;
			wharfs[i]->TogglePressOffset(FALSE);
			if(wharfNoAnim)
			{
				SetWindowPos(wharfs[i]->folder->hMainWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
				wharfs[i]->folder->open = FALSE;
			}
			else
			{
				wharfs[i]->folder->moving = TRUE;
				wharfs[i]->folder->closing = TRUE;
				SetTimer(wharfs[i]->hWnd, 3, wharfAnimTime, NULL);
			}
			OpenFolders--;
		}
	}
}

BOOL wharfFolderType::PartOfWharf(HWND myWnd)
{
	if(myWnd == NULL)
		return FALSE;
	if(hParent == myWnd)
		return TRUE;
	if(hMainWnd == myWnd)
		return TRUE;

	for(int i = 0; i < numWharfs; i++)
	{
		if(wharfs[i]->hWnd == myWnd)
			return TRUE;
		if(wharfs[i]->folder)
		{
			if(wharfs[i]->folder->PartOfWharf(myWnd))
				return TRUE;
		}
	}
	return FALSE;
}

void wharfFolderType::OnActivate(Message &message)
{
	if(!wharfCloseOnSwitch)
		return;

	if(wharfs.size() && message.wParamLo == WA_INACTIVE)
	{
		if(!PartOfWharf((HWND)(message.lParam)))
			CloseAllFolders();
	}
}

void wharfFolderType::OnTimer(Message &message)
{
	if(message.wParam == 4)
	{
		for(int i = 0; i < numWharfs; i++)
		{
			if(wharfs[i]->bPressed && !wharfs[i]->folder->open)
				wharfs[i]->TogglePressOffset(FALSE);
		}
	}
}

wharfTileType::wharfTileType(HWND pWnd, HRGN pRgn, LPCSTR name, LPCSTR command, LPCSTR params, LPCSTR image, LPCSTR imageParams, BOOL showBack, int Width, int Height, int xPos, int yPos, LPCSTR windowName, int Direction, BOOL InFolder)
{
	hInst = NULL;
	hWnd = NULL;
	taskWnd = NULL;
	parentWnd = pWnd;
	backImage = NULL;
	frontImage = LoadLSImage(image, imageParams);
	szName = new char[strlen(name) + 1];
	strcpy(szName, name);
	szCommand = new char[strlen(command) + 1];
	strcpy(szCommand, command);
	szParameters = new char[strlen(params) + 1];
	strcpy(szParameters, params);
	width = Width;
	height = Height;
	inWharfX = xPos;
	inWharfY = yPos;
	direction = Direction;
	showbg = showBack;
	bPressed = FALSE;
	bTogglePressed = FALSE;
	inFolder = InFolder;
	initWharfModule = NULL;
	quitWharfModule = NULL;
	GetLSRegion = NULL;
	parentRgn = pRgn;
	folder = new wharfFolderType((direction == wharfDirection) ? wharfFolderDirection : wharfDirection);

	Create(windowName);
}

wharfTileType::~wharfTileType()
{
	parentWnd = NULL;
	taskWnd = NULL;
	parentRgn = NULL;
	if(szName)
		delete[] szName;
	szName = NULL;
	if(szCommand)
		delete[] szCommand;
	szCommand = NULL;
	if(szParameters)
		delete[] szParameters;
	szParameters = NULL;

	if(folder)
		delete folder;
	if(hInst)
	{
		(*quitWharfModule)(hInst);
		FreeLibrary(hInst);
	}
	DestroyWindow(hWnd);
	if(backImage)
		DeleteObject(backImage);
	if(frontImage)
		DeleteObject(frontImage);
}

BOOL wharfTileType::Create(LPCSTR szWindowName)
{
	HWND tempWnd;
	RECT r;
	
	tempWnd = CreateWindowEx(
		WS_EX_TRANSPARENT,
		szTileWindowClass,
		szWindowName,
		WS_CHILD,
		0, 0,
		width, height,
		parentWnd,
		NULL,
		dll,
		NULL);
	
	if(!tempWnd)
	{
		MessageBox(hParent, "Error creating wharf tile", "Wharf", MB_OK | MB_TOPMOST);
		return FALSE;
	}
	hWnd = tempWnd;
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(hWnd, 4, (LONG)this);
	//Wharf hints
	if(!wharfNoHints)
	{
		if(hWnd)
		{
			RECT r;
			GetClientRect (hWnd, &r);
			CreateWharfhints (hWnd, szName, &r);
		}
	}

	SetWindowPos(hWnd, 0, inWharfX, inWharfY, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
	
	if(szCommand[0] == '@')
	{
		int (FAR *FinitWharfModule)(HWND, HINSTANCE, wharfDataType*);
		int (FAR *FquitWharfModule)(HINSTANCE);
		HRGN (FAR *FGetLSRegion)(int, int);
		
		char *module;
		HINSTANCE moduleInst;
		
		module = szCommand;
		if(*module == '@')
			module++;
		moduleInst = LoadLibrary(module);
		if((UINT)moduleInst > HINSTANCE_ERROR)
		{
			FinitWharfModule = (int (FAR *)(HWND, HINSTANCE, wharfDataType*))GetProcAddress(moduleInst, "initWharfModule");
			if(!FinitWharfModule)
				FinitWharfModule = (int (FAR *)(HWND, HINSTANCE, wharfDataType*))GetProcAddress(moduleInst, "_initWharfModule");
			FquitWharfModule = (int (FAR *)(HINSTANCE))GetProcAddress(moduleInst, "quitWharfModule");
			if(!FquitWharfModule)
				FquitWharfModule = (int (FAR *)(HINSTANCE))GetProcAddress(moduleInst, "_quitWharfModule");
			FGetLSRegion = (HRGN (FAR *)(int, int))GetProcAddress(moduleInst, "GetLSRegion");
			if(!FGetLSRegion)
				FGetLSRegion = (HRGN (FAR *)(int, int))GetProcAddress(moduleInst, "_GetLSRegion");
			
			if(!FinitWharfModule || !FquitWharfModule)
			{
				MessageBox(NULL, module, "Invalid Wharf module", MB_OK | MB_TOPMOST);
				FreeLibrary(moduleInst);
				hInst = NULL;
			}
			else
			{
				hInst = moduleInst;
				initWharfModule = FinitWharfModule;
				quitWharfModule = FquitWharfModule;
				GetLSRegion = FGetLSRegion;
				Execute();
			}
		}
		else
		{
			hInst = NULL;
			MessageBox(NULL, module, "Error loading module", MB_OK | MB_TOPMOST);
		}
	}
	
	/* Combine our images into one */
	{
		HBITMAP oldBMP1, oldBMP2 = NULL;
		HDC src = CreateCompatibleDC(NULL);
		HDC dst = CreateCompatibleDC(NULL);
		HBRUSH hb = CreateSolidBrush(RGB(255,0,255));
		HDC tempDC = GetDC(hWnd);
		RECT r;
		
		backImage = CreateCompatibleBitmap(tempDC, width, height);
		oldBMP1 = (HBITMAP)SelectObject(dst, backImage);
		r.left = 0;
		r.top = 0;
		r.right = width;
		r.bottom = height;
		FillRect(dst, &r, hb);
		if(wharfTitles && !hInst)
		{
			HBRUSH hb2 = CreateSolidBrush(RGB(0,0,128));
			r.bottom = 10;
			FillRect(dst, &r, hb2);
			DeleteObject(hb2);
		}
		if(hInst && !GetLSRegion)
		{
			HDC ddc = GetDC(GetDesktopWindow());
			POINT p;
			
			p.x = 0;
			p.y = 0;
			ClientToScreen(hWnd, &p);
			BitBlt(dst, 0, 0, width, height, ddc, p.x, p.y, SRCCOPY);
			ReleaseDC(GetDesktopWindow(), ddc);
		}
		if(defaultBackImage && !inFolder)
		{
			if(showbg == TRUE)
			{
				SelectObject(src, defaultBackImage);
				TransparentBltLS(dst, 0, 0, width, height, src, 0, 0, RGB(255, 0, 255));
			}
		}
		else if(defaultFolderImage && inFolder)
		{
			if(showbg == TRUE)
			{
				SelectObject(src, defaultFolderImage);
				TransparentBltLS(dst, 0, 0, width, height, src, 0, 0, RGB(255, 0, 255));
			}
		}
		if (frontImage)
		{
			BITMAP bmInfo;
			
			GetObject(frontImage, sizeof(bmInfo), &bmInfo);
			if (bmInfo.bmWidth > width) bmInfo.bmWidth = width;
			if (bmInfo.bmHeight > height) bmInfo.bmHeight = height;
			oldBMP2 = (HBITMAP)SelectObject(src, frontImage);
			TransparentBltLS(dst, (width/2)-(bmInfo.bmWidth/2), (height/2)-(bmInfo.bmHeight/2), bmInfo.bmWidth, bmInfo.bmHeight, src, 0, 0, RGB(255,0,255));
			DeleteObject(frontImage);
		}
		if((folderImage)&& ((!strcmpi(szCommand, "Folder"))||(!strcmpi(szCommand, "!WharfTasks"))))
		{
			if(showbg == TRUE )
			{
				if(oldBMP2)
					SelectObject(src, folderImage);
				else
					oldBMP2 = (HBITMAP)SelectObject(src, folderImage);
				TransparentBltLS(dst, 0, 0, width, height, src, 0, 0, RGB(255,0,255));
			}
		}
		
		ReleaseDC(hWnd, tempDC);
		SelectObject(src, oldBMP2);
		DeleteDC(src);
		SelectObject(dst, oldBMP1);
		DeleteDC(dst);
		DeleteObject(hb);
	}
	/* Calculate transparent regions for hMainWnd here, compile regions per bitmap/tile and add together
	* for a full transparent hParent window - <toasty@iav.com>  */
	if(backImage && !hInst)
	{
		HRGN wharfRgn;

		wharfRgn = BitmapToRegion(backImage, RGB(255,0,255), 0x101010, inWharfX, inWharfY);
		if(parentRgn)
		{
      		CombineRgn(parentRgn, parentRgn, wharfRgn, RGN_OR);
			DeleteObject(wharfRgn);
    	}
		else
		{
			parentRgn = wharfRgn;
		}
	}
	else
	{
		HRGN rgn, bgRgn;

		if(GetLSRegion)
		{
			bgRgn = BitmapToRegion(backImage, RGB(255,0,255), 0x101010, inWharfX, inWharfY);
			rgn = GetLSRegion(inWharfX, inWharfY);
			
			if(rgn)
			{
				CombineRgn(rgn, rgn, bgRgn, RGN_OR);
				DeleteObject(bgRgn);
			}
			else
			{
				rgn = bgRgn;
			}
		} 
		else 
		{
			rgn = CreateRectRgn(inWharfX, inWharfY, width+inWharfX, height+inWharfY);
		}
		if(parentRgn)
		{
      		CombineRgn(parentRgn, parentRgn, rgn, RGN_OR);
			DeleteObject(rgn);
    	}
		else
		{
			parentRgn = rgn;
    	}
	}

	if(!strcmpi(szCommand, "Folder"))
	{
		char *val1 = NULL, *val2 = NULL;

		val1 = strtok(szParameters, " ");
		val2 = strtok(NULL, "");
		if(val1)
			folder->tileWidth = atoi(val1);
		else
			folder->tileWidth = width;
		if(val2)
			folder->tileHeight = atoi(val2);
		else
			folder->tileHeight = height;

		if(folder->direction == WHARF_RIGHT)
		{
			folder->width = 0;
			folder->height = folder->tileHeight;
		}
		else if(folder->direction == WHARF_DOWN)
		{
			folder->width = folder->tileWidth;
			folder->height = 0;
		}
	}

	ShowWindow(hWnd, SW_SHOWNORMAL);
	GetClientRect(hWnd, &r);
	InvalidateRect(hWnd, &r, TRUE);
	
	return TRUE;
}

void wharfTileType::Execute()
{
	if(!strcmpi(szCommand, "Folder"))
	{
/*		if(wharfAutoClose)
		{
			SendMessage(parentWnd, WHARF_CLOSEFOLDERS, 0, 0);
			for(q = 0; q < MainWharf[0]->numWharfs; q++)
			{
				if((MainWharf[0]->wharfs[q]->folder->open || MainWharf[0]->wharfs[q]->folder->moving) && (MainWharf[0]->wharfs[q]->hWnd != hWnd))
				{
					MainWharf[0]->wharfs[q]->bPressed = FALSE;
					MainWharf[0]->wharfs[q]->TogglePressOffset(FALSE);
					if(wharfNoAnim)
					{
						SetWindowPos(MainWharf[0]->wharfs[q]->folder->hMainWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
					}
					else
					{
						MainWharf[0]->wharfs[q]->folder->moving = TRUE;
						MainWharf[0]->wharfs[q]->folder->closing = TRUE;
						//wharfs[q]->movingPos = wharfs[q]->folder->numWharfs*64;
						SetTimer(MainWharf[0]->wharfs[q]->hWnd, 3, wharfAnimTime, NULL);
					}
					MainWharf[0]->wharfs[q]->folder->open = FALSE;
					OpenFolders--;
				}
			}
		}
*/		
		if(folder->moving)
		{
			if(folder->closing)
			{
				folder->closing = FALSE;
				if(wharfOpenSound) SoundOpen();
			}
			else
			{
				folder->closing = TRUE;
				if(wharfCloseSound) SoundClose();
			}
		}
		else if(folder->open == FALSE)
		{
			if(wharfOpenSound) SoundOpen();
			folder->open = TRUE;
			if(wharfNoAnim)
			{
				RECT r;
				GetWindowRect(hWnd, &r);
				if(bPressed)
				{
					r.bottom--;
					r.left--;
					r.right--;
					r.top--;
				}

				if(direction == WHARF_DOWN)
				{
					if((r.left + (width/2)) > ScreenWidth/2)
						SetWindowPos(folder->hMainWnd, 0, r.left - folder->width, r.top, folder->width, folder->height, SWP_NOZORDER);
					else
						SetWindowPos(folder->hMainWnd, 0, r.right, r.top, folder->width, folder->height, SWP_NOZORDER);
				}
				else if(direction == WHARF_RIGHT)
				{
					if((r.top + (height/2)) > ScreenHeight/2)
						SetWindowPos(folder->hMainWnd, 0, r.left, r.top - folder->height, folder->width, folder->height, SWP_NOZORDER);
					else
						SetWindowPos(folder->hMainWnd, 0, r.left, r.bottom, folder->width, folder->height, SWP_NOZORDER);
				}
			}
			else
			{
				folder->moving = TRUE;
				folder->closing = FALSE;
				SetTimer(hWnd, 2, wharfAnimTime, NULL);
				OpenFolders++;
			}
		}
		else if(folder->open)
		{
			if(wharfCloseSound) SoundClose();
			if(wharfNoAnim)
			{
				folder->open = FALSE;
				bPressed = FALSE;
				TogglePressOffset(FALSE);
				SetWindowPos(folder->hMainWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
			}
			else
			{
				folder->moving = TRUE;
				folder->closing = TRUE;
				SetTimer(hWnd, 3, wharfAnimTime, NULL);
				OpenFolders--;
			}
		}
		return;
	}
	
	if(szCommand[0] == '@')
	{
		wharfDataType wharfData;
		memset (&wharfData, 0, sizeof (wharfData));
		GetWharfData(&wharfData, width, height);

		(*initWharfModule)(hWnd, hInst, &wharfData);
		return;
	}
	
	if(szCommand[0] == '!')
	{
		/*if(!strcmpi(szCommand, "!task"))
		{
			if(!SendMessage(hParent, LM_BRINGTOFRONT, 0, (long)taskWnd))
				SwitchToThisWindow(taskWnd, 1);
		}
		else if(!strcmpi(szCommand, "!WharfTasks"))
		{
			for(q = 0; q < numWharfs; q++)
				if(MainWharf[0]->wharfs[q]->hWnd == hWnd)
					ExecuteWharfTasks(q);
		}
		else*/
			ParseBangCommand(hWnd, szCommand, szParameters);
		return;
	}
	
	{
		char workDirectory[MAX_PATH];
		char drive[_MAX_DRIVE];
		char dir[_MAX_DIR];

		_splitpath(szCommand, drive, dir, NULL, NULL);
		strcpy(workDirectory, drive);
		strcat(workDirectory, dir);
/*		
		if(!wharfAutoUnpress)
		{
			bPressed = FALSE;
			TogglePressOffset(FALSE);
		}
*/		
		LSExecuteEx(NULL, NULL, szCommand, szParameters, workDirectory, SW_SHOWNORMAL);

		return;
	}
}

void wharfTileType::TogglePressOffset(BOOL bToggle)
{
	if(bTogglePressed != bToggle) // redundancy check...see below comment
	{
		if(direction == WHARF_DOWN)
		{
			SetWindowPos(hWnd,							 
			0, 
			bToggle ? wharfPressOffset : 0, 
			bToggle ? inWharfY + wharfPressOffset : inWharfY, 
			width, 
			bToggle ? height-1 : height, 
			SWP_NOZORDER);
		}
		else if(direction == WHARF_RIGHT)
		{
			SetWindowPos(hWnd, 
			0, 
			bToggle ? inWharfX + wharfPressOffset : inWharfX, 
			bToggle ? wharfPressOffset : 0, 
			bToggle ? width-1 : width,
			height,
			SWP_NOZORDER);
		}
		bTogglePressed = bToggle; // could this be replaced by checking the windows current position for a 1, 1 offset?
	}
}

void wharfTileType::AnimateOpen()
{
	if(folder->closing)
	{
		KillTimer(hWnd, 2);
		SetTimer(hWnd, 3, wharfAnimTime, NULL);
	}
	else
	{
		RECT r;
		GetWindowRect(hWnd, &r);
		if(bPressed)
		{
			r.bottom--;
			r.left--;
			r.right--;
			r.top--;
		}

		if(direction == WHARF_DOWN)
		{
			if(folder->direction == WHARF_RIGHT)
			{
				if(folder->movingPos + wharfStep >= folder->width)
					folder->movingPos = folder->width;
				else
					folder->movingPos += wharfStep;
				KillTimer(parentWnd, 4);

				if((r.left + (width/2)) > ScreenWidth/2)
					SetWindowPos(folder->hMainWnd, 0, r.left - folder->movingPos, r.top, folder->movingPos, folder->height, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.right, r.top, folder->movingPos, folder->height, SWP_NOZORDER);

				if(folder->movingPos >= folder->width)
				{
					folder->open = TRUE;
					folder->moving = FALSE;
					folder->closing = TRUE;
					KillTimer(hWnd, 2);
				}
			}
			else if(folder->direction == WHARF_DOWN)
			{
				if(folder->movingPos + wharfStep >= folder->height)
					folder->movingPos = folder->height;
				else
					folder->movingPos += wharfStep;
				KillTimer(parentWnd, 4);

				if((r.left + ( width/2)) > ScreenWidth/2)
					SetWindowPos(folder->hMainWnd, 0, r.left - folder->width, r.top, folder->width, folder->movingPos, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.right, r.top, folder->width, folder->movingPos, SWP_NOZORDER);

				if(folder->movingPos >= folder->height)
				{
					folder->open = TRUE;
					folder->moving = FALSE;
					folder->closing = TRUE;
					KillTimer(hWnd, 2);
				}
			}
		}
		else if(direction == WHARF_RIGHT)
		{
			if(folder->direction == WHARF_DOWN)
			{
				if(folder->movingPos + wharfStep >= folder->height)
					folder->movingPos = folder->height;
				else
					folder->movingPos += wharfStep;
			  	KillTimer(parentWnd, 4);

				if((r.top + (height/2)) > ScreenHeight/2)
					SetWindowPos(folder->hMainWnd, 0, r.left, r.top - folder->movingPos, folder->width, folder->movingPos, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.left, r.bottom, folder->width, folder->movingPos, SWP_NOZORDER);
	
				if(folder->movingPos >= folder->height)
				{
					folder->open = TRUE;
					folder->moving = FALSE;
					folder->closing = TRUE;
					KillTimer(hWnd, 2);
				}
			}
			else if(folder->direction == WHARF_RIGHT)
			{
				if(folder->movingPos + wharfStep >= folder->width)
					folder->movingPos = folder->width;
				else
					folder->movingPos += wharfStep;
			  	KillTimer(parentWnd, 4);

				if((r.top + (height/2)) > ScreenHeight/2)
					SetWindowPos(folder->hMainWnd, 0, r.left, r.top - folder->height, folder->movingPos, folder->height, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.left, r.bottom, folder->movingPos, folder->height, SWP_NOZORDER);
	
				if(folder->movingPos >= folder->width)
				{
					folder->open = TRUE;
					folder->moving = FALSE;
					folder->closing = TRUE;
					KillTimer(hWnd, 2);
				}
			}
		}
	}
}

void wharfTileType::AnimateClose()
{
	if(!folder->closing)
	{
		KillTimer(hWnd, 3);
		SetTimer(hWnd, 2, wharfAnimTime, NULL);
	}
	else
	{
		RECT r;
		GetWindowRect(hWnd, &r);
		if(bPressed)
		{
			r.bottom--;
			r.left--;
			r.right--;
			r.top--;
		}

		folder->movingPos -= wharfStep;
		bPressed = FALSE;
		TogglePressOffset(FALSE);
		KillTimer(parentWnd, 4);
		SetTimer(folder->hMainWnd, 4, 50, NULL);

		if(direction == WHARF_DOWN)
		{
			if(folder->direction == WHARF_RIGHT)
			{
				if((r.left + (width/2)) > ScreenWidth/2)
					SetWindowPos(folder->hMainWnd, 0, r.left - folder->movingPos, r.top, folder->movingPos, folder->height, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.right, r.top, folder->movingPos, folder->height, SWP_NOZORDER);
			}
			else if(folder->direction == WHARF_DOWN)
			{
				if((r.left + (width/2)) > ScreenWidth/2)
					SetWindowPos(folder->hMainWnd, 0, r.left - folder->width, r.top, folder->width, folder->movingPos, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.right, r.top, folder->width, folder->movingPos, SWP_NOZORDER);
			}
		}
		else if(direction == WHARF_RIGHT)
		{
			if(folder->direction == WHARF_DOWN)
			{
				if((r.top + (height/2)) > ScreenHeight/2)
					SetWindowPos(folder->hMainWnd, 0, r.left, r.top - folder->movingPos, folder->width, folder->movingPos, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.left, r.bottom, folder->width, folder->movingPos, SWP_NOZORDER);
			}
			else if(folder->direction == WHARF_RIGHT)
			{
				if((r.top + (height/2)) > ScreenHeight/2)
					SetWindowPos(folder->hMainWnd, 0, r.left, r.top - folder->height, folder->movingPos, folder->height, SWP_NOZORDER);
				else
					SetWindowPos(folder->hMainWnd, 0, r.left, r.bottom, folder->movingPos, folder->height, SWP_NOZORDER);
			}
		}

		if(folder->movingPos <= 0)
		{
			folder->open = FALSE;
			bPressed = FALSE;
			TogglePressOffset(FALSE);
			folder->moving = FALSE;
			folder->closing = FALSE;
			KillTimer(hWnd, 3);
			KillTimer(folder->hMainWnd, 4);
		}
	}
}

void wharfTileType::OnMouseMove(Message &message)
{
	MSG TooltipMessage;

	if(!wharfNoHints)
	{
		TooltipMessage.hwnd=hWnd;
		TooltipMessage.message=message.uMsg;
		TooltipMessage.wParam=message.wParam;
		TooltipMessage.lParam=message.lParam;
		SendMessage(wharfHints,TTM_RELAYEVENT,0,(LPARAM)&TooltipMessage);
		SetWindowPos(wharfHints, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
	}

	if(message.wParam & MK_LBUTTON)
	{
		if(bPressed)
			TogglePressOffset(TRUE);
		else if(!folder->open)
			TogglePressOffset(FALSE);
	}
}

void wharfTileType::OnPaint(Message &message)
{
	HBITMAP oldBMP = NULL;
	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd,&ps);
	HDC src = CreateCompatibleDC(hdc);

	if(backImage)
	{
		oldBMP = (HBITMAP)SelectObject(src, backImage);
		
		if(bPressed)
			TransparentBltLS(hdc, 0, 0, width, height, src, 0, 0, RGB(255,0,255));
		else
			BitBlt(hdc, 0, 0, width, height, src, 0, 0, SRCCOPY);
	}
	if((wharfTitles && !hInst)||(!strcmpi(szCommand, "!task")))
	{
		PaintTitle(hdc, src);
	}
	if(bevelWidth)
	{
		RECT r = {0, 0, width, height};
		Frame3D(hdc, r, RGB(255,255,255), RGB(0,0,0), bevelWidth);
	}

	if(oldBMP)
	{
		SelectObject(src, oldBMP);
	}

	EndPaint(hWnd,&ps);
	DeleteDC(src);
}

void wharfTileType::PaintTitle(HDC hdc, HDC src)
{
	RECT r;
	HBRUSH back;
	HFONT titleFont, oldFont;
	int nHeight;
	int len = lstrlen(szName);
	
	back = CreateSolidBrush(titleBack);
	GetClientRect(hWnd, &r);
	//					r.bottom = 10;
	//					FillRect(hdc, &r, back);
	nHeight = MulDiv(iTitleFontSize, GetDeviceCaps(src, LOGPIXELSY), 72);
	r.bottom = nHeight +2;
	FillRect(src, &r, back);
	titleFont = CreateFont(
		nHeight, // 8,
		0, // 6,
		0,
		0,
		iTitleFontWeight, // 0,
		FALSE,
		FALSE,
		FALSE,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_DONTCARE, // DEFAULT_PITCH,
		szTitleFont
		);
	oldFont = (HFONT)SelectObject(src, titleFont);
	SetBkMode(src, TRANSPARENT);
	SetTextColor(src, titleFore);
	TextOut(src, 2, 1, szName, len);
	BitBlt(hdc, 0, 0, width, height, src, 0, 0, SRCCOPY);
	SelectObject(src, oldFont);
	DeleteObject(titleFont);
	DeleteObject(back);
}

void wharfTileType::OnLButtonDown(Message &message)
{
	bPressed = TRUE;
	TogglePressOffset(TRUE);
	SetTimer(parentWnd, 4, 50, NULL);
}

void wharfTileType::OnLButtonUp(Message &message)
{
	if(bPressed)
	{
		if(wharfAutoUnpress)
		{
			bPressed = FALSE;
			TogglePressOffset(FALSE);
		}

		KillTimer(parentWnd, 4);
		Execute();
	}
}

void wharfTileType::OnTimer(Message &message)
{
	if(message.wParam == 2)   //sub wharf opening
	{
		AnimateOpen();
	}
	if(message.wParam == 3)  // sub wharf closing
	{
		AnimateClose();
	}
}

wharfHiddenType::wharfHiddenType(wharfType *p)
{
	parent = p;
	HiddenWnd = NULL;
	hideTimerActive = FALSE;
	showTimerActive = FALSE;
}

wharfHiddenType::~wharfHiddenType()
{
	DestroyWindow(HiddenWnd);
}

BOOL wharfHiddenType::Create()
{
	HiddenWnd = CreateWindowEx(
		WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
		szHiddenWindowClass,
		"LSWharfHidden",
		WS_POPUP,
		(parent->x == 0) ? 0 : (parent->x+parent->width == ScreenWidth) ? parent->x+parent->width-hiddenWidth : parent->x,
		(parent->y == 0) ? 0 : (parent->y+parent->height == ScreenHeight) ? parent->y+parent->height-hiddenWidth : parent->y,
		(parent->direction == WHARF_DOWN) ? hiddenWidth : ScreenWidth,
		(parent->direction == WHARF_RIGHT) ? hiddenWidth : ScreenHeight,
		hParent,
		NULL,
		dll,
		NULL
		);
		
	if(!HiddenWnd)
	{
		MessageBox(hParent, "Error creating wharf", "Wharf", MB_OK | MB_TOPMOST);
		return 1;
	}

	SetWindowLong(HiddenWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(HiddenWnd, 4, (LONG)this);

	return 0;
}

void wharfHiddenType::OnDisplayChange(Message &message)
{
	bool WasDocked = (parent->x + parent->width) == ScreenWidth;
	int RelativeX = ScreenWidth - parent->x;
	bool MoveRelative = RelativeX > (ScreenWidth / 2);
	parent->CloseAllFolders();
	ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
	ScreenHeight = GetSystemMetrics(SM_CYSCREEN);
	if(WasDocked)
		parent->x = ScreenWidth - parent->width;
	else if(MoveRelative)
		parent->x = ScreenWidth - RelativeX;
	SetWindowPos(parent->hMainWnd, HWND_TOPMOST, parent->x, parent->y, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
}

void wharfHiddenType::OnPaint(Message& message)
{
	PAINTSTRUCT ps;
	RECT r;
	HDC hdc = BeginPaint(HiddenWnd,&ps);
	HBRUSH hb = CreateSolidBrush(0xFFFFFF);

	GetClientRect(HiddenWnd, &r);
	r.right += 1;
	r.bottom += 1;

	FillRect(hdc, &r, hb);

	DeleteObject(hb);
	EndPaint(HiddenWnd, &ps);
}

void wharfHiddenType::OnTimer(Message& message)
{
	if(parent->docked)
	{
		switch(message.wParam)
		{
		case 0:
			if(wharfAutoHide)
			{
				if(parent->visible)
				{
					parent->Hide();
					ShowWindow(HiddenWnd, SW_SHOWNORMAL);
				}
			}
			KillTimer(HiddenWnd, 0);
			hideTimerActive = FALSE;
			break;
		case 1:
			if(wharfAutoHide && parent->visible && !hideTimerActive)
			{
				POINT pt;
				RECT r;
				GetCursorPos(&pt);
				GetWindowRect(parent->hMainWnd, &r);
				if(!parent->PartOfWharf(WindowFromPoint(pt)) && (wharfNoAnim || wharfCloseOnSwitch ? TRUE : !OpenFolders))
				{
					SetTimer(HiddenWnd, 0, autoHideDelay, NULL);
					hideTimerActive = TRUE;
				}
			}
			else
			{
				if(wharfAutoHide && !parent->visible && !showTimerActive)
				{
					POINT pt;
					RECT r;
					GetCursorPos(&pt);
					GetWindowRect(HiddenWnd, &r);
					if(pt.x >= r.left && pt.x <= r.right && pt.y >= r.top && pt.y <= r.bottom)
					{
						SetTimer(HiddenWnd, 2, autoShowDelay, NULL);
						showTimerActive = TRUE;
					}

				}
				else if(!parent->visible && showTimerActive)
				{
					POINT pt;
					RECT r;
					GetCursorPos(&pt);
					GetWindowRect(HiddenWnd, &r);
					if(pt.x < r.left || pt.x > r.right || pt.y < r.top || pt.y > r.bottom)
					{
						KillTimer(HiddenWnd, 2);
						showTimerActive = FALSE;
					}
				}
			}
			break;
		case 2:
			if(wharfAutoHide)
			{
				if(!parent->visible)
				{
					ShowWindow(HiddenWnd, SW_HIDE);
					parent->Show();
				}
			}
			KillTimer(HiddenWnd, 2);
			showTimerActive = FALSE;
			break;
		}
	}
	else
	{
		if(hideTimerActive)
		{
			KillTimer(HiddenWnd, 0);
			hideTimerActive = FALSE;
		}
	}
}

wharfType::wharfType(HWND parent, LPCSTR name, int xPos, int yPos, int TileWidth, int TileHeight, int Direction)
{
	hMainWnd = NULL;
	parentWnd = parent;
	x = xPos;
	y = yPos;
	width = 0;
	height = 0;
	tileWidth = TileWidth;
	tileHeight = TileHeight;
	szName = new char[strlen(name) + 1];
	strcpy(szName, name);
	direction = Direction;
	if(direction == WHARF_DOWN)
	{
		width = tileWidth;
		height += capHeight;
	}
	else if(direction == WHARF_RIGHT)
	{
		width += capHeight;
		height = tileHeight;
	}
	hMainRgn = CreateRectRgn(0, 0, width, height);
	docked = 0;
	numWharfs = 0;
	movingPos = 0;
	open = TRUE;
	moving = FALSE;
	closing = FALSE;
	visible = TRUE;
}

wharfType::~wharfType()
{
	UINT Msgs[2];

	for(int i = 0; i < numWharfs; i++)
	{
		delete wharfs[i];
	}
	wharfs.clear();

	if(wharfAutoHide)
	{
		KillTimer(HiddenWharf->HiddenWnd, 1);
		delete HiddenWharf;
	}

	Msgs[0] = LM_SHADETOGGLE;
	Msgs[1] = 0;
	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);

	if(szName)
		delete[] szName;
	szName = NULL;

	if(hMainRgn)
		DeleteObject(hMainRgn);
	DestroyWindow(hMainWnd);
}

BOOL wharfType::Create(FILE *file)
{
	UINT Msgs[2];
	HWND tempWnd;

	tempWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW | (wharfAlwaysOnTop ? WS_EX_TOPMOST : 0),
		szMainWindowClass,
		szName,
		WS_CLIPCHILDREN | WS_POPUP,
		x,
		y,
		0,
		0,
		parentWnd,
		NULL,
		dll,
		NULL
		);

	if(!tempWnd)
	{
		MessageBox(hParent, "Error creating wharf", "Wharf", MB_OK | MB_TOPMOST);
		return 1;
	}
	hMainWnd = tempWnd;

	SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(hMainWnd, 4, (LONG)this);

	ParseData(file);

	if(wharfAutoHide)
	{
		HiddenWharf = new wharfHiddenType(this);
		HiddenWharf->Create();
	}

	Msgs[0] = LM_SHADETOGGLE;
	Msgs[1] = 0;
	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);

	SetWindowPos(hMainWnd, 0, x, y, width, height, SWP_NOZORDER);

	/* transparent titlebar */
	if(wharfTitlebar && titlebarImage)
	{
		HRGN hClipRgn, hTitlebarRgn;

		if(direction == WHARF_DOWN)
		{
			hClipRgn = CreateRectRgn(0, 0, width, capHeight);
		}
		else if(direction == WHARF_RIGHT)
		{
			hClipRgn = CreateRectRgn(0, 0, capHeight, height);
		}
		hTitlebarRgn = BitmapToRegion(titlebarImage, RGB(255,0,255), 0x101010, 0, 0);
		
		if(hMainRgn)
		{
			CombineRgn(hTitlebarRgn, hClipRgn, hTitlebarRgn, RGN_DIFF);
			CombineRgn(hMainRgn, hMainRgn, hTitlebarRgn, RGN_DIFF);
		}
		
		DeleteObject(hClipRgn);
		DeleteObject(hTitlebarRgn);
	}
	SetWindowRgn(hMainWnd, hMainRgn, TRUE);
	hMainRgn = NULL;

	if(wharfStartHidden)
		visible = FALSE;
	else
		ShowWindow(hMainWnd, SW_SHOWNORMAL);
	
	// If we are autohiding, set the autohide delay.
	if(wharfAutoHide)
	{
		RECT r;
		GetClientRect(hMainWnd, &r);

		if(direction == WHARF_DOWN)
		{
			SetWindowPos(HiddenWharf->HiddenWnd, 0, 0, 0, hiddenWidth, r.bottom - r.top, SWP_NOZORDER | SWP_NOMOVE);
		}
		else if(direction == WHARF_RIGHT)
		{
			SetWindowPos(HiddenWharf->HiddenWnd, 0, 0, 0, r.right - r.left, hiddenWidth, SWP_NOZORDER | SWP_NOMOVE);
		}

		SetTimer(HiddenWharf->HiddenWnd, 1, 50, NULL);
	}
	SetWorkArea();

	return 0;
}

void wharfType::ParseData(FILE *file)
{
	char buffer[255];
	char token1[255], token2[255], token3[255], token4[255], extra_text[255];
	char *tokens[4];

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	buffer[0] = 0;

	while(LCReadNextConfig(file, "*Wharf", buffer, sizeof(buffer)))
	{
		int count;

		token1[0] = token2[0] = token3[0] = token4[0] = extra_text[0] = '\0';
				
		count = LCTokenize(buffer, tokens, 4, extra_text);

		switch(count)
		{
		case 4:
			{
				if(!strcmpi(token2, "!New"))
				{
					numMainWharfs++;
					MainWharf.push_back(new wharfType(parentWnd, token3, atoi(token4), atoi(extra_text), tileWidth, tileHeight, wharfDirection));
					MainWharf[numMainWharfs]->Create(file);
					return;
				}

				// token 1 is "*Wharf", token 2 is the name, token 3 is the
				// graphic, token 4 is the executable, and the extra_text are
				// the program arguments.
				char windowName[256];
				BOOL showBack = TRUE;
				char szTT[1024];
				int xPos, yPos;
						
				windowName[0] = '\0';

				if((token4[0] == '%') && (strrchr(token4, '%') == token4))
				{
					char szTempToken[4096];
					char *tokens2[5];
					tokens2[0] = token1;
					tokens2[1] = token2;
					tokens2[2] = token3;
					tokens2[3] = szTempToken;
					tokens2[4] = token4;

					strcpy(windowName, token4 + 1);

					extra_text[0] = token4[0] = '\0';
				}
				else
					strcpy(windowName, token2);

				if(token3[0] == '*')
				{
					char *temptoken3;
					temptoken3 = token3;
					if(*temptoken3 == '*')
						temptoken3++;
					strcpy(token3,temptoken3);
					showBack = FALSE;
				}

				if(direction == WHARF_DOWN)
				{
					xPos = 0;
					yPos = height;
					height += tileHeight;
				}
				else if(direction == WHARF_RIGHT)
				{
					xPos = width;
					yPos = 0;
					width += tileWidth;
				}
							
				if(!strcmpi (token4, "Folder"))
				{
					strcpy(szTT, token2);
				}
				else
				{
					strcpy(szTT, token4);
					if(strnicmp(".extract", token3, 8) && extra_text && strlen(extra_text))
					{
						strcat (szTT, " ");
						strcat (szTT, extra_text);
					}
				}
				wharfs.push_back(new wharfTileType(hMainWnd, hMainRgn, token2, token4, extra_text, token3, szTT, showBack, tileWidth, tileHeight, xPos, yPos, windowName, direction, FALSE));

				if(!strcmpi(token4, "Folder"))
				{
					wharfs[numWharfs]->folder->Create(file);
				}

				numWharfs++;
			}
		}
	}
}

void wharfType::Show()
{
	if(!visible && !IsWindowVisible(HiddenWharf->HiddenWnd))
	{
		ShowWindow(hMainWnd, SW_SHOWNORMAL);
		visible = TRUE;
	}
}

void wharfType::Hide()
{
	if(visible)
	{
		ShowWindow(hMainWnd, SW_HIDE);
		visible = FALSE;
	}
}

void wharfType::Move(LPCSTR arg1, LPCSTR arg2, BOOL moveTo)
{
	int sw, sh;

	if(visible)
	{
		if(arg1)
		{
			if(moveTo)
				x = atoi(arg1);
			else
				x += atoi(arg1);

			sw = GetSystemMetrics(SM_CXSCREEN);

			if(x < 0)
				x = 0;
			else if(x > (sw - width))
				x = sw - width;
		}
		if(arg2)
		{
			if(moveTo)
				y = atoi(arg2);
			else
				y += atoi(arg2);

			sh = GetSystemMetrics(SM_CYSCREEN);

			if(y < 0)
				y = 0;
			else if(y > (sh - height))
				y = sh - height;
		}
	}
	SetWindowPos(hMainWnd, NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
}

void wharfType::AnimateOpen()
{
	if(direction == WHARF_DOWN)
	{
		movingPos += wharfStep;
		SetWindowPos(hMainWnd, 0, x, y, width, movingPos, SWP_NOZORDER);
		if(movingPos >= height)
		{
			closing = FALSE;
			open = TRUE;
			KillTimer(hMainWnd, 0);
		}
	}
	else if(direction == WHARF_RIGHT)
	{
		movingPos += wharfStep;
		SetWindowPos(hMainWnd, 0, x, y, movingPos, height, SWP_NOZORDER);
		if(movingPos >= width)
		{
			closing = FALSE;
			open = TRUE;
			KillTimer(hMainWnd, 0);
		}
	}
}

void wharfType::AnimateClose()
{
	if(direction == WHARF_DOWN)
	{
		if(movingPos - wharfStep <= capHeight )
			movingPos = capHeight;
		else
			movingPos -= wharfStep;
		SetWindowPos(hMainWnd, 0, x, y, width, movingPos, SWP_NOZORDER);
		if(movingPos <= capHeight)
		{
			closing = FALSE;
			open = FALSE;
			KillTimer(hMainWnd, 1);
		}
	}
	else if(direction == WHARF_RIGHT)
	{
		if(movingPos - wharfStep <= capHeight )
			movingPos = capHeight;
		else
			movingPos -= wharfStep;
		SetWindowPos(hMainWnd, 0, x, y, movingPos, height, SWP_NOZORDER);
		if(movingPos <= capHeight)
		{
			closing = FALSE;
			open = FALSE;
			KillTimer(hMainWnd, 1);
		}
	}
}

void wharfType::CloseAllFolders()
{
	for(int i = 0; i < numWharfs; i++)
	{
		if(wharfs[i]->folder->open || wharfs[i]->folder->moving)
		{
			wharfs[i]->folder->CloseAllFolders();
			wharfs[i]->bPressed = FALSE;
			wharfs[i]->TogglePressOffset(FALSE);
			if(wharfNoAnim)
			{
				SetWindowPos(wharfs[i]->folder->hMainWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
				wharfs[i]->folder->open = FALSE;
			}
			else
			{
				wharfs[i]->folder->moving = TRUE;
				wharfs[i]->folder->closing = TRUE;
				SetTimer(wharfs[i]->hWnd, 3, wharfAnimTime, NULL);
			}
			OpenFolders--;
		}
	}
}

BOOL wharfType::PartOfWharf(HWND myWnd)
{
	if(myWnd == NULL)
		return FALSE;
	if(hParent == myWnd)
		return TRUE;
	if(hMainWnd == myWnd)
		return TRUE;

	for(int i = 0; i < numWharfs; i++)
	{
		if(wharfs[i]->hWnd == myWnd)
			return TRUE;
		if(wharfs[i]->folder)
		{
			if(wharfs[i]->folder->PartOfWharf(myWnd))
				return TRUE;
		}
	}
	return FALSE;
}

void wharfType::SetWorkArea()
{
	RECT deskRect;
	int oldDocked = docked;
	
	SystemParametersInfo(SPI_GETWORKAREA, 0, &deskRect, 0);
	
	if(x == 0 && direction == WHARF_DOWN) 
	{
		docked = 1;
		if(setDesktopArea == FALSE)
		{
			deskRect.left = (wharfAutoHide) ? hiddenWidth : width;
			deskRect.right = ScreenWidth;
		}
	}
	else if(x + width == ScreenWidth && direction == WHARF_DOWN) 
	{
		docked = 2;
		if(setDesktopArea == FALSE)
		{
			deskRect.left = 0;
			deskRect.right = (wharfAutoHide) ? ScreenWidth - hiddenWidth : ScreenWidth - width;
		}
	}
	else if(y == 0 && direction == WHARF_RIGHT) 
	{
		docked = 3;
		if(setDesktopArea == FALSE)
		{
			deskRect.top = (wharfAutoHide) ? hiddenWidth : height;
			deskRect.bottom = ScreenHeight;
		}
	}
	else if(y + height == ScreenHeight && direction == WHARF_RIGHT) 
	{
		docked = 4;
		if(setDesktopArea == FALSE)
		{
			deskRect.top = 0;
			deskRect.bottom = (wharfAutoHide) ? ScreenHeight - hiddenWidth : ScreenHeight - height;
		}
	}
	else
	{
		docked = 0;
		if(setDesktopArea == FALSE)
		{
			deskRect.left = 0;
			deskRect.right = ScreenWidth;
		}
	}
	
	if(docked != oldDocked)
	{
		SystemParametersInfo(SPI_SETWORKAREA, 0, &deskRect, SPIF_SENDCHANGE);
	}
	
	if(wharfAutoHide && docked)
	{
		switch(docked)
		{
		case 1:
			SetWindowPos(HiddenWharf->HiddenWnd, 0, 0, y, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
		case 2:
			SetWindowPos(HiddenWharf->HiddenWnd, 0, ScreenWidth - hiddenWidth, y, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
		case 3:
			SetWindowPos(HiddenWharf->HiddenWnd, 0, x, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
		case 4:
			SetWindowPos(HiddenWharf->HiddenWnd, 0, x, ScreenHeight - hiddenWidth, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
		}
	}
}

void wharfType::OnActivate(Message &message)
{
	if(!wharfCloseOnSwitch)
		return;

	if(wharfs.size() && message.wParamLo == WA_INACTIVE)
	{
		if(!PartOfWharf((HWND)(message.lParam)))
			CloseAllFolders();
	}
}

void wharfType::OnDisplayChange(Message &message)
{
	int RelativeX = ScreenWidth - x;
	int RelativeY = ScreenHeight - y;
	bool MoveRelativeX = RelativeX > (ScreenWidth / 2);
	bool MoveRelativeY = RelativeY > (ScreenHeight / 2);
	CloseAllFolders();
	ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
	ScreenHeight = GetSystemMetrics(SM_CYSCREEN);
	if(MoveRelativeX)
		x = ScreenWidth - RelativeX;
	if(MoveRelativeY)
		y = ScreenHeight - RelativeY;
	SetWindowPos(hMainWnd, HWND_TOPMOST, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
}

void wharfType::OnMove(Message &message)
{
	LPWINDOWPOS lpwp = (LPWINDOWPOS)(message.lParam);

	CloseAllFolders();

	x = lpwp->x;
	y = lpwp->y;

	SetWorkArea();
}

void wharfType::OnShadeToggle(Message &message)
{
	if(closing)
		return;
	CloseAllFolders();
	if(open)
	{
		if(wharfMinSound)
			SoundMin();
		if(wharfNoAnim)
		{
			if(direction == WHARF_DOWN)
				SetWindowPos(hMainWnd, 0, x, y, width, capHeight, SWP_NOZORDER);
			else if(direction == WHARF_RIGHT)
				SetWindowPos(hMainWnd, 0, x, y, capHeight, height, SWP_NOZORDER);
			open = FALSE;
			return;
		}
		closing = TRUE;
		if(direction == WHARF_DOWN)
			movingPos = height;
		else if(direction == WHARF_RIGHT)
			movingPos = width;
		SetTimer(hMainWnd, 1, wharfAnimTime, NULL);
	}
	else
	{
		if(wharfMaxSound)
			SoundMax();
		if(wharfNoAnim)
		{
			SetWindowPos(hMainWnd, 0, x, y, width, height, SWP_NOZORDER);
			open = TRUE;;
			return;
		}
		closing = FALSE;
		movingPos = capHeight;
		SetTimer(hMainWnd, 0, wharfAnimTime, NULL);
	}
}

void wharfType::OnNCHitTest(Message &message)
{
	if(wharfTitlebar)
		message.lResult = HTCAPTION;
	else
		message.lResult = DefWindowProc(hMainWnd, message.uMsg, message.wParam, message.lParam);
}

void wharfType::OnNCLButtonDblClick(Message &message)
{
	if(wharfTitlebar)
	{
		if(direction == WHARF_DOWN)
		{
			if(closing)
			{
				x = wharfDblClickDockOnLeft ? 0 : ScreenWidth - width;
			}
			else
			{
				x = ScreenWidth - wharfDblClickXPosition;
				if(x >= ScreenWidth - width)
					x = ScreenWidth - width;
			}
			y = 0;
			SetWorkArea();
			SendMessage(hMainWnd, LM_SHADETOGGLE, 0, 0);
		}
		else if(direction == WHARF_RIGHT)
		{
			if(closing)
			{
				y = wharfDblClickDockOnLeft ? 0 : ScreenHeight - height;
			}
			else
			{
				y = ScreenHeight - wharfDblClickXPosition;
				if(y >= ScreenHeight - height)
					y = ScreenHeight - height;
			}
			x = 0;
			SetWorkArea();
			SendMessage(hMainWnd, LM_SHADETOGGLE, 0, 0);
		}
	}
}

void wharfType::OnPaint(Message &message)
{
	HBITMAP oldBMP = NULL;
	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hMainWnd,&ps);
	HDC src = CreateCompatibleDC(hdc);

	if(wharfTitlebar && titlebarImage)
	{
		oldBMP = (HBITMAP)SelectObject(src, titlebarImage);

		if(direction == WHARF_DOWN)
			BitBlt(hdc, 0, 0, width, capHeight, src, 0, 0, SRCCOPY);
		else if(direction == WHARF_RIGHT)
			BitBlt(hdc, 0, 0, capHeight, height, src, 0, 0, SRCCOPY);
    
		SelectObject(src, oldBMP);
	}

	EndPaint(hMainWnd,&ps);
	DeleteDC(src);
}

void wharfType::OnPosChanging(Message &message)
{
	//if(wharfTitlebar)
	//{
		LPWINDOWPOS lpwp = (LPWINDOWPOS)(message.lParam);

		if(lpwp->x <= (snapTo ? snapToSensitivity : 0))
			lpwp->x = 0;
		else if(lpwp->x >= ScreenWidth - width - (snapTo ? snapToSensitivity : 0))
			lpwp->x = ScreenWidth - width;

		if(lpwp->y <= (snapTo ? snapToSensitivity : 0))
			lpwp->y = 0;
		else if(lpwp->y >= ScreenHeight - height - (snapTo ? snapToSensitivity : 0))
			lpwp->y = ScreenHeight - height;
	//}
	//else
		//message.lResult = DefWindowProc(hMainWnd, message.uMsg, message.wParam, message.lParam);
}

void wharfType::OnTimer(Message &message)
{
	if(!closing && message.wParam == 0)
	{
		AnimateOpen();
	}
	if(closing && message.wParam == 1)
	{
		AnimateClose();
	}
	if(message.wParam == 4)
	{
		for(int i = 0; i < numWharfs; i++)
		{
			POINT pt;
			GetCursorPos(&pt);
			if(wharfs[i]->bPressed && !wharfs[i]->folder->open && !PtInRegion(hMainRgn, pt.x, pt.y))
				wharfs[i]->TogglePressOffset(FALSE);
		}
	}
}

/*
$Log: wharf.cpp,v $
Revision 1.11.2.4  2000/08/25 22:40:32  NeXTer
See changes.txt

Revision 1.11.2.3  2000/08/25 19:56:44  headius
fixes and rewrites in wharf

Revision 1.11.2.2  2000/08/03 21:35:38  NeXTer
- Added the ability to pause a recycle by holding the shift key
- Added the MB_TOPMOST flag to all messageboxes

Revision 1.11.2.1  2000/07/22 03:37:24  message
*** empty log message ***

Revision 1.11  2000/04/22 04:57:37  message
*** empty log message ***

Revision 1.5  2000/02/24 20:54:13  headius
see changes.txt

Revision 1.1.1.1  2000/01/28 05:57:39  headius
Import of Litestep into new cvs

Revision 1.2  2000/01/21 06:16:15  headius
Tabifying

Revision 1.1  2000/01/17 10:23:25  headius
Update of wharf to be .cpp and to use the new WindowList class
Not thread-safe yet.

  Revision 1.112  2000/01/06 05:26:15  message
  Changed source files back to dos format, somehow had become unix format, updated
  dependencies of desktop to include lsutil, wasn't linking properly because lsutil
  was not being built first.
  
	Revision 1.92  1998/11/17 19:27:39  bryan
	Some more mods and fixes.
	
	  Revision 1.91  1998/11/17 15:13:28  cyberian
	  *** empty log message ***
	  
*/
