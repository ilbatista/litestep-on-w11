Ucho - http://pcla.host.sk/ - ucho3000@poczta.onet.pl
uShort 0.00

uShort is a desktop module for Litestep which alows you to place transparent 
icons on desktop- it's a realy cool thing :)


Configuration

Add in your step.rc following line:
uShortConfig c:\litestep\ushort.cfg
And place there corect path to module settings file. That file has simple syntax:

X Y Transparency
Imagepath
LeftCommand
LeftCommandParram
RightCommand
RightCommandParram


Where:
X,Y- cords of left top corner of icon
Transparency- transparency from 0% to 80 %
LeftCommand, RightCommand- !bang executed after mouseclick
LeftCommandParram, RightCommandParram- and params for bangs
Sample file looks like that:

0 0 20
c:\ikony\wallpaper.bmp
!execute
["e:\my pictures\wallpapers\"]
!none
!none
100 0 20
c:\ikony\mymusic.bmp
!execute
[c:\music\]
!none
!none


As you can see, too add more icons you just have to add more lines.


Icons

Icons can have any dimensions, but they have to be in .bmp format. As usual 
(255,0,255) is transparent color.


Limitations

this version has several limitations:
-only 11 icons support
-area where you can place icons is limited to (0,0)- (500,500)
-there is a bug, which requires you to recycle Litestep after first load


========
This readme file is created with text from Ucho's site.
The package (included added/fixed text in this readme) was created by rootrider.