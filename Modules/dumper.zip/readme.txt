!Dump

Read your logfile to see what it does... nice for user-side memleak tracing ;)

e-sushi@gmx.net
use at own risk!