#define WC_WMP7_MAIN		"WMPlayerApp"
#define WC_WMP7_SKIN		"WMP Skin Host"

#define WMP7_VOLUMEUP		VK_F10
#define WMP7_VOLUMEDOWN		VK_F9
#define WMP7_VOLUMEMUTE		VK_F8

// file
#define WMP7_OPEN			"CTRL+O"
#define WMP7_OPENURL		"CTRL+U"
#define WMP7_CLOSE			"CTRL+W"

#define WMP7_NEXTSONG		"CTRL+F"
#define WMP7_PREVSONG		"CTRL+B"
#define WMP7_REWIND			"CTRL+SHIFT+B"
#define WMP7_FORWARD		"CTRL+SHIFT+F"

#define WMP7_FULLMODE		"CTRL+1"
#define WMP7_COMPACT		"CTRL+2"

#define WMP7_PLAY			"CTRL+P"
#define WMP7_PAUSE			"CTRL+P"
#define WMP7_STOP			"CTRL+S"

#define WMP7_SHUFFLE		"CTRL+H"
#define WMP7_REPEAT			"CTRL+T"

#define WMP7_SEARCHMEDIA	VK_F3