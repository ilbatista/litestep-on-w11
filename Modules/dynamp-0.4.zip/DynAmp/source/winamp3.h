#ifndef __WINAMP3_H
#define __WINAMP3_H

#include "player.h"

#define WC_WINAMP3 "Studio"


#define WA3_PREVSONG	'z'
#define WA3_PLAY		'x'
#define WA3_PAUSE		'c'
#define WA3_STOP		'v'
#define WA3_NEXTSONG	'b'

#define WA3_FILEPLAY	'l'
#define WA3_REPEAT		'r'
#define WA3_SHUFFLE		's'

#define WA3_CROSSFADE	'f'

// shift +
#define WA3_OPENLOC		'l'

// alt +
#define WA3_EDITID3		3

// ctrl +
#define WA3_ONTOP		'a' 
#define WA3_LOADDIR		'l'
#define WA3_DOUBLESIZE	'd'
#define WA3_PREFS		'p'

// vkey
#define WA3_RELOADSKIN	VK_F5
#define WA3_FFWD5S		VK_RIGHT
#define WA3_RWD5S		VK_LEFT
#define WA3_VOLUMEUP	VK_UP
#define WA3_VOLUMEDOWN	VK_DOWN

// class for handling wa3

class wa3 : public player
{
public:
	wa3();
	~wa3();

	HWND GetPlayerWnd();
	void powerOff();

	void repeat();
	void shuffle();

	void prev();
	void play();
	void pause();
	void stop();
	void next();

	void volumeUp();
	void volumeDown();
	void forward5s();
	void rewind5s();

	void openLoc();
	void loadDir();
	void prefs();

	void onTop();
	void loadFile();

	// specific commands:
	static void wa3::Bang_CrossFade(HWND caller, LPCSTR args) {
		mainSendKey(WA3_CROSSFADE);
	}

	static void wa3::Bang_ReloadSkin(HWND caller, LPCSTR args)
	{
		mainSendVKey(WA3_RELOADSKIN);
	}

	// no idea why wa3 doesn't respond to this one...
	static void wa3::Bang_DoubleSize(HWND caller, LPCSTR args) {
		mainSendKey(WA3_DOUBLESIZE, CTRL); // 
	}


	static void wa3::Bang_EditID3(HWND caller, LPCSTR args) {
		mainSendKey(WA3_EDITID3, ALT);
	}

	static void wa3::Bang_ListStart(HWND caller, LPCSTR args) {
		plSendVKey(VK_HOME);
	}

	static void wa3::Bang_ListEnd(HWND caller, LPCSTR args) {
		plSendVKey(VK_END);
	}

	static void wa3::mainSendVKey(short vkey)
	{
		player::sendKey(getMain(), vkey);
	}

	static void wa3::mainSendKey(char ckey, const int mod)
	{
		player::sendKey(getMain(), VkKeyScan(ckey), mod);
	}

	static void wa3::mainSendKey(char ckey)
	{
		player::sendKey(getMain(), VkKeyScan(ckey));
	}

	static void wa3::plSendVKey(short vkey)
	{
		player::sendKey(getPlaylist(), vkey);
	}

	static void wa3::plSendKey(char ckey)
	{
		player::sendKey(getPlaylist(), VkKeyScan(ckey));
	}

	// find main window handle
	static HWND wa3::getMain()
	{
		return FindWindow(WC_WINAMP3, NULL);
	}

	// find PL handle
	static HWND wa3::getPlaylist()
	{
		HWND list = FindWindow("BaseWindow_RootWnd", "Playlist"); 
		if (list != NULL)
		{
			list = GetWindow(list, GW_CHILD);	
			list = GetWindow(list, GW_HWNDLAST);
			return list;
		}
		else return NULL;
	}

private:
	void wa3vKeySequence(short vkey);
	void wa3KeySequence(char ckey);
	void wa3KeySequence(char ckey, const int mod);
};

#endif