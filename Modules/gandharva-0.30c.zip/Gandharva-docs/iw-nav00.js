// JavaScipt for keyboard navigation at Interface Workshop, version 1.0.
// Authour: Takayuki Kawamoto [philsci@jupiter.interq.or.jp]
// Date (from): [2001-10-14 05.32 (JST: GMT+0900) @897]
// Encoding: UTF-8N

var menuData = new Array (
  '01', '/index.html',
  '01', '/sitemap.html',
  '02', '/index.html',
  '02', '/shell-01.html',
  '02', '/shell-02a.html',
  '02', '/shell-02b.html',
  '02', '/shell-03a.html',
  '02', '/shell-03b.html',
  '02', '/shell-03c.html',
  '02', '/shell-04a.html',
  '02', '/shell-04b.html',
  '02', '/shell-04c.html',
  '02', '/shell-05.html',
  '02', '/shell-06a.html',
  '03', '/index.html',
  '03', '/ls-intro-01.html',
  '03', '/ls-intro-02.html',
  '03', '/ls-intro-03.html',
  '03', '/ls-intro-04.html',
  '03', '/ls-intro-05.html',
  '03', '/ls-intro-06.html',
  '03', '/ls-intro-07.html',
  '03', '/ls-intro-08.html',
  '03', '/ls-intro-09.html',
  '03', '/ls-intro-10.html',
  '03', '/tutorial-0246-01.html',
  '03', '/tutorial-0246-02.html',
  '03', '/tutorial-0246-03.html',
  '03', '/tutorial-0246-04.html',
  '03', '/tutorial-0246-05.html',
  '03', '/tutorial-0246-06.html',
  '03', '/tutorial-0246-07.html',
  '03', '/tutorial-0246-08.html',
  '03', '/ls-trans-deskfolders2.html',
  '03', '/ls-trans-systray.html',
  '03', '/ls-trans-chronos.html',
  '03', '/ls-trans-sysvwm.html',
  '03', '/ls-trans-gandharva.html',
  '03', '/ls-trans-lsxcommand.html',
  '03', '/ls-cvs01.html',
  '04', '/index.html',
  '04', '/geo-intro.html',
  '04', '/geo-dev.html',
  '04', '/geo-get.html',
  '04', '/geo-installation.html',
  '04', '/geo-installation-02.html',
  '04', '/geo-settings.html',
  '04', '/geo-plugins.html',
  '04', '/geo-schemes.html',
  '04', '/geo-skins.html',
  '04', '/geo-popup.html',
  '04', '/geo-2chlog01.html',
  '04', '/geo-2chlog02.html',
  '10', '/index.html',
  '10', '/en-winscroll.html',
  '10', '/en-madotate.html',
  '10', '/ja-multidesktop.html',
  '10', '/help.html',
  '20', '/index.html',
  '20', '/screens-01.html',
  '20', '/screens-02.html',
  '20', '/screens-03.html',
  '20', '/screens-04.html',
  '20', '/banner01.html',
  '20', '/banner02.html',
  '20', '/banner03.html',
  '20', '/banner04.html',
  '20', '/banner05.html',
  '20', '/banner06.html',
  '20', '/banner07.html',
  '20', '/banner08.html',
  '98', '/index.html',
  '98', '/faq-iw-ja.html',
  '98', '/faq-env-ja.html',
  '98', '/faq-philsci-ja.html',
  '98', '/help-copy-ja.html',
  '98', '/help-rss-ja.html',
/*
  '98', '/about-ja.html',
  '98', '/about-en.html',
  '98', '/honorary-ja.html',
  '98', '/honorary-en.html',
  '98', '/policies-ja.html',
  '98', '/policies-en.html',
  '98', '/acknowledgements.html',
  '98', '/banners.html',
*/
  '99', '/index.html',
  '99', '/scribbles-2001-12.html',
  '99', '/scribbles-2001-11.html',
  '99', '/scribbles-2001-10sp.html',
  '99', '/scribbles-2001-10.html',
  '99', '/scribbles-2001-09sp.html',
  '99', '/scribbles-2001-09.html',
  '99', '/scribbles-2001-08sp.html',
  '99', '/scribbles-2001-08.html',
  '99', '/scribbles-2001-07sp.html',
  '99', '/scribbles-2001-07.html',
  '99', '/scribbles-2001-06sp.html',
  '99', '/scribbles-2001-06.html',
  '99', '/scribbles-2001-05sp.html',
  '99', '/scribbles-2001-05.html',
  '99', '/scribbles-2001-04sp.html',
  '99', '/scribbles-2001-04.html',
  '99', '/scribbles-2001-03sp.html',
  '99', '/scribbles-2001-03.html',
  '99', '/scribbles-2001-02sp.html',
  '99', '/scribbles-2001-02.html',
  '99', '/scribbles-2001-01.html',
  '99', '/scribbles-2000-12.html',
  '99', '/scribbles-2000-11.html',
  '99', '/scribbles-2000-10.html',
  '99', '/scribbles-2000-09.html',
  '99', '/scribbles-2000-08.html',
  '99', '/scribbles-2000-07.html',
  '99', '/scribbles-2000-03-06.html',
  '0' );

showNav();

function showNav()
  {
  // フロントページではフロントページのキーを表示しないってだけ。
  if ( !(( menuCode == '01' ) && ( pageCode == '/index.html' )) ) {
    document.write('<p><a class=\"topnavi\" accesskey=\"u\" href=\"../iw-html-01/index.html\" title=\"Front\">IW front (U)</a> / ');
  } else {
    document.write('<p>');
  }

  // フロントと同じディレクトリにあるページは、セクションのトップを表示しないで IW フロントだけを表示する。
  if ( !( menuCode == '01' ) && ( pageCode != '/index.html' ) ) document.write('<a class=\"topnavi\" accesskey=\"i\" href=\"../iw-html-' + menuCode + '/index.html\">Sec top (I) / </a>');

  // 直前・直後のページを先に解析する。直前のセクションは同じセクションの index.html を先に見つけてから、
  // 直前のページ（直前のセクションにある最後のページ）にある menuData を元に文字列変数へ代入する。
  for ( countPage = 0; !(menuData[countPage * 2] == '0'); countPage++ ) {
    if ( ( menuCode == menuData[countPage * 2] ) && ( menuData[countPage * 2 + 1] == '/index.html' ) )
      var prevSection = menuData[countPage * 2 - 2] + '/index.html';
    if ( ( menuCode == menuData[countPage * 2] ) && ( pageCode == menuData[countPage * 2 + 1] ) ) {
      for ( sectionCount = 0; !(menuData[countPage * 2 + sectionCount * 2] == '0'); sectionCount++ ) {
        if ( !(menuData[countPage * 2] == menuData[countPage * 2 + sectionCount * 2]) ) {
          var nextSection = menuData[countPage * 2 + sectionCount * 2] + '/index.html';
          break;
        }
      }
      var prevPage = menuData[countPage * 2 - 2] + menuData[countPage * 2 - 1];
      var nextPage = menuData[countPage * 2 + 2] + menuData[countPage * 2 + 3];
      break;
    }
  }

  // IW のフロントセクションは直前のセクションを省く。特にフロントページは直前のページも省く。
  // Scribbles (iw-html-99) は直後のセクションを省く。
    if ( !(menuCode == '01') ) {
      document.write('<a class=\"topnavi\" accesskey=\"h\" href=\"../iw-html-' + prevSection + '\">Prev section (H)</a> / ');
    } else {
      ;
    }
    if ( (menuCode == '01') && (pageCode == '/index.html') ) {
      ;
    } else {
      document.write('<a class=\"topnavi\" accesskey=\"j\" href=\"../iw-html-' + prevPage + '\">Prev page (J)</a> / ');
    }
    if ( !(menuData[countPage * 2 + 2] == '0') ) {
      document.write('<a class=\"topnavi\" accesskey=\"k\" href=\"../iw-html-' + nextPage + '\">Next page (K)</a> / ');
    }
    if ( !(menuCode == '99') ) {
      document.write('<a class=\"topnavi\" accesskey=\"l\" href=\"../iw-html-' + nextSection + '\">Next section (L)</a> / ');
    }
    document.write('<a class=\"topnavi\" accesskey=\"m\" href=\"../iw-html-01/sitemap.html\">Map (M)</a></p>');
  }
