// JavaScipt for navigation at Interface Workshop, version 2.0.
// Authour: Takayuki Kawamoto [philsci@jupiter.interq.or.jp]
// Date (from): [2001-10-14 05.33 (JST: GMT+0900) @898]
// Encoding: UTF-8N

var menuData = new Array (
  '01', '/index.html', 'フロントページ', 'Front',
  '01', '/sitemap.html', 'サイトマップ', 'Sitemap',
  '01', '/iw-news.xml', 'ニューズサイト用の XML バックエンド・ファイル', 'backend XML (RSS)',
  '02', '/index.html', 'シェル', 'Shell',
  '02', '/shell-01.html', 'シェルについて', 'About shell',
  '02', '/shell-02a.html', 'エクスプローラについて(1)', 'About Explorer (1)',
  '02', '/shell-02b.html', 'エクスプローラについて(2)', 'About Explorer (2)',
  '02', '/shell-03a.html', '互換シェルについて(1)', 'About shell replacement (1)',
  '02', '/shell-03b.html', '互換シェルについて(2)', 'About shell replacement (2)',
  '02', '/shell-03c.html', '互換シェルについて(3)', 'About shell replacement (3)',
  '02', '/shell-04a.html', 'シェルを支える構造(1)', 'Structure under shell (1)',
  '02', '/shell-04b.html', 'シェルを支える構造(2)', 'Structure under shell (2)',
  '02', '/shell-04c.html', 'シェルを支える構造(3)', 'Structure under shell (3)',
  '02', '/shell-05.html', 'アカウントごとにシェルを使う', 'Shells per account',
  '02', '/shell-06a.html', '3D のユーザーインターフェイス(1) TaskGallery', '3D UI (1) TaskGallery',
  '03', '/index.html', 'LiteStep です', 'LiteStep',
  '03', '/ls-intro-01.html', '開発の経緯', 'History',
  '03', '/ls-intro-02.html', 'ファイル構成', 'Structure',
  '03', '/ls-intro-03.html', '長所と短所', 'Good and bad',
  '03', '/ls-intro-04.html', 'ショートカット', 'Shortcut',
  '03', '/ls-intro-05.html', '仮想デスクトップ', 'Virtual Desktop',
  '03', '/ls-intro-06.html', 'ウォーフ', 'Wharf',
  '03', '/ls-intro-07.html', 'タスクとトレイ', 'Taskbar and tray',
  '03', '/ls-intro-08.html', 'ポップアップ', 'Popup menu',
  '03', '/ls-intro-09.html', 'その他のモジュール', 'Other modules',
  '03', '/ls-intro-10.html', 'ウェブガイド・海外編', 'References (oversea)',
  '03', '/tutorial-0246-01.html', 'LS Tutorial (1) はじめに', 'Tutorial (1) Introduction',
  '03', '/tutorial-0246-02.html', 'LS Tutorial (2) 用語解説', 'Tutorial (2) Keywords',
  '03', '/tutorial-0246-03.html', 'LS Tutorial (3) どれを使うか', 'Tutorial (3) Builds and distros',
  '03', '/tutorial-0246-04.html', 'LS Tutorial (4) ファイルの入手', 'Tutorial (4) Get LiteStep',
  '03', '/tutorial-0246-05.html', 'LS Tutorial (5) インストール', 'Tutorial (5) Installation',
  '03', '/tutorial-0246-06.html', 'LS Tutorial (6) 設定ファイル', 'Tutorial (6) step.rc and modules.ini',
  '03', '/tutorial-0246-07.html', 'LS Tutorial (7) step.rc の基本', 'Tutorial (7) Basics of step.rc',
  '03', '/tutorial-0246-08.html', 'LS Tutorial (8) モジュールの読み込み', 'Tutorial (8) Load modules',
  '03', '/ls-trans-deskfolders2.html', 'DeskFolders2', 'Deskfolders2',
  '03', '/ls-trans-systray.html', 'Systray', 'Systray',
  '03', '/ls-trans-chronos.html', 'Chronos', 'Chronos',
  '03', '/ls-trans-sysvwm.html', 'SysVWM', 'SysVWM',
  '03', '/ls-trans-gandharva.html', 'Gandharva', 'Gandharva',
  '03', '/ls-trans-lsxcommand.html', 'LSXCommand', 'LSXCommand',
  '03', '/ls-cvs01.html', 'CVS サーバからファイルを取得する (1)', 'How to get LS from CVS server (1)',
  '04', '/index.html', 'geOShell です', 'geOShell',
  '04', '/geo-intro.html', 'geOShell について', 'About geOShell',
  '04', '/geo-dev.html', '作者と開発チーム', 'Development',
  '04', '/geo-get.html', 'geOShell を手に入れる', 'Get geOShell',
  '04', '/geo-installation.html', 'インストール', 'Installation',
  '04', '/geo-installation-02.html', 'R4.7 以降のインストール', 'Installation of R4.7 or later',
  '04', '/geo-settings.html', '基本的な設定', 'Settings',
  '04', '/geo-plugins.html', 'プラグインの導入', 'Plugins',
  '04', '/geo-schemes.html', 'スキーム', 'Schemes',
  '04', '/geo-skins.html', 'スキン', 'Skins',
  '04', '/geo-popup.html', 'ポップアップ・メニュー', 'Popup Menu',
  '04', '/geo-2chlog01.html', '渡辺篤史の geOShell 探訪 (1)', 'Log from 2ch (1)',
  '04', '/geo-2chlog02.html', '渡辺篤史の geOShell 探訪 (2)', 'Log from 2ch (2)',
  '10', '/index.html', '翻訳文書', 'Translations',
  '10', '/en-winscroll.html', 'WinScroll（英語）', 'WinScroll (en)',
  '10', '/en-madotate.html', '窓立て（英語）', 'Madotate (en)',
  '10', '/ja-multidesktop.html', 'MultiDesktop Manager（日本語）', 'MultiDesktop Manager (ja)',
  '10', '/help.html', 'ヘルプ', 'Help (en)',
  '20', '/index.html', '作業場', 'Workshop',
  '20', '/screens-01.html', 'スクリーン集 1', 'Screens 1',
  '20', '/screens-02.html', 'スクリーン集 2', 'Screens 2',
  '20', '/screens-03.html', 'スクリーン集 3', 'Screens 3',
  '20', '/screens-04.html', 'スクリーン集 4', 'Screens 4',
  '20', '/banner01.html', 'バナーを作ろう (1)', 'Make your banner (1)',
  '20', '/banner02.html', 'バナーを作ろう (2)', 'Make your banner (2)',
  '20', '/banner03.html', 'バナーを作ろう (3)', 'Make your banner (3)',
  '20', '/banner04.html', 'バナーを作ろう (4)', 'Make your banner (4)',
  '20', '/banner05.html', 'バナーを作ろう (5)', 'Make your banner (5)',
  '20', '/banner06.html', 'バナーを作ろう (6)', 'Make your banner (6)',
  '20', '/banner07.html', 'バナーを作ろう (7)', 'Make your banner (7)',
  '20', '/banner08.html', 'バナーを作ろう (8)', 'Make your banner (8)',
  '98', '/index.html', 'ヘルプと注意書き', 'Help and Info',
  '98', '/faq-iw-ja.html', 'IW についてよくある質問（日本語）', 'IW FAQ (ja)',
  '98', '/faq-env-ja.html', 'IW の制作環境についてよくある質問（日本語）', 'Environment of IW FAQ (ja)',
  '98', '/faq-philsci-ja.html', 'philsci についてよくある質問（日本語）', 'philsci FAQ (ja)',
  '98', '/help-copy-ja.html', '著作権について（日本語）', 'Copyright/left (ja)',
  '98', '/help-rss-ja.html', 'RSS について（日本語）', 'RSS (ja)',
/*
  '98', '/about-ja.html', 'このウェブサイトについて', 'About this website (ja)',
  '98', '/about-en.html', 'About this website', 'About this website (en)',
  '98', '/honorary-ja.html', '参照してくれたみなさん', 'Honorary (ja)',
  '98', '/honorary-en.html', 'Honorary', 'Honorary (en)',
  '98', '/policies-ja.html', 'プライバシーや編集上の方針', 'Policies (ja)',
  '98', '/policies-en.html', 'Policies', 'Policies (en)',
  '98', '/acknowledgements.html', '謝辞', 'Acknowledgements',
  '98', '/banners.html', 'バナー', 'Banners',
*/
  '99', '/index.html', '落書き', 'Scribbles',
  '99', '/scribbles-2001-12.html', '2001年12月分', 'December, 2001',
  '99', '/scribbles-2001-11.html', '2001年11月分', 'November, 2001',
  '99', '/scribbles-2001-10sp.html', '2001年10月スペシャル', 'October, 2001 (special)',
  '99', '/scribbles-2001-10.html', '2001年10月分', 'October, 2001',
  '99', '/scribbles-2001-09sp.html', '2001年9月スペシャル', 'September, 2001 (special)',
  '99', '/scribbles-2001-09.html', '2001年9月分', 'September, 2001',
  '99', '/scribbles-2001-08sp.html', '2001年8月スペシャル', 'August, 2001 (special)',
  '99', '/scribbles-2001-08.html', '2001年8月分', 'August, 2001',
  '99', '/scribbles-2001-07sp.html', '2001年7月スペシャル', 'July, 2001 (special)',
  '99', '/scribbles-2001-07.html', '2001年7月分', 'July, 2001',
  '99', '/scribbles-2001-06sp.html', '2001年6月スペシャル', 'June, 2001 (special)',
  '99', '/scribbles-2001-06.html', '2001年6月分', 'June, 2001',
  '99', '/scribbles-2001-05sp.html', '2001年5月スペシャル', 'May, 2001 (special)',
  '99', '/scribbles-2001-05.html', '2001年5月分', 'May, 2001',
  '99', '/scribbles-2001-04sp.html', '2001年4月スペシャル', 'April, 2001 (special)',
  '99', '/scribbles-2001-04.html', '2001年4月分', 'April, 2001',
  '99', '/scribbles-2001-03sp.html', '2001年3月スペシャル', 'March, 2001 (special)',
  '99', '/scribbles-2001-03.html', '2001年3月分', 'March, 2001',
  '99', '/scribbles-2001-02sp.html', '2001年2月スペシャル', 'February, 2001 (special)',
  '99', '/scribbles-2001-02.html', '2001年2月分', 'February, 2001',
  '99', '/scribbles-2001-01.html', '2001年1月分', 'January, 2001',
  '99', '/scribbles-2000-12.html', '2000年12月分', 'December, 2000',
  '99', '/scribbles-2000-11.html', '2000年11月分', 'November, 2000',
  '99', '/scribbles-2000-10.html', '2000年10月分', 'October, 2000',
  '99', '/scribbles-2000-09.html', '2000年9月分', 'September, 2000',
  '99', '/scribbles-2000-08.html', '2000年8月分', 'August, 2000',
  '99', '/scribbles-2000-07.html', '2000年7月分', 'July, 2000',
  '99', '/scribbles-2000-03-06.html', '2000年3月-6月分', 'From March to June in 2000',
  'turnstile', '/index.html', 'リンク集のつもり', 'turnstile',
  '0' );

showMenu();

function affiliatesWin() {
  window.open("../iw-html-01/affiliates.html","affiliates","width=300,height=300,status=yes,resizable=yes");
  }

function showMenu() {
  document.write('<p><span class=\"subtitle\">Menu</span><br />');
  for (countData = 0; !(menuData[ 4 * countData ] == '0'); countData++) {
    if (menuCode == menuData[ 4 * countData ]) {
      if (menuData[ 4 * countData + 1 ] == pageCode) {
        if (menuData[ 4 * countData + 1 ] == '/index.html') {
          document.write('<span class=\"active\">' + menuData[ 4 * countData + 3 ] + '</span><br />');
          } else {
          document.write('<span class=\"active\">:: ' + menuData[ 4 * countData + 3 ] + '</span><br />');
          }
        } else {
          if (menuData[ 4 * countData + 1 ] == '/index.html') {
            document.write('<a href=\"../iw-html-' + menuData[ 4 * countData ] + menuData[ 4 * countData + 1 ] + '\" title=\"' + menuData[ 4 * countData + 2 ] + '\">' + menuData[ 4 * countData + 3 ] + '</a><br />');
            } else {
            document.write('<a href=\"../iw-html-' + menuData[ 4 * countData ] + menuData[ 4 * countData + 1 ] + '\" title=\"' + menuData[ 4 * countData + 2 ] + '\">:: ' + menuData[ 4 * countData + 3 ] + '</a><br />');
            }
        }
      } else {
        if (menuData[ 4 * countData + 1 ] == '/index.html') {
            document.write('<a href=\"../iw-html-' + menuData[ 4 * countData ] + menuData[ 4 * countData + 1 ] + '\" title=\"' + menuData[ 4 * countData + 2 ] + '\">' + menuData[ 4 * countData + 3 ] + '</a><br />');
          }
        }
      }
    document.write('</p>');
    document.write('<p><a href=\"../iw-html-06/index.html\" title=\"LiteStep 日本語化プロジェクトのサイト ver.2\">litestep jpn</a><br />');
    document.write('<a href=\"../iw-html-xswv/index.html\" title=\"旧 XSWeekly のアーカイブ\">XSWeekly Virgule</a><br />');
    document.write('<a href=\"../tek-html/index.html\" title=\"Teknidermy Japan\">Teknidermy Japan</a><br />');
    document.write('</p>');
    document.write('<p><span class=\"subtitle\">Affiliates</span><br />');
    document.write('<a href=\"http://digilander.iol.it/alphaos/\">alphaLS</a><br />');
    document.write('<a href=\"http://www.cv.cs.ritsumei.ac.jp/~hirohisa/\">Blue Topaz</a><br />');
    document.write('<a href=\"http://customize.virtualave.net/\">Customize Zone</a><br />');
    document.write('<a href=\"http://desktopian.org/\">desktopian.org</a><br />');
    document.write('<a href=\"http://floach.pimpin.net/\">floach.pimpin.net</a><br />');
    document.write('<a href=\"http://geo-navi.dyndns.org/\">geO Navi</a><br />');
    document.write('<a href=\"http://joeblade.com/paul/\">la haine</a><br />');
    document.write('<a href=\"http://www.layer13.com/\">Layer13.com</a><br />');
//    document.write('<a href=\"http://why.litestep.com/\">LiteStep Distro for People</a><br />');
    document.write('<a href=\"http://www.edp.eng.tamagawa.ac.jp/~todoroki/litestep/\">LiteStep World in Japan</a><br />');
    document.write('<a href=\"http://www5.ocn.ne.jp/~maskman/ls/top.html\">ls mod doc dog</a><br />');
    document.write('<a href=\"http://www.mzks.org/\">mzks.org</a><br />');
    document.write('<a href=\"http://shellcity.net/\">Shell Extension City</a><br />');
    document.write('<a href=\"http://www.shellfront.org/\">ShellFront.org</a><br />');
    document.write('<a href=\"http://www.teknidermy.org/\">TEKNIDERMY Magazine</a><br />');
    document.write('<a href=\"http://www.virtualplastic.net/\">Virtual Plastic</a><br />');
    document.write('<a href=\"javascript:affiliatesWin();\" title=\"Banners of affiliate websites\">[Or banners!]</a>');
    document.write('</p>');
    document.write('<p><span class=\"subtitle\">Shells / mgrs</span><br />');
    document.write('<a href=\"http://www.cloud9ine.com/\" title=\"Cloud:9ine home\">Cloud:9ine (R3.5 RC1)</a><br />');
    document.write('<a href=\"http://home.student.uu.se/c/cace4851/core/core.php3\" title=\"Core Shell home\">Core Shell (release 1.2)</a><br />');
    document.write('<a href=\"http://www.geoshellx.com/\" title=\"geOShell home\">geOShell</a><br />');
    document.write('<a href=\"http://website.lineone.net/~pdw63/\" title=\"pdw63 build\">- beta 4.7 (pdw63)</a><br />');
    document.write('<a href=\"http://www.fragmentized.com/jaykul/geoshell/\" title=\"Jaykul build\">- beta 4.8 (Jaykul et al.)</a><br />');
    document.write('<a href=\"http://www.shellcity.net/go/go.htm\" title=\"home of GO\">GO (version 0.1)</a><br />');
    document.write('<a href=\"http://www.labyrinth.net.au/~mosses/liteshell/\" title=\"Liteshell home\">Liteshell (0.6a)</a><br />');
    document.write('<a href=\"http://lsdev.org/\" title=\"LiteStep dev team\">LiteStep (0.24.6 preview)</a><br />');
    document.write('<a href=\"http://www.litestep.com/\" title=\"LiteStep.com\">- litestep.com</a></br />');
    document.write('<a href=\"http://www.litestep.net/\" title=\"LiteStep.net\">- litestep.net</a></br />');
    document.write('<a href=\"http://www.muukka.net/multidesktop/\" title=\"MultiDesktop Manager\">MultiDesktop Manager (0.3.4)</a><br />');
    document.write('<a href=\"http://207.253.56.34/OpenVision/index.html\" title=\"Open Vision home\">Open Vision (release 1.41)</a><br />');
    document.write('<a href=\"http://raptor.cybersnot.com/\" title=\"Raptor home\">Raptor</a><br />');
    document.write('<a href=\"http://www.lowdimension.net/\" title=\"SharpE home\">SharpE (prebeta 2)</a><br />');
    document.write('<a href=\"http://sourceforge.net/projects/snf/\" hreflang=\"ja\" title=\"すなふきん\">Snafkin (build 4.7.3)</a><br />');
    document.write('<a href=\"http://digilander.iol.it/alphaos/snafkin/snafkin.html\" title=\"Snafkin English version\">Snafkin (en, build 4.7.3.1e)</a><br />');
    document.write('<a href=\"http://www.lighttek.com/\" title=\"Talisman\">Talisman (2.0)</a><br />');
    document.write('<a href=\"http://www.zeronet.tv/\" title=\"Zero\">Zero (beta 2)</a>');
    document.write('</p>');
    document.write('<p><img src=\"../iw-img-01/bnr-iw05.png\" width=\"90\" height=\"30\" alt=\"IW banner\" style=\"margin: 2px\" /><br />');
    document.write('<a href=\"http://manifesto.lockergnome.com/\"><img src=\"../iw-img-01/bnr-manifesto.png\" width=\"88\" height=\"31\" alt=\"Libera Manifesto\" style=\"margin: 2px\" /></a><br />');
    document.write('<a href=\"https://members.ud.com/\"><img src=\"../iw-img-01/bnr-tlg.png\" width=\"90\" height=\"30\" alt=\"Join us!\" style=\"margin: 2px\" /></a><br />');
    document.write('<a href=\"http://www.shellfront.org/shellcon/\"><img src=\"../iw-img-01/bnr-shellcon.png\" width=\"101\" height=\"27\" alt=\"ShellCon Northwest 2002\" style=\"margin: 2px\" /></a><br />');
    document.write('<a href=\"http://www.sam.hi-ho.ne.jp/itakura/ring.html\" target=\"_top\"><img src=\"../iw-img-01/bnr-lsring.png\" width=\"90\" height=\"30\" alt=\"LiteStep Webring in Japan\" style=\"margin: 2px\" /></a><br />');
    document.write('<a href=\"http://www.webring.ne.jp/cgi-bin/webring?ring=litestep;list\" target=\"_top\">list</a> / <a href=\"http://www.webring.ne.jp/cgi-bin/webring?ring=litestep;id=5;next\" target=\"_top\">next</a>');
    document.write('</p>');
//    document.write('<p class=\"image\"><a href=\"../iw-img-01/ssb.png\"><img src=\"../iw-img-01/sss.png\" width=\"160\" height=\"120\" alt=\"current desktop\" /></a><br />2001-12-03</p>');
  return true;
  }
