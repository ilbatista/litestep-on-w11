GESTURES.DLL 1.2.0
------------------


1. What is it?
--------------

Gestures implements simple mouse stroke controlling system, same
that can be found in Opera browser, at system level.



2. How it works?
----------------

1. Right click with your mouse everywhere on desktop or any window
and start drag (or "paint") your gesture
(You can define another mouse button, define keyboard hotkey or even
combine mouse-click with hotkeys).

2. As long as underlying window is not in list of excluded windows
(hardcoded or defined, see below), you can see that your gesture is
painted onto screen as thin line.

3. To finish your gesture, you will release mouse button (or release
hotkey).

4. Now, if you managed to draw your gesture correctly, module will
search predefined list of gestures and will do appropriate action,
if any match has been found.

5. The line symbolising the gesture is cleared up.

6. If timeout expires during gesture drawing or gesture is not found
in the list, nothing happens.



3. Notes
--------

1. If you interrupt drawing your gesture for too long, timeout will
expire and nothing happens. You will be notified with the sound about
this. Sound and timeout values are configurable.


2. Gestures module will capture your mouse click. If you like to drag
with your right mouse button (files in explorer, for example), there are
several ways how to avoid conflicts:

a) You can just right-click and wait a moment for timeout to expire
(it is very short time period) and after you hear the timeout sound,
you can drag your files as usual. Simple right click (without dragging)
works just normal, as usual.

b) You can also define different mouse-button (though right button is
default) or define keyboard hotkeys that may be used standalone or
in combination with mouse-click.

c) You can add Explorer file-management-area to windows exclusion list
so gestures module will be inactive if your mouse is over Eplorer window
(see example below).


3. As you will see later in the document, there are some predefined
actions for every mouse gesture.


4. How to define gestures?
--------------------------

To define gestures, imagine 3 to 3 matrix:

 1 2 3
 4 5 6
 7 8 9

and imaginary put your mouse movement into it, you will get resulting
sequence:

so, to define "L" gesture, it is 14789
to define "U" gesture, it is 1478963
to define "Z" gesture, it is 1235789
and so on.

you may define more gestures on one line, first gesture recognized
will be used. it is useful when you have more complex (or circular)
gestures that may be recognized in more ways, for example for "L"
gesture, it may be 14789, 1478, or 4789, depending on its symmetric
proportions.

same as for "C", it may be 3214789, or 32489, or 324789 or 321489, or
214789... etc.


5. How to set gestures in STEP.RC?
----------------------------------

See enclosed EXAMPLE.RC file for more complex examples.

Notice I named all commands beginning with "stroke" here, which
is synonym for "gesture". Don't ask my why, I don't remember... ;-)

Parameters:
------------------

GesturesTrail boolean
	Switch gesture trail drawing on.

GesturesTrailWidth n
	Gesture trail width in pixels. Minimum 1, maximum 20.

GesturesTrailColor 0000FF
	Color of gesture trail. Default is FF0000 (red).

GesturesTrailDrawMode 0|1
	Drawing mode of gesture trail. 0 means XOR mode (inverting color),
	1 means COPY mode (painting over).

GesturesNotifySound c:\sounds\down.wav
	Sound that will be played after successful gesture recognition.

GesturesTimeoutSound c:\sounds\msgback.wav
	Sound that will be played after gesture-timeout.

GesturesTimeout 400
	Gesture timeout in milliseconds.
	Default is 500ms.

GesturesReversed boolean
	Reverse definition matrix in Y-axe, so you can easily use
	numeric-keypad as visual reference for creating new gestures.
	The matrix is then as follows:

 7 8 9
 4 5 6
 1 2 3

GesturesNoExcludes boolean
	Disables checking for window in exclusion list.

GesturesNoDefaultExcludes boolean
	Disables checking for default hard-coded window exclusions
	(for instance excluding wharf, desktop, shortcut, popup from
	.close action, etc.).

GesturesExcludeSound sound_filename
	Sound that will be played when underlying window has been found
	in exclusion list.

GesturesNotifySound sound_filename
	Sound that will be played when gesture has been succesfully
	recognized.

GesturesTimeoutSound sound_filename
	Sound that will be played after gesture timeout.

GesturesButton 0|1|2|3
	Define mouse button that must be pressed to iniciate stroke.
		0 = No button. In this case, hotkey should be defined
		1 = Left button
		2 = Right button
		3 = Middle button
	Button combinations are not supported.
	Default is 2.

GesturesHotkey hotkey|hotkey_combination
	Define keyboard key that must be pressed to iniciate stroke.
	It can be Shift, Alt, Ctrl or combination of these
	(use + or | as separator).
	It can be used in combination with StrokeButton, or may work
	as standalone activation key if StrokeButton is 0.
	Default is no-hotkey.

GesturesMinimumSize n
	Minimum size of stroke. Default is 100 pixels.

GesturesBoostPriority boolean
	Boosts gesture module priority when trail drawing starts.
	Experimental feature.

GesturesUseFreeMove boolean
	Guru mode. Only for mighty mouse-man. Gesture recognition is
	working continuously, without need of gesture activation by
	button or hotkey.
	In this mode it is very important to setup free-move gestures
	reasonably non-trivial and with reasonable minimum size,
	to avoid 'false positives'.
	Use with common sense, very powerful...
	Try to bind action .exec "!alert gesture?" to 456 or 654 gesture.
	Very funny... :-)


Definition:
------------

Possible gesture definition can look like this. Read further for detailed
description of each command and modifier (<> means mandatory parameter,
[] optional parameter):

	*stroke <"gesture_name"> <gesture_sequence> [gesture_sequence2 ...]
	*stroke action <action_parameter> [command_parameters]
	*stroke flags <flags_list>
	*stroke win_module <module_name>
	*stroke win_class <window_class-name>
	*stroke win_title <window_title>
	*stroke minsize <size_in_pixels>
	*stroke ~

Example:

	*stroke "opera-reload" 9874123 98423 987423 984123
	*stroke flags	f
	*stroke	action	.sendkeys <F5>
	*stroke win_mod	"*opera.exe"
	*stroke minsize	200
	*stroke ~

Actions:
--------
action_parameter can be bang-command, or one of predefined actions:

.maximize
	Maximize window under cursor

.minimize
	Minimize window under cursor

.restore
	Restore window under cursor to its normal size

.close
	Close window (application) under cursor

.browseBack
	Browser back function - actually sends Alt+Left to window under cursor

.browseForward
	Browser forward function - actually sends Alt+Right to window under cursor

.browseReload
	Browser reload function - actually sends Ctrl+R to window under cursor

.exec c:\dev\shutdown.lnk
	Execute program or document. Prefix with @ to run program hidden.

.sendKeys keys_sequence
	Send sequence of keyboard presses/releases to underlying window.
	Sequence may look like this: <alt>p</alt><delay 10><ctrl><F1></ctrl>some text<enter>
	Keyboard names and codes are read from file specified either with GesturesVKTable variable
	or by jKeyVKTable variable (used by jkey.dll). If GesturesVKTable variable is specified,
	it wins over jKeyVKTable.

!bangCommand
	Any bang command

Flags:
------

Flags modify gesture behaviour. Flags should be listed without spaces.

F	Free-move gesture

D	Disable gesture


Windows binding:
----------------

Any gesture can be bound to just one window using win_mod, win_class, win_title commands.

win_mod
	Name of module (executable) with or without path. Wildcards '*' and '?' can be used.
	For example:
		*stroke win_mod "*/opera.exe"
	will allow the gesture to be executed on opera windows only.

win_class
	Class name of window. Wildcards '*' and '?' can be used.

win_title
	Window title. Wildcards '*' and '?' can be used.


Commands:
---------

*StrokeExcludeWin "window_executable" "window_class_name" "window_title"

	Define window/application that will not react on gestures. Wildcards
	(*,?) may be used. Window is matched if all parameters match.

	For instance, you can exclude Explorer windows file management area:

		*StrokeExcludeWin "*\explorer.exe" "Sys????View32" ""

	These exclusions are used by default (hardcoded):

		*StrokeExcludeWin "*\opera.exe" "" ""

	For spying windows executable-name, class and title, you can use
	Spy32 from http://come.to/kobik/.
	Though this program cannot display executable name (module name)
	under WindowsNT (v 2.70). If you know about another window-spying
	program that can, please let me know.


Bangs:
------

!GesturesEnable
!GesturesDisable
!GesturesToggle
!GesturesExecute


6. Known problems and issues
----------------------------

Version prior to 1.2:
	Conflicting with EASYMOVE.DLL. Load EASYMOVE.DLL after GESTURES, otherwise
	Easymove is not able to capture right mouse button for window resizing.
	Solved in 1.2.


7. Upgrading
------------

Upgrading from version 1.1.x to 1.2:
	1. StrokeXXXX commands have been renamed to GesturesXXXX. Rename your setting
	in step.rc.

	2. kmhook.dll is no more used. Gestures_hook.dll is the new hooking library and
	should be present in the same directory. It is not a litestep module, do not try
	to load it. Gestures will take care of this.


8. Acknowledgements
-------------------

Module uses GPLed library LIBSTROKE:
http://www.etla.net/~willey/projects/libstroke/

If you are interested in gesture recognition techniques, here are some
links:
http://www.etla.net/~willey/
http://www.mit.edu/people/cadet/strokes-algorithm.html
http://www.etla.net/libstroke/libstroke.pdf
http://www.etla.net/libstroke/sloppy.html
http://www.stressbunny.com/wayv/
http://sa-1.enteract.com/~mghall/tcltk/tcltk.html


9. Credits
----------

author: Pavel Vitis, (c)2001-2005
e-mail: pavel.vitis@seznam.cz
web   : http://pavelvitis.no-ip.org/litestep/
