#if !defined(AFX_MYHTMLVIEW_H__9ECC9099_BEB2_468A_A464_1AB6E4320027__INCLUDED_)
#define AFX_MYHTMLVIEW_H__9ECC9099_BEB2_468A_A464_1AB6E4320027__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyHTMLView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// MyHTMLView window

class MyHTMLView : public CWnd
{
// Construction
public:
	MyHTMLView();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(MyHTMLView)
	//}}AFX_VIRTUAL

// Implementation
public:
	char wname[1024];
	HRESULT Refresh2(VARIANT *Level);
	void Navigate2(LPCTSTR lpszURL, DWORD dwFlags = 0, LPCTSTR lpszTargetFrameName = NULL, LPCTSTR lpszHeaders = NULL, LPVOID lpvPostData = NULL, DWORD dwPostDataLen = 0);
	bool CreateMe(HWND hParent, char *name, const RECT &r, bool bVisible);
	IWebBrowser2* m_pBrowserApp;
	CWnd m_wndBrowser;
	virtual ~MyHTMLView();
	bool visible;

	// Generated message map functions
protected:
	//{{AFX_MSG(MyHTMLView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYHTMLVIEW_H__9ECC9099_BEB2_468A_A464_1AB6E4320027__INCLUDED_)
