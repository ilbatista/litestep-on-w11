// oborzevatel.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "oborzevatel.h"
#include "..\ils\lsapi\lsapi.h"

#include "myhtmlview.h"

extern "C" {
    __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
    __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

void bangShowWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangHideWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangToggleVisibility(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangRefreshWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangRefreshIfExpired(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);
void bangRefreshCompletely(HWND hSender, LPCSTR szCommand, LPCSTR szArgs);

COborzevatelApp theApp;

BEGIN_MESSAGE_MAP(COborzevatelApp, CWinApp)
	//{{AFX_MSG_MAP(COborzevatelApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

COborzevatelApp::COborzevatelApp()
{
}

BOOL COborzevatelApp::InitInstance() 
{
	AfxEnableControlContainer();
	return CWinApp::InitInstance();
}

bool COborzevatelApp::CreateBrowserWindow(HWND hParent,char *wname)
{
	RECT r;
	char s[1024];
	char buf[1024];
	int lb;
	sprintf(s,"%sX",wname);
	r.left = GetRCCoordinate(s, 0, GetSystemMetrics(SM_CXSCREEN));
	sprintf(s,"%sY",wname);
	r.top  = GetRCCoordinate(s, 0, GetSystemMetrics(SM_CYSCREEN));
	sprintf(s,"%sWidth",wname);
	r.right = r.left + GetRCInt(s, 100);
	sprintf(s,"%sHeight",wname);
	r.bottom = r.top + GetRCInt(s, 100);
	sprintf(s,"%sHidden",wname);
	bool bVisible = !GetRCBoolDef(s,false);

	MyHTMLView *w = new MyHTMLView;
	if(NULL != w)
	{
		if (w->CreateMe(hParent,wname,r,bVisible))
		{
			sprintf(s,"%sURL",wname);
			GetRCLine(s,buf,1024,"http://www.litestep.net/");
			lb = strlen(buf);
			if (lb>0 && buf[lb-1] == '"') buf[lb-1] = 0;
			if (buf[0] == '"')
				w->Navigate2(_T(buf+1),NULL,NULL);
			else
				w->Navigate2(_T(buf),NULL,NULL);
			wlist.insert(wlist.end(),w);
			sprintf(s,"!%sShow",wname);
			AddBangCommandEx(s,bangShowWindow);
			sprintf(s,"!%sHide",wname);
			AddBangCommandEx(s,bangHideWindow);
			sprintf(s,"!%sToggleVisibility",wname);
			AddBangCommandEx(s,bangToggleVisibility);
			sprintf(s,"!%sRefresh",wname);
			AddBangCommandEx(s,bangRefreshWindow);
			sprintf(s,"!%sRefreshIfExpired",wname);
			AddBangCommandEx(s,bangRefreshIfExpired);
			sprintf(s,"!%sRefreshCompletely",wname);
			AddBangCommandEx(s,bangRefreshCompletely);
			return true;
		}
		else
			MessageBox(0,"Errr... Cannot create IE window...","Oborzevatel: Fatal Error :((",0);
	}
	else
		MessageBox(0,"Errr... Cannot create a CWnd... suppose that not enough system resources","Oborzevatel.dll: Fatal Error :((",0);
	return false;
}

int COborzevatelApp::ShowHMTLWindows(HWND hParent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	HWND hWndToUse = GetLitestepWnd();	

	FILE *f;
	int crs;
	int i;
	char curname[1024];
	if(f = LCOpen(NULL))
	{
		char lineBuffer[MAX_LINE_LENGTH];
		while(LCReadNextConfig(f, "OborzevatelWindows", lineBuffer, MAX_LINE_LENGTH))
		{
			char* buffers[1];
			char commandName[64] = { 0 };
			buffers[0] = commandName;
			char value[MAX_LINE_LENGTH];
			LCTokenize(lineBuffer, buffers, 1, value);
			if(value[0] && _stricmp("OborzevatelWindows",commandName) == 0)
			{
				crs = 0;
				while(value[crs])
				{
					curname[crs] = 0;
					i = 0;
					while (isalnum(value[crs]) || value[crs] == '.' || value[crs] == '_')
					{
						curname[i] = value[crs];
						crs++;
						i++;
					}
					curname[i] = 0;
					CreateBrowserWindow(hWndToUse,curname);
					while (value[crs] && !isalnum(value[crs]) && value[crs] != '.' && value[crs] != '_')	crs++;
				}
			}
		}

		LCClose(f);
	} else MessageBox(NULL,"Oooops!!!","Oborzevatel",MB_OK);
	return true;
}

void COborzevatelApp::QuitModule()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	for(WndListIterator wi = wlist.begin(); wi != wlist.end(); wi++)
		delete *wi;
	wlist.clear();
}

int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
	return theApp.ShowHMTLWindows(parent);
}


void quitModule(HINSTANCE dllInst)
{
	theApp.QuitModule();
}


MyHTMLView * COborzevatelApp::LookupWnd(const char *name)
{
	for(WndListIterator wi = wlist.begin(); wi != wlist.end(); wi++)
	{
		if(_stricmp(name, (*wi)->wname) == 0)
			return *wi;
	}
	return NULL;
}

void COborzevatelApp::BangShowWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 5).c_str());
	if(w != 0)
	{
		w->ShowWindow(SW_SHOW);
		w->visible = true;
	}
}

void COborzevatelApp::BangHideWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 5).c_str());
	if(w != 0)
	{
		w->ShowWindow(SW_HIDE);
		w->visible = false;
	}
}

void COborzevatelApp::BangToggleVisibility(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 17).c_str());
	if(w != 0)
	{
		if (w->visible)
			w->ShowWindow(SW_HIDE);
		else
			w->ShowWindow(SW_SHOW);
		w->visible = !w->visible;
	}
}

void COborzevatelApp::BangRefreshWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	VARIANT rlevel;
	rlevel.intVal = REFRESH_NORMAL;
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 8).c_str());
	if(w != 0)
		w->Refresh2(&rlevel);
}

void COborzevatelApp::BangRefreshIfExpired(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	VARIANT rlevel;
	rlevel.intVal = REFRESH_IFEXPIRED;
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 17).c_str());
	if(w != 0)
		w->Refresh2(&rlevel);
}

void COborzevatelApp::BangRefreshCompletely(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	VARIANT rlevel;
	rlevel.intVal = REFRESH_COMPLETELY;
	string wname = string(szCommand);
	MyHTMLView *w = LookupWnd(wname.substr(1, wname.length() - 22).c_str());
	if(w != 0)
		w->Refresh2(&rlevel);
}


void bangShowWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangShowWindow(hSender,szCommand,szArgs);
}

void bangHideWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangHideWindow(hSender,szCommand,szArgs);
}

void bangToggleVisibility(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangToggleVisibility(hSender,szCommand,szArgs);
}

void bangRefreshWindow(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangRefreshWindow(hSender,szCommand,szArgs);
}

void bangRefreshIfExpired(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangRefreshIfExpired(hSender,szCommand,szArgs);
}

void bangRefreshCompletely(HWND hSender, LPCSTR szCommand, LPCSTR szArgs)
{
	theApp.BangRefreshCompletely(hSender,szCommand,szArgs);
}
