#ifndef __UTILITY_HEADER__
#define __UTILITY_HEADER__

//void globModifyStyle(HWND hWnd, DWORD removeStyle, DWORD addStyle);

#endif