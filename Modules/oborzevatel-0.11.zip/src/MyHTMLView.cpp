// MyHTMLView.cpp : implementation file
//

#include "stdafx.h"
#include "oborzevatel.h"
#include "MyHTMLView.h"
#include "..\ils\lsapi\lsapi.h"
#include "utility.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MyHTMLView

MyHTMLView::MyHTMLView()
{
}

MyHTMLView::~MyHTMLView()
{
	if (m_pBrowserApp != NULL)
		m_pBrowserApp->Release();
	char s[1024];
	sprintf(s,"!%sShow",wname);
	RemoveBangCommand(s);
	sprintf(s,"!%sHide",wname);
	RemoveBangCommand(s);
	sprintf(s,"!%sToggleVisibility",wname);
	RemoveBangCommand(s);
	sprintf(s,"!%sRefresh",wname);
	RemoveBangCommand(s);
	sprintf(s,"!%sRefreshIfExpired",wname);
	RemoveBangCommand(s);
	sprintf(s,"!%sRefreshCompletely",wname);
	RemoveBangCommand(s);
}


BEGIN_MESSAGE_MAP(MyHTMLView, CWnd)
	//{{AFX_MSG_MAP(MyHTMLView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// MyHTMLView message handlers

bool MyHTMLView::CreateMe(HWND hParent, char *name, const RECT &r, bool bVisible)
{
	strcpy(wname,name);
	CString txtClassName = AfxRegisterWndClass(CS_DBLCLKS);
	UINT nStyleEx = WS_EX_TOOLWINDOW;
	UINT nStyle = WS_POPUP;
	if (bVisible)	nStyle |= WS_VISIBLE;
	visible = bVisible;
	if(CreateEx(nStyleEx, txtClassName, wname, nStyle, r.left, r.top, r.right, r.bottom, hParent, 0))
	{
		AfxEnableControlContainer();
		RECT rectClient;
		GetClientRect(&rectClient);
		if (!m_wndBrowser.CreateControl(CLSID_WebBrowser, wname,
					WS_VISIBLE | WS_CHILD, rectClient, this, AFX_IDW_PANE_FIRST))
		{
			DestroyWindow();
			return false;
		}
		LPUNKNOWN lpUnk = m_wndBrowser.GetControlUnknown();
		HRESULT hr = lpUnk->QueryInterface(IID_IWebBrowser2, (void**) &m_pBrowserApp);
		if (!SUCCEEDED(hr))
		{
			m_pBrowserApp = NULL;
			m_wndBrowser.DestroyWindow();
			DestroyWindow();
			return false;
		}
		return true;
	}
	return false;
}

void MyHTMLView::Navigate2(LPCTSTR lpszURL, DWORD dwFlags, LPCTSTR lpszTargetFrameName, LPCTSTR lpszHeaders, LPVOID lpvPostData, DWORD dwPostDataLen)
{
	COleSafeArray vPostData;
	if (lpvPostData != NULL)
	{
		if (dwPostDataLen == 0)
			dwPostDataLen = lstrlen((LPCTSTR) lpvPostData);
		vPostData.CreateOneDim(VT_UI1, dwPostDataLen, lpvPostData);
	}

	COleVariant vURL(lpszURL, VT_BSTR);
	COleVariant vHeaders(lpszHeaders, VT_BSTR);
	COleVariant vTargetFrameName(lpszTargetFrameName, VT_BSTR);
	COleVariant vFlags((long) dwFlags, VT_I4);
	m_pBrowserApp->Navigate2(vURL,
		vFlags, vTargetFrameName, vPostData, vHeaders);	
}

HRESULT MyHTMLView::Refresh2(VARIANT *Level)
{
	return m_pBrowserApp->Refresh2(COleVariant((long) Level, VT_I4));
}

