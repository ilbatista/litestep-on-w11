/*
This is a part of the Beep LiteStep module source code.
Copyright (C) 2002 Erik Christiansson, aka Sci
http://www.alphafish.com/
erik@alphafish.com

Modified by Brian Hartvigsen, aka Tresni
http://tresni.coreshell.info/
tresni@coreshell.info

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <windows.h>
#include "..\lsapi\lsapi.h"

#define HiValue  sizeof(DWORD)

extern "C" {
	__declspec( dllexport ) int initModuleEx(HWND hParent, HINSTANCE hInst, LPCSTR pszPath);
	__declspec( dllexport ) void quitModule(HINSTANCE hInst);
}
void bangBeep(HWND hCaller, LPCSTR pszArgs);

/* Added By Tresni for Win9x/ME support */
void beepShutUp(void);
void beepHardBeep(WORD freq, DWORD mSec);
void beepAsmBeep(WORD freq);
void beepPause(DWORD mSec);
BOOL IS_WINNT = false;

int initModuleEx(HWND hParent, HINSTANCE hInst, LPCSTR pszPath)
{
	OSVERSIONINFO osVI;
	AddBangCommand("!Beep", bangBeep);

	/* We attempt to determine the running version of Windows
	   If we can't assume it's NT (as the asm code is 'privileged'
	   under NT so we don't want to use it unless we know for sure
	   we are running 9x/ME */
	osVI.dwOSVersionInfoSize = sizeof(osVI);
	if(GetVersionEx(&osVI) == 0 || osVI.dwPlatformId == VER_PLATFORM_WIN32_NT)
		IS_WINNT = true;

	return 0;
}

void quitModule(HINSTANCE hInst)
{
	RemoveBangCommand("!Beep");
}

void bangBeep(HWND hCaller, LPCSTR pszArgs)
{
	int nFrequency, nDuration;
	char szFrequency[32], szDuration[32];
	char* pszTokens[2] = {szFrequency, szDuration};
	/*int nCount = 0;

	nCount = */LCTokenize(pszArgs, pszTokens, 2, NULL);

	nFrequency = atoi(szFrequency);
	nDuration = atoi(szDuration);

	if(!IS_WINNT)
		beepHardBeep(nFrequency, nDuration);
	else if(!Beep(nFrequency, nDuration))
		MessageBox(NULL, "Failed to process sound instruction.", "Beep", MB_SETFOREGROUND);
}

/*
   This code was actually taken from an Open Sourced, GPL'd program called Bleeper
   Copyright 1999 Andy Preston - Apollo Developments, Swindon U.K. andy@anorak.org.uk
   (written in Delphi [and licensed under the GPL])

   The asembler code was changed just to make it compatable with C++
   Some of the code was restructured/changed to make it work correctly.
   The theory and implementation should be credited to him, I just modified
     said implementation to make it work for what I needed.

   BleepInt, Bleeper, and GWBleep code can be found at:
   http://delphi.icm.edu.pl/ftp/d10free/bleepint.zip
*/

void beepShutUp(void)
{
	_asm{
		In al,0x61
		And al,0xFC
		Out 0x61,al
	}
}

void beepHardBeep(WORD freq, DWORD mSec)
{
	if(freq > 20 && freq < 5000)
	{
		beepAsmBeep((WORD)(1193181/(DWORD)freq));
		if(mSec>=0)
			beepPause(mSec);
		beepShutUp();
	}
}

void beepAsmBeep(WORD freq)
{
	_asm
	{
		Push BX
        In AL, 0x61
        Mov BL, AL
        And AL, 3
        Jne Skip
        Mov AL, BL
        Or AL, 3
        Out 0x61, AL
        Mov AL, 0xB6
        Out 0x43, AL
  Skip: Mov AX, freq
        Out 0x42, AL
        Mov AL, AH
        Out 0x42, AL
        Pop BX
	}
}

void beepPause(DWORD mSec)
{
	DWORD iCurTick, iFirstTick, iElapTime;
	iFirstTick = GetTickCount();
	
	do {
		iCurTick = GetTickCount();
		if (iCurTick < iFirstTick)
			iElapTime = (HiValue - iFirstTick) + iCurTick;
		else
			iElapTime = iCurTick - iFirstTick;
	} while(iElapTime <= mSec);
}