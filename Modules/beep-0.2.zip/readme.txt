Beep 0.2 (bleep)
--==--

Copyright (c) 2002 Brian Hartvigsen, aka Tresni
Copyright (c) 2002 Erik Christiansson, aka Sci
Copyright (c) 1999 Andy Preston - Apollo Developments, Swindon U.K. andy@anorak.org.uk
--==--

Change Log:
  0.2 - 09 sep 2002 - Tresni
    Found code that will make Beep work on 9x/ME with frequency and duration
    The code is by Andy Preston and is his code (originally written in Delphi)
    I just modified it to make it work with MS Visual C++ and LiteStep
    See the source for more information on this.
  0.1 - 22 aug 2002 - Sci
    First public release
--==--

Feedback:
  Bugs/Questions/Ideas on this release to tresni@coreshell.info (the source and all
  information has been given to Sci, but I don't know if he wants to handle my changes)
--==--

To Do:
  - PLAY support (like in GWBASIC or QBASIC)
--==--

Source Code:
  The sourcecode for this module is distributed under the GNU
  Public License. If you didn't get the sourcecode then contact
  the host from where you downloaded this file as it should have
  been included.