/****************************************************************************

Todo:
	- Multiple settings, bitmaps a la label?
	- Customizable menu like recycler

Changelog:

2003-01-19 (Vendicator):
	- Added support for LSMailFontBold
	- Moved code a bit
	- Added a check to prevent illegal access to servers before they are set up
	- Made sure to initialize all vars to prevent errors
	- Recreated change (didn't find source) from jesus_mjjg when no name was present : wasn't printed

2002-10-30 (Vendicator):
	- Removed ugly hWnd2 variable hack
	- Moved code out from lsmail.cpp to separate .cpp files, had to resort to a static hack
	  to send the lsmail object to them...
	- Added LsMailBangMode which disables the gui routines for faster functioning

2002-08-27 (Vendicator):
	- Fixed inheritance framework to allow for new server checking later on, thanks Nivenh!

2002-08-25 (Vendicator):
	- Fixed startup window paint before a mail check has been run.
	- Other shells without LSSetvar() in lsapi should be working again, PureLS and others.
	- Also added check for log support in lsapi.dll to be on the safe side
	- Another check for getrccoordinate() added
	- Also reduced mem usage some by removing some redunant ints

2002-08-19 (Vendicator):
	- Fixed stupid timer mistake causing lsmail not to do interval mail checking
	- Sets the following vars after a mail check:
	  LsMailNumMessages [total nr messages], LsMailServer[nr] [nr messages]
	  ie for 2 configed server: LsMailNumMessages 10, LsMailServer1 2 and LsMailServer2 8
	  Requires lsapi version newer than 2002-05-08.

2002-08-18 (Vendicator):
	- Filesize slashed with about 50k, had to use ugly hack by adding hWnd2 as a public HWND for external funtions
	- Added setting to disable mail check "LSMailDisableCheck", use bangs to enable
	  in runtime: !LSMailToggleCheck, !LSMailEnableCheck, !LSMailDisableCheck
	- Added !LsMailMove x y
	- Added LSMailErrorBmp, LSMailBackErrorColor, LSMailErrorFontColor, LSMailErrorCmd per request of... sorry I forgot...
	- !Refresh support

2002-08-13 (Vendicator):
	- Big push towards more OOP
	- Even more code cleaning

2002-07-24 (Vendicator):
	- More move to OOP
	- Fixed memleak in !bang commands removal when recycling
	- Added !LsMailHook for lsbox support
	- Added LSMailNoMessageBoxes, which sends errors as warnings to log file
	- Started rewrite to a more OOP layout, will make it easier to add other server types
	- Added LSMailDoneCheckCmd, per request of Maestr0

2002-05-29 (Vendicator):
	- Added a check so that the password actually is set in .rc if not old style is used
	- LsMail no longer shows up in taskmanager
	- Added killing of lsmail thread on quit, might fix the ls crash on recycle when lsmail was checking.
	- Added LSMailCheckMailCmd, per request of morph, originally added by ilmcuts

2002-05-11 (Jesus_mjjg):
	- now it is possible to specify the password in the step.rc

2002-04-18 (Vendicator):
	- Added a !bang for when there is no mail (LSMailNoMailCmd	!bang)

2002-04-17 (Vendicator):
	- Implemented bitmap for checking state (LSMailCheckingBmp)
	- Fixed clearing/setting of new mail flag (was only taking one server into account before)
	- Added ability to execute a !bang command on new mail (LSMailNewMailCmd	!bang)

2002-04-16 (Vendicator):
	- Clear new mail in popup now works again (was tied to left click action)

2002-04-16 (Vendicator):
	- Since the mail checking routine also clears the new mail flag when
	there is no mail on server, left click action is now checkmail.

2002-04-15 (Vendicator):
	- Added X,Y reading through GetRCCooridinate
	- Now clears new mail flag if 0 mail found on server

Bugs:
	- Sometime memory could not be read?

****************************************************************************/

#include "LsMail.h"
#include "Servers.h"
#include "pop3server.h"

#include "LogSetting.h"

// The module var
LsMail *mail;

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	mail = new LsMail(ParentWnd, code, dllInst);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete mail;
}


//=========================================================
// Bang commands
//=========================================================

void BangHook(HWND caller, LPCTSTR szArgs)
{
	if (mail->bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "Attempting to hook to LSBox");

	HWND hWnd = mail->GetHWND();
	char *handle = strrchr(szArgs,' ');
	if (handle) 
	{
		HWND boxwnd = (HWND)atoi(handle+1);
		if (boxwnd) 
		{
			mail->lsboxed = TRUE;
			if (boxwnd != GetParent(hWnd))
			{
				SetWindowLong(hWnd, GWL_STYLE, (GetWindowLong(hWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
				SetParent(hWnd, boxwnd);
			}
			if (mail->bLogSupport)
				LSLog(LOG_DEBUG, szAppName, "Hooking to LSBox successful");
		}
		else
		{
			if (mail->bLogSupport)
				LSLog(LOG_DEBUG, szAppName, "Hooking to LSBox failed");
		}
	}
	return;
}

void BangShow(HWND caller, const char* args)
{
	ShowWindow(mail->GetHWND(), SW_SHOW);
}

void BangHide(HWND caller, const char* args)
{ 
	ShowWindow(mail->GetHWND(), SW_HIDE);
}

void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(mail->GetHWND()))
		BangHide(caller, args);
	else
		BangShow(caller, args);
}

void BangCheckMail(HWND caller, const char* args)
{
	mail->CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckAllMail, (LPVOID)NULL, 0, &mail->threadID);
}

void BangToggleCheck(HWND caller, const char* args)
{
	mail->bDisableCheck = !mail->bDisableCheck;
}

void BangEnableCheck(HWND caller, const char* args)
{
	mail->bDisableCheck = TRUE;
}

void BangDisableCheck(HWND caller, const char* args)
{
	mail->bDisableCheck = FALSE;
}

void BangMove(HWND caller, const char *args)
{
	char szX[MAX_LINE_LENGTH], szY[MAX_LINE_LENGTH];
	char *tokens[2] = {szX, szY};
	LCTokenize( args, tokens, 2, NULL );
	mail->Move(atoi(szX), atoi(szY));
}

//=========================================================
// Module code
//=========================================================

HWND LsMail::GetHWND()
{
	return hWnd;
}

void LsMail::Size(int x_size, int y_size)
{
	SetWindowPos(hWnd, NULL, 0, 0, x_size, y_size, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
}

void LsMail::Move(int x_pos, int y_pos)
{
	if (x_pos < 0) x += GetSystemMetrics(SM_CXSCREEN);
	if (y_pos < 0) y += GetSystemMetrics(SM_CYSCREEN);

#ifdef DEBUG_EXTRA
	if (bLogSupport)
		LSLogPrintf(LOG_DEBUG, szAppName, "new pos: x:%d,y:%d", x_pos, y_pos);
#endif

	SetWindowPos(hWnd, NULL, x_pos, y_pos, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}

void LsMail::SetWindowBitmapRgn(HBITMAP bmp)
{
	if (hWnd && bmp)
	{
		int x=0, y=0;
		HDC hdc = CreateCompatibleDC(NULL);
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;

		GetObject(bmp, sizeof(bitmap), &bitmap);
		SelectObject(hdc, bmp);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y < bitmap.bmHeight; x=0, y++)
		{
			for (x=0; x < bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == 0x00FF00FF)
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hWnd, hMainRgn, FALSE);

		DeleteDC(hdc);
		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hWnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hWnd, rgn, FALSE);
	}
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------

LsMail::LsMail(HWND parentWnd, int& code, HINSTANCE dllInst):
	Window(szAppName),

	// ls support
	bSetVarSupport(FALSE),
	bLogSupport(FALSE),

	// for work
	hInstance2(NULL),
	hWndParent(NULL),
	bInitialized(false),
	threadID(NULL),
	TIMER(0),
	popup(NULL),
	font(NULL),
	Servers(NULL),

	// settings
	x(0), y(0), w(0), h(0),
	bBangMode(FALSE),
	bOnTop(false),
	bHidden(false),
	lsboxed(false),
	bNoMessageBoxes(false),
	bDisableCheck(false),

	// status
	CHECKING(FALSE),
	NEWMAIL(FALSE),
	ERRORS(FALSE),
	MAIL_STATUS(MAIL_NO),

	// commands
	NewMailCmd(NULL),
	NoMailCmd(NULL),
	CheckMailCmd(NULL),
	DoneCheckCmd(NULL),
	ErrorCmd(NULL)

{

	memset(MAILCLIENT, 0, MAX_PATH);
	int msgs[] = {LM_GETREVID, LM_REPAINT, LM_REFRESH, 0};

	// check for log support
	if ( GetProcAddress(GetModuleHandle("LSAPI.DLL"), "LSLogPrintf") != NULL)
	{
		bLogSupport = TRUE;
		if (bLogSupport)
			LSLog(LOG_NOTICE, szAppName, "log support found!");
	}

	// check for setvar support
	if ( GetProcAddress(GetModuleHandle("LSAPI.DLL"), "LSSetVariable") != NULL)
	{
		bSetVarSupport = TRUE;
		if (bLogSupport)
			LSLog(LOG_NOTICE, szAppName, "setvar support found!");
	}

	if (bLogSupport)
	{
#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_WARNING, szAppName, "*Debug* Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#else
	LSLogPrintf(LOG_DEBUG, szAppName, "Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#endif
	}

	memset(MAILCLIENT, 0, sizeof(MAILCLIENT)/sizeof(MAILCLIENT[0]) );

	hWndParent = parentWnd;
	hInstance2 = dllInst;

	LoadSetup();

	if ( !createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
                    x, y, w, h, parentWnd) )
	{
		if (bLogSupport)
			LSLog(LOG_ERROR, szAppName, "unable to create window");

		MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
		code = 1;
		return;
	}
	else
	{
		//hWnd2 = hWnd;
		if (bLogSupport)
			LSLogPrintf(LOG_DEBUG, szAppName, "window created, 0x%X", hWnd);
	}

	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	if (bBangMode = GetRCBool("LSMailBangMode", TRUE))
		ShowWindow(hWnd, SW_HIDE);

	TIMER=GetRCInt("LSMailTimer", 5);
	if (TIMER)
		SetTimer(hWnd, 0, TIMER*60000, NULL);

	if (!bBangMode)
	{
		GUIProps();

		AddBangCommand("!LSMailShow", BangShow);
		AddBangCommand("!LSMailHide", BangHide);
		AddBangCommand("!LSMailToggle", BangToggle);
		AddBangCommand("!LSMailHook", BangHook);
		AddBangCommand("!LSMailMove", BangMove);

		CreatePopup();
	}

	AddBangCommand("!LSMailCheckMail", BangCheckMail);
	AddBangCommand("!LSMailToggleCheck", BangToggleCheck);
	AddBangCommand("!LSMailEnableCheck", BangEnableCheck);
	AddBangCommand("!LSMailDisableCheck", BangDisableCheck);

	if (bLogSupport)
		LSLog(LOG_NOTICE, szAppName, "loaded successfully");
	
	code = 0;
	
	// protect so that the text functions aren't used before everything has been set up
	bInitialized = true;

	CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)::CheckAllMail, (LPVOID)NULL, 0, &threadID);
}

void LsMail::GUIProps()
{

	bHidden = GetRCBool("LSMailStartHidden", TRUE);
	if (bHidden)
	{
		if (bLogSupport)
			LSLog(LOG_DEBUG, szAppName, "Starting as hidden");
		ShowWindow(hWnd, SW_HIDE);
	}
	else
	{
		if (bLogSupport)
			LSLog(LOG_DEBUG, szAppName, "Starting as shown");
		ShowWindow(hWnd, SW_SHOW);
	}

	bOnTop = GetRCBool("LSMailAlwaysOnTop", TRUE);
	if (bOnTop)
	{
		if (bLogSupport)
			LSLog(LOG_DEBUG, szAppName, "Setting Ontop");
		SetWindowPos(GetHWND(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
	}
	else
	{
		if (bLogSupport)
			LSLog(LOG_DEBUG, szAppName, "Normal Window, not ontop");
	}

	if (bgbmp && !USEBGCOLOR)
	{
		SetWindowBitmapRgn(bgbmp);
		if (bLogSupport)
			LSLog(LOG_DEBUG, szAppName, "Setting window bitmap region");
	}
}


void LsMail::LoadSetup()
{
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "Loading setup...");

	int size;
	char temp[256];
	bool bold;

	bDisableCheck = GetRCBool("LSMailDisableCheck", TRUE);
	bNoMessageBoxes = GetRCBool("LSMailNoMessageBoxes", TRUE);

	if (!bBangMode)
	{
		if ( GetProcAddress(GetModuleHandle("LSAPI.DLL"), "GetRCCoordinate") != NULL)
		{
			if (bLogSupport)
				LSLog(LOG_DEBUG, szAppName, "GetRCCoordinate found!");
			
			x = GetRCCoordinate("LSMailX", 0, GetSystemMetrics(SM_CXSCREEN));
			y = GetRCCoordinate("LSMailY", 0, GetSystemMetrics(SM_CYSCREEN));
		}
		else
		{
			x = GetRCInt("LSMailX", 0);
			y = GetRCInt("LSMailY", 0);
		}

		w = GetRCInt("LSMailW", 400);
		h = GetRCInt("LSMailH", 25);

		size = GetRCInt("LSMailFontSize", 12);
		bold = GetRCBool("LSMailFontBold", TRUE);
		GetRCString("LSMailFont", temp, "Arial", 256);
		font = CreateFont(size, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);
		color = GetRCColor("LSMailFontColor", 0x00FFFFFF);
		nmcolor = GetRCColor("LSMailNewMailFontColor", 0x000000FF);
		checkcolor = GetRCColor("LSMailCheckingFontColor", 0x000000FF);
		errorcolor = GetRCColor("LSMailErrorFontColor", 0x00FF0000);

		USEBGCOLOR = GetRCBool("LSMailBackColor", TRUE);
		if (USEBGCOLOR) 
		{
			bgcolor = GetRCColor("LSMailBackColor", 0x00000000);
			bgbrush = CreateSolidBrush(bgcolor);

			bgcolor = GetRCColor("LSMailBackNewMailColor", 0x000000FF);
			nmbgbrush = CreateSolidBrush(bgcolor);

			bgcolor = GetRCColor("LSMailBackCheckingColor", 0x00000000);
			checkbgbrush = CreateSolidBrush(bgcolor);

			bgcolor = GetRCColor("LSMailBackErrorColor", 0x00FF0000);
			errorbgbrush = CreateSolidBrush(bgcolor);
		}
		else 
		{
			GetRCString("LSMailBackBmp", temp, "", 256);
			bgbmp = LoadLSImage(temp, temp);

			GetRCString("LSMailNewMailBmp", temp, "", 256);
			newmailbmp = LoadLSImage(temp, temp);

			GetRCString("LSMailCheckingBmp", temp, "", 256);
			checkingbmp = LoadLSImage(temp, temp);

			GetRCString("LSMailErrorBmp", temp, "", 256);
			errorbmp = LoadLSImage(temp, temp);
		}
	}
	GetRCString("LSMailEMailClient", MAILCLIENT, "", MAX_PATH);

}

void LsMail::ReadServers()
{
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "Reading mail server configs");

	SERVER::RegisterSettings(GetHWND(), hInstance2, bLogSupport, !bNoMessageBoxes);

	int i = 0;
	// *LSMailServer X Y Name host:<port> login
	FILE* step;

	char temp[256];
	char stepRC[MAX_PATH];
	LSGetLitestepPath(stepRC, MAX_PATH);
	strcat(stepRC, "\\step.rc");
#ifdef DEBUG_SERVER
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "opening step rc");
#endif
	step = LCOpen(stepRC);
	
	while (LCReadNextConfig(step, "*LSMailServer", temp, 256)) 
	{
		i++;
#ifdef DEBUG_SERVER
		if (bLogSupport)
			LSLogPrintf(LOG_DEBUG, szAppName, "server config %d", i);
#endif

		SERVER *s = new Pop3Server(temp);

		if (s->Working())
		{
			if (Servers)
				s->next = Servers;
			Servers = s;
		}
		else
		{
			delete s;
			if (bLogSupport)
				LSLogPrintf(LOG_ERROR, szAppName, "Error on server: %d", i);
		}

		#ifdef DEBUG_SERVER
			if (bLogSupport)
				LSLog(LOG_DEBUG, szAppName, "checking for next server");
		#endif
	}
	LCClose(step);
	if (bLogSupport)
		LSLogPrintf(LOG_DEBUG, szAppName, "Read %d servers", i);
}

void LsMail::onCreate(Message& message)
{
#ifdef DEBUG_EXTRA
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "OnCreate accessed");
#endif

	ReadCommands();
	ReadServers();

}

void LsMail::CreatePopup()
{
	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CHECKMAIL, "&Check Mail");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_LAUNCHCLIENT, "&Launch E-Mail Client");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CLEARNEWMAIL, "Clear &New Mail");
	//AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_ZEROACCOUNTS, "&Zero All Accounts");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_DISPLAYERROR, "&Display Last Error");
	AppendMenu(popup, MF_SEPARATOR, 0, "");

	for (SERVER* s=Servers; s; s=s->next)
	{
		s->menu = CreatePopupMenu();
		AppendMenu(s->menu, MF_ENABLED | MF_STRING, POPUP_SERVER+s->ID+1, "&Change Password");

		AppendMenu(popup, MF_ENABLED | MF_STRING | MF_POPUP, (int)s->menu, s->name);
	}
}

void LsMail::ReadCommands()
{
	char temp[MAX_LINE_LENGTH];
	memset(temp, 0, MAX_LINE_LENGTH);

	GetRCLine("LSMailCheckMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // new mail command
	CheckMailCmd = new char[strlen(temp)+1];
	strcpy(CheckMailCmd, temp);

	GetRCLine("LSMailNewMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // new mail command
	NewMailCmd = new char[strlen(temp)+1];
	strcpy(NewMailCmd, temp);

	GetRCLine("LSMailNoMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // no mail command
	NoMailCmd = new char[strlen(temp)+1];
	strcpy(NoMailCmd, temp);

	GetRCLine("LSMailDoneCheckCmd", temp, MAX_LINE_LENGTH, "!NONE"); // done check command
	DoneCheckCmd = new char[strlen(temp)+1];
	strcpy(DoneCheckCmd, temp);

	GetRCLine("LSMailErrorCmd", temp, MAX_LINE_LENGTH, "!NONE"); // error command
	ErrorCmd = new char[strlen(temp)+1];
	strcpy(ErrorCmd, temp);

}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
LsMail::~LsMail()
{
	int msgs[] = {LM_GETREVID, LM_REPAINT, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	if (!bBangMode)
	{
		RemoveBangCommand("!LSMailShow");
		RemoveBangCommand("!LSMailHide");
		RemoveBangCommand("!LSMailToggle");
		RemoveBangCommand("!LSMailHook");
		RemoveBangCommand("!LsMailMove");
	}
	RemoveBangCommand("!LSMailCheckMail");
	RemoveBangCommand("!LSMailToggleCheck");
	RemoveBangCommand("!LSMailEnableCheck");
	RemoveBangCommand("!LSMailDisableCheck");

	destroyWindow();
}

void LsMail::onDestroy(Message& message)
{
#ifdef DEBUG_EXTRA
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "OnDestroy accessed");
#endif

	if (CHECKING) // what about this? wait for module to close, or does it lock everything...
	{
		TerminateThread(CheckThread, NULL); // kill the checking thread.
		//Sleep(1000);
	}

	DeleteCommands();
	CleanUp();

}

void LsMail::DeleteCommands()
{
	if (NewMailCmd != NULL) {
		delete [] NewMailCmd;
		NewMailCmd = NULL;
	}
	if (NoMailCmd != NULL) {
		delete [] NoMailCmd;
		NoMailCmd = NULL;
	}
	if (CheckMailCmd != NULL) {
		delete [] CheckMailCmd;
		CheckMailCmd = NULL;
	}
	if (DoneCheckCmd != NULL) {
		delete [] DoneCheckCmd;
		DoneCheckCmd = NULL;
	}
	if (ErrorCmd != NULL) {
		delete [] ErrorCmd;
		ErrorCmd = NULL;
	}
}

void LsMail::CleanUp()
{
	if (!bBangMode)
	{
		DeleteObject(bgbrush);
		DeleteObject(nmbgbrush);
		DeleteObject(checkbgbrush);
		DeleteObject(errorbgbrush);
		DeleteObject(bgbmp);
		DeleteObject(newmailbmp);
		DeleteObject(checkingbmp);
		DeleteObject(errorbmp);
		DeleteObject(font);
		DestroyMenu(popup);
	}

	if (TIMER)
		KillTimer(hWnd, 0);

	SERVER *next;
	for (SERVER* s=Servers; s; s=next)
	{
		DestroyMenu(s->menu);
		next = s->next;
		delete s;
	}
	Servers = NULL;
}

//=========================================================
// Registered messages
//=========================================================

void LsMail::windowProc(Message& message)
{

#ifdef DEBUG_SPAM
	if (bLogSupport)
		LSLogPrintf(LOG_DEBUG, szAppName, "Message: %X", message.uMsg) ;
#endif

	BEGIN_MESSAGEPROC
		MESSAGE(onEraseBg,		WM_ERASEBKGND)
		MESSAGE(onEndSession,	WM_ENDSESSION)
		MESSAGE(onEndSession,	WM_QUERYENDSESSION)
		MESSAGE(onGetRevId,		LM_GETREVID)
		MESSAGE(onMouse,		WM_RBUTTONDOWN)
		MESSAGE(onMouse,		WM_LBUTTONUP)
		MESSAGE(onCreate,		WM_CREATE)
		MESSAGE(onDestroy,		WM_DESTROY)
		MESSAGE(onRefresh,		LM_REFRESH)
		MESSAGE(onSysCommand,	WM_SYSCOMMAND)
		MESSAGE(onCommand,		WM_COMMAND)
		MESSAGE(onPaint,		WM_PAINT)
		MESSAGE(onPaint,		LM_REPAINT)
		MESSAGE(onTimer,		WM_TIMER)
	END_MESSAGEPROC
}

//=========================================================
// Message handlers
//=========================================================

void LsMail::onRefresh(Message& message)
{
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "Refreshing");

	CleanUp();
	DeleteCommands();

	ReadCommands();
	
	LoadSetup();
	ReadServers();
	CreatePopup();

	// handling for new size & bitmap?
	Move(x, y);
	Size(w, h);

	GUIProps();

	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "Refresh done");

	CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)::CheckAllMail, (LPVOID)NULL, 0, &threadID);

}

void LsMail::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void LsMail::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "LsMail.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


void LsMail::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void LsMail::onMouse(Message& message)
{
#ifdef DEBUG_EXTRA
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "OnMouse accessed");
#endif

	if (message.uMsg == WM_LBUTTONUP)
	{
			/*NEWMAIL=FALSE;
			for (SERVER *s=Servers; s; s=s->next) 
			{
				s->num=s->newnum;
				s->NEWMAIL=FALSE;
			}
			*/
		CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)::CheckAllMail, (LPVOID)NULL, 0, &threadID);
		InvalidateRect(hWnd, NULL, TRUE);
	}
	else if (message.uMsg == WM_RBUTTONDOWN)
	{
#ifdef DEBUG_EXTRA
		if (bLogSupport)
			LSLog(LOG_DEBUG, szAppName, "open popup");
#endif

		DWORD dw = GetMessagePos();
		TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hWnd, NULL); // hwnd?
	}
	message.lResult = DefWindowProc(GetHWND(), message.uMsg, message.wParam, message.lParam);
}

void LsMail::onCommand(Message& message)
{
	switch (message.wParam)
	{
		case POPUP_CHECKMAIL:
		{
			CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)::CheckAllMail, (LPVOID)NULL, 0, &threadID);
		}
		break;
	
		case POPUP_LAUNCHCLIENT: 
		{
			WinExec(MAILCLIENT, SW_SHOWNORMAL);
		}
		break;
		case POPUP_DISPLAYERROR:
		{
			MessageBox(hWnd, Servers->ERR, "LSMail Error", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
		}
		break;
		case POPUP_ZEROACCOUNTS:
		{
			for (SERVER *s=Servers; s; s=s->next) 
			{
				s->MAIL_STATUS = MAIL_NO;
				s->num=s->newnum=0;
			}
			InvalidateRect(hWnd, NULL, TRUE);
		}
		break;
		
		case POPUP_CLEARNEWMAIL:
		{
			NEWMAIL=FALSE;
			for (SERVER *s=Servers; s; s=s->next) 
			{
				//s->num=s->newnum; //V
				s->MAIL_STATUS = MAIL_NO;
			}
			InvalidateRect(hWnd, NULL, TRUE); // needed for redraw
		}
		break;
		
		default:
		{
			for (SERVER *s=Servers; s; s=s->next) 
			{
				if ((int)message.wParam == (POPUP_SERVER+s->ID+1))
				{
					// Change Password
					strcpy(s->TEMP_SERVER, s->name);
					DialogBox(hInstance, MAKEINTRESOURCE(IDD_GETPASS), hWnd, GetPassProc);
					if (strlen(s->TEMP_PASS)) 
					{
						char temp[256] = "";
						if (s->password) 
							memset(&s->password, 0, sizeof(s->password));
						s->password = NULL;
						s->password = _strdup(s->TEMP_PASS);
						sprintf(temp, "%s/%s", s->host, s->login);
						WriteProfileString("LSMail", temp, s->encrypt(s->password));
					}
					break;
				}
			}
		}
		break;
	}

}

void LsMail::onPaint(Message& message)
{
#ifdef DEBUG_EXTRA
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "onpaint accessed");
#endif

	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd, &ps);
	HDC buf = CreateCompatibleDC(NULL);
	HDC src = CreateCompatibleDC(NULL);
	HBITMAP bufbmp = CreateCompatibleBitmap(hdc, w, h);
	HBITMAP oldbuf, oldsrc;
	RECT r;

	GetClientRect(hWnd, &r);

	if (!bgbmp && !USEBGCOLOR)
	{
		bgbmp = CreateCompatibleBitmap(hdc, w, h);
		oldbuf = (HBITMAP)SelectObject(buf, bgbmp);
		BitBlt(buf, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		SelectObject(buf, oldbuf);
	}

	oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			
	if (!USEBGCOLOR)
	{
		if (ERRORS && errorbmp)
			oldsrc = (HBITMAP)SelectObject(src, errorbmp);
		else if (CHECKING && checkingbmp)
			oldsrc = (HBITMAP)SelectObject(src, checkingbmp);
		else if (NEWMAIL && newmailbmp)
			oldsrc = (HBITMAP)SelectObject(src, newmailbmp);
		else
			oldsrc = (HBITMAP)SelectObject(src, bgbmp);

		BitBlt(buf, 0, 0, w, h, src, 0, 0, SRCCOPY);
	}
	else
	{
		if (ERRORS)
			FillRect(buf, &r, (HBRUSH)errorbgbrush);
		else if (CHECKING)
			FillRect(buf, &r, (HBRUSH)checkbgbrush);
		else if (NEWMAIL)
			FillRect(buf, &r, (HBRUSH)nmbgbrush);
		else
			FillRect(buf, &r, (HBRUSH)bgbrush);
	}

	SelectObject(buf, font);
	SetBkMode(buf, TRANSPARENT);

	if (bInitialized)
	{
		// var outside for loop
		char temp[256] = "";

		for (SERVER *s=Servers; s; s=s->next)
		{
			memset(temp, 0, 256);
			
			if (strlen(s->name))
				sprintf(temp, "%s: ", s->name);

			if (s->bERROR)
				strcpy(temp, "Error!");
			else
				sprintf(temp, "%s%d", temp, s->newnum-s->num);

			SetRect(&r, s->x, s->y, w, h);

			if (CHECKING)
				SetTextColor(buf, checkcolor);
			else
			{
				if (s->MAIL_STATUS != MAIL_NO)
				{
					SetTextColor(buf, nmcolor);
	#ifdef DEBUG_SERVER
					if (bLogSupport)
						LSLogPrintf(LOG_DEBUG, szAppName, "new mail on server: %s", s->host);
	#endif
				}
				else
				{
					if (s->bERROR)
					{
						SetTextColor(buf, errorcolor);
					}
					else
					{

					SetTextColor(buf, color);
	#ifdef DEBUG_SERVER
					if (bLogSupport)
						LSLogPrintf(LOG_DEBUG, szAppName, "no new mail on server: %s", s->host);
	#endif
					}

				}
			}

			DrawText(buf, temp, strlen(temp), &r, DT_CALCRECT | DT_LEFT | DT_VCENTER);
			DrawText(buf, temp, strlen(temp), &r, DT_LEFT | DT_VCENTER);
		}
	}

	BitBlt(hdc, 0, 0, w, h, buf, 0, 0, SRCCOPY);

	SelectObject(src, oldsrc);
	DeleteDC(src);
	SelectObject(buf, oldbuf);
	DeleteDC(buf);
	DeleteObject(bufbmp);
	EndPaint(hWnd, &ps);
}

void LsMail::onEraseBg(Message& message)
{
	return;
}

void LsMail::onTimer(Message& message)
{
#ifdef DEBUG_EXTRA
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "OnTimer accessed, checking mail");
#endif
	CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)::CheckAllMail, (LPVOID)NULL, 0, &threadID);
}


// Server functions

BOOL LsMail::CheckAllMail()
{
	int nummail = 0;
	char name[255];
	char text[255];
	HWND hWnd = GetHWND();

	// abort on these conditions
	if (CHECKING || bDisableCheck) {
		//mail->CHECKING = FALSE;
		InvalidateRect(hWnd, NULL, TRUE);
		return FALSE;
	}

#ifdef DEBUG_SERVER
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "starting mail check");
#endif

	CHECKING=TRUE;
	ERRORS = FALSE;

	InvalidateRect(hWnd, NULL, TRUE);
	LSExecute(hWnd, CheckMailCmd, 0); // check !bang

	__try 
	{
		for (SERVER *s=Servers; s; s=s->next)
		{
			s->CheckMail();
		}
	} __except(1) { }

	MAIL_STATUS = Status();

	if (MAIL_STATUS == MAIL_NEW) {
		NEWMAIL = TRUE;
		LSExecute(hWnd, NewMailCmd, 0);
	}
	else if (MAIL_STATUS == MAIL_NO) {
		NEWMAIL = FALSE;
		LSExecute(hWnd, NoMailCmd, 0);
	}

	for (SERVER *s=Servers; s; s=s->next)
	{
		if (bSetVarSupport)
		{
			nummail += s->newnum;
			memset(name, 0, 255);
			memset(text, 0, 255);
			sprintf(name, "LsMailServer%d", s->ID);
			sprintf(text, "%d", s->newnum);
			LSSetVariable(name, text);
		}

		if (s->bERROR)
			mail->ERRORS = TRUE;
	}
	if (ERRORS)
		LSExecute(hWnd, ErrorCmd, 0); // error !bang

	if (bSetVarSupport)
	{
		memset(name, 0, 255);
		memset(text, 0, 255);
		strcpy(name, "LsMailNumMessages");
		sprintf(text, "%d", nummail);
		LSSetVariable(name, text);
	}

	CHECKING=FALSE;
	LSExecute(hWnd, DoneCheckCmd, 0); // check !bang
	InvalidateRect(hWnd, NULL, TRUE);

#ifdef DEBUG_SERVER
	if (bLogSupport)
		LSLog(LOG_DEBUG, szAppName, "mail check done");
#endif
	return TRUE;
}

// mail checking, not possible to thread class functions...
BOOL CheckAllMail()
{
	return mail->CheckAllMail();
}


BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG: 
		{
			char temp[256] = "";
			sprintf(temp, "%s Password", mail->Servers->TEMP_SERVER);
			SetWindowText(hwnd, temp);
			return TRUE;
		}

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDOK:
						{
							GetDlgItemText(hwnd, IDC_PASSWORD, mail->Servers->TEMP_PASS, 256);
						}
						case IDCANCEL:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}

	return FALSE;
}

int LsMail::Status()
{
	int status = MAIL_NO;
	for (SERVER *s=Servers; s; s=s->next)
	{
		status = max(status, s->MAIL_STATUS);
	}
	return status;
}
