#ifndef  __LSMAIL_H
#define  __LSMAIL_H

// module information
const char szAppName[] = "LsMail"; // Our window class, etc
const char rcsRevision[] = "$Revision: 4.14 $"; // Our Version
const char rcsId[] = "$Id: LsMail.cpp,v 4.14 11:20:37 Vendicator Exp $"; // The Full RCS ID.

// Includes
#include <windows.h>
#include <time.h> // for timers

#include "Servers.h"

#include "resource.h"
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/lswinbase.h"

// Definitions
#define POPUP_CHECKMAIL 200
#define POPUP_CLEARNEWMAIL 201
#define POPUP_ZEROACCOUNTS 202
#define POPUP_LAUNCHCLIENT 203
#define POPUP_DISPLAYERROR 204
#define POPUP_SERVER 220

#define MAX_LINE_LENGTH 4096

#define WC_SHELLDESKTOP		"DesktopBackgroundClass"

class LsMail : public Window
{
public:
	LsMail(HWND parentWnd, int& code, HINSTANCE dllInst);
	~LsMail();
	int Status();
	void LoadSetup();
	void ReadServers();

	BOOL CheckAllMail();

	void Move(int x_pos, int y_pos);
	void Size(int x_size, int y_size);
	HWND GetHWND();

	HINSTANCE hInstance2;
	HANDLE CheckThread;
	HWND hWndParent;

	bool bInitialized;
	BOOL bOnTop;
	BOOL bHidden;
	BOOL lsboxed;
	BOOL bNoMessageBoxes;
	BOOL bDisableCheck;
	BOOL bBangMode;

	BOOL bSetVarSupport;
	BOOL bLogSupport;

	BOOL CHECKING;
	BOOL NEWMAIL;
	BOOL ERRORS;

	int TIMER;

	int x, y, w, h;

	HMENU popup;
	HFONT font;

	DWORD threadID;

	char MAILCLIENT[MAX_PATH];

	char *NewMailCmd, *NoMailCmd, *CheckMailCmd, *DoneCheckCmd, *ErrorCmd;

	int MAIL_STATUS;

	// The Server list
	SERVER *Servers;

private:

	void CleanUp();

	void ReadCommands();
	void DeleteCommands();

	void CreatePopup();

	void GUIProps();
	void SetWindowBitmapRgn(HBITMAP bmp);

	// gui settings:
	COLORREF color, nmcolor, checkcolor, bgcolor, errorcolor;
	HBRUSH bgbrush, nmbgbrush, checkbgbrush, errorbgbrush;
	HBITMAP bgbmp, newmailbmp, checkingbmp, errorbmp;
	BOOL USEBGCOLOR;

	// Event handling:
	virtual void windowProc(Message& message);
	void onTimer(Message& message);
	void onEraseBg(Message& message);
	void onPaint(Message& message);
	void onCommand(Message& message);
	void onMouse(Message& message);
	void onRefresh(Message& message);
	void onGetRevId(Message& message);
	void onDestroy(Message& message);
	void onCreate(Message& message);
	void onSysCommand(Message& message);
	void onEndSession(Message& message);

};

// Function Definitions
//LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CheckAllMail();

void BangHook(HWND caller, LPCTSTR szArgs);
void BangShow(HWND caller, const char* args);
void BangHide(HWND caller, const char* args);
void BangToggle(HWND caller, const char* args);
void BangCheckMail(HWND caller, const char* args);
void BangToggleCheck(HWND caller, const char* args);
void BangEnableCheck(HWND caller, const char* args);
void BangDisableCheck(HWND caller, const char* args);
void BangMove(HWND caller, const char *args);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
