/*

	ClockFace class that handles all the clock functions

*/

#include <math.h>
#include "ClockFace.h"
#include "HandCalc.h"

#include "../VTK/LSUtils.h"
#include "../VTK/apis.h"
#include "../VTK/TokenSafeString.h"

#include "log_on.h"
using namespace LSUtils;


/* ClockFace */

ClockFace::ClockFace(LPCSTR prefix) :
	bNoSeconds(false),
	Prefix(prefix),
	nResolution(60),
	borderTop(0),
	borderLeft(0),
	borderRight(0),
	borderBottom(0),
	nWidth(0),
	nHeight(0)
{
}

ClockFace::~ClockFace()
{
	for (vector<ClockDisplay*>::iterator i = displays.begin(); i != displays.end(); i++)
	{
		delete (ClockDisplay*)(*i);		
	}
	displays.clear();

	delete ClockHand::sinus;
	delete ClockHand::cosinus;
}

int ClockFace::GetRefresh()
{
	return nRefresh;
}

// drawing function, originally from aLsClock
void ClockFace::DrawClock(const HDC hdc, HRGN hrgn)
{
	SYSTEMTIME time;
	GetLocalTime(&time);

	// use objects in given order instead of switching on every update
	for (vector<ClockDisplay*>::iterator i = displays.begin(); i != displays.end(); i++)
	{
		(*i)->DrawClock(hdc, hrgn, time);
	}
}

void ClockFace::CalcCenter(int width, int height)
{
	// calculate center
	ClockHand::SetCenter((float)width / 2, (float)height / 2);
}

void ClockFace::CalcCenter()
{
	// calculate center
	ClockHand::SetCenter(borderLeft+(float)((nWidth-borderLeft-borderRight) / 2), borderTop+(float)(nHeight-borderTop-borderBottom) / 2);
}

void ClockFace::SetBorders(int t, int l, int r, int b)
{
	borderTop = t;
	borderLeft = l;
	borderRight = r;
	borderBottom = b;
}

void ClockFace::SetSize(int w, int h)
{
	nWidth = w;
	nHeight = h;
}

void ClockFace::ReadClockSettings()
{
#ifdef _DEBUG
	_LSLogPrintf(LOG_DEBUG, Prefix, "Looking for prefix: %s", Prefix);
#endif

	char szMainHand[MAX_LINE_LENGTH];
	char szTemp[MAX_LINE_LENGTH];
	COLORREF ci, co;
	int w, l, b_main, b, a_main, a, count, textcount;
	TokenSafeString* tokenize;
	int nCenterX = ClockHand::GetCenterX();
	int nCenterY = ClockHand::GetCenterY();

	PrefixedGetRCString(Prefix, "HandType", szMainHand, "line" , MAX_LINE_LENGTH);
	a_main = PrefixedGetRCInt(Prefix, "HandAlpha", 255);
	a_main = max(min(a_main, 255), 0);
	b_main = PrefixedGetRCInt(Prefix, "HandBorder", 1);

	ClockHand::SetAdaptRegion(PrefixedGetRCBool(Prefix, "NoAdaptRegion", true));

	nResolution = min(PrefixedGetRCInt(Prefix, "Resolution", 60), 60000);
	nRefresh = PrefixedGetRCInt(Prefix, "Refresh", 60000/nResolution);

	HandCalc::SetResolution(nResolution);
	ClockHand::sinus = new SinBuffer(nResolution, 0);
	ClockHand::cosinus = new CosBuffer(nResolution, -(nResolution)/2);


	char t1[MAX_LINE_LENGTH], t2[MAX_LINE_LENGTH], t3[MAX_LINE_LENGTH], t4[MAX_LINE_LENGTH];
	char* tokens[4] = {t1, t2, t3, t4};

	PrefixedGetRCLine(Prefix, "DrawOrder", szTemp, MAX_LINE_LENGTH, "t h m s");
	count = LCTokenize(szTemp, tokens, 4, NULL);

#ifdef _DEBUG
	_LSLogPrintf(LOG_DEBUG, Prefix, "order string: %s, c: %d", szTemp, count);
#endif

	bNoSeconds = PrefixedGetRCBool(Prefix, "NoSeconds", true);

	for (int i = 0; i < count; i++)
	{
		// compile a list in what order functions should be run, since this is needs only be done once...
		switch(tokens[i][0])
		{
			case 't':
				PrefixedGetRCString(Prefix, "TextDisplays", szTemp, "", MAX_LINE_LENGTH);
				tokenize = new TokenSafeString(szTemp);
				textcount = tokenize->CountTokens();
				if (textcount >= 1)
				{
					for (int txt = 0; txt < textcount; ++txt)
					{
						_LSLogPrintf(LOG_DEBUG, Prefix, "Looking for text display: %s (%d)", tokenize->GetToken(txt), tokenize->GetToken(txt));
						displays.push_back( LoadDisplay("text", tokenize->GetToken(txt), borderLeft, borderRight, nWidth-borderLeft-borderRight, nHeight-borderTop-borderBottom) );
					}
				}
				else
					_LSLog(LOG_DEBUG, Prefix, "no text loaded");
				delete tokenize;
			break;

			case 'h':
				// hours:
				PrefixedGetRCString(Prefix, "HourHandType", szTemp, szMainHand, MAX_LINE_LENGTH);
				co = PrefixedGetRCColor(Prefix, "HourColor", RGB(0, 0, 255));
				ci = PrefixedGetRCColor(Prefix, "HourInnerColor", co);
				b = PrefixedGetRCInt(Prefix, "HourBorder", b_main);
				l = PrefixedGetRCInt(Prefix, "HourLength", 0.7*min(nCenterX, nCenterY));
				w = PrefixedGetRCInt(Prefix, "HourWeight", 3);
				a = PrefixedGetRCInt(Prefix, "HourAlpha", a_main);
				displays.push_back( LoadHand(HAND_HOUR, szTemp, ci, co, l, w, b, a) );
			break;

			case 'm':
				// minutes:
				PrefixedGetRCString(Prefix, "MinuteHandType", szTemp, szMainHand, MAX_LINE_LENGTH);
				co = PrefixedGetRCColor(Prefix, "MinuteColor", RGB(0, 255, 0));
				ci = PrefixedGetRCColor(Prefix, "MinuteInnerColor", co);
				b = PrefixedGetRCInt(Prefix, "MinuteBorder", b_main);
				l = PrefixedGetRCInt(Prefix, "MinuteLength", 0.9*min(nCenterX, nCenterY));
				w = PrefixedGetRCInt(Prefix, "MinuteWeight", 2);
				a = PrefixedGetRCInt(Prefix, "MinuteAlpha", a_main);
				displays.push_back( LoadHand(HAND_MINUTE, szTemp, ci, co, l, w, b, a) );
			break;

			case 's':
				if (!bNoSeconds)
				{
					// seconds:					
					if (!bNoSeconds)
					{
						PrefixedGetRCString(Prefix, "SecondHandType", szTemp, szMainHand, MAX_LINE_LENGTH);
						co = PrefixedGetRCColor(Prefix, "SecondColor", RGB(255, 0, 0));
						ci = PrefixedGetRCColor(Prefix, "SecondInnerColor", co);
						b = PrefixedGetRCInt(Prefix, "SecondBorder", b_main);
						w = PrefixedGetRCInt(Prefix, "SecondWeight", 1);
						l = PrefixedGetRCInt(Prefix, "SecondLength", 0.9*min(nCenterX, nCenterY));
						a = PrefixedGetRCInt(Prefix, "SecondAlpha", a_main);
						displays.push_back( LoadHand(HAND_SECOND, szTemp, ci, co, l, w, b, a) );
					}
				}
			break;
		}
	}
}

ClockDisplay* ClockFace::LoadDisplay(LPCSTR type, LPCSTR prefix, const int x, const int y, const int w, const int h)
{
	if (stricmp(type, "aatext") == 0)
	{
		return NULL;
	}
	else
	{
	#ifdef _DEBUG
		_LSLog(LOG_DEBUG, Prefix, "Loading Text");
	#endif
		return new TextClock(prefix, x, y, w, h);
	}
}

ClockHand* ClockFace::LoadHand(const int type_id, LPCSTR type, COLORREF ci, COLORREF co, int l, int w, int b, int a)
{
	if (stricmp(type, "box") == 0)
	{
#ifdef _DEBUG
		_LSLog(LOG_DEBUG, Prefix, "Loading boxhand");
#endif
		return new BoxHand(type_id, ci, co, l, w, b, a);
	}
	else if (stricmp(type, "triangle") == 0)
	{
#ifdef _DEBUG
		_LSLog(LOG_DEBUG, Prefix, "Loading trihand");
#endif
		return new TriHand(type_id, ci, co, l, w, b, a);
	}
	else if (stricmp(type, "aaline") == 0)
	{
#ifdef _DEBUG
		_LSLog(LOG_DEBUG, Prefix, "Loading AALineHand");
#endif
		return new AALineHand(type_id, ci, co, l, w, b, a);
	}
	else if (stricmp(type, "aabox") == 0)
	{
#ifdef _DEBUG
		_LSLog(LOG_DEBUG, Prefix, "Loading AABoxHand");
#endif
		return new AABoxHand(type_id, ci, co, l, w, b, a);
	}
	else if (stricmp(type, "aatriangle") == 0)
	{
#ifdef _DEBUG
		_LSLog(LOG_DEBUG, Prefix, "Loading AATriHand");
#endif
		return new AATriHand(type_id, ci, co, l, w, b, a);
	}
	else 
	{
#ifdef _DEBUG
		_LSLog(LOG_DEBUG, Prefix, "Loading Linehand (default)");
#endif
		return new LineHand(type_id, ci, co, l, w, b, a);
	}
}