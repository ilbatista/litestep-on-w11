#ifndef __TEXTCLOCK_H
#define __TEXTCLOCK_H

#include <windows.h>
#include <time.h>
#include "clockdisplay.h"
#include "TextDrawer.h"

class TextClock : public ClockDisplay
{
public:
	TextClock(LPCSTR prefix, int x, int y, int w, int h);
	~TextClock();

	void DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);

	void ConvertSystemTime(tm* tm_time, const SYSTEMTIME time);
	bool IsDaylightSaving();
	bool IsLeapYear(const int year);
	int DayInYear(const SYSTEMTIME time);
	int StringEscapeCopy(LPSTR szout, LPCSTR szin);

protected:
	char* szTextFormat;
	TextDrawer* text_painter;

};

#endif