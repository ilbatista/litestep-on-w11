/****************************************************************************

ClockWork 0.6
by Vendicator (http://vendicator.shellfront.org | vendicator@mail.com)

Analog clock module which should work on desktop/lsbox or in wharf.
Made since I couldn't find a working desktop analog clock module.

Used window&bitmap handling from systray2, clock drawing from aLsClock.
Code is split into several files due to the OOP layout and me wanting
to have modular code snippets.
Note that windows.cpp/.h are the lswinbase from ls (just wanted to have
them included if I wanted to base something else on this)

Note:
You need to use ClockWorkHandType "box" or other transparent compatible
hand type inorder for ClockWork to be visible with completely transparent
backgrounds.

Note2:
Inorder to use antialiased lines you need to have the gdiplus.dll library
installed (only non XP users, XP ships with gdi+ installed),
a distributable package is available from Microsoft at:
http://www.microsoft.com/downloads/release.asp?releaseid=32738
Will not work with win95.


Loading the module:
	Extract the ClockWork.dll file to either your LiteStep dir, or
	the modules directory of the theme which you are currently
	using. Add a LoadModule line to configure LiteStep to load
	the module such as:

	LoadModule	"$LiteStepDir$ClockWork.dll"
	If the module is located in the LiteStep directory, Or

	LoadModule	"$ModulesDir$ClockWork.dll"
	if the module is in the modules dir of the theme.


Step.rc Settings:

Size & Placement:
	ClockWorkX
	Int, default: 0
	X placement of the clock window

	ClockWorkY
	Int, default: 0
	Y placement of the clock window

	ClockWorkWidth
	Int, default: 64 (alt. bitmap size)
	Sets width of the clock window

	ClockWorkHeight
	Int, default: 64 (alt. bitmap size)
	Sets height of the clock window


Window & bitmaps:
	ClockWorkHidden
	Bool, default: false
	Set whether to start ClockWork in hidden state

	ClockWorkAlwaysOnTop
	Bool, default: false
	Set whether ClockWork should be placed above all other windows

	ClockWorkBitmap
	String, default: none
	Location of the image to use as bg for ClockWork
	(use a transparent compatible hand when using a completely transparent bg)

	ClockWorkBitmapTiled
	Bool, default: false
	Set whether to tile if on otherwise stretch the image if window size is different from bitmap size

	ClockWorkBorderSize
	Int, default: 0
	Set width of border which isn't stretched/tiled

	ClockWorkBorderTop
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of top border

	ClockWorkBorderLeft
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of left border

	ClockWorkBorderRight
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of right border

	ClockWorkBorderBottom
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of bottom border

	ClockWorkBorderDrag
	Bool, default: false (not activated)
	If specified the user is able to reposition the clock using the mouse

	ClockWorkBGColor
	Color, default: FFFFFF
	Background color to use instead of bitmap
	(use a transparent compatible hand when using a completely transparent bg)

	ClockWorkBorderColor
	Color, default: 000000
	Color of border

	ClockWorkDoNotAlignUsingBorders
	Bool, default: false
	When this is set to false (default) clockwork will use the borders to find
	the size & center of the clock (not specifying clock hand length will also
	cause the hands to be shorter).
	When this is set to true, the center will be calculated using the specified
	size of the clockwork window.


Clock hands:
	ClockWorkHandType "box" / "line" / "triangle" / (gdi+) "aabox" / "aaline" / "aatriangle"
	string, default: "line"
	Determines the clock hand type that should be used.
	"line" is the standard version, using LineTo()
	(*) "box" similar to line, but drawn using polygons
	(*) "triangle" also drawn using polygons, wide base to pointy end
	(+) "aaline" line with antialiasing
	(+) "aabox" same as "box" but with antialiasing
	(+) "aatriangle" same as "triangle" but with antialiasing
	* = polygon based and therefore transparent compatible,
	use this if combined with a completely transparent region
	to allow the window region to be adapted to include the hands.
	Rounding errors might make the width of these modes look inaccurate at times.
	+ = modes that uses gdi+ to draw, accepts alpha transparency & antialiasing
	see top of readme if you get an error loading this module,
	then you will need to download the .dll from MS (http://www.microsoft.com/downloads/release.asp?releaseid=32738).

	ClockWorkHandAlpha
	Int between 0-255, default: 255
	Sets the alpha transparency of all the hands, only works with gdi+ handtypes (aa[..])

	ClockWorkHandBorder
	Int, default: 1
	Sets the border width that is painted with the normal color

	ClockWorkNoSeconds
	BOOL, default: false
	Disable display of the seconds hand

	ClockWorkResolution
	Int, default: 60
	Defines into how many steps the clock is divided (for smoother clocksteps increase this).
	Note that this increases mem usage (8b * Resolution) as well as cpu
	(since you need to update the window more often to see the effect)

	ClockWorkRefresh
	Int, default: 60000 / ClockWorkResolution
	Sets how often the clock should be refreshed, time given in milliseconds.
	With the default ClockWorkResolution=60, the refresh would be once every second.
	Just specifying a different resolution will adapt the refresh to optimum, but
	you have the ability to override the refresh setting if you feel like it.

	ClockWorkDrawOrder ? ? ?
	3 chars, default: h m s
	Determines in what order the hands should be drawn, h=hour, m=minute, s=second
	The hands are drawn above eachother so the last will be on top of the other two.

	ClockWorkHourHandType (same modes as ClockWorkHandType)
	string, default: whatever ClockWorkHandType is set to
	Individual hand type

	ClockWorkMinuteHandType (same modes as ClockWorkHandType)
	string, default: whatever ClockWorkHandType is set to
	Individual hand type

	ClockWorkSecondHandType (same modes as ClockWorkHandType)
	string, default: whatever ClockWorkHandType is set to
	Individual hand type

	ClockWorkHourAlpha
	Int between 0-255, default: whatever ClockWorkHandAlpha is set to
	Individual alpha transparency of hand

	ClockWorkMinuteAlpha
	Int between 0-255, default: whatever ClockWorkHandAlpha is set to
	Individual alpha transparency of hand

	ClockWorkSecondAlpha
	Int between 0-255, default: whatever ClockWorkHandAlpha is set to
	Individual alpha transparency of hand

	ClockWorkHourColor
	Color, default: 0000FF
	Sets color of the hours hand

	ClockWorkMinuteColor
	Color, default: 00FF00
	Sets color of the minutes hand

	ClockWorkSecondColor
	Color, default: FF0000
	Sets color of the seconds hand

	ClockWorkHourInnerColor
	Color, default: what ClockWorkHourColor is set to
	Sets the internal color of the hours hand in polygon hand types (ie. box),
	the normal color is then used as a wide border around the hand shape
	Note: AABox & AATriangle hand types accepts FF00FF for transparency

	ClockWorkMinuteInnerColor
	Color, default: what ClockWorkMinuteColor is set to
	Sets the internal color of the minutes hand in polygon hand types (ie. box),
	the normal color is then used as a border around the hand shape
	Note: AABox & AATriangle hand types accepts FF00FF for transparency

	ClockWorkSecondInnerColor
	Color, default: what ClockWorkSecondColor is set to
	Sets the internal color of the seconds hand in polygon hand types (ie. box),
	the normal color is then used as a border around the hand shape
	Note: AABox & AATriangle hand types accepts FF00FF for transparency

	ClockWorkHourBorderWidth
	Int, default: whatever ClockWorkHandBorder is set to
	Sets the border width that is painted with the normal color

	ClockWorkMinuteBorderWidth
	Int, default: whatever ClockWorkHandBorder is set to
	Sets the border width that is painted with the normal color

	ClockWorkSecondBorderWidth
	Int, default: whatever ClockWorkHandBorder is set to
	Sets the border width that is painted with the normal color

	ClockWorkHourWeight
	Int, default: 3
	Sets the width of the hours hand
	  
	ClockWorkMinuteWeight
	Int, default: 2
	Sets the width of the mintes hand

	ClockWorkSecondWeight
	Int, default: 1
	Sets the width of the seconds hand

	ClockWorkHourLength
	Int, default: 70% of the smallest of the window width/height
	Length of the hours hand

	ClockWorkMinuteLength
	Int, default: 90% of the smallest of the window width/height
	Length of the minutes hand

	ClockWorkSecondLength
	Int, default: 90% of the smallest of the window width/height
	Length of the seconds hand


Text Clock Display:
	ClockWorkTextDisplays name1 name2 etc
	String, default: ""
	Lists the names of the text displays you want to use, in
	the rest of the documentation these names will be refered
	to as [TextName]. So if you have a text display named Date
	then ClockWork will look for DateFormat etc.
	
	[TextName]Format
	String, default: %H:%M:%S %Y-%m-%d
	Formats the text to display, according to following options:
		%a - Abbreviated weekday name
		%A - Full weekday name
		%b - Abbreviated month name
		%B - Full month name
		%c - Date and time representation appropriate for locale
		%d - Day of month as decimal number (01 - 31)
		%H - Hour in 24-hour format (00 - 23)
		%I - Hour in 12-hour format (01 - 12)
		%j - Day of year as decimal number (001 - 366)
		%m - Month as decimal number (01 - 12)
		%M - Minute as decimal number (00 - 59)
		%p - Current locale�s A.M./P.M. indicator for 12-hour clock
		%S - Second as decimal number (00 - 59)
		%U - Week of year as decimal number, with Sunday as first day of week (00 � 53)
		%w - Weekday as decimal number (0 - 6; Sunday is 0)
		%W - Week of year as decimal number, with Monday as first day of week (00 � 53)
		%x - Date representation for current locale
		%X - Time representation for current locale
		%y - Year without century, as decimal number (00 - 99)
		%Y - Year with century, as decimal number
		%z, %Z - Time-zone name or abbreviation; no characters if time zone is unknown
		%% - Percent sign

	[TextName]X
	Int, default: Inner area of clock
	Placement of text in clock

	[TextName]Y
	Int, default: Inner area of clock
	Placement of text in clock

	[TextName]Width
	Int, default: Inner area of clock
	Placement of text in clock

	[TextName]Height
	Int, default: Inner area of clock
	Placement of text in clock

	[TextName]Color
	Color, default: 000000
	Color of text

	[TextName]ShadowColor
	Color, default: 808080
	Color of texts shadow

	[TextName]ShadowDepth
	Int, default: 0
	Displacement of text shadow (pixels shifted down/right, 45degrees).

	[TextName]Font
	Font, default: "Arial"
	Font of text

	[TextName]FontSize
	Int, default: 12
	Size of text

	[TextName]Bold
	Bool, default: 
	Whether the text should be bold or not

	[TextName]Italic
	Bool, default: 
	Makes text italic

	[TextName]HorizontalJustify
	String, possible: left, right, center, default: center
	Horizontal justification of text

	[TextName]VerticalJustify
	String, possible: top, bottom, center, default: center
	Vertical justification of text

	[TextName]WordBreak
	Bool, default: 
	Breaks words per line so it is used more effectively (more text/line)


Mouse commands:
	ClockWorkOnLeftDBL
	String, default: !none
	Command to be executed when the user left double clicks the clock

	ClockWorkOnLeftDown
	String, default: !none
	Command to be executed when the user presses the left button on clock

	ClockWorkOnLeftUp
	String, default: !none
	Command to be executed when the user releases the left button on clock

	ClockWorkOnRightDBL
	String, default: !none
	Command to be executed when the user right double clicks the clock

	ClockWorkOnRightDown
	String, default: !none
	Command to be executed when the user presses the right button on clock

	ClockWorkOnRightUp
	String, default: !none
	Command to be executed when the user releases the right button on clock

	ClockWorkOnMiddleDBL
	String, default: !none
	Command to be executed when the user middle double clicks the clock

	ClockWorkOnMiddleDown
	String, default: !none
	Command to be executed when the user presses the middle button on clock

	ClockWorkOnMiddleUp
	String, default: !none
	Command to be executed when the user releases the middle button on clock


Bangs:
	!ClockWorkSetTime
	Brings up the date/time settings from the control panel

	!ClockWorkHook
	Hooks ClockWork to lsbox

	!ClockWorkSetOnTop on/off
	Sets ClockWorks window to be ontop or not, if no argument specified it's turned on.

	!ClockWorkToggleOnTop
	Toggles the on top status

	!ClockWorkShow
	Shows ClockWorks window if hidden

	!ClockWorkHide
	Hides ClockWorks window

	!ClockWorkToggle
	Toggles visible/hidden status of ClockWork

	!ClockWorkMove x y
	Move ClockWork to the given position

	!ClockWorkSize
	Change the size of ClockWork


Changelog:
	Changed [Vendicator, 2003-07-28, release 0.60]
	  - Added ability to use multiple text displays.
	  - Starting GDI+ with module, not window creation.

	Changed [Vendicator, 2003-07-26]
	  - Saving the pens/brushes when painting for increased speed.

	Changed [Vendicator, 2003-07-25]
	  - Using BoxPainter for background.
	  - Updated the available bangs for wharfed/normal load.

	Changed [Vendicator, 2003-07-24]
	  - Using _LSLog etc, might work with older ls builds.
	  - Using updated GuiWindow, LSUtils, WinUtils from VTK.

	Added [Vendicator, 2003-01-13]
	  - Worked on time output, fixing some options

	Added [Vendicator, 2003-01-12]
	  - Added time output to textdisplay using standard C function (thanks to nivenh)

	Added [Vendicator, 2003-01-11]
	  - Started work on text display

	Fixed [Vendicator, 2003-01-05]
	  - Fixed so that the debug mode works without seconds hand

	Fixed [Vendicator, 2002-12-03]
	  - Using an integer based approach always when calculating hand widths, thought
	    pure double would be more accurate, but checking with pythagoras this was better

	Fixed [Vendicator, 2002-12-02]
	  - Fixed behaviour with IsVisible(), fixed ClockWorkHidden

	Fixed [Vendicator, 2002-12-02, release: 0.51]
	  - Finally redesigned code to remove the 3 switches that ran on every update,
	    reducing cpu usage. Now the biggest issue is the gfx code, which is pure
		windows functions, so there isn't much that can be done now...
	  - Minor changes to reduce mem usage.
	  - Made changes to be able to add other clock drawers such as text...
	  - Fixed small bugs thanks to Ilmcuts

	Fixed [Vendicator, 2002-12-01]
	  - Renamed hour, minute, second border setting to what's stated in readme

	Added [Vendicator, 2002-11-30, release: 0.5]
	  - Added AABox & AATriangle & AALine hand types
	  - Internally calculating points with decimals
	  - AABox & AATriangle accepts FF00FF inner colors for transparency
	  - Even though it had been in code, now the readme states that you can
		set individual hand types with ClockWorkHourHandType, ClockWorkMinuteHandType
		& ClockWorkSecondHandType
	  - Added ClockWorkHandBorder, ClockWorkHourBorder, ClockWorkMinuteBorder, ClockWorkSecondBorder
	    to be able to specify borders when painting inner/outer color
	  - Less logging when not running the debug build

	Fixed [Vendicator, 2002-11-29]
	  - Buffered all trig indexes to reduce cpu, increases mem usage by ~250kb
	  - Filled bg first with FF00FF when using bitmaps to ensure that 
	    transparency actually work from bitmap
	  - Added ClockWorkNoAdaptRegion, which should speed up tri & box draw modes
	    (works by disabling the transparancy check, so if the area is transparent
		underneath the hands, they will not show anymore)
	  - Saved 3 divisions on every paint, reducing cpu usage somewhat
	  - Added a max resolution at 60000
	    (limit for milliseconds when calculating seconds hand position)

	Fixed [Vendicator, 2002-11-13]
	  - Plugged two gdi leaks, one from each recycle and another from each update
	    when using one of the polygon clock hands
		(thanks to NeXTer for pointing me in the right direction)
	  - Fixed ClockWorkDrawOrder from using string reading (which would only get
	    the first char) now using line reading which gets them all
	  - Also fixed a possible uninitialized variable problem regarding to colors

	Fixed [Vendicator, 2002-11-13]
	  - Switched color variables so that InnerColor actually sets the right one =)
	  - Renamed readme file to ClockWork.txt (yay!)

	Added [Vendicator, 2002-11-13]
	  - Changed default behaviour to use borders when calculating center
	  - ClockWorkDoNotAlignUsingBorders to specify center alignment
	    without taking borders into consideration
	  - Added ClockWorkSecondInnerColor, ClockWorkMinuteInnerColor, ClockWorkHourInnerColor
	    to be able to specify an inner color for polygon based clock hand types
	  - Added new clock hand type: triangle

	Added [Vendicator, 2002-11-12]
	  - Start of support for different inner & outer colors for polygon hands

	Added [Vendicator, 2002-11-12]
	  - Fixed color being painted even tho a bitmap was used
	  - Changed default bgcolor to FFFFFF
	  - Changed the clockface structure to use hand object so different hands
	    can be made and selected.
	  - Added ClockWorkHandType to select which hand type to use
	  - Added clock hand type "box", which is completely transparent compatible

	Added [Vendicator, 2002-11-10]
	  - Ability to specify paint order with ClockWorkDrawOrder x x x

	Added [Vendicator, 2002-11-09]
	  - Initial Release


Todo:
	- All tooltips in Windows disappear when using transp. bg (not mirc buttons?) and resolution > ~180
	- Dynamically load aa functions?
	- Clickthrough, pass mouse message to parent, or perhaps directly to desktop?
	- Modifier keys in clickable class
	- Temporarily disable region adapt in aatri/aabox modes? to avoid pink jaggies
	- Background bitmap copy for aa to work on bg etc, talk to rainy...
	- overlay for hour markers..
	- percent hand length for stretched clock look, adapting to angle in clock
	- More different types of hands?


I got GDIPlus.dll, new theme tenebrae2, and now the clock module is flickering like crazy
(in Win2K).  And I no longer see the digital clock on the left side of the task bar.
And for some reason, when I enabld the clock, theh scroll-lock flash is now a constant-on,
and I can't open the popups by clicking on the desktop.
(and can't open any popup folders when I click on the themepopup button).
That makes it kind of hard to use. :)

****************************************************************************/

#include <math.h>
#include "ClockWork.h"
#include "../VTK/Apis.h"
#include "../VTK/WinUtils.h"
#include "../VTK/LSUtils.h"
#include "TrigBuffer.h"
#include "log_on.h"
using namespace LSUtils;

// prefix for all settings to be read
const char szSettingsPrefix[] = "ClockWork";

// messages that we want to listen to
const int LSMsgs[] = {LM_GETREVID, LM_REFRESH, 0};

const char szAppName[] = "ClockWork"; // Our window class, etc
LPCSTR szLogName = "ClockWork";
const char rcsRevision[] = "$Revision: 0.6 $"; // Our Version
const char rcsId[] = "$Id: ClockWork.cpp,v 0.6 19:46:35 Vendicator Exp $"; // The Full RCS ID.
ClockWork *clockwork; // The module

// register these bangs

const Bang CommonBangs[] =
{
#ifdef DEBUG
	{"!ClockWorkInfo", &BangInfo},
#endif
	{"!ClockWorkSetTime", &BangSetTime}
};

const Bang GuiBangs[] =
{
	{"!ClockWorkHook", &BangHook},
	{"!ClockWorkSetOnTop", &BangSetOnTop},
	{"!ClockWorkToggleOnTop", &BangToggleOnTop},
	{"!ClockWorkShow", &BangShow},
	{"!ClockWorkHide", &BangHide},
	{"!ClockWorkToggle", &BangToggle},
	{"!ClockWorkMove", &BangMove},
	{"!ClockWorkSize", &BangSize}
};

// calculate how many bangs there are
const int nGuiBangs = sizeof(GuiBangs) / sizeof(GuiBangs[0]);
const int nCommonBangs = sizeof(CommonBangs) / sizeof(CommonBangs[0]);


//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	clockwork = new ClockWork(GetLitestepWnd(), code, false);
	return code;
}

int initWharfModule(HWND parentWnd, HINSTANCE dllInst, void *wharfData)
{
	int code;
	Window::init(dllInst);
	clockwork = new ClockWork(parentWnd, code, true);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete clockwork;
}

void quitWharfModule(HINSTANCE dllInst)
{
	delete clockwork;
}


//=========================================================
// Bang commands
//=========================================================

void BangSetTime(HWND caller, LPCTSTR szArgs)
{
	// from Popup2, originally from aLsClock
	char WinDir[256];
	GetSystemDirectory(WinDir, 256);
	ShellExecute(clockwork->GetHWND(), "open", "rundll32.exe",
		"shell32.dll,Control_RunDLL timedate.cpl",
		WinDir, SW_SHOWNORMAL);
}

void BangHook(HWND caller, LPCTSTR szArgs)
{
	clockwork->BoxHook(szArgs);
}

void BangSetOnTop(HWND caller, LPCSTR args)
{
	if (stricmp(args, "off") == 0)
		clockwork->SetOnTop(false);
	else
		clockwork->SetOnTop(true);
}

void BangToggleOnTop(HWND caller, LPCSTR args)
{
	clockwork->ToggleOnTop();
}

void BangShow(HWND caller, LPCSTR args)
{
	clockwork->Show();
}

void BangHide(HWND caller, LPCSTR args)
{
	clockwork->Hide();
}

void BangToggle(HWND caller, LPCSTR args)
{
	clockwork->ToggleVisibility();
}

void BangMove(HWND caller, LPCSTR args)
{
	char szX[MAX_LINE_LENGTH], szY[MAX_LINE_LENGTH];
	char* tokens[2] = {szX, szY};
	LCTokenize( args, tokens, 2, NULL );
	clockwork->Move(atoi(szX), atoi(szY));
}

void BangSize(HWND caller, LPCSTR args)
{
	char szCX[MAX_LINE_LENGTH], szCY[MAX_LINE_LENGTH];
	char* tokens[2] = {szCX, szCY};
	LCTokenize( args, tokens, 2, NULL );
	clockwork->Size(atoi(szCX), atoi(szCY));
}

#ifdef DEBUG
void BangInfo(HWND caller, LPCSTR args)
{
	clockwork->Info();
}
#endif


//=========================================================
// Module code
//=========================================================

#ifdef DEBUG
void ClockWork::Info()
{
	_LSLogPrintf(LOG_DEBUG, szLogName, "Window: %d pos:%d,%d size:%d,%d, p:%d", GetHWND(), GetX(), GetY(), GetWidth(), GetHeight(), GetParentHWND());
}
#endif

HWND ClockWork::GetModuleWnd()
{
	return GuiWindow::GetHWND();
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------

ClockWork::ClockWork(HWND parentWnd, int& code, bool Wharfed) :
	GuiWindow(szAppName, parentWnd, Wharfed),
	Clickable(szSettingsPrefix),
	bTranspBack(FALSE),
	clock(szSettingsPrefix)
{

	InitAPIs();

#ifdef DEBUG
	_LSLogPrintf(LOG_WARNING, szLogName, "*Debug* Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#else
	_LSLogPrintf(LOG_DEBUG, szLogName, "Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#endif

	// get desktop & ls window handle
	HWND desktop = WinUtils::GetDesktopHWND();
	HWND litestep = GetLitestepWnd();

	if (!litestep) {
		_LSLog(LOG_ERROR, szLogName, "Could not find litestep window, aborting");
		code = 2;
		return;
	}

	// Initialize GDI+.
	int gdiload = GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
	if (gdiload == Ok)
		_LSLogPrintf(LOG_DEBUG, szLogName, "GDI+ started ok (%d)", gdiload);
	else
		_LSLogPrintf(LOG_ERROR, szLogName, "GDI+ failed to start (%d)", gdiload);

	// First read gui props to get a bitmap to use for size when no size specified
	ReadGUIProps();
	ReadSizeAndPos();
	ReadClickSettings();

	// pass where to paint along to face of clock
	clock.SetBorders(borderTop, borderLeft, borderRight, borderBottom);
	clock.SetSize(GetWidth(), GetHeight());

	if (bDoNotAlignUsingBorders)
		clock.CalcCenter(GetWidth(), GetHeight());
	else
		clock.CalcCenter();

	clock.ReadClockSettings();
	
	_LSLogPrintf(LOG_DEBUG, szLogName, "Creating Window, pos:%d,%d size:%d,%d, p:%d, l:%d, d:%d", GetX(), GetY(), GetWidth(), GetHeight(), GetParentHWND(), litestep, desktop);
	
	if (!CreateWnd(NULL)) // szAppName
	{
		_LSLog(LOG_ERROR, szLogName, "Unable to create window");
		MessageBox(NULL, "Unable to create window", szAppName, MB_TOPMOST);
		code = 1;
		return ;
	}
	else
	{
		// make sure it handle dblclicks... =)
		SetClassLong(hWnd, GCL_STYLE, CS_DBLCLKS | GetClassLong(hWnd, GCL_STYLE));

		// show window
		InvalidateRect( hWnd, NULL, TRUE );

#ifdef _DEBUG
		_LSLogPrintf(LOG_DEBUG, szLogName, "Window created, 0x%X", GetHWND());
#endif
	}
	
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)LSMsgs);

	// show/hide window
	FixVisibility();
	
	if ( !IsInWharf() )
	{
		InsertBangs(GuiBangs, nGuiBangs);
	}
	InsertBangs(CommonBangs, nCommonBangs);

	// Set a timer for clock
	SetTimer(hWnd, 0, clock.GetRefresh(), NULL);

	code = 0;
}

// get the position and size of the main window
// using different method if it's docked in the wharf
void ClockWork::ReadSizeAndPos()
{
	if ( IsInWharf() )
	{
		RECT rc;
		int wharfBorder;
		_LSLog(LOG_DEBUG, szLogName, "Loaded in Wharf, reading Wharf settings");

		// get the wharf window size
		GetClientRect( GetParentHWND(), &rc );
		wharfBorder = GetRCInt( "WharfBevelWidth", 0 );

#ifdef _DEBUG
		_LSLogPrintf(LOG_DEBUG, szLogName, "wharf: p: %d,%d, s:%d,%d", rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top);
#endif

		SetPosition(wharfBorder, wharfBorder);
		SetSize(rc.right - 2 * wharfBorder, rc.bottom - 2 * wharfBorder);
		_LSLog(LOG_DEBUG, szLogName, "Done reading wharf settings");
	}
	else
	{
		int defaultX = 64, defaultY = 64;
		if (painter.IsUsingBitmap())
			painter.GetBitmapSize(&defaultX, &defaultY);

		_LSLog(LOG_DEBUG, szLogName, "Not in wharf, reading size settings");
		SetPosition(PrefixedGetRCCoordinate(szSettingsPrefix, "X", 0, GetSystemMetrics(SM_CXSCREEN)), PrefixedGetRCCoordinate(szSettingsPrefix, "Y", 0, GetSystemMetrics(SM_CYSCREEN)));
		SetSize(PrefixedGetRCInt(szSettingsPrefix, "Width", defaultX), PrefixedGetRCInt(szSettingsPrefix, "Height", defaultY));
		_LSLog(LOG_DEBUG, szLogName, "Done reading size settings");
	}
}

void ClockWork::ReadGUIProps()
{
	char szTemp[256];
	int tmpInteger = 0;

	// load settings here
	// ===========================================
	BOOL hidden = PrefixedGetRCBool(szSettingsPrefix, "Hidden", TRUE);
#ifdef DEBUG
	BOOL visible = IsInWharf() || !hidden;
#endif
	SetVisible(IsInWharf() || !hidden);

#ifdef DEBUG
	_LSLogPrintf(LOG_DEBUG, szLogName, "Hidden: %d, Visible: %d", hidden, visible);
#endif

	SetTop(!IsInWharf() && PrefixedGetRCBool(szSettingsPrefix, "AlwaysOnTop", TRUE));
	tmpInteger = PrefixedGetRCInt(szSettingsPrefix, "BorderSize", 0);
	borderTop = max(PrefixedGetRCInt(szSettingsPrefix, "BorderTop", tmpInteger), 0);
	borderLeft = max(PrefixedGetRCInt(szSettingsPrefix, "BorderLeft", tmpInteger), 0);
	borderRight = max(PrefixedGetRCInt(szSettingsPrefix, "BorderRight", tmpInteger), 0);
	borderBottom = max(PrefixedGetRCInt(szSettingsPrefix, "BorderBottom", tmpInteger), 0);
	borderDrag = !IsInWharf() && PrefixedGetRCBool(szSettingsPrefix, "BorderDrag", TRUE);
	bDoNotAlignUsingBorders = PrefixedGetRCBool(szSettingsPrefix, "DoNotAlignUsingBorders", TRUE);
	painter.SetBorders(borderLeft, borderTop, borderRight, borderBottom);

	// skinning
	PrefixedGetRCString(szSettingsPrefix, TEXT("Bitmap"), szTemp, TEXT(""), MAX_LINE_LENGTH);
	if ( szTemp[0] == '\0' ) // TCHAR version?
	{
		painter.SetColors(
			PrefixedGetRCColor(szSettingsPrefix, TEXT("BGColor"), RGB(255, 255, 255)),
			PrefixedGetRCColor(szSettingsPrefix, TEXT("BorderColor"), RGB(0, 0, 0))
		);
	}
	else
	{
		painter.SetBitmap(LoadLSImage(szTemp, NULL));
		painter.SetTiled(PrefixedGetRCBool(szSettingsPrefix, TEXT("BitmapTiled"), TRUE));
	}
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
ClockWork::~ClockWork()
{
	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)LSMsgs);

	if ( !IsInWharf() )
	{
		RemoveBangs(GuiBangs, nGuiBangs);
	}
	RemoveBangs(CommonBangs, nCommonBangs);

	KillTimer(hWnd, 0);

	destroyWindow();
	GdiplusShutdown(gdiplusToken);
}


//=========================================================
// Registered messages
//=========================================================

void ClockWork::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onEndSession,       WM_ENDSESSION)
		MESSAGE(onEndSession,       WM_QUERYENDSESSION)
		MESSAGE(onCreate,			WM_CREATE)
		MESSAGE(onDestroy,			WM_DESTROY)
		MESSAGE(onGetRevId,         LM_GETREVID)
		MESSAGE(onSysCommand,       WM_SYSCOMMAND)
		//MESSAGE(onDisplayChange,	WM_DISPLAYCHANGE)
		MESSAGE(onPaint,			WM_PAINT)
		MESSAGE(onTimer,			WM_TIMER)
		MESSAGE(onMouse,			WM_LBUTTONDBLCLK)
		MESSAGE(onMouse,			WM_LBUTTONDOWN)
		MESSAGE(onMouse,			WM_LBUTTONUP)
		MESSAGE(onMouse,			WM_RBUTTONDBLCLK)
		MESSAGE(onMouse,			WM_RBUTTONDOWN)
		MESSAGE(onMouse,			WM_RBUTTONUP)
		MESSAGE(onMouse,			WM_MBUTTONDBLCLK)
		MESSAGE(onMouse,			WM_MBUTTONDOWN)
		MESSAGE(onMouse,			WM_MBUTTONUP)
	END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================

void ClockWork::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void ClockWork::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
	case 0:
		sprintf(buf, "ClockWork.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
	case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
	default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}

void ClockWork::onCreate(Message& message)
{
#ifdef DEBUG
	_LSLog(LOG_DEBUG, szLogName, "OnCreate: Setting ClockWork Window Props.");
#endif
	
	painter.SetWindow(hWnd);
	painter.SetSize(nWidth, nHeight);
	painter.CreateBackground();

	// set always on top
	if (IsOnTop())
		SetOnTop(true);
	else
		SetOnTop(false);
}

void ClockWork::onDestroy(Message& message)
{
}

void ClockWork::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void ClockWork::onPaint(Message& message)
{
	HDC hdcBuffer;
	HBITMAP hbmBuffer, hbmBufOld;
	HRGN hrgn = NULL;

	PAINTSTRUCT ps;
	HDC	hdcScreen = BeginPaint(hWnd, &ps);

	hdcBuffer = CreateCompatibleDC(hdcScreen);
	hbmBuffer = CreateCompatibleBitmap(hdcScreen, GetWidth(), GetHeight());
	hbmBufOld = (HBITMAP)SelectObject(hdcBuffer, hbmBuffer);

	bool bTranspBack = painter.IsTransparent();
	if (bTranspBack)
		hrgn = CreateRectRgn( 0, 0, 0, 0 );

	// blit the skin
	painter.PaintBackground(hdcBuffer, hrgn);

	// draw clock on the buffer here...
	clock.DrawClock(hdcBuffer, hrgn);

	// set the windowRgn, windows deletes region after it's done with it
	if (bTranspBack)
	{
		// system owns the region now, deletes it... (?)
		// removes all tooltips in windows?
		SetWindowRgn(hWnd, hrgn, TRUE);
	}

	// when the region is applied you can use a simple SRCCOPY from the buffer
	BitBlt(hdcScreen, 0, 0, GetWidth(), GetHeight(), hdcBuffer, 0, 0, SRCCOPY);

	// reselect the oldBitmap and kill the new one
	SelectObject(hdcBuffer, hbmBufOld);
	DeleteObject(hbmBuffer);

	// remove the memory DC
	DeleteDC(hdcBuffer);

	EndPaint(hWnd, &ps);
}

void ClockWork::onDisplayChange(Message& message)
{
#ifdef DEBUG
	int width = message.lParamLo;
	int height = message.lParamHi;

	_LSLogPrintf(LOG_DEBUG, szLogName, "Display change (%d,%d), trying to fix position", width, height);
#endif

	// test
	//ToggleOnTop();
	//ToggleOnTop();
	//FixPosition();

#ifdef DEBUG
	Info();
#endif
}

void ClockWork::onTimer(Message& message)
{
	InvalidateRect(hWnd, NULL, TRUE);
}

void ClockWork::onMouse(Message& message)
{
	bool trapped;
	trapped = MouseExecute(message.uMsg);

	// pass the message along if it wasn't for us...
	//if (!trapped)
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}
