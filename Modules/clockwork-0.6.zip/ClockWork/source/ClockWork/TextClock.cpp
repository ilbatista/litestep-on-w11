#include <time.h>
#include "TextClock.h"
#include "../VTK/LSUtils.h"
#include "../VTK/apis.h"
#include <sys/timeb.h>
#include "log_on.h"

using namespace LSUtils;
extern LPCSTR szLogName;

TextClock::TextClock(LPCTSTR Prefix, int x, int y, int w, int h)
{
	char szTemp[MAX_LINE_LENGTH];

	// set up the text painter
	text_painter = new TextDrawer(false, NULL);

	// text position
	int xpos = PrefixedGetRCInt(Prefix, TEXT("X"), x);
	int ypos = PrefixedGetRCInt(Prefix, TEXT("Y"), y);
	int width = PrefixedGetRCInt(Prefix, TEXT("Width"), w);
	int height = PrefixedGetRCInt(Prefix, TEXT("Height"), h);
	text_painter->SetRect(xpos, ypos, width, height);

	// colors & shadows
	text_painter->SetColors( PrefixedGetRCColor(Prefix, TEXT("Color"), RGB(0, 0, 0)), RGB(255, 0, 255) );
	text_painter->SetShadow( PrefixedGetRCColor(Prefix, TEXT("ShadowColor"), RGB(80, 80, 80)), PrefixedGetRCInt(Prefix, TEXT("ShadowDepth"), 0) );

	// text properties
	PrefixedGetRCString(Prefix, TEXT("Font"), szTemp, TEXT("Arial"), MAX_LINE_LENGTH);
	int fontsize = PrefixedGetRCInt(Prefix, TEXT("FontSize"), 12);
	bool bold = PrefixedGetRCBool(Prefix, TEXT("Bold"), TRUE);
	bool italic = PrefixedGetRCBool(Prefix, TEXT("Italic"), TRUE);
	text_painter->LoadFont(szTemp, fontsize, bold, italic);

	int hjust = 0;
	// text justification in text print
	PrefixedGetRCString(Prefix, TEXT("HorizontalJustify"), szTemp, TEXT("Center"), MAX_LINE_LENGTH);
	if ( stricmp(szTemp, "left") == 0 )
		hjust |= DT_LEFT;
	else if ( stricmp(szTemp, "right") == 0 )
		hjust |= DT_RIGHT;
	else
		hjust |= DT_CENTER;

	int vjust = 0;
	// text justification in text print
	PrefixedGetRCString(Prefix, TEXT("VerticalJustify"), szTemp, TEXT("Center"), MAX_LINE_LENGTH);
	if ( stricmp(szTemp, "top") == 0 )
		vjust |= DT_TOP;
	else if ( stricmp(szTemp, "bottom") == 0 )
		vjust |= DT_BOTTOM;
	else
		vjust |= DT_VCENTER;

	// word break?
	bool wordbreak = PrefixedGetRCBool(Prefix, TEXT("WordBreak"), TRUE);

	text_painter->SetProperties(hjust, vjust, wordbreak);

	// format:
	PrefixedGetRCString(Prefix, TEXT("Format"), szTemp, TEXT("%H:%M:%S %Y-%m-%d"), MAX_LINE_LENGTH);
	szTextFormat = new char[strlen(szTemp)+1];
	int o = StringEscapeCopy(szTextFormat, szTemp);
	//MessageBox(NULL, szTextFormat, "Test", MB_OK);

	_LSLogPrintf(LOG_DEBUG, szLogName, "format: \"%s\", %d", szTextFormat, o);
}

TextClock::~TextClock()
{
	delete text_painter;

	delete [] szTextFormat;
}

int TextClock::StringEscapeCopy(LPSTR szout, LPCSTR szin)
{
	unsigned int in;
	unsigned int out;
	int ret = FALSE;

	for (in = 0, out = 0; in < strlen(szin); in++)
	{
		//_LSLogPrintf(LOG_DEBUG, "EscapeCopy", "in: %d, out: %d", in, out);
		if (szin[in] != '\\')
		{
			szout[out] = szin[in];
			out++;
		}
		else
		{
			if (szin[in+1] == 'n')
			{
				//szout[out++] = '\r';
				szout[out++] = '\n';
				//out+=1;
				ret++;
			}
			else
			{
				out++;
			}
			
			in++;
			
		}
	}
	szout[out] = '\0';
	return ret;
}

void TextClock::DrawClock(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	tm tm_time;
	char szTime[128];

	ConvertSystemTime(&tm_time, time);
	strftime(szTime, 128, szTextFormat, &tm_time);
#ifdef SPAMDEBUG
	_LSLogPrintf(LOG_DEBUG, szLogName, "time output: %s", szTime);
#endif
	//strcpy(szTime, "test");
	//szTime[strlen(szTime)] = '\0';

	text_painter->SetText(szTime);
	text_painter->Draw(hdc, hrgn);
};

void TextClock::ConvertSystemTime(tm* tm_time, const SYSTEMTIME time)
{
	tm_time->tm_sec = time.wSecond;
	tm_time->tm_min = time.wMinute;
	tm_time->tm_hour = time.wHour;

	tm_time->tm_mday = time.wDay;
	tm_time->tm_mon = time.wMonth - 1;
	tm_time->tm_year = time.wYear - 1900;

	tm_time->tm_wday = time.wDayOfWeek;

	tm_time->tm_yday = DayInYear(time);

	tm_time->tm_isdst = -1; // attempt to detmine it from the system.
}

bool TextClock::IsDaylightSaving()
{
	struct _timeb time;
	_ftime(&time);
	return (time.dstflag!=0) ? true : false;
}

bool TextClock::IsLeapYear(const int year)
{
	if (year % 4 == 0)
		if (year % 100 != 0)
			if (year % 400 == 0) 
				return true; 
	
	return false; 
}

int TextClock::DayInYear(const SYSTEMTIME time)
{
	int day = time.wDay;

	// not including this months length
	for (int i = 0; i < time.wMonth - 1; i++)
	{
		if (i % 2)
		{
			if (i == 2)
				day += (28 + IsLeapYear(time.wYear));
			else
				day += 30;
		}
		else
			day	+= 31;
	}
	return day;
}