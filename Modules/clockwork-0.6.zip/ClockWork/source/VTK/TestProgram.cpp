#include <conio.h>
#include <stdio.h>
#include <string.h>
//#include "SafeString.h"
//#include "BangManager.h"

void main()
{
	/*SafeString* test = new SafeString;
	test->assign("test");
	printf("1, %s, ok: %d ", test->c_str(), *test == "test");
	
	test->append("ad");

	printf("3, %s ", test->char_str());
	delete test;

	BangManager temp;
	temp.AddBang("Test", NULL);
	temp.RemoveBang("Test");*/

	getch();
}