#ifndef __COMMONDEFINES_H
#define __COMMONDEFINES_H

// extra debug info:
//#define DEBUG_EXTRA

// spamming debug info:
//#define DEBUG_SPAM

#endif