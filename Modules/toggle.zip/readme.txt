Little module available, not finished, but definitely working.
Still have to register the revid to LiteStep and shrink it a bit

What it does is adds three RC commands and Bangs that set the NumLock,
ScrollLock and CapsLock state

RC:
CapsOn True/False
NumlockOn True/False
ScrollOn True/False

Bangs:
!caps <on/off>
!numlock <on/off>
!scroll <on/off>




Rob Allshouse
http://webpages.csus.edu/~sac75061/
robert.a.allshouse@intel.com