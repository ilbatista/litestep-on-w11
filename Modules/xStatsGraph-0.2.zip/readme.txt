xStatsGraph by thegeek.

----Introduction----

Hi, this is the very first public release of a small graphing module I put together to replace rainmeter.
At the moment it is very basic, it only has one rendering mode ( filled graph ).
It uses perfmon counters to gather data, so you can graph pretty much anything;P
I will hopefully add more rendering modes later, and I am very open to suggestions/requests:)
Since this is also the very first public release please report any bugs.

----Capabilities----

I use the excellent xpaintclass by andymon, so the graphics for the "background layer" has full support for xpaintclass settings.
The graph itself is rendered ontop of this background, at the moment you can set color and alpha for the graph.
This is a basic example to illustrate a basic cpu graph:


*xStatsGraph test
testX 0
testY 0
testWidth 200
testHeight 22
testPaintingMode .image
testImage horizontalbar_2.png
testCounter "\Processor(_Total)\% Processor Time"
testMeterRefreshRate 200
testMeterX 0
testMeterY 0
testMeterHeight 18
testMeterWidth 200
testMeterAlpha 50
testMeterColor 555555
testMeterScale 100



Most of these settings is very basic xpaintclass stuff. If you do not understand any of these settings and they are not explained below, please consult the xpaintclass help.
The settings that are new / are not basic xpaintclass are these:

Counter "\Processor(_Total)\% Processor Time"
The Counter string is what you use to define the perfmon counter that is the source of the data, if you have trouble formatting this string correctly use the 
!xStatsGraphShowPerformancePicker bang to get a dialog that allows you to select among all counters. After you have selected the counter you want, click ok and the correct string will be copied to your clipboard.

MeterRefreshRate 200
This setting allows you to set the milliseconds between each update, lower bound is 50.

MeterScale 100
This allows you to set the (vertical) scale of the graph.



----Release History----

--0.1
First alpha.

--0.2
First public release



----Contact----

I am thegeek on efnet and freenode (irc).
You can also reach me by email to okrog@online.no

