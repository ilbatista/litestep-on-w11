#include <windows.h>
#include "wa3remote.h"
#include "../common/corehandle.h"
#include "../common/metatags.h"

static WA3Remote wac;
WAComponentClient *the = &wac;

// {E8C818AB-C017-43D9-A1AF-671296C637B2}
static const GUID guid = 
{ 0xE8C818AB, 0xC017, 0x43D9, { 0xA1, 0xAF, 0x67, 0x12, 0x96, 0xC6, 0x37, 0xB2 } };

WA3Remote::WA3Remote() : WAComponentClient("WA3 Remote")
{

}

void
WA3Remote::onCreate()
{
	// Create window
	HINSTANCE hInstance;
	WNDCLASSEX wc;

	hInstance = GetModuleHandle(NULL);

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = 0;
	wc.lpfnWndProc = WA3Remote::WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = NULL;
	wc.hCursor = NULL;
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = WA3REMOTE_WNDCLASS;
	wc.hIconSm = NULL;

	RegisterClassEx(&wc);
	hWnd = CreateWindowEx(WS_EX_TOOLWINDOW, WA3REMOTE_WNDCLASS, NULL, WS_POPUP, 0, 0, 0, 0, NULL, NULL, hInstance, NULL);

	// Allocate shared memory block
	hSharedMem = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, sizeof(WA3REMOTE_SHAREDMEM), WA3REMOTE_SHAREDMEMNAME);

	if(hSharedMem)
	{
		PWA3REMOTE_SHAREDMEM pSharedMem = (PWA3REMOTE_SHAREDMEM) MapViewOfFile(hSharedMem, FILE_MAP_WRITE, 0, 0, 0);
		memset(pSharedMem, 0, sizeof(WA3REMOTE_SHAREDMEM));
		UnmapViewOfFile(pSharedMem);
	}

	// Register for callbacks
	api->core_addCallback(0, this);
}

void
WA3Remote::onDestroy()
{
	// Unregister for callbacks
	api->core_delCallback(0, this);

	// Free shared memory block
	CloseHandle(hSharedMem);

	// Destroy window
	DestroyWindow(hWnd);
}

GUID
WA3Remote::getGUID()
{
	return guid;
}

int
WA3Remote::corecb_onTitleChange(const char *title)
{
	CoreHandle core;
	const char *pszCurrent = core.getCurrent();
	PWA3REMOTE_SHAREDMEM pSharedMem = (PWA3REMOTE_SHAREDMEM) MapViewOfFile(hSharedMem, FILE_MAP_WRITE, 0, 0, 0);

	api->metadb_getMetaData(pszCurrent, MT_ADDEDON, (char *) &pSharedMem->nAddedOn, sizeof(int), MDT_TIMESTAMP);
	api->metadb_getMetaData(pszCurrent, MT_ALBUM, pSharedMem->szAlbum, WA3REMOTE_MAX_ALBUM, MDT_STRINGZ);
	api->metadb_getMetaData(pszCurrent, MT_ARTIST, pSharedMem->szArtist, WA3REMOTE_MAX_ARTIST, MDT_STRINGZ);
	api->metadb_getMetaData(pszCurrent, MT_BITRATE, (char *) &pSharedMem->nBitRate, sizeof(int), MDT_INT);
	api->metadb_getMetaData(pszCurrent, MT_BITSPERSAMPLE, (char *) &pSharedMem->nBitsPerSample, sizeof(int), MDT_INT);
	api->metadb_getMetaData(pszCurrent, MT_COMMENT, pSharedMem->szComment, WA3REMOTE_MAX_COMMENT, MDT_STRINGZ);
	api->metadb_getMetaData(pszCurrent, MT_GENRE, pSharedMem->szGenre, WA3REMOTE_MAX_GENRE, MDT_STRINGZ);
	api->metadb_getMetaData(pszCurrent, MT_INFO, pSharedMem->szInfo, WA3REMOTE_MAX_INFO, MDT_STRINGZ);
	api->metadb_getMetaData(pszCurrent, MT_LASTPLAYED, (char *) &pSharedMem->nLastPlayed, sizeof(int), MDT_TIMESTAMP);
	api->metadb_getMetaData(pszCurrent, MT_LENGTH, (char *) &pSharedMem->nLength, sizeof(int), MDT_TIME);
	api->metadb_getMetaData(pszCurrent, MT_MODIFIED, (char *) &pSharedMem->nModified, sizeof(int), MDT_TIMESTAMP);
	api->metadb_getMetaData(pszCurrent, MT_NAME, pSharedMem->szName, WA3REMOTE_MAX_NAME, MDT_STRINGZ);
	api->metadb_getMetaData(pszCurrent, MT_NUMCHANNELS, (char *) &pSharedMem->nNumChannels, sizeof(int), MDT_INT);
	api->metadb_getMetaData(pszCurrent, MT_PLAYSTRING, pSharedMem->szPlayString, WA3REMOTE_MAX_PLAYSTRING, MDT_STRINGZ);
	api->metadb_getMetaData(pszCurrent, MT_SAMPLERATE, (char *) &pSharedMem->nSampleRate, sizeof(int), MDT_INT);
	api->metadb_getMetaData(pszCurrent, MT_SIZE, (char *) &pSharedMem->nSize, sizeof(int), MDT_INT);
	api->metadb_getMetaData(pszCurrent, MT_TITLE, pSharedMem->szTitle, WA3REMOTE_MAX_TITLE, MDT_STRINGZ);
	api->metadb_getMetaData(pszCurrent, MT_TRACK, pSharedMem->szTrack, WA3REMOTE_MAX_TRACK, MDT_STRINGZ);
	api->metadb_getMetaData(pszCurrent, MT_YEAR, pSharedMem->szYear, WA3REMOTE_MAX_YEAR, MDT_STRINGZ);

	UnmapViewOfFile(pSharedMem);
	return 0;
}

LRESULT
WA3Remote::OnGetLength(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	return (LRESULT) core.getLength();
}

LRESULT
WA3Remote::OnGetPan(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	return (LRESULT) core.getPan();
}

LRESULT
WA3Remote::OnGetPosition(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	return (LRESULT) core.getPosition();
}

LRESULT
WA3Remote::OnGetStatus(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	return (LRESULT) core.getStatus();
}

LRESULT
WA3Remote::OnGetVolume(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	return (LRESULT) core.getVolume();
}

LRESULT
WA3Remote::OnNext(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	core.next();
	return 0;
}

LRESULT
WA3Remote::OnPause(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	core.pause();
	return 0;
}

LRESULT
WA3Remote::OnPlay(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	core.play();
	return 0;
}

LRESULT
WA3Remote::OnPrevious(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	core.prev();
	return 0;
}

LRESULT
WA3Remote::OnSetPan(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	core.setPan((int) wParam);
	return 0;
}

LRESULT
WA3Remote::OnSetPosition(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	core.setPosition((int) wParam);
	return 0;
}

LRESULT
WA3Remote::OnSetVolume(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	core.setVolume((int) wParam);
	return 0;
}

LRESULT
WA3Remote::OnStop(WPARAM wParam, LPARAM lParam)
{
	CoreHandle core;
	core.stop();
	return 0;
}

LRESULT WINAPI
WA3Remote::WndProc(HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam)
{
	WA3Remote *remote = (WA3Remote *) the;

	switch(nMessage)
	{
	case WA3REMOTE_WM_GETLENGTH:
		return remote->OnGetLength(wParam, lParam);

	case WA3REMOTE_WM_GETPAN:
		return remote->OnGetPan(wParam, lParam);

	case WA3REMOTE_WM_GETPOSITION:
		return remote->OnGetPosition(wParam, lParam);

	case WA3REMOTE_WM_GETVOLUME:
		return remote->OnGetVolume(wParam, lParam);

	case WA3REMOTE_WM_NEXT:
		return remote->OnNext(wParam, lParam);

	case WA3REMOTE_WM_PAUSE:
		return remote->OnPause(wParam, lParam);

	case WA3REMOTE_WM_PLAY:
		return remote->OnPlay(wParam, lParam);

	case WA3REMOTE_WM_PREVIOUS:
		return remote->OnPrevious(wParam, lParam);

	case WA3REMOTE_WM_SETPAN:
		return remote->OnSetPan(wParam, lParam);

	case WA3REMOTE_WM_SETPOSITION:
		return remote->OnSetPosition(wParam, lParam);

	case WA3REMOTE_WM_SETVOLUME:
		return remote->OnSetVolume(wParam, lParam);

	case WA3REMOTE_WM_STOP:
		return remote->OnStop(wParam, lParam);
	}

	return DefWindowProc(hWnd, nMessage, wParam, lParam);
}
