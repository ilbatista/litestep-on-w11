===================================================
===================================================
=tasks.dll - it makes your coffee. Sorry no decaf!=
===================================================
===================================================
====== Written by: ================================
================== Chris Rempel (jugg) ============
===================================================
================== http://jugg.logicpd.com/ =======
================== jugg@dylern.com ================
===================================================
===================================================
====== Adapted from: ==============================
==================== [rdj]'s tasks.dll ============
==================== Remco de Jong ================
===================================================
================(?)= http://litestep.rdj.cg.nu/ ===
================(?)= rdj@telekabel.nl =============
===================================================
===================================================
= Version: 0.92 = Release Date: 01.06.05 ==========
========= 0.92b3 = Modded: 2003-01-05 =============
===================================================

-=ToC=-
I. Introduction
II. Installation
III. Information
 A} Commands
 B} Changes
 C} Notes
IV. Tips & Tricks
V. Disclaimer


=====================
== I. Introduction ==
=====================
===================================================
Welcome, and thank you for trying out this small
efficient task manager for Win32 shells. Tasks runs
under LiteStep and other shells that support the
LiteStep module standard such as PureLS. Tasks
displays by default, 32x32 tiles with 16x16 icons
representing the currently running applications.
Each tile has a popup system menu for the specific
application it represents, from which you can
control the application window.

Furthermore, Tasks is completely customizable,
supporting a wide range of functionality from a
static block of tiles, to a popup menu interface,
with hide-on-click and zOrder positioning options.
But that is only a small portion of the numerous
options to customize your Tasks tiles.


======================
== II. Installation ==
======================
===================================================

Extract "tasks.dll" to your shell directory
(c:\litestep\). Open up your step.rc (your shell
configuration file) and find the section where all
of your "LoadModule" lines are located. Now, add a
new line that looks like this:

LoadModule "c:\litestep\tasks.dll"

Of course, adjust the path as necessary. Save your
step.rc and issue the shell's Recycle command
(!Recycle).


======================
== III. Information ==
======================
===================================================

The following Commands section is broken up into
four parts. You have the "MAIN", "NORMAL",
"MINIMIZED", and "SELECTED" sections. Basically,
Tasks has three different "states" it can be in.

First you have your default "NORMAL" state where
the application is neither minimized nor active.

Secondly, there is the "MINIMIZED" state where the
application is minimized.

Finally, there is the "SELECTED" or "active" state
where the application is the one with the focus.

By default the second and third states are
disabled (minimized, selected), defaulting all
tiles to have the "normal" look. You can activate
the "minimized" and "selected" states by setting
the first command under those two sections shown
below.

The three "state" sections each have an identical
set of commands to the other. All Task display
settings default to the "NORMAL" state settings
unless overridden by the equivelant command from
the "MINIMIZED" or "SELECTED" state commands.

Besides the three different "state" sections, you
have a "main" section of commands whos values are
not effected by the current state of the
application, plus several action (!bang) commands
and filters.

===============
= A} Commands =
===============

The default value for each command is shown
following the command, just as you would set a new
value in the shell configuration file.

===================================================
=========== (Begin) MAIN Command Section ==========
===================================================

TasksX 0
  - Sets the horizontal (x coordinate) value to
    start placing Tasks tiles, relevant to the
    direction in which they are arranged.
  - accepts any negative or positive integer,
    or centered by adding an ending 'C' ie 70C.
	- value is relative to the "DockWindow"
  - defaults to: 0

TasksY 0
  - Sets the vertical (y coordinate) value to
    start placing Tasks tiles, relevant to the
    direction in which they are arranged.
  - accepts any negative or positive integer.
    or centered by adding an ending 'C' ie 70C.
	- value is relative to the "DockWindow"
  - defaults to: 0

TasksHeight 32
  - Sets the vertical size (height) value.
  - accepts any positive integer greater then 1.
  - defaults to: 32

TasksWidth 32
  - Sets the horizontal size (width) value.
  - accepts any positive integer greater then 1.
  - defaults to: 32

TasksSpacingX 0
  - Sets the horizontal seperation (spacing)
    between tiles.
  - accepts any positive or negative integer.
  - defaults to: 0

TasksSpacingY 0
  - Sets the vertical seperation (spacing)
    between tiles.
  - accepts any positive or negative integer.
  - defaults to: 0

TasksDirection "right"
  - Sets the directional postion new tiles are
    added relevant to the values given in
    [TasksX] and [TasksY].
  - accepts one of the following: "up", "down",
    "left", "right".
  - when set to "up" or "left". If you set [TasksY]
    or [TasksX] respectively to zero 0, the zero
    acts like a negative zero.
  - defaults to: "right"

TasksWrapDirection "down"
  - Sets the directional postion tiles are wrapped
    to relevant to the values given in [TasksX] and
    [TasksY] when the [TasksWrapCount] limit has
    been reached.
  - accepts one of the following:
    + Either "up" or "down" if [TasksDirection] is
      set to "left" or "right".
    + Either "left" or "right" if [TasksDirection]
      is set to "up", or "down".
  - when set to "up" or "left". If you set [TasksY]
    or [TasksX] respectively to zero 0, the zero
    acts like a negative zero.
  - defaults to: "down"

TasksWrapCount 0
  - Sets the maximum number of tiles that can be
    displayed in one direction, before wrapping.
  - accepts any positive integer or the following:
      Set to 0 to disable.
      Set to -1 to autowrap.
  - defaults to: 0

TasksMaxTiles 0
  - Sets the maximum number of tiles that can be
    displayed.
  - accepts any positive integer. Use 0 to disable.
    When disabled, the maximum is limited by your
    system memory.
  - defaults to: 0

TasksDockWindow "DesktopBackgroundClass"
  - Sets the window inside of which tiles will be
    displayed.
  - accepts a string in the format of:
    "ClassName;WindowName" -Notice the semicolon.
    Or just the "ClassName" by itself.
    To force no DockWindow set to ".none".
    See [TaskszOrder] for more information.
  - defaults to: "DesktopBackgroundClass"
    If a valid LiteStep desktop window does not
    exist, then it will default to no DockWindow,
    the same as setting ".none"

TasksDragDistance 4
  - Sets the distance a tile must move before it is
    registered as movement, rather then a mouse
    click.
  - accepts any positive integer.
  - defaults to: 4

TasksSetTimer 250
  - Sets the Update Timer refresh rate in
	  milliseconds. This is how often tasks checks to
		see if any windows have changed, and updates
		its display.
	- accepts any value greater then or equal to 250.
	- defaults to: 250

TasksIconSize 16
  - Sets the size of the displayed Icon on the tile
  - accepts any positive integer greater then 1.
  - defaults to: 16

TasksDisplay "all"
  - Sets what application "states" (min,sel,normal)
    to create Tiles for.
  - accepts any one or combination of:
    normal, minimized, selected, all
    all is equivelant to using the combination of
    the three previous ones.
  - defaults to: all

TaskszOrder "floating"
  - Sets whether the Task Tiles are always on top or
    floating.
  - accepts "floating" or "ontop".
  - NOTE: on bottom status is only obtained by
          loading a valid LiteStep Desktop module
          before tasks.dll, and leaving the Tasks
          command "TasksDockWindow" to its default
          setting.
  - defaults to: floating

TasksTransparency "fake"
  - Sets the transparency level of the Tasks Tiles
    when and where the Pink (FF00FF, RGB 255,0,255)
    color is found in the Tile.
  - accepts "fake", "real", "none".
  - defaults to: fake

TasksMButton1 "!none"
  - Sets the command to be executed when the left
    mouse button is clicked on a Tile.
  - accepts any !Bang command or Executable. Or the
    special Task command ".syspopup" which shows
    the system menu for the relevant application.
    Regardless of what this is set to, the left
    button always acts as a normal click on the
    tile as well.
  - defaults to: !none

TasksMButton2 ".syspopup"
  - Sets the command to be executed when the right
    mouse button is clicked on a Tile.
  - accepts any !Bang command or Executable. Or the
    special Task command ".syspopup" which shows
    the system menu for the relevant application.
  - defaults to: .syspopup

TasksMButton3 "!Popup"
  - Sets the command to be executed when the middle
    mouse button is clicked on a Tile.
  - accepts any !Bang command or Executable. Or the
    special Task command ".syspopup" which shows
    the system menu for the relevant application.
  - defaults to: !Popup

TasksEmptyCmd "!none"
  - Sets the command to be executed when the Task
    List is emptied.
  - accepts any !Bang command or Executable.
  - defaults to: !none

TasksAutoArrange
  - If set, Tasks tiles will be rearrange to close.
    any gaps made if a single tile is dragged away
    from the group. You do not need to set this if
    you do not drag Tiles around.
  - boolean value: true if set, otherwise false.

TasksHideMinAppBar
  - If set, Tasks will hide all minimized
    application bars from the viewable desktop area
  - boolean value: true if set, otherwise false.

TasksMoveAll
  - If set, when any tile is dragged and dropped on
    the desktop, all Tasks tiles will be moved and
    rearranged at that location.
  - boolean value: true if set, otherwise false.

TasksNoHints
  - If set, no popup hints containing the
    applications title will be displayed.
  - boolean value: true if set, otherwise false.

TasksNoIcons
  - If set, no icons will be displayed on the tiles
    although, custom "pix" (bitmaps) will be.
  - boolean value: true if set, otherwise false.

TasksNoMinimizeOnClick
  - If set, when clicking on the tile of the active
    application, the application will -not- be
    minimized. Otherwise it would be.
  - boolean value: true if set, otherwise false.

TasksNoMove
  - If set, all dragging movement of the tiles are
    disabled.
  - boolean value: true if set, otherwise false.

TasksSort
  - If set, the Task List is sorted based upon the a
    primary key of the App Class and a secondary key
    of the Window Title.
  - boolean value: true if set, otherwise false.

TasksStartHidden
  - If set, all Tasks tiles will be hidden on load/
    recyle of the shell.
  - boolean value: true if set, otherwise false.

TasksTitles
  - If set, turns on the display of application
    titles on the Tasks tiles for -non- minimized
    and -non- active applications.
  - boolean value: true if set, otherwise false.

TasksTitleMinimized
  - If set, turns on the display of application
    titles on the Tasks tiles for minimized
    applications only.
  - boolean value: true if set, otherwise false.

TasksTitleSelected
  - If set, turns on the display of application
    titles on the Tasks tiles for the active
    (selected) application only.
  - boolean value: true if set, otherwise false.
  
TasksUseWindowsSettings
  - If set, all display of the Tasks tiles gets
    handled by windows. This setting uses the
    system color schemes, fonts, and icons. No
    custom settings can be used from of the three
    states commands, and only some of the Main set.
    However if you use "TasksHighlightSelected"
    the system will paint the active task tile the
    foreground color.
  - boolean value: true if set, otherwise false.

TasksUseSystemHook
  - If set, tasks will receive its update
    notifications from the Shell it is running
    under (if the shell supports this) instead of
    using a Timer. (TasksSetTimer does nothing if
    this is set)
  - boolean value: true if set, otherwise false.


  =====!Bang Commands==============================
  =================================================
   !TasksGather
     - parameters: none
     - Issuing this command will re-position all
       tiles back to their original position.

   !TasksHide
     - parameters: none
     - Issuing this command will hide all tiles.

   !TasksMove
     - parameters: x,y
       'x' is any positive or negative integer
       representing the horizontal (x coordinate)
       value to position the tiles at.
       'y' is any positive or negative integer
       representing the vertical (y coordinate)
       value to position the tiles at.
     - Issuing this command will position the tiles
       at x,y values passed, or if no values were
       specified, it will position the tiles at
       the current mouse coordinates.

   !TasksShow
     - parameters: none
     - Issuing this command will show all tiles.

   !TasksSwitch
     - parameters: "next" or "prev"
     - Issuing this command will switch the active
       application to either the "next" or
       "previous" application in the Tasks list. If
       no parameters are specified, the command is
       ignored. This command only switches between
       applications that are represented by Task
       Tiles.

   !TasksToggle
     - parameters: none
     - Issuing this command toggles the visibility
       state of the tiles, by either hiding or
       showing them, opposite of their current
       visible state.

   !TasksDisplay
     - parameters: "normal" or "minimized" or
                   "selected" or "all" or any
                   combination first three options.
     - Issuing this command will change what type
       of Tiles Tasks.dll will display. See
       "TasksDisplay" command for more information.

   !TasksDockWindow
     - parameters: "ClassName;WindowName"
       'ClassName' is the Class of the Window you
                   want to dock the Task Tiles to.
       'WindowName' is the Caption of the Window
                    you want to dock to.
       or set to ".none" to not dock to any window.
     - Issuing this command will set or remove the
       Task Tiles DockWindow. If set to
       "DesktopBackgroundClass", while using a valid
       LiteStep Desktop window, the Task Tiles will
       have an "always on bottom" zOrder style.
       (This does not affect the TaskszOrder value
        and vise-versa)
       See "TasksDockWindow" for more information.

   !TaskszOrder
     - parameters: "ontop" or "floating"
     - Issuing this command set the Task Tiles to
       be ontop of other windows or not. This
       command only has affect within the respect
       of the TasksDockWindow value. Most users
       will want to set "TasksDockWindow" to
       ".none" in order to have the expected result
       while using this "!TaskszOrder". See the
       command "TaskszOrder" for more information.

   !TasksMinimize
    - parameters: none
    - Issuing this command will minimize all
      windows that Tasks.dll displays a Tile for.

   !TasksMaximize
    - parameters: none
    - Issuing this command will maximize all
      windows that Tasks.dll displays a Tile for.

   !TasksRestore
    - parameters: none
    - Issuing this command will restore all
      windows that Tasks.dll displays a Tile for.


  =====Task Filters================================
  == All "text" fields are case sensitive! ========
  == Multiple settings of each command in this ====
  ==      section is allowed and is limited by ====
  ==      available memory. =======================
  =================================================
   *TasksAdd
     - parameters: "text"
     - Adds a tile for any application who's class
       or title matches the string passed in the
       "text" field.

   *TasksClass
     - parameters: "text", "newtext"
     - Used to specify a substitute class name for
       an application. When a new application
       starts, the application window title and
       class are compared with "text" and if one
       matches, the text given by "newtext" is used
       for the application class instead of the
       actual class. Very useful for controlling
       the behavior of TasksSort.
     - Note: by changing the Class value here, the
       comparisons on other class matching reflects
       this.

   *TasksIcon
     - parameters: "text", "filename", n
     - It is used to specify a custom icon for any
       tile who's application's title or class
       matches the text specified in the "text"
       field. The "filename" is any icon resource
       contianing a valid icon in the position
       specified by the positive integer "n".

   *TasksIgnore
     - paramters: "text"
     - Removes all tiles for applications who's
       class or title matches the string passed in
       the "text" field.

   *TasksPix
     - parameters: "text", "filename"
     - It is used to specify a custom bitmap for
       any tile who's application's title or class
       matches the text specified in the "text"
       field. The "filename" is either the full
       path and filename to a valid bitmap, or the
       filename to a valid bitmap located in the
       shell's image/theme directory.

   *TasksWrapCmd
     - parameters: n, "command"
     - When TasksWrapping is enabled this allows
       specifying a command to execute each time
       the task list wraps. "n" specifies the on
       which wrap to execute the command beginning
       with zero.

===================================================
============ (End) MAIN Command Section ===========
===================================================


===================================================
========== (Begin) NORMAL Command Section =========
===================================================
TasksIconX -2
  - Sets the horizontal (x coordinate) value to
    place the Icon at inside of the tile.
  - accepts any positive integer, -1,-2, or -3. See
    the table at the end of the command section for
    explanation of negative values.
  - defaults to: -2

TasksIconY -2
  - Sets the vertical (y coordinate) value to
    place the Icon at inside of the tile.
  - accepts any positive integer, -1,-2, or -3. See
    the table at the end of the command section for
    explanation of negative values.
  - defaults to: -2

TasksPixX 1
  - Sets the horizontal (x coordinate) value to
    place the Custom bitmap at inside of the tile.
  - accepts any positive or negative integer.
  - defaults to: 1

TasksPixY 1
  - Sets the vertical (y coordinate) value to
    place the Custom bitmap at inside of the tile.
  - accepts any positive or negative integer.
  - defaults to: 1

TasksBgColor FF00FF
  - Sets the BackGround color of the tile.
  - accepts any color format the shell supports.
    Usually in the form of RBG Hex. Use FF00FF or
    RGB 255,0,255 (pink) for transparency.
  - defaults to: FF00FF
    
TasksDarkColor FF00FF
  - Sets the bottom/right border color of the tile.
  - accepts any color format the shell supports.
    Usually in the form of RBG Hex. Use FF00FF or
    RGB 255,0,255 (pink) for transparency.
  - defaults to: FF00FF

TasksLightColor FF00FF
  - Sets the top/left border color of the tile.
  - accepts any color format the shell supports.
    Usually in the form of RBG Hex. Use FF00FF or
    RGB 255,0,255 (pink) for transparency.
  - defaults to: FF00FF

TasksBgImage ".none"
  - Sets the BackGround image of the tile.
  - accepts any image format supported by the shell
    which is normally only BMP (bitmap).
    Use ".none" for no image/ transparency. Any
    portion of the image that contains the color
    FF00FF Hex will be displayed as transparent.
  - defaults to: ".none"


  =====Title Commands==============================
  == These are only available if "TasksTitles" ====
  == has been set. ================================
  =================================================
   TasksTitleHeight 12
     - Sets the vertical size (height) value of the
       Title box.
     - accepts any positive integer greater then 1.
     - defaults to: 12

   TasksTitleWidth 28
     - Sets the horizontal size (width) value of
       the Title box.
     - accepts any positive integer greater then 1.
     - defaults to: 28

   TasksTitleX -2
     - Sets the horizontal (x coordinate) value to
       place the Title box at inside of the tile.
     - accepts any positive integer, -1,-2, or -3.
       See the table at the end of the command
       section for explanation of negative values.
     - defaults to: -2

   TasksTitleY -3
     - Sets the vertical (y coordinate) value to
       place the Title box at inside of the tile.
     - accepts any positive integer, -1,-2, or -3.
       See the table at the end of the command
       section for explanation of negative values.
     - defaults to: -3

   TasksTitleIconX -2
     - Sets the horizontal (x coordinate) value to
       place the Icon at inside of the tile when
       titles are enabled, overriding [TasksIconX].
     - accepts any positive integer, -1,-2, or -3.
       See the table at the end of the command
       section for explanation of negative values.
     - defaults to: -2

   TasksTitleIconY -1
     - Sets the vertical (y coordinate) value to
       place the Icon at inside of the tile when
       titles are enabled, overriding [TasksIconY]
     - accepts any positive integer, -1,-2, or -3.
       See the table at the end of the command
       section for explanation of negative values.
     - defaults to: -1

   TasksTitlePixX 1
     - Sets the horizontal (x coordinate) value to
       place the Custom bitmap at inside of the
       tile when titles are enabled, overriding
       [TasksPixX].
     - accepts any positive or negative integer.
     - defaults to: 1

   TasksTitlePixY 1
     - Sets the vertical (y coordinate) value to
       place the Custom bitmap at inside of the
       tile when titles are enabled, overriding
       [TasksPixY].
     - accepts any positive or negative integer.
     - defaults to: 1

   TasksTitleFontSize 10
     - Sets the font size for the title text.
     - accepts any positive integer greater then 1.
     - defaults to: 10

   TasksTitleFont "Arial"
     - Sets the font name(face) for the title text.
     - accepts any valid windows font name.
     - defaults to: "Arial"

   TasksTitleFontColor C0C0C0
     - Sets the font color of the title text.
     - accepts any color format the shell supports.
       Usually in the form of RBG Hex. Use FF00FF
       or RGB 255,0,255 (pink) for transparency.
     - defaults to: C0C0C0  (a light grey)

   TasksTitleBgColor FF00FF
     - Sets the BackGround color of the title box.
     - accepts any color format the shell supports.
       Usually in the form of RBG Hex. Use FF00FF
       or RGB 255,0,255 (pink) for transparency.
     - defaults to: FF00FF

   TasksTitleDarkColor FF00FF
     - Sets the bottom/right border color of the
       title box.
     - accepts any color format the shell supports.
       Usually in the form of RBG Hex. Use FF00FF
       or RGB 255,0,255 (pink) for transparency.
     - defaults to: FF00FF

   TasksTitleLightColor FF00FF
     - Sets the top/left border color of the title
       box.
     - accepts any color format the shell supports.
       Usually in the form of RBG Hex. Use FF00FF
       or RGB 255,0,255 (pink) for transparency.
     - defaults to: FF00FF

   TasksTitleAlignCenter
     - If set, the title text is centered in
       respect to the titleX and titleWidth values.
     - boolean value: true if set, otherwise false.

   TasksTitleItalicize
     - If set, italicizes the title text.
     - boolean value: true if set, otherwise false.

   TasksTitleNoEllipsis
     - If set, turns off the display of Ellipsis
       "..." shown at the end of truncated titles.
     - boolean value: true if set, otherwise false.

   TasksTitleUnderline
     - If set, underlines the title text.
     - boolean value: true if set, otherwise false.
===================================================
=========== (End) NORMAL Command Section ==========
===================================================


For the next two sections, the descriptions of each
command is exactly the same as the previous section
commands, accept that these are for overiding the
settings for Minimized apps and the Active app. Be
sure to set the first command in each of the
following sections to enable the rest of the
commands in each section!  Each command in the next
two sections are followed by a command in
[brackets]. This means it defaults to that command
if not set, or if set, it overides that command
for any application that is either minimized or 
selected(active).


===================================================
========= (Begin) MINIMIZED Command Section =======
===================================================
TasksHighLightMinimized
  - If set, enables the rest of the commands in the
    MINIMIZED Command Section.
  - boolean value: true if set, otherwise false.

TasksMinIconX [TasksIconX]
TasksMinIconY [TasksIconY]

TasksMinPixX [TasksPixX]
TasksMinPixY [TasksPixY]

TasksMinBgColor [TasksBgColor]
TasksMinDarkColor [TasksDarkColor]
TasksMinLightColor [TasksLightColor]

TasksMinBgImage "" [TasksBgImage]
  - If using empty quotes "" it will default to
    [TasksBgImage]. Use ".none" to disable/make
    transparent.

  =====Title Commands==============================
  == These are only available if ==================
  == "TasksTitleMinimized" has been set as well. ==
  =================================================
   TasksTitleMinHeight [TasksTitleHeight]
   TasksTitleMinWidth [TasksTitleWidth]

   TasksTitleMinX [TasksTitleX]
   TasksTitleMinY [TasksTitleY]

   TasksTitleMinIconX [TasksTitleIconX]
   TasksTitleMinIconY [TasksTitleIconY]

   TasksTitleMinPixX [TasksTitlePixX]
   TasksTitleMinPixY [TasksTitlePixY]

   TasksTitleMinFontSize [TasksTitleFontSize]
   TasksTitleMinFont [TasksTitleFont]
   TasksTitleMinFontColor [TasksTitleFontColor]

   TasksTitleMinBgColor [TasksTitleBgColor]
   TasksTitleMinDarkColor [TasksTitleDarkColor]
   TasksTitleMinLightColor [TasksTitleLightColor]

   TasksTitleMinAlignCenter

   TasksTitleMinItalicize
   TasksTitleMinNoEllipsis
   TasksTitleMinUnderline
===================================================
========= (End) MINIMIZED Command Section =========
===================================================

===================================================
========= (Begin) SELECTED Command Section ========
===================================================
TasksHighLightSelected
  - If set, enables the rest of the commands in the
    SELECTED Command Section.
  - boolean value: true if set, otherwise false.

TasksSelIconX [TasksIconX]
TasksSelIconY [TasksIconY]

TasksSelPixX [TasksPixX]
TasksSelPixY [TasksPixY]

TasksSelBgColor [TasksBgColor]
TasksSelDarkColor [TasksDarkColor]
TasksSelLightColor [TasksLightColor]

TasksSelBgImage "" [TasksBgImage]
  - If using empty quotes "" it will default to
    [TasksBgImage]. Use ".none" to disable/make
    transparent.

  =====Title Commands==============================
  == These are only available if ==================
  == "TasksTitleSelected" has been set as well. ===
  =================================================
   TasksTitleSelHeight [TasksTitleHeight]
   TasksTitleSelWidth [TasksTitleWidth]

   TasksTitleSelX [TasksTitleX]
   TasksTitleSelY [TasksTitleY]

   TasksTitleSelIconX [TasksTitleIconX]
   TasksTitleSelIconY [TasksTitleIconY]

   TasksTitleSelPixX [TasksTitlePixX]
   TasksTitleSelPixY [TasksTitlePixY]

   TasksTitleSelFontSize [TasksTitleFontSize]
   TasksTitleSelFont [TasksTitleFont]
   TasksTitleSelFontColor [TasksTitleFontColor]

   TasksTitleSelBgColor [TasksTitleBgColor]
   TasksTitleSelDarkColor [TasksTitleDarkColor]
   TasksTitleSelLightColor [TasksTitleLightColor]

   TasksTitleSelAlignCenter

   TasksTitleSelItalicize
   TasksTitleSelNoEllipsis
   TasksTitleSelUnderline
===================================================
========== (End) SELECTED Command Section =========
===================================================


===Negative number Positioning code===
Imagine the following grid as the Task tile. So,
when you specify -2 for x and -2 for y, the item
will be centered in the tile. If you specify -3 for
x and -1 for y, then the item will be placed in the
top right corner of the tile.

|  x, y |  x, y |  x, y |

|-----------------------|
|       |       |       |
| -1,-1 | -2,-1 | -3,-1 |
|       |       |       |
|-----------------------|
|       |       |       |
| -1,-2 | -2,-2 | -3,-2 |
|       |       |       |
|-----------------------|
|       |       |       |
| -1,-3 | -2,-3 | -3,-3 |
|       |       |       |
|-----------------------|


If that still seems confusing, perhaps a little
description will help: (for x: -1 = left etc...)

x|left, center,  right
x| -1     -2      -3

y| top, middle, bottom
y| -1     -2      -3


===================================================
= B} Changes =
==============
  - 0.92b3 -
  ---------
    * drag and drop seems fixed (no big change, though, look in the code).
      It seems that fixing this also helps minimize-on-click when using the hook.
    * removed the contributors names from the about box (if 20 more people make changes to this module,
      it's going to be trashed ... the about box).
      Contributors are:
        jugg (main coder)
        MrJukes, Blkhawk, Vendicator, jesus_mjjg (modifiers, in order of appearance).

  - 0.92b2 -
  ---------
    * ... which didn't have the lsbox hook, it's now fixed.

  - 0.92b1 -
  ---------
    * Merged with MrJukes version with color tinting support.

  - 0.921 -
  ---------
    * Changed X,Y coordinate reader for support for centered coordinates.

  - 0.92 -
  --------
    + Added TasksUseSystemHook
    + Added TasksSort
    + Added TasksEmptyCmd
    + Added *TasksClass
    + Added *TasksWrapCmd
    + Added TasksTitleAlignCenter
            TasksTitleMinAlignCenter
            TasksTitleSelAlignCenter

    * Changed the Tasks List filter. Much better.

    ! Fixed !TasksSwitch from switching to a Shell
            window if it previously had focus.
    ! Fixed !TasksMove from not accepting
            negative values
    ! Fixed TasksMButtonX settings not accepting
            parameters to specified command.
    ! Fixed Active task title from disapearing
            when clicking on it, and the Display
            state was set to not show normal tiles.
    ! Fixed Active task filter so it works.


  - 0.90 -
  --------
    + Added TasksSetTimer

    ! Fixed memory corruption when no task tiles
            were displayed.
    ! Fixed resource leak when a Tile had both a
            custom bitmap and icon defined for it.
    ! Fixed code from loading a custom icon when
            a custom bitmap was already loaded for
            the same Tile.

  - 0.89 -
  --------
    + Added TasksDisplay
    + Added TaskszOrder
    + Added TasksTransparency
    + Added TasksTitleItalicize
            TasksTitleMinItalicize
            TasksTitleSelItalicize
    + Added TasksMButton1
    + Added !TasksDisplay
            !TasksDockWindow
            !TaskszOrder
            !TasksMinimize
            !TasksMaximize
            !TasksRestore

    - Removed TasksOnlySelected
    - Removed TasksOnlyMinimized
    - Removed TasksHideMinimized
    - Removed TasksNoTransparency
    - Removed TasksEnableTrueTransparency
    - Removed TasksHideOnClick
    - Removed !TasksOnBottom
              !TasksOnTop

    ! Fixed internal update timer.
    ! Fixed more tasklist problems.
    ! Fixed mouse-click interaction with Tiles.
    ! Fixed in its entirety the Focus bug.
    ! Fixed a bug in dragging code while using
            "TasksMoveAll".
    ! Fixed "!TasksSwitch" from crashing.
    ! Fixed memory corruption potential in all
            !bang commands, while using an old
            build of LiteStep.
    ! Fixed resource leak on quit/recycle.
    
    * Changed "TasksWrapCount" to accept "-1" to
              enable Auto Wrap at screen edge.
              Use "0" to disable all wrapping.
    * Changed Tile drag to support Auto Wrap.
    * Changed "!TasksMove" to support Auto Wrap.
    * Changed all movement code to keep Tiles on
              screen. Now Tiles will only go off
              screen if manually set to do so.

    ^ Other misc cleanup. There is a lot of changes
            in this build, and more underway. Please
            read the "NOTES" section for more info.

  - 0.84 -
  --------
    + Added minimal Drag&Drop support.
    + Added "TasksNoTransparency"
    + Added "TasksMButton2" and "TasksMButton3"
    + Added "TasksDockWindow"

    - Removed "TasksAlwaysOnTop".
    - Removed "TasksInjTray" (meaningless to you).
    - Removed "TasksTestTransFix"

    ! Fixed certain items from not showing in the
            TaskList. All should be well now.
    ! Fixed system popup menu from disapearing.
    ! Fixed Transparency issues for tiles and icons
    ! Fixed misc code and optomized settings.
    ! Fixed defualt settings/documentation issues.

    ^ Please read the corresponding news update on
             my website for important information
             as well as the Tips&Tricks section.

  - 0.83 -
  --------
    ! Fixed GDI resource leak in Paint handler.
    ! Fixed crash bug when using TasksAutoArrange.

    ^ For devs, I changed several project settings,
      but mainly just link/include paths.
    ^ To help fix some transparency issues I added
      a command "TasksTestTransFix". Use it and let
      me know if you still get transparency issues.

  - 0.82 -
  --------
    + Added true transparency. Use the boolean
            TasksEnableTrueTransparency to enable.

    ! Fixed TasksHideMinAppBar... again!
            Third time is a charm, hopefully.
    ! Fixed Tooltips not updating.
    ! Fixed several movement/ update problems.
    ! Fixed multiple flicker/refresh issues.

    ^ And just some general clean up work.

  - 0.81 -
  --------
    + Added "TasksOnlySelected" boolean.

    - Removed obsolete Tooltip code.

    * Changed code dealing with misc focus issues.

    ! Fixed misc Painting issues.
    ! Fixed problems with "TasksUseWindowsSettings"
    ! Fixed incorrect cursor after a recycle.
    ! Fixed a problem where I forgot to uncomment
            code in the last release, that fixes
            problems with minimized application
            bars.
    ! Fixed r-click popup menu from disapearing
            randomly when the application itself
            was minimized.
    ! Fixed task list, so now apps using
            "WS_EX_APPWINDOW" will show up in the
            task list, if they are Visible and are
            a top level window.

  - 0.80 -
  --------
  
    + Added filter "*TasksAdd"
    + Added !TasksMove
    + Added TasksHideOnClick
    + Added TasksMaxTiles
    + Added TasksUseWindowsSettings
    + Added TasksHideMinimized
    + Added a whole lot of new commands for the
            Normal/Min/Sel state settings.
            Read the command section to see them.
    + Added !TasksSwitch
    + Added negative zero support for TasksX/Y when
            using "up" or "left" for a direction.
    + Added code to keep tiles in the visible
            window when dragging them around.

    - Removed double internal task list, decreasing
              memory usage significantly.

    * Changed all !bang commands so they start with
              !Tasksxxxx.
    * Changed !TasksBottom to !TasksOnBottom and
              !TasksTop to !TasksOnTop
    * Changed all memory management to all dynamic
              allocation, instead of static.
              Making a much smaller memory usage.
    * Changed !TasksGather so now it resets tile
              positions back to their default setup

    ! Fixed ScreenSaver from showing in task list.
    ! Fixed MDI bugs
    ! Fixed Focus bug
    ! Fixed misc task list issues
    ! Fixed case sensitivity in commands
    ! Fixed minappbars from not being hidden.
    ! Fixed TasksOnlyMinimized from showing a tile
            even after the application wasn't min.
    ! Fixed system popup menus from refreshing.
    ! Fixed tiles from being destroyed from alt+f4
    ! Fixed movement bugs.
    ! Fixed serveral GDI resource leaks. thanks dde
    
    And a lot more... but I forget :/


  - old -
  -------
   Will move the old version changes over when I
   have the time.

===================================================
= C} Notes =
============

Not much.  Just enjoy :)


=====================
= IV. Tips & Tricks =
=====================
===================================================
Use only the following commands for a quick and
easy setup to get a Task List popup menu.

TasksWidth 150
TasksHeight 20
TasksUseWindowsSettings
TasksDirection "down"
TasksNoMove
TasksMButton1 "!TasksHide"
TasksStartHidden
; Only include the following two lines if you want
; the menu to appear on top of all other windows.
TasksDockWindow ".none"
TaskszOrder "ontop"

Then using a desktop module, like jDesk or the
DarkStep desktop.dll, or the LiteStep Desktop2.dll,
bind the following command to the mouse down action:

!TasksHide

And to the mouse up action bind the following:

!TasksMove !TasksShow

Now, whenever you click on the Desktop up will pop
a fast clean and convenient menu containing all of
the running applications.
---------------------------------------------------

If you are using the "TasksUseWindowsSettings"
boolean, you can still use the boolean
"TasksHighlightSelected" and the active task tile
will be automatically updated with your default
windows "foreground" color.
---------------------------------------------------

Using the "TasksDockWindow" feature:

Whatever window you want Tasks to dock into -MUST-
be loaded before tasks.dll is loaded!

Docking the Task tiles into a shortcut is slighty
tricky right now.  The following should be a
general guideline in getting it to work.

...
LoadModule shortcut.dll
LoadModule tasks.dll
...

; the shortcut you want to have tasks put into MUST
; be the FIRST one listed!!
; the shortcut MUST also be set to be ON TOP!!
*shortcut "TaskTray" .....
*shortcut "all other shortcuts listed now" ....

TasksDockWindow "ShortcutClass;LSShortCut"
...
---------------------------------------------------

To make Tasks to be "always ontop" use this:

TasksDockWindow ".none"
TaskszOrder "ontop"
---------------------------------------------------

Will add in more tips & tricks when I have time.
---------------------------------------------------

=Credits/Thanks:=
=================
-Derek Ney for providing the TasksSort code.
-Floach for no real reason, but no one else claimed
  ownership of the Shell System hook, so thanks!
-[rdj] for providing the original tasks.dll source
  and for a great concept to work off of!
-The great coders who've worked with me on this.
  limpid, killarny, maduin, nimue, fahim, others.
-Re5ources popup source code.
-dde for some GDI code, fixing resource leaks.
-Gustav Munkby for true transparency code.
-Those who email with suggestions/bug reports/etc.

=================
= V. Disclaimer =
=================
===================================================

Copyright (C) 1999, Chris Rempel

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT  WARRANTY
OF ANY KIND, EXPRESS OR  IMPLIED, INCLUDING BUT NOT
LIMITED  TO  THE   WARRANTIES  OF  MERCHANTABILITY,
FITNESS  FOR   A   PARTICULAR   PURPOSE   AND  NON-
INFRINGEMENT.  IN  NO  EVENT  SHALL THE  AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,  DAMAGES
OR  OTHER  LIABILITY,   WHETHER  IN  AN  ACTION  OF
CONTRACT,  TORT OR OTHERWISE,  ARISING FROM, OUT OF
OR IN CONNECTION  WITH  THE  SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
