/*setup includes*/
#include <windows.h>
#include <commctrl.h> // Included for ToolTips. Is there another way to do ToolTips without this dependency?
#include "lsapi.h"
#include "tasks.h"

/*setup constants*/
const char szAppName[] = "Tasks";

const char aboutStr[] = "Tasks 0.92a (jugg)";


/*setup variables*/
ClassList* classTag;
IconList* iconTag;
AddList* addTag;
IgnoreList* ignoreTag;
PixList* pixTag;
WrapCmdList* wrapCmd;
TaskType* tasks;
TasksSettings ts;

BOOL taskWrap, bgImgNone, minBgImgNone, selBgImgNone;
HCURSOR normalCursor, movingCursor;
HINSTANCE dll;
HWND parent, mainWin, hints, curTask, lockCurTask, oldCurTask;
int numClass, numIcon, numAdd, numIgnore, numPix, numTasks, numWrapCmd;
int screenHeight, screenWidth, dockHeight, dockWidth;
int bkUpX, bkUpY, bkDisp;
int captureTask, capMClick;
RECT rAllTasks;
POINT oldCursorPos;

/*declare all the functions*/
BOOL GetTasksAdd( char * );
BOOL GetTasksIgnore( char * );
BOOL IsAppWindow( HWND, BOOL );
BOOL IsValidWindow( HWND );
BOOL CALLBACK EnumWindowsProc( HWND, LPARAM );
BOOL StripWS( char * );
HICON GetIconFromWindow( HWND, BOOL );
LRESULT CALLBACK WndProc( HWND, UINT, WPARAM, LPARAM );
int InWinList( HWND );
int GetTaskByWnd( HWND );
int GetTaskByAppWnd( HWND );
int GetUnMovedNrTasks( int );
void CreateHints( HWND, char * );
void CreateTask( int, HWND );
void DeleteTask( int );
void FreeList( void );
void GetNewTaskPos( int );
void GetTasksClass( int );
void GetTasksIcon( int );
void GetTasksPix( int );
void HideMinAppBar( HWND );
void PackList( void );
void PaintTask( HDC, int );
void ReadTasksIcon( void );
void ReadTasksAdd( void );
void ReadTasksClass( void );
void ReadTasksIgnore( void );
void ReadTasksPix( void );
void ReadTasksWrapCmd( void );
void ReArrangeTasks( int, BOOL );
void RemoveHints( HWND );
void TaskPosition( int, int );
void UpdateTasks( void );
void UpdateHints( HWND, char * );
/*The rest are !bang commands*/
void TasksGather( HWND, LPCSTR );
void TasksHide( HWND, LPCSTR );
void TasksMove( HWND, LPCSTR );
void TasksShow( HWND, LPCSTR );
void TasksSwitch( HWND, LPCSTR );
void TasksToggle( HWND, LPCSTR );
void TasksDisplay( HWND, LPCSTR );
void TasksDockWindow( HWND, LPCSTR );
void TaskszOrder( HWND, LPCSTR );
void TasksMinimize( HWND, LPCSTR );
void TasksMaximize( HWND, LPCSTR );
void TasksRestore( HWND, LPCSTR );
void TasksBoxHook( HWND, LPCSTR );

/*and here are all the functions*/
TasksSettings ReadSettings()
{
	TasksSettings settings;
	char tmp[MAXLEN];
	char * ptr1=NULL, * ptr2=NULL;

	*tmp = '\0';
	GetRCString("TasksDirection", tmp, "right", 16);
			settings.Direction = 2;  /*only needed if user enters an invalid parameter*/
		if (_strcmpi(tmp, "up") == 0)
			settings.Direction = 1;
		else if (_strcmpi(tmp, "right") == 0)
			settings.Direction = 2;
		else if (_strcmpi(tmp, "down") == 0)
			settings.Direction = 3;
		else if (_strcmpi(tmp, "left") == 0)
			settings.Direction = 4;

	*tmp = '\0';
	GetRCString("TasksDisplay", tmp, "all", 256);
		settings.Display = 0x00;
		if (tmp && strlen(tmp)){
			_strlwr(tmp); // convert to lower case, since there is no 'strstr' case insensitive routine.
			if (strstr(tmp, "all"))
				settings.Display = 0x0F; // 1111 in binary... going to perform bitwise operations on it.
			else{ // no real reason to do this, but just that much less processing to do on startup.
				if (strstr(tmp, "normal"))
					settings.Display |= 0x01;
				if (strstr(tmp, "minimized"))
					settings.Display |= 0x02;
				if (strstr(tmp, "selected"))
					settings.Display |= 0x04;
			}
		}
		if (settings.Display == 0x00) settings.Display = 0x0F;  // if they put in something bogus, lets just default to 'all'
		bkDisp = settings.Display;

	*tmp = '\0';
	GetRCString("TasksTransparency", tmp, "fake", 16);
			settings.Transparency = 1;  /*only needed if user enters an invalid parameter*/
		if (_strcmpi(tmp, "none") == 0)
			settings.Transparency = 0;
		else if (_strcmpi(tmp, "fake") == 0)
			settings.Transparency = 1;
		else if (_strcmpi(tmp, "real") == 0)
			settings.Transparency = 2;

	*tmp = '\0';
	GetRCString("TaskszOrder", tmp, "floating", 16);
			settings.zOrder = 1;  /*only needed if user enters an invalid parameter*/
		if (_strcmpi(tmp, "floating") == 0)
			settings.zOrder = 1;
		else if (_strcmpi(tmp, "ontop") == 0)
			settings.zOrder = 2;

	settings.DragDistance = GetRCInt("TasksDragDistance", 4);
		if (settings.DragDistance < 0) settings.DragDistance = 4;
	settings.MaxTiles = GetRCInt("TasksMaxTiles", 0);
		if (settings.MaxTiles < 0) settings.MaxTiles = 0;
	settings.SetTimer = GetRCInt("TasksSetTimer", 250);
		if (settings.SetTimer < 250) settings.SetTimer = 250;
	settings.SpacingX = GetRCInt("TasksSpacingX", 0);
	settings.SpacingY = GetRCInt("TasksSpacingY", 0);
	settings.WrapCount = GetRCInt("TasksWrapCount", 0);
		taskWrap = settings.WrapCount > 0;

	*tmp = '\0';
	GetRCString("TasksWrapDirection", tmp, "down", 10); // the largest size is 5, but in case of typo's or something...
			settings.WrapDirection = 3;  /*only needed if user enters an invalid parameter*/
		if (_strcmpi(tmp, "up") == 0)
			settings.WrapDirection = 1;
		else if (_strcmpi(tmp, "right") == 0)
			settings.WrapDirection = 2;
		else if (_strcmpi(tmp, "down") == 0)
			settings.WrapDirection = 3;
		else if (_strcmpi(tmp, "left") == 0)
			settings.WrapDirection = 4;

	settings.Height = GetRCInt("TasksHeight", 32);
		if (settings.Height < 2) settings.Height = 32;
	settings.Width = GetRCInt("TasksWidth", 32);
		if (settings.Width < 2) settings.Width = 32;
	settings.X = GetRCInt("TasksX", 0);
		bkUpX = settings.X;
	settings.Y = GetRCInt("TasksY", 0);
		bkUpY = settings.Y;

	settings.IconSize = GetRCInt("TasksIconSize", 16);
		if (settings.IconSize < 2) settings.IconSize = 16;

	settings.IconX = GetRCInt("TasksIconX", -2);
		if (settings.IconX < 0)
		{
			if (settings.IconX == -1)
				settings.IconX = 1;
			else if (settings.IconX == -3)
				settings.IconX = settings.Width - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.IconX = settings.Width/2 - settings.IconSize/2;
		}
	settings.MinIconX = GetRCInt("TasksMinIconX", settings.IconX);
		if (settings.MinIconX < 0)
		{
			if (settings.MinIconX == -1)
				settings.MinIconX = 1;
			else if (settings.MinIconX == -3)
				settings.MinIconX = settings.Width - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.MinIconX = settings.Width/2 - settings.IconSize/2;
		}
	settings.SelIconX = GetRCInt("TasksSelIconX", settings.IconX);
		if (settings.SelIconX < 0)
		{
			if (settings.SelIconX == -1)
				settings.SelIconX = 1;
			else if (settings.SelIconX == -3)
				settings.SelIconX = settings.Width - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.SelIconX = settings.Width/2 - settings.IconSize/2;
		}

	settings.IconY = GetRCInt("TasksIconY", -2);
		if (settings.IconY < 0)
		{
			if (settings.IconY == -1)
				settings.IconY = 1;
			else if (settings.IconY == -3)
				settings.IconY = settings.Height - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.IconY = settings.Height/2 - settings.IconSize/2;
		}
	settings.MinIconY = GetRCInt("TasksMinIconY", settings.IconY);
		if (settings.MinIconY < 0)
		{
			if (settings.MinIconY == -1)
				settings.MinIconY = 1;
			else if (settings.MinIconY == -3)
				settings.MinIconY = settings.Height - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.MinIconY = settings.Height/2 - settings.IconSize/2; //Center the Icon by default for any other negative value.
		}
	settings.SelIconY = GetRCInt("TasksSelIconY", settings.IconY);
		if (settings.SelIconY < 0)
		{
			if (settings.SelIconY == -1)
				settings.SelIconY = 1;
			else if (settings.SelIconY == -3)
				settings.SelIconY = settings.Height - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.SelIconY = settings.Height/2 - settings.IconSize/2; //Center the Icon by default for any other negative value.
		}

	settings.PixX = GetRCInt("TasksPixX", 1);
	settings.MinPixX = GetRCInt("TasksMinPixX", settings.PixX);
	settings.SelPixX = GetRCInt("TasksSelPixX", settings.PixX);

	settings.PixY = GetRCInt("TasksPixY", 1);
	settings.MinPixY = GetRCInt("TasksMinPixY", settings.PixY);
	settings.SelPixY = GetRCInt("TasksSelPixY", settings.PixY);

	*tmp = '\0';
	GetRCString("TasksDockWindow", tmp, "DesktopBackgroundClass", MAXLEN);
	if (StripWS(tmp)){
		if (_strcmpi(tmp, ".none") == 0)
			settings.DockWindow = NULL;
		else{
			ptr1 = strtok(tmp, ";");
			ptr2 = strtok(NULL, ";");
			StripWS(ptr1);
			StripWS(ptr2);
			settings.DockWindow = (ptr1 && strlen(ptr1)) ? FindWindow(ptr1, ptr2):NULL;
			ptr1=ptr2=NULL;
			if (settings.DockWindow != NULL && !IsWindow(settings.DockWindow))
				settings.DockWindow = NULL;
		}
	}else
		settings.DockWindow = NULL;

	settings.AutoArrange = GetRCBool("TasksAutoArrange", TRUE);
	settings.HideMinAppBar = GetRCBool("TasksHideMinAppBar", TRUE);
	settings.MoveAll = GetRCBool("TasksMoveAll", TRUE);
	settings.NoMinimizeOnClick = GetRCBool("TasksNoMinimizeOnClick", TRUE);
	settings.NoMove = GetRCBool("TasksNoMove", TRUE);
	settings.Sort = GetRCBool("TasksSort", TRUE);
	settings.StartHidden = GetRCBool("TasksStartHidden", TRUE);
	settings.UseSystemHook = GetRCBool("TasksUseSystemHook", TRUE);

	settings.NoHints = GetRCBool("TasksNoHints", TRUE);
	settings.NoIcons = GetRCBool("TasksNoIcons", TRUE);
	settings.HighLightMinimized = GetRCBool("TasksHighLightMinimized", TRUE);
	settings.HighLightSelected = GetRCBool("TasksHighLightSelected", TRUE);
	settings.UseWindowsSettings = GetRCBool("TasksUseWindowsSettings", TRUE);

	settings.BgColor = GetRCColor("TasksBgColor", 0xFF00FF);
	settings.MinBgColor = GetRCColor("TasksMinBgColor", settings.BgColor);
	settings.SelBgColor = GetRCColor("TasksSelBgColor", settings.BgColor);

	settings.DarkColor = GetRCColor("TasksDarkColor", 0xFF00FF);
	settings.MinDarkColor = GetRCColor("TasksMinDarkColor", settings.DarkColor);
	settings.SelDarkColor = GetRCColor("TasksSelDarkColor", settings.DarkColor);

	settings.LightColor = GetRCColor("TasksLightColor", 0xFF00FF);
	settings.MinLightColor = GetRCColor("TasksMinLightColor", settings.LightColor);
	settings.SelLightColor = GetRCColor("TasksSelLightColor", settings.LightColor);

	*tmp = '\0';
	GetRCString("TasksBgImage", tmp, ".none", MAXLEN);
			bgImgNone = TRUE;
		if (_strcmpi(".none", tmp))
		{
			settings.BgImage = LoadLSImage(tmp, NULL);
			bgImgNone = FALSE;
		}
		else
			settings.BgImage = NULL;

	*tmp = '\0';
	GetRCString("TasksMinBgImage", tmp, "", MAXLEN); /*By using "" as the default, it uses the TasksBackImage.*/
			minBgImgNone = FALSE;
		if (_strcmpi(".none", tmp))
			settings.MinBgImage = LoadLSImage(tmp, NULL);
		else
		{
			settings.MinBgImage = NULL;
			minBgImgNone = TRUE;
		}

	*tmp = '\0';
	GetRCString("TasksSelBgImage", tmp, "", MAXLEN); /*By using "" as the default, it uses the TasksBackImage.*/
			selBgImgNone = FALSE;
		if (_strcmpi(".none", tmp))
			settings.SelBgImage = LoadLSImage(tmp, NULL);
		else
		{
			settings.SelBgImage = NULL;
			selBgImgNone = TRUE;
		}
	settings.TitleHeight = GetRCInt("TasksTitleHeight", 12); /*The Title settings here align it centered along the bottom of a 32x32 tile.*/
		if (settings.TitleHeight < 2) settings.TitleHeight = 12;
	settings.TitleMinHeight = GetRCInt("TasksTitleMinHeight", settings.TitleHeight); /*The Title settings here align it centered along the bottom of a 32x32 tile.*/
		if (settings.TitleMinHeight < 2) settings.TitleMinHeight = settings.TitleHeight;
	settings.TitleSelHeight = GetRCInt("TasksTitleSelHeight", settings.TitleHeight); /*The Title settings here align it centered along the bottom of a 32x32 tile.*/
		if (settings.TitleSelHeight < 2) settings.TitleSelHeight = settings.TitleHeight;

	settings.TitleWidth = GetRCInt("TasksTitleWidth", 28);
		if (settings.TitleWidth < 2) settings.TitleWidth = 28;
	settings.TitleMinWidth = GetRCInt("TasksTitleMinWidth", settings.TitleWidth);
		if (settings.TitleMinWidth < 2) settings.TitleMinWidth = settings.TitleWidth;
	settings.TitleSelWidth = GetRCInt("TasksTitleSelWidth", settings.TitleWidth);
		if (settings.TitleSelWidth < 2) settings.TitleSelWidth = settings.TitleWidth;

	settings.TitleX = GetRCInt("TasksTitleX", -2);
		if (settings.TitleX < 0)
		{
			if (settings.TitleX == -1)
				settings.TitleX = 1;
			else if (settings.TitleX == -3)
				settings.TitleX = settings.Width - settings.TitleWidth - 1;
			else /*Center the Title for '-2' and by default for any other negative value.*/
				settings.TitleX = settings.Width/2 - settings.TitleWidth/2;
		}
	settings.TitleMinX = GetRCInt("TasksTitleMinX", settings.TitleX);
		if (settings.TitleMinX < 0)
		{
			if (settings.TitleMinX == -1)
				settings.TitleMinX = 1;
			else if (settings.TitleMinX == -3)
				settings.TitleMinX = settings.Width - settings.TitleMinWidth - 1;
			else /*Center the Title for '-2' and by default for any other negative value.*/
				settings.TitleMinX = settings.Width/2 - settings.TitleMinWidth/2;
		}
	settings.TitleSelX = GetRCInt("TasksTitleSelX", settings.TitleX);
		if (settings.TitleSelX < 0)
		{
			if (settings.TitleSelX == -1)
				settings.TitleSelX = 1;
			else if (settings.TitleSelX == -3)
				settings.TitleSelX = settings.Width - settings.TitleSelWidth - 1;
			else /*Center the Title for '-2' and by default for any other negative value.*/
				settings.TitleSelX = settings.Width/2 - settings.TitleSelWidth/2;
		}

	settings.TitleY = GetRCInt("TasksTitleY", -3);
		if (settings.TitleY < 0)
		{
			if (settings.TitleY == -1)
				settings.TitleY = 1;
			else if (settings.TitleY == -3)
				settings.TitleY = settings.Height - settings.TitleHeight - 1;
			else /*Center the Title for '-2' and by default for any other negative value.*/
				settings.TitleY = settings.Height/2 - settings.TitleHeight/2;
		}
	settings.TitleMinY = GetRCInt("TasksTitleMinY", settings.TitleY);
		if (settings.TitleMinY < 0)
		{
			if (settings.TitleMinY == -1)
				settings.TitleMinY = 1;
			else if (settings.TitleMinY == -3)
				settings.TitleMinY = settings.Height - settings.TitleMinHeight - 1;
			else /*Center the Title for '-2' and by default for any other negative value.*/
				settings.TitleMinY = settings.Height/2 - settings.TitleMinHeight/2;
		}
	settings.TitleSelY = GetRCInt("TasksTitleSelY", settings.TitleY);
		if (settings.TitleSelY < 0)
		{
			if (settings.TitleSelY == -1)
				settings.TitleSelY = 1;
			else if (settings.TitleSelY == -3)
				settings.TitleSelY = settings.Height - settings.TitleSelHeight - 1;
			else /*Center the Title for '-2' and by default for any other negative value.*/
				settings.TitleSelY = settings.Height/2 - settings.TitleSelHeight/2;
		}

	settings.TitleIconX = GetRCInt("TasksTitleIconX", -2);
		if (settings.TitleIconX < 0)
		{
			if (settings.TitleIconX == -1)
				settings.TitleIconX = 1;
			else if (settings.TitleIconX == -3)
				settings.TitleIconX = settings.Width - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.TitleIconX = settings.Width/2 - settings.IconSize/2;
		}
	settings.TitleMinIconX = GetRCInt("TasksTitleMinIconX", settings.TitleIconX);
		if (settings.TitleMinIconX < 0)
		{
			if (settings.TitleMinIconX == -1)
				settings.TitleMinIconX = 1;
			else if (settings.TitleMinIconX == -3)
				settings.TitleMinIconX = settings.Width - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.TitleMinIconX = settings.Width/2 - settings.IconSize/2;
		}
	settings.TitleSelIconX = GetRCInt("TasksTitleSelIconX", settings.TitleIconX);
		if (settings.TitleSelIconX < 0)
		{
			if (settings.TitleSelIconX == -1)
				settings.TitleSelIconX = 1;
			else if (settings.TitleSelIconX == -3)
				settings.TitleSelIconX = settings.Width - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.TitleSelIconX = settings.Width/2 - settings.IconSize/2;
		}

	settings.TitleIconY = GetRCInt("TasksTitleIconY", -1);
		if (settings.TitleIconY < 0)
		{
			if (settings.TitleIconY == -1)
				settings.TitleIconY = 1;
			else if (settings.TitleIconY == -3)
				settings.TitleIconY = settings.Height - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.TitleIconY = settings.Height/2 - settings.IconSize/2;
		}
	settings.TitleMinIconY = GetRCInt("TasksTitleMinIconY", settings.TitleIconY);
		if (settings.TitleMinIconY < 0)
		{
			if (settings.TitleMinIconY == -1)
				settings.TitleMinIconY = 1;
			else if (settings.TitleMinIconY == -3)
				settings.TitleMinIconY = settings.Height - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.TitleMinIconY = settings.Height/2 - settings.IconSize/2; //Center the Icon by default for any other negative value.
		}
	settings.TitleSelIconY = GetRCInt("TasksTitleSelIconY", settings.TitleIconY);
		if (settings.TitleSelIconY < 0)
		{
			if (settings.TitleSelIconY == -1)
				settings.TitleSelIconY = 1;
			else if (settings.TitleSelIconY == -3)
				settings.TitleSelIconY = settings.Height - settings.IconSize - 1;
			else /*Center the Icon for '-2' and by default for any other negative value.*/
				settings.TitleSelIconY = settings.Height/2 - settings.IconSize/2; //Center the Icon by default for any other negative value.
		}

	settings.TitlePixX = GetRCInt("TasksTitlePixX", 1);
	settings.TitleMinPixX = GetRCInt("TasksTitleMinPixX", settings.TitlePixX);
	settings.TitleSelPixX = GetRCInt("TasksTitleSelPixX", settings.TitlePixX);

	settings.TitlePixY = GetRCInt("TasksTitlePixY", 1);
	settings.TitleMinPixY = GetRCInt("TasksTitleMinPixY", settings.TitlePixY);
	settings.TitleSelPixY = GetRCInt("TasksTitleSelPixY", settings.TitlePixY);

	settings.TitleFontSize = GetRCInt("TasksTitleFontSize", 10);
		if (settings.TitleFontSize < 2) settings.TitleFontSize = 10;
	settings.TitleMinFontSize = GetRCInt("TasksTitleMinFontSize", settings.TitleFontSize);
		if (settings.TitleMinFontSize < 2) settings.TitleMinFontSize = settings.TitleFontSize;
	settings.TitleSelFontSize = GetRCInt("TasksTitleSelFontSize", settings.TitleFontSize);
		if (settings.TitleSelFontSize < 2) settings.TitleSelFontSize = settings.TitleFontSize;

	settings.Titles = GetRCBool("TasksTitles", TRUE);
	settings.TitleMinimized = GetRCBool("TasksTitleMinimized", TRUE);
	settings.TitleSelected = GetRCBool("TasksTitleSelected", TRUE);

	settings.TitleItalicize = GetRCBool("TasksTitleItalicize", TRUE);
	settings.TitleMinItalicize = GetRCBool("TasksTitleMinItalicize", TRUE);
	settings.TitleSelItalicize = GetRCBool("TasksTitleSelItalicize", TRUE);

	settings.TitleNoEllipsis = GetRCBool("TasksTitleNoEllipsis", TRUE);
	settings.TitleMinNoEllipsis = GetRCBool("TasksTitleMinNoEllipsis", TRUE);
	settings.TitleSelNoEllipsis = GetRCBool("TasksTitleSelNoEllipsis", TRUE);

	settings.TitleUnderline = GetRCBool("TasksTitleUnderline", TRUE);
	settings.TitleMinUnderline = GetRCBool("TasksTitleMinUnderline", TRUE);
	settings.TitleSelUnderline = GetRCBool("TasksTitleSelUnderline", TRUE);

	settings.TitleAlignCenter = GetRCBool("TasksTitleAlignCenter", TRUE);
	settings.TitleMinAlignCenter = GetRCBool("TasksTitleMinAlignCenter", TRUE);
	settings.TitleSelAlignCenter = GetRCBool("TasksTitleSelAlignCenter", TRUE);

	settings.TitleBgColor = GetRCColor("TasksTitleBgColor", 0xFF00FF);
	settings.TitleMinBgColor = GetRCColor("TasksTitleMinBgColor", settings.TitleBgColor);
	settings.TitleSelBgColor = GetRCColor("TasksTitleSelBgColor", settings.TitleBgColor);

	settings.TitleDarkColor = GetRCColor("TasksTitleDarkColor", 0xFF00FF);
	settings.TitleMinDarkColor = GetRCColor("TasksTitleMinDarkColor", settings.TitleDarkColor);
	settings.TitleSelDarkColor = GetRCColor("TasksTitleSelDarkColor", settings.TitleDarkColor);

	settings.TitleFontColor = GetRCColor("TasksTitleFontColor", 0xC0C0C0); /*'C0C0C0' is a light gray*/
	settings.TitleMinFontColor = GetRCColor("TasksTitleMinFontColor", settings.TitleFontColor);
	settings.TitleSelFontColor = GetRCColor("TasksTitleSelFontColor", settings.TitleFontColor);

	settings.TitleLightColor = GetRCColor("TasksTitleLightColor", 0xFF00FF);
	settings.TitleMinLightColor = GetRCColor("TasksTitleMinLightColor", settings.TitleLightColor);
	settings.TitleSelLightColor = GetRCColor("TasksTitleSelLightColor", settings.TitleLightColor);

	*tmp = '\0';
	GetRCString("TasksTitleFont", tmp, "Arial", MAXLEN);
	settings.TitleFont = new char[strlen(tmp)+1];
	strcpy(settings.TitleFont, tmp);
	*tmp = '\0';
	GetRCString("TasksTitleMinFont", tmp, settings.TitleFont, MAXLEN);
	settings.TitleMinFont = new char[strlen(tmp)+1];
	strcpy(settings.TitleMinFont, tmp);
	*tmp = '\0';
	GetRCString("TasksTitleSelFont", tmp, settings.TitleFont, MAXLEN);
	settings.TitleSelFont = new char[strlen(tmp)+1];
	strcpy(settings.TitleSelFont, tmp);

	*tmp = '\0';
	GetRCLine("TasksMButton3", tmp, MAXLEN, "!POPUP");
	settings.MButton3 = new char[strlen(tmp)+1];
	strcpy(settings.MButton3, tmp);
	*tmp = '\0';
	GetRCLine("TasksMButton2", tmp, MAXLEN, ".SYSPOPUP");
	settings.MButton2 = new char[strlen(tmp)+1];
	strcpy(settings.MButton2, tmp);
	*tmp = '\0';
	GetRCLine("TasksMButton1", tmp, MAXLEN, "!NONE");
	settings.MButton1 = new char[strlen(tmp)+1];
	strcpy(settings.MButton1, tmp);

	*tmp = '\0';
	GetRCLine("TasksEmptyCmd", tmp, MAXLEN, "!NONE");
	settings.EmptyCmd = new char[strlen(tmp)+1];
	strcpy(settings.EmptyCmd, tmp);

	settings.hueIntensity    = (UCHAR)min( max( GetRCInt("TasksIconHueIntensity",0), 0), 255 );
	settings.clrHue          = GetRCColor("TasksIconHueColor",RGB(128,128,128));
	settings.saturation     = (UCHAR)min( max( GetRCInt("TasksIconSaturation",255), 0), 255 );
	
	return settings;
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, const char* /*szPath*/)
{
	dll = dllInst;
	parent = ParentWnd;
	screenWidth = GetSystemMetrics(SM_CXSCREEN);
	screenHeight = GetSystemMetrics(SM_CYSCREEN);
	captureTask = -1;
	capMClick = -1;

	{ /* register window class */
		WNDCLASS wc;
		memset(&wc,0,sizeof(wc));
		//wc.cbClsExtra = NULL;
		//wc.cbWndExtra = NULL;
		//wc.hbrBackground = NULL;
		//wc.hCursor = NULL;
		//wc.hIcon = NULL;
		wc.hInstance = dllInst;
		wc.lpfnWndProc = WndProc;
		wc.lpszClassName = szAppName;
		//wc.lpszMenuName = NULL;
		//wc.style = NULL;
		if (!RegisterClass(&wc)){
			MessageBox(parent,"Error registering window class","Tasks",MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
			return 1;
		}
	}

	mainWin = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, "Timer", WS_CHILD, 0,0,0,0, parent, NULL, dll, NULL);
	if (!mainWin){
		MessageBox(parent,"Error creating window","Tasks",MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		quitModule(dll);
		return 1;
	}
	SetWindowLong(mainWin, GWL_USERDATA, 0x49474541);

		// Do these need to be destroyed on exit?
	movingCursor = LoadCursor(NULL, IDC_UPARROW);
	normalCursor = LoadCursor(NULL, IDC_ARROW);
	ts = ReadSettings();
	if (!ts.NoIcons)
		ReadTasksIcon();
	ReadTasksClass();
	ReadTasksAdd();
	ReadTasksIgnore();
	ReadTasksPix();
	ReadTasksWrapCmd();
	if (ts.DockWindow != NULL && IsWindow(ts.DockWindow)){
		RECT r;
		GetWindowRect(ts.DockWindow, &r);
		dockWidth = r.right - r.left;
		dockHeight = r.bottom - r.top;
	}else{
		ts.DockWindow = NULL;
		dockWidth = screenWidth;
		dockHeight = screenHeight;
	}

	if (!ts.NoHints){
		hints = CreateWindow(TOOLTIPS_CLASS,NULL,TTS_ALWAYSTIP,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,NULL,(HMENU)NULL,dll,NULL);
		if (!hints){
			MessageBox(parent, "Error creating ToolTip Window. ToolTips are now disabled!", "Tasks", MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
			ts.NoHints = TRUE;
		}else
			SetWindowPos(hints, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
	}

	AddBangCommand("!TASKSGATHER", TasksGather);
	AddBangCommand("!TASKSHIDE", TasksHide);
	AddBangCommand("!TASKSMOVE", TasksMove);
	AddBangCommand("!TASKSSHOW", TasksShow);
	AddBangCommand("!TASKSSWITCH", TasksSwitch);
	AddBangCommand("!TASKSTOGGLE", TasksToggle);
	AddBangCommand("!TASKSDISPLAY", TasksDisplay);
	AddBangCommand("!TASKSDOCKWINDOW", TasksDockWindow);
	AddBangCommand("!TASKSZORDER", TaskszOrder);
	AddBangCommand("!TASKSMINIMIZE", TasksMinimize);
	AddBangCommand("!TASKSMAXIMIZE", TasksMaximize);
	AddBangCommand("!TASKSRESTORE", TasksRestore);
	AddBangCommand("!TASKSBOXHOOK", TasksBoxHook);

	if (ts.UseSystemHook)
		if (!SendMessage(GetLitestepWnd(), LM_GETLSOBJECT, NULL, NULL))
			ts.UseSystemHook = FALSE;
	if (ts.UseSystemHook){
		UINT Msgs[6];
		Msgs[0] = LM_GETREVID;
		Msgs[1] = LM_WINDOWCREATED;
		Msgs[2] = LM_WINDOWDESTROYED;
		Msgs[3] = LM_WINDOWACTIVATED;
		Msgs[4] = LM_REDRAW;
		Msgs[5] = 0;
		SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM)mainWin, (LPARAM)Msgs);
	}else{
		UINT Msgs[2];
		Msgs[0] = LM_GETREVID;
		Msgs[1] = 0;
		SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM)mainWin, (LPARAM)Msgs);

		if (!SetTimer(mainWin, TMR_UPDATE, ts.SetTimer, (TIMERPROC)NULL)){
			MessageBox(parent,"Error creating update Timer!\nCan not continue to load.","Tasks",MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
			quitModule(dll);
			return 1;
		}
	}

		/*Immediately add and update tasks, instead of waiting 250ms for the first round of the timer.*/
	curTask = GetForegroundWindow();
	EnumWindows(EnumWindowsProc, NULL);/*Add new apps to tasks list*/
	UpdateTasks();/*Update task windows*/
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	/* We should probably NULL and zero out all of the globals just in case... */

	int i;

	if (ts.UseSystemHook){
		UINT Msgs[6];
		Msgs[0] = LM_GETREVID;
		Msgs[1] = LM_WINDOWCREATED;
		Msgs[2] = LM_WINDOWDESTROYED;
		Msgs[3] = LM_WINDOWACTIVATED;
		Msgs[4] = LM_REDRAW;
		Msgs[5] = 0;
		SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM) mainWin, (LPARAM) Msgs);
	}else{
		UINT Msgs[2];
		KillTimer(mainWin, TMR_UPDATE);
		// unregister the litestep version info message.
		Msgs[0] = LM_GETREVID;
		Msgs[1] = 0;
		SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM) mainWin, (LPARAM) Msgs);
	}

	RemoveBangCommand("!TASKSGATHER");
	RemoveBangCommand("!TASKSHIDE");
	RemoveBangCommand("!TASKSMOVE");
	RemoveBangCommand("!TASKSSHOW");
	RemoveBangCommand("!TASKSSWITCH");
	RemoveBangCommand("!TASKSTOGGLE");
	RemoveBangCommand("!TASKSDISPLAY");
	RemoveBangCommand("!TASKSDOCKWINDOW");
	RemoveBangCommand("!TASKSZORDER");
	RemoveBangCommand("!TASKSMINIMIZE");
	RemoveBangCommand("!TASKSMAXIMIZE");
	RemoveBangCommand("!TASKSRESTORE");
	RemoveBangCommand("!TASKSBOXHOOK");

	FreeList();

	if (!ts.NoHints && hints != NULL)
		DestroyWindow(hints);

	for (i=0;i<numWrapCmd;i++){
		delete [] wrapCmd[i].cmd;
	}	if (wrapCmd){
			free(wrapCmd);
		}

	for (i=0;i<numPix;i++){
		delete [] pixTag[i].match;
		delete [] pixTag[i].pix;
	}	if (pixTag){
			free(pixTag);
		}

	for (i=0;i<numIcon;i++){
		delete [] iconTag[i].match;
		delete [] iconTag[i].name;
	}	if (iconTag){
			free(iconTag);
		}

	for (i=0;i<numAdd;i++){
		delete [] addTag[i].match;
	}	if (addTag){
			free(addTag);
		}

	for (i=0;i<numIgnore;i++){
		delete [] ignoreTag[i].match;
	}	if (ignoreTag){
			free(ignoreTag);
		}

 	for (i=0;i<numClass;i++){
 		delete [] classTag[i].match;
 		delete [] classTag[i].name;
 	}	if (classTag){
 			free(classTag);
 		}

	delete [] ts.MButton3;
	delete [] ts.MButton2;
	delete [] ts.MButton1;

	delete [] ts.TitleFont;
	delete [] ts.TitleMinFont;
	delete [] ts.TitleSelFont;

	if (ts.BgImage)
		DeleteObject(ts.BgImage);
	if (ts.MinBgImage)
		DeleteObject(ts.MinBgImage);
	if (ts.SelBgImage)
		DeleteObject(ts.SelBgImage);

	if (ts.HideMinAppBar)
		ArrangeIconicWindows(GetDesktopWindow());

	DestroyWindow(mainWin);
	UnregisterClass(szAppName,dllInst);
	return;
}

BOOL GetTasksAdd(char * addStr)
{
	int i;
	for (i=0;i<numAdd;i++){
		if (strstr(addStr, addTag[i].match))
			return TRUE;
	}
	return FALSE;
}

BOOL GetTasksIgnore(char * ignoreStr)
{
	int i;
	if (!lstrcmpi(ignoreStr, "WindowsScreenSaverClass") || !lstrcmpi(ignoreStr, "tooltips_class32"))
		return TRUE;
	for (i=0;i<numIgnore;i++)
		if (strstr(ignoreStr, ignoreTag[i].match))
			return TRUE;
	return FALSE;
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	TaskType* tmpTasks = NULL;
	lParam=lParam;
	if (!(numTasks < ts.MaxTiles) && ts.MaxTiles > 0) return FALSE;
	if (IsWindow(hwnd) && !InWinList(hwnd)){
		if (IsValidWindow(hwnd)){
			if (tasks == NULL)
				tasks = (TaskType *)malloc(sizeof(TaskType));
			else{
				tmpTasks = tasks;
				tasks = (TaskType *)realloc(tasks, (numTasks+1)*sizeof(TaskType));
			}
			if (tasks == NULL){
				tasks = tmpTasks;
				tmpTasks = NULL;
				return FALSE;
			}
			tmpTasks = NULL;
			memset(&tasks[numTasks], 0, sizeof(TaskType));
			CreateTask(numTasks, hwnd);
		}
		else if (ts.HideMinAppBar && IsWindowVisible(hwnd) && IsIconic(hwnd))
			HideMinAppBar(hwnd);
	}
	return TRUE;
}

BOOL IsAppWindow(HWND hwnd, BOOL chkOwner)
{/*This is based off of code from re5ource's Popups*/
	BOOL bResult = FALSE;
	LONG nStyle;
	HWND hOwner;

	if (IsWindow(hwnd)){
		/*if the magicDWord <-- UserData type used by shells to say it is a shell window, fail*/
		if(GetWindowLong(hwnd, GWL_USERDATA) != 0x49474541){
			/*if it is a WS_CHILD or not WS_VISIBLE, fail*/
			nStyle = GetWindowLong(hwnd, GWL_STYLE);
			if(!(nStyle & WS_CHILD) && (nStyle & WS_VISIBLE)){
				/*if everything up to this point passes and it is an WS_EX_APPWINDOW force a pass*/
				nStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
				if (nStyle & WS_EX_APPWINDOW)
					bResult = TRUE;
				/*if the window is a WS_EX_TOOLWINDOW fail it*/
				else if(!(nStyle & WS_EX_TOOLWINDOW)){
					/*if it has a parent, fail*/
					if (GetParent(hwnd) == NULL){
						hOwner = GetWindow(hwnd, GW_OWNER);
						if (hOwner == NULL){
							RECT r;
							GetClientRect(hwnd, &r);
							if (IsRectEmpty(&r)){
								GetWindowRect(hwnd, &r);
								bResult = !IsRectEmpty(&r) ? IsIconic(hwnd):FALSE;
							}else
								bResult = TRUE;
							if (!chkOwner)
								bResult = !bResult;
						}else{
							bResult = IsAppWindow(hOwner, FALSE);
							if (bResult == TRUE && GetTaskByAppWnd(hwnd) != GetTaskByAppWnd(hOwner))
								bResult = FALSE;
						}
					}
				}
			}
		}
	}
	return bResult;
}

BOOL IsValidWindow(HWND hwnd)
{
	BOOL bResult = FALSE;

	if (IsWindow(hwnd)){
		int maskVal = 0x00;

			/* Fixes Tasks tile disapearing when ts.Display does not have "normal" value applied, and a user clicks on the active tile */
		maskVal |= (hwnd == curTask || (hwnd == lockCurTask && (capMClick != -1 || captureTask != -1))) ? 0x04:0x00;
		//maskVal |= hwnd == curTask ? 0x04:0x00;
		maskVal |= IsIconic(hwnd) ? 0x02:0x00;
		maskVal |= (maskVal & 0x02) || (maskVal & 0x04) ? 0x00:0x01;

		if ( (maskVal & ts.Display) ){
			char tmpTitle[MAXLEN], tmpClass[MAXLEN];

			GetWindowText(hwnd, tmpTitle, MAXLEN);
			GetClassName(hwnd, tmpClass, MAXLEN);

			if ( !(GetTasksIgnore(tmpTitle) || GetTasksIgnore(tmpClass)) )
				if ( (IsWindowVisible(hwnd) && (IsAppWindow(hwnd, TRUE) || GetTasksAdd(tmpTitle) || GetTasksAdd(tmpClass))) )
					bResult = TRUE;
		}
	}

	return bResult;
}

HICON GetIconFromWindow(HWND hwnd, BOOL bBigIcon)
{/*This code is a mix from re5ource's Popups and Fahim's lsTasks*/
	HICON a=NULL;
	if (!bBigIcon){
		SendMessageTimeout(hwnd, WM_GETICON, ICON_SMALL, 0, 0, 1000, (unsigned long*)&a);
		if (!a) a = (HICON)GetClassLong(hwnd, GCL_HICONSM);
		if (!a) SendMessageTimeout(hwnd, WM_GETICON, ICON_BIG, 0, 0, 1000, (unsigned long*)&a);
		if (!a) a = (HICON)GetClassLong(hwnd, GCL_HICON);
		if (!a) SendMessageTimeout(hwnd, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long*)&a);
	}else{
		SendMessageTimeout(hwnd, WM_GETICON, ICON_BIG, 0, 0, 1000, (unsigned long*)&a);
		if (!a) a = (HICON)GetClassLong(hwnd, GCL_HICON);
		if (!a) SendMessageTimeout(hwnd, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long*)&a);
		if (!a) SendMessageTimeout(hwnd, WM_GETICON, ICON_SMALL, 0, 0, 1000, (unsigned long*)&a);
		if (!a) a = (HICON)GetClassLong(hwnd, GCL_HICONSM);
	}
	if (!a)
		a = LoadIcon(NULL, MAKEINTRESOURCE(IDI_APPLICATION));
	return a;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case LM_GETREVID:
		{
			char* buf = (char*)lParam;
			strcpy(buf, aboutStr);
			return strlen(buf);
		}
		case WM_DROPFILES:
		{/*thanks again to Fahim for pointing me in the right direction*/
			int n = GetTaskByWnd(hwnd);
			if (n != -1){
				POINT pt;
				HDROP hDrop = (HDROP)wParam;
				DragQueryPoint(hDrop, &pt);

				if (IsIconic(tasks[n].appHandle2)){
					SendMessage(tasks[n].appHandle2, WM_SYSCOMMAND, (WPARAM)SC_RESTORE, 0);
					SendMessage(parent, LM_BRINGTOFRONT, 0, (long)tasks[n].appHandle);
					SetForegroundWindow(GetLastActivePopup(tasks[n].appHandle2));
				}else{
					SendMessage(parent, LM_BRINGTOFRONT, 0, (long)tasks[n].appHandle);
					SetForegroundWindow(GetLastActivePopup(tasks[n].appHandle2));
				}

				SendMessage(tasks[n].appHandle, message, (WPARAM)hDrop, (LPARAM)NULL);
				DragFinish(hDrop);
				return 0;
			}
//			MessageBox(parent, "You cannot drag an item onto a Tasks Tile. Yet..."/*\n\r\n\rHowever, if you do this without releasing the mouse button, the window will open and you can then drag the item into the window."*/, "Tasks", MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_TOPMOST|MB_APPLMODAL);
			break;
		}
		case LM_WINDOWCREATED:
		case LM_WINDOWDESTROYED:
		case LM_WINDOWACTIVATED:
		case LM_REDRAW:
		case WM_TIMER:
			if (message != WM_TIMER || (message == WM_TIMER && wParam == TMR_UPDATE)){
				int oldNumTasks = ts.AutoArrange ? GetUnMovedNrTasks(numTasks):numTasks;
				oldCurTask = curTask;
				curTask = GetForegroundWindow();
				if (!InWinList(curTask) && GetTaskByWnd(curTask) == -1){
					HWND tmpWnd = NULL;
					if (InWinList(tmpWnd = GetParent(curTask)) || InWinList(tmpWnd = GetWindow(curTask, GW_OWNER)))
						curTask = tasks[GetTaskByAppWnd(tmpWnd)].appHandle;
				}
				if (oldCurTask != curTask)
					lockCurTask = oldCurTask;
				PackList();/*Get rid of old apps in tasks list*/
				EnumWindows(EnumWindowsProc, NULL);/*Add new apps to tasks list*/
				UpdateTasks();/*Update task windows*/

				// NEED TO FIX THIS NOT EXECUTING WHEN MOVING(DRAGGING) A TASK OUT OF THE ARRANGED ORDER

				if (oldNumTasks != (ts.AutoArrange ? GetUnMovedNrTasks(numTasks):numTasks)){
					if (numTasks == 0)
						LSExecute(mainWin, ts.EmptyCmd, 0);
					else if (taskWrap && numWrapCmd){
						int tmpNumTasks = ts.AutoArrange ? GetUnMovedNrTasks(numTasks):numTasks;

						if (
								(oldNumTasks < tmpNumTasks && tmpNumTasks % ts.WrapCount == 1)
								||
								(oldNumTasks > tmpNumTasks && tmpNumTasks % ts.WrapCount == 0)
							)
						{
							for (int i=0;i<numWrapCmd;i++){
								if (wrapCmd[i].index == ((oldNumTasks > tmpNumTasks) ? (tmpNumTasks/ts.WrapCount - 1) : (tmpNumTasks/ts.WrapCount))){
									LSExecute(mainWin, wrapCmd[i].cmd, 0);
									i=numWrapCmd;
								}
							}
						}
					}
				}
				return 0;
			}
			break;
		case WM_PAINT:
		{
			int n = GetTaskByWnd(hwnd);
			if (n != -1){
				PAINTSTRUCT ps;
				HDC hdc = BeginPaint(hwnd,&ps);

				if (ts.UseWindowsSettings){
					UINT dcFlags = DC_TEXT|DC_ICON;
					RECT r;
					GetClientRect(hwnd, &r);
					if (ts.HighLightSelected && tasks[n].IsActive) dcFlags |= DC_ACTIVE;
					DrawCaption(tasks[n].appHandle2, hdc, &r, dcFlags);
				}else{
					HDC hdcbuf = CreateCompatibleDC(hdc);
					HBITMAP hbmpbuf = CreateCompatibleBitmap(hdc,ts.Width,ts.Height);
					HBITMAP holdbmp = (HBITMAP) SelectObject(hdcbuf,hbmpbuf);

					if (ts.Transparency == 1)
						PaintDesktop(hdc); // paint to original DC

					PaintTask(hdcbuf, n);  // Painting to a buffer first.
					if (ts.Transparency == 2){  // TRUE TRANSPARENCY CODE BY GUSTAV MUNKBY
						SelectObject(hdcbuf,holdbmp);
						HRGN tile = BitmapToRegion(hbmpbuf, 0x00EF00EF, 0x00101010, 0, 0);
						SetWindowRgn(tasks[n].hwnd,tile,TRUE);
						holdbmp = (HBITMAP) SelectObject(hdcbuf,hbmpbuf);
					}

					if (ts.Transparency == 1)
						TransparentBltLS(hdc, 0,0, ts.Width,ts.Height, hdcbuf, 0,0, RGB(255,0,255));
					else // this is faster(?)
						BitBlt(hdc, 0,0, ts.Width,ts.Height, hdcbuf, 0,0, SRCCOPY);

					SelectObject(hdcbuf,holdbmp);
					DeleteObject(hbmpbuf);
					DeleteDC(hdcbuf);
				}
				EndPaint(hwnd,&ps);
				return 0;
			}
			break;
		}
		case WM_DISPLAYCHANGE:
		{// Screen resolution has changed. Update stored settings.
				screenWidth = LOWORD(lParam);
				screenHeight = HIWORD(lParam);

				if (ts.DockWindow == NULL){
					dockWidth = screenWidth;
					dockHeight = screenHeight;
					TasksGather(NULL, NULL);
				}

				/*
				if (ts.DockWindow != NULL && IsWindow(ts.DockWindow)){
					// Is this necessary?
					RECT r;
					GetWindowRect(ts.DockWindow, &r);
					dockWidth = r.right - r.left;
					dockHeight = r.bottom - r.top;
				}else{
					dockWidth = screenWidth;
					dockHeight = screenHeight;
				}
				TasksGather();
				*/
				break; // no specified return value, so just break...
		}
		case WM_LBUTTONDOWN:
		{
			if (capMClick == -1 && (captureTask = GetTaskByWnd(hwnd)) != -1){
				GetCursorPos(&oldCursorPos);
				SetCapture(tasks[captureTask].hwnd);
				return 0;
			}
			break;
		}
		case WM_MOUSEMOVE:
		{
			int n = GetTaskByWnd(hwnd);
			if (n != -1){
				if ((wParam == MK_LBUTTON) && !ts.NoMove && n == captureTask){
					int x,y;
					POINT cursorPos;
					GetCursorPos(&cursorPos);
					if (cursorPos.x == oldCursorPos.x && cursorPos.y == oldCursorPos.y){
						if (normalCursor != NULL && GetCursor() != normalCursor)
							SetCursor(normalCursor);
					}else{
						if (movingCursor != NULL && GetCursor() != movingCursor)
							SetCursor(movingCursor);
					}
					x = tasks[n].x - (oldCursorPos.x - cursorPos.x);
					y = tasks[n].y - (oldCursorPos.y - cursorPos.y);
					if (x < 0) x = 0;
					if (y < 0) y = 0;
					if (x + ts.Width > dockWidth) x = dockWidth - ts.Width;
					if (y + ts.Height > dockHeight) y = dockHeight - ts.Height;
					SetWindowPos(tasks[n].hwnd,HWND_TOPMOST,x,y,0,0,SWP_NOSIZE|SWP_NOACTIVATE);//|SWP_NOSENDCHANGING);
					if (!ts.StartHidden && ts.Transparency == 1)
						InvalidateRect(hwnd, NULL, TRUE);/* psuedo transparency during move, causes some flicker, but it works (Maduin)*/
				}else{
					if (normalCursor != NULL && GetCursor() != normalCursor)
						SetCursor(normalCursor);
				}
				return 0;
			}
			break;
		}
		case WM_LBUTTONUP:
		{
			POINT cursorPos;
			GetCursorPos(&cursorPos);
			int n = GetTaskByWnd(hwnd);
			if (n != -1 && n == captureTask && capMClick == -1){
				if ((abs(oldCursorPos.x - cursorPos.x) <= ts.DragDistance && abs(oldCursorPos.y - cursorPos.y) <= ts.DragDistance) || ts.NoMove){
					SetWindowPos(tasks[n].hwnd, 0, tasks[n].x, tasks[n].y, ts.Width, ts.Height, SWP_NOACTIVATE|SWP_NOZORDER);//SWP_NOSENDCHANGING
					if (tasks[n].hwnd == WindowFromPoint(cursorPos) && IsWindowVisible(tasks[n].appHandle2)){ //if someone uses *TasksAdd to add a window that might turn invisible, we don't want to activate it when invisible.
						if (IsIconic(tasks[n].appHandle2)){
							SendMessage(tasks[n].appHandle2, WM_SYSCOMMAND, (WPARAM)SC_RESTORE, 0);
							SendMessage(parent, LM_BRINGTOFRONT, 0, (long)tasks[n].appHandle);/*This is for VWM's, so that it changes VW's on task focus... -jugg*/
							SetForegroundWindow(GetLastActivePopup(tasks[n].appHandle2));
						}
						else if (!ts.NoMinimizeOnClick && (tasks[n].appHandle == curTask || (tasks[n].hwnd == curTask && tasks[n].appHandle == lockCurTask))){
							HWND hTmpWnd = GetLastActivePopup(tasks[n].appHandle2);
							if (hTmpWnd == curTask || hTmpWnd == lockCurTask)
								SendMessage(tasks[n].appHandle2, WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE, 0);
						}else{
							SendMessage(parent, LM_BRINGTOFRONT, 0, (long)tasks[n].appHandle);/*This is for VWM's, so that it changes VW's on task focus... -jugg*/
							SetForegroundWindow(GetLastActivePopup(tasks[n].appHandle2));
						}
						LSExecute(hwnd, ts.MButton1, 0);
					}else
						SetForegroundWindow(GetLastActivePopup(hwnd == curTask ? lockCurTask:oldCurTask));
				}
				else if (!ts.NoMove){ /*move*/
					int tmpoldx, tmpoldy;
					tmpoldx = tasks[n].x;
					tmpoldy = tasks[n].y;
					tasks[n].x -= oldCursorPos.x - cursorPos.x;
					tasks[n].y -= oldCursorPos.y - cursorPos.y;
					if (tasks[n].x < 0) tasks[n].x = 0;
					if (tasks[n].y < 0) tasks[n].y = 0;
					if (tasks[n].x + ts.Width > dockWidth) tasks[n].x = dockWidth - ts.Width;
					if (tasks[n].y + ts.Height > dockHeight) tasks[n].y = dockHeight - ts.Height;
					if (ts.MoveAll){
						BOOL wasHidden = ts.StartHidden;
						ts.X -= tmpoldx - tasks[n].x;
						ts.Y -= tmpoldy - tasks[n].y;
						if (ts.X < 0)
							ts.X = ((ts.Direction == 4 || (taskWrap && ts.WrapDirection == 4))) ? 1:0;
						if (ts.Y < 0)
							ts.Y = ((ts.Direction == 1 || (taskWrap && ts.WrapDirection == 1))) ? 1:0;
						if (!wasHidden)
							TasksHide(NULL,NULL);
						rAllTasks.left = rAllTasks.right = rAllTasks.top = rAllTasks.bottom = 0;
						ReArrangeTasks(0, TRUE);
						if (rAllTasks.right > dockWidth){
							if (ts.Direction == 4 || (taskWrap && ts.WrapDirection == 4))
								ts.X = dockWidth;
							else
								ts.X -= rAllTasks.right - dockWidth;
						}
						if (rAllTasks.bottom > dockHeight){
							if (ts.Direction == 1 || (taskWrap && ts.WrapDirection == 1))
								ts.Y = dockHeight;
							else
								ts.Y -= rAllTasks.bottom - dockHeight;
						}
						if (rAllTasks.left < 0){
							if (ts.Direction == 4 || (taskWrap && ts.WrapDirection == 4))
								ts.X -= rAllTasks.left;
							else
								ts.X = 0;
						}
						if (rAllTasks.top < 0){
							if (ts.Direction == 1 || (taskWrap && ts.WrapDirection == 1))
								ts.Y -= rAllTasks.top;
							else
								ts.Y = 0;
						}
						rAllTasks.left = rAllTasks.right = rAllTasks.top = rAllTasks.bottom = 0;
						if (!wasHidden)
							TasksShow(NULL,NULL);
						ReArrangeTasks(0, TRUE);
					}else{
						SetWindowPos(tasks[n].hwnd, 0, tasks[n].x, tasks[n].y, ts.Width, ts.Height, SWP_NOACTIVATE|SWP_NOZORDER);
						if (!tasks[n].IsMoved){
							tasks[n].IsMoved = TRUE;
							if (ts.AutoArrange)
								ReArrangeTasks(n, FALSE);
						}
					}
					SetForegroundWindow(GetLastActivePopup(tasks[n].IsActive ? tasks[n].appHandle2:lockCurTask));
				}
			}
			if (normalCursor != NULL && GetCursor() != normalCursor)
				SetCursor(normalCursor);
			lockCurTask = NULL;
			captureTask = -1;
			ReleaseCapture();
			return 0;
		}
		case WM_RBUTTONDOWN:
		case WM_MBUTTONDOWN:
		{
			if (captureTask == -1 && (capMClick = GetTaskByWnd(hwnd)) != -1){
				SetCapture(tasks[capMClick].hwnd);
				return 0;
			}
			break;
		}
		case WM_RBUTTONUP:
		case WM_MBUTTONUP:
		{
			POINT cursorPos;
			GetCursorPos(&cursorPos);
			int n = GetTaskByWnd(WindowFromPoint(cursorPos)); // want to allow execution as long as the MButtonUP is on a task Tile, regardless of which task tile the DOWN action was on.
			if (n != -1 && captureTask == -1 && capMClick != -1){
				if ( (message == WM_RBUTTONUP && !_stricmp(ts.MButton2, ".syspopup")) || (message == WM_MBUTTONUP && !_stricmp(ts.MButton3, ".syspopup")) ){
					if (IsIconic(tasks[n].appHandle2))
						SetForegroundWindow(GetLastActivePopup(tasks[n].appHandle2));
					else{
						SendMessage(parent, LM_BRINGTOFRONT, 0, (long)tasks[n].appHandle);
						SetForegroundWindow(GetLastActivePopup(tasks[n].appHandle2));
					}
					Sleep(130); //some computers are too fast (or slow?) and need a delay... but doesn't hurt if they aren't, so do it regardless
					PostMessage(tasks[n].appHandle2, 0x313, 0, GetMessagePos()); // Using PostMessage() instead of SendMessage() since it doesn't wait for a return, thus allowing tasks.dll to continue processing.
				}else{
					if (message == WM_RBUTTONUP)
						LSExecute(hwnd, ts.MButton2 , 0);
					else if (message == WM_MBUTTONUP)
						LSExecute(hwnd, ts.MButton3 , 0);
				}
			}else
				SetForegroundWindow(GetLastActivePopup(hwnd == curTask ? lockCurTask:oldCurTask));
			capMClick = -1;
			ReleaseCapture();
			return 0;
		}
		/*Capture unwanted closing commands, we only want to exit when LiteStep tells us to*/
		case WM_CLOSE:
		case WM_SYSCOMMAND:
			return 0;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

int GetTaskByWnd(HWND hwnd)
{
	if (hwnd)
		for (int i=0;i<numTasks;i++)
			if (tasks[i].hwnd == hwnd)
				return i;
	return -1;
}

int GetTaskByAppWnd(HWND hwnd)
{
	if (hwnd)
		for (int i=0;i<numTasks;i++)
			if (tasks[i].appHandle == hwnd || tasks[i].appHandle2 == hwnd)
				return i;
	return -1;
}

int GetUnMovedNrTasks(int n)
{
	int j=0;
	for (int i=0;i<n;i++)
		if (!tasks[i].IsMoved)
			++j;
	return j;
}

int InWinList(HWND hwnd)
{
	if (hwnd)
		for (int i=0;i<numTasks;i++)
			if (tasks[i].appHandle == hwnd || tasks[i].appHandle2 == hwnd)
				return i+1;
	return 0;
}

void CreateHints(HWND hwnd, char * txt)
{ /*from the original ls code (shortcuts)*/
	RECT r;
	GetClientRect(hwnd, &r);
	TOOLINFO ti;/*tool information*/
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hwnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = txt;
	ti.rect = r;
	SendMessage(hints, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
	return;
}

void CreateTask(int i, HWND handle)
{
	HWND hwnd = NULL;
	GetNewTaskPos(i);
	hwnd = CreateWindowEx(WS_EX_ACCEPTFILES|WS_EX_TOOLWINDOW|(ts.zOrder == 2 ? WS_EX_TOPMOST:0), szAppName, "", (ts.DockWindow != NULL) ? WS_CHILD:WS_POPUP, tasks[i].x, tasks[i].y, ts.Width, ts.Height, (ts.DockWindow != NULL) ? ts.DockWindow:NULL, NULL, dll, NULL);
	if (hwnd == NULL)
		MessageBox(parent,"Error creating window","Tasks",MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
	else{
		if (ts.DockWindow != NULL)
			SetWindowLong(hwnd, GWL_STYLE, (GetWindowLong(hwnd, GWL_STYLE) &~ WS_CHILD)|WS_POPUP);
		tasks[i].hwnd = hwnd;
		tasks[i].appHandle = handle;
		if ((tasks[i].appHandle2 = GetWindow(handle, GW_OWNER)) == NULL)
			tasks[i].appHandle2 = handle;
			//keeps the tiles from showing up in shell lists/displays, as well as keeping them on every VW in a VWM.
		SetWindowLong(tasks[i].hwnd, GWL_USERDATA, 0x49474541);

			// Populate Title Text
		{
			char titleTmp[MAXLEN];
			GetWindowText(tasks[i].appHandle2, titleTmp, MAXLEN);
			tasks[i].appTitle = new char[strlen(titleTmp) + 1];
			strcpy(tasks[i].appTitle, titleTmp);
		}

			// Populate Class Text
		GetTasksClass(i);

		tasks[i].IsActive = (tasks[i].appHandle == curTask);
		tasks[i].IsIconic = IsIconic(tasks[i].appHandle2);
		if (tasks[i].IsIconic && ts.HideMinAppBar) HideMinAppBar(tasks[i].appHandle);
		tasks[i].IsMoved  = FALSE;
		tasks[i].IsCustomIcon = FALSE;
		if (!ts.NoIcons)
			GetTasksIcon(i);
		GetTasksPix(i);
		if (ts.StartHidden)
			ShowWindow(tasks[i].hwnd, SW_HIDE);
		else
			ShowWindow(tasks[i].hwnd, SW_SHOWNOACTIVATE);
		if (!ts.NoHints)
			CreateHints(tasks[i].hwnd, tasks[i].appTitle);
		++numTasks;
	}

	if (ts.Sort)
		ReArrangeTasks(0, FALSE);

	return;
}

void DeleteTask(int i)
{
	ShowWindow(tasks[i].hwnd, SW_HIDE);
	if (!ts.NoHints)
		RemoveHints(tasks[i].hwnd);
	if (tasks[i].pix){
		DeleteObject(tasks[i].pix);
		tasks[i].pix = NULL;
	}
	if (tasks[i].appClass){
		delete [] tasks[i].appClass;
		tasks[i].appClass = NULL;
	}
	if (tasks[i].appTitle){
		delete [] tasks[i].appTitle;
		tasks[i].appTitle = NULL;
	}
	if (tasks[i].icon && tasks[i].IsCustomIcon){
		DestroyIcon(tasks[i].icon);
		tasks[i].icon = NULL;
	}
	if (tasks[i].hwnd){
		DestroyWindow(tasks[i].hwnd);
		tasks[i].hwnd = NULL;
	}
	return;
}

void GetNewTaskPos(int i)
{
	TaskPosition(i, (ts.AutoArrange && !ts.NoMove ? GetUnMovedNrTasks(numTasks):numTasks));
	return;
}

void UpdateTasks(void)
{
	int n;
	BOOL refreshTask = FALSE;
	BOOL resortTasks = FALSE;

	if (ts.DockWindow != NULL && !IsWindow(ts.DockWindow)){
		ts.DockWindow = NULL;
		dockWidth = screenWidth;
		dockHeight = screenHeight;
		FreeList();
		EnumWindows(EnumWindowsProc, NULL);
	}

		// Should this be happening every time? Seems a bit much.
	if (ts.DockWindow != NULL){
		RECT r;
		GetWindowRect(ts.DockWindow, &r);
		if (dockWidth != r.right - r.left || dockHeight != r.bottom - r.top){
			dockWidth = r.right - r.left;
			dockHeight = r.bottom - r.top;
			TasksGather(NULL, NULL);
		}
	}

	for (n=0;n<numTasks;n++){
		if (tasks[n].IsIconic != IsIconic(tasks[n].appHandle2)){
			tasks[n].IsIconic = !tasks[n].IsIconic;
			if (ts.HideMinAppBar)
				HideMinAppBar(tasks[n].appHandle);
			if (ts.HighLightMinimized || !(ts.Titles && ts.TitleMinimized && ts.TitleSelected))
				refreshTask = TRUE;
		}

		if (capMClick == -1 && captureTask == -1 && tasks[n].IsActive != (curTask == tasks[n].appHandle)){
			tasks[n].IsActive = !tasks[n].IsActive;
			if (!refreshTask && (ts.HighLightSelected || !(ts.Titles && ts.TitleMinimized && ts.TitleSelected)))
				refreshTask = TRUE;
		}

		{
			char tmpTitle[MAXLEN];
			GetWindowText(tasks[n].appHandle2, tmpTitle, MAXLEN);
			if (strcmp(tmpTitle, tasks[n].appTitle)){
				delete [] tasks[n].appTitle;
				tasks[n].appTitle = new char[strlen(tmpTitle) + 1];
				strcpy(tasks[n].appTitle, tmpTitle);
				if (!ts.NoHints)
					UpdateHints(tasks[n].hwnd, tasks[n].appTitle);
				if (!refreshTask && (ts.UseWindowsSettings || (ts.Titles && !(tasks[n].IsIconic || tasks[n].IsActive)) || (ts.TitleMinimized && tasks[n].IsIconic) || (ts.TitleSelected && tasks[n].IsActive)))
					refreshTask = TRUE;
				resortTasks = TRUE;
			}
		}

		if (!ts.UseWindowsSettings && !tasks[n].pix && !tasks[n].IsCustomIcon && !ts.NoIcons && tasks[n].icon != GetIconFromWindow(tasks[n].appHandle2, (ts.IconSize > 23) ? TRUE:FALSE)){
			tasks[n].icon = GetIconFromWindow(tasks[n].appHandle2, (ts.IconSize > 23) ? TRUE:FALSE);
			refreshTask = TRUE;
		}

		if (!ts.StartHidden && refreshTask)
			InvalidateRect(tasks[n].hwnd, NULL, TRUE);

		refreshTask = FALSE;
	}

	if (ts.Sort && resortTasks)
		ReArrangeTasks(0, FALSE);
	return;
}

// Allow for the user to substitute a class name based upon the
// title or classname. This is useful for apps that do not set
// the classname to something constant for sorting. Also it allows
// you to put a certain class last or first easily by substituting
// a prefix such as "aaa" or "zzz"
void GetTasksClass(int n)
{
	int i;
	char classTmp[MAXLEN];
	BOOL found = FALSE;

	GetClassName(tasks[n].appHandle2, classTmp, MAXLEN);
	for (i=0;found == FALSE && i<numClass;i++)
	{
		if (strstr(tasks[n].appTitle, classTag[i].match) || strstr(classTmp, classTag[i].match))
		{
			strcpy(classTmp, classTag[i].name);
			found = TRUE;
		}
	}
	tasks[n].appClass = new char[strlen(classTmp) + 1];
	strcpy(tasks[n].appClass, classTmp);
	return;
}

void GetTasksIcon(int n)
{
	int i;
	for (i=0;i<numIcon;i++)
	{
		if (strstr(tasks[n].appTitle, iconTag[i].match) || strstr(tasks[n].appClass, iconTag[i].match))
		{
			tasks[n].icon = ExtractIcon(dll,iconTag[i].name,iconTag[i].icon);
			if (tasks[n].icon != NULL )
			{
				tasks[n].IsCustomIcon = TRUE;
				return;
			}
		}
	}
	tasks[n].icon = GetIconFromWindow(tasks[n].appHandle2, (ts.IconSize > 23) ? TRUE:FALSE);
	tasks[n].IsCustomIcon = FALSE;
	return;
}

void GetTasksPix(int n)
{
	int i;
	for (i=0;i<numPix;i++)
	{
		if (strstr(tasks[n].appTitle, pixTag[i].match) || strstr(tasks[n].appClass, pixTag[i].match))
		{
			tasks[n].pix = LoadLSImage(pixTag[i].pix, NULL);
			if (tasks[n].pix)
			{
				if (tasks[n].icon && tasks[n].IsCustomIcon)
					DestroyIcon(tasks[n].icon);
				tasks[n].icon = NULL;
				tasks[n].IsCustomIcon = FALSE;
				return;
			}
		}
	}
	return;
}

void HideMinAppBar(HWND hwnd)
{
	if (IsIconic(hwnd)){
		RECT r;
		GetWindowRect(hwnd, &r);
		MoveWindow(hwnd, screenWidth*5+r.left, screenHeight*5+r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}
	return;
}

void FreeList(void)
{
	int n;
	for (n=0;n<numTasks;n++)
		DeleteTask(n);
	if (tasks != NULL){
		free(tasks);
		tasks = NULL;
	}
	numTasks = 0;
}

void PackList(void)
{
	int a,b,c,d,e,n;
	e=-1;
	a=b=c=d=n=0;

	if (!numTasks)
		return;
	while ( c<numTasks ){
		for ( a=c ; a<numTasks && IsValidWindow(tasks[a].appHandle) ; a++ )
			++n;
		if (a==numTasks)
			return;
		if (e==-1 && (!ts.AutoArrange || ts.NoMove))
			e=n;
		for ( b=a ; b<numTasks && !IsValidWindow(tasks[b].appHandle) ; b++ ){
			if (ts.AutoArrange && !ts.NoMove && !tasks[b].IsMoved && e==-1)
				e=n;
			DeleteTask(b);
		}
		if (b==numTasks){
			//break; // yuch, but ohwell I suppose... Don't know which is better, set 'c' greater then numTasks so the next interation fails, or using the 'break;'
			c=numTasks+1; // gonna try this for a while... should work.
		}else{
			d=1;
			for ( c=b+1 ; c<numTasks && IsValidWindow(tasks[c].appHandle) ; c++ )
				++d;
			memmove(&tasks[n], &tasks[b], d*sizeof(TaskType));
			n+=d;
		}
	}
	if (!n){
		if (tasks != NULL){
			free(tasks);
			tasks = NULL;
			numTasks = 0;
		}
	}else{
		TaskType* tmpTasks = tasks;
		tasks = (TaskType *)realloc(tasks, (n)*sizeof(TaskType));
		if (tasks == NULL){
			free(tmpTasks);
			tmpTasks = NULL;
			numTasks = 0;
		}else{
			numTasks=n;
			if (e!=-1)
				ReArrangeTasks(e, FALSE);
		}
	}
	return;
}

void PaintTask(HDC hdcbuf, int i)
{
	int posX, posXpix, posXtmp, posY, posYpix, posYtmp, titleFontSize, titleWidth, titleHeight, titleX, titleY;
	BOOL activeTask = ts.HighLightSelected && tasks[i].IsActive;
	BOOL minTask = ts.HighLightMinimized && tasks[i].IsIconic;
	BOOL minTitles = ts.TitleMinimized && tasks[i].IsIconic;
	BOOL selTitles = ts.TitleSelected && tasks[i].IsActive;
	BOOL normTitles = ts.Titles && !(tasks[i].IsActive || tasks[i].IsIconic);
	BOOL bUnderline, bNoEllipsis, bItalic, bAlignCenter;
	CHAR titleFont[MAXLEN];
	COLORREF bgColor, darkColor, lightColor, titleBgColor, titleDarkColor, titleFontColor, titleLightColor;
	BITMAP bmInfo;

	HDC src = CreateCompatibleDC(hdcbuf);
	//HBITMAP hbmpbuf = CreateCompatibleBitmap(hdcbuf,ts.Width,ts.Height);
	//HBITMAP holdbmp = (HBITMAP) SelectObject(src,hbmpbuf);

	if (activeTask)
	{
		bgColor = ts.SelBgColor;
		lightColor = ts.SelLightColor;
		darkColor = ts.SelDarkColor;
		titleBgColor = ts.TitleSelBgColor;
		titleDarkColor = ts.TitleSelDarkColor;
		titleFontColor = ts.TitleSelFontColor;
		titleLightColor = ts.TitleSelLightColor;
		strcpy(titleFont, ts.TitleSelFont);
		titleFontSize = ts.TitleSelFontSize;
		titleHeight = ts.TitleSelHeight;
		titleWidth = ts.TitleSelWidth;
		titleX = ts.TitleSelX;
		titleY = ts.TitleSelY;
		bNoEllipsis = ts.TitleSelNoEllipsis;
		bUnderline = ts.TitleSelUnderline;
		bItalic = ts.TitleSelItalicize;
		bAlignCenter = ts.TitleAlignCenter;
		if (selTitles){
			posX = ts.TitleSelIconX;
			posY = ts.TitleSelIconY;
			posXpix = ts.TitleSelPixX;
			posYpix = ts.TitleSelPixY;
		}else{
			posX = ts.SelIconX;
			posY = ts.SelIconY;
			posXpix = ts.SelPixX;
			posYpix = ts.SelPixY;
		}
	}
	else if (minTask)
	{
		bgColor = ts.MinBgColor;
		lightColor = ts.MinLightColor;
		darkColor = ts.MinDarkColor;
		titleBgColor = ts.TitleMinBgColor;
		titleDarkColor = ts.TitleMinDarkColor;
		titleFontColor = ts.TitleMinFontColor;
		titleLightColor = ts.TitleMinLightColor;
		strcpy(titleFont, ts.TitleMinFont);
		titleFontSize = ts.TitleMinFontSize;
		titleHeight = ts.TitleMinHeight;
		titleWidth = ts.TitleMinWidth;
		titleX = ts.TitleMinX;
		titleY = ts.TitleMinY;
		bNoEllipsis = ts.TitleMinNoEllipsis;
		bUnderline = ts.TitleMinUnderline;
		bItalic = ts.TitleMinItalicize;
		bAlignCenter = ts.TitleMinAlignCenter;
		if (minTitles){
			posX = ts.TitleMinIconX;
			posY = ts.TitleMinIconY;
			posXpix = ts.TitleMinPixX;
			posYpix = ts.TitleMinPixY;
		}else{
			posX = ts.MinIconX;
			posY = ts.MinIconY;
			posXpix = ts.MinPixX;
			posYpix = ts.MinPixY;
		}
	}
	else
	{
		bgColor = ts.BgColor;
		lightColor = ts.LightColor;
		darkColor = ts.DarkColor;
		titleBgColor = ts.TitleBgColor;
		titleDarkColor = ts.TitleDarkColor;
		titleFontColor = ts.TitleFontColor;
		titleLightColor = ts.TitleLightColor;
		strcpy(titleFont, ts.TitleFont);
		titleFontSize = ts.TitleFontSize;
		titleHeight = ts.TitleHeight;
		titleWidth = ts.TitleWidth;
		titleX = ts.TitleX;
		titleY = ts.TitleY;
		bNoEllipsis = ts.TitleNoEllipsis;
		bUnderline = ts.TitleUnderline;
		bItalic = ts.TitleItalicize;
		bAlignCenter = ts.TitleSelAlignCenter;
		if (normTitles || minTitles || selTitles){
			posX = ts.TitleIconX;
			posY = ts.TitleIconY;
			posXpix = ts.TitlePixX;
			posYpix = ts.TitlePixY;
		}else{
			posX = ts.IconX;
			posY = ts.IconY;
			posXpix = ts.PixX;
			posYpix = ts.PixY;
		}
	}

	{ // fill complete area with background color
		RECT r;
		HBRUSH bg, oldBg;
		GetClientRect(tasks[i].hwnd, &r);
		bg = CreateSolidBrush(bgColor);
		oldBg = (HBRUSH) SelectObject(hdcbuf, bg);
		FillRect(hdcbuf, &r, bg);
		SelectObject(hdcbuf, oldBg);
		DeleteObject(bg);
		bg = oldBg = NULL;
	}

	if ((ts.BgImage || (ts.SelBgImage && activeTask) || (ts.MinBgImage && minTask)) && !(selBgImgNone && activeTask) && !(minBgImgNone && minTask))
	{/*Paint the background image. Believe me, the above if conditions are all necessary. Odd, but necessary :)*/
		HBITMAP hOldBitmap;
		if (ts.MinBgImage && minTask)
		{
			GetObject(ts.MinBgImage, sizeof(bmInfo), &bmInfo);
			hOldBitmap = (HBITMAP) SelectObject(src, ts.MinBgImage); //dde
		}
		else if (ts.SelBgImage && activeTask)
		{
			GetObject(ts.SelBgImage, sizeof(bmInfo), &bmInfo);
			hOldBitmap = (HBITMAP) SelectObject(src, ts.SelBgImage); //dde
		}
		else
		{
			GetObject(ts.BgImage, sizeof(bmInfo), &bmInfo);
			hOldBitmap = (HBITMAP) SelectObject(src, ts.BgImage); //dde
		}
		posXtmp = ts.Width/2 - bmInfo.bmWidth/2;   /*Center in Tile*/
		posYtmp = ts.Height/2 - bmInfo.bmHeight/2;

		TransparentBltLS(hdcbuf, posXtmp, posYtmp, bmInfo.bmWidth, bmInfo.bmHeight, src, 0, 0, RGB(255, 0, 255));
		SelectObject (src, hOldBitmap); //dde
		hOldBitmap = NULL;
	}

	if (tasks[i].pix)
	{
		HBITMAP hOldPix;
		GetObject(tasks[i].pix, sizeof(bmInfo), &bmInfo);
		hOldPix = (HBITMAP) SelectObject(src, tasks[i].pix); //dde

		TransparentBltLS(hdcbuf, posXpix, posYpix, bmInfo.bmWidth, bmInfo.bmHeight, src, 0, 0, RGB(255,0,255));
		SelectObject (src, hOldPix); //dde
	}
	else if (tasks[i].icon && !ts.NoIcons)
	{
    	int y = 0;
		HDC hdcScreen = CreateDC("DISPLAY", NULL, NULL, NULL);
		HDC hdcIcon = CreateCompatibleDC(hdcScreen);
		HBITMAP hbmpIcon = CreateCompatibleBitmap(hdcbuf, ts.IconSize*2, ts.IconSize);
		HBITMAP hbmpOldIcon = (HBITMAP)SelectObject(hdcIcon, hbmpIcon);

		DeleteDC(hdcScreen);

		DrawIconEx(hdcIcon, 0, 0, tasks[i].icon, ts.IconSize, ts.IconSize, 0, NULL, DI_NORMAL);
	    DrawIconEx(hdcIcon, ts.IconSize, 0, tasks[i].icon, ts.IconSize, ts.IconSize, 0, NULL, DI_MASK);

		while (y < ts.IconSize)
		{			
			int x = 0;
			while (x < ts.IconSize)
			{
				// loop through all transparent pixels...
				while (x < ts.IconSize)
				{
					// if the mask-pixel is white, then break
					if ( !GetPixel(hdcIcon, x+ts.IconSize, y) )
					{
						COLORREF cl = GetPixel(hdcIcon, x, y);
						BYTE r = GetRValue(cl);
						BYTE g = GetGValue(cl);
						BYTE b = GetBValue(cl);

						// saturnation effect
						if (ts.saturation != 255)
						{
							BYTE gray = (BYTE)(r*0.3086+g*0.6094+b*0.0820);

							r = (BYTE)((r*ts.saturation+gray*(255-ts.saturation)+255)>>8);
							g = (BYTE)((g*ts.saturation+gray*(255-ts.saturation)+255)>>8);
							b = (BYTE)((b*ts.saturation+gray*(255-ts.saturation)+255)>>8);
						}

						// icon hue effect
						if (ts.hueIntensity)
						{
							// the B & R values of the hue is swapped here, can somebody tell me why it only works that way?
							r = (BYTE)((r*(255-ts.hueIntensity)+GetBValue(ts.clrHue)*ts.hueIntensity+255)>>8);
							g = (BYTE)((g*(255-ts.hueIntensity)+GetGValue(ts.clrHue)*ts.hueIntensity+255)>>8);
							b = (BYTE)((b*(255-ts.hueIntensity)+GetRValue(ts.clrHue)*ts.hueIntensity+255)>>8);
						}

						//that saves us from the nasty Mask stuff and we don't have to do the BitBLT -blkhawk
						SetPixel(hdcbuf, posX+x, posY+y, RGB(r, g, b));
						//SetPixel(hdcIcon, x, y, RGB(r, g, b));
					}
					x++;
				}
			}
			y++;
		}
        
		// This isn't needed anymore -blkhawk
		// Copy the icon the the buffer
		// BitBlt(hdcbuf, posX, posY, ts.IconSize, ts.IconSize, hdcIcon, 0, 0, SRCCOPY);

		SelectObject(hdcIcon, hbmpOldIcon);
		DeleteObject(hbmpIcon);
		DeleteDC(hdcIcon);

	}
	if (normTitles || minTitles || selTitles)
	{/*Paint the title boxes - bg/border/text*/
		RECT r;
		GetClientRect(tasks[i].hwnd, &r);
		r.top = titleY;
		r.left = titleX;
		r.bottom = titleHeight + titleY;
		r.right = titleWidth + titleX;

		if (titleBgColor != 0x00FF00FF){
			HBRUSH titleBg, oldTitleBg;
			titleBg = CreateSolidBrush(titleBgColor);
			oldTitleBg = (HBRUSH) SelectObject(hdcbuf, titleBg);
			FillRect(hdcbuf, &r, titleBg);
			SelectObject(hdcbuf, oldTitleBg);
			DeleteObject(titleBg);
		}
		if (titleLightColor != 0x00FF00FF)
		{/*Light Color Bevel (left/top)*/
			HPEN pen, oldpen;
			pen = CreatePen(PS_SOLID, 1, titleLightColor);
			oldpen = (HPEN) SelectObject(hdcbuf, pen);
			MoveToEx(hdcbuf, r.left, r.bottom - 1, NULL);
			LineTo(hdcbuf, r.left, r.top);
			LineTo(hdcbuf, r.right - 1, r.top);
			SelectObject(hdcbuf, oldpen);
			DeleteObject(pen);
		}
		if (titleDarkColor != 0x00FF00FF)
		{/*Dark Color Bevel (bottom/right)*/
			HPEN pen, oldpen;
			pen = CreatePen(PS_SOLID, 1, titleDarkColor);
			oldpen = (HPEN) SelectObject(hdcbuf, pen);
			MoveToEx(hdcbuf, r.right - 1, r.top, NULL);
			LineTo(hdcbuf, r.right - 1, r.bottom - 1);
			LineTo(hdcbuf, r.left, r.bottom - 1);
			SelectObject(hdcbuf, oldpen);
			DeleteObject(pen);
		}
		if (titleFontColor != 0x00FF00FF)
		{
			HFONT Font, oldFont;
			int oldBkMode;
			int len = strlen(tasks[i].appTitle);
			r.top += 1;
			r.bottom -= 1;
			r.left += 2;
			r.right -= 2;
			Font = CreateFont(titleFontSize, 0, 0, 0, FW_NORMAL, (bItalic ? TRUE:FALSE), (bUnderline ? TRUE:FALSE), FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, PROOF_QUALITY, DEFAULT_PITCH|FF_DONTCARE, titleFont);
			oldFont = (HFONT) SelectObject(hdcbuf, Font);
			oldBkMode = SetBkMode(hdcbuf, TRANSPARENT);
			SetTextColor(hdcbuf, titleFontColor);
			DrawText(hdcbuf, tasks[i].appTitle, len, &r, DT_VCENTER|DT_SINGLELINE|(bNoEllipsis ? 0:DT_END_ELLIPSIS)|(bAlignCenter ? DT_CENTER:0));
			SetBkMode(hdcbuf, oldBkMode);
			SelectObject(hdcbuf, oldFont);
			DeleteObject(Font);
		}
	}
	{/*Main task border*/
		RECT r;
		GetClientRect(tasks[i].hwnd, &r);
		if (lightColor != 0x00FF00FF)
		{/*Light Color Bevel (left/top)*/
			HPEN pen, oldpen;
			pen = CreatePen(PS_SOLID, 1, lightColor);
			oldpen = (HPEN) SelectObject(hdcbuf, pen);
			MoveToEx(hdcbuf, r.left, r.bottom - 1, NULL);
			LineTo(hdcbuf, r.left, r.top);
			LineTo(hdcbuf, r.right - 1, r.top);
			SelectObject(hdcbuf, oldpen);
			DeleteObject(pen);
		}
		if (darkColor != 0x00FF00FF)
		{/*Dark Color Bevel (bottom/right)*/
			HPEN pen, oldpen;
			pen = CreatePen(PS_SOLID, 1, darkColor);
			oldpen = (HPEN) SelectObject(hdcbuf, pen);
			MoveToEx(hdcbuf, r.right - 1, r.top, NULL);
			LineTo(hdcbuf, r.right - 1, r.bottom - 1);
			LineTo(hdcbuf, r.left, r.bottom - 1);
			SelectObject(hdcbuf, oldpen);
			DeleteObject(pen);
		}
	}
	//SelectObject(src,holdbmp);
	//DeleteObject(hbmpbuf);
	DeleteDC(src);
	return;
}

BOOL StripWS(char * buffer)
{// strip leading and trailing white space from full String
	UINT length = buffer ? strlen (buffer):0;
	while ( length && isspace(*buffer) ){
		strcpy (buffer, buffer + 1);
		--length;
	}
	while ( length && isspace(buffer[length-1]) )
		buffer[--length] = 0;
	if ( length ) return TRUE;
	if ( buffer != NULL )
		*buffer = 0;
	return FALSE;
}

void ReadTasksClass(void)
{
	FILE * f;
	unsigned int i;
	char * token[3];
	char buffer[4096];
	numClass = 0;
	f = LCOpen(NULL);
	if (!f)
		return;
	for (i=0; i<3; i++)
		token[i] = new char[MAXLEN];
	while (LCReadNextConfig (f, "*TasksClass", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 3, NULL);
		if (count >= 3)
		{
			if (!classTag)
				classTag = (ClassList *)malloc(sizeof(ClassList));
			else
				classTag = (ClassList *)realloc(classTag, (numClass+1)*sizeof(ClassList));
			classTag[numClass].match = new char[strlen(token[1])+1];
			classTag[numClass].name = new char[strlen(token[2])+1];
			strcpy(classTag[numClass].match, token[1]);
			strcpy(classTag[numClass].name, token[2]);
			numClass++;
		}
	}
	LCClose(f);
	for (i=0; i<3; i++)
		delete [] token[i];
	return;
}

void ReadTasksIcon(void)
{
	FILE * f;
	unsigned int i;
	char * token[4];
	char buffer[4096];
	numIcon = 0;
	f = LCOpen(NULL);
	if (!f)
		return;
	for (i=0;i<4;i++)
		token[i] = new char[MAXLEN];
	while (LCReadNextConfig (f, "*TasksIcon", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 4, NULL);
		if (count >= 4)
		{
			if (!iconTag)
				iconTag = (IconList *)malloc(sizeof(IconList));
			else
				iconTag = (IconList *)realloc(iconTag, (numIcon+1)*sizeof(IconList));
			iconTag[numIcon].match = new char[strlen(token[1])+1];
			iconTag[numIcon].name = new char[strlen(token[2])+1];
			strcpy(iconTag[numIcon].match, token[1]);
			strcpy(iconTag[numIcon].name, token[2]);
			iconTag[numIcon].icon = atoi(token[3]);
			numIcon++;
		}
	}
	LCClose(f);
	for (i=0; i<4; i++)
		delete [] token[i];
	return;
}

void ReadTasksAdd(void)
{
	FILE * f;
	unsigned int i;
	char * token[2];
	char buffer[4096];
	numAdd = 0;
	f = LCOpen(NULL);
	if (!f)
		return;
	for (i=0;i<2;i++)
		token[i] = new char[MAXLEN];
	while (LCReadNextConfig (f, "*TasksAdd", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 2, NULL);
		if (!StripWS(token[1])) continue;
		if (count >= 2)
		{
			if (!addTag)
				addTag = (AddList *)malloc(sizeof(AddList));
			else
				addTag = (AddList *)realloc(addTag, (numAdd+1)*sizeof(AddList));
			addTag[numAdd].match = new char[strlen(token[1])+1];
			strcpy(addTag[numAdd].match, token[1]);
			numAdd++;
		}
	}
	LCClose(f);
	for (i = 0; i < 2; i++)
		delete [] token[i];
	return;
}

void ReadTasksIgnore(void)
{
	FILE * f;
	unsigned int i;
	char * token[2];
	char buffer[4096];
	numIgnore = 0;
	f = LCOpen(NULL);
	if (!f)
		return;
	for (i=0;i<2;i++)
		token[i] = new char[MAXLEN];
	while (LCReadNextConfig (f, "*TasksIgnore", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 2, NULL);
		if (!StripWS(token[1])) continue;
		if (count >= 2)
		{
			if (!ignoreTag)
				ignoreTag = (IgnoreList *)malloc(sizeof(IgnoreList));
			else
				ignoreTag = (IgnoreList *)realloc(ignoreTag, (numIgnore+1)*sizeof(IgnoreList));
			ignoreTag[numIgnore].match = new char[strlen(token[1])+1];
			strcpy(ignoreTag[numIgnore].match, token[1]);
			numIgnore++;
		}
	}
	LCClose(f);
	for (i = 0; i < 2; i++)
		delete [] token[i];
	return;
}

void ReadTasksPix(void)
{
	FILE * f;
	unsigned int i;
	char * token[3];
	char buffer[4096];
	numPix = 0;
	f = LCOpen(NULL);
	if (!f)
		return;
	for (i=0;i<3;i++)
		token[i] = new char[MAXLEN];
	while (LCReadNextConfig (f, "*TasksPix", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 3, NULL);
		if (count >= 3)
		{
			if (!pixTag)
				pixTag = (PixList *)malloc(sizeof(PixList));
			else
				pixTag = (PixList *)realloc(pixTag, (numPix+1)*sizeof(PixList));
			pixTag[numPix].match = new char[strlen(token[1])+1];
			pixTag[numPix].pix = new char[strlen(token[2])+1];
			strcpy(pixTag[numPix].match, token[1]);
			strcpy(pixTag[numPix].pix, token[2]);
			numPix++;
		}
	}
	LCClose(f);
	for (i = 0; i < 3; i++)
		delete [] token[i];
	return;
}

void ReadTasksWrapCmd(void)
{
	FILE * f;
	unsigned int i;
	char * token[3];
	char buffer[4096];
	numWrapCmd = 0;
	f = LCOpen(NULL);
	if (!f)
		return;
	for (i=0;i<3;i++)
		token[i] = new char[MAXLEN];
	while (LCReadNextConfig (f, "*TasksWrapCmd", buffer, sizeof(buffer)))
	{
		int count;
		count = LCTokenize (buffer, token, 3, NULL);
		if (count >= 3)
		{
			if (!wrapCmd)
				wrapCmd = (WrapCmdList *)malloc(sizeof(WrapCmdList));
			else
				wrapCmd = (WrapCmdList *)realloc(wrapCmd, (numWrapCmd+1)*sizeof(WrapCmdList));
			wrapCmd[numWrapCmd].index = atoi(token[1]);
			wrapCmd[numWrapCmd].cmd = new char[strlen(token[2])+1];
			strcpy(wrapCmd[numWrapCmd].cmd, token[2]);
			numWrapCmd++;
		}
	}
	LCClose(f);
	for (i = 0; i < 3; i++)
		delete [] token[i];
	return;
}

// function called by qsort to sort tasks based on the primary
// key of the class name and the secondary key the title
int SortTasksByClassTitle(const void *i0, const void *i1)
{
  TaskType *a = (TaskType*) i0;
  TaskType *b = (TaskType*) i1;
  int cv;

  cv = strcmp(a->appClass, b->appClass);

  if (cv)
    return cv;

  return strcmp(a->appTitle, b->appTitle);
}

void ReArrangeTasks(int i, BOOL all)
{
	int j=i;
	if (ts.AutoArrange && !ts.NoMove && !all && i>0)
		j = GetUnMovedNrTasks(i);

	if (ts.Sort && (i == 0))
		qsort(tasks, numTasks, sizeof(TaskType), SortTasksByClassTitle);

	for ( ;i<numTasks;i++){
		if (all || !tasks[i].IsMoved){
			TaskPosition(i, j);
			SetWindowPos(tasks[i].hwnd, 0, tasks[i].x, tasks[i].y, ts.Width, ts.Height, SWP_NOZORDER|SWP_NOACTIVATE);
			tasks[i].IsMoved = FALSE;
			if (!ts.StartHidden)/*Have to force a complete redraw here...*/
				InvalidateRect(tasks[i].hwnd, NULL, TRUE);
			++j;
		}
	}
	return;
}

void RemoveHints(HWND hwnd)
{/*from the original ls code (shortcuts)*/
	TOOLINFO ti;/*tool information*/
	RECT r={0,0,0,0};
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hwnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = NULL;
	ti.rect = r;
	SendMessage(hints, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
	return;
}

void TaskPosition(int i, int tmpNumTasks)
{
	int wrapLine = 0, resetLine = 0, tWrapCount = ts.WrapCount;
	if (ts.WrapCount == -1){ //auto wrap
		switch (ts.Direction)
		{
			case 1:
				tWrapCount = ((ts.Y > 0) ? ts.Y:(dockHeight + ts.Y)) / ts.Height;
				break;
			case 2:
				tWrapCount = ((ts.X >= 0) ? (dockWidth - ts.X):abs(ts.X)) / ts.Width;
				break;
			case 3:
				tWrapCount = ((ts.Y >= 0) ? (dockHeight - ts.Y):abs(ts.Y)) / ts.Height;
				break;
			case 4:
				tWrapCount = ((ts.X > 0) ? ts.X:(dockWidth + ts.X)) / ts.Width;
				break;
		}
		if (tWrapCount < 1)
			tWrapCount = 1;
		taskWrap = TRUE;
	}

	if (taskWrap)
	{
		wrapLine = tmpNumTasks / tWrapCount;
		resetLine = tmpNumTasks - tWrapCount * wrapLine;
	}

	if (ts.Direction == 1) /*up*/
	{
		if (taskWrap)
		{
			if (ts.Y > 0) // >=0
				tasks[i].y = ts.Y - ts.Height - resetLine * (ts.Height + ts.SpacingY);
			else /*now accepts negative values*/
				tasks[i].y = dockHeight + ts.Y - ts.Height - resetLine * (ts.Height + ts.SpacingY);
			if (ts.WrapDirection == 4) /*left*/
			{
				if (ts.X > 0) // >=0
					tasks[i].x = ts.X - ts.Width - wrapLine * (ts.Width + ts.SpacingX);
				else /*now accepts negative values*/
					tasks[i].x = dockWidth + ts.X - ts.Width - wrapLine * (ts.Width + ts.SpacingX);
			}
			else /*defaults to right, even if user inputs invalid up or down setting*/
			{
				if (ts.X >= 0)
					tasks[i].x = ts.X + wrapLine * (ts.Width + ts.SpacingX);
				else /*now accepts negative values*/
					tasks[i].x = dockWidth + ts.X + wrapLine * (ts.Width + ts.SpacingX);
			}
		}
		else
		{
			if (ts.X >= 0)
				tasks[i].x = ts.X;
			else /*now accepts negative values*/
				tasks[i].x = dockWidth + ts.X;
			if (ts.Y > 0) // >=0
				tasks[i].y = ts.Y - ts.Height - tmpNumTasks * (ts.Height + ts.SpacingY);
			else /*now accepts negative values*/
				tasks[i].y = dockHeight + ts.Y - ts.Height - tmpNumTasks * (ts.Height + ts.SpacingY);
		}
	}
	else if (ts.Direction == 2) /*right*/
	{
		if (taskWrap)
		{
			if (ts.X >= 0)
				tasks[i].x = ts.X + resetLine * (ts.Width + ts.SpacingX);
			else /*now accepts negative values*/
				tasks[i].x = dockWidth + ts.X + resetLine * (ts.Width + ts.SpacingX);
			if (ts.WrapDirection == 1) /*up*/
			{
				if (ts.Y > 0) // >=0
					tasks[i].y = ts.Y - ts.Height - wrapLine * (ts.Height + ts.SpacingY);
				else /*now accepts negative values*/
					tasks[i].y = dockHeight + ts.Y - ts.Height - wrapLine * (ts.Height + ts.SpacingY);
			}
			else /*defaults to down, even if user inputs invalid left or right setting*/
			{
				if (ts.Y >= 0)
					tasks[i].y = ts.Y + wrapLine * (ts.Height + ts.SpacingY);
				else /*now accepts negative values*/
					tasks[i].y = dockHeight + ts.Y + wrapLine * (ts.Height + ts.SpacingY);
			}
		}
		else
		{
			if (ts.X >= 0)
				tasks[i].x = ts.X + tmpNumTasks * (ts.Width + ts.SpacingX);
			else /*now accepts negative values*/
				tasks[i].x = dockWidth + ts.X + tmpNumTasks * (ts.Width + ts.SpacingX);
			if (ts.Y >= 0)
				tasks[i].y = ts.Y;
			else /*now accepts negative values*/
				tasks[i].y = dockHeight + ts.Y;
		}
	}
	else if (ts.Direction == 3) /*down*/
	{
		if (taskWrap)
		{
			if (ts.Y >= 0)
				tasks[i].y = ts.Y + resetLine * (ts.Height + ts.SpacingY);
			else /*now accepts negative values*/
				tasks[i].y = dockHeight + ts.Y + resetLine * (ts.Height + ts.SpacingY);
			if (ts.WrapDirection == 4) /*left*/
			{
				if (ts.X > 0) // >=0
					tasks[i].x = ts.X - ts.Width - wrapLine * (ts.Width + ts.SpacingX);
				else /*now accepts negative values*/
					tasks[i].x = dockWidth + ts.X - ts.Width - wrapLine * (ts.Width + ts.SpacingX);
			}
			else /*defaults to right, even if user inputs invalid up or down setting*/
			{
				if (ts.X >= 0)
					tasks[i].x = ts.X + wrapLine * (ts.Width + ts.SpacingX);
				else /*now accepts negative values*/
					tasks[i].x = dockWidth + ts.X + wrapLine * (ts.Width + ts.SpacingX);
			}
		}
		else
		{
			if (ts.X >= 0)
				tasks[i].x = ts.X;
			else /*now accepts negative values*/
				tasks[i].x = dockWidth + ts.X;
			if (ts.Y >= 0)
				tasks[i].y = ts.Y + tmpNumTasks * (ts.Height + ts.SpacingY);
			else /*now accepts negative values*/
				tasks[i].y = dockHeight + ts.Y + tmpNumTasks * (ts.Height + ts.SpacingY);
		}
	}
	else if (ts.Direction == 4) /*left*/
	{
		if (taskWrap)
		{
			if (ts.X > 0) // >=0
				tasks[i].x = ts.X - ts.Width - resetLine * (ts.Width + ts.SpacingX);
			else /*now accepts negative values*/
				tasks[i].x = dockWidth + ts.X - ts.Width - resetLine * (ts.Width + ts.SpacingX);
			if (ts.WrapDirection == 1) /*up*/
			{
				if (ts.Y > 0) // >=0
					tasks[i].y = ts.Y - ts.Height - wrapLine * (ts.Height + ts.SpacingY);
				else /*now accepts negative values*/
					tasks[i].y = dockHeight + ts.Y - ts.Height - wrapLine * (ts.Height + ts.SpacingY);
			}
			else /*defaults to down, even if user inputs invalid left or right setting*/
			{
				if (ts.Y >= 0)
					tasks[i].y = ts.Y + wrapLine * (ts.Height + ts.SpacingY);
				else /*now accepts negative values*/
					tasks[i].y = dockHeight + ts.Y + wrapLine * (ts.Height + ts.SpacingY);
			}
		}
		else
		{
			if (ts.X > 0) // >=0
				tasks[i].x = ts.X - ts.Width - tmpNumTasks * (ts.Width + ts.SpacingX);
			else /*now accepts negative values*/
				tasks[i].x = dockWidth + ts.X - ts.Width - tmpNumTasks * (ts.Width + ts.SpacingX);
			if (ts.Y >= 0)
				tasks[i].y = ts.Y;
			else /*now accepts negative values*/
				tasks[i].y = dockHeight + ts.Y;
		}
	}
	if (tasks[i].x < rAllTasks.left) rAllTasks.left = tasks[i].x;
	if (tasks[i].x + ts.Width > rAllTasks.right) rAllTasks.right = tasks[i].x + ts.Width;
	if (tasks[i].y < rAllTasks.top) rAllTasks.top = tasks[i].y;
	if (tasks[i].y + ts.Height > rAllTasks.bottom) rAllTasks.bottom = tasks[i].y + ts.Height;
	return;
}

void UpdateHints(HWND hwnd, char * txt)
{
	RECT r;
	GetClientRect(hwnd, &r);
	TOOLINFO ti;
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hwnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = txt;
	ti.rect = r;
	SendMessage(hints, TTM_UPDATETIPTEXT, 0, (LPARAM) (LPTOOLINFO) &ti);
	return;
}

/*From here down are the !bang commands*/
void TasksGather(HWND hwnd, LPCSTR szArgs)
{
	UNREFERENCED_PARAMETER(hwnd);
	UNREFERENCED_PARAMETER(szArgs);

	ts.X = bkUpX;
	ts.Y = bkUpY;
	ReArrangeTasks(0, TRUE);
	return;
}

void TasksHide(HWND hwnd, LPCSTR szArgs)
{
	UNREFERENCED_PARAMETER(hwnd);
	UNREFERENCED_PARAMETER(szArgs);

	for (int i=0;i<numTasks;i++)
		ShowWindow(tasks[i].hwnd, SW_HIDE);
	ts.StartHidden = TRUE;
	return;
}

void TasksMove(HWND caller, LPCSTR args)
{
	caller = caller;
	if (args != NULL && *args != 0){
		char * orgArgs = new char[strlen(args)+1];
		char * tmpArgs = orgArgs;
		strcpy(tmpArgs, args);
		if (StripWS(tmpArgs)){
			tmpArgs = strtok(tmpArgs, "\'\"\t ,");
				if (tmpArgs != NULL )
					ts.X = atoi(tmpArgs);
				if (ts.X < 0)
					ts.X += dockWidth;
			tmpArgs = strtok(NULL, "\'\"\t ,");
				if (tmpArgs != NULL )
					ts.Y = atoi(tmpArgs);
				if (ts.Y < 0)
					ts.Y += dockHeight;
		}
		delete [] orgArgs;
		orgArgs = tmpArgs = NULL;
	}else{
		BOOL wasHidden = ts.StartHidden;
		POINT ps;
		GetCursorPos(&ps);
		ts.X = ps.x;
		ts.Y = ps.y;
		if ((ts.Direction == 4 || (taskWrap && ts.WrapDirection == 4))) ts.X += 1;
		if ((ts.Direction == 1 || (taskWrap && ts.WrapDirection == 1))) ts.Y += 1;
		rAllTasks.left = rAllTasks.right = rAllTasks.top = rAllTasks.bottom = 0;
		if (!wasHidden)
			TasksHide(NULL,NULL);
		ReArrangeTasks(0, TRUE);
		if (rAllTasks.right > dockWidth){
			if (ts.Direction == 4 || (taskWrap && ts.WrapDirection == 4))
				ts.X = dockWidth;
			else
				ts.X -= rAllTasks.right - dockWidth;
		}
		if (rAllTasks.bottom > dockHeight){
			if (ts.Direction == 1 || (taskWrap && ts.WrapDirection == 1))
				ts.Y = dockHeight;
			else
				ts.Y -= rAllTasks.bottom - dockHeight;
		}
		if (rAllTasks.left < 0){
			if (ts.Direction == 4 || (taskWrap && ts.WrapDirection == 4))
				ts.X -= rAllTasks.left;
			else
				ts.X = 0;
		}
		if (rAllTasks.top < 0){
			if (ts.Direction == 1 || (taskWrap && ts.WrapDirection == 1))
				ts.Y -= rAllTasks.top;
			else
				ts.Y = 0;
		}
		rAllTasks.left = rAllTasks.right = rAllTasks.top = rAllTasks.bottom = 0;
		if (!wasHidden)
			TasksShow(NULL,NULL);
	}
	ReArrangeTasks(0, TRUE);
	return;
}

void TasksShow(HWND hwnd, LPCSTR szArgs)
{
	UNREFERENCED_PARAMETER(hwnd);
	UNREFERENCED_PARAMETER(szArgs);

	for (int i=0;i<numTasks;i++)
		ShowWindow(tasks[i].hwnd, SW_SHOWNOACTIVATE);
	ts.StartHidden = FALSE;
	return;
}

void TasksSwitch(HWND caller, LPCSTR args)
{
	caller=caller;
	if (!numTasks || args == NULL || *args == 0 || !strlen(args)) return;

	BOOL bNext = FALSE;
	char * orgArgs = new char[strlen(args)+1];
	char * tmpArgs = orgArgs;
	strcpy(tmpArgs, args);
	if (StripWS(tmpArgs)){
		int n;
		if (!_strcmpi(tmpArgs, "next"))
			bNext = TRUE;
		else if (!_strcmpi(tmpArgs, "prev"))
			bNext = FALSE;
		else{
			delete [] orgArgs;
			tmpArgs = orgArgs = NULL;
			return;
		}
		if ((n = InWinList(curTask)) == 0){
			if ((n = GetTaskByWnd(curTask)) == -1){
				if ((n = InWinList(lockCurTask)) == 0)
					n = GetTaskByWnd(lockCurTask);
				else
					n -= 1;
			}
		}else
			n -= 1;

		if (bNext){
			if (n == -1 || ++n >= numTasks)
				n=0;
		}else{
			if (n == -1 || --n < 0)
				n = numTasks-1;
		}
		if (IsIconic(tasks[n].appHandle2)){
			SendMessage(tasks[n].appHandle2, WM_SYSCOMMAND, (WPARAM)SC_RESTORE, 0);
			SendMessage(parent, LM_BRINGTOFRONT, 0, (long)tasks[n].appHandle);
			SetForegroundWindow(GetLastActivePopup(tasks[n].appHandle2));
		}else{
			SendMessage(parent, LM_BRINGTOFRONT, 0, (long)tasks[n].appHandle);
			SetForegroundWindow(GetLastActivePopup(tasks[n].appHandle2));
		}
	}
	delete [] orgArgs;
	tmpArgs = orgArgs = NULL;
	return;
}

void TasksToggle(HWND hwnd, LPCSTR szArgs)
{
	UNREFERENCED_PARAMETER(hwnd);
	UNREFERENCED_PARAMETER(szArgs);

	for (int i=0;i<numTasks;i++){
		if (ts.StartHidden)
			ShowWindow(tasks[i].hwnd, SW_SHOWNOACTIVATE);
		else
			ShowWindow(tasks[i].hwnd, SW_HIDE);
	}
	ts.StartHidden = !ts.StartHidden;
	return;
}

void TasksDisplay(HWND caller, LPCSTR args)
{
	caller=caller;
	int i = 0x00; // going to perform bitwise operations on it.(actually on ts.Display)

	if (args != NULL && *args != 0 && strlen(args)){
		char * orgArgs = new char[strlen(args)+1];
		char * tmpArgs = orgArgs;
		strcpy(tmpArgs, args);
		if (StripWS(tmpArgs)){
			_strlwr(tmpArgs); // convert to lower case, since there is no 'strstr' case insensitive routine.
			if (strstr(tmpArgs, "all"))
				i = 0x0F;
			else{
				if (strstr(tmpArgs, "normal"))
					i |= 0x01;
				if (strstr(tmpArgs, "minimized"))
					i |= 0x02;
				if (strstr(tmpArgs, "selected"))
					i |= 0x04;
			}
			ts.Display = (i == 0x00) ? 0x0F:i;
		}else
			ts.Display = bkDisp;
		delete [] orgArgs;
		tmpArgs = orgArgs = NULL;
	}else
		ts.Display = bkDisp;
	return;
}

void TasksDockWindow(HWND caller, LPCSTR args)
{
	caller=caller;
	if (args != NULL && *args != 0 && strlen(args)){
		char * orgArgs = new char[strlen(args)+1];
		char * tmpArgs = orgArgs;
		char * ptr1 = NULL;
		char * ptr2 = NULL;
		HWND tmpWnd = NULL;
		strcpy(tmpArgs, args);
		if (StripWS(tmpArgs)){
			if (_strcmpi(tmpArgs, ".none") == 0)
				tmpWnd = NULL;
			else{
				ptr1 = strtok(tmpArgs, ";\"\'");
				ptr2 = strtok(NULL, ";\"\'");
				StripWS(ptr1);
				StripWS(ptr2);
				tmpWnd = (ptr1 != NULL && *ptr1 != 0 && strlen(ptr1)) ? FindWindow(ptr1, ptr2):ts.DockWindow;
				ptr1=ptr2=NULL;
			}
			if (tmpWnd != ts.DockWindow){
				for (int i=0;i<numTasks;i++){
					SetWindowLong(tasks[i].hwnd, GWL_STYLE, (GetWindowLong(tasks[i].hwnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
					SetParent(tasks[i].hwnd, tmpWnd);
					SetWindowLong(tasks[i].hwnd, GWL_STYLE, (GetWindowLong(tasks[i].hwnd, GWL_STYLE) &~ WS_CHILD)|WS_POPUP);
				}
				ts.DockWindow = tmpWnd;
			}
		}
		delete [] orgArgs;
		tmpArgs = orgArgs = NULL;
		tmpWnd = NULL;
	}
	return;
}

void TaskszOrder(HWND caller, LPCSTR args)
{
	caller=caller;
	if (args != NULL && *args != 0 && strlen(args)){
		char * orgArgs = new char[strlen(args)+1];
		char * tmpArgs = orgArgs;
		strcpy(tmpArgs, args);
		if (StripWS(tmpArgs)){
			if (_strcmpi(tmpArgs, "ontop") == 0){
				ts.zOrder = 2;
				for (int i=0;i<numTasks;i++)
					SetWindowPos(tasks[i].hwnd, HWND_TOPMOST,0,0,0,0,SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOSIZE|SWP_NOSENDCHANGING);
			}
			else if (_strcmpi(tmpArgs, "floating") == 0){
				ts.zOrder = 1;
				for (int i=0;i<numTasks;i++)
					SetWindowPos(tasks[i].hwnd, HWND_NOTOPMOST,0,0,0,0,SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOSIZE|SWP_NOSENDCHANGING);
			}
		}
		delete [] orgArgs;
		tmpArgs = orgArgs = NULL;
	}
	return;
}

void TasksMinimize(HWND hwnd, LPCSTR szArgs)
{
	UNREFERENCED_PARAMETER(hwnd);
	UNREFERENCED_PARAMETER(szArgs);

	for (int i=0;i<numTasks;i++)
		if (!IsIconic(tasks[i].appHandle2))
			SendMessage(tasks[i].appHandle2, WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE, 0);
	return;
}

void TasksMaximize(HWND hwnd, LPCSTR szArgs)
{
	UNREFERENCED_PARAMETER(hwnd);
	UNREFERENCED_PARAMETER(szArgs);

	for (int i=0;i<numTasks;i++)
		SendMessage(tasks[i].appHandle2, WM_SYSCOMMAND, (WPARAM)SC_MAXIMIZE, 0);
	return;
}

void TasksRestore(HWND hwnd, LPCSTR szArgs)
{
	UNREFERENCED_PARAMETER(hwnd);
	UNREFERENCED_PARAMETER(szArgs);

	for (int i=0;i<numTasks;i++)
		SendMessage(tasks[i].appHandle2, WM_SYSCOMMAND, (WPARAM)SC_RESTORE, 0);
	return;
}


//Primitive LsBox-Hook added by blkhawk

void TasksBoxHook(HWND caller, LPCTSTR szArgs)
{
  UNREFERENCED_PARAMETER(caller);

  char *handle = strrchr(szArgs,' ');
  if (handle) 
  {
	  HWND hWnd = (HWND)atoi(handle+1);
	  if (hWnd) 
	  {
		  if (hWnd != ts.DockWindow){
				for (int i=0;i<numTasks;i++){
					SetWindowLong(tasks[i].hwnd, GWL_STYLE, (GetWindowLong(tasks[i].hwnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
					SetParent(tasks[i].hwnd, hWnd);
					//SetWindowLong(tasks[i].hwnd, GWL_STYLE, (GetWindowLong(tasks[i].hwnd, GWL_STYLE) &~ WS_CHILD)|WS_POPUP);
				}
				ts.DockWindow = hWnd;
		  }
	  }
  }
	return;
}