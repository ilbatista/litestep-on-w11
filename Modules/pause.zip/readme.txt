created by maduin (http://maduin.dasoft.org/)

MindJunction idea # 43

Reason: this is a scripting module that has the ability to pause so that you can run a bang command, wait x amount of seconds and then run the next bang

Usage: !Pause x , where X is the number of milliseconds you want to pause.
