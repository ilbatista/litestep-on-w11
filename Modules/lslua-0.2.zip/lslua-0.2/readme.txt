example.lua is an example Lua script file. After loading the lslua module, you
can include this file by putting *LuaFile path\to\example.lua in your step.rc.
A few things to keep in mind:
1: For questions about Lua syntax, the manual is online at
   http://www.lua.org/manual/5.0/
2: lslua comes with a few (well, one right now) libraries that you can access
   by putting a 'require( "lib" )' line at the beginning of the script. For
   example, get access to the evar table by doing 'require( "vars" )'
3: Evars are accessed through the global 'ls' table. The keys for the table
   are the names of the evars (no $), and the values are objects that you can
   call toString(), toNumber(), or toBoolean() on. For example,
   ls.LiteStepDir:toString(), or ls.ResolutionX:toNumber(). (See the changelog
   for an explanation of the . vs : thing.)
4: Bang functions can take one string variable as an argument that contains
   everything passed to them on the command line. You are free to parse out
   arguments from that however you want, and hopefully there will be a
   tokenizing function available soon to make that easier
5: Any comments are more than welcome: I am doy on irc.freenode.net, and
   my email is doy <at> jjaro <dot> net.

Changes:
0.2:
- First public release
- Bangs can now use arguments
- exec now has the option of passing several arguments in that will be passed
  as arguments to the command. For examples, see example.lua
- Removed pause(), since it really can't work correctly without better core
  support.
- Moved loading of evar code out to Lua as well... 'require( "vars" )' to get
  it.

Private alphas:
-----------------
0.1.1:
- Changed evar access to use the global 'ls' table. Access evars now like
  'ls.LiteStepDir:toString()'. Yes, the first is a period, and the second is a
  colon. In Lua, ls.var is equivalent to ls[ "var" ], and var:func is
  equivalent to var.func( self ) (self is lua's equivalent of 'this' in c++; it
  refers to the current object). Evar saving is coming shortly(:
- message_box now takes two arguments, first being the messagebox text, and the
  second being the title of the messagebox.
- The source zip now comes with just the precompiled Lua libraries. If you
  care, you can get the Lua source from http://lua.org/ftp/.

0.1:
- Initial release.
