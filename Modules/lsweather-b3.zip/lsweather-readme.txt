//////////////////////////////////////
// LSWeather B3
// Written By: MrJukes
// Graphics By: [TheBORG]
// Released: 9/29/99
///////////////////////////

// What's New in B3?
- Added a favorites menu
- Fixed some bugs
- Moved weather conditions into the modules.ini instead of being hardcoded

// What's New in B2?
- Can be loaded as a LoadModule
- Got rid of messagebox warning that it could not connect to weather.com
- Images can be in any directory

// IMPORTANT!!
If you are going to run LSWeather as a LoadModule follow these steps:
1) Load into litestep as loadmodule
	It could possibly be looking funky right now so,
2) Edit the settings in modules.ini
3) Recycle

LoadModule mode does not allow the dialog boxes to edit the preferences because it did some weird stuff.

// Installation
1) Put all the .bmp's into your litestep images folder (ie c:\litestep\images)
2) Put a line like this in your step.rc:
	*Wharf LSWeather c:\litestep\images\lsweather.bmp @c:\litestep\lsweather.app
   or for a loadmodule
	LoadModule c:\litestep\lsweather.app
3) Save & Recycle

// Usage
- LSWeather can either use your zip code or a specific page located on weather.com
- To find out your specific page, visit weather.com and type in your city.
- Then look at the URL and copy the file and paste it into LSWeather.
- It will be of the form country_state_city.html (ie us_in_lafayette.html)

// Popup
Update - Checks weather.com for the latest temperature and weather conditions
Active - Toggles whether LSWeather checks the current conditions on a timer
Change Settings - Changes your settings
Change Location - Changes your zip code or city
About LSWeather - The about box
Use Zip Code - Uses the specified zip code
Use City - Uses the specified city file
Farenheit / Celcius / Kelvin - Check which one you want your temperature reported in

// Example modules.ini section
[LSWeather]
// Your zipcode
ZipCode=47906

// These are screen coordinates for loadmodule mode
XPos=226
YPos=5

// Show weather conditions (1=True, 0=False)
WC=1

// Coordinates where the text is located
TextX=12
TextY=28

// Timer in ms for how often to update. (60000 = 60 seconds)
Timer=60000

// The RGB of the normal text
R=34
G=178
B=195

// The RGB of the text while updating from weather.com
CR=0
CG=100
CB=125

// The height, width, and name of the font
FontHeight=15
FontWidth=0
FontName=Arial

// There can be 25 states total
// The part to the right is what it matches with weather.com
// Each state can have 4 different bmps
// 1) Normal (lsweather_cloudy.bmp)
// 2) Mostly (lsweather_mcloudy.bmp)
// 3) Partly (lsweather_pcloudy.bmp)
// 4) Night (lsweather_cloudy_night.bmp)

State0=Sunny
StateBmp0=lsweather_sunny.bmp

State1=Cloudy
StateBmp1=lsweather_cloudy.bmp
StateMostlyBmp1=lsweather_cloudy.bmp
StatePartlyBmp1=lsweather_pcloudy.bmp
StateNightBmp1=lsweather_cloudy_night.bmp

State2=Rain
StateBmp2=lsweather_rain.bmp

State3=Fog
StateBmp3=lsweather_cloudy.bmp

State4=Snow
StateBmp4=lsweather_snow.bmp
StateNightBmp4=lsweather_snow_night.bmp

State5=Clear
StateBmp5=lsweather_sunny.bmp
StateNightBmp5=lsweather_night.bmp

// This toggles whether to use the zip code or the city file
UseZip=1

// This is the city specific file as given by the url from weather.com
File=us_il_northbrook.html

// You can have 10 favorites
// This one is what you see in the popup menu
Favorite0=Lafayette
// This is the zipcode
FavoriteZip0=47906
// This is the city specific file
FavoriteFile0=us_in_lafayette.html

Favorite1=Northbrook
FavoriteZip1=60062
FavoriteFile1=us_il_northbrook.html

Favorite2=Lake Bluff
FavoriteZip2=60044
FavoriteFile2=us_il_lake_bluff.html
=================================================

That's about it. E-mail me at mrjukes@purdue.edu if you have any questions.

Have fun,
	MrJukes