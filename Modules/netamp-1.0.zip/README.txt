<<<<<<<<<<------------------------
			NETAmp v.1
			Jack Lange ; jarusl@artifex.org
			http://www.artifex.org/~jaursl/netamp
<<<<<<<<<<------------------------

1. Introduction
2. Installation
3. step.rc
4. Client Interface
5. Server Interface



<<<<<<<<<<------------------------
			Introduction

NETAmp is a litestep module that provides a way for winamp to be controlled over a network.
Its basically Geekamp except the controlling computer and the mp3 playing computer are 
separate, but connected by a network. The module can act like both the controller and 
the server depending on configuration.


<<<<<<<<<<------------------------
			Installation

To install NETAmp, simply unzip netamp.dll into your modules directory and add a line to 
step.rc like the following: 

LoadModule "$ModDir$netamp.dll"

Then recycle Litestep, or restart your computer.

<<<<<<<<<<------------------------
			Step.rc

NETAmp takes four configuration parameters at this time.

NetampMode <client | server | both>

	This line specifies the mode NETAmp will run as. 
	
	client -- the machine acts as the controller and does not start a 
	listening server. Only the controlling bang commands are created. 
	
	Server -- the machine listens for network connections. The controlling bang commands
	are not enabled.

	Both -- the machine acts as both the client and the server. The controlling bang commands
	are enabled, and it listens for incoming connections.

NetampPort <portnum>
	
	This specifies the port number that the server will listen on and the client will 
	connect to. If not specified will default to "4242".

WinAmpPath <path to winamp>
	
	Used if NetampMode is set to "server" or "both". Defines location of winamp executable.
	If not specified will default to "c:\\progra~1\\winamp\\winamp.exe"

NetampServer <IP | Hostname>

	Used if NetampMode is set to "client" or "both". Specifies the IP address of the machine
	which the client will try to contact. Can be specified as a numeric IP address, or a 
	hostname. If not specified will default to "127.0.0.1".

<<<<<<<<<<------------------------
			Client Interface

The client interface consists of a set of bang commands that are enabled. They're pretty self 
explanatory.

!NETAMP_PLAY
!NETAMP_PAUSE
!NETAMP_STOP
!NETAMP_NEXT
!NETAMP_PREV
!NETAMP_VOLUMEUP
!NETAMP_VOLUMEDOWN
!NETAMP_LISTSTART   -- Skips to the beginning of the playlist
!NETAMP_LISTEND		-- Skips to the end of the playlist
!NETAMP_POWER		-- Turns winamp on/off
!NETAMP_REPEAT		-- Toggles repeat setting
!NETAMP_SHUFFLE		-- Shuffles the playlist

To take advantage of the geekamp interface provided by certain themes, just replace the
geekamp commands with these where the shortcuts are defined.

<<<<<<<<<<------------------------
			Server Interface

Basically just telnet to the server and port and type "help". The screen should look like this:

NETAMP V.1 Commands:
                Power                           --Turns Winamp Off/On
                Current                         --Displays the Current Song playing
                Play                            --Plays songs in playlist
                Stop                            --Stops playing song
                Pause                           --Pauses Winamp
                Repeat                          --Toggles Repeat Setting
                Shuffle                         --Shuffles the playlist
                List <start|end>                --Starts playing at the beginning/end of playlist
                Volume <up|down>                --Turns up/down the volume
                Prev                            --Goes back to previous song in playlist
                Next                            --Skips to next song in playlist
                Quit                            --Exits interface


<<<<<<<<<<------------------------

So that should do it. Currently the controls are somewhat limited, but if you would like to 
have more included please just email and ask. I really didn't see the need to be able to 
popup the playlist window on a machine that was in a different room. Future revisions hopefully
will include the ability to edit the playlist, and load different playlists. 
Anyway. Questions and comments would be appreciated

Thanks to Geekamp, whose code I shamelessly copied.

Jack Lange ; jarusl@artifex.org
http://www.artifex.org/~jarusl