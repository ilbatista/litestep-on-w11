xStatsGraph by thegeek.

----Introduction----

Hi, this is a small graphing module I put together to replace rainmeter.
At the moment it is very basic, but it's under development;P
It uses perfmon counters or xstatsclass to gather data, so you can graph pretty much anything;P
I hope to add more rendering modes later, and I am very open to suggestions/requests:)
Since this module is under heavy development please report any bugs.

----Capabilities----

I use the excellent xpaintclass by andymon, so the graphics for the "background layer" has full support for xpaintclass settings.
The graph itself is rendered ontop of this background, at the moment you can set color and alpha for both the graph "fill" and outer "stroke".
This is a basic example to illustrate a cpu graph:


*xStatsGraph test
testX 0
testY 0
testWidth 200
testHeight 22
testPaintingMode .image
testImage horizontalbar_2.png
testMeterX 0
testMeterY 0
testMeterHeight 18
testMeterWidth 200

testMeterRefreshRate 200
testMeterRenderMode FillAndStroke
testMeterFillAlpha 50
testMeterFillColor 555555
testMeterStrokeAlpha 230
testMeterStrokeColor 555555
testMeterScale 100
;testMeterSource perfmon
;testMeterSourceString "\Processor(_Total)\% Processor Time"
MeterSource xstatsclass
MeterSourceString "[cpu]"



The first part of these are very basic xpaintclass settings.
If you do not understand any of these settings and they are not explained below, please consult the xpaintclass help.
The settings that are new / are not basic xpaintclass are these:

MeterRenderMode
This allows you to set the rendering mode, available modes are: StrokeOnly, FillOnly and FillAndStroke

MeterSource
This setting allows you to choose between xpaintclass and the built-in perfmon code to use for data collection. 
Xpaintclass is a lot easier to use, but perfmon gives you greater freedom and maybe less overhead.

MeterSourceString 
Tis setting is what you use to define the string that either xpaintclass or perfmon uses to gather the data.
For xpaintclass this is pretty easy, and if you are wondering what possibilities you have consult xpaintclass docs.
For perfmon this is a bit harder, if you have trouble formatting this string correctly use the !xStatsGraphShowPerformancePicker bang to get a dialog that allows you to select among all counters. After you have selected the counter you want, click ok and the correct string will be copied to your clipboard.
The default setting is for english windows, if you have another language you will have to change it.


MeterRefreshRate 200
This setting allows you to set the milliseconds between each update, lower bound is 50.
If you use xpaintclass you need to set xStatsCpuStatsUpdateInterval  to the same or lower in order for it to work.

MeterScale 100
This allows you to set the (vertical) scale of the graph.


----Bangs----
!xStatsGraphCreate 		"name"
!xStatsGraphDestroy 		"name"
!xStatsGraphAlwaysOnTop 	"name"
!xStatsGraphHook 		"name"
!xStatsGraphHide 		"name"
!xStatsGraphMove 		"name" 
!xStatsGraphMoveBy 		"name"
!xStatsGraphReposition 		"name"
!xStatsGraphRepositionBy 	"name"
!xStatsGraphResize 		"name"
!xStatsGraphResizeBy 		"name"
!xStatsGraphShow 		"name"
!xStatsGraphToggle 		"name"
!xStatsGraphShowPerformancePicker


----Release History----

--0.4
New rendering modes (StrokeOnly, FillOnly and FillAndStroke), different color and alpha settings for stroke and fill.
All rendering is now done through the agg2d abstraction layer for agg (anti-grain geometry), this means it is _much_ easier to code the rendering.

--0.31
Adds support for hookin

--0.3
This release adds support for xpaintclass. 
Also renamed some of the settings for consistency.
Make sure that if you are going to use xpaintclass to set xStatsCpuStatsUpdateInterval to the same as (or lower than) your refreshrate.

--0.2
First public release

--0.1
First alpha.





----Contact----

I am thegeek on efnet and freenode (irc).
You can also reach me by email to okrog@online.no

