scrsaver.dll 1.3
Screen saver and screen power-off controlling bangs
---------------------------------------------------------

Bangs:

!ScreenSaver [optional delay in ms]
	Issue screen saver. Optionally after timeout. It is handy
	when running this bang with a hotkey.

!ScreenSaverEnable
	Enable screen saver.

!ScreenSaverDisable
	Disable screen saver.

!ScreenSaverToggle
	Toggle screen saver on/off.

!ScreenSaverStop
	Stop already running screen saver.

!ScreenPowerOffEnable
	Enable screen power-off.

!ScreenPowerOffDisable
	Disable screen power-off.

!ScreenPowerOffToggle,
	Toggle screen power-off. If disabled in display control panel,
	it will be enabled.

!ScreenPowerOffTimeout [minutes]
	Sets timeout in minutes of screen power-off. Setting to 0 means
	'never'.

!ScreenSaverAndPowerOffEnable
	Enable screen saver and screen power-off at once. If you have
	disabled power-off feature in control panel and
	!ScreenSaverAndPowerOffDisable has been issued before, this
	bang will not enable it.

!ScreenSaverAndPowerOffDisable
	Temporarily disable screen saver and screen power-off at once

!ScreenSaverAndPowerOffToggle
	Temporarily toggle screen saver and screen power-off at once

What means "temporarily" here? If you have disabled screen-power
off feature in control panel, calling !ScreenSaverAndPowerOffToggle
or !ScreenSaverAndPowerOffEnable will *not* re-enable it.
It will be re-enabled only if it has been enabled in control panel
already before issuing !ScreenSaverAndPowerOffDisable or
!ScreenSaverAndPowerOffToggle

--------------------------------------------------------
mailto: pavel.vitis@seznam.cz
www   : http://floach.pimpin.net/pavel/
