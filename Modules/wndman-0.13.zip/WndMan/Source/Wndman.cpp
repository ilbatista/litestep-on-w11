/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************

WndMan (0.13):
by Vendicator

WndMan, short for Window Manager.
The module is intended to provide useful utility functins for handling windows
Currently a lot of the commands are untested.

Bang %argument%
	WndMan can try to find the target window to work on depending on the given argument:
	%point% - Bang will work on the window beneath the mouse pointer
	%active% - Bang will work on the active window (foreground)
	Other - WndMan assumes that the argument is a window class and looks for it
	Default: foreground window

Bangs:

Basic Window Handling:
	!WndForeground %argument%
	Sets the window to foreground

	!WndPushBottom %argument% [untested]
	Pushes the window down to the bottom closes to desktop

	!WndPushBack %argument% [untested]
	Pushes the window back one step

	!WndOnTop %argument% ("on"/"true")
	Sets the window status to be on top if argument is "on" or "true" otherwise it'll be set to normal

	!WndHide %argument%
	Hides the window

	!WndRestore %argument%
	Restores a window from being hidden

	!WndMaxToggle %argument%
	Toggles a window between maximized/normal view

	!WndMaximize %argument%
	Maximizes a window

	!WndMinimize %argument%
	Minimizes a window

	!WndClose %argument%
	Closes a window

	!WndDestroy %argument% [untested]
	Destroys a window, use at own risk

	!WndSetOpacity %argument% (Int: 0-255)
	Sets the opacity of the window, range 0-255. Win2k/Xp only

	!WndInfo %argument%
	Displays a messagebox with various info on a window, also ouputted to log file

	!WndAllInfo %argument%
	Same as !WndInfo but applied to active, foreground and focused window (to check difference)

Changing Size of Windows:
	!WndShade %argument%
	Shades a window, only showing it's titlebar

	!WndToggleShade %argument%
	Toggles a window between shaded state and normal size

	!WndUnShade %argument%
	Unshades the window

	!WndUnShadeAll
	Unshades all windows that have the shaded

	!WndToggleShade %argument%
	Toggles shading the window.

	!WndSize %argument% x y
	Sets the new size of the window to x y (old width or height is kept if that size is set to 0)

	!WndSizeGrow %argument% x y
	Grows the size of the window by x, y (old width or height is kept if that grow amount is set to 0)

	!WndSizeMax %argument% x y [untested]
	Sets the size of the dimension to biggest that the resolution can show
	(ie. 1 0 would mean that the window would be as wide as possible)

Moving Windows:
	!WndMove %argument% x y
	Moves the window to position x, y (old x or y position is kept if that is set to 0)

	!WndMoveDelta %argument% x y
	Moves the window by x y  (old x or y position is kept if that is set to 0)

	!WndMoveHome %argument% [untested]
	Asks Windows where the window should be and moves it there

	!WndMoveCenter %argument% [untested]
	Centers the window on the screen

Traying:
	!WndSendToTray %argument%
	Minimizes the window to tray, clicking it's icon will restore it again

	!WndRestoreFromTray %argument%
	Restores the window from being in the tray

	!WndRestoreAllFromTray
	Restores all icons that have been minimized to tray


Changelog:

- Added [WndMan / repugnant, Vendicator / 2003-02-07, release: 0.13]
  - Added !WndToggleShade made by repugnant
  - Fixed bug with saved window size not being removed when window is unshaded
    (needed otherwise the restored size can't be changed and needed for shade toggle)

- Changed [WndMan / Vendicator / 2003-02-05, release: 0.12]
  - WndMan now restores all tasks from tray before closing, otherwise the tasks
    wouldn't restorable, since the icons still refer to the old WndMan window
  - Added !WndRestoreFromTray and !WndRestoreAllFromTray

- Fixed [WndMan / Vendicator / 2003-02-05, release: 0.11]
  - Tested and fixed shading/unshading windows
  - Removed some logging left from early development
  - Renamed previous !WndClose to !WndDestroy, and made a new implementation of !WndClose
  - Added !WndUnshadeAll to restore previously shaded windows

- Fixed [WndMan / Vendicator / 2003-02-03, release: 0.1]
  - Fixed tray minimization & restore

- Added [WndMan / Vendicator / 2002-07-22]
  - Added options %active% and %point% to commands to get active window or window from mouse point location.

- Added [WndMan / Vendicator / 2002-06-10]
  - Added !WndClose to close a window.
  - Worked more on systray minimization, needs unique uID's & track HWND's that have been minimized

- Added [WndMan / Vendicator / 2002-06-09]
  - Added Minimizing to tray, tho not possible to restore yet.
  - Added !bangs for sizing and moving

- Added [WndMan / Vendicator / 2002-06-08]
  - Added WndSize() & WndMove()

- Modified [WndMan / Vendicator / 2002-06-02]
  - Restructured WindowInfo()

- Modified [WndMan / Vendicator / 2002-06-02]
  - Moved code section for finding window on args or active window to a function.

- Added [WndMan / Vendicator / 2002-06-02]
  - Can now specify window classname in all !bang commands (set first)
  - Fixes to Opacity setting handlers.

- Added [WndMan / Vendicator / 2002-06-01]
  - Added Opacity setting (thanks MickeM).
  - Added some more stuff... don't remember

- Start [WndMan / Vendicator 2002-05-31]
  - Started working on WndMan - Window Manager, basic window commands added


To Do:

  - Test moving & sizing (multimon too)
  - SetThreadPriority, GetThreadFromWindow?
  - Change window titles?
  - Linking windows to move together, specify parent / child.
  - Docking windows together.
  - Remaximize windows on recycle (if desktop area changes, so windows look right after recycle)
  - Intercept new HWNDs? hook into windows.
  - Window startup animations? (alpha 0->255)
  - Info: find process name from HWND, exe
  - Colors (GetSysColor, set...)
  - Get sizes GetSystemMetrics, GetTitleBarInfo, GetWindowInfo, GetClientRect
  - Set animation AnimateWindow, toggles of animation
  - Keep internal window list? hooks?
  - placement on different desks?
  - groups?
  - step.rc settings, detect of windows for everything
  - x tracking, set forground window automatically to window under point?
  - dialog pos, per windows?


****************************************************************************/

#include "Wndman.h"
const char szAppName[] = "WndMan"; // Our window class, etc
const char rcsRevision[] = "$Revision: 0.13 $"; // Our Version
const char rcsId[] = "$Id: WndMan.cpp,v 0.13 23:47:23 Vendicator Exp $"; // The Full RCS ID.
Wndman *wndman; // The module

// name of shelldesktop class
#define WC_SHELLDESKTOP    "DesktopBackgroundClass"

#define ACTIVE_WINDOW 1
#define FOREGROUND_WINDOW 2
#define FOCUS_WINDOW 3

#define MAX_LINE_LENGTH 4096

// for alpha trans
#define WS_EX_LAYERED           0x00080000
#define LWA_COLORKEY            0x00000001
#define LWA_ALPHA               0x00000002

// size properties:
#define SIZE_DELTA		101
#define SIZE_SET		102
#define SIZE_SHADE		103
#define SIZE_UNSHADE	104
#define SIZE_MAX		105

// move properties:
#define MOVE_DELTA		201
#define MOVE_SET		202
#define MOVE_HOME		203
#define MOVE_CENTER		204

#define WM_ICON_NOTIFY	WM_USER+10

//#define DEBUG

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	wndman = new Wndman(ParentWnd, code);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
  delete wndman;
}


//=========================================================
// Bang commands
//=========================================================

void BangWndForeground(HWND caller, LPCSTR args) {
	wndman->WindowForeground(wndman->getHWNDhelper(args));
}

void BangWndPushBottom(HWND caller, LPCSTR args) {
	wndman->WindowPushBottom(wndman->getHWNDhelper(args));
}

void BangWndPushBack(HWND caller, LPCSTR args) {
	wndman->WindowPushBack(wndman->getHWNDhelper(args));
}

void BangWndSetOpacity(HWND caller, LPCSTR args) {
	wndman->WindowSetOpacity(args);
}

void BangWndOnTop(HWND caller, LPCSTR args) {
	wndman->WindowOnTop(caller, args);
}

void BangWndHide(HWND caller, LPCSTR args) {
	wndman->WindowHide(wndman->getHWNDhelper(args));
}

void BangWndRestore(HWND caller, LPCSTR args) {
	wndman->WindowRestore(wndman->getHWNDhelper(args));
}

void BangWndMaxToggle(HWND caller, LPCSTR args) {
	wndman->WindowMaxToggle(wndman->getHWNDhelper(args));
}

void BangWndMaximize(HWND caller, LPCSTR args) {
	wndman->WindowMaximize(wndman->getHWNDhelper(args));
}

void BangWndMinimize(HWND caller, LPCSTR args) {
	wndman->WindowMinimize(wndman->getHWNDhelper(args));
}

void BangWndDestroy(HWND caller, LPCSTR args) {
	wndman->WindowDestroy(wndman->getHWNDhelper(args));
}

void BangWndClose(HWND caller, LPCSTR args) {
	wndman->WindowClose(wndman->getHWNDhelper(args));
}

// info
void BangWndInfo(HWND caller, LPCSTR args) {
	wndman->WindowInfo(wndman->getHWNDhelper(args), TRUE);
}

void BangWndAllInfo(HWND caller, LPCSTR args) {
	wndman->WindowAllInfo(caller, args);
}

// sizing (shade)
void BangWndShade(HWND caller, LPCSTR args) {
	wndman->WndSize(wndman->getHWNDhelper(args), SIZE_SHADE, 0, 0);
}

void BangWndUnShade(HWND caller, LPCSTR args) {
	wndman->WndSize(wndman->getHWNDhelper(args), SIZE_UNSHADE, 0, 0);
}

void BangUnShadeAll(HWND caller, LPCSTR args) {
	wndman->UnShadeAll();
}

void BangWndToggleShade(HWND caller, LPCTSTR args) {
	HWND hwnd = wndman->getHWNDhelper(args);

	if ( wndman->IsWindowShaded(hwnd) ) {
		wndman->WndSize(hwnd, SIZE_UNSHADE, 0, 0);
	} else {
		wndman->WndSize(hwnd, SIZE_SHADE, 0, 0);
	}
}

// sizing
void BangWndSize(HWND caller, LPCSTR args) {
	int x=0, y=0;
	HWND window;
	if ( wndman->returnHWNDAndCoords(&window, &x, &y, args) )
		wndman->WndSize(window, SIZE_SET, x, y);
}

void BangWndSizeGrow(HWND caller, LPCSTR args) {
	int x=0, y=0;
	HWND window;
	if ( wndman->returnHWNDAndCoords(&window, &x, &y, args) )
		wndman->WndSize(window, SIZE_DELTA, x, y);
}

void BangWndSizeMax(HWND caller, LPCSTR args) {
	int x=0, y=0;
	HWND window;
	if ( wndman->returnHWNDAndCoords(&window, &x, &y, args) )
		wndman->WndSize(window, SIZE_MAX, x, y);
}

// moving
void BangWndMoveHome(HWND caller, LPCSTR args) {
	wndman->WndSize(wndman->getHWNDhelper(args), MOVE_HOME, 0, 0);
}

void BangWndMoveCenter(HWND caller, LPCSTR args) {
	wndman->WndSize(wndman->getHWNDhelper(args), MOVE_CENTER, 0, 0);
}

void BangWndMove(HWND caller, LPCSTR args) {
	int x=0, y=0;
	HWND window;
	if ( wndman->returnHWNDAndCoords(&window, &x, &y, args) )
		wndman->WndPos(window, MOVE_SET, x, y);
}

void BangWndMoveDelta(HWND caller, LPCSTR args) {
	int x=0, y=0;
	HWND window;
	if ( wndman->returnHWNDAndCoords(&window, &x, &y, args) )
		wndman->WndPos(window, MOVE_DELTA, x, y);
}

// traying
void BangSendToTray(HWND caller, LPCSTR args) {
	HWND min_wnd = wndman->getHWNDhelper(args);
	wndman->TraySend(min_wnd);
}

void BangRestoreFromTray(HWND caller, LPCSTR args) {
	HWND min_wnd = wndman->getHWNDhelper(args);
	wndman->TrayRestore(min_wnd);
}

void BangRestoreAllFromTray(HWND caller, LPCSTR args) {
	wndman->TrayRestoreAll();
}

//=========================================================
// Module code
//=========================================================

HWND Wndman::getTargetHWND(int window_code) {
	HWND desktop;
	HWND TargetHWND;
	if (window_code == ACTIVE_WINDOW)
		TargetHWND = GetActiveWindow();
	if (window_code == FOREGROUND_WINDOW)
		TargetHWND = GetForegroundWindow();
	if (window_code == FOCUS_WINDOW)
		TargetHWND = GetFocus();

	desktop = FindWindow(WC_SHELLDESKTOP, NULL);
	if (!desktop)
		desktop = GetDesktopWindow();

	if (TargetHWND != GetLitestepWnd() && TargetHWND != desktop)
		return TargetHWND;
	else
		return NULL;	
}

HWND Wndman::getActiveHWND(void) {
	return getTargetHWND(ACTIVE_WINDOW);
}

HWND Wndman::getForegroundHWND(void) {
	return getTargetHWND(FOREGROUND_WINDOW);
}

HWND Wndman::getFocusHWND(void) {
	return getTargetHWND(FOCUS_WINDOW);
}

HWND Wndman::getHWNDBelow(HWND window) {
	HWND below = GetNextWindow(window, GW_HWNDNEXT);
	// pass through all tooltip windows
	while( isToolTipHWND(below) ) {
		below = GetNextWindow(below, GW_HWNDNEXT);
	}
	return below;
}

HWND Wndman::getHWNDAbove(HWND window)
{
	HWND above = GetNextWindow(window, GW_HWNDPREV);
	// pass through all tooltip windows
	while( isToolTipHWND(above) ) {
		above = GetNextWindow(above, GW_HWNDPREV);
	}
	return above;

}

HWND Wndman::getHWNDhelper(LPCSTR args) {
	HWND window;
	if (*args != NULL)
	{
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "Argument: %s", args);
#endif
		if (strnicmp(args, "%active%", 8) == 0)
			window = getForegroundHWND();
		else if (strnicmp(args, "%point%", 7) == 0)
		{
#ifdef DEBUG
			LSLog(LOG_DEBUG, szAppName, "Checking point");
#endif
			POINT Point;
			GetCursorPos(&Point);
			window = WindowFromPoint(Point);
		}
		else
		{
			// if specified name take that window
			window = FindWindow(args, NULL);
		}
	}
	else {  // else foreground
		window = getForegroundHWND();
	}
	return window;
}

char *Wndman::isToolTipHWND(HWND window) {
	// use GetWindowInfo?
	char name[64];
	GetClassName(window, name, sizeof(name)/sizeof(name[0]) );
	return strstr(name, "tooltip");
}

void Wndman::setHWNDAcceptAlpha(HWND window) {
	SetWindowLong(window, GWL_EXSTYLE, WS_EX_LAYERED);
}

void Wndman::setHWNDNoAlpha(HWND window) {
	SetWindowLong(window, GWL_EXSTYLE, NULL);
}

void Wndman::hideHWNDVWM(HWND window) {
	SetWindowLong(window, GWL_USERDATA, magicDWord);
}

void Wndman::setHWNDAlpha(HWND window, int alpha) {
	if (alpha < 0)
		alpha = 0;
	if (alpha > 255)
		alpha = 255;
	
	FARPROC (__stdcall *SetLayeredWindowAttributes)(HWND, COLORREF, BYTE, DWORD);
	SetLayeredWindowAttributes = (FARPROC (__stdcall *) (HWND, COLORREF, BYTE, DWORD)) GetProcAddress(GetModuleHandle("USER32.DLL"), "SetLayeredWindowAttributes");
	
	if (SetLayeredWindowAttributes != NULL) {
		SetLayeredWindowAttributes(window, NULL, (BYTE)alpha, LWA_ALPHA); //LWA_ALPHA
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "Setting trans: %d", alpha);
#endif
	}
	else {
		LSLog(LOG_NOTICE, szAppName, "didn't find SetLayeredWindowAttributes() from user32.dll, requires Win2k, XP or later");
	}
	if (alpha == 255) {
		setHWNDNoAlpha(window);
	}
	
	//SetLayeredWindowAttributes(window, NULL, (BYTE)alpha, NULL);
}

int Wndman::getHWNDAlpha(HWND window) {
	BYTE alpha=NULL;

	FARPROC (__stdcall *GetLayeredWindowAttributes)(HWND, COLORREF*, BYTE*, DWORD*);
	GetLayeredWindowAttributes = (FARPROC (__stdcall *) (HWND, COLORREF*, BYTE*, DWORD*)) GetProcAddress(GetModuleHandle("USER32.DLL"), "GetLayeredWindowAttributes");

	if (GetLayeredWindowAttributes != NULL) {
		if ( GetLayeredWindowAttributes(window, NULL, &alpha, NULL) ) { //LWA_ALPHA
#ifdef DEBUG
			LSLogPrintf(LOG_DEBUG, szAppName, "Getting trans: %d", alpha);
#endif
		}
		else {
#ifdef DEBUG
			LSLog(LOG_DEBUG, szAppName, "Didn't find trans");
#endif
		}
		return (int)(alpha);
	}
	else {
		LSLog(LOG_NOTICE, szAppName, "didn't find GetLayeredWindowAttributes() from user32.dll, requires Win2k, XP or later");
		return -1;
	}
	//GetLayeredWindowAttributes(window, NULL, &alpha, LWA_ALPHA);
}

BOOL Wndman::returnHWNDAndCoords(HWND *window, int *x, int *y, LPCSTR args) {
	int count = 0;

	char token1[MAX_LINE_LENGTH], token2[MAX_LINE_LENGTH], token3[MAX_LINE_LENGTH], extra[MAX_LINE_LENGTH];
	char *tokens[3] = {token1, token2, token3};
	
	token1[0] = token2[0] = token3[0] = extra[0] = NULL;
	count = LCTokenize (args, tokens, 3, extra);

	if (count == 3)
	{
		*window = FindWindow(token1, NULL);
	}
	else
	{
		*window = getForegroundHWND();
	}
	*x = atoi(tokens[count-2]);
	*y = atoi(tokens[count-1]);

	if (*window != NULL)
	{
		return true;
	}
	else if (count == 3)
	{
		LSLogPrintf(LOG_NOTICE, szAppName, "no window found: %s", token1);
	}
	return false;
}

BOOL Wndman::IsWindowShaded(HWND window)
{
	map<HWND, RECT>::iterator theIter;
	theIter = shadedWindows.find(window);
	if ( theIter == shadedWindows.end() )
		return FALSE;

	return TRUE;
}
void Wndman::WndSize(HWND window, const int sizeProp, int x, int y)
{
	RECT orgRc;
	GetWindowRect(window, &orgRc);

	// first set to original size
	int newX = orgRc.right-orgRc.left;
	int newY = orgRc.bottom-orgRc.top;
	int posX = orgRc.left;
	int posY = orgRc.top;

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "Window: %x, current dim x:%d y:%d w:%d h:%d", window, posX, posY, newX, newY);
#endif

	// increase size with delta if set
	if (sizeProp == SIZE_DELTA)
	{
		newX += x;
		newY += y;
	}
	// else change size of either dim if different from 0
	else if (sizeProp == SIZE_SET)
	{
		if (x) newX = x;
		if (y) newY = y;
	}
	else if (sizeProp == SIZE_SHADE)
	{
		TITLEBARINFO titlebar;
		titlebar.cbSize = sizeof(TITLEBARINFO);
		GetTitleBarInfo(window, &titlebar);

		shadedWindows.insert(pair<HWND, RECT>(window, orgRc));

		//newX = titlebar.rcTitleBar.right-titlebar.rcTitleBar.left;
		// only necessary to update the y size
		newY = titlebar.rcTitleBar.bottom-titlebar.rcTitleBar.top;
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "Shading window: %x to %d", window, newY);
#endif
	}
	else if (sizeProp == SIZE_UNSHADE)
	{
		/*WINDOWPLACEMENT place;
		place.length = sizeof(WINDOWPLACEMENT);
		GetWindowPlacement(window, &place);
		newX = place.rcNormalPosition.right-place.rcNormalPosition.left;
		newY = place.rcNormalPosition.bottom-place.rcNormalPosition.top;*/

		// check for the existance in map first?
		RECT temp = shadedWindows[window];
		newY = temp.bottom-temp.top;
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "shaded windows: %d", shadedWindows.size());
#endif
		//shadedWindows.
		shadedWindows.erase(window);
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "Unshading window: %x to %d, still shaded: %d", window, newY, shadedWindows.size());
#endif
	}
	else if (sizeProp == SIZE_MAX)
	{
		MONITORINFO monInfo;
		HMONITOR monitor;
		monitor = MonitorFromRect(&orgRc, MONITOR_DEFAULTTONEAREST);
		monInfo.cbSize = sizeof(MONITORINFO);
		GetMonitorInfo(monitor, &monInfo);
		if (x) {
			newX = monInfo.rcWork.right  - monInfo.rcWork.left;
			posX = 0;
		}
		if (y) {
			newY = monInfo.rcWork.bottom - monInfo.rcWork.top;
			posY = 0;
		}
	}

	// set size with safegaurd against neg. sizes

	if ( sizeProp == SIZE_MAX && (x || y) )
		SetWindowPos(window, NULL, posX, posY, max(newX, 0), max(newY, 0), SWP_NOZORDER | SWP_NOACTIVATE);
	else
		SetWindowPos(window, NULL, 0, 0, max(newX, 0), max(newY, 0), SWP_NOZORDER | SWP_NOMOVE | SWP_NOACTIVATE);
}

void Wndman::UnShadeAll()
{
	map<HWND, RECT>::iterator i;
	int y;
	for (i=shadedWindows.begin(); i!=shadedWindows.end(); i++)
	{
		y = (i->second).bottom - (i->second).top;
		WndSize(i->first, SIZE_SET, 0, y);
	}
	shadedWindows.clear();
}

void Wndman::WndPos(HWND window, const int moveProp, int x, int y)
{
	RECT orgRc;
	GetWindowRect(window, &orgRc);

	// first set to original size
	int newX = orgRc.left;
	int newY = orgRc.top;

	// increase size with delta if set
	if (moveProp == MOVE_DELTA)
	{
		newX += x;
		newY += y;
	}
	// else change size of either dim if different from 0
	else if (moveProp == MOVE_SET)
	{
		if (x) newX = x;
		if (y) newY = y;
	}
	else if (moveProp == MOVE_HOME)
	{
		WINDOWPLACEMENT place;
		place.length = sizeof(WINDOWPLACEMENT);
		GetWindowPlacement(window, &place);
		newX = place.rcNormalPosition.left;
		newY = place.rcNormalPosition.top;
	}
	else if (moveProp == MOVE_CENTER)
	{
		MONITORINFO monInfo;
		HMONITOR monitor;
		monitor = MonitorFromRect(&orgRc, MONITOR_DEFAULTTONEAREST);
		monInfo.cbSize = sizeof(MONITORINFO);
		GetMonitorInfo(monitor, &monInfo);
		newX = monInfo.rcWork.left + (monInfo.rcWork.right  - monInfo.rcWork.left - (orgRc.right+orgRc.left) ) / 2;
		newY = monInfo.rcWork.top  + (monInfo.rcWork.bottom - monInfo.rcWork.top  - (orgRc.bottom+orgRc.top) ) / 2;
	}
	// set size with safegaurd against neg. sizes
	SetWindowPos(window, NULL, max(newX, 0), max(newY, 0), 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
}

void Wndman::WindowInfo(HWND window, BOOL alert) {
	char name[50];
	char handle[50];
	char alphaString[10];
	int alpha = -1;

	TCHAR path[128]; // char
	memset(path, 0, sizeof(path)/sizeof(path[0]) );
	char msg[256];
	memset(msg, 0, sizeof(msg)/sizeof(msg[0]) );

	if (window) {
		HINSTANCE hInstance = (HINSTANCE) GetWindowLong(window, GWL_HINSTANCE);
		GetModuleFileName(hInstance, path, sizeof(path)/sizeof(path[0]));

		GetClassName(window, name, sizeof(name)/sizeof(name[0]) );
		//GetWindowModuleFileName(window, path, sizeof(path)/sizeof(path[0]) );
		alpha = getHWNDAlpha(window);
		LSLogPrintf(LOG_NOTICE, szAppName, "Window Info -> classname: %s, 0x%X, modpath: %s, alpha %d", name, window, path, alpha);
		if (alert)
		{
			itoa( (int)window, handle, 10);
			itoa( alpha, alphaString, 10);
			lstrcat(msg, name);
			lstrcat(msg, ", ");
			lstrcat(msg, handle);
			lstrcat(msg, ", alpha: ");
			lstrcat(msg, alphaString);
			MessageBox(NULL, msg, "Window info:", MB_SETFOREGROUND | MB_OK | MB_ICONINFORMATION);
		}
	}
}

// from jugg's tasks.dll, based on code from Fahim and re5ource
HICON Wndman::GetIconFromWindow( HWND hWnd, BOOL bBigIcon )
{
	HICON hIcon = NULL;

	if (hWnd)
	{
		if ( bBigIcon )
		{
			SendMessageTimeout( hWnd, WM_GETICON, ICON_BIG, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			if ( !hIcon )
				hIcon = (HICON) GetClassLong( hWnd, GCL_HICON );
			if ( !hIcon )
				SendMessageTimeout( hWnd, WM_QUERYDRAGICON, 0, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			if ( !hIcon )
				SendMessageTimeout( hWnd, WM_GETICON, ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			//if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICONSM );
			if ( !hIcon )
				hIcon = (HICON) GetClassLong( hWnd, GCL_HICON );
		}
		else
		{
			SendMessageTimeout( hWnd, WM_GETICON, ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			if ( !hIcon )
				hIcon = (HICON) GetClassLong( hWnd, GCL_HICONSM );
			if ( !hIcon )
				SendMessageTimeout( hWnd, WM_QUERYDRAGICON, 0, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			if ( !hIcon )
				SendMessageTimeout( hWnd, WM_GETICON, ICON_BIG, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			//if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICON );
			if ( !hIcon )
				hIcon = (HICON) GetClassLong( hWnd, GCL_HICONSM );
		}
	}

	return hIcon;
}

BOOL Wndman::TraySend(HWND window)
{
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "Sending HWND:0x%X to tray", window);
#endif
	BOOL IconNotified;
	// Get an icon handle
	HICON hIcon = GetIconFromWindow(window, FALSE);

	NOTIFYICONDATA Icon;
	ZeroMemory(&Icon, sizeof(Icon));
		
	Icon.cbSize = sizeof(NOTIFYICONDATA); //NOTIFYICONDATA_V1_SIZE // sizeof(NOTIFYICONDATA)
	Icon.hWnd = hWnd; // use this HWND to accept messages
	Icon.uID = (int) window;
	Icon.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP; //  
	Icon.uCallbackMessage = WM_ICON_NOTIFY; // WM_ICON_NOTIFY
	Icon.hIcon = hIcon;

	GetWindowText( window, Icon.szTip, sizeof(Icon.szTip) );
	//lstrcat(Icon.szTip,TEXT(" Double-click to restore"));

	IconNotified = Shell_NotifyIcon(NIM_ADD, &Icon);
	if (IconNotified)
	{
		ShowWindow(window, SW_HIDE );
		trayedWindows.push_back(window);
	}
	else {
		LSLog(LOG_NOTICE, szAppName, "unable to post messages to tray");
	} 
	DestroyIcon(hIcon);
	return IconNotified;
}

BOOL Wndman::TrayRestore(HWND window)
{
	BOOL IconNotified;
	// Get an icon handle
	HICON hIcon = GetIconFromWindow(window, FALSE);

	NOTIFYICONDATA Icon;
	ZeroMemory(&Icon, sizeof(Icon));
		
	Icon.cbSize = sizeof(NOTIFYICONDATA); //NOTIFYICONDATA_V1_SIZE // sizeof(NOTIFYICONDATA)
	Icon.hWnd = hWnd; // use this window to accept messages
	Icon.uID = (int) window;
	Icon.uFlags = NIF_MESSAGE |NIF_ICON | NIF_TIP; //  
	Icon.uCallbackMessage = WM_ICON_NOTIFY; // WM_ICON_NOTIFY
	Icon.hIcon = hIcon;

	GetWindowText( window, Icon.szTip, sizeof(Icon.szTip) );
	//lstrcat(Icon.szTip,TEXT(" Double-click to restore"));

	IconNotified = Shell_NotifyIcon(NIM_DELETE, &Icon);
	if (IconNotified)
	{
		ShowWindow(window, SW_SHOW );
		trayedWindows.remove(window);
	}
	else {
		LSLog(LOG_NOTICE, szAppName, "unable to post messages to tray");
	}
	DestroyIcon(hIcon);
	return IconNotified;
}

BOOL Wndman::TrayRestoreAll()
{
	list<HWND>::iterator i;
	BOOL ok = TRUE;
	BOOL current;
	for (i = trayedWindows.begin(); i != trayedWindows.end(); i++)
	{
		current = TrayRestore(*i);
		// check for changes when everything is still ok
		if (!current)
			ok = FALSE;
	}
	trayedWindows.clear();
	return ok;
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Wndman::Wndman(HWND parentWnd, int& code):
Window(szAppName)
{

	int msgs[] = {LM_GETREVID, 0};

	if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
		0, 0, 0, 0, parentWnd))
	{
		MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
		code = 1;
		return;
	}

	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	AddBangCommand("!WndForeground", BangWndForeground);
	AddBangCommand("!WndSetOpacity", BangWndSetOpacity);
	AddBangCommand("!WndPushBottom", BangWndPushBottom);
	AddBangCommand("!WndPushBack", BangWndPushBack);
	AddBangCommand("!WndOnTop", BangWndOnTop);
	AddBangCommand("!WndHide", BangWndHide);
	AddBangCommand("!WndMaxToggle", BangWndMaxToggle);
	AddBangCommand("!WndMaximize", BangWndMaximize);
	AddBangCommand("!WndRestore", BangWndRestore);
	AddBangCommand("!WndMinimize", BangWndMinimize);
	AddBangCommand("!WndDestroy", BangWndDestroy);
	AddBangCommand("!WndClose", BangWndClose);
	AddBangCommand("!WndInfo", BangWndInfo);
	AddBangCommand("!WndAllInfo", BangWndAllInfo);

	// sizing
	AddBangCommand("!WndShade", BangWndShade);
	AddBangCommand("!WndUnShade", BangWndUnShade);
	AddBangCommand("!WndUnShadeAll", BangUnShadeAll);
	AddBangCommand("!WndSize", BangWndSize);
	AddBangCommand("!WndSizeGrow", BangWndSizeGrow);
	AddBangCommand("!WndSizeMax", BangWndSizeMax);
	AddBangCommand("!WndToggleShade", BangWndToggleShade);

	// positioning
	AddBangCommand("!WndMove", BangWndMove);
	AddBangCommand("!WndMoveDelta", BangWndMoveDelta);
	AddBangCommand("!WndMoveHome", BangWndMoveHome);
	AddBangCommand("!WndMoveCenter", BangWndMoveCenter);

	// traying
	AddBangCommand("!WndSendToTray", BangSendToTray);
	AddBangCommand("!WndRestoreFromTray", BangRestoreFromTray);
	AddBangCommand("!WndRestoreAllFromTray", BangRestoreAllFromTray);

	#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "%s ready, hwnd: 0x%X", szAppName, hWnd);
	#endif

	code = 0;
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
Wndman::~Wndman()
{
	int msgs[] = {LM_GETREVID, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	RemoveBangCommand("!WndForeground");
	RemoveBangCommand("!WndSetOpacity");
	RemoveBangCommand("!WndPushBottom");
	RemoveBangCommand("!WndPushBack");
	RemoveBangCommand("!WndOnTop");
	RemoveBangCommand("!WndHide");
	RemoveBangCommand("!WndMaxToggle");
	RemoveBangCommand("!WndMaximize");
	RemoveBangCommand("!WndRestore");
	RemoveBangCommand("!WndMinimize");
	RemoveBangCommand("!WndDestroy");
	RemoveBangCommand("!WndClose");
	RemoveBangCommand("!WndInfo");
	RemoveBangCommand("!WndAllInfo");

	// sizing
	RemoveBangCommand("!WndShade");
	RemoveBangCommand("!WndUnShade");
	RemoveBangCommand("!WndUnShadeAll");
	RemoveBangCommand("!WndSize");
	RemoveBangCommand("!WndSizeGrow");
	RemoveBangCommand("!WndSizeMax");
	RemoveBangCommand("!WndToggleShade");

	// positioning
	RemoveBangCommand("!WndMove");
	RemoveBangCommand("!WndMoveDelta");
	RemoveBangCommand("!WndMoveHome");
	RemoveBangCommand("!WndMoveCenter");

	RemoveBangCommand("!WndSendToTray");
	RemoveBangCommand("!WndRestoreFromTray");
	RemoveBangCommand("!WndRestoreAllFromTray");

	// restore all windows when closing WndMan, otherwise the icons would point
	// to the old hwnd of WndMan, and they wouldn't be able to be restored
	TrayRestoreAll();

	destroyWindow();
}


//=========================================================
// Registered messages
//=========================================================

void Wndman::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onEndSession,	WM_ENDSESSION)
		MESSAGE(onEndSession,	WM_QUERYENDSESSION)
		MESSAGE(onGetRevId,		LM_GETREVID)
		MESSAGE(onSysCommand,	WM_SYSCOMMAND)
		MESSAGE(onTray,			WM_ICON_NOTIFY);	
	END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void Wndman::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void Wndman::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
		case 0:
			sprintf(buf, "Wndman.dll: %s", &rcsRevision[11]);
			buf[strlen(buf) - 1] = '\0';
		break;
		case 1:
			strcpy(buf, &rcsId[1]);
			buf[strlen(buf) - 1] = '\0';
		break;
		default:
			strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}


void Wndman::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void Wndman::onTray(Message& message)
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "ontray msg");
#endif
	switch(message.lParam)
	{
		case WM_LBUTTONUP:
		{
#ifdef DEBUG
			LSLog(LOG_DEBUG, szAppName, "message: WM_LBUTTONUP");
#endif
			TrayRestore((HWND)message.wParam);
		};
		break;

		case WM_RBUTTONUP:
		{
#ifdef DEBUG
			LSLog(LOG_DEBUG, szAppName, "message: WM_RBUTTONUP");
#endif
			TrayRestore((HWND)message.wParam);
		};
		break;

		default:
		break;
	};
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "Icon notify msg");
#endif
}

//=========================================================
// Bang command handling
//=========================================================

void Wndman::WindowForeground(HWND window) {
	SetForegroundWindow(window);
}

void Wndman::WindowSetOpacity(LPCSTR args) {
	int count = 0;
	HWND window = NULL;
	int alpha;

	char token1[MAX_LINE_LENGTH], token2[MAX_LINE_LENGTH], extra[MAX_LINE_LENGTH];
	char *tokens[2] = {token1, token2};
	
	token1[0] = token2[0] = extra[0] = NULL;
	count = LCTokenize (args, tokens, 2, extra);

	window = getHWNDhelper((count==2) ? token1 : NULL);

	if (window != NULL)
	{
		alpha = min(max(atoi(tokens[count-1]), 0), 255);
		setHWNDAcceptAlpha(window);
		setHWNDAlpha(window, alpha);
	}
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "Set Alpha called, args %s, 1: %s, 2: %s", args, token1, token2);
#endif
}

void Wndman::WindowPushBottom(HWND window) {
	HWND below = getHWNDBelow(window); 
	SetWindowPos(window, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	SetForegroundWindow(below);
}

void Wndman::WindowPushBack(HWND window) {
	HWND below = getHWNDBelow(window); 
	SetForegroundWindow(below);
}

void Wndman::WindowOnTop(HWND caller, LPCSTR args) {
	int count = 0;
	HWND window = NULL;

	char token1[MAX_LINE_LENGTH], token2[MAX_LINE_LENGTH], extra[MAX_LINE_LENGTH];
	char *tokens[2] = {token1, token2};
	
	token1[0] = token2[0] = extra[0] = NULL;
	count = LCTokenize (args, tokens, 2, extra);

	window = getHWNDhelper((count==2) ? token1 : NULL);

	if (window != NULL)
	{
		if ( lstrcmpi(tokens[count-1], "on")==0 || lstrcmpi(tokens[count-1], "true")==0 ) {
			SetWindowPos(window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
#ifdef DEBUG
			LSLog(LOG_DEBUG, szAppName, "topmost");
#endif
		}
		else {
			SetWindowPos(window, HWND_NOTOPMOST	, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
#ifdef DEBUG
			LSLog(LOG_DEBUG, szAppName, "notopmost");
#endif
		}
	}
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "On top called, args %s, 1: %s, 2: %s", args, token1, token2);
#endif
}

void Wndman::WindowHide(HWND window) {
	ShowWindow(window, SW_HIDE);
}

void Wndman::WindowMaxToggle(HWND window) {
	if ( IsZoomed(window) )
		ShowWindow(window, SW_RESTORE);
	else
		ShowWindow(window, SW_MAXIMIZE);
}

void Wndman::WindowMaximize(HWND window) {
	ShowWindow(window, SW_MAXIMIZE);
}

void Wndman::WindowRestore(HWND window) {
	ShowWindow(window, SW_RESTORE);
}

void Wndman::WindowMinimize(HWND window) {
	ShowWindow(window, SW_MINIMIZE);
}

void Wndman::WindowDestroy(HWND window) {
	// cruel method, might not be what the user expects
	DestroyWindow(window);
}

void Wndman::WindowClose(HWND window) {
	FARPROC (__stdcall *EndTask)(HWND, BOOL, BOOL);
	EndTask = (FARPROC (__stdcall *) (HWND, BOOL, BOOL)) GetProcAddress(GetModuleHandle("USER32.DLL"), "EndTask");

	if (EndTask != NULL) {
	// close the task instead
	EndTask(window, false, true);
	//DestroyWindow(window);
	}
	else
	{
		LSLog(LOG_NOTICE, szAppName, "Unable to find EndTask() in user32.dll");
	}
}

void Wndman::WindowAllInfo(HWND caller, LPCSTR args) {
	WindowInfo(getActiveHWND(), FALSE);
	WindowInfo(getFocusHWND(), FALSE);
	WindowInfo(getForegroundHWND(), FALSE);
}

