/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __WNDMAN_H
#define __WNDMAN_H

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <stdlib.h>
#include <shellapi.h>

#include "..\current\lsapi\lsapi.h"
#include "..\current\lsapi\lswinbase.h"

#include <map>
#include <list>
using namespace std;

class Wndman : public Window
{
// data
protected:
	map<HWND, RECT> shadedWindows;
	list<HWND> trayedWindows;

// functions
public:
	Wndman(HWND parentWnd, int& code);
	~Wndman();

	// window finders:
	HWND getFocusHWND();
	HWND getActiveHWND();
	HWND getForegroundHWND();

	HWND getHWNDBelow(HWND window);
	HWND getHWNDAbove(HWND window);
	HWND getHWNDhelper(LPCSTR args);
	BOOL returnHWNDAndCoords(HWND *window, int *x, int *y, LPCSTR args);

	// trayfunctions
	BOOL TraySend(HWND window);
	BOOL TrayRestore(HWND window);
	BOOL TrayRestoreAll();

	void WindowInfo(HWND window, BOOL alert);

	// opacity functions
	void setHWNDAlpha(HWND window, int Alpha);
	int getHWNDAlpha(HWND window);

	// size & positioning
	void WndSize(HWND window, const int sizeProp, int x, int y);
	void WndPos(HWND window, const int moveProp, int x, int y);
	void UnShadeAll();
	void ShadeToggle(HWND window);
	BOOL IsWindowShaded(HWND window);

	// bang functions
	void WindowForeground(HWND wnd);
	void WindowPushBottom(HWND wnd);
	void WindowPushBack(HWND wnd);
	void WindowSetOpacity(LPCSTR args);
	void WindowOnTop(HWND, LPCSTR);
	void WindowHide(HWND window);
	void WindowRestore(HWND window);
	void WindowMaxToggle(HWND window);
	void WindowMaximize(HWND window);
	void WindowMinimize(HWND window);
	void WindowClose(HWND window);
	void WindowDestroy(HWND window);

	void WindowAllInfo(HWND, LPCSTR);

private:

	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
	void onTray(Message& message);

	// helpers
	HWND getTargetHWND(int window_code);
	char *isToolTipHWND(HWND window);

	void setHWNDNoAlpha(HWND window);
	void setHWNDAcceptAlpha(HWND window);
	void hideHWNDVWM(HWND window);

	HICON GetIconFromWindow( HWND hWnd, BOOL bBigIcon );

};

void BangWndForeground(HWND, LPCSTR);
void BangWndSetOpacity(HWND, LPCSTR);
void BangWndPushBottom(HWND, LPCSTR);
void BangWndPushBack(HWND, LPCSTR);
void BangWndOnTop(HWND, LPCSTR);
void BangWndHide(HWND, LPCSTR);
void BangWndMaxToggle(HWND, LPCSTR);
void BangWndMaximize(HWND, LPCSTR);
void BangWndRestore(HWND, LPCSTR);
void BangWndMinimize(HWND, LPCSTR);
void BangWndClose(HWND caller, LPCSTR args);
void BangWndInfo(HWND caller, LPCSTR args);
void BangWndAllInfo(HWND caller, LPCSTR args);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
