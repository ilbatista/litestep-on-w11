#include "beep.h"

CONST DWORD dwFREQ[13][7] = {
	{33,  65, 131, 262, 523, 1047, 2093 },
	{35,  69, 139, 277, 554, 1109, 2217 },
	{37,  73, 147, 294, 587, 1174, 2344 },
    {39,  78, 156, 311, 622, 1245, 2489 },
    {41,  82, 165, 330, 659, 1319, 2637 },
    {44,  87, 175, 349, 698, 1397, 2794 },
    {46,  92, 185, 370, 740, 1480, 2960 },
    {49,  98, 196, 392, 784, 1568, 3136 },
    {52, 104, 208, 415, 831, 1661, 3322 },
    {55, 110, 220, 440, 880, 1760, 3520 },
    {59, 117, 233, 466, 932, 1865, 3729 },
    {62, 123, 247, 494, 988, 1976, 3951 },
	{ 0,   0,   0,   0,   0,    0,    0 }
};

CONST enum TNOTE {
	NoteC=0,
	NoteCs,
	NoteD,
	NoteDs,
	NoteE,
	NoteF,
	NoteFs,
	NoteG,
	NoteGs,
	NoteA,
	NoteAs,
	NoteB,
	NoteBad
};

CONST TNOTE NATURAL[7] = {
	NoteA,
	NoteB,
	NoteC,
	NoteD,
	NoteE,
	NoteF,
	NoteG
};

CONST TNOTE SHARP[7] = {
	NoteAs,
	NoteBad,
	NoteCs,
	NoteDs,
	NoteBad,
	NoteFs,
	NoteGs
};

CONST TNOTE FLAT[7] = {
	NoteGs,
	NoteAs,
	NoteBad,
	NoteCs,
	NoteDs,
	NoteBad,
	NoteFs
};

DWORD mpb(UINT tempo)
{
	return (DWORD)((DOUBLE)1000/(DOUBLE)(tempo/60)) * 4;
}

UINT getNumbers(LPCSTR sNotes, UINT i)
{
	UINT utemp = 0;
	i++;
	while (isdigit(sNotes[i]))
	{
		utemp = utemp * 10 + (sNotes[i] - '0');
		i++;
	}

	return utemp;
}

void playBeep(LPCSTR sNotes)
{	
	UINT uOctave = 3,
		uTempo = 120,
		uTemp,
		i;
	DOUBLE dMod=1;
	DWORD dNoteLen=4,
		dWholeLen=2000,
		dDur=500,
		dFreq;


	for(i=0;i<strlen(sNotes);i++)
	{
		CHAR sTemp = toupper(sNotes[i]);
		
		switch(sTemp)
		{
			case 'L':
				uTemp = dNoteLen;
				dNoteLen = getNumbers(sNotes, i);
				if(!CHECK_LENGTH(dNoteLen))	dNoteLen=uTemp;
				dDur = (dWholeLen/dNoteLen);
				break;
			case 'O':
				uTemp = uOctave;
				uOctave = getNumbers(sNotes,i);
				if(!CHECK_OCTAVE(uOctave)) uOctave = uTemp;
				dDur = (dWholeLen/dNoteLen);
				break;
			case 'M':
				i++;
				switch(toupper(sNotes[i]))
				{
					case 'S':
						dMod = .75;
						break;
					case 'N':
						dMod = .875;
						break;
					case 'L':
						dMod = 1;
						break;
					default:
						i--;
						break;
				}
				break;
			case 'P':
				uTemp = getNumbers(sNotes, i);
				if(CHECK_LENGTH(uTemp)) beepPause(dWholeLen/uTemp);
				break;
			case 'T':
				uTemp = uTempo;
				uTempo = getNumbers(sNotes, i);
				if(!CHECK_TEMPO(uTempo)) uTempo = uTemp;
				dWholeLen = mpb(uTempo);
				break;
			case 'A':
			case 'B':
			case 'C':
			case 'D':
			case 'E':
			case 'F':
			case 'G':
				uTemp=dDur;
				switch(sNotes[i+1])
				{
					case '+':
					case '#':
						dFreq = dwFREQ[SHARP[sTemp-'A']][uOctave];
						if(sNotes[i+2] == '.')
						{
							dDur = (DWORD)((DOUBLE)dDur * 1.5);
							i++;
						}
						i++;
						break;
					case '-':
						dFreq = dwFREQ[FLAT[sTemp-'A']][uOctave];
						if(sNotes[i+2] == '.')
						{
							dDur = (DWORD)((DOUBLE)dDur * 1.5);
							i++;
						}
						i++;
						break;
					case '.':
						dDur = (DWORD)((DOUBLE)dDur * 1.5);
						i++;
					default:
						dFreq = dwFREQ[NATURAL[sTemp-'A']][uOctave];
						break;
				}
				if(dFreq==0) continue;
				OSBeep(dFreq,(DWORD)((DOUBLE)dDur * dMod));
				dDur=uTemp;
				break;
		}
	}
}