/*
   This code was actually taken from an Open Sourced, GPL'd program called Bleeper
   Copyright 1999 Andy Preston - Apollo Developments, Swindon U.K. andy@anorak.org.uk
   (written in Delphi [and licensed under the GPL])

   The asembler code was changed just to make it compatable with C++
   Some of the code was restructured/changed to make it work correctly.
   The theory and implementation should be credited to him, I just modified
     said implementation to make it work for what I needed.

   BleepInt, Bleeper, and GWBleep code can be found at:
   http://delphi.icm.edu.pl/ftp/d10free/bleepint.zip
*/
#include "beep.h"

void beepShutUp(void)
{
	_asm{
		In al,0x61
		And al,0xFC
		Out 0x61,al
	}
}

void beepHardBeep(DWORD freq, DWORD mSec)
{
	if(freq > 20 && freq < 5000)
	{
		beepAsmBeep((WORD)(1193181/(DWORD)freq));
		if(mSec>=0)
			beepPause(mSec);
		beepShutUp();
	}
}

void beepAsmBeep(WORD freq)
{
	_asm
	{
		Push BX
        In AL, 0x61
        Mov BL, AL
        And AL, 3
        Jne Skip
        Mov AL, BL
        Or AL, 3
        Out 0x61, AL
        Mov AL, 0xB6
        Out 0x43, AL
  Skip: Mov AX, freq
        Out 0x42, AL
        Mov AL, AH
        Out 0x42, AL
        Pop BX
	}
}

void beepPause(DWORD mSec)
{
	DWORD iCurTick, iFirstTick, iElapTime;
	iFirstTick = GetTickCount();
	
	do {
		iCurTick = GetTickCount();
		if (iCurTick < iFirstTick)
			iElapTime = (HiValue - iFirstTick) + iCurTick;
		else
			iElapTime = iCurTick - iFirstTick;
	} while(iElapTime <= mSec);
}