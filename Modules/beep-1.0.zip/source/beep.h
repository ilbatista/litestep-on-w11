#include "..\lsapi\lsapi.h"

//#define NOTE_PLAYABLE (NoteC | NoteCs | NoteD |	NoteDs | NoteE | NoteF | NoteFs | NoteG | NoteGs | NoteA | NoteAs | NoteB)
#define CHECK_TEMPO(tempo) ((255 <= tempo) && (tempo >= 32))
#define CHECK_OCTAVE(octa) ((octa <= 6) && (octa >= 0))
#define CHECK_LENGTH(leng) ((leng & 1)  || (leng & 2) || (leng & 4) || (leng & 8) || (leng & 16) || (leng & 32) || (leng & 64))

#define HiValue  sizeof(DWORD)

extern "C" {
	__declspec( dllexport ) int initModuleEx(HWND hParent, HINSTANCE hInst, LPCSTR pszPath);
	__declspec( dllexport ) void quitModule(HINSTANCE hInst);
}
void bangBeep(HWND hCaller, LPCSTR pszArgs);
void bangPlay(HWND hCaller, LPCSTR pszArgs);

/* Added By Tresni for Win9x/ME support */
void beepShutUp(void);
void beepHardBeep(DWORD freq, DWORD mSec);
void beepAsmBeep(WORD freq);
void beepPause(DWORD mSec);

void OSBeep(DWORD dFreq, DWORD dDur);
void playBeep(LPCSTR sNotes);
DWORD mpb(UINT tempo);
UINT getNumbers(LPCSTR, UINT);

/*
Ln
  Sets the duration (length) of the notes. The variable n does not indicate
  an actual duration amount but rather a note type;
  L1 - whole note, L2 - half note, L4 - quarter note, etc. (L8, L16, L32, L64).
  By default n = 4.

On
  Sets the current octave. Valid values for n are 0 through 6. An octave
  begins with C and ends with B. Remember that C- is equivalent to B.

MN ML MS
  Stand for Music Normal, Music Legato, and Music Staccato.
  MN - Note duration is 7/8ths of the length indicated by Ln.
  ML - Note duration is full length of that indicated by Ln.
  MS - Note duration is 3/4ths of the length indicated by Ln.

Pn
  Causes a silence (pause) for the length of note indicated (same as Ln).

Tn
  Sets the number of "L4"s in a minute. Valid values are from 32 to 255. 
  The default value is T120.

. (period)
  When placed after a note, it causes the duration of the note to be 3/2 
  of the set duration. This is how to get "dotted" notes. "L4 C#." would 
  play C sharp as a dotted quarter note.
*/
