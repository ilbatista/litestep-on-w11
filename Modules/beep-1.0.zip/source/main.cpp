/*
This is a part of the Beep LiteStep module source code.
Copyright (C) 2002 Erik Christiansson, aka Sci
http://www.alphafish.com/
erik@alphafish.com

Modified by Brian Hartvigsen, aka Tresni
http://tresni.coreshell.info/
tresni@coreshell.info

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//#include <windows.h>
#include "beep.h"

BOOL IS_WINNT = false;

int initModuleEx(HWND hParent, HINSTANCE hInst, LPCSTR pszPath)
{
	OSVERSIONINFO osVI;
	CHAR sPlay[MAX_PATH+1];
	AddBangCommand("!Beep", bangBeep);
	AddBangCommand("!Play", bangPlay);

	/* We attempt to determine the running version of Windows
	   If we can't assume it's NT (as the asm code is 'privileged'
	   under NT so we don't want to use it unless we know for sure
	   we are running 9x/ME */
	osVI.dwOSVersionInfoSize = sizeof(osVI);
	if(GetVersionEx(&osVI) == 0 || osVI.dwPlatformId == VER_PLATFORM_WIN32_NT)
		IS_WINNT = true;

	GetRCString("PlayOnLoad",sPlay, "",MAX_PATH);
	if(sPlay) playBeep(sPlay);

	return 0;
}

void quitModule(HINSTANCE hInst)
{
	CHAR sPlay[MAX_PATH+1];
	
	RemoveBangCommand("!Beep");
	RemoveBangCommand("!Play");

	GetRCString("PlayOnUnload",sPlay, "",MAX_PATH);
	if(sPlay) playBeep(sPlay);
}

void bangBeep(HWND hCaller, LPCSTR pszArgs)
{
	int nFrequency, nDuration;
	char szFrequency[32], szDuration[32];
	char* pszTokens[2] = {szFrequency, szDuration};
	
	LCTokenize(pszArgs, pszTokens, 2, NULL);

	nFrequency = atoi(szFrequency);
	nDuration = atoi(szDuration);

	OSBeep(nFrequency,nDuration);
}

void bangPlay(HWND caller, LPCSTR pszArgs)
{
	playBeep(pszArgs);
}

void OSBeep(DWORD dFreq, DWORD dDur)
{
	if(!IS_WINNT)
		beepHardBeep(dFreq, dDur);
	else if(!Beep(dFreq, dDur))
		MessageBox(NULL, "Failed to process sound instruction.", "Beep", MB_SETFOREGROUND);
}