Beep 1.0 (ping)
--==--

Copyright (c) 2002 Brian Hartvigsen, aka Tresni
Copyright (c) 2002 Erik Christiansson, aka Sci
Copyright (c) 1999 Andy Preston - Apollo Developments, Swindon U.K. andy@anorak.org.uk
--==--

Change Log:
  1.0 - 16 sep 2002 - Tresni
    Added !PLAY (uses QBASIC PLAY syntax)
    Added PlayOnLoad & PlayOnUnload
  0.2 - 09 sep 2002 - Tresni
    Found code that will make Beep work on 9x/ME with frequency and duration
    The code is by Andy Preston and is his code (originally written in Delphi)
    I just modified it to make it work with MS Visual C++ and LiteStep
    See the source for more information on this.
  0.1 - 22 aug 2002 - Sci
    First public release
--==--

Notes:
  One thing missing from beep.dll is the ability to play in the "background"..  This
  means unless you have beep threaded, while the music is playing, you can't do
  anything else! I've been running it threaded for a while now without any problems.
  If anyone has any ideas on how to make this play "in background" I would appreciate
  your input!
  
  To Load Threaded:
    LoadModule $path_to_module$\beep.dll threaded
--==--

Bangs:
  !beep <frequency> <duration>
    Plays a beep of <frequency> Hz in <duration> ms (1000 ms = 1 s)
  !play <string>
    Plays a string like the QBASIC PLAY statement (see section on !play syntax)
--==--

Step.rc Settings:
  PlayOnLoad <string>
    Plays a string like the QBASIC PLAY statement on module Load
    (ie LS Startup or if you load the module manually)
  PlayOnUnload <string>
    Plays a string like the QBASIC PLAY statement on module unload
    (ie LS Quit and Recycle)
--==--

!play Syntax
  
  A B C D E F G -- Plays this note
  
  Ln -- Sets the duration (length) of the notes. The variable n does not
     indicate an actual duration amount but rather a note type;
     L1 - whole note, L2 - half note, L4 - quarter note, etc. (L8, L16, L32, L64)
     By default n = 4.

  On -- Sets the current octave. Valid values for n are 0 through 6. An octave
     begins with C and ends with B. Remember that C- is equivalent to B.
     By default n = 3 (middle C)
  
  MN -- Stands for Music Normal
     Note duration is 7/8ths of the length indicated by Ln.
     
  ML -- Stands for Music Legato
     Note duration is full length of that indicated by Ln.
     
  MS -- Stands for Music Staccato
     Note duration is 3/4ths of the length indicated by Ln.

  Pn -- Causes a silence (pause) for the length of note indicated (same as Ln).

  Tn -- Sets the number of "L4"s in a minute. Valid values are from 32 to 255.
     The default value is T120.

  . -- (period) When placed after a note, it causes the duration of the note to be
    3/2 of the set duration. This is how to get "dotted" notes. "L4 C#." would play
    C sharp as a dotted quarter note.
    
  Examples:
   Macarena
   t180o4L4fL8ffL4fL8fffffffaccL4fL8ffL4fL8ffffffdcp4L4fL8ffL4fL8fffffffap4o5L2co4L4ao5L8cL8o4afp4p2

   Killing Me Softly -
   t90p4o4L8eL4fgL8aL4aL8gL4dgp4p8L8aL4gL8feefL2cp4L8eL4fL4gL8aL4aL8gL4abL8bo5co4L8bL16aL8gL16aL2aa

   Boom Boom Boom - Venga Bots
   t160L4o3ap32ap32gp32f.p8L8cccggL4fp8L8dddfga.f.p8dddddc.g.p8

   Barbie Girl - Aqua
   t125L8o4g#eg#o5c#L4o4ap4L8f#d#f#bL4g#f#L8ep4e8c#L4f#c#p4L8f#eL4g#f#

   Dangerous - Same People
   T125L4o3eeL8ababL4eeL8baap8L4eeL8ababL4eecc

   The Can-can
   T255O2L1CL4DFEDL2GGL4GAEFL2DDL4DFEDCO3CL2O2L4BAGFEDL1CL4DFEDL2GGL4GAEFL2DDL4DFEDCGDEL2CP2

   Get Your freak on - Missy Eliot
   T90L8o3fL16ffff#L8cfL16ffff#L8cL8o3fL16ffff#L8c#fL16ffff#L8c

   Gotta Get through this - Daniel Bledingfield
   t140o3l8gp4l8o4dd#p4o3a#p2a#.a.o3l8gp4l8o4dd#p4o3a#p2a#.a.o3l8gp4l8o4dd#p4o3a#p2a#.a.03gp4o4dd#

   Skip to my Lou
   l4eeccl8eel4el2gl4ddccl8ddl4dl2fl4eeccl8eel4el2gl4dfedl2cc

   Teen Spirit - Nirvana
   o2L8fff+fg+g+f+l4fl8ff+fo3c#c#o2ba#o2fff+fg+g+f+l4fl8ff+fo3ffd#c#

  If you want to find popular songs to use, lookup Nokia Ringtones (the composer ones
  that look like this "8d1 8e1 4f1 8g1 4f1 4e1").  They are really easy to port to PLAY
  syntax.

  WARNING:  Length of string can only be 260 characters long..  beep will only read
  the first 260 characters.
--==--

Feedback:
  Bugs/Questions/Ideas on this release to tresni@coreshell.info (the source and all
  information has been given to Sci, but I don't know if he wants to handle my changes)
--==--

To Do:
  - PLAY support (like in GWBASIC or QBASIC)
--==--

Source Code:
  The sourcecode for this module is distributed under the GNU
  Public License. If you didn't get the sourcecode then contact
  the host from where you downloaded this file as it should have
  been included.