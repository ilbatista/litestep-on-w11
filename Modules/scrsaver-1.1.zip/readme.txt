scrsaver.dll 1.1 - Essential screen-saver bang commands
---------------------------------------------------------

Bangs:

!ScreenSaver [optional delay in ms]
!ScreenSaverEnable
!ScreenSaverDisable
!ScreenSaverToggle


History:

1.1
  * Fixed bug (hope) causing crash on some WinNT machines
  + Module will not try to launch already running 
    screensaver
  + Added optional Delay parameter to !ScreenSaver bang.
    Useful on fast machines, when starting screensaver 
    with a hotkey. Specify desired delay interval to 
    avoid unwanted aborting of screensaver by releasing 
    of key. (On user request)

1.0
  Initial release

--------------------------------------------------------
mailto: pavel.vitis@seznam.cz
www   : http://floach.pimpin.net/pavel/
