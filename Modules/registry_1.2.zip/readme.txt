registry
========

This module is designed to work similarly to envvars :

*registryread myVar regBase regKey regValue

or 

*registryread [myVar] [regBase] [regKey] [regValue]

will read the value of regKey from regBase and place it into $myVar$ for you. All reads defined in this way are read at startup. For in-session reads, e.g. for scripts, you can use :

!registryread myVar regBase regKey

or 

!registryread [myVar] [regBase] [regKey] [regValue]

Examples:
---------

!registryread "canwereadthis" "HKCU" "Control Panel\Desktop" "Wallpaper"
*registryread "canwereadthis" "HKCU" "Control Panel\Desktop" "Wallpaper"

Notes:
------

1) regBase can be HKCU, HKLM or HKCR.

2) All registry entities are supported (DWORDs, strings, etc.). You can use the same LS EVar (myVar) multiple times in the same session.

3) No write access due to potential for abuse.

4) The source is probably suboptimal in some places, but that's the way of things. Error boxes will be shown for major events.

5) registryparanoia in step.rc will prevent any registry read attempts from working :)

Version history:
----------------

v 1.2
=====

- Refresh support added. Probably flaky.

v 1.1
=====

- Expand variables.

v 1.0
=====

Support for HKCR added.
Disabled the error message dialog for userParanoia because it would be tedious.

v 0.9
=====
- *sigh* Pointers - I forgot the difference between & and *. Silly, silly me. Thanks to ilmcuts for the smack around the head.
- Spaced values failed to work properly. Fixed.
- Memory leak identified by ilmcuts. Fixed.

v 0.6
=====
- ilmcuts pointed out a silly flaw. Fixed :)
- Rewrote the registry code using Tobbe's code as a base to work from.
- I really must knock some C# wrappers up to make my life easier :)

v 0.5
=====
Far, far too much time spent to get this working. *sigh*

- Resolved the linker problems with VS2005EE. Have to manually add advapi32.lib, user32.lib and lsapi.lib.
 - ATL also missing from the Express Edition, helpfully.
- Fixed InitModuleEx() problem - forgot to include registry.h *smack around head*
- Credit to Richard Reynolds for much patient assistance :
  - Found out that Windows functions require Unicode, so introduced conversion code to make this happen (ATL).
  - He also spotted numerous silly errors with the conversion code :)
- jugg pointed out that GetToken requires a char array to drop (a) token(s) into.

Contact:
--------

Phil @ the LDE(X) support boards. Be gentle :)