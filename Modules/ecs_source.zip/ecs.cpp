/*
This is a part of the LSECS Module Source code.

  Copyright (C) 2002-2006 Mike Edward Moras.
  
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	  This program is distributed in the hope that it will be useful,
	  but WITHOUT ANY WARRANTY; without even the implied warranty of
	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
	  GNU General Public License for more details.
	  
		You should have received a copy of the GNU General Public License
		along with this program; if not, write to the Free Software
		Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "ecs.h"

/*********************************************************************/

typedef struct _lsBangCmdDef {
	const char *Name;
	BangCommand *Command;
} lsBangCmdDef;

static lsBangCmdDef Bangs[] = {
	{ "!ecsscrollbarcolor", bang_ecssetcolorscrollbar },
	{ "!ecsbackgroundcolor", bang_ecssetcolorbackground },
	{ "!ecsactivecaptioncolor", bang_ecssetcoloractivecaption },
	{ "!ecsinactivecaptioncolor", bang_ecssetcolorinactivecaption },
	{ "!ecsmenucolor", bang_ecssetcolormenu },
	{ "!ecswindowcolor", bang_ecssetcolorwindow },
	{ "!ecswindowframecolor", bang_ecssetcolorwindowframe },
	{ "!ecsmenutextcolor", bang_ecssetcolormenutext },
	{ "!ecswindowtextcolor", bang_ecssetcolorwindowtext },
	{ "!ecscaptiontextcolor", bang_ecssetcolorcaptiontext },
	{ "!ecsactivebordercolor", bang_ecssetcoloractiveborder },
	{ "!ecsinactivebordercolor", bang_ecssetcolorinactiveborder },
	{ "!ecsappworkspacecolor", bang_ecssetcolorappworkspace },
	{ "!ecshighlightcolor", bang_ecssetcolorhighlight },
	{ "!ecshighlighttextcolor", bang_ecssetcolorhighlighttext },
	{ "!ecsbtnfacecolor", bang_ecssetcolorbtnface },
	{ "!ecsbtnshadowcolor", bang_ecssetcolorbtnshadow },
	{ "!ecsgraytextcolor", bang_ecssetcolorgraytext },
	{ "!ecsbtntextcolor", bang_ecssetcolorbtntext },
	{ "!ecsinactivecaptiontextcolor", bang_ecssetcolorinactivecaptiontext },
	{ "!ecsbtnhighlightcolor", bang_ecssetcolorbtnhighlight },
	{ "!ecs3ddkshadowcolor", bang_ecssetcolor3ddkshadow },
	{ "!ecs3dlightcolor", bang_ecssetcolor3dlight },
	{ "!ecsinfotextcolor", bang_ecssetcolorinfotext },
	{ "!ecsinfobkcolor", bang_ecssetcolorinfobk },
	{ "!ecshotlightcolor", bang_ecssetcolorhotlight },
	{ "!ecsgradientactivecaptioncolor", bang_ecssetcolorgradientactivecaption },
	{ "!ecsgradientinactivecaptioncolor", bang_ecssetcolorgradientinactivecaption },
	{ "!ecsmenuhilightcolor", bang_ecssetcolormenuhilight },
	{ "!ecsmenubarcolor", bang_ecssetcolormenubar },
	// Microsoft stubs
	{ "!ecsdesktopcolor", bang_ecssetcolordesktop },
	{ "!ecs3dfacecolor", bang_ecssetcolor3dface },
	{ "!ecs3dshadowcolor", bang_ecssetcolorbtnshadow },
	{ "!ecs3dhighlightcolor", bang_ecssetcolorbtnhighlight },
	{ "!ecs3dhilightcolor", bang_ecssetcolorbtnhighlight },
	{ "!ecsbtnhilightcolor", bang_ecssetcolorbtnhighlight },
	
	// NONCLIENTMETRICS from now on
	{ "!ecsborderwidth", bang_ecssetncmborderwidth },
	{ "!ecsscrollwidth", bang_ecssetncmscrollwidth },
	{ "!ecsscrollheight", bang_ecssetncmscrollheight },
	{ "!ecscaptionwidth", bang_ecssetncmcaptionwidth },
	{ "!ecscaptionheight", bang_ecssetncmcaptionheight },
	{ "!ecssmallcaptionwidth", bang_ecssetncmsmallcaptionwidth },
	{ "!ecssmallcaptionheight", bang_ecssetncmsmallcaptionheight },
	{ "!ecsmenuwidth", bang_ecssetncmmenuwidth },
	{ "!ecsmenuheight", bang_ecssetncmmenuheight },
	{ "!ecscaptionfontfacename", bang_ecssetncmcaptionfontfacename },
	{ "!ecscaptionfontheight", bang_ecssetncmcaptionfontheight },
	{ "!ecscaptionfontweight", bang_ecssetncmcaptionfontweight },
	{ "!ecscaptionfontitalic", bang_ecssetncmcaptionfontitalic },
	{ "!ecssmallcaptionfontfacename", bang_ecssetncmsmallcaptionfontfacename },
	{ "!ecssmallcaptionfontheight", bang_ecssetncmsmallcaptionfontheight },
	{ "!ecssmallcaptionfontweight", bang_ecssetncmsmallcaptionfontweight },
	{ "!ecssmallcaptionfontitalic", bang_ecssetncmsmallcaptionfontitalic },
	{ "!ecsmenufontfacename", bang_ecssetncmmenufontfacename },
	{ "!ecsmenufontheight", bang_ecssetncmmenufontheight },
	{ "!ecsmenufontweight", bang_ecssetncmmenufontweight },
	{ "!ecsmenufontitalic", bang_ecssetncmmenufontitalic },
	{ "!ecsstatusfontfacename", bang_ecssetncmstatusfontfacename },
	{ "!ecsstatusfontheight", bang_ecssetncmstatusfontheight },
	{ "!ecsstatusfontweight", bang_ecssetncmstatusfontweight },
	{ "!ecsstatusfontitalic", bang_ecssetncmstatusfontitalic },
	{ "!ecsmessagefontfacename", bang_ecssetncmmessagefontfacename },
	{ "!ecsmessagefontheight", bang_ecssetncmmessagefontheight },
	{ "!ecsmessagefontweight", bang_ecssetncmmessagefontweight },
	{ "!ecsmessagefontitalic", bang_ecssetncmmessagefontitalic },
	// and some combinations
	{ "!ecscaptionfont", bang_ecssetncmcaptionfont},
	{ "!ecssmallcaptionfont", bang_ecssetncmsmallcaptionfont },
	{ "!ecsmenufont", bang_ecssetncmmenufont },
	{ "!ecsstatusfont", bang_ecssetncmstatusfont },
	{ "!ecsmessagefont", bang_ecssetncmmessagefont },
	// and some combinations
	{ "!ecssavetorc", bang_ecssavetorc},
	{ "!ecsdisablevisualstyles", bang_ecsdisablevisualstyles},
//	{ "!ecsabout", bang_ecsabout},
	{ NULL , NULL}
};


int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int i = 0;
	while(Bangs[i].Name != NULL)
	{
		AddBangCommand(Bangs[i].Name, Bangs[i].Command);
		i++;
	}
	
	if(GetRCInt("ecsignorerc", 1) == 0)
	{
		ParseRC();
	}
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	int i = 0;
	while(Bangs[i].Name != NULL)
	{
		RemoveBangCommand(Bangs[i].Name);
		i++;
	}
}

/*******************************************************************************************/


void ParseRC(void)
{	
	int GDC = GetDeviceCaps(GetDC(NULL), LOGPIXELSY);
	
	BOOL iLL = FALSE;
	HMODULE hUX = GetModuleHandle("UxTheme.dll");
	if(hUX == NULL)
	{
		hUX = LoadLibrary("UxTheme.dll");
		iLL = TRUE;
	}
	if(hUX != NULL)
	{
		HRESULT (__stdcall * EnableTheming)(BOOL) = NULL;
		EnableTheming = (HRESULT (__stdcall *)(BOOL))GetProcAddress(hUX, "EnableTheming");
		if (EnableTheming)
		{
			EnableTheming(GetRCBoolDef("ecskeepvisualstyles", FALSE));
		}
		if(iLL)
		{
			FreeLibrary(hUX);
		}
	}
	
	
	char szPath[4096];
	if(GetRCString("ecssavetorc", szPath, "ecstheme.rc", 4096))
	{
		ecssavecurrentsettings(szPath);
	}
	
	INT colornum[31];
	for(INT i = 0; i< 31; i++)
	{
		colornum[i] = i;
	}
	COLORREF colorref[31];
	colorref[0] = GetRCColor("ecsscrollbarcolor", GetSysColor(0));
	/* stub */
	colorref[1] = GetRCColor("ecsbackgroundcolor", RGB(255,0,255));
	if(colorref[1] == RGB(255,0,255))
	{
		colorref[1] = GetRCColor("ecsdesktopcolor", GetSysColor(1));
	}
	colorref[2] = GetRCColor("ecsactivecaptioncolor", GetSysColor(2));
	colorref[3] = GetRCColor("ecsinactivecaptioncolor", GetSysColor(3));
	colorref[4] = GetRCColor("ecsmenucolor", GetSysColor(4));
	colorref[5] = GetRCColor("ecswindowcolor", GetSysColor(5));
	colorref[6] = GetRCColor("ecswindowframecolor", GetSysColor(6));
	colorref[7] = GetRCColor("ecsmenutextcolor", GetSysColor(7));
	colorref[8] = GetRCColor("ecswindowtextcolor", GetSysColor(8));
	colorref[9] = GetRCColor("ecscaptiontextcolor", GetSysColor(9));
	colorref[10] = GetRCColor("ecsactivebordercolor", GetSysColor(10));
	colorref[11] = GetRCColor("ecsinactivebordercolor", GetSysColor(11));
	colorref[12] = GetRCColor("ecsappworkspacecolor", GetSysColor(12));
	colorref[13] = GetRCColor("ecshighlightcolor", GetSysColor(13));
	colorref[14] = GetRCColor("ecshighlighttextcolor", GetSysColor(14));
	/* stub */		
	colorref[15] = GetRCColor("ecsbtnfacecolor", RGB(255,0,255));
	if(colorref[15] == RGB(255,0,255))
	{
		colorref[15] = GetRCColor("ecs3dfacecolor", GetSysColor(15));
	}
	/* stub */
	colorref[16] = GetRCColor("ecsbtnshadowcolor", RGB(255,0,255));
	if(colorref[16] == RGB(255,0,255))
	{
		colorref[16] = GetRCColor("ecs3dshadowcolor", GetSysColor(16));
	}	
	colorref[17] = GetRCColor("ecsgraytextcolor", GetSysColor(17));
	colorref[18] = GetRCColor("ecsbtntextcolor", GetSysColor(18));
	colorref[19] = GetRCColor("ecsinactivecaptiontextcolor", GetSysColor(19));
	/* stub */
	colorref[20] = GetRCColor("ecsbtnhighlightcolor", RGB(255,0,255));
	if(colorref[20] == RGB(255,0,255))
	{
		colorref[20] = GetRCColor("ecs3dhighlightcolor", RGB(255,0,255));
		if(colorref[20] == RGB(255,0,255))
		{
			colorref[20] = GetRCColor("ecs3dhilightcolor", RGB(255,0,255));
			if(colorref[20] == RGB(255,0,255))
			{
				colorref[20] = GetRCColor("ecsbtnhilightcolor", GetSysColor(20));
			}	
		}	
	}	
	colorref[21] = GetRCColor("ecs3ddkshadowcolor", GetSysColor(21));
	colorref[22] = GetRCColor("ecs3dlightcolor", GetSysColor(22));
	colorref[23] = GetRCColor("ecsinfotextcolor", GetSysColor(23));
	colorref[24] = GetRCColor("ecsinfobkcolor", GetSysColor(24));
	/* 25 not officially known according to Microsoft */
	colorref[25] = GetSysColor(25);
	colorref[26] = GetRCColor("ecshotlightcolor", GetSysColor(26));
	colorref[27] = GetRCColor("ecsgradientactivecaptioncolor", GetSysColor(27));
	colorref[28] = GetRCColor("ecsgradientinactivecaptioncolor", GetSysColor(28));
	colorref[29] = GetRCColor("ecsmenuhilightcolor", GetSysColor(29));
	colorref[30] = GetRCColor("ecsmenubarcolor", GetSysColor(30));
	
	int iPushedTheColors = 0;
	
	// NONCLIENTMETRICS from now on
	char szI[32];
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
	{
		ncm.iBorderWidth = GetRCInt("ecsborderwidth", ncm.iBorderWidth);
		ncm.iScrollWidth = GetRCInt("ecsscrollwidth", ncm.iScrollWidth);
		ncm.iScrollHeight = GetRCInt("ecsscrollheight", ncm.iScrollHeight);
		ncm.iCaptionWidth = GetRCInt("ecscaptionwidth", ncm.iCaptionWidth);
		ncm.iCaptionHeight = GetRCInt("ecscaptionheight", ncm.iCaptionHeight);
		ncm.iSmCaptionWidth = GetRCInt("ecssmallcaptionwidth", ncm.iSmCaptionWidth);
		ncm.iSmCaptionHeight = GetRCInt("ecssmallcaptionheight", ncm.iSmCaptionHeight);
		ncm.iMenuWidth = GetRCInt("ecsmenuwidth", ncm.iMenuWidth);
		ncm.iMenuHeight = GetRCInt("ecsmenuheight", ncm.iMenuHeight);
		if(GetRCString("ecscaptionfontfacename", szI, ncm.lfCaptionFont.lfFaceName, 32))
			lstrcpy(ncm.lfCaptionFont.lfFaceName, szI);
		
		int i = GetRCInt("ecscaptionfontheight", ncm.lfCaptionFont.lfHeight);
		if(i > 0) { i = -MulDiv(i, GDC, 72); }
		ncm.lfCaptionFont.lfHeight = i;
		
		ncm.lfCaptionFont.lfWeight = GetRCInt("ecscaptionfontweight", ncm.lfCaptionFont.lfWeight);
		ncm.lfCaptionFont.lfItalic = GetRCInt("ecscaptionfontitalic", ncm.lfCaptionFont.lfItalic);
		if(GetRCString("ecssmallcaptionfontfacename", szI, ncm.lfSmCaptionFont.lfFaceName, 32))
			lstrcpy(ncm.lfSmCaptionFont.lfFaceName, szI);
		
		i = GetRCInt("ecssmallcaptionfontheight", ncm.lfSmCaptionFont.lfHeight);
		if(i > 0) { i = -MulDiv(i, GDC, 72); }
		ncm.lfSmCaptionFont.lfHeight = i;
		
		ncm.lfSmCaptionFont.lfWeight = GetRCInt("ecssmallcaptionfontweight", ncm.lfSmCaptionFont.lfWeight);
		ncm.lfSmCaptionFont.lfItalic = GetRCInt("ecssmallcaptionfontitalic", ncm.lfSmCaptionFont.lfItalic);
		if(GetRCString("ecsmenufontfacename", szI, ncm.lfMenuFont.lfFaceName, 32))
			lstrcpy(ncm.lfMenuFont.lfFaceName, szI);
		
		i = GetRCInt("ecsmenufontheight", ncm.lfMenuFont.lfHeight);
		if(i > 0) { i = -MulDiv(i, GDC, 72); }
		ncm.lfMenuFont.lfHeight = i;
		
		ncm.lfMenuFont.lfWeight = GetRCInt("ecsmenufontweight", ncm.lfMenuFont.lfWeight);
		ncm.lfMenuFont.lfItalic = GetRCInt("ecsmenufontitalic", ncm.lfMenuFont.lfItalic);
		if(GetRCString("ecsstatusfontfacename", szI, ncm.lfStatusFont.lfFaceName, 32))
			lstrcpy(ncm.lfStatusFont.lfFaceName, szI);
		
		
		i = GetRCInt("ecsstatusfontheight", ncm.lfStatusFont.lfHeight);
		if(i > 0) { i = -MulDiv(i, GDC, 72); }
		ncm.lfStatusFont.lfHeight = i;
		
		
		ncm.lfStatusFont.lfWeight = GetRCInt("ecsstatusfontweight", ncm.lfStatusFont.lfWeight);
		ncm.lfStatusFont.lfItalic = GetRCInt("ecsstatusfontitalic", ncm.lfStatusFont.lfItalic);
		
		if(GetRCString("ecsmessagefontfacename", szI, ncm.lfMessageFont.lfFaceName, 32))
			lstrcpy(ncm.lfMessageFont.lfFaceName, szI);
		
		i = GetRCInt("ecsmessagefontheight", ncm.lfMessageFont.lfHeight);
		if(i > 0) { i = -MulDiv(i, GDC, 72); }
		ncm.lfMessageFont.lfHeight = i;
		
		ncm.lfMessageFont.lfWeight = GetRCInt("ecsmessagefontweight", ncm.lfMessageFont.lfWeight);
		ncm.lfMessageFont.lfItalic = GetRCInt("ecsmessagefontitalic", ncm.lfMessageFont.lfItalic);
		
		SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, /*SPIF_UPDATEINIFILE |*/ SPIF_SENDCHANGE);
	}
	
	/* update the colors last... looks nicer since the font stuff takes more time than the color inits! */
	SetSysColors(31,colornum, colorref);
}


/***************************************************************************/

void ecs_setsyscolor(int colornum, LPCSTR args)
{
	char hexy[32];
	if(!GetToken(args, hexy, &args, FALSE))
		return;
	int r, g, b;
	sscanf( hexy, "%02X%02X%02X", &r,&g,&b );
	COLORREF colorref = RGB(r,g,b);
	SetSysColors(1,&colornum, &colorref);
}

void bang_ecssetcolorscrollbar(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(0, args);
}
void bang_ecssetcolorbackground(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(1, args);
}
void bang_ecssetcoloractivecaption(HWND caller, LPCSTR args)
{
	ecs_setsyscolor(2, args);
}
void bang_ecssetcolorinactivecaption(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(3, args);
}
void bang_ecssetcolormenu(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(4, args);
}
void bang_ecssetcolorwindow(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(5, args);
}
void bang_ecssetcolorwindowframe(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(6, args);
}
void bang_ecssetcolormenutext(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(7, args);
}
void bang_ecssetcolorwindowtext(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(8, args);
}
void bang_ecssetcolorcaptiontext(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(9, args);
}
void bang_ecssetcoloractiveborder(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(10, args);
}
void bang_ecssetcolorinactiveborder(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(11, args);
}
void bang_ecssetcolorappworkspace(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(12, args);
}
void bang_ecssetcolorhighlight(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(13, args);
}
void bang_ecssetcolorhighlighttext(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(14, args);
}
void bang_ecssetcolorbtnface(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(15, args);
}
void bang_ecssetcolorbtnshadow(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(32, args);
}
void bang_ecssetcolorgraytext(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(17, args);
}
void bang_ecssetcolorbtntext(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(18, args);
}
void bang_ecssetcolorinactivecaptiontext(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(19, args);
}
void bang_ecssetcolorbtnhighlight(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(20, args);
}
void bang_ecssetcolor3ddkshadow(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(21, args);
}
void bang_ecssetcolor3dlight(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(22, args);
}
void bang_ecssetcolorinfotext(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(23, args);
}
void bang_ecssetcolorinfobk(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(24, args);
}
void bang_ecssetcolorhotlight(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(26, args);
}
void bang_ecssetcolorgradientactivecaption(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(27, args);
}
void bang_ecssetcolorgradientinactivecaption(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(28, args);
}

void bang_ecssetcolormenuhilight(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(29, args);
}
void bang_ecssetcolormenubar(HWND caller, LPCSTR args) 
{
	ecs_setsyscolor(30, args);
}
// Microsoft stubs

void bang_ecssetcolordesktop(HWND caller, LPCSTR args) 
{		 
	bang_ecssetcolorbackground(caller, args);
}
void bang_ecssetcolor3dface(HWND caller, LPCSTR args) 
{		 
	bang_ecssetcolorbtnface(caller, args);
}
void bang_ecssetcolor3dshadow(HWND caller, LPCSTR args) 
{		 
	bang_ecssetcolorbtnshadow(caller, args);
}
void bang_ecssetcolor3dhighlight(HWND caller, LPCSTR args) 
{	   
	bang_ecssetcolorbtnhighlight(caller, args);
}
void bang_ecssetcolor3dhilight(HWND caller, LPCSTR args) 
{	   
	bang_ecssetcolorbtnhighlight(caller, args);
}
void bang_ecssetcolorbtnhilight(HWND caller, LPCSTR args) 
{	   
	bang_ecssetcolorbtnhighlight(caller, args);
}

// NONCLIENTMETRICS from now on
void bang_ecssetncmborderwidth(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.iBorderWidth = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmscrollwidth(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.iScrollWidth = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmscrollheight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.iScrollHeight = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmcaptionwidth(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.iCaptionWidth = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmcaptionheight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.iCaptionHeight = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmsmallcaptionwidth(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.iSmCaptionWidth = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmsmallcaptionheight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.iSmCaptionHeight = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmenuwidth(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.iMenuWidth = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmenuheight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.iMenuHeight = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmcaptionfontfacename(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfCaptionFont.lfFaceName, szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmcaptionfontheight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	
	int i = atoi(szI);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfCaptionFont.lfHeight = i;
	
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmcaptionfontweight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfCaptionFont.lfWeight = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmcaptionfontitalic(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfCaptionFont.lfItalic = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmsmallcaptionfontfacename(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfSmCaptionFont.lfFaceName, szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmsmallcaptionfontheight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	
	int i = atoi(szI);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfSmCaptionFont.lfHeight = i;
	
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmsmallcaptionfontweight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfSmCaptionFont.lfWeight = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmsmallcaptionfontitalic(HWND caller, LPCSTR args)
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfSmCaptionFont.lfItalic = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmenufontfacename(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfMenuFont.lfFaceName, szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmenufontheight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	
	int i = atoi(szI);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfMenuFont.lfHeight = i;
	
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmenufontweight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfMenuFont.lfWeight = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmenufontitalic(HWND caller, LPCSTR args)
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfMenuFont.lfItalic = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmstatusfontfacename(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfStatusFont.lfFaceName, szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmstatusfontheight(HWND caller, LPCSTR args)
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	
	int i = atoi(szI);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfStatusFont.lfHeight = i;
	
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmstatusfontweight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfStatusFont.lfWeight = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmstatusfontitalic(HWND caller, LPCSTR args)
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfStatusFont.lfItalic = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmessagefontfacename(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfMessageFont.lfFaceName, szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmessagefontheight(HWND caller, LPCSTR args)
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	
	int i = atoi(szI);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfMessageFont.lfHeight = i;
	
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmessagefontweight(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfMessageFont.lfWeight = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmessagefontitalic(HWND caller, LPCSTR args) 
{	   
	char szI[32];
	if(!GetToken(args, szI, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	ncm.lfMessageFont.lfItalic = atoi(szI);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
// and some combinations
void bang_ecssetncmcaptionfont(HWND caller, LPCSTR args)
{	   
	char szI[32];
	char szJ[32];
	char szK[32];
	char szL[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	if(!GetToken(args, szJ, &args, FALSE))
		return;
	if(!GetToken(args, szK, &args, FALSE))
		return;
	if(!GetToken(args, szL, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfCaptionFont.lfFaceName, szI);
	
	int i = atoi(szJ);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfCaptionFont.lfHeight = i;
	
	ncm.lfCaptionFont.lfWeight = atoi(szK);
	ncm.lfCaptionFont.lfItalic = atoi(szL);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}

void bang_ecssetncmsmallcaptionfont(HWND caller, LPCSTR args)
{	   
	char szI[32];
	char szJ[32];
	char szK[32];
	char szL[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	if(!GetToken(args, szJ, &args, FALSE))
		return;
	if(!GetToken(args, szK, &args, FALSE))
		return;
	if(!GetToken(args, szL, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfSmCaptionFont.lfFaceName, szI);
	
	int i = atoi(szJ);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfSmCaptionFont.lfHeight = i;
	
	ncm.lfSmCaptionFont.lfWeight = atoi(szK);
	ncm.lfSmCaptionFont.lfItalic = atoi(szL);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmenufont(HWND caller, LPCSTR args)
{	   
	char szI[32];
	char szJ[32];
	char szK[32];
	char szL[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	if(!GetToken(args, szJ, &args, FALSE))
		return;
	if(!GetToken(args, szK, &args, FALSE))
		return;
	if(!GetToken(args, szL, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfMenuFont.lfFaceName, szI);
	
	int i = atoi(szJ);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfMenuFont.lfHeight = i;
	
	ncm.lfMenuFont.lfWeight = atoi(szK);
	ncm.lfMenuFont.lfItalic = atoi(szL);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmstatusfont(HWND caller, LPCSTR args)
{	   
	char szI[32];
	char szJ[32];
	char szK[32];
	char szL[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	if(!GetToken(args, szJ, &args, FALSE))
		return;
	if(!GetToken(args, szK, &args, FALSE))
		return;
	if(!GetToken(args, szL, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfStatusFont.lfFaceName, szI);
	
	int i = atoi(szJ);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfStatusFont.lfHeight = i;
	
	ncm.lfStatusFont.lfWeight = atoi(szK);
	ncm.lfStatusFont.lfItalic = atoi(szL);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}
void bang_ecssetncmmessagefont(HWND caller, LPCSTR args)
{	   
	char szI[32];
	char szJ[32];
	char szK[32];
	char szL[32];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	if(!GetToken(args, szJ, &args, FALSE))
		return;
	if(!GetToken(args, szK, &args, FALSE))
		return;
	if(!GetToken(args, szL, &args, FALSE))
		return;
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	if(!SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL))
		return; 
	lstrcpy(ncm.lfMessageFont.lfFaceName, szI);
	
	
	int i = atoi(szJ);
	if(i > 0) { i = -MulDiv(i, GetDeviceCaps(GetDC(NULL), LOGPIXELSY), 72); }
	ncm.lfMessageFont.lfHeight = i;
	
	ncm.lfMessageFont.lfWeight = atoi(szK);
	ncm.lfMessageFont.lfItalic = atoi(szL);
	SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}

// general stuff
void bang_ecssavetorc(HWND caller, LPCSTR args)
{	
	char szI[4096];
	if(!GetToken(args, szI, &args, TRUE))
		return;
	ecssavecurrentsettings(szI);
}

void ecssavecurrentsettings(LPCSTR szI)
{
	FILE *f = fopen(szI, "wb");
	if(!f)
		return;
	fprintf(f, "\r\n");
	
	COLORREF tmpColor = GetSysColor(0);
	fprintf(f, "ecsscrollbarcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(1);
	fprintf(f, "ecsbackgroundcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(2);
	fprintf(f, "ecsactivecaptioncolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(3);
	fprintf(f, "ecsinactivecaptioncolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(4);
	fprintf(f, "ecsmenucolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(5);
	fprintf(f, "ecswindowcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(6);
	fprintf(f, "ecswindowframecolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(7);
	fprintf(f, "ecsmenutextcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(8);
	fprintf(f, "ecswindowtextcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(9);
	fprintf(f, "ecscaptiontextcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(10);
	fprintf(f, "ecsactivebordercolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(11);
	fprintf(f, "ecsinactivebordercolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(12);
	fprintf(f, "ecsappworkspacecolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(13);
	fprintf(f, "ecshighlightcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(14);
	fprintf(f, "ecshighlighttextcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(15);
	fprintf(f, "ecsbtnfacecolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(16);
	fprintf(f, "ecsbtnshadowcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(17);
	fprintf(f, "ecsgraytextcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(18);
	fprintf(f, "ecsbtntextcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(19);
	fprintf(f, "ecsinactivecaptiontextcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(20);
	fprintf(f, "ecsbtnhighlightcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(21);
	fprintf(f, "ecs3ddkshadowcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(22);
	fprintf(f, "ecs3dlightcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(23);
	fprintf(f, "ecsinfotextcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(24);
	fprintf(f, "ecsinfobkcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(26);
	fprintf(f, "ecshotlightcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(27);
	fprintf(f, "ecsgradientactivecaptioncolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(28);
	fprintf(f, "ecsgradientinactivecaptioncolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(29);
	fprintf(f, "ecsmenuhilightcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	tmpColor = GetSysColor(30);
	fprintf(f, "ecsmenubarcolor %02X%02X%02X\r\n", GetRValue(tmpColor), GetGValue(tmpColor), GetBValue(tmpColor));
	
	
	fprintf(f, "\r\n");
	
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm, NULL);
	
	fprintf(f, "ecsborderwidth %d\r\n", ncm.iBorderWidth);
	fprintf(f, "ecsscrollwidth %d\r\n", ncm.iScrollWidth);
	fprintf(f, "ecsscrollheight %d\r\n", ncm.iScrollHeight);
	fprintf(f, "ecscaptionwidth %d\r\n", ncm.iCaptionWidth);
	fprintf(f, "ecscaptionheight %d\r\n", ncm.iCaptionHeight);
	fprintf(f, "ecssmallcaptionwidth %d\r\n", ncm.iSmCaptionWidth);
	fprintf(f, "ecssmallcaptionheight %d\r\n", ncm.iSmCaptionHeight);
	fprintf(f, "ecsmenuwidth %d\r\n", ncm.iMenuWidth);
	fprintf(f, "ecsmenuheight %d\r\n", ncm.iMenuHeight);
	fprintf(f, "ecscaptionfontfacename \"%s\"\r\n", ncm.lfCaptionFont.lfFaceName);
	
	int i = ncm.lfCaptionFont.lfHeight;
	if(i < 0) { i = -MulDiv(i, 72, GetDeviceCaps(GetDC(NULL), LOGPIXELSY)); }
	fprintf(f, "ecscaptionfontheight %d\r\n", i);
	
	fprintf(f, "ecscaptionfontweight %d\r\n", ncm.lfCaptionFont.lfWeight);
	fprintf(f, "ecscaptionfontitalic %d\r\n", ncm.lfCaptionFont.lfItalic);
	fprintf(f, "ecssmallcaptionfontfacename \"%s\"\r\n", ncm.lfSmCaptionFont.lfFaceName);
	
	i = ncm.lfSmCaptionFont.lfHeight;
	if(i < 0) { i = -MulDiv(i, 72, GetDeviceCaps(GetDC(NULL), LOGPIXELSY)); }
	fprintf(f, "ecssmallcaptionfontheight %d\r\n", i);
	
	fprintf(f, "ecssmallcaptionfontweight %d\r\n", ncm.lfSmCaptionFont.lfWeight);
	fprintf(f, "ecssmallcaptionfontitalic %d\r\n", ncm.lfSmCaptionFont.lfItalic);
	fprintf(f, "ecsmenufontfacename \"%s\"\r\n", ncm.lfMenuFont.lfFaceName);
	
	
	i = ncm.lfMenuFont.lfHeight;
	if(i < 0) { i = -MulDiv(i, 72, GetDeviceCaps(GetDC(NULL), LOGPIXELSY)); }
	fprintf(f, "ecsmenufontheight %d\r\n", i);
	
	fprintf(f, "ecsmenufontweight %d\r\n", ncm.lfMenuFont.lfWeight);
	fprintf(f, "ecsmenufontitalic %d\r\n", ncm.lfMenuFont.lfItalic);
	fprintf(f, "ecsstatusfontfacename \"%s\"\r\n", ncm.lfStatusFont.lfFaceName);
	
	i = ncm.lfStatusFont.lfHeight;
	if(i < 0) { i = -MulDiv(i, 72, GetDeviceCaps(GetDC(NULL), LOGPIXELSY)); }
	fprintf(f, "ecsstatusfontheight %d\r\n", i);
	
	fprintf(f, "ecsstatusfontweight %d\r\n", ncm.lfStatusFont.lfWeight);
	fprintf(f, "ecsstatusfontitalic %d\r\n", ncm.lfStatusFont.lfItalic);
	fprintf(f, "ecsmessagefontfacename \"%s\"\r\n", ncm.lfMessageFont.lfFaceName);
	
	
	i = ncm.lfMessageFont.lfHeight;
	if(i < 0) { i = -MulDiv(i, 72, GetDeviceCaps(GetDC(NULL), LOGPIXELSY)); }
	
	fprintf(f, "ecsmessagefontheight %d\r\n", i);
	
	fprintf(f, "ecsmessagefontweight %d\r\n", ncm.lfMessageFont.lfWeight);
	fprintf(f, "ecsmessagefontitalic %d\r\n", ncm.lfMessageFont.lfItalic);
	fclose(f);
}

void bang_ecsdisablevisualstyles(HWND caller, LPCSTR args)
{
	BOOL iLL = FALSE;
	HMODULE hUX = GetModuleHandle("UxTheme.dll");
	if(hUX == NULL)
	{
		hUX = LoadLibrary("UxTheme.dll");
		iLL = TRUE;
	}
	if(hUX != NULL)
	{
		HRESULT (__stdcall * EnableTheming)(BOOL) = NULL;
		EnableTheming = (HRESULT (__stdcall *)(BOOL))GetProcAddress(hUX, "EnableTheming");
		if (EnableTheming)
		{
			EnableTheming(FALSE);
		}
		if(iLL)
		{
			FreeLibrary(hUX);
		}
	}
}

/*void bang_ecsabout(HWND caller, LPCSTR args)
{
	MessageBox(NULL, "ECS 1.0.0.0\r\nThe module is licensed GNU GPL v2.\r\nCopyright � 2002 - 2006 Mike Edward Moras. All rights reserved.\r\n\r\nFor more information, please read the documentation.", "About ECS", MB_OK | MB_ICONINFORMATION | MB_TOPMOST);
}*/

