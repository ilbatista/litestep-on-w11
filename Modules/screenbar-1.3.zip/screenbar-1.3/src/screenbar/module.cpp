/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenbar.hpp"

HINSTANCE dllInstance;
string modulePath;
VWM *vwm = NULL;
const char *traceFilename = "screenbar.log";

ULONG_PTR gdiplusToken;

//=========================================================
// Module initialization and cleanup
//=========================================================
int initModuleEx(HWND parentWindow, HINSTANCE dllInstance, LPCSTR path)
{
	::dllInstance = dllInstance;
	::modulePath = path;
	
	if(getConfigBool("Trace", false))
		trace.enable();
	
	if(parentWindow == GetLitestepWnd())
		parentWindow = NULL;
	
	if(getConfigBool("UseDefaultConfig", true))
		loadDefaultSettings();
	
	settings = new RCSettings();
	settings->refresh();
	
	ScreenbarWindow::registerWindowClass();
	DragWindow::registerWindowClass();
	ToolTipWindow::registerWindowClass();
	
	Gdiplus::GdiplusStartupInput gdiInitOptions;
	Gdiplus::GdiplusStartup(&gdiplusToken, &gdiInitOptions, NULL);
	
	layoutPool = new LayoutPool();
	monitors = new MonitorPool();
	
	snapshotManager = new SnapshotManager();
	windowTracker = new WindowTracker();
	processTracker = new ProcessTracker();
	vwm = new VWM(parentWindow);
	
	bangManager->initBangs();
	vwm->initDesktops();
	vwm->initPanels(parentWindow);
	
	windowTracker->update();
	vwm->updateLayouts();
	
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	closeToolTip();
	
	vwm->saveState();
	vwm->destroyPanels();
	
	delete vwm;
	delete processTracker;
	delete windowTracker;
	delete snapshotManager;
	delete monitors;
	delete layoutPool;
	delete settings;
	bangManager->cleanupBangs();
	
	ScreenbarWindow::unregisterWindowClass();
	DragWindow::unregisterWindowClass();
	ToolTipWindow::unregisterWindowClass();
	
	Gdiplus::GdiplusShutdown(gdiplusToken);
	
	trace.close();
}
