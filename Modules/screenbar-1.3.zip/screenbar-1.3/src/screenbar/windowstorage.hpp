/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

class DeskSlot
{
public:
	virtual Rect getRect() const=0;
	
	void transferFrom(Rect &rect, DeskSlot *prev) const;
	void storeRect(Rect &rect) const;
	void unstoreRect(Rect &rect) const;
	void storePoint(POINT &point) const;
	void unstorePoint(POINT &point) const;
};

class StorageArea
	:public DeskSlot
{
public:
	StorageArea(Rect &rect);
	~StorageArea();
	
	Rect getRect() const;
	void release();
	
private:
	friend class StorageManager;
	StorageArea(StorageManager *owner, int index, int x, int y);
	
	int index;
	StorageManager *owner;
	int x;
	int y;
};

class StorageManager
{
public:
	StorageManager();
	~StorageManager();
	
	StorageArea *getStorageArea();
	void releaseStorageArea(StorageArea *area);
	void createArea();
	
	void save(std::ostream &stream);
	void restore(std::istream &stream);
	void saveDesk(VirtualDesktop *desk, std::ostream &stream);
	VirtualDesktop *restoreDesk(std::istream &stream);
	
private:
	int spacingX;
	int spacingY;
	
	vector<StorageArea*> areas;
	set<int> unusedAreas;
	int maxArea;
};

