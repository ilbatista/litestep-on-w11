/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

const char *const defaultSettingPrefix = "sb";

// There are two settings of config-getting functions here, one with default
// values and one without. If no default value is provided, the setting must
// be defined (otherwise, an error dialog will pop up). Base settings may be
// defined in the default-config file, so undefined-config errors should only
// pop up in vars with calculated names.
int getConfigInt(const char *name, const char *prefix=defaultSettingPrefix);
float getConfigFloat(const char *name, const char *prefix=defaultSettingPrefix);
COLORREF getConfigColor(const char *name, const char *prefix=defaultSettingPrefix);
int getConfigCoord(const char *name, int limit, const char *prefix=defaultSettingPrefix);
bool getConfigBool(const char *name, const char *prefix=defaultSettingPrefix);

int getConfigInt(const char *name, int defaultValue, const char *prefix=defaultSettingPrefix);
float getConfigFloat(const char *name, float defaultValue, const char *prefix=defaultSettingPrefix);
COLORREF getConfigColor(const char *name, int r, int g, int b, const char *prefix=defaultSettingPrefix);
string getConfigString(const char *name, const char *defaultValue=NULL, const char *prefix=defaultSettingPrefix);
string getConfigLine(const char *name, const char *defaultValue=NULL, const char *prefix=defaultSettingPrefix);
int getConfigCoord(const char *name, int defaultValue, int limit, const char *prefix=defaultSettingPrefix);
bool getConfigBool(const char *name, bool defaultValue, const char *prefix=defaultSettingPrefix);

void setConfigInt(const char *varname, int value, const char *prefix=defaultSettingPrefix);
void setConfigLine(const char *varname, const char *value, const char *prefix=defaultSettingPrefix);
void setConfigBool(const char *varname, bool value, const char *prefix=defaultSettingPrefix);

void loadDefaultSettings();
bool rcIsDefined(const char *name);
bool rcIsDefined(const char *name, const char *prefix);

struct RCSettings
{
public:
	~RCSettings();
	void refresh();
	
	// Behavior settings
	bool keepEmptyDesktops;
	bool keepEmptyFocusedDesktop;
	bool autoGather;
	bool rescueOffScreenWindows;
	bool trackProcesses;
	int pollInterval;
	int hoverTrackingInterval;
	int backgroundSnapshotInterval;
	int foregroundSnapshotInterval;
	string altTabMonitor;
	string panels;
};

extern RCSettings *settings;

