installation:
--------------------------------------------
just like any other litestep module...

loadmodule cleanup.dll

this little module adds 3 bangs to litestep:
--------------------------------------------

!cleandoc

cleans the recent documents list

!cleanbin

empty the recycle bin

!cleanup

clear both the list and the bin

--------------------------------------------
(c)2002 memoras / e-sushi
