mDesktop is a desktop module based on the desktop2 source code. Listed below 
is the various fixes and enhancements. Most notable is the DesktopBackground 
settings which will make the specified image the background image of the 
desktop window. This is not the same as the Window's desktop image, in fact, 
the Window's desktop image should be disabled if you use this feature. If you 
are using a png-enabled version of LiteStep, then you are able to specify a 
PNG for the background image. As of this release, only centering the image is 
support (not stretching or tiling). 

There is no readme in the zips, jsut a changes.txt.. all commands unless 
noted otherwise are exactly the same as desktop2.

http://www.vinyards.net/mdesktop1001.zip
http://www.vinyards.net/mdesktop1001-src.zip

Changes from latest Desktop2:
  - Added DesktopBackground settings center the supplied image within the 
    desktop window, image is centered, png images supported if you are using
    a png-enabled version of litestep
    (I haven't tested this, but anyone using a multiple monitor setup with the
     desktop stretched across all windows should be able to specificy an image
     large enough to stretch across all monitors seamlessly... YMMV...) 
  - Added !DesktopSetBackground... changes the background to the specified
    image
  - Fixed some processing in the *Desktop line parsing
  - General Code formatting
  - Added version info resource

------------------
from Message, to the LS Mailing List
2002.03.17

this readme included by rootrider (shellfront.org)