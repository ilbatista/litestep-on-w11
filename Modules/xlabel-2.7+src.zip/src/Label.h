#if !defined(__LABEL_H)
#define __LABEL_H

class Font;
class Texture;

//Alpha Transparency
typedef DWORD (WINAPI *PSLWA)(HWND, DWORD, BYTE, DWORD);

#define WS_EX_LAYERED           0x00080000    

#define LWA_COLORKEY            0x00000001
#define LWA_ALPHA               0x00000002

static PSLWA pSetLayeredWindowAttributes = NULL;
static BOOL initialized = FALSE;
//-----------------------------------------------------

//HTMLText
typedef VOID (*DRAWHTMLPARSEDTEXT)(HDC destLabelDC, LPCSTR Text, LOGFONT lf, int Color, RECT Position, int Alignment, int VAlignment);

static HMODULE m_PluginText = NULL;

static DRAWHTMLPARSEDTEXT UseDrawHtmlParsedText = NULL;
//-----------------------------------------------------

//Anim
enum EffectType {
		Random=-1,
		Spin=0,
		Vortex=1,
		ScatterGather=2,
		Spike=3,
		Fireworks=4
	};

typedef VOID (*ANIMSHOW)(RECT rcWindow, EffectType effect, int iSteps, int iAfterimages, int iDelay = 10);
typedef VOID (*ANIMHIDE)(RECT rcWindow, EffectType effect, int iSteps, int iAfterimages, int iDelay = 10);

static HMODULE m_PluginAnim = NULL;

static ANIMSHOW UseAnimShow = NULL;
static ANIMHIDE UseAnimHide = NULL;
//-----------------------------------------------------

class Label
{
public:

	Label(const string &name);
	virtual ~Label();

	void load(HINSTANCE hInstance, HWND box = 0);
	void desktopload(HINSTANCE hInstance, string configLine = "");
	void shortcutload(HINSTANCE hInstance, string configLine = "", int lastx = 0, int lasty = 0);

	void reconfigure();
	void desktopreconfigure(string configLine);
	void shortcutreconfigure(string configLine, int lastx, int lasty);

	Texture *getBackground() const { return background; }
	Font *getFont() const { return font; }

	bool isAlwaysOnTop() const { return alwaysOnTop; }
	bool isGhosted() const { return ghosted; }
	bool isVisible() const { return visible; }
	bool isScrolling() const { return scroll; }
	bool bUseFahrenheit;
	
	int getHeight() const { return actualheight; }
	int getWidth() const { return actualwidth; }
	int getX() const { return actualx; }
	int getY() const { return actualy; }

	int getAlign() { return align; }
	int getVertAlign() { return vertAlign; }
	int getUpdateInterval() { return updateInterval; }

	int getLeftBorder() const { return leftBorder; }
	int getTopBorder() const { return topBorder; }
	int getRightBorder() const { return rightBorder; }
	int getBottomBorder() const { return bottomBorder; }

	const HWND &getBox() const { return box; }
	const string &getName() const { return name; }
	const string &getText() const { return text; }

	void setAlign(int align);
	void setAlwaysOnTop(bool alwaysOnTop);
	void setGhosted(bool ghosted);
	void setBox(HWND newparent);
	void setBackground(Texture *background);
	void setFont(Font *font);
	void setText(const string &text);
	void setUpdateInterval(int updateInterval);
	void setLeftBorder(int leftBorder);
	void setTopBorder(int topBorder);
	void setRightBorder(int rightBorder);
	void setBottomBorder(int bottomBorder);
	void setScrolling(bool scrolling);
	void setScrollLimit(int limit);
	void setVertAlign(int vertAlign);
	void setAlpha(int factor = 255);

	bool checkRegion(int x, int y, StringList inputlist);
	bool checkenterleaveRegion(int x, int y);
	
	void repaint(bool invalidateCache = false);

	void move(int newx, int newy, int steps = 0, int time = 0);
	void reposition(int newx, int newy, int newwidth, int newheight, int steps = 0, int time = 0);
	void resize(int newwidth, int newheight, int steps = 0, int time = 0);

	void internalHide();
	void internalShow();
	void hide();
	void show();
	void showHide(double timeout);

	void previous();
	void next();
	void update();

	void clipboardCopy(string prefix);
	void clipboardPaste(string prefix);

	void mzscriptvarcopy(string var);
	void posmzscriptvarcopy(string varx, string vary);
	void sizemzscriptvarcopy(string varcx, string varcy);

	//Desktop
	string iconCommand;
	bool rememberPosition;

	string configSavePath;

	//Label/Shortcut Group
	string labelGroup;

	//AutoSize
	int autoWidthMode;
	int autoHeightMode;

private:

	HWND hWnd;
	HINSTANCE hInstance;
	HWND box;

	HDC backgroundDC;
	HDC bufferDC;
	HBITMAP backgroundBitmap;
	HBITMAP bufferBitmap;

	int newlineCounter;
	string longestTextLine;

	bool hoverActive;
	bool pressedActive;

	bool useHover;
	bool usePressed;

	Texture *background;
	Font *font;

	bool alwaysOnTop;
	bool canBeVisible;
	bool visible;
	bool bUsingDefSkin;
	bool bInDestructor;

	int actualheight;
	int actualwidth;
	int actualx;
	int actualy;

	int shadowY; // V

	int scrollPadLength;
	int scrollInterval;
	int scrollSpeed;
	bool scroll;
	int scrollPosition;
	UINT scrollLimit;

	//AutoSize
	int autoMinWidth;
	int autoMinHeight;
	int autoMaxWidth;
	int autoMaxHeight;
	int startCenterX;
	int startCenterY;

	int transparencyMode;
	int alphaTransparency;
	bool alphaFade;
	bool ghosted;

	int align;
	int vertAlign;
	int updateInterval;
	bool alwaysUpdateContent;

	int leftBorder;
	int topBorder;
	int rightBorder;
	int bottomBorder;

	string name;

	bool dynamicText;
	vector<string> originalText;
	int current;
	string text;
	string tooltip;

	bool textChange;

	bool desktopItem;
	bool lineBreak;
	int UpdateAlpha;

	bool mousePressed;
	bool mouseInside;

	string leftClickCommand;
	string leftDoubleClickCommand;
	string middleClickCommand;
	string middleDoubleClickCommand;
	string rightClickCommand;
	string rightDoubleClickCommand;
	string wheelDownCommand;
	string wheelUpCommand;
	string enterCommand;
	string leaveCommand;
	string dropCommand;
	string textChangeCommand;

	POINT savedpt;
	bool movemodifierkeyPressed;
	int moveButtonPressed;

	bool moveable;
	int moveKey;
	int moveButton;

	StringList labelLeftClickRegions;
	StringList labelRightClickRegions;
	StringList labelMiddleClickRegions;

	string enterleaveRegion;

	//Plugins Setup
	bool htmltext;

	bool anim;
	EffectType animEffect;
	int animSteps;
	int animDelay;
	int animAfterSteps;

protected:

	//Plugins Setup
	bool InitializeDLL(string pluginName);

	void updateRegion(int drawImage);

	void ReorderZOrder();

	HWND TooltipHints;
	char oldtooltiptext[256];

	void addHint(HWND hWnd, LPSTR caption);
	void updateHint(HWND hWnd, LPSTR caption);
	void removeHint(HWND hWnd);

	BOOL UpdateWindowTransparent(HWND hWnd, unsigned char factor);

	void relayMouseMessageToBox(UINT message, WPARAM wParam, LPARAM lParam);

	virtual void onLButtonDblClk(int x, int y);
	virtual void onLButtonDown(int x, int y);
	virtual void onLButtonUp(int x, int y);
	virtual void onMButtonDblClk(int x, int y);
	virtual void onMButtonDown(int x, int y);
	virtual void onMButtonUp(int x, int y);
	virtual void onRButtonDblClk(int x, int y);
	virtual void onRButtonDown(int x, int y);
	virtual void onRButtonUp(int x, int y);
	virtual void onWheelDown(int x, int y);
	virtual void onWheelUp(int x, int y);
	virtual void onMouseEnter();
	virtual void onMouseLeave();
	virtual void onMouseMove(int x, int y);
	virtual void onPaint(HDC hDC);
	virtual void onSize(int width, int height);
	virtual void onTimer(int timerID);
	virtual void onWindowPosChanged(WINDOWPOS *windowPos);

	virtual bool onWindowMessage(UINT message, WPARAM wParam, LPARAM lParam, LRESULT &lResult);

public:

	static LRESULT WINAPI windowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
};

#endif
