#if !defined(__FONT_H)
#define __FONT_H

class Font
{
public:

	Font();
	virtual ~Font();

	void configure(const string &prefix, Font *baseFont);
	void apply(HDC hDC, int x, int y, int width, int height, const string &text, unsigned int flags, int vertAlign);
	void measure(HDC hDC, const string &longestTextLine, unsigned int flags, long *width, long *height);
	
	LOGFONT GetLFont() { return createHandle(); }
	int GetColor() { return color; }

	void setColor(int aColor);

	int shadowX; // V
	int shadowY; 
	
private:

	HFONT hFont;

	string name;
	int height;
	int color;

	bool bold;
	bool italic;
	bool underline;

	bool shadow;
	int shadowColor;

	LOGFONT createHandle();
};

#endif
