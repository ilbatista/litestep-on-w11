#if !defined(__BLANKTEXTURE_H)
#define __BLANKTEXTURE_H

#include "Texture.h"

class BlankTexture : public Texture
{
public:

	void configure(const string &prefix, const string &subKey) { }
	void apply(HDC hDC, int x, int y, int width, int height, int imageType) { }
};

#endif
