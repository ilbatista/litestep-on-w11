#include "common.h"
#include "ImageTexture.h"

ImageTexture::ImageTexture()
{
	bitmap = 0;
	hoverbitmap = 0;
	pressedbitmap = 0;

	memoryDC = 0;
	memoryBitmap = 0;

	memoryHoverDC = 0;
	memoryHoverBitmap = 0;

	memoryPressedDC = 0;
	memoryPressedBitmap = 0;
}

ImageTexture::~ImageTexture()	// it seems this destructor is never called
{
	if(bitmap)
	{
		SelectObject(memoryDC, memoryBitmap);
		DeleteObject(bitmap);
	}
	if(memoryDC)
		DeleteDC(memoryDC);

	if(hoverbitmap)
	{
		SelectObject(memoryHoverDC, memoryHoverBitmap);
		DeleteObject(hoverbitmap);
	}
	if(memoryHoverDC)
		DeleteDC(memoryHoverDC);

	if(pressedbitmap)
	{
		SelectObject(memoryPressedDC, memoryPressedBitmap);
		DeleteObject(pressedbitmap);
	}
	if(memoryPressedDC)
		DeleteDC(memoryPressedDC);
}

NameValuePair modeConstants[] =
{
	{ "stretch", MULTIBLT_STRETCH },
	{ "tile", MULTIBLT_TILE },
	{ "tile-horizontal", MULTIBLT_TILEHORIZONTAL },
	{ "tile-vertical", MULTIBLT_TILEVERTICAL },
	{ "tilehorizontal", MULTIBLT_TILEHORIZONTAL },
	{ "tilevertical", MULTIBLT_TILEVERTICAL },
	{ 0, 0 }
};

void ImageTexture::configure(const string &prefix, const string &subKey)
{
	string imageFile = GetRCString(prefix, "Image", "");
	bitmap = LoadLSImage(imageFile.c_str(), 0);
	GetLSBitmapSize(bitmap, &imageWidth, &imageHeight);

	memoryDC = CreateCompatibleDC(0);
	memoryBitmap = (HBITMAP) SelectObject(memoryDC, bitmap);

	imageFile = GetRCString(prefix, "HoverImage", "");
	if (!imageFile.empty())
		hoverbitmap = LoadLSImage(imageFile.c_str(), 0);
	else 
		hoverbitmap = LoadLSImage( (GetRCString(prefix, "Image", "")).c_str(), 0 );
		
	GetLSBitmapSize(hoverbitmap, &hoverimageWidth, &hoverimageHeight);

	memoryHoverDC = CreateCompatibleDC(0);
	memoryHoverBitmap = (HBITMAP) SelectObject(memoryHoverDC, hoverbitmap);

	imageFile = GetRCString(prefix, "PressedImage", "");
	if ( !imageFile.empty() )
		pressedbitmap = LoadLSImage(imageFile.c_str(), 0);
	else if ( !(GetRCString(prefix, "HoverImage", "")).empty() )
		pressedbitmap = LoadLSImage( (GetRCString(prefix, "HoverImage", "")).c_str(), 0 );
	else
		pressedbitmap = LoadLSImage( (GetRCString(prefix, "Image", "")).c_str(), 0 );

	GetLSBitmapSize(pressedbitmap, &pressedimageWidth, &pressedimageHeight);

	memoryPressedDC = CreateCompatibleDC(0);
	memoryPressedBitmap = (HBITMAP) SelectObject(memoryPressedDC, pressedbitmap);

	_saturation = GetRCInt(prefix , "SaturationIntensity", 255, 0, 255);
	_hueIntensity = GetRCInt(prefix , "HueIntensity", 0, 0, 255);
	_hueColor = GetRCColor(prefix, "HueColor", RGB(0, 0, 0));

	if ( stricmp((GetRCString(prefix, "TransparencyMode", "true")).c_str(), "fake") == 0 ) 
		usefakeTransparency = true;
	else
		usefakeTransparency = false;

	leftEdge = GetRCInt(prefix, "ImageLeftEdge", 0, 0);
	topEdge = GetRCInt(prefix, "ImageTopEdge", 0, 0);
	rightEdge = GetRCInt(prefix, "ImageRightEdge", 0, 0);
	bottomEdge = GetRCInt(prefix, "ImageBottomEdge", 0, 0);

	mode = GetRCNamedValue(prefix, "ImageMode", modeConstants, MULTIBLT_STRETCH);

	//Saturation /Hueing Effects
	if (_saturation != 255 || _hueIntensity != 0)
	{
		paintEffects(memoryDC);
		paintEffects(memoryHoverDC);
		paintEffects(memoryPressedDC);
	}
}

void ImageTexture::apply(HDC hDC, int x, int y, int width, int height, int imageType)
{
	if (imageType == 0)
	{
		if(bitmap == 0)
			return;
	}
	else if (imageType == 1)
	{
		if(hoverbitmap == 0)
			return;
	}
	else if (imageType == 2)
	{
		if(pressedbitmap == 0)
			return;
	}

	HDC bufferDC = CreateCompatibleDC(hDC);
	HBITMAP bufferBitmap = CreateCompatibleBitmap(hDC, width, height);
	bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);

	if(usefakeTransparency)
	{
		SetStretchBltMode(bufferDC, STRETCH_DELETESCANS);

		if (imageType == 0)
		{
			MultiBlt(bufferDC, 0, 0, width, height,
			memoryDC, 0, 0, imageWidth, imageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		else if (imageType == 1)
		{
			MultiBlt(bufferDC, 0, 0, width, height,
			memoryHoverDC, 0, 0, hoverimageWidth, hoverimageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		else if (imageType == 2)
		{
			MultiBlt(bufferDC, 0, 0, width, height,
			memoryPressedDC, 0, 0, pressedimageWidth, pressedimageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		
		TransparentBltLS(hDC, x, y, width, height,
			bufferDC, 0, 0,
			RGB(255, 0, 255));
	}
	else
	{
		SetStretchBltMode(hDC, STRETCH_DELETESCANS);

		if (imageType == 0)
		{
			MultiBlt(hDC, x, y, width, height,
			memoryDC, 0, 0, imageWidth, imageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		else if (imageType == 1)
		{
			MultiBlt(hDC, x, y, width, height,
			memoryHoverDC, 0, 0, hoverimageWidth, hoverimageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		else if (imageType == 2)
		{
			MultiBlt(hDC, x, y, width, height,
			memoryPressedDC, 0, 0, pressedimageWidth, pressedimageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
	}

	bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
	DeleteDC(bufferDC);
	DeleteObject(bufferBitmap);
}

void ImageTexture::paintEffects(HDC destHDC)
{
	//Paint Saturation and Hueing Effects in MemoryDC's
	int iy = 0;
	int ix = 0;
	COLORREF cl = 0;
	BYTE r = 0;
	BYTE g = 0;
	BYTE b = 0;
	for(iy = 0; iy < imageHeight; iy++)
	{
		for(ix = 0; ix < imageWidth; ix++)
		{
			cl = GetPixel(destHDC, ix, iy);
			r = GetRValue(cl);
			g = GetGValue(cl);
			b = GetBValue(cl);

			if( !( r == 255 && g == 0 && b == 255 ) )
			{
				// Saturation effect
				if(_saturation != 255)
				{
					BYTE gray = (BYTE)(r * 0.3086 + g * 0.6094 + b * 0.0820);

					r = (BYTE)((r * _saturation + gray * (255 - _saturation) + 255) >> 8);
					g = (BYTE)((g * _saturation + gray * (255 - _saturation) + 255) >> 8);
					b = (BYTE)((b * _saturation + gray * (255 - _saturation) + 255) >> 8);
				}

				// Hue effect
				if(_hueIntensity != 0)
				{
					// The B & R values of the hue is swapped here, can somebody tell me why it only works that way?
					// test normal
					r = (BYTE)((r * (255 - _hueIntensity) + GetRValue(_hueColor) * _hueIntensity + 255) >> 8);
					g = (BYTE)((g * (255 - _hueIntensity) + GetGValue(_hueColor) * _hueIntensity + 255) >> 8);
					b = (BYTE)((b * (255 - _hueIntensity) + GetBValue(_hueColor) * _hueIntensity + 255) >> 8);
				}
			}

			SetPixel(destHDC, ix, iy, RGB(r, g, b));
		}
	}
	//End Saturation / Hueing
}
