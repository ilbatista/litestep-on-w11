#include "stdafx.h"
#include "HTMLDrawer.h"
#include "HTMLFont.h"

#define _MERGE_RDATA_
#include "AggressiveOptimize.h"

/* The one and only exported function */
extern "C"
{
__declspec( dllexport ) void DrawHtmlParsedText(HDC destLabelDC, LPCSTR Text, LOGFONT lf, int Color, RECT Position, int Alignment, int VAlignment);
}

void DrawHtmlParsedText(HDC destLabelDC, LPCSTR Text,
            LOGFONT lf, int Color, RECT Position, int Alignment, int VAlignment)
{
	//Convert into MFC variables
	CDC tmpCDC;
	tmpCDC.Attach(destLabelDC);

	CString strText = Text;

	CHTMLFont fntDefault;
	if (lf.lfWeight == FW_BOLD)
		fntDefault.SetBold(true);
	else
		fntDefault.SetBold(false);
	if (lf.lfItalic)
		fntDefault.SetItalic(true);
	else
		fntDefault.SetItalic(false);
	if (lf.lfUnderline)
		fntDefault.SetUnderline(true);
	else
		fntDefault.SetUnderline(false);

	fntDefault.SetName(lf.lfFaceName);
	fntDefault.SetSize(lf.lfHeight);
	fntDefault.SetCharSet(lf.lfCharSet);
	fntDefault.SetColor(Color);

	CRect rctPosition; 
	rctPosition.left = Position.left;
	rctPosition.right = Position.right;
	rctPosition.top = Position.top;
	rctPosition.bottom = Position.bottom;

	short nAlignment = Alignment;
	short nVAlignment = VAlignment;

	/////////////////////////////////////////////////////////////
	// DrawText
	/////////////////////////////////////////////////////////////
	// Parameters:
	// pDC : Device context
	// strText: Text to be drawn
	// fntDefault : Default font to be used
	// rctPosition : Rectangle in which the text is to be drawn
	// nAlignment: 0 (left) or 1 (centered) or 2 (right)
	/////////////////////////////////////////////////////////////
	CHTMLDrawer::DrawText(&tmpCDC,
							strText,
							fntDefault,
							rctPosition,
							nAlignment,
							nVAlignment);

	tmpCDC.Detach();
}

