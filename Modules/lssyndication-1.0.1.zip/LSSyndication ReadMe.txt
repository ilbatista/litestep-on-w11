------------------------------------------------------------
LSSyndication.dll - LiteStepSyndication, created by Xjill
------------------------------------------------------------

Feature list:
-------------
 +	Supports an unlimited number of RSS feeds (in theory, but currently limited to 200)
 +	Complies to the W3C XML 1.0 standards, and the RSS 2.0 standards (should also support
	RSS ver. 0.91 and 0.92, but not guaranteed)
 +	The only thing limiting how many items you can have is your system memory!
 +	You can customize what RSS elements you want to display
 +	Left-click to open the article in your browser (if the news file includes a link)
 +	Right-click to toggle the scrolling
 +	Middle-click to jump forward to the next source
 +	Use your mouse wheel to scroll through the items
 +	Background images (with magicpink)
 +	Can check if there's been released a newer version of the module
 +	Doesn't update the news locally if the file on the server hasn't changed
 +	Has a MaxAge setting, removing all news older than the specified period (for the feeds
	which include the publication date)
 +	LSBox support
 -	Multiline support coming around v1.1, that is: Vertical scrolling instead of horizontal
 

Available Bang! Commands:
-------------------------
!LssRssUpdate			Re-fetches the news (Does not reload any .rc arguments)
!LssRssBoxHook			Let's LSBox hook LSSyndication (if hooked, you can't use the
				mousewheel, as LSBox currently doesn't support this)

!LssRssAlwaysOnTop		Sets window to be topmost
!LssRssNormalZOrder		Sets the window to be non-topmost

!LssRssStopScrolling		Stops the scrolling of the news
!LssRssStartScrolling		Starts the scrolling
!LssRssToggleScrolling		Toggles the scrolling (right-clicking the window will also
				perform this)

!LssRssNextItem			Jumps forward one item
!LssRssPrevItem			Jumps backwards one item
!LssRssNextSource		Jumps forward to the beginning of the next source

!LssRssShow			Shows the module
!LssRssHide	1		Hides the module, optional argument to continue scrolling (use
					any non-zero value), otherwise it stops scrolling.
!LssRssToggle	1		Toggles the visibility of the module, same argument as above


Available .rc arguments:
------------------------
Use the following entry to add a source, you can add as many as you want, but I have at the
current time limited it to 200 sources, if anybody feels this is to low, just give me a mail
and I'll be more than happy to raise that in future releases. The number on the end is an
optional argument specifying the maximum number of items to display from this source.

*LssRssURL			"yourLinkToRssFileHere"		10


LssRssX				0		The position of the LSSyndication window on
						the X axis. A negative value is relative to
						the right of the screen, an ending 'C' from
						the center. To obtain true negative values
						use '~' in front.

LssRssY				0		Same as LssRssX, but for the Y axis instead.
LssRssWidth			1280		The width of the window
LssRssHeight			20		The height of the window
LssRssVAlign			Top		The vertical alignment of the text, can be
						either Top (default), Center or Bottom.

LssRssFontFace			"verdana"	The font to use (Defaults to "Arial")
LssRssFontSize			14		The size of the text
LssRssFontColor			FFFFFF		The color of the text

LssRssBackgroundColor		CC2222			The background color (in hex)
LssRssBackgroundImage		"FullPath\Image.png"	The background image (stretches if
							smaller than window)

LssRssTransparency		If defined then all parts of the background image that are
				MagicPink (#FF00FF) are transparent (fake transparency)

LssRssNoDescriptions		If defined the <description> of an item is ignored (uses
				only the title)
				
LssRssStripHtml			If defined the module will strip everything in the data
				between < and >	brackets (including brackets defined in
				CDATA sections). This is meant to help remove HTML code
				but won't distinguish between real HTML and other uses
				of these brackets. There really shouldn't be HTML in RSS,
				but since some people still use it, I've included this.

LssRssNoMessageBoxes		If this is set, no message boxes will pop up (you can still
				see the error messages in the LSSyndication window).

LssRssAlwaysOnTop		If this is set the window will be above all other windows

LssRssCheckForNewVersion	If this is set LSSyndication will check whether a new version
				of LSSyndication has been released. (If a new version is found
				this will pop up a message box regardless of
				LssRssNoMessageBoxes)

LssRssStartHidden		Allows the module to start hidden. To later display it, use
				the bang commands !LssRssShow or !LssRssToggle.

LssRssDelimiter			" :: "		The delimiter between the different items
						(Default: " :: "), (if "" (empty), a single
						space is used)

LssRssTitleFormat		"-<title>: "	The data around the title. This is not used if
						LssRssNoDescriptions is defined! If only one
						argument supplied, it uses that on both sides.
						(Default: "<title>: "), can be empty ( "" )
						(equals "<title>")

LssRssLoadingMessage		"Loading..."	If specified, this is what will be shown when
						loading the files, if not, the current staus will
						be shown (like, "Connecting to <server>..." or
						"Processing File...").

LssRssScrollInterval		30		The scrolling update interval (in milliseconds).
						Default: 50

LssRssScrollSpeed		2		The number of pixels to move each scroll update.
						Default: 1

LssRssUpdateInterval		0		The number of minutes to pass before to
						automatically update the news. Never updates
						automatically if set to 0 (which is the default).
						NOTE: Some sites (like slashdot.org) ban your IP
						if you update too often! (slashdot.org sets the
						limit to 30 min, but this can vary from site to
						site)

LssRssMaxAge			0		The maximum age of a news item in hours. Set to
						0 (default) to disable this feature.

LssRssMaxItems			0		The maximum number of items per URL (global number, see also *LssRssURL). Set to 0
						for unlimited (Default)


Known Issues:
-------------
None at the moment :D


Version History:
----------------
- 1.0:
*Fixed bug when LssRssMaxAge where set to 0
*Added LssRssStartHidden
  - .1:
	*Added LssRssVAlign
	*Added LssRssStripHtml
	*Fixed the version checking, which were broken
	*Added argument for !LssRssHide and !LssRssToggle to keep scrolling when hidden

- b0.9:
*Added background images (with magic pink, though not real transparency)
*Fixed a problem with !LssRssNextSource when the first file wasn't valid
*Fixed the network code to use the "If-Modified-Since" header, so it won't update the local news if the file hasn't been modified. This feature eases the load on both the server and you! For servers supporting this feature, this will make the "LssRssUpdateInterval" setting (almost) unnecessary.
  - .1:
	*Quickfix for some bugs
  - .2:
	*Added LssRssMaxAge
	*Added support for ASCII numeral text escapes (like &#039; = ' ) and the most common HTML escapes (like &quest; = ? )
  - .3:
	*Added LssRssCheckForNewVersion
	*Added !LssRssHide, !LssRssShow and !LssRssToggle
	*Added !LssRssNextItem and !LssRssPrevItem
	*Small performance and bug fixes
  - .4:
	*Bug fixes and tweaking
	*Changed LssRssX and LssRssY handling
	*Removed LssRssHugBottom
	*Added LssRssLoadingMessage
	*Added LSBox hook: !LssRssBoxHook


- b0.8:
*Fixed some things which gave (heavy) crashes
  - .1: *Fixed further crashes
  - .2: *Fixed some problems regarding libraries,
	*Fixed LssRssMaxItems
	*Added !LssRssNextSource
	*Did some minor performance improvements

- b0.7:
Completely new network code, and some small fixes all around

- b0.6:
First release, don't know how many had it, probably none :D


------------------------------------------------------------

Please contact me (xjill_IV@hotmail.com) if there's anything you would like improved or you find any bugs!

============================================================
Xjill
xjill_IV@hotmail.com
============================================================
"Everything you perceive, is only the result of your abstraction of the movements of particles"

