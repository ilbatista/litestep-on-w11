/*

	LSUtils

	Author:	Vendicator
	
	Description:
	Class that provides wrappers for reading settings with a prefix
	instead of supplying whole name (ie "Module", "Setting" for "ModuleSetting")

	Requires:

	Changelog:
	[2003-06-12 - Vendicator]
	- Fixed some char* to LPCSTR
	- Using _LSLog from apis.h

	[2002-11-09 - Vendicator]
	- First work?
	
*/

#include "apis.h"
#include "LSUtils.h"
#include "lsapi_location.h"

//#define DEBUG

HINSTANCE LSUtils::LoggedBangExecute(LPCSTR szAppName, HWND Owner, LPCSTR szCommand, int nShowCmd)
{
	_LSLogPrintf(LOG_DEBUG, szAppName, "Running Bang: %s", szCommand);
	return LSExecute(Owner, szCommand, nShowCmd);
}

BOOL LSUtils::PrefixedGetRCLine(LPCSTR prefix, LPCSTR setting, LPSTR buffer, LPCSTR defaultVal)
{
	BOOL res = FALSE;
	char* szTemp = new char[strlen(prefix) + strlen(setting) + 1];
	strcpy(szTemp, prefix);
	strcat(szTemp, setting);
	res = GetRCLine(szTemp, buffer, MAX_LINE_LENGTH, defaultVal);
#ifdef DEBUG
	_LSLogPrintf(LOG_DEBUG, prefix, "looking for setting: %s, got: %s", szTemp, buffer);
#endif
	delete [] szTemp;
	return res;
}

BOOL LSUtils::PrefixedGetRCLine(LPCSTR prefix, LPCSTR setting, LPSTR buffer, UINT maxLen, LPCSTR defaultVal)
{
	BOOL res = FALSE;
	char* szTemp = new char[strlen(prefix) + strlen(setting) + 1];
	strcpy(szTemp, prefix);
	strcat(szTemp, setting);
	res = GetRCLine(szTemp, buffer, maxLen, defaultVal);
#ifdef DEBUG
	_LSLogPrintf(LOG_DEBUG, prefix, "looking for setting: %s, got: %s", szTemp, buffer);
#endif
	delete [] szTemp;
	return res;
}

BOOL LSUtils::PrefixedGetRCString(LPCSTR prefix, LPCSTR setting, LPSTR buffer, LPCSTR defaultString, int maxLen)
{
	BOOL res = FALSE;
	char* szTemp = new char[strlen(prefix) + strlen(setting) + 1];
	strcpy(szTemp, prefix);
	strcat(szTemp, setting);
	res = GetRCString(szTemp, buffer, defaultString, maxLen);
#ifdef DEBUG
	_LSLogPrintf(LOG_DEBUG, prefix, "looking for setting: %s, got: %s", szTemp, buffer);
#endif
	delete [] szTemp;
	return res;
}

BOOL LSUtils::PrefixedGetRCBool(LPCSTR prefix, LPCSTR setting, bool def)
{
	BOOL retValue;
	char* szTemp = new char[strlen(prefix) + strlen(setting) + 1];
	strcpy(szTemp, prefix);
	strcat(szTemp, setting);
	retValue = GetRCBool(szTemp, def);
#ifdef DEBUG
	_LSLogPrintf(LOG_DEBUG, prefix, "looking for setting: %s, got %d", szTemp, retValue);
#endif
	delete [] szTemp;	
	return retValue;
}

int LSUtils::PrefixedGetRCInt(LPCSTR prefix, LPCSTR setting, int nDefault)
{
	char* szTemp = new char[strlen(prefix) + strlen(setting) + 1];
	strcpy(szTemp, prefix);
	strcat(szTemp, setting);
	int retValue = GetRCInt(szTemp, nDefault);
#ifdef DEBUG
	_LSLogPrintf(LOG_DEBUG, prefix, "looking for setting: %s, got %d", szTemp, retValue);
#endif
	delete [] szTemp;
	return retValue;
}

int LSUtils::PrefixedGetRCCoordinate(LPCSTR prefix, LPCSTR setting, int nDefault, int maxVal)
{
	char* szTemp = new char[strlen(prefix) + strlen(setting) + 1];
	strcpy(szTemp, prefix);
	strcat(szTemp, setting);
	int retValue = GetRCCoordinate(szTemp, nDefault, maxVal);
#ifdef DEBUG
	_LSLogPrintf(LOG_DEBUG, prefix, "looking for setting: %s, got: %d", szTemp, retValue);
#endif
	delete [] szTemp;
	return retValue;
}

COLORREF LSUtils::PrefixedGetRCColor(LPCSTR prefix, LPCSTR setting, COLORREF colDef)
{
	char* szTemp = new char[strlen(prefix) + strlen(setting) + 1];
	strcpy(szTemp, prefix);
	strcat(szTemp, setting);
	COLORREF retValue = GetRCColor(szTemp, colDef);
#ifdef DEBUG
	_LSLogPrintf(LOG_DEBUG, prefix, "looking for setting: %s, got: %d", szTemp, retValue);
#endif
	delete [] szTemp;
	return retValue;
}

