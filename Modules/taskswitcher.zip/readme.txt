taskSwitcher just provides 2 bang commands: !SwitchToPreviousTask and !SwitchToNextTask

by Maduin