/****************************************************************************

Todo:
	- Multiple settings, bitmaps a la label?
	- Customizable menu like recycler

Changelog:

2003-06-13 [Vendicator, release 4.3]
	- Using STL instead of homebrewn linked list
	- Added !LSMailClearNew and !LSMailZeroMail
	- Added "LSMailNoText" for disabling text output for those who only want to see different gfx
	  when there is new mail.
	- Started work on a SafeString class using the functions from strsafe.h and converted to TCHAR
	- Included the *line reader for getting server configs.
	- Also using Clickable class, allows for specifying the actions when user clicks window
	- LsMail now uses GuiWindow class for window handling functions (lsbox, toggling etc).
	  Note that the on top handling is slightly different.
	- Started moving some of my classes to a separate folder for code reuse.

2003-05-31 [ilmcuts, release 4.2]:
    - Added !LsMailMenu to show the rightclick menu.
    - Fixed potential access violations (aka crashes).
    - Fixed fonts from charsets other than ANSI_CHARSET not working correctly.
    - Fixed display only being updated when all servers are done retrieving the
      mail count (Vendicator).
    - Fixed LSMailEMailClient requiring quotes and not working reliably with
      parameters.
    - Fixed compatibility with old builds and PureLS (possibly even works with
      0.24.5 now :p).
    - Fixed all compiler warnings on warning level 3 and most on level 4.
    - Restructured readme.

2003-03-23 [ilmcuts, release 4.16]:
    - improved parser, it no longer reparses step.rc but uses the existing cache
    - fixed access violation

2003-01-27 [Vendicator, release 4.15]:
	- The enable/disabled check bangs did the opposite of what they were supposed to do,
	  thanks to Maciej Ligenza for pointing it out
	- Added an extra check in the mailcheck code to get rid of a rare start up error

2003-01-19 [Vendicator, release 4.14]:
	- Added support for LSMailFontBold
	- Moved code a bit
	- Added a check to prevent illegal access to servers before they are set up
	- Made sure to initialize all vars to prevent errors
	- Recreated change (didn't find source) from jesus_mjjg ':' isn't printed anymore when no name is entered

2002-10-30 [Vendicator, release 4.13]:
	- Removed ugly hWnd2 variable hack
	- Moved code out from lsmail.cpp to separate .cpp files, had to resort to a static hack
	  to send the lsmail object to them...
	- Added LsMailBangMode which disables the gui routines for faster functioning

2002-08-27 (Vendicator):
	- Fixed inheritance framework to allow for new server checking later on, thanks Nivenh!

2002-08-25 (Vendicator):
	- Fixed startup window paint before a mail check has been run.
	- Other shells without LSSetvar() in lsapi should be working again, PureLS and others.
	- Also added check for log support in lsapi.dll to be on the safe side
	- Another check for getrccoordinate() added
	- Also reduced mem usage some by removing some redunant ints

2002-08-19 (Vendicator):
	- Fixed stupid timer mistake causing lsmail not to do interval mail checking
	- Sets the following vars after a mail check:
	  LsMailNumMessages [total nr messages], LsMailServer[nr] [nr messages]
	  ie for 2 configed server: LsMailNumMessages 10, LsMailServer1 2 and LsMailServer2 8
	  Requires lsapi version newer than 2002-05-08.

2002-08-18 (Vendicator):
	- Filesize slashed with about 50k, had to use ugly hack by adding hWnd2 as a public HWND for external funtions
	- Added setting to disable mail check "LSMailDisableCheck", use bangs to enable
	  in runtime: !LSMailToggleCheck, !LSMailEnableCheck, !LSMailDisableCheck
	- Added !LsMailMove x y
	- Added LSMailErrorBmp, LSMailBackErrorColor, LSMailErrorFontColor, LSMailErrorCmd per request of... sorry I forgot...
	- !Refresh support

2002-08-13 (Vendicator):
	- Big push towards more OOP
	- Even more code cleaning

2002-07-24 (Vendicator):
	- More move to OOP
	- Fixed memleak in !bang commands removal when recycling
	- Added !LsMailHook for lsbox support
	- Added LSMailNoMessageBoxes, which sends errors as warnings to log file
	- Started rewrite to a more OOP layout, will make it easier to add other server types
	- Added LSMailDoneCheckCmd, per request of Maestr0

2002-05-29 (Vendicator):
	- Added a check so that the password actually is set in .rc if not old style is used
	- LsMail no longer shows up in taskmanager
	- Added killing of lsmail thread on quit, might fix the ls crash on recycle when lsmail was checking.
	- Added LSMailCheckMailCmd, per request of morph, originally added by ilmcuts

2002-05-11 (Jesus_mjjg):
	- now it is possible to specify the password in the step.rc

2002-04-18 (Vendicator):
	- Added a !bang for when there is no mail (LSMailNoMailCmd	!bang)

2002-04-17 (Vendicator):
	- Implemented bitmap for checking state (LSMailCheckingBmp)
	- Fixed clearing/setting of new mail flag (was only taking one server into account before)
	- Added ability to execute a !bang command on new mail (LSMailNewMailCmd	!bang)

2002-04-16 (Vendicator):
	- Clear new mail in popup now works again (was tied to left click action)

2002-04-16 (Vendicator):
	- Since the mail checking routine also clears the new mail flag when
	there is no mail on server, left click action is now checkmail.

2002-04-15 (Vendicator):
	- Added X,Y reading through GetRCCooridinate
	- Now clears new mail flag if 0 mail found on server

****************************************************************************/

#include "LsMail.h"
#include "Servers.h"
#include "pop3server.h"
#include "..\VTK\apis.h"
#include "..\VTK\MultipleConfigReader.h"
#include "LogSetting.h"

#include "..\VTK\BangManager.h"

#include <vector>
using std::vector;

// The module var
LsMail *mail;

const Bang BangMode[] =
{
	{ "!LSMailCheckMail", BangCheckMail },
	{ "!LSMailToggleCheck", BangToggleCheck },
	{ "!LSMailEnableCheck", BangEnableCheck },
	{ "!LSMailDisableCheck", BangDisableCheck },
	{ "!LSMailClearNew", BangClearNewMail },
	{ "!LSMailZeroMail", BangZeroMail }
};

const Bang GuiMode[] =
{
	{ "!LSMailSetOnTop", BangSetOnTop},
	{ "!LSMailShow", BangShow },
	{ "!LSMailHide", BangHide },
	{ "!LSMailToggle", BangToggle },
	{ "!LSMailHook", BangHook },
	{ "!LSMailMove", BangMove },
	{ "!LSMailMenu", BangMenu }
};

// calculate how many bangs there are
const int GuiBangs = sizeof(GuiMode) / sizeof(GuiMode[0]);
const int BangBangs = sizeof(BangMode) / sizeof(BangMode[0]);


//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR /* szPath */)
{
	int code = 0;
	Window::init(dllInst);
	mail = new LsMail(ParentWnd, code, dllInst);
	return code;
}

void quitModule(HINSTANCE /* dllInst */)
{
	if (mail)
    {
        delete mail;
        mail = NULL;
    }
}


//=========================================================
// Bang commands
//=========================================================

void BangHook(HWND /* caller */, LPCTSTR szArgs)
{
	if (mail != NULL)
		mail->BoxHook(szArgs);
}

void BangShow(HWND /* caller */, const char* /* args */)
{
	if (mail != NULL)
		mail->Show();
}

void BangHide(HWND /* caller */, const char* /* args */)
{ 
	if (mail != NULL)
		mail->Hide();
}

void BangSetOnTop(HWND caller, LPCSTR args)
{
	if (stricmp(args, "off") == 0)
		mail->SetOnTop(false);
	else
		mail->SetOnTop(true);
}

void BangToggle(HWND caller, const char* args)
{
	if (mail != NULL)
		mail->ToggleVisibility();
}

void BangCheckMail(HWND /* caller */, const char* /* args */)
{
    mail->CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckAllMail, (LPVOID)NULL, 0, &mail->threadID);
}

void BangToggleCheck(HWND /* caller */, const char* /* args */)
{
    mail->bDisableCheck = !mail->bDisableCheck;
}

void BangEnableCheck(HWND /* caller */, const char* /* args */)
{
    mail->bDisableCheck = false;
}

void BangDisableCheck(HWND /* caller */, const char* /* args */)
{
    mail->bDisableCheck = true;
}

void BangMove(HWND /* caller */, const char *args)
{
    char szX[MAX_LINE_LENGTH], szY[MAX_LINE_LENGTH];
    char *tokens[2] = {szX, szY};
    LCTokenize( args, tokens, 2, NULL );
    mail->Move(atoi(szX), atoi(szY));
}

void BangMenu(HWND /* caller */, const char* /* args */)
{
    POINT pt;
    GetCursorPos(&pt);
    mail->ShowPopup(pt.x, pt.y);
}

void BangZeroMail(HWND /* caller */, const char* /* args */)
{
    mail->ZeroAccounts();
}

void BangClearNewMail(HWND /* caller */, const char* /* args */)
{
    mail->ClearNewMail();
}


//=========================================================
// Module code
//=========================================================

HWND LsMail::GetHWND()
{
	return hWnd;
}

void LsMail::SetWindowBitmapRgn(HBITMAP bmp)
{
	if (hWnd && bmp)
	{
		int x=0, y=0;
		HDC hdc = CreateCompatibleDC(NULL);
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;

		GetObject(bmp, sizeof(bitmap), &bitmap);
		SelectObject(hdc, bmp);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y < bitmap.bmHeight; x=0, y++)
		{
			for (x=0; x < bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == 0x00FF00FF)
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hWnd, hMainRgn, FALSE);

		DeleteDC(hdc);
		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hWnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hWnd, rgn, FALSE);
	}
}

void LsMail::ShowPopup(int x, int y)
{
    TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON,
        x, y, 0, hWnd, NULL); // hwnd?
}

void LsMail::ClearNewMail()
{
	NEWMAIL=false;
	for (Servers::iterator i = servers.begin(); i != servers.end(); ++i) 
	{
		SERVER* s = (*i);
		//s->num=s->newnum; //V
		s->MAIL_STATUS = MAIL_NO;
	}
	InvalidateRect(hWnd, NULL, TRUE); // needed for redraw
}

void LsMail::ZeroAccounts()
{
	for (Servers::iterator i = servers.begin(); i != servers.end(); ++i) 
	{
		SERVER* s = (*i);
		s->MAIL_STATUS = MAIL_NO;
		s->mails_zeroed=s->mails=0;
	}
	InvalidateRect(hWnd, NULL, TRUE);
}


//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------

LsMail::LsMail(HWND parentWnd, int& code, HINSTANCE dllInst):
	GuiWindow(szAppName, parentWnd, false),

	// for work
	hInstance2(NULL),
	hWndParent(NULL),
	bInitialized(false),
	threadID(NULL),
	TIMER(0),
	popup(NULL),
	font(NULL),

	// settings
	bBangMode(false),
	bNoMessageBoxes(false),
	bDisableCheck(false),
	bNoText(false),

	// status
	CHECKING(false),
	NEWMAIL(false),
	ERRORS(false),
	MAIL_STATUS(MAIL_NO),
	Clickable(TEXT("LSMail"))
{
	int msgs[] = {LM_GETREVID, LM_REPAINT, LM_REFRESH, 0};

    InitAPIs();

#ifdef DEBUG_EXTRA
	_LSLogPrintf(LOG_WARNING, szAppName, "*Debug* Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#else
	_LSLogPrintf(LOG_DEBUG, szAppName, "Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#endif

	hWndParent = parentWnd;
	hInstance2 = dllInst;

	SetMouseKey(RIGHT_DOWN, TEXT("!LSMailMenu"));
	SetMouseKey(LEFT_UP, TEXT("!LSMailCheckMail"));
	LoadSetup();

	if ( !CreateWnd(NULL) )
	{
		_LSLog(LOG_ERROR, szAppName, "unable to create window");

		MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
		code = 1;
		return;
	}
	else
	{
		//hWnd2 = hWnd;
		_LSLogPrintf(LOG_DEBUG, szAppName, "window created, 0x%X", hWnd);
	}

	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	bBangMode = GetRCBool("LSMailBangMode", TRUE) ? true : false;

	TIMER=GetRCInt("LSMailTimer", 5);
	if (TIMER)
		SetTimer(hWnd, 0, TIMER*60000, NULL);

	InsertBangs(BangMode, BangBangs);
	if (!bBangMode)
	{
		ReadGUIProps();
		InsertBangs(GuiMode, GuiBangs);
		CreatePopup();
		Show();
	}
	else
		Hide();

    _LSLog(LOG_NOTICE, szAppName, "loaded successfully");
	
	code = 0;
	
	// protect so that the text functions aren't used before everything has been set up
	bInitialized = true;

	CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)::CheckAllMail, (LPVOID)NULL, 0, &threadID);
}

void LsMail::ReadGUIProps()
{
	char temp[MAX_LINE_LENGTH];

	bNoText = GetRCBool("LSMailNoText", TRUE) ? true : false;

	// font settings
	int size = GetRCInt("LSMailFontSize", 12);
	bool bold = GetRCBool("LSMailFontBold", TRUE) ? true : false;
	GetRCString("LSMailFont", temp, "Arial", 256);
	font = CreateFont(size, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);
	color = GetRCColor("LSMailFontColor", 0x00FFFFFF);
	nmcolor = GetRCColor("LSMailNewMailFontColor", 0x000000FF);
	checkcolor = GetRCColor("LSMailCheckingFontColor", 0x000000FF);
	errorcolor = GetRCColor("LSMailErrorFontColor", 0x00FF0000);

	USEBGCOLOR = GetRCBool("LSMailBackColor", TRUE) ? true : false;
	if (USEBGCOLOR) 
	{
		bgcolor = GetRCColor("LSMailBackColor", 0x00000000);
		bgbrush = CreateSolidBrush(bgcolor);

		bgcolor = GetRCColor("LSMailBackNewMailColor", 0x000000FF);
		nmbgbrush = CreateSolidBrush(bgcolor);

		bgcolor = GetRCColor("LSMailBackCheckingColor", 0x00000000);
		checkbgbrush = CreateSolidBrush(bgcolor);

		bgcolor = GetRCColor("LSMailBackErrorColor", 0x00FF0000);
		errorbgbrush = CreateSolidBrush(bgcolor);
	}
	else 
	{
		GetRCString("LSMailBackBmp", temp, "", 256);
		bgbmp = LoadLSImage(temp, temp);

		GetRCString("LSMailNewMailBmp", temp, "", 256);
		newmailbmp = LoadLSImage(temp, temp);

		GetRCString("LSMailCheckingBmp", temp, "", 256);
		checkingbmp = LoadLSImage(temp, temp);

		GetRCString("LSMailErrorBmp", temp, "", 256);
		errorbmp = LoadLSImage(temp, temp);
	}

	if (bgbmp && !USEBGCOLOR)
	{
		SetWindowBitmapRgn(bgbmp);
		_LSLog(LOG_DEBUG, szAppName, "Setting window bitmap region");
	}
}

void LsMail::LoadSetup()
{
    _LSLog(LOG_DEBUG, szAppName, "Loading setup...");

    char temp[MAX_PATH];
    
    bDisableCheck = GetRCBool("LSMailDisableCheck", TRUE) ? true : false;
    bNoMessageBoxes = GetRCBool("LSMailNoMessageBoxes", TRUE) ? true : false;
    
    if (!bBangMode)
    {
		SetPosition(_GetRCCoordinate("LSMailX", 0, GetSystemMetrics(SM_CXSCREEN)),
			_GetRCCoordinate("LSMailY", 0, GetSystemMetrics(SM_CYSCREEN)));

		SetSize(GetRCInt("LSMailW", 400), GetRCInt("LSMailH", 25));
	}
	GetRCLine("LSMailEMailClient", temp, MAX_PATH, "");
	MailClient.assign(temp);

	ReadClickSettings();

	bool hidden = GetRCBool("LSMailStartHidden", TRUE) ? true : false;
	SetVisible(!hidden);

	bool ontop = GetRCBool("LSMailAlwaysOnTop", TRUE) ? true : false;
	SetTop(ontop);
}

void LsMail::ReadServers()
{
	_LSLog(LOG_DEBUG, szAppName, "Reading mail server configs");

	SERVER::RegisterSettings(GetHWND(), hInstance2, !bNoMessageBoxes);

	// *LSMailServer X Y Name host:<port> login
	
	MultipleConfigReader mailservers(TEXT("*LSMailServer"));

	SafeString* config;
	while (mailservers.HasMoreConfigs())
	{
		#ifdef DEBUG_SERVER
			_LSLog(LOG_DEBUG, szAppName, "checking server config");
		#endif

		config = new SafeString(mailservers.GetNextConfig());
		// char?
		SERVER *s = new Pop3Server(config->c_str());

		if (s->Working())
		{
			servers.push_front(s);
		}
		else
		{
			_LSLogPrintf(LOG_ERROR, szAppName, "Error on server: (%d) %s", s->ID, s->name);
			delete s;
		}
	}

	_LSLogPrintf(LOG_DEBUG, szAppName, "Read %d servers", SERVER::ServerCount());
}

void LsMail::onCreate(Message& message)
{
#ifdef DEBUG_EXTRA
	_LSLog(LOG_DEBUG, szAppName, "OnCreate accessed");
#endif

	ReadCommands();
	ReadServers();

	// set always on top
	if (IsOnTop())
		SetOnTop(true);
	else
		SetOnTop(false);
}

void LsMail::CreatePopup()
{
	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CHECKMAIL, "&Check Mail");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_LAUNCHCLIENT, "&Launch E-Mail Client");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CLEARNEWMAIL, "Clear &New Mail");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_ZEROACCOUNTS, "&Zero All Accounts");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_DISPLAYERROR, "&Display Last Error");
	AppendMenu(popup, MF_SEPARATOR, 0, "");

	for (Servers::iterator i = servers.begin(); i != servers.end(); ++i)
	{
		SERVER* s = (*i);
		s->menu = CreatePopupMenu();
		AppendMenu(s->menu, MF_ENABLED | MF_STRING, POPUP_SERVER+s->ID+1, "&Change Password");

		AppendMenu(popup, MF_ENABLED | MF_STRING | MF_POPUP, (int)s->menu, s->name);
	}
}

void LsMail::ReadCommands()
{
    char temp[MAX_LINE_LENGTH] = { 0 };

	GetRCLine("LSMailCheckMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // new mail command
	CheckMailCmd.assign(temp);

	GetRCLine("LSMailNewMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // new mail command
	NewMailCmd.assign(temp);

	GetRCLine("LSMailNoMailCmd", temp, MAX_LINE_LENGTH, "!NONE"); // no mail command
	NoMailCmd.assign(temp);

	GetRCLine("LSMailDoneCheckCmd", temp, MAX_LINE_LENGTH, "!NONE"); // done check command
	DoneCheckCmd.assign(temp);

	GetRCLine("LSMailErrorCmd", temp, MAX_LINE_LENGTH, "!NONE"); // error command
	ErrorCmd.assign(temp);
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
LsMail::~LsMail()
{
	int msgs[] = {LM_GETREVID, LM_REPAINT, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	if (!bBangMode)
	{
		RemoveBangs(GuiMode, GuiBangs);
    }	
    RemoveBangs(BangMode, BangBangs);

	destroyWindow();
}

void LsMail::onDestroy(Message& message)
{
#ifdef DEBUG_EXTRA
	_LSLog(LOG_DEBUG, szAppName, "OnDestroy accessed");
#endif

	if (CHECKING) // what about this? wait for module to close, or does it lock everything...
	{
		TerminateThread(CheckThread, NULL); // kill the checking thread.
		//Sleep(1000);
	}

	CleanUp();

}

void LsMail::CleanUp()
{
	if (!bBangMode)
	{
		DeleteObject(bgbrush);
		DeleteObject(nmbgbrush);
		DeleteObject(checkbgbrush);
		DeleteObject(errorbgbrush);
		DeleteObject(bgbmp);
		DeleteObject(newmailbmp);
		DeleteObject(checkingbmp);
		DeleteObject(errorbmp);
		DeleteObject(font);
		DestroyMenu(popup);
	}

	if (TIMER)
		KillTimer(hWnd, 0);

	for (Servers::iterator i = servers.begin(); i != servers.end(); ++i)
	{
		SERVER* s = (*i);
		DestroyMenu(s->menu);
	}
}

//=========================================================
// Registered messages
//=========================================================

void LsMail::windowProc(Message& message)
{

#ifdef DEBUG_SPAM
	_LSLogPrintf(LOG_DEBUG, szAppName, "Message: %X", message.uMsg) ;
#endif

	BEGIN_MESSAGEPROC
		MESSAGE(onEraseBg,		WM_ERASEBKGND)
		MESSAGE(onEndSession,	WM_ENDSESSION)
		MESSAGE(onEndSession,	WM_QUERYENDSESSION)
		MESSAGE(onGetRevId,		LM_GETREVID)
		MESSAGE(onMouse,		WM_RBUTTONDOWN)
		MESSAGE(onMouse,		WM_LBUTTONUP)
		MESSAGE(onCreate,		WM_CREATE)
		MESSAGE(onDestroy,		WM_DESTROY)
		MESSAGE(onRefresh,		LM_REFRESH)
		MESSAGE(onSysCommand,	WM_SYSCOMMAND)
		MESSAGE(onCommand,		WM_COMMAND)
		MESSAGE(onPaint,		WM_PAINT)
		MESSAGE(onPaint,		LM_REPAINT)
		MESSAGE(onTimer,		WM_TIMER)
	END_MESSAGEPROC
}

//=========================================================
// Message handlers
//=========================================================

void LsMail::onRefresh(Message& message)
{
	_LSLog(LOG_DEBUG, szAppName, "Refreshing");

	CleanUp();

	ReadCommands();
	
	LoadSetup();
	ReadServers();
	CreatePopup();

	// handling for new size & bitmap?
	FixPosition();

	ReadGUIProps();

	_LSLog(LOG_DEBUG, szAppName, "Refresh done");

	CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)::CheckAllMail, (LPVOID)NULL, 0, &threadID);

}

void LsMail::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void LsMail::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
		case 0:
			sprintf(buf, "LsMail.dll: %s", &rcsRevision[11]);
			buf[strlen(buf) - 1] = '\0';
		break;
		case 1:
			strcpy(buf, &rcsId[1]);
			buf[strlen(buf) - 1] = '\0';
		break;
		default:
			strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}


void LsMail::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void LsMail::onMouse(Message& message)
{
#ifdef DEBUG_EXTRA
	_LSLog(LOG_DEBUG, szAppName, "OnMouse accessed");
#endif

	MouseExecute(message.uMsg);

	message.lResult = DefWindowProc(GetHWND(), message.uMsg, message.wParam, message.lParam);
}

void LsMail::onCommand(Message& message)
{
	switch (message.wParam)
	{
		case POPUP_CHECKMAIL:
		{
			CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)::CheckAllMail, (LPVOID)NULL, 0, &threadID);
		}
		break;
	
		case POPUP_LAUNCHCLIENT: 
		{
			WinExec(MailClient.c_str(), SW_SHOWNORMAL);
		}
		break;
		case POPUP_DISPLAYERROR:
		{
			MessageBox(hWnd, SERVER.ERR, "LSMail Error", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
		}
		break;
		case POPUP_ZEROACCOUNTS:
		{
			ZeroAccounts();
		}
		break;
		
		case POPUP_CLEARNEWMAIL:
		{
			ClearNewMail();
		}
		break;
		
		// change password
		default:
		{
			SERVER* s;
			for (Servers::iterator i = servers.begin(); i != servers.end(); ++i) 
			{
				s = (*i);
				if ((int)message.wParam == (POPUP_SERVER+s->ID+1))
				{
					// Change Password
					strcpy(s->TEMP_SERVER, s->name);
					DialogBox(hInstance, MAKEINTRESOURCE(IDD_GETPASS), hWnd, GetPassProc);
					if (strlen(s->TEMP_PASS)) 
					{
						char temp[256] = "";
						if (s->password) 
							memset(&s->password, 0, sizeof(s->password));
						s->password = NULL;
						s->password = _strdup(s->TEMP_PASS);
						sprintf(temp, "%s/%s", s->host, s->login);
						WriteProfileString("LSMail", temp, s->encrypt(s->password));
					}
					break;
				}
			}
		}
		break;
	}

}

void LsMail::onPaint(Message& message)
{
#ifdef DEBUG_EXTRA
	_LSLog(LOG_DEBUG, szAppName, "onpaint accessed");
#endif

	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd, &ps);
	HDC buf = CreateCompatibleDC(NULL);
	HDC src = CreateCompatibleDC(NULL);
	HBITMAP bufbmp = CreateCompatibleBitmap(hdc, GetWidth(), GetHeight());
	HBITMAP oldbuf, oldsrc = NULL;
	RECT r;

	GetClientRect(hWnd, &r);

	if (!bgbmp && !USEBGCOLOR)
	{
		bgbmp = CreateCompatibleBitmap(hdc, GetWidth(), GetHeight());
		oldbuf = (HBITMAP)SelectObject(buf, bgbmp);
		BitBlt(buf, 0, 0, GetWidth(), GetHeight(), hdc, 0, 0, SRCCOPY);
		SelectObject(buf, oldbuf);
	}

	oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			
	if (!USEBGCOLOR)
	{
		if (ERRORS && errorbmp)
			oldsrc = (HBITMAP)SelectObject(src, errorbmp);
		else if (CHECKING && checkingbmp)
			oldsrc = (HBITMAP)SelectObject(src, checkingbmp);
		else if (NEWMAIL && newmailbmp)
			oldsrc = (HBITMAP)SelectObject(src, newmailbmp);
		else
			oldsrc = (HBITMAP)SelectObject(src, bgbmp);

		BitBlt(buf, 0, 0, GetWidth(), GetHeight(), src, 0, 0, SRCCOPY);
	}
	else
	{
		if (ERRORS)
			FillRect(buf, &r, (HBRUSH)errorbgbrush);
		else if (CHECKING)
			FillRect(buf, &r, (HBRUSH)checkbgbrush);
		else if (NEWMAIL)
			FillRect(buf, &r, (HBRUSH)nmbgbrush);
		else
			FillRect(buf, &r, (HBRUSH)bgbrush);
	}

	SelectObject(buf, font);
	SetBkMode(buf, TRANSPARENT);

	// output of mail text in window
	if (bInitialized && !bNoText)
	{
		char temp[256] = "";

		SERVER* s;
		for (Servers::iterator i = servers.begin(); i != servers.end(); ++i)
		{
			s = (*i);

			memset(temp, 0, 256);
			
			if (strlen(s->name))
				sprintf(temp, "%s: ", s->name);

			if (s->bERROR)
				strcpy(temp, "Error!");
			else
				sprintf(temp, "%s%d", temp, s->mails-s->mails_zeroed);

			SetRect(&r, s->x, s->y, GetWidth(), GetHeight());

			if (CHECKING)
				SetTextColor(buf, checkcolor);
			else
			{
				if (s->MAIL_STATUS != MAIL_NO)
				{
					SetTextColor(buf, nmcolor);
	#ifdef DEBUG_SERVER
					_LSLogPrintf(LOG_DEBUG, szAppName, "new mail on server: %s", s->host);
	#endif
				}
				else
				{
					if (s->bERROR)
					{
						SetTextColor(buf, errorcolor);
					}
					else
					{

					SetTextColor(buf, color);
	#ifdef DEBUG_SERVER
					_LSLogPrintf(LOG_DEBUG, szAppName, "no new mail on server: %s", s->host);
	#endif
					}

				}
			}

			DrawText(buf, temp, strlen(temp), &r, DT_CALCRECT | DT_LEFT | DT_VCENTER);
			DrawText(buf, temp, strlen(temp), &r, DT_LEFT | DT_VCENTER);
		}
	}

	BitBlt(hdc, 0, 0, GetWidth(), GetHeight(), buf, 0, 0, SRCCOPY);

	SelectObject(src, oldsrc);
	DeleteDC(src);
	SelectObject(buf, oldbuf);
	DeleteDC(buf);
	DeleteObject(bufbmp);
	EndPaint(hWnd, &ps);
}

void LsMail::onEraseBg(Message& message)
{
	return;
}

void LsMail::onTimer(Message& message)
{
#ifdef DEBUG_EXTRA
	_LSLog(LOG_DEBUG, szAppName, "OnTimer accessed, checking mail");
#endif
	CheckThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)::CheckAllMail, (LPVOID)NULL, 0, &threadID);
}


// Server functions

bool LsMail::CheckAllMail()
{
	int nummail = 0;
	char name[255];
	char text[255];
	HWND hWnd = GetHWND();

	// abort on these conditions
	if (CHECKING || bDisableCheck) {
		//mail->CHECKING = false;
		InvalidateRect(hWnd, NULL, TRUE);
		return false;
	}

#ifdef DEBUG_SERVER
	_LSLog(LOG_DEBUG, szAppName, "starting mail check");
#endif

	CHECKING=true;
	ERRORS = false;
	Servers::iterator i;

	InvalidateRect(hWnd, NULL, TRUE);
	_Execute(CheckMailCmd); // check !bang

#ifdef DEBUG_SERVER
	_LSLog(LOG_DEBUG, szAppName, "check mail !bang run");
#endif

	for (i = servers.begin(); i != servers.end(); ++i)
	{
		SERVER* s = (*i);
		s->CheckMail();
        InvalidateRect(hWnd, NULL, TRUE);
	}

	MAIL_STATUS = Status();

	if (MAIL_STATUS == MAIL_NEW) {
		NEWMAIL = true;
		_Execute(NewMailCmd);
	}
	else if (MAIL_STATUS == MAIL_NO) {
		NEWMAIL = false;
		_Execute(NoMailCmd);
	}

	// export nr of mail as LS variables
	for (i = servers.begin(); i != servers.end(); ++i)
	{
		SERVER* s = (*i);
		nummail += s->mails;
		memset(name, 0, 255);
		memset(text, 0, 255);
		sprintf(name, "LsMailServer%d", s->ID);
		sprintf(text, "%d", s->mails);
		_LSSetVariable(name, text);

		if (s->bERROR)
			mail->ERRORS = true;
	}
	if (ERRORS)
		_Execute(ErrorCmd); // error !bang

	memset(name, 0, 255);
	memset(text, 0, 255);
	strcpy(name, "LsMailNumMessages");
	sprintf(text, "%d", nummail);
	_LSSetVariable(name, text);

	CHECKING=false;
	_Execute(DoneCheckCmd); // check !bang
	InvalidateRect(hWnd, NULL, TRUE);

#ifdef DEBUG_SERVER
	_LSLog(LOG_DEBUG, szAppName, "mail check done");
#endif
	return true;
}

// mail checking, not possible to thread class functions...
bool CheckAllMail()
{
	if (mail)
		return mail->CheckAllMail();
	else
		return false;
}


BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM /* lParam */)
{
	switch (msg)
	{
		case WM_INITDIALOG: 
		{
			char temp[256] = "";
			sprintf(temp, "%s Password", SERVER.TEMP_SERVER);
			SetWindowText(hwnd, temp);
			return TRUE;
		}

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDOK:
						{
							GetDlgItemText(hwnd, IDC_PASSWORD, SERVER.TEMP_PASS, 256);
						}
						case IDCANCEL:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}

	return false;
}

int LsMail::Status()
{
	int status = MAIL_NO;
#ifdef DEBUG_SERVER
#endif
	SERVER* s;
	for (Servers::iterator i = servers.begin(); i != servers.end(); ++i)
	{
		s = (*i);
		status = max(status, s->MAIL_STATUS);

#ifdef DEBUG_SERVER
		LSLogPrintf(LOG_DEBUG, szAppName, "%s: %d", s->name, s->MAIL_STATUS);
#endif
	}
	return status;
}





















