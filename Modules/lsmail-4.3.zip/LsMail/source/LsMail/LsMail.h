#ifndef  __LSMAIL_H
#define  __LSMAIL_H

// module information
const char szAppName[] = "LsMail"; // Our window class, etc
const char rcsRevision[] = "$Revision: 4.3 $"; // Our Version
const char rcsId[] = "$Id: LsMail.cpp,v 4.3 $"; // The Full RCS ID.

// Includes
#include <windows.h>
#include <time.h> // for timers

#include <list>
using std::list;

#include "..\VTK\SafeString.h"

#include "Servers.h"

#include "resource.h"
#include "../current/lsapi/lsapi.h"
#include "../VTK/GuiWindow.h"
#include "../VTK/Clickable.h"

// Definitions
#define POPUP_CHECKMAIL 200
#define POPUP_CLEARNEWMAIL 201
#define POPUP_ZEROACCOUNTS 202
#define POPUP_LAUNCHCLIENT 203
#define POPUP_DISPLAYERROR 204
#define POPUP_SERVER 220

#define MAX_LINE_LENGTH 4096

#define WC_SHELLDESKTOP		"DesktopBackgroundClass"

typedef list<SERVER*> Servers;

class LsMail : public GuiWindow, Clickable
{
public:
	LsMail(HWND parentWnd, int& code, HINSTANCE dllInst);
	~LsMail();
	int Status();
	void LoadSetup();
	void ReadServers();

	bool CheckAllMail();

	HWND GetHWND();

	void ZeroAccounts();
	void ClearNewMail();

    void ShowPopup(int x, int y);

	HINSTANCE hInstance2;
	HANDLE CheckThread;
	HWND hWndParent;

	bool bInitialized;
	bool bNoMessageBoxes;
	bool bDisableCheck;
	bool bBangMode;
	bool bNoText;

	bool CHECKING;
	bool NEWMAIL;
	bool ERRORS;

	int TIMER;

	HMENU popup;
	HFONT font;

	DWORD threadID;

	SafeString NewMailCmd, NoMailCmd, CheckMailCmd, DoneCheckCmd, ErrorCmd, MailClient;

	int MAIL_STATUS;

	Servers servers;

protected:

	void CleanUp();

	void ReadCommands();

	void CreatePopup();

	void ReadGUIProps();
	void SetWindowBitmapRgn(HBITMAP bmp);

    HINSTANCE _Execute(const SafeString& sCommand)
    { return LSExecute(hWnd, sCommand.c_str(), 0); }

	// gui settings:
	COLORREF color, nmcolor, checkcolor, bgcolor, errorcolor;
	HBRUSH bgbrush, nmbgbrush, checkbgbrush, errorbgbrush;
	HBITMAP bgbmp, newmailbmp, checkingbmp, errorbmp;
	bool USEBGCOLOR;

	// Event handling:
	virtual void windowProc(Message& message);
	void onTimer(Message& message);
	void onEraseBg(Message& message);
	void onPaint(Message& message);
	void onCommand(Message& message);
	void onMouse(Message& message);
	void onRefresh(Message& message);
	void onGetRevId(Message& message);
	void onDestroy(Message& message);
	void onCreate(Message& message);
	void onSysCommand(Message& message);
	void onEndSession(Message& message);

};

// Function Definitions
//LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
bool CheckAllMail();

void BangSetOnTop(HWND caller, const char* args);
void BangHook(HWND caller, const char* szArgs);
void BangShow(HWND caller, const char* args);
void BangHide(HWND caller, const char* args);
void BangToggle(HWND caller, const char* args);
void BangCheckMail(HWND caller, const char* args);
void BangToggleCheck(HWND caller, const char* args);
void BangEnableCheck(HWND caller, const char* args);
void BangDisableCheck(HWND caller, const char* args);
void BangMove(HWND caller, const char *args);
void BangMenu(HWND caller, const char* args);
void BangZeroMail(HWND caller, const char* args);
void BangClearNewMail(HWND caller, const char* args);

extern BOOL (WINAPI *_LSLog)(int nLevel, LPCSTR pszModule, LPCSTR pszMessage);
extern BOOL (WINAPIV *_LSLogPrintf)(int nLevel, LPCSTR pszModule, LPCSTR pszFormat, ...);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif