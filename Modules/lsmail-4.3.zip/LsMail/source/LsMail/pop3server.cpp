#include "pop3server.h"
#include "LogSetting.h"
#include "../current/lsapi/lsapi.h"
#include "../VTK/apis.h"
#include "lsmail.h"

Pop3Server::Pop3Server(LPCSTR dataline) : SERVER(dataline)
{	
}

Pop3Server::~Pop3Server()
{
}

// Pop3 mail check
Pop3Server::CheckMail()
{

#ifdef DEBUG_SERVER
	_LSLogPrintf(LOG_DEBUG, szAppName, "trying pop3 server %s@%s", login, host);
#endif

	bool Error = false;
	unsigned int addr; 
	int	socket_type = SOCK_STREAM; 
	struct sockaddr_in server; 
	struct hostent *hp; 
	WSADATA wsaData; 
	SOCKET conn_socket;
	char temp[256] = "";
	if (!password)
	{
		sprintf(temp, "%s/%s", host, login);
		GetProfileString("LSMail", temp, "", temp, 256);
		if (!strlen(temp))
		{
			strcpy(TEMP_SERVER, name);
			DialogBox(hInstance, MAKEINTRESOURCE(IDD_GETPASS), parent, GetPassProc);
			if (strlen(TEMP_PASS)) 
			{
				password = _strdup(TEMP_PASS);
				sprintf(temp, "%s/%s", host, login);
				WriteProfileString("LSMail", temp, encrypt(password));
			}
			memset(&TEMP_PASS, 0, sizeof(TEMP_PASS));
		}
		else
		{
			password=_strdup(encrypt(temp));
		}
	}

	// Startup Sockets
	if (WSAStartup(0x202,&wsaData) == SOCKET_ERROR)
	{ 
		sprintf(ERR, "Could not initialize Windows Sockets");
		Error=true;
		WSACleanup(); 
		return 1;
	} 

	// Check to see if server_name is an alpha or ip
	if (isalpha(host[0]))
		hp = gethostbyname(host); 
	else  
	{
		addr = inet_addr(host); 
		hp = gethostbyaddr((char *)&addr,4,AF_INET); 
	} 

	// Couldn't resolve
	if (hp == NULL) 
	{	
		sprintf(ERR, "Could not resolve %s", host);
		//SERVER->ERR=true;
		WSACleanup();
		return 1;
	} 

	// Copy the resolved information into the sockaddr_in structure 
	memset(&server,0,sizeof(server)); 
	memcpy(&(server.sin_addr),hp->h_addr,hp->h_length); 
	server.sin_family = hp->h_addrtype; 
	server.sin_port = htons((u_short)port); 

	// Open a socket
	conn_socket = socket(AF_INET,socket_type,0);
	if (conn_socket < 0 ) 
	{ 
		sprintf(ERR, "Could not open a socket");
		Error=true;
		WSACleanup(); 
		return 1;
	}

	// Connect to the server
	if (connect(conn_socket,(struct sockaddr*)&server,sizeof(server)) == SOCKET_ERROR)
	{
		sprintf(ERR, "Could not connect to %s:%d, socket error", host, port);
		Error=true;
		WSACleanup(); 
		return 1;
	}

	char* recvd=NULL;
	if (!ReceiveData(conn_socket)) 
	{ 
		sprintf(ERR, "No data received from server");
		Error=true; 
		return 1; 
	}

	sprintf(temp, "USER %s\r\n", login);
	send(conn_socket, temp, strlen(temp), 0);
	if (!ReceiveData(conn_socket)) 
	{
		sprintf(ERR, "%s: Invalid Login", login);
		Error=true; 
		return 1; 
	}
	sprintf(temp, "PASS %s\r\n", password);
	send(conn_socket, temp, strlen(temp), 0);
	if (!ReceiveData(conn_socket)) 
	{
		sprintf(ERR, "%s: Invalid password", password);
		sprintf(temp, "Invalid password for user %s on %s", login, host);
		if (bMsgboxes)
			MessageBox(parent, temp, "LSMail Error, no data received after sending password", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
		else
		{
			_LSLog(LOG_WARNING, szAppName, "LSMail Error, no data received after sending password");
		}
		Error=true; 
		return 1; 
	}
	sprintf(temp, "STAT\r\n");
	send(conn_socket, temp, strlen(temp), 0);
	if (!(recvd=ReceiveData(conn_socket))) 
	{
		sprintf(ERR, "Could not execute STAT. No data received.");
		Error=true; 
		return 1; 
	}
	else
	{
		char* p = strtok(recvd, " ");
		int ReportedNum=-1;
		p = strtok(NULL, " ");
		ReportedNum = atoi(p);
		// new mail if:
		// 1. we have more mail than before
		// 2. we have more than zero mail, and less than before
		//    meaning we've fetched the mail, but before refresh, we've gotten even more
		//    what about when we get exactly the same amount of mail again?
		if ( ReportedNum > mails || (ReportedNum > 0 && ReportedNum < mails) ) 
		{
			MAIL_STATUS = MAIL_NEW;
		}
		else if (ReportedNum == mails && ReportedNum != 0) {
			MAIL_STATUS = MAIL_EXISTS;
		}
		else if (ReportedNum == 0) {
			/*if (mail->MAIL_STATUS == MAIL_NO) {
				mail->MAIL_STATUS = MAIL_NO;
			}*/
			mails_zeroed=mails=0;
			MAIL_STATUS = MAIL_NO;
		}
		mails=ReportedNum;

		if (mails < mails_zeroed)
			mails_zeroed=mails;

#ifdef DEBUG_SERVER
	_LSLogPrintf(LOG_DEBUG, szAppName, "mail: new %d, zeroed %d", mails, mails_zeroed);
#endif

	}

	sprintf(temp, "QUIT\r\n");
	send(conn_socket, temp, strlen(temp), 0);
	if (!ReceiveData(conn_socket)) 
	{ 
		sprintf(ERR, "Error disconnecting from server");
		Error=true; 
		return 1; 
	}

	// set server error if a new error has been found
	if (Error)
		bERROR = true;
	else
		bERROR = false;

	closesocket(conn_socket);
	WSACleanup();

#ifdef DEBUG_SERVER
	_LSLog(LOG_DEBUG, szAppName, "server done");
#endif
    return 0;

}