#ifndef __HOVER_H
#define __HOVER_H

#include <windows.h>

enum {
	HOVER_OUT,
	HOVER_IN,
	HOVER_OVER
};


class Hover
{
public:
	Hover(LPCSTR prefix);
	~Hover();

	void HoverCheck();
	void ReadHoverSettings();
	void PurgeHoverSettings();
	void HoverExecute(const int over);
#ifdef FAKE_HWND
	virtual HWND GetHWND();
#else
	virtual HWND GetHWND() = 0;
#endif

private:
	BOOL bHover;
	const char *Prefix;

	char *OnMouseEnterCommand;
	char *OnMouseLeaveCommand;

};

#endif