#include <conio.h>
#include "SafeString.h"

void main()
{
	SafeString* test = new SafeString;
	test->assign("test");
	printf("1, %s ", test->c_str());
	
	test->append("ad");

	printf("3, %s ", test->char_str());
	delete test;

	getch();
}