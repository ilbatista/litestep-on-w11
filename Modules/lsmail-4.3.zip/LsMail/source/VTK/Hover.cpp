/*

	Hover

	Author:	Vendicator

	Description:
	Simple class that handles hovering over window

	Requires:
	- GetHWND() implemented in child class

	Changelog:

	[2003-03-15 - Vendicator]
	- First work?

*/

#include "Hover.h"
#include "LSUtils.h"
#include "lsapi_location.h"

#include "CommonDefines.h"

Hover::Hover(LPCSTR prefix) :
	OnMouseEnterCommand(NULL),
	OnMouseLeaveCommand(NULL),
	Prefix(prefix),
	bHover(FALSE)
{
}

Hover::~Hover()
{
	if (OnMouseEnterCommand)
		delete [] OnMouseEnterCommand;
	if (OnMouseLeaveCommand)
		delete [] OnMouseLeaveCommand;
}

void Hover::ReadHoverSettings()
{
	char szTemp[MAX_LINE_LENGTH];
	memset(szTemp, 0, MAX_LINE_LENGTH);

	LSUtils::PrefixedGetRCLine(Prefix, "OnMouseEnter", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnMouseEnterCommand = new char[strlen(szTemp)+1];
	strcpy(OnMouseEnterCommand, szTemp);

	LSUtils::PrefixedGetRCLine(Prefix, "OnMouseLeave", szTemp, MAX_LINE_LENGTH, "!NONE");
	OnMouseLeaveCommand = new char[strlen(szTemp)+1];
	strcpy(OnMouseLeaveCommand, szTemp);
}

void Hover::PurgeHoverSettings()
{
	if (OnMouseEnterCommand)
	{
		delete [] OnMouseEnterCommand;
		OnMouseEnterCommand = NULL;
	}

	if (OnMouseLeaveCommand)
	{
		delete [] OnMouseLeaveCommand;
		OnMouseLeaveCommand = NULL;
	}
}

void Hover::HoverCheck()
{
	RECT rc;
	POINT pt;
	GetCursorPos(&pt);
	GetWindowRect(GetHWND(), &rc);

	if(PtInRect(&rc, pt))
		HoverExecute(HOVER_IN);
	else
		HoverExecute(HOVER_OUT);
}

void Hover::HoverExecute(const int ID)
{
	HWND hWnd = GetHWND();
	switch(ID)
	{
		case HOVER_IN:
			if(GetCapture() != hWnd)
				SetCapture(hWnd);
			if (!bHover)
			{
				bHover = TRUE;

			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, hWnd, OnMouseEnterCommand, 0);
			#else
				LSExecute(hWnd, OnMouseEnterCommand, 0);
			#endif
			}

		break;
		case HOVER_OUT:
			if (bHover)
			{
				bHover = FALSE;
				ReleaseCapture();

			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, hWnd, OnMouseLeaveCommand, 0);
			#else
				LSExecute(hWnd, OnMouseLeaveCommand, 0);
			#endif
			}
		break;
	}
}

#ifdef FAKE_HWND
HWND Hover::GetHWND()
{
	return NULL;
};
#endif