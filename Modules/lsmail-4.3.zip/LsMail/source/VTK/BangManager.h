/*

	BangManager

	Author:	Vendicator

	Description:
	Simple functions & structs for handling the adding/removal of bangs into LiteStep.

	Requires:

	Changelog:
	[2003-05-28 - Vendicator]
	- First work?

*/

#ifndef __BANGMANAGER_H
#define __BANGMANAGER_H

#include <windows.h>
#include "lsapi_location.h"

/*

EXAMPLE:

const Bang BangList[] =
{
	{ "!WndForeground", BangWndForeground }
};

// calculate how many bangs there are
const int NrOfBangs = sizeof(BangList) / sizeof(BangList[0]);

 */


// bang entry
struct Bang
{
	const char *bangName;
	void (*bangFunc) (HWND, LPCSTR);
};

void InsertBangs(const Bang banglist[], const int nrofbangs)
{
	if (banglist == NULL)
		return;

	for (int i = 0; i < nrofbangs; i++)
		AddBangCommand(banglist[i].bangName, *banglist[i].bangFunc);
}

void RemoveBangs(const Bang banglist[], const int nrofbangs)
{
	if (banglist == NULL)
		return;

	for (int i = 0; i < nrofbangs; i++)
		RemoveBangCommand(banglist[i].bangName);
}

#endif