-\\___________________//-
-//                   \\-
     xDesktop	v1.0
	    by Andymon
-\\___________________//-
-//                   \\-

--------
Overview
--------
	This simulation of the explorer desktop is up to 95% identical to Explorer Desktop! Just 
	set the following Three Lines and you're having your OldStyle Explorer Desktop =)

	xDesktopAutoCreate
	xDesktopConfigFile "$ConfigDir$yourdesktopfile.rc"
	include "$ConfigDir$yourdesktopfile.rc"

------------------------
Basic Settings Overview:
------------------------

	Of course, you should also specify some basic layout informations.
	
	xDesktopX
	xDesktopY
	xDesktopItemWidth
	xDesktopItemHeight
	xDesktopSpacingX
	xDesktopSpacingY
	xDesktopDirection
	xDesktopWrapDirection
	xDesktopWrapCount 
	
	These settings affect only the "!xDesktopCreate replace ..." Bang and "xDesktopAutoCreate"
	to provide a instant layout ;) The further finetune positioning should be made by hand (Draggable). 


------------------------------
Configuration of the "Desktop"
------------------------------

Internal Syntax for each DesktopItem

*xdesktopitem xldi(number) (x pos) (y pos) "(Quoted Path)"
	Each specified line creates an DesktopItem with the Icon of the specified file. Path MUST be be quoted! 

------------------
Essential Settings
------------------

xDesktopAutoCreate
	This command enables the complete "Explorer Desktop Emulation"!
	If NO! *xdesktopitem line is set the desktop is automatically created!
	Deleted Files/Folders are instantly removed!
	Added (or renamed) Files/Folders appear at position x=100, y=100 for further positioning!
	
	You can use the jdesk-0.73 feature, to make your "Desktop" complete =) :
	jDeskDesktopFolder "$desktop$"

		If used and set to a valid directory, it will enable drag and drop of files or folders onto the 
		jDesk desktop area. Any file dropped on the desktop will be automatically copied into the folder 
		specified. If the file exists, you will be prompted to overwrite. You can move files holding the 
		SHIFT key or to create shortcuts holding the CTRL+SHIFT keys during dragging. 


xDesktopConfigFile "(Quoted path to rc-file)"
	This command specifies the rc-file in which your *xdesktopitem lines will be stored.
	MUST be set, for xDesktopAutoCreate, !xDesktopCreate and !xDesktopSave to work!
	The Path must, as always, be quoted!
	MUST be "included" of course!
	include "(Quoted path to rc-file)" 


------------------
Desktop Arrangment
------------------

xDesktopX (number)
	Sets the horizontal position of the first DesktopIcon in pixels. It is relative to the left
	side of the desktop.

xDesktopY (number)
	Sets the vertical position of the first DesktopIcon in pixels. It is relative to the top of
	the desktop,

xDesktopItemWidth (number)
	This command specifies the width of each DesktopItem [Icon + Text] If no value is provided 
	then the default is 100.
	TIP:
	If the text is cut of on some DesktopIcons (too long) simply make this setting larger!! 

xDesktopItemHeight (number)
	This command specifies the height of each DesktopItem [Icon + Text] If no value is provided 
	then the default is 75.
	TIP:
	If the text is cut of on some DesktopIcons (too high) simply make this setting larger!! 

xDesktopSpacingX (number)
	This command specifies the horizontal space between each DesktopItem.
	Note: 	The distance is calculated between the xDesktopItemWidth. 
			If no value is provided then the default is 0. 

xDesktopSpacingY (number)
	This command specifies the vertical space between each DesktopItem.
	Note: 	The distance is calculated between the xDesktopItemHeight.
			If no value is provided then the default is 0. 

xDesktopDirection "left", "right", "up", or "down"
	The direction to draw the icons in. Defaults to "right". 

xDesktopWrapDirection "up", "down", "left", or "right"
	Direction to wrap the icons in. Defaults to "down".
	Note: If Direction is set to right or left, WrapDirection must be up or down and vice versa. 

xDesktopWrapCount (number)
	Number of icons to display before wrapping to the next line or column. If no value is 
	provided then the default is automatically calculated. 


-------------------
Desktop Item Layout
-------------------

xDesktopIconSize (number)
	This command specifies the Size (Width/Height) of the displayed Icon.
	Minimum: 16
	Maximum: 64
	If no value is provided then the default is 32. 

xDesktopSaturationIntensity (number)
	This command specifies the color saturation of the desktopicons.
	Minimum: 0 -> Grayscale
	Maximum: 255 -> Full Colored (Default)

xDesktopHueIntensity (number)
	This command specifies the amount of the, in the desktopicons, blended in color.
	Minimum: 0 -> Nothing (Default)
	Maximum: 255 

xDesktopHueColor (color)
	This command specifies the blended in color 

xDesktopTextPosition "top", "bottom", "left", or "right"
	This command specifies the position of the Icon Text relative to the icon. If no value 
	is provided then the default is "bottom". 

xDesktopTextBackground (color) [(color)] [(color)]
	If set, this color will be used to paint a box behind the text. If no value is provided 
	or set to "ff00ff" the default is blank (no box is painted). With the optional second and 
	third color you can specify a bevel around the textbox. First ist the light color, second 
	the dark color. 

xDesktopTextSpacing (number)
	Distance between the icon and the textbox. If no value is provided then the default is 5. 

xDesktopStartHidden
	If this command is present then the DesktopItems will be initially invisible. They can 
	later be shown using bang commands "!xdesktopshow" or "!xdesktoptoggle". 

xDesktopFont (font)
	Sets the name of the font used to display text. If no value is provided then the default is "Arial". 

xDesktopFontHeight (number)
	Sets the height of the font used to display the text in pixels. If no value is provided 
	then the default is 15. 

xDesktopFontBold
	If this command is present then the font will be bold. 

xDesktopFontItalic
	If this command is present then the font will be italic. 

xDesktopFontUnderline
	If this command is present then the font will be underlined. 

xDesktopFontColor (color)
	Sets the color of the font used to display the text. If no value is provided then the 
	default is black (RGB 0, 0, 0). 

xDesktopFontShadow
	If this command is present then the font will be shadowed. 

xDesktopFontShadowColor (color)
	Sets the color used to display the text shadow. If no value is provided then the default 
	is dark gray (RGB 128, 128, 128). 

xDesktopFontShadowX (number)
	Sets the number of pixels in the horizontal direction that the shadow is offset 
	from the rest of the text; this can be negative. If no value is provided then the default is 1. 

xDesktopFontShadowY (number)
	Sets the number of pixels in the vertical direction that the shadow is offset from 
	the rest of the text; this can be negative. If no value is provided then the default is 1. 

TIP:
	To remove Text simply set the ItemHeight = IconSize in Top/Bottom Textposition or 
	ItemWidth = IconSize in Left/Right Textposition


---------------------------------
Bang Commands for "Desktop Items"
---------------------------------

!xDesktopCreate replace ".desktop"
	If you specify ".desktop", this automatically Creates/REPOSITIONS your complete Desktop.
	Both, in Normal Mode and in xDesktopAutoCreate Mode!! 
	
!xDesktopCreate update ".desktop"
	If you specify ".desktop", this automatically Updates your complete Desktop.
	Both, in Normal Mode and in xDesktopAutoCreate Mode!!
	Use this only if your DesktopItems have changed, when the Tracker didn't run! Not for 
	"Creating" your Desktop. Normally, if you use "xDesktopAutoCreate" this Bang is superfluous. 

!xDesktopCreate "append"|"replace"|"update" "(Quoted Path to Folder)"
	Creates/Changes/Removes the *xdesktopitem lines for every File/Folder found in the specified folder (eg.: $desktop$).
	"append" : 	Keep already present *xdesktopitem lines and append all new ones.
	"replace" : Delete all present *xdesktopitem lines and add only new ones.
	"update" : 	Updates *xdesktopitem lines according to current state (Add & Remove).

ATTENTION:
	xDesktopConfigFile MUST be specified AND Path MUST be enclosed in '" "'.
	If you have set xDesktopAutoCreate then all appended/added DesktopItems, 
	which aren't on your Desktop will be removed on the next recycle! 

The following Bangs affect all DesktopItems at once and are quite obvious:
!xDesktopDestroy 	<- Destroys the Desktop
!xDesktopShow 		<- Shows the Desktop
!xDesktopHide 		<- Hides the Desktop 
!xDesktopToggle 	<- Toggles the Desktop Visibility

