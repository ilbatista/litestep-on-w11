-\\____________________________//-
-//                            \\-
          xDeskFun	v0.1
	        by Andymon
	 andymon@ls-universe.info
-\\____________________________//-
-//                            \\-

---------
Overview:
---------

	This is (atm) just a Gimmick Module, which adds a MouseTrail ON THE DESKTOP ONLY :0
	You can use AlphaMap Images for the Trail Images for smooth BackgroundBlending.
	
	Ok, now to the POSSIBLE purpose of this module:
	1. It sits between your DESKTOP and the other Modules
	2. It could process/filter all MouseActions (before jDesk or Desktop2 get it).
	3. It could make HoverActions or Hotspots.
	4. It could paint all kinds of AlphaMap Images on the Desktop or do anything else with it.
	5. ...
	
	Just some impressions and one example -> Fading & Animated MouseTrail <- already implemented.
	
	So, if YOU say: "Yes, this or that feature would be cool",
	then this module will be pushed further, otherwise it's a simple Fun Module :)
	
	Comments in the Forum at http://www.ls-universe.info

------------------------
Basic Settings Overview:
------------------------

xDeskFunMoveImage IMAGE
     Sets the Image of one MouseTrail Point (can have AlphaChannel).
     This shouldn't be a "Big" Image, best is maybe 10x10 Pixels or smaller.

xDeskFunAlphaMap BOOL
     If set, the AlphaChannel of the Image is used.

xDeskFunFollowMouse BOOL
     If set, the Trail chases the Mouse.

xDeskFunAnimatedTrail BOOL
     If set, the Trail pulses towards the Mouse.

---------------------------------
Bang Commands for "DeskFun"
---------------------------------

!xDeskFunStart 
	Starts the Trail Effect.
	
!xDeskFunStop
	Stops the Trail Effect.



