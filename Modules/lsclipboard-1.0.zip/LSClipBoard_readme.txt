/////////////////////////
// LSClipBoard V1.0
// Written By: MrJukes
// Graphics By: snowchyld
// Concept By: mr_eh

// Installation
1) Unzip LSClipBoard.app to your Litestep directory (c:\litestep)
2) Unzip LSClipBoard.bmp to your Images directory (c:\litestep\images)
3) Edit your step.rc to look something like this:
	*Wharf LSClipBoard LSClipBoard.bmp @c:\Litestep\LSClipBoard.app
4) Recycle Litestep

// Module Operation
+ Double click on the module to bring up the List Window
+ Right click on the module to bring up the popup list

// List Window Operation
+ File Menu
- Empty List: Empties the list
- Hide Window: Hides the List Window

+ About: Brings up the About Box

+ Double click on an item in the list to copy it back into the clipboard

// Popup Menu Operation
+ Toggle List Window: Hides/Displays the List Window
+ About LSClipBoard: Brings up the About Box

Have fun,
	MrJukes