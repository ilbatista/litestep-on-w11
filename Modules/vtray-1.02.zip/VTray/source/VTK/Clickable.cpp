/*

	Clickable

	Author:	Vendicator
	
	Description:
	Simple class that handles clicking of window

	Requires:
	- GetModuleWnd() implemented in child class

	Changelog:
	[2003-06-12 - Vendicator]
	- Using SafeString class

	[2003-01-05 - Vendicator]
	- First work?
	
*/

#include "Clickable.h"
#include "LSUtils.h"
#include "lsapi_location.h"

//#define DEBUG

Clickable::Clickable(LPCTSTR prefix)
{
	Prefix.assign(prefix);
	SetMouseDefaults();
}

Clickable::~Clickable()
{
}

void Clickable::SetMouseDefaults()
{
	OnLeftDBL.assign("!None");
	OnLeftDown.assign("!None");
	OnLeftUp.assign("!None");
	OnRightDBL.assign("!None");
	OnRightDown.assign("!None");
	OnRightUp.assign("!None");
	OnMiddleDBL.assign("!None");
	OnMiddleDown.assign("!None");
	OnMiddleUp.assign("!None");
}

void Clickable::SetMouseKey(MouseKey key, LPCTSTR action)
{
	switch(key)
	{
		case WM_LBUTTONDBLCLK:
		case LEFT_DBL:
			OnLeftDBL.assign(action);
		break;
		case WM_LBUTTONDOWN:
		case LEFT_DOWN:
			OnLeftDown.assign(action);
		break;
		case WM_LBUTTONUP:
		case LEFT_UP:
			OnLeftUp.assign(action);
		break;

		case WM_RBUTTONDBLCLK:
		case RIGHT_DBL:
			OnRightDBL.assign(action);
		break;
		case WM_RBUTTONDOWN:
		case RIGHT_DOWN:
			OnRightDown.assign(action);
		break;
		case WM_RBUTTONUP:
		case RIGHT_UP:
			OnRightUp.assign(action);		
		break;

		case WM_MBUTTONDBLCLK:
		case MIDDLE_DBL:
			OnMiddleDBL.assign(action);			
		break;
		case WM_MBUTTONDOWN:
		case MIDDLE_DOWN:
			OnMiddleDown.assign(action);		
		break;
		case WM_MBUTTONUP:
		case MIDDLE_UP:
			OnMiddleUp.assign(action);
		break;
	}
}

void Clickable::ReadClickSettings()
{
	char szTemp[MAX_LINE_LENGTH];
	memset(szTemp, 0, MAX_LINE_LENGTH);

	LSUtils::PrefixedGetRCLine(Prefix.c_str(), "OnLeftDBL", szTemp, MAX_LINE_LENGTH, OnLeftDBL.c_str());
	OnLeftDBL.assign(szTemp);

	LSUtils::PrefixedGetRCLine(Prefix.c_str(), "OnLeftDown", szTemp, MAX_LINE_LENGTH, OnLeftDown.c_str());
	OnLeftDown.assign(szTemp);

	LSUtils::PrefixedGetRCLine(Prefix.c_str(), "OnLeftUp", szTemp, MAX_LINE_LENGTH, OnLeftUp.c_str());
	OnLeftUp.assign(szTemp);

	LSUtils::PrefixedGetRCLine(Prefix.c_str(), "OnRightDBL", szTemp, MAX_LINE_LENGTH, OnRightDBL.c_str());
	OnRightDBL.assign(szTemp);

	LSUtils::PrefixedGetRCLine(Prefix.c_str(), "OnRightDown", szTemp, MAX_LINE_LENGTH, OnRightDown.c_str());
	OnRightDown.assign(szTemp);

	LSUtils::PrefixedGetRCLine(Prefix.c_str(), "OnRightUp", szTemp, MAX_LINE_LENGTH, OnRightUp.c_str());
	OnRightUp.assign(szTemp);

	LSUtils::PrefixedGetRCLine(Prefix.c_str(), "OnMiddleDBL", szTemp, MAX_LINE_LENGTH, OnMiddleDBL.c_str());
	OnMiddleDBL.assign(szTemp);

	LSUtils::PrefixedGetRCLine(Prefix.c_str(), "OnMiddleDown", szTemp, MAX_LINE_LENGTH, OnMiddleDown.c_str());
	OnMiddleDown.assign(szTemp);

	LSUtils::PrefixedGetRCLine(Prefix.c_str(), "OnMiddleUp", szTemp, MAX_LINE_LENGTH, OnMiddleUp.c_str());
	OnMiddleUp.assign(szTemp);

}

bool Clickable::MouseExecute(const int ID)
{
	switch(ID)
	{
		case WM_LBUTTONDBLCLK:
		case LEFT_DBL:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetModuleWnd(), OnLeftDBL.c_str(), 0);
			#else
				LSExecute(GetModuleWnd(), OnLeftDBL.c_str(), 0);
			#endif
		break;
		case WM_LBUTTONDOWN:
		case LEFT_DOWN:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetModuleWnd(), OnLeftDown.c_str(), 0);
			#else
				LSExecute(GetModuleWnd(), OnLeftDown.c_str(), 0);
			#endif
		break;
		case WM_LBUTTONUP:
		case LEFT_UP:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetModuleWnd(), OnLeftUp.c_str(), 0);
			#else
				LSExecute(GetModuleWnd(), OnLeftUp.c_str(), 0);
			#endif
		break;

		case WM_RBUTTONDBLCLK:
		case RIGHT_DBL:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetModuleWnd(), OnRightDBL.c_str(), 0);
			#else
				LSExecute(GetModuleWnd(), OnRightDBL.c_str(), 0);
			#endif
		break;
		case WM_RBUTTONDOWN:
		case RIGHT_DOWN:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetModuleWnd(), OnRightDown.c_str(), 0);
			#else
				LSExecute(GetModuleWnd(), OnRightDown.c_str(), 0);
			#endif
		break;
		case WM_RBUTTONUP:
		case RIGHT_UP:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetModuleWnd(), OnRightUp.c_str(), 0);
			#else
				LSExecute(GetModuleWnd(), OnRightUp.c_str(), 0);
			#endif			
		break;

		case WM_MBUTTONDBLCLK:
		case MIDDLE_DBL:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetModuleWnd(), OnMiddleDBL.c_str(), 0);
			#else
				LSExecute(GetModuleWnd(), OnMiddleDBL.c_str(), 0);
			#endif			
		break;
		case WM_MBUTTONDOWN:
		case MIDDLE_DOWN:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetModuleWnd(), OnMiddleDown.c_str(), 0);
			#else
				LSExecute(GetModuleWnd(), OnMiddleDown.c_str(), 0);
			#endif			
		break;
		case WM_MBUTTONUP:
		case MIDDLE_UP:
			#ifdef DEBUG
				LSUtils::LoggedBangExecute(Prefix, GetModuleWnd(), OnMiddleUp.c_str(), 0);
			#else
				LSExecute(GetModuleWnd(), OnMiddleUp.c_str(), 0);
			#endif			
		break;

		default:
			// we didn't find want to use this msg
			return false;
	}
	// we did use the msg
	return true;
}