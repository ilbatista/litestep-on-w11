#if !defined(__VERINFO_H)
#define __VERINFO_H

#define V_AUTHOR "Andymon, started by X, modified by Seg@"
#define V_NAME "xLabel"
#define V_VERSION "2.8"

#endif
