07-11-2002 [allelimo]


this is a very minimal change to syscolor.dll: added 
"SCNoChange (BOOL)", prevents syscolor from changing your system colors.
If you, like me, hate when a theme changes your colors without asking,
simply add this setting to your "personal".rc...

