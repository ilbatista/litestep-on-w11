--------------
I. About LsBox
--------------
Lsbox pre-release version 0.95
-{handle with care}-{fragile}-

----------------
II. Requirements
----------------
You  will need a fairly new LS dev build to run LsBox.
I don't know how new, but if you're getting a msg about
a library function that is not found then your build 
is too old.
You will also need to have at least win98+ running.
 (BTW - I'm currently running WinME build 2495)

-----------------
III. Installation
-----------------
Just copy LsBox.dll to your LS dir and add the following 
line to your step.rc: 

   Loadmodule C:\Litestep\LsBox.dll
(*assuming you have your LS stuff in C:\Litestep*)

-------
IV. Use
-------
To actually use LsBox you have to have a .box 
file and a few gfx to use with it.
I have included two examples with this pre-release.
Modifying them shouldn't be a problem for you if 
you ever customised a theme for your use. The .Box 
file's syntax is plain step.rc code. 

After having placed everything in the right directorys
and editing you can call
      
        !LsBoxCreate [path and filename of the .Box file]

Examples:
	!LsBoxCreate C:\Litestep\recycle.box
	!LsBoxCreate C:\Litestep\Shutdown.box

I won't tell you anymore about it, because you already 
knew far too much. 

*PLEASE use ONLY the stuff present in the sample 
files - cause that's the stuff that seem to work*

---------
V. Issues
---------

*One - at least one leak in the create/destoy functions.
 Try to have more than one instance of a Lsbox and 
 destroy/create them a couple of times.......
 
*misc stuff
