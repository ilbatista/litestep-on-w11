#ifndef __LOGSETTING_H
#define __LOGSETTING_H

// for extra debugging
//#define DEBUG_EXTRA

// for server debugging:
#define DEBUG_SERVER

// for message debugging:
//#define DEBUG_SPAM


#endif