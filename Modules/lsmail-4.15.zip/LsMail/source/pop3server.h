#ifndef  __POP3
#define  __POP3

#include "servers.h"
#include "lsmail.h"

class Pop3Server : public SERVER
{
public:
	Pop3Server(LPCSTR dataline);
	~Pop3Server();
	CheckMail();
};

#endif