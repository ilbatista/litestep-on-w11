#include "Servers.h"
#include "../current/lsapi/lsapi.h"
#include "LogSetting.h"

const char szLogName[] = "LsMail: Servers";

int SERVER::nServers = 0;
char SERVER::ERR[256];
char SERVER::TEMP_PASS[256];
char SERVER::TEMP_SERVER[256];

HINSTANCE SERVER::hInstance = NULL;
HWND SERVER::parent = NULL;
bool SERVER::bLog = false;
bool SERVER::bMsgboxes = false;

void SERVER::RegisterSettings(HWND p, HINSTANCE hInst, bool log, bool msg)
{
	SERVER::hInstance = hInst;
	SERVER::parent = p;
	SERVER::bLog = log;
	SERVER::bMsgboxes = msg;
}

SERVER::SERVER(LPCSTR dataline) :
	ID(0),
	x(0), y(0),
	name(NULL),
	host(NULL),
	login(NULL),
	password(NULL),
	port(110),
	num(0), newnum(0),
	MAIL_STATUS(MAIL_NO),
	bERROR(FALSE),
	menu(NULL),
	next(NULL),
	bWorking(TRUE)
{

	ID = ++nServers;
#ifdef DEBUG_SERVER
	if (bLog)
		LSLogPrintf(LOG_DEBUG, "LsMail: Server", "server: %d", ID);
#endif

	parseConfig(dataline);

#ifdef DEBUG_SERVER
	if (bLog)
		LSLog(LOG_DEBUG, "LsMail: Server", "server created");
#endif
}

SERVER::~SERVER()
{
}

#define DSIZE	256

bool SERVER::parseConfig(LPCSTR dataline)
{

	char	token1[DSIZE], token2[DSIZE], token3[DSIZE], token4[DSIZE], token5[DSIZE], token6[DSIZE], extra_text[DSIZE];
	char*	tokens[6];
	int count = 0;

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	tokens[5] = token6;

	token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = extra_text[0] = '\0';
	count = LCTokenize(dataline, tokens, 6, extra_text);

#ifdef DEBUG_SERVER
	if (bLog)
		LSLogPrintf(LOG_DEBUG, "LsMail: Server", "config parsed, found: %s", token4);
#endif

	if (count == 6)
	{
#ifdef DEBUG_SERVER
		if (bLog)
			LSLogPrintf(LOG_DEBUG, szLogName, "setting up new server");
#endif
			
#ifdef DEBUG_SERVER
		if (bLog)
			LSLog(LOG_DEBUG, szLogName, "reading text pos");
#endif
		x = atoi(token2);
		y = atoi(token3);
		name = _strdup(token4);
			
		// blah.blah.blah.blah:80
		char* p = strtok(token5, ":");
		host = _strdup(p);
		p = strtok(NULL, "");
		if (p) port = atoi(p);
		else port = 110;
			
		login = _strdup(token6);
		if (extra_text[0] != '\0')
		{
#ifdef DEBUG_SERVER
			if (bLog)
				LSLog(LOG_DEBUG, szLogName, "Found password for mail server in config");
#endif
			password = _strdup(extra_text); //jesus_mjjg
		}
	}
	else
	{
		bWorking = FALSE;
		return false;
	}
	return true;
}

bool SERVER::Working()
{
	return bWorking;
}

char* SERVER::ReceiveData(SOCKET conn_socket)
{
	int retval;
	int nStatus;
	struct timeval timeout = {0, 0};
	struct fd_set fds;
	DWORD dwStartTicks = GetTickCount();
	char temp[256] = "";

	while (true)
	{
		if ((GetTickCount() - dwStartTicks) > 60000)
		{
			if (bMsgboxes)
				MessageBox(parent, "Receive Timed Out", "Server", MB_SYSTEMMODAL);
			else
			{
				if (bLog)
					LSLog(LOG_WARNING, szLogName, "Receive Timed Out");
			}
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}

		FD_ZERO(&fds);
		FD_SET(conn_socket, &fds);
		nStatus = select(0, &fds, NULL, NULL, &timeout);
		if (nStatus == SOCKET_ERROR) 
		{
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}
		else
		{
			if (!nStatus) 
			{
				Sleep(250);
				continue;
			}
		}

		retval = recv(conn_socket, temp, 256, 0); 
		if (retval == SOCKET_ERROR) 
		{ 
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}
		else
		{
			if (_strnicmp(temp, "+OK", 3))
			{
				closesocket(conn_socket);
				WSACleanup();
				return NULL;
			}
			else return _strdup(temp);
		}
	}

	return _strdup(temp);
}


char* SERVER::encrypt(char* pass)
{
	char* ret=_strdup(pass);
	char* p=ret;
	for (; *pass; *pass++, *ret++)
	{
		*ret=*pass ^ 0x5405;
	}
	return p;
}