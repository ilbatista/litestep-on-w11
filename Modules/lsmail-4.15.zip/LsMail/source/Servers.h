#ifndef  __SERVERS
#define  __SERVERS

#include <windows.h>
#include <wininet.h>

enum {
	MAIL_NO,
	MAIL_EXISTS,
	MAIL_NEW
};

class SERVER
{
public:
	SERVER(LPCSTR dataline);
	~SERVER();

	static char* encrypt(char* pass);
	static void RegisterSettings(HWND p, HINSTANCE hInst, bool log, bool msg);
	bool parseConfig(LPCSTR dataline);
	virtual CheckMail() = 0;
	char* ReceiveData(SOCKET conn_socket);
	bool Working();

	// for linked list
	SERVER* next;

	char* name;
	char* host;
	char* login;
	char* password;

	BOOL bERROR;
	HMENU menu;

	int ID, x, y, port, num, newnum, MAIL_STATUS;

	static char ERR[256];
	static char TEMP_PASS[256];
	static char TEMP_SERVER[256];


protected:
	// settings
	static HINSTANCE hInstance;
	static HWND parent;
	static bool bLog;
	static bool bMsgboxes;

	static int nServers;

	BOOL bWorking;

};

#endif