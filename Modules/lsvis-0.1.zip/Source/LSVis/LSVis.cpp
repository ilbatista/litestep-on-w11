/* LSVis.cpp
 * Copyright (c) 2003,2004 Brian Hartvigsen
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike License. To view a copy of this license,
 * visit http://creativecommons.org/licenses/by-nc-sa/2.0/ or send a letter to
 * Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
 */
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")

#include "../../Litestep/lsapi/lsApi.h"
#pragma comment(lib, "../../LiteStep/lsapi/lsapi.lib")
#if !defined(DEBUG)
#pragma warning(disable: 4244)
#pragma warning(disable: 4800)
#endif

#include "FFT.h"

unsigned char waveformData[3][576] = {0,};
unsigned char spectrumData[3][576] = {0,};

LPCSTR szAppName = "LSVis";

HWND hMainWnd;
HDC memDC;
HBITMAP memBM;
HBITMAP oldBM;
bool isWinSockRunning;

#define EQ_DROP_SMALL /*4.0/256//*/(0.15 * height) / 100.0
#define EQ_DROP_LARGE /*50.0/256//*/(1.95 * height) / 100.0

struct sockaddr_in server;

int width, height, visType;

int eqBands;
COLORREF eqPeakColor, eqBarColor, eqBackColor;

int RenderVU( void );
int RenderEq( void );
int RenderAnalyser( void );
int RenderOscilliscope( void );
void GetVisData( void );

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_NCHITTEST:	return HTCAPTION;
		case WM_CREATE:		return 0;
		case WM_ERASEBKGND: return 0;
		case WM_CLOSE:		return 0;

		case WM_PAINT:
		{ // update from doublebuffer
			PAINTSTRUCT ps;
			RECT r;
			HDC hdc = BeginPaint(hwnd,&ps);
			GetClientRect(hwnd,&r);
			BitBlt(hdc,0,0,r.right,r.bottom,memDC,0,0,SRCCOPY);
			EndPaint(hwnd,&ps);
		}
		return 0;

		case WM_TIMER:
		{
			GetVisData();
			
			switch( visType )
			{
				case 4:
					RenderOscilliscope();
					break;
				case 3:
					RenderAnalyser();
					break;
				case 2:
					RenderVU();
					break;
				default:
					RenderEq();
					break;
			}
		}
		return 0;

		default:
			return DefWindowProc(hwnd,message,wParam,lParam);
	}
}

void StartWinSock( HWND sender, LPCSTR args )
{
	if( !isWinSockRunning )
	{
		WSADATA wsaData;
		struct hostent *hp;
		unsigned int addr;
		char hostname[MAX_PATH];

		GetRCString( "LSVisHostName", hostname, "127.0.0.1", MAX_PATH );

		if( WSAStartup( MAKEWORD( 2,0 ), &wsaData ) )
			return;

		/*
		if( inet_addr( hostname ) == INADDR_NONE )
					hp = gethostbyname( hostname );
				else
				{
					addr = inet_addr( hostname );
					hp = gethostbyaddr( (char*)&addr, sizeof(addr), AF_INET );
				}*/
		hp = gethostbyname( hostname );

		if( hp == NULL )
			return;
		
		server.sin_addr.s_addr = *((unsigned long*)hp->h_addr);
		server.sin_family = AF_INET;
		server.sin_port = htons(54175);

		SetTimer( hMainWnd, 1, GetRCInt( "LSVisDelay", 100 ), NULL );
		isWinSockRunning = true;
	}
}

void StopWinSock( HWND sender, LPCSTR args )
{
	if( isWinSockRunning )
	{
		KillTimer( hMainWnd, 1 );
		WSACleanup();
		isWinSockRunning = false;
	}
}

int initModuleEx(HWND ParentWnd, HINSTANCE hInstance, LPCSTR szPath)
{
	{
		WNDCLASS wc;
		ZeroMemory( &wc, sizeof(WNDCLASS) );
		wc.hbrBackground = (HBRUSH)GetStockObject( BLACK_BRUSH );
		wc.hCursor = LoadCursor( NULL, IDC_ARROW );
		wc.hInstance = hInstance;
		wc.lpfnWndProc = WndProc;
		wc.lpszClassName = szAppName;
		
		if( !RegisterClass( &wc ) )
			return -1;
	}

	width = GetRCInt( "LSVisWidth", 75 );
	height = GetRCInt( "LSVisHeight", 20 );
	visType = GetRCInt( "LSVisType", 1 );

	int x = GetRCInt( "LSVisX", 0 );
	int y = GetRCInt( "LSVisY", 0 );

	if( x < 0 )
		x = LSGetSystemMetrics( SM_CXSCREEN ) + x;

	if( y < 0 )
		y = LSGetSystemMetrics( SM_CYSCREEN ) + y;



	hMainWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,
		szAppName,
		NULL,
		WS_POPUP,
		x,
		y,
		width,
		height,
		ParentWnd,
		NULL,
		hInstance,
		NULL );

	if( !hMainWnd )
		return -1;

	{	// adjust size of window to make the client area exactly width x height
		RECT r;
		bool aot = GetRCBoolDef( "LSVisAlwaysOnTop", false );
		GetClientRect( hMainWnd, &r );
		SetWindowPos( hMainWnd, aot ? HWND_TOPMOST : HWND_TOP, 0, 0, width * 2 - r.right, height * 2 - r.bottom, SWP_NOMOVE );
	}

	AddBangCommand( "!LSVisStart", StartWinSock );
	AddBangCommand( "!LSVisStop", StopWinSock );

	eqBarColor = GetRCColor( "LSVisEqBarColor", RGB( 255, 255, 255 ) );
	eqBackColor = GetRCColor( "LSVisEqBackColor", RGB( 0, 0, 0 ) );
	eqPeakColor = GetRCColor( "LSVisEqPeakColor", RGB( 255, 0, 255 ) );
	eqBands = GetRCInt( "LSVisEqBands", 20 );

	StartWinSock( hMainWnd, NULL );

	ShowWindow( hMainWnd, SW_SHOWNORMAL );
	HDC hdc = GetDC( hMainWnd );
	memDC = CreateCompatibleDC(hdc);
	memBM = CreateCompatibleBitmap(hdc,width,height);
	oldBM = (HBITMAP)SelectObject(memDC,memBM);
	ReleaseDC( hMainWnd, hdc );
	
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	SelectObject(memDC,oldBM);	// delete our doublebuffer
	DeleteObject(memDC);
	DeleteObject(memBM);

	StopWinSock( hMainWnd, NULL );
	DestroyWindow( hMainWnd );
	UnregisterClass( szAppName, dllInst );
}

int RenderOscilliscope( void )
{
	int x, y;
	// clear background
	Rectangle( memDC, 0, 0, width, height );

	float xOffset = 0;

	if( width > 576 )
		xOffset = width / 576;

	// draw oscilliscope
	for( y = 0; y < 2; y ++ )
	{
		MoveToEx( memDC,0,( y * height ) >> 1, NULL );
		for( x = 0; x < width; x++ )
		{
			LineTo( memDC, ( x + ( xOffset * (float)x ) ), ( y * height + waveformData[y][x] ^ ( height / 2 ) ) >> 1 );
		}
	}
	{ // copy doublebuffer to window
		HDC hdc = GetDC( hMainWnd );
		BitBlt( hdc, 0, 0, width, height, memDC, 0, 0, SRCCOPY) ;
		ReleaseDC( hMainWnd,hdc );
	}
	return 0;
}

// render function for analyser. Returns 0 if successful, 1 if visualization should end.
int RenderAnalyser( void )
{
	int x, y;
	// clear background
	Rectangle( memDC, 0, 0, width, height);
	
	// draw analyser
	float xOffset = 0;

	for (y = 0; y < 2; y ++)
	{
		for (x = 0; x < 576 && x < width; x++ )
		{
			MoveToEx( memDC, x, ( y * height + height ) >> 1, NULL);
			LineTo( memDC, x, ( y * height + height - spectrumData[y][x] ) >> 1 );
		}
	}
	{ // copy doublebuffer to window
		HDC hdc = GetDC( hMainWnd );
		BitBlt (hdc, 0, 0, 288, 256, memDC, 0, 0, SRCCOPY);
		ReleaseDC( hMainWnd, hdc );
	}
	return 0;
}


// render function for VU meter. Returns 0 if successful, 1 if visualization should end.
int RenderVU( void )
{
	int x, y;
	// clear background
	Rectangle( memDC, 0, 0, width, height );
	// draw VU meter
	for (y = 0; y < 2; y ++)
	{
		int last = waveformData[y][0];
		int total = 0;
		for( x = 1; x < 576; x ++ )
		{
			total += abs( last - waveformData[y][x] );
			last = waveformData[y][x];
		}
		total /= 288;
		if ( total > (width / 2) - 1 ) total = ( width / 2) - 1;
		if ( y ) Rectangle( memDC, (width / 2), 0, (width / 2) + total, height );
		else Rectangle( memDC, (width / 2) - total, 0, (width / 2), height );
	}
	{ // copy doublebuffer to window
		HDC hdc = GetDC( hMainWnd );
		BitBlt( hdc, 0, 0, width, height, memDC, 0, 0, SRCCOPY );
		ReleaseDC( hMainWnd, hdc );
	}
	return 0;
}

int RenderEq( void )
{
	static float eqOldBuf[512] = {0,};
	static float eqPeakBuf[512] = {0,};
	float temp_wave[576];
	float temp2[576];
	float Data[512];

	FFT fft;
	//for( int oSamples = 2; oSamples < eqBands; oSamples = oSamples << 1 );

	fft.Init( 576, 512 );
	int old_i = 0;
	for( int i = 0; i < 576; i++ )
	{
		temp2[i] = (float)((waveformData[2][i] ^ 128) - 128);
//        waveformData[1][i] = (float)((waveformData[1][i] ^ 128) - 128);

		temp_wave[i] = 0.5f*(temp2[i] + temp2[old_i]);
		//temp_wave[i] = temp2[i];
		old_i = i;
	}

	fft.time_to_frequency_domain(temp_wave, temp2);
	
	float d = eqBands / 512.0;
	
	for( i = 0; i < 512; i++ ) Data[i] = 0;
	for( i = 0; i < 512; i++ )
	{
		int o = i * d;
		Data[o] += temp2[i] * d;
	}

	for( i = 0; i < eqBands; i++ )
	{
		if( Data[i] > 1 ) Data[i] = 1;
		else if( Data[i] < 0 ) Data[i] = 0;
	}
		
	for( i = 0; i < eqBands; i++ )
	{
		if( eqOldBuf[i] > EQ_DROP_LARGE )
			eqOldBuf[i] -= EQ_DROP_LARGE;
		else
			eqOldBuf[i] = 0;

		if( Data[i] > eqOldBuf[i] )
			eqOldBuf[i] = Data[i];
		else
			Data[i] = eqOldBuf[i];

		eqOldBuf[i] = Data[i];

		if( eqPeakBuf[i] > ( eqOldBuf[i] + EQ_DROP_SMALL ) )
			eqPeakBuf[i] -= EQ_DROP_SMALL;
		else
			eqPeakBuf[i] = eqOldBuf[i];
	}

	{
		RECT r = { 0, 0, width, height };
		HBRUSH backBrush  = CreateSolidBrush( eqBackColor );
		FillRect( memDC, &r, backBrush );
		DeleteObject( backBrush );
	}

	HBRUSH barBrush = CreateSolidBrush( eqBarColor );
	HPEN peakPen = CreatePen( PS_SOLID, 1, eqPeakColor );
	HPEN oldPen = (HPEN)SelectObject( memDC, (HPEN)peakPen );

	for( i  = 0; i < eqBands; i++ )
	{
		int H = height * ( 1.0 - Data[i] );
		int X1 = i * width / (eqBands - 1);
		int X2 = ((i + 1) * width / (eqBands - 1)) - 1;
		RECT R1 = { X1, H, X2, height };

		FillRect( memDC, &R1, barBrush );

		H = height * (1.0 - eqPeakBuf[i]);
		MoveToEx( memDC, X1, H, NULL);
		LineTo( memDC, X2, H );
	}
	
	SelectObject( memDC, oldPen );
	DeleteObject( peakPen );
	DeleteObject( barBrush );

	{ // copy doublebuffer to window
		HDC hdc = GetDC( hMainWnd );
		BitBlt( hdc, 0, 0, width, height, memDC, 0, 0, SRCCOPY );
		ReleaseDC( hMainWnd, hdc );
	}

	return 0;
}
void ComposeArrays( unsigned const char a[576], unsigned const char b[576], unsigned char c[576] )
{
	for( int i = 0; i < 576; i++ )
	{
		if( a[i] > b[i] )
			c[i] = a[i];
		else
			c[i] = b[i];
	}
}

/*static */bool connecting = false;
void GetVisData( void )
{
	static SOCKET conn;
	if( conn ) return;

	conn = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );

	if( conn == INVALID_SOCKET )
	{
		conn = NULL;
		return;
	}

	if( connect( conn, (struct sockaddr*)&server, sizeof(server) ) )
	{
		closesocket( conn );
		conn = NULL;
		return;	
	}

	recv( conn, (char *)waveformData[0], 576, 0 );
	recv( conn, (char *)waveformData[1], 576, 0 );
	recv( conn, (char *)spectrumData[0], 576, 0 );
	recv( conn, (char *)spectrumData[1], 576, 0 );

	ComposeArrays( waveformData[0], waveformData[1], waveformData[2] );
	ComposeArrays( spectrumData[0], spectrumData[1], spectrumData[2] );
	
	closesocket (conn );
	conn = NULL;
}