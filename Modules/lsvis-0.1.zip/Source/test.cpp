/* test.cpp
 * Copyright (c) 2003,2004 Brian Hartvigsen
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike License. To view a copy of this license,
 * visit http://creativecommons.org/licenses/by-nc-sa/2.0/ or send a letter to
 * Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
 *
 * Uses Winamp test visualization library v1.0
 * Copyright (C) 1997-1998, Justin Frankel/Nullsoft
 */
#include <windows.h>
#include "vis.h"

// stop bugging me about the damn LPVOID to bool!  I know already!
#pragma warning(disable:4800)

SOCKET server;
HANDLE hThread;
bool dataLock;
unsigned char spectrumData[2][576];
unsigned char waveformData[2][576];

// returns a winampVisModule when requested. Used in hdr, below
winampVisModule *getModule(int which);

// "member" functions
void config(struct winampVisModule *this_mod); // configuration dialog
int init(struct winampVisModule *this_mod);	   // initialization for module
int init2(struct winampVisModule *this_mod);	   // initialization for module
int render(struct winampVisModule *this_mod);  // rendering for module 1
void quit(struct winampVisModule *this_mod);   // deinitialization for module
DWORD WINAPI ServerThread( LPVOID pParam );
DWORD WINAPI ClientThread( LPVOID pParam );

// Module header, includes version, description, and address of the module retriever function
winampVisHeader hdr = { VIS_HDRVER, "NetVis v1.0", getModule };

// first module (oscilliscope)
winampVisModule mod1 =
{
	"Localhost Only",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	0,		// sRate
	0,		// nCh
	25,		// latencyMS
	25,		// delayMS
	2,		// spectrumNch
	2,		// waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config,
	init,
	render, 
	quit
};

winampVisModule mod2 =
{
	"Any Host",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	0,		// sRate
	0,		// nCh
	25,		// latencyMS
	25,		// delayMS
	2,		// spectrumNch
	2,		// waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config,
	init2,
	render, 
	quit
};


// this is the only exported symbol. returns our main header.
// if you are compiling C++, the extern "C" { is necessary, so we just #ifdef it
#ifdef __cplusplus
extern "C" {
#endif
__declspec( dllexport ) winampVisHeader *winampVisGetHeader()
{
	return &hdr;
}
#ifdef __cplusplus
}
#endif

// getmodule routine from the main header. Returns NULL if an invalid module was requested,
// otherwise returns either mod1, mod2 or mod3 depending on 'which'.
winampVisModule *getModule(int which)
{
	switch( which )
	{
		case 0:
			return &mod1;
		case 1:
			return &mod2;
		default:
			return NULL;
	}
}

// configuration. Passed this_mod, as a "this" parameter. Allows you to make one configuration
// function that shares code for all your modules (you don't HAVE to use it though, you can make
// config1(), config2(), etc...)
void config(struct winampVisModule *this_mod)
{
	MessageBox( this_mod->hwndParent, "This module is Copyright (c) 2003, Brian Hartvigsen\n"
									  "   This module allows you to set up a server that will\n"
									  "   feed clients the visualization data\n\n"
									  "   Select \"Localhost Only\" or \"Any Host\" to to\n"
									  "   restrict who can request the data.\n\n"
									  "   NetVis uses TCP port 54174", "Configuration", MB_OK );
//	MessageBox(this_mod->hwndParent,"This module is Copyright (c) 1997-1998, Justin Frankel/Nullsoft\n"
//									"-- This is just a demonstration module, it really isn't\n"
//									"   supposed to be enjoyable --","Configuration",MB_OK);
									
}

// initialization. Registers our window class, creates our window, etc. Again, this one works for
// both modules, but you could make init1() and init2()...
// returns 0 on success, 1 on failure.
int init(struct winampVisModule *this_mod)
{
	hThread = CreateThread( NULL, 0, ServerThread, (LPVOID)false, 0, NULL );
	
	return 0;
}

int init2(struct winampVisModule *this_mod)
{
	hThread = CreateThread( NULL, 0, ServerThread, (LPVOID)true, 0, NULL );
	
	return 0;
}

// render function for oscilliscope. Returns 0 if successful, 1 if visualization should end.
int render(struct winampVisModule *this_mod)
{
	memcpy( spectrumData[0], this_mod->spectrumData[0], 576 );
	memcpy( spectrumData[1], this_mod->spectrumData[1], 576 );
	memcpy( waveformData[0], this_mod->waveformData[0], 576 );
	memcpy( waveformData[1], this_mod->waveformData[1], 576 );
	return 0;
}

// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quit(struct winampVisModule *this_mod)
{
//	config_write(this_mod);		// write configuration
	TerminateThread( hThread, 0 );
	CloseHandle( hThread );
    closesocket( server );
    WSACleanup();
}

DWORD WINAPI ClientThread( LPVOID pParam )
{
    SOCKET client=(SOCKET)pParam;

	send( client, (char *)waveformData[0], sizeof(waveformData[0]), 0 );
	send( client, (char *)waveformData[1], sizeof(waveformData[1]), 0 );
	send( client, (char *)spectrumData[0], sizeof(waveformData[0]), 0 );
	send( client, (char *)spectrumData[1], sizeof(waveformData[1]), 0 );
	
    closesocket(client);
    ExitThread( 0 );
}

DWORD WINAPI ServerThread( LPVOID pParam )
{	
    //cout << "Starting up TCP server\r\n";

    //A SOCKET is simply a typedef for an unsigned int.
    //In Unix, socket handles were just about same as file 
    //handles which were again unsigned ints.
    //Since this cannot be entirely true under Windows
    //a new data type called SOCKET was defined.    

    //WSADATA is a struct that is filled up by the call 
    //to WSAStartup
    WSADATA wsaData;

    //The sockaddr_in specifies the address of the socket
    //for TCP/IP sockets. Other protocols use similar structures.
    sockaddr_in local;
	bool anyhost = (bool) pParam;

    //WSAStartup initializes the program for calling WinSock.
    //The first parameter specifies the highest version of the 
    //WinSock specification, the program is allowed to use.
    //WSAStartup returns zero on success.
    //If it fails we exit.
    if( WSAStartup( MAKEWORD(2,0) ,&wsaData ) != 0 )
    {
        ExitThread( 0 );
    }

    //Now we populate the sockaddr_in structure
    local.sin_family = AF_INET; //Address family
	if( anyhost )
		local.sin_addr.s_addr = INADDR_ANY; //Wild card IP address
	else
	{
		hostent *ptrh = gethostbyname( "localhost" );
		if( ((char *)ptrh) == NULL )
			ExitThread( 0 );
		memcpy( &local.sin_addr, ptrh->h_addr, ptrh->h_length );
	}

    local.sin_port = htons( (u_short)54175 ); //port to use

    //the socket function creates our SOCKET
    server = socket( AF_INET,SOCK_STREAM,0 );

    //If the socket() function fails we exit
    if( server == INVALID_SOCKET )
    {
        ExitThread( 0 );
    }

    //bind links the socket we just created with the sockaddr_in 
    //structure. Basically it connects the socket with 
    //the local address and a specified port.
    //If it returns non-zero quit, as this indicates error
    if( bind( server, (sockaddr*)&local, sizeof( local ) ) != 0)
    {
        ExitThread( 0 );
    }

    //listen instructs the socket to listen for incoming 
    //connections from clients. The second arg is the backlog
    if( listen( server, 10 ) != 0 )
    {
        ExitThread( 0 );
    }

    //we will need variables to hold the client socket.
    //thus we declare them here.
    SOCKET client;
    sockaddr_in from;
    int fromlen = sizeof( from );

    while( true )
    {
        client = accept( server, (struct sockaddr*)&from, &fromlen);
		CloseHandle(CreateThread( NULL, 0, ClientThread, (LPVOID)client, 0, NULL ));
    }	
}