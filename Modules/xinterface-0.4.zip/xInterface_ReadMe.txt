-\\____________________________//-
-//                            \\-
         xInterface  v0.4
	        by Andymon
	 andymon@ls-universe.info
-\\____________________________//-
-//                            \\-

--------
Overview
--------

    Currently only Four little "interface(s)" (for xLabel for instance)!
    Interface for Recycle -> "xRecycle"
    Interface for SHUTDOWN/RESTART/LOGOFF -> "xSystem"
    Interface to the Recycle Bin -> "xTrash"
    Interface to the number of HardDisks -> "xHardDisk"
    Maybe more is added in the future, maybe not.
    
    I hope for other coders (or new ideas with source attached :P)

----------
 xRecycle
----------

  -----------------
   xRecycle Config
  -----------------
   
  xRecycleOverride BOOL
    If set the "normal" !Recycle is replaced with the new Bang functionality.
    So every !recycle will do the stuff a !xRecycle would do!
    
  xRecycleAction ACTION
    Any valid Litestep Action, which will be performed BEFORE the Recycle is launched.
  
  ----------------
   xRecycle Bangs
  ----------------
  
  !xRecycle [DELAY in MILLISEC]  or  !Recycle [DELAY in MILLISEC]
    Performs a normal recycle, when used without argument.
    With argument (timeout in milliseconds) the recycle is performed delayed.
    
    
---------
 xSystem
---------

  ---------------
   xSystem Bangs
  ---------------

  !xShutDown
  !xShutDown ".delay" MIN SEC
  !xShutDown ".exact" HOUR MIN
    Performs a direct Shutdown.
    
  !xRestart
  !xRestart ".delay" MIN SEC
  !xRestart ".exact" HOUR MIN
    Performs a direct Restart.
    
  !xLogOff
  !xLogOff ".delay" MIN SEC
  !xLogOff ".exact" HOUR MIN
    Performs a direct LogOff.
    
  !xCancel
    Cancels a timed !xShutDown, !xRestart or !xLogOff
    
  ------------------------
   xSystem Exported Evars
  ------------------------
  
    xSystemActionTimeLeft "MIN:SEC"
    
    xSystemActionTime "HOUR:MIN"


--------
 xTrash
--------

  ---------------
   xTrash Config
  ---------------

  xTrashBecomesEmpty ACTION
    ACTION is fired, if the RecycleBin is empty(Startup) or is purged.

  xTrashBecomesFilled ACTION
    ACTION is fired, if the RecycleBin is filled(Startup) or something is deleted into the EMPTY RecycleBin.
    
  xTrashOnChange ACTION
    ACTION is fired, if the RecycleBin content changes. Will also fire together with xTrashBecomesEmpty and xTrashBecomesFilled.

  xTrashCheckInterval INT
    INT is the time is sec, between checks of the RecycleBin. Default is 30sec

  -----------------------
   xTrash Exported Evars
  -----------------------
  
  xTrashItemCount INT
    Exports the current count of item(s) in the RecycleBin
    
  xTrashItemSize STRING
    Exports the current size of item(s) in the RecycleBin in matching valid units (kb, mb, gb, ...)
  
  --------------
   xTrash Bangs
  --------------
  
  !xTrashEmpty
    Delete the RecycleBin.



-----------
 xHardDisk
-----------

 --------------------------
   xHardDisk Exported Evar
  -------------------------
  
  xHardDiskCount INT
    Exports the current count of HardDisk(s) (Logical HardDisk Drives) in your PC
    

-----------------------------------------------------------------------------
Changes for xInterface
-----------------------------------------------------------------------------

0.4 Release on 13-03-2006, Changes by Andymon

- Added: xRecycleOverride BOOL
         If set the "normal" !Recycle is replaced with the new Bang functionality.
         So every !recycle will do the stuff a !xRecycle would do!
    
- Added: xRecycleAction ACTION
         Any valid Litestep Action, which will be performed BEFORE the Recycle is launched.
  
- Added: !xRecycle [DELAY in MILLISEC]  or  !Recycle [DELAY in MILLISEC]
         Performs a normal recycle, when used without argument.
         With argument (timeout in milliseconds) the recycle is performed delayed.

0.3 Release on 08-03-2006, Changes by Andymon

- Added: !xShutDown
         !xShutDown ".delay" MIN SEC
         !xShutDown ".exact" HOUR MIN
         Performs a direct Shutdown.
    
- Added: !xRestart
         !xRestart ".delay" MIN SEC
         !xRestart ".exact" HOUR MIN
         Performs a direct Restart.
    
- Added: !xLogOff
         !xLogOff ".delay" MIN SEC
         !xLogOff ".exact" HOUR MIN
         Performs a direct LogOff.
    
- Added: !xCancel
         Cancels a timed !xShutDown, !xRestart or !xLogOff

- Added: xSystemActionTimeLeft "MIN:SEC"
         Exports the time (in min:sec) left before ACTION is executed.
    
- Added: xSystemActionTime "HOUR:MIN"
         Exports the defined time (in hour:min) to execute ACTION.

- Fixed: Missing KillTimer on Recycle.

0.2 Release on 19-05-2005, Changes by Andymon

- Added: xTrashOnChange ACTION
         ACTION is fired, if the RecycleBin content changes. Will also fire together with xTrashBecomesEmpty and xTrashBecomesFilled.

- Added: xTrashItemSize STRING
         Exports the current size of item(s) in the RecycleBin in matching valid units (kb, mb, gb, ...)

0.1 Inital Release on 20-09-2005, Changes by Andymon


           
           