-\\____________________________//-
-//                            \\-
         xInterface  v0.1
	        by Andymon
	 andymon@ls-universe.info
-\\____________________________//-
-//                            \\-

--------
Overview
--------

    Currently only TWO little "interface(s)" (for xLabel for instance)!
    Interface to the Recycle Bin -> "xTrash"
    Interface to the number of HardDisks -> "xHardDisk"
    Maybe more is added in the future, maybe not.
    
    I hope for other coders (or new ideas with source attached :P)


--------
 xTrash
--------

  ---------------
   xTrash Config
  ---------------

  xTrashBecomesEmpty ACTION
    ACTION is fired, if the RecycleBin is empty(Startup) or is purged.

  xTrashBecomesFilled ACTION
    ACTION is fired, if the RecycleBin is filled(Startup) or something is deleted into it.

  xTrashCheckInterval INT
    INT is the time is sec, between checks of the RecycleBin. Default is 30sec

  ----------------------
   xTrash Exported Evar
  ----------------------
  
  xTrashItemCount INT
    Exports the current count of item(s) in the RecycleBin
  
  -------------
   xTrash Bang
  -------------
  
  !xTrashEmpty
    Delete the RecycleBin.



-----------
 xHardDisk
-----------

 --------------------------
   xHardDisk Exported Evar
  -------------------------
  
  xHardDiskCount INT
    Exports the current count of HardDisk(s) (Logical HardDisk Drives) in your PC
    

-----------------------------------------------------------------------------
Changes for xInterface
-----------------------------------------------------------------------------

0.1 Inital Release on 20-09-2005, Changes by Andymon


           
           