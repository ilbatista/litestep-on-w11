VBModulo Loader
Author: James Elkins
Email: jelkins@dhcp-58-70.adacpe.cableone.net
URL: http://dhcp-58-70.adacpe.cableone.net/vbmodulo/

This program helps load VB Active-X dll's in LiteStep.

Be sure and place the vblsapi.dll and vbmodulo.dll in the litestep directory with lsapi.dll.

I have included a test vb Active-X dll with source code.

To load a VB dll for LiteStep you first have to load VBModulo

	LoadModule "vblsapi.dll"

Then to tell VBModulo to load your dll's add 

	VBLoadModule <VB Project Name> <Class Name>

the project name is the actual name of the dll, the class name is for the name of the class that has the VBinitModuleEx & VBquitModule functions.

For example:
	The included example vbmodulo is Test.dll and the class name is cModulo
	so you would add a line in the step.rc file like this

		LoadModule "vblsapi.dll"	---	to load the VBModulo Loader
		VBLoadModule Test cModulo	---	Load the VBModulo


Thats about it, If you have any questions or comments send them to me.
