// HTMLFont.cpp: implementation of the CHTMLFont class.
//
//////////////////////////////////////////////////////////////////////
// (c) Jerome Sopocko 2003
// this code worked last time I saw it
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HTMLFont.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHTMLFont::CHTMLFont()
{
	m_rgbColor	= 0;
	m_strName = _T("Arial");
	m_dSize = 15;
	m_isBold = false;
	m_isItalic = false;
	m_isUnderline = false;
	m_nCharSet = 0;
}

CHTMLFont::~CHTMLFont()
{

}

CHTMLFont::CHTMLFont(const CHTMLFont & fnt)
{
	CopyProperties(fnt);
}

CHTMLFont & CHTMLFont::operator =(const CHTMLFont & fnt)
{
	if ( this != &fnt )
		CopyProperties(fnt);
	return *this;
}

void CHTMLFont::CopyProperties(const CHTMLFont & fnt)
{
	m_strName 		= fnt.m_strName;
	m_dSize 		= fnt.m_dSize;
	m_isBold 		= fnt.m_isBold;
	m_isItalic 		= fnt.m_isItalic;
	m_isUnderline 	= fnt.m_isUnderline;
	m_nCharSet 		= fnt.m_nCharSet;
	m_rgbColor 		= fnt.m_rgbColor;
}


void CHTMLFont::DeleteArray(CObArray & arrArray)
{
	for ( int nObj=0; nObj < arrArray.GetSize(); nObj++)
		delete (CHTMLFont *) arrArray[nObj];
	arrArray.RemoveAll();
}

CFont* CHTMLFont::GetFont(CDC * pDC) const
{
	CFont * pFont=new CFont;

	int lfHeight = (int) m_dSize;

	pFont->CreateFont( lfHeight, 0, 0, 0, m_isBold ? FW_BOLD : FW_NORMAL, m_isItalic, m_isUnderline, 0, (BYTE) m_nCharSet, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, m_strName);

	return pFont;
}
