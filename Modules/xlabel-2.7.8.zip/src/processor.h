#if !defined(__PROCESSOR_H)
#define __PROCESSOR_H

bool startProcessorStatistics();
int getProcessorUsage();
bool endProcessorStatistics();

#endif
