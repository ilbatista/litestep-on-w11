//
// This is part of ScreenHK, the hotkey module for ScreenWM.
// Copyright (C) 2008 James Babcock (jimrandomh)
// This program is partially derived from the Litestep shell.
// Copyright (C) 1997-2001 The LiteStep Development Team
// Copyright (C) 1997-98 Francis Gastellu (aka Lone Runner/Aegis)
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
#ifndef __HOTKEY_H
#define __HOTKEY_H

#pragma	warning(disable: 4786) // STL naming warnings

#define WIN32_LEAN_AND_MEAN

#include "../lib/xpaintclass/lsapi/lsapi.h"

#define LM_POPUP        9182
#define magicDWord      0x49474541

#include <string>
using std::string;
#include <vector>
using std::vector;
#include <map>
using std::map;
#include "lswinbase.h"

class HotkeyGroup;

struct HotkeyAction
{
	virtual ~HotkeyAction() {}
	virtual void activate()=0;
};

struct ModifiedKey
{
	char ch;
	int modifiers;
	
	bool operator==(const ModifiedKey &rhs) const;
	bool operator<(const ModifiedKey &rhs) const;
};

struct HotkeyType
{
	ModifiedKey key;

	bool registered;
	int index;
	
	string command;
	string parameters;
};

class HotkeyGroup
{
public:
	HotkeyGroup(string name);
	string getName();
	void addHotkey(HotkeyType key);
	
	void activate(HWND window);
	void deactivate(HWND window);
	void deactivateShadowed(HWND window, HotkeyGroup *shadow);
	void reactivateShadowed(HWND window, HotkeyGroup *shadow);
	void changeShadow(HWND window, HotkeyGroup *oldShadow, HotkeyGroup *newShadow);
	
private:
	void activateKey(HWND window, HotkeyType *key);
	void deactivateKey(HWND window, HotkeyType *key);
	
	string name;
	vector<HotkeyType> keys;
};

class Hotkey : public Window
{
private:
	bool loadExplorerKeys;
	bool noWinKeyPopup;
	bool noShellWarning;
	bool explorerNoWarn;
	vector<ATOM> atomHotkeys;
	
	HotkeyGroup *rootHotkeyGroup;
	HotkeyGroup *currentHotkeyGroup;
	vector<HotkeyType> hotKeys;
	map<string, HotkeyGroup*> hotkeyGroups;

public:
	Hotkey(HWND parentWnd, int& code);
	~Hotkey();
	
	void setActiveGroup(const char *groupname);
	void reset();

private:
	bool parseHotkey(char *str, HotkeyType *hotkey, string *groupName);
	string parseHotkeyGroup(char *buf);
	
	void loadHotkeys();
	void loadExplorerHotkeys();
	void findLnks(const char *searchDir);
	void addExplorerHotkey(const char*, const char*);
	void freeHotkeys();
	void freeExplorerHotkeys();
	void showPopup();

	virtual void windowProc(Message& message);
	void onCreate(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onRefresh(Message& message);
	void onSysCommand(Message& message);
	void onDestroy(Message& message);
	void onHotkey(Message& message);
	void onTimer(Message& message);
};

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
