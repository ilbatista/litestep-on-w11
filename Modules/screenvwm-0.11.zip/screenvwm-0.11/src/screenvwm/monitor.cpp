/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"
#include <algorithm>

/////////////////////////////////////////////////////////////////////////////

MonitorPool *monitors = NULL;

BOOL CALLBACK enumMonitors(HMONITOR monitor, HDC hdc, LPRECT boundingRect, LPARAM data)
{
	vector<Monitor*> *monitorList = (vector<Monitor*>*)data;
	string monitorName = retprintf("%i", monitorList->size()+1);
	Monitor *newMonitor = new Monitor(monitor, monitorName, Rect(*boundingRect));
	monitorList->push_back(newMonitor);
	return TRUE;
}

MonitorPool::MonitorPool()
{
	EnumDisplayMonitors(NULL, NULL, enumMonitors, (LPARAM)&monitors);
}

MonitorPool::~MonitorPool()
{
	for(unsigned ii=0; ii<monitors.size(); ii++)
		delete monitors[ii];
	monitors.clear();
}

void MonitorPool::refresh()
{
	//vector<Monitor*> newMonitors;
	//EnumDisplayMonitors(NULL, NULL, enumMonitors, (LPARAM)&newMonitors);
	
	// TODO
}

int MonitorPool::numMonitors()
{
	return monitors.size();
}

vector<Monitor*> MonitorPool::findMonitor(Rect windowPos)
{
	// Given the location of a window, find all the monitors that window
	// is (partially or completely) visible on. If the window is off-screen
	// (eg, on a virtual desktop that's not selected), returns the empty set.
	// If the window is on more than one monitor, sorted in descending order
	// by visible area.
	vector<Monitor*> ret;
	
	for(unsigned ii=0; ii<monitors.size(); ii++)
	{
		if(monitors[ii]->getRect().overlaps(windowPos))
			ret.push_back(monitors[ii]);
	}
	
	struct MonitorComparator
	{
		MonitorComparator(Rect windowPos)
			:windowPos(windowPos) {}
		bool operator()(Monitor *a, Monitor *b)
			{ return a->getOverlapArea(windowPos) > b->getOverlapArea(windowPos); }
		Rect windowPos;
	};
	MonitorComparator comparator(windowPos);
	
	std::sort(ret.begin(), ret.end(), comparator);
	
	return ret;
}

Monitor *MonitorPool::findMonitor(Point cursorPos)
{
	for(unsigned ii=0; ii<monitors.size(); ii++)
		if(monitors[ii]->getRect().containsPoint(cursorPos.x, cursorPos.y))
			return monitors[ii];
	return NULL;
}

Monitor *MonitorPool::getMonitor(int index)
{
	if(index<0 || index>=(int)monitors.size())
		return NULL;
	return monitors[index];
}

Monitor *MonitorPool::getPrimaryMonitor()
{
	return monitors[0];
}

/////////////////////////////////////////////////////////////////////////////

Monitor::Monitor(HMONITOR handle, string name, Rect boundingRect)
{
	this->handle = handle;
	this->boundingRect = boundingRect;
	currentDesk = NULL;
	this->name = name;
}

Monitor::~Monitor()
{
}

VirtualDesktop *Monitor::getDesk()
	{ return currentDesk; }
void Monitor::setDesk(VirtualDesktop *desk)
	{ currentDesk = desk; }
Rect Monitor::getRect() const
	{ return boundingRect; }
string Monitor::getName()
	{ return name; }

vector<VWMPanel*> Monitor::getPanels()
{
	vector<VWMPanel*> allPanels;
	vwm->getPanels(&allPanels);
	
	vector<VWMPanel*> ret;
	for(unsigned ii=0; ii<allPanels.size(); ii++) {
		if(allPanels[ii]->getMonitor() == this)
			ret.push_back(allPanels[ii]);
	}
	return ret;
}

int Monitor::getOverlapArea(Rect &rect)
{
	if(!rect.overlaps(boundingRect))
		return 0;
	
	Rect intersection = rect.intersect(boundingRect);
	return intersection.width*intersection.height;
}

Rect Monitor::getMaximizeArea()
{
	MONITORINFO monitorInfo;
	monitorInfo.cbSize = sizeof monitorInfo;
	GetMonitorInfo(handle, &monitorInfo);
	
	return monitorInfo.rcWork;
}
