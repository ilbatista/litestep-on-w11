/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

FlowDirection directionFromString(const char *str)
{
	if(!_stricmp(str, "left"))       return directionLeftDown;
	if(!_stricmp(str, "right"))      return directionRightDown;
	if(!_stricmp(str, "up"))         return directionUpRight;
	if(!_stricmp(str, "down"))       return directionDownRight;
	if(!_stricmp(str, "left up"))    return directionLeftUp;
	if(!_stricmp(str, "left down"))  return directionLeftDown;
	if(!_stricmp(str, "right down")) return directionRightDown;
	if(!_stricmp(str, "right up"))   return directionRightUp;
	if(!_stricmp(str, "up left"))    return directionUpLeft;
	if(!_stricmp(str, "up right"))   return directionUpRight;
	if(!_stricmp(str, "down left"))  return directionDownLeft;
	if(!_stricmp(str, "down right")) return directionDownRight;
	
	// Default
	return directionRightDown;
}

WrappingFlow::WrappingFlow(FlowDirection dir, int minX, int minY, int maxX, int maxY)
	:dir(dir), minX(minX), minY(minY), maxX(maxX), maxY(maxY)
{
}

void WrappingFlow::start(int &x, int &y)
{
	switch(dir)
	{
		default:
		case directionRightDown: x = minX; y = minY; break;
		
		case directionRightUp:   x = minX; y = maxY; break;
		case directionLeftDown:  x = maxX; y = minY; break;
		case directionLeftUp:    x = maxX; y = maxY; break;
		case directionUpLeft:    x = maxX; y = maxY; break;
		case directionUpRight:   x = minX; y = maxY; break;
		case directionDownLeft:  x = maxX; y = minY; break;
		case directionDownRight: x = minX; y = minY; break;
	}
}

bool WrappingFlow::next(int &x, int &y, int stepX, int stepY)
{
	switch(dir)
	{
		default:
		case directionRightDown:
		case directionRightUp:
			if(x+stepX <= maxX) {
				x += stepX;
				return true;
			} else {
				x = minX;
				if(dir == directionRightUp) {
					y -= stepY;
					return (y>=minY);
				} else { //dir==directionRightDown or default
					y += stepY;
					return (y<=maxY);
				}
			}
			break;
		case directionLeftDown:
		case directionLeftUp:
			if(x-stepX >= minX) {
				x -= stepX;
				return true;
			} else {
				x = maxX;
				if(dir == directionLeftDown) {
					y += stepY;
					return (y<=maxY);
				} else { //dir==directionLeftUp
					y -= stepY;
					return (y>=minY);
				}
			}
		case directionUpLeft:
		case directionUpRight:
			if(y-stepY >= minY) {
				y -= stepY;
				return true;
			} else {
				y = maxY;
				if(dir == directionUpRight) {
					x += stepX;
					return (x<=maxX);
				} else { //dir==directionUpLeft
					x -= stepX;
					return (x>=minX);
				}
			}
		case directionDownLeft:
		case directionDownRight:
			if(y+stepY <= maxY) {
				y += stepY;
				return true;
			} else {
				y = minY;
				if(dir == directionDownRight) {
					x += stepX;
					return (x<=maxX);
				} else { //dir==directionUpLeft
					x -= stepX;
					return (x>=minX);
				}
			}
	}
}

bool WrappingFlow::isInBounds(int x, int y)
{
	return x>=minX && y>=minY && x<=maxX && y<=maxY;
}

void WrappingFlow::wrap(int &x, int &y, int stepX, int stepY)
{
	switch(dir) {
		default:
		case directionRightDown: x = minX; y += stepY; break;
		case directionRightUp:   x = minX; y -= stepY; break;
		case directionLeftDown:  x = maxX; y += stepY; break;
		case directionLeftUp:    x = maxX; y -= stepY; break;
		
		case directionUpLeft:    x -= stepX; y = maxY; break;
		case directionUpRight:   x += stepX; y = maxY; break;
		case directionDownLeft:  x -= stepX; y = minY; break;
		case directionDownRight: x += stepX; y = minY; break;
	}
}

bool WrappingFlow::isDown()
{
	return dir==directionDownLeft||dir==directionDownRight
	     ||dir==directionRightDown||dir==directionLeftDown;
}
bool WrappingFlow::isRight()
{
	return dir==directionRightDown||dir==directionRightUp
	     ||dir==directionUpRight||dir==directionDownRight;
}

bool WrappingFlow::fit(int &x, int &y, int width, int height)
{
	int xstep=isRight() ? (width-1) : (1-width);
	int ystep=isDown() ? (height-1) : (1-height);
	
	if(isInBounds(x+xstep, y+ystep))
		return true;
	wrap(x, y, width, height);
	return isInBounds(x+xstep, y+ystep);
}

RECT WrappingFlow::getRect(int x, int y, int width, int height)
{
	RECT ret;
	
	if(isRight()) {
		ret.left = x;
		ret.right = x+width;
	} else {
		ret.left = x-width;
		ret.right = x;
	}
	if(isDown()) {
		ret.top = y;
		ret.bottom = y+height;
	} else {
		ret.top = y-height;
		ret.bottom = y;
	}
	
	return ret;
}

bool directionIsVertical(FlowDirection dir)
{
	return dir==directionUpLeft||dir==directionUpRight
	     ||dir==directionDownLeft||dir==directionDownRight;
}

int directionCountSteps(FlowDirection dir, int x, int y, int minX, int minY, int maxX, int maxY, int stepX, int stepY)
{
	// TODO: Do this more efficiently (can be O(1) instead of this O(n) crap)
	int posX, posY;
	int ii=0;
	WrappingFlow flow(dir, minX, minY, maxX, maxY);
	flow.start(posX, posY);
	do {
		if(posX==x && posY==y)
			return ii;
		ii++;
	} while(flow.next(posX, posY, stepX, stepY));
	
	return -1;
}
