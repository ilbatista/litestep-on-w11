/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

MinimapElement::MinimapElement(string prefix)
	:RectLayoutElement(prefix)
{
	// Minimap display settings
	minimapTitleBarsThickness = getConfigBool("MinimapTitleBars", true, prefix.c_str())
		? getConfigInt("MinimapTitleBarThickness", 4, prefix.c_str())
		: 0;
	minimapIconSize = getConfigInt("MinimapIconSize", 16, prefix.c_str());
	if(!getConfigBool("MinimapTitleBars", true, prefix.c_str()))
		minimapTitleBarsThickness = 0;
	if(!getConfigBool("MinimapIcons", true, prefix.c_str()))
		minimapIconSize = 0;
	
	minimapWindowColor          = getConfigColor("MinimapWinColor", 255, 255, 255, prefix.c_str());
	minimapTitleBarColor        = getConfigColor("MinimapTitleBarColor", 80, 80, 80, prefix.c_str());
	minimapFocusedTitleBarColor = getConfigColor("MinimapFocusedTitleBarColor", 0, 0, 255, prefix.c_str());
	minimapWindowBorderColor    = getConfigColor("MinimapWinBorderColor", 0, 0, 0, prefix.c_str());
}

WindowData *MinimapElement::getWindow(ElementContext *context, int px, int py)
{
	// Convert to minimap-space coordinates
	Rect rect = context->boundingRect;
	POINT pt = {px-rect.left, py-rect.top};
	
	vector<WindowData*> windows = windowTracker->getWindows(context->desk);
	
	for(vector<WindowData*>::iterator it = windows.begin(); it != windows.end(); it++)
	{
		WindowData *windowData = *it;
		RECT vwmRect = screenToMinimapPos(context, windowData->lastScreenPos);
		
		if(PtInRect(&vwmRect, pt))
			return windowData;
	}
	
	return NULL;
}

class MinimapWindowPainter
{
public:
	HBRUSH windowBrush;
	HPEN pen;
	HBRUSH titleBarBrush;
	HBRUSH focusedTitleBarBrush;
	HBRUSH oldBrush;
	HPEN oldPen;
	RCSettings *settings;
	HDC backBuffer;
	MinimapElement *minimap;
	
	MinimapWindowPainter(RCSettings *settings, HDC backBuffer, MinimapElement *minimap)
		:settings(settings), backBuffer(backBuffer), minimap(minimap)
	{
		windowBrush = CreateSolidBrush(minimap->minimapWindowColor);
		titleBarBrush = CreateSolidBrush(minimap->minimapTitleBarColor);
		focusedTitleBarBrush = CreateSolidBrush(minimap->minimapFocusedTitleBarColor);
		pen = CreatePen(PS_SOLID, 1, minimap->minimapWindowBorderColor);
		oldBrush = (HBRUSH)SelectObject(backBuffer, windowBrush);
		oldPen = (HPEN)SelectObject(backBuffer, pen);
	}
	
	~MinimapWindowPainter()
	{
		SelectObject(backBuffer, oldBrush);
		SelectObject(backBuffer, oldPen);
		DeleteObject(windowBrush);
		DeleteObject(titleBarBrush);
		DeleteObject(focusedTitleBarBrush);
		DeleteObject(pen);
	}
	
	void paintWindow(WindowData *window, RECT r, HICON icon, POINT iconPos)
	{
		Rectangle(backBuffer, r.left, r.top, r.right, r.bottom);
		
		RECT rtitle;
		if(minimap->minimapTitleBarsThickness && !window->isPopup)
		{
			if(window->isFocused())
				SelectObject(backBuffer, focusedTitleBarBrush);
			else
				SelectObject(backBuffer, titleBarBrush);
			
			rtitle.left = r.left;
			rtitle.top = r.top;
			rtitle.right = r.right;
			rtitle.bottom = r.top + minimap->minimapTitleBarsThickness;
			// save the bottom of the titlebar as the top of the rest of the window
			r.top = rtitle.bottom;
			
			Rectangle(backBuffer,
				rtitle.left, rtitle.top, rtitle.right, rtitle.bottom);
			SelectObject(backBuffer, windowBrush);
		}
		
		int iconSize = minimap->minimapIconSize;
		if(icon && iconSize)
			DrawIconEx(backBuffer, iconPos.x, iconPos.y, icon, iconSize, iconSize, 0, NULL, DI_NORMAL);
	}
};

void MinimapElement::draw(HDC drawContext, LayoutCacheNode *layout)
{
	MinimapWindowPainter painter(settings, drawContext, this);
	RECT rect = layout->context.boundingRect;
	
	vector<WindowData*> windows = windowTracker->getWindows(layout->context.desk);
	
	// Iterate in bottom-to-top order (Painter's algorithm)
	for(vector<WindowData*>::reverse_iterator it=windows.rbegin(); it!=windows.rend(); it++)
	{
		WindowData *windowData = *it;
		
		if(windowData->isMinimized())
			continue;
		
		POINT iconPos;
		
		RECT r = screenToMinimapPos(&layout->context, windowData->lastScreenPos, &iconPos);
			r.left += rect.left;
			r.right += rect.left;
			r.top += rect.top;
			r.bottom += rect.top;
			iconPos.x += rect.left;
			iconPos.y += rect.top;
		
		if(!windowData->parent && !windowData->isPopup)
			painter.paintWindow(windowData, r, windowData->getIcon(minimapIconSize), iconPos);
		else
			painter.paintWindow(windowData, r, NULL, iconPos);
	}
}

RECT MinimapElement::screenToMinimapPos(ElementContext *context, Rect screenPos, POINT *iconPos)
{
	// Remove translation due to being on the second monitor, being offscreen,
	// etc.
	Rect maximizeArea;
	
	if(context->desk->monitor) {
		maximizeArea = context->desk->monitor->getMaximizeArea();
		context->desk->monitor->unstoreRect(maximizeArea);
	} else {
		maximizeArea = context->desk->lastMaximizeArea;
	}
	
	context->desk->currentSlot()->unstoreRect(screenPos);
	
	// Promote to float for intermediate calculations;
	float left, right, top, bottom;
	left   = (float)screenPos.left - maximizeArea.left;
	right  = (float)screenPos.getRight() - maximizeArea.left;
	top    = (float)screenPos.top - maximizeArea.top;
	bottom = (float)screenPos.getBottom() - maximizeArea.top;
	
	RECT minimapRect = context->boundingRect;
	int minimapWidth = minimapRect.right - minimapRect.left;
	int minimapHeight = minimapRect.bottom - minimapRect.top;
	
	// Scale it to minimap size
	//  +1 and -2 because the minimap's borders don't count
	left   *= (float)(minimapWidth-2)  / maximizeArea.width;
	right  *= (float)(minimapWidth-2)  / maximizeArea.width;
	top    *= (float)(minimapHeight-2) / maximizeArea.height;
	bottom *= (float)(minimapHeight-2) / maximizeArea.height;
		left++;
		right++;
		top++;
		bottom++;
	
	if(left < 0)
		left = 0;
	if(top < 0)
		top = 0;
	if(right > minimapWidth)
		right = minimapWidth;
	if(bottom > minimapHeight)
		bottom = minimapHeight;
	if(left > right)
		left = right;
	if(top > bottom)
		top = bottom;
	
	if(iconPos)
	{
		iconPos->x = (left+right)/2 - minimapIconSize/2;
		iconPos->y = (top+bottom)/2 - minimapIconSize/2;
		
		if(iconPos->x + minimapIconSize > minimapWidth)
			iconPos->x = minimapWidth - minimapIconSize;
		if(iconPos->y + minimapIconSize > minimapHeight)
			iconPos->y = minimapHeight - minimapIconSize;
		if(iconPos->x < 0)
			iconPos->x = 0;
		if(iconPos->y < 0)
			iconPos->y = 0;
	}
	
	RECT ret;
		ret.left   = (long)left;
		ret.right  = (long)right;
		ret.top    = (long)top;
		ret.bottom = (long)bottom;
	return ret;
}

POINT MinimapElement::minimapToScreenPos(ElementContext *context, int x, int y)
{
	POINT ret;
	RECT maximizeArea;
	
	if(context->desk->monitor)
		maximizeArea = context->desk->monitor->getMaximizeArea();
	else
		maximizeArea = context->desk->lastMaximizeArea;
	
	RECT minimapArea = context->boundingRect;
	
	ret.x = (x - minimapArea.left) * ((float)(maximizeArea.right-maximizeArea.left) / (minimapArea.right-minimapArea.left));
	ret.y = (y - minimapArea.top ) * ((float)(maximizeArea.bottom-maximizeArea.top) / (minimapArea.bottom-minimapArea.top));
	ret.x += maximizeArea.left;
	ret.y += maximizeArea.top;
	
	context->desk->currentSlot()->storePoint(ret);
	
	return ret;
}
