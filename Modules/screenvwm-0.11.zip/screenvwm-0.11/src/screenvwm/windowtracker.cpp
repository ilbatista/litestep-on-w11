/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

WindowTracker *windowTracker = NULL;

WindowTracker::WindowTracker()
{
	foreground = NULL;
	changed = true;
}

WindowTracker::~WindowTracker()
{
	for(set<TaskData*>::iterator ii=tasks.begin(); ii!=tasks.end(); ii++)
		delete *ii;
	for(map<HWND,WindowData*>::iterator ii=windows.begin(); ii!=windows.end(); ii++)
		delete ii->second;
}

void WindowTracker::windowCreated(HWND handle)
{
	// Verify that this window both really new and not something we're
	// deliberately ignoring.
	if(windows.find(handle) != windows.end())
		return;
	if(shouldIgnoreWindow(handle))
		return;
	// Create a struct to track this window
	changed = true;
	WindowData *window = new WindowData(handle);
	windows[handle] = window;
	unownedWindows.insert(window);
	
	// Assign this window a task and desk
	window->desk = vwm->deskFromLocation(window->lastScreenPos);
	if(!window->desk)
		window->desk = vwm->rescueOffscreenWindow(window, &window->lastScreenPos);
	
	updateWindowTask(window);
}

void WindowTracker::updateWindow(WindowData *window)
{
	// If this window has been hidden, become a Litestep window, been
	// reparented, etc., stop tracking it
	if(shouldIgnoreWindow(window->handle)) {
		windowDestroyed(window->handle);
		return;
	}
	
	if(window->updateCachedProperties())
		changed = true;
	
	if(!window->minimized)
	{
		VirtualDesktop *newDesk = vwm->deskFromLocation(window->lastScreenPos);
		if(!newDesk)
			newDesk = vwm->rescueOffscreenWindow(window, &window->lastScreenPos);
		updateAndFlag(newDesk, window->desk, changed);
	}
	
	updateWindowTask(window);
}

void WindowTracker::windowDestroyed(HWND handle)
{
	// Check that we were tracking this window
	if(windows.find(handle) == windows.end())
		return;
	changed = true;
	
	WindowData *window = windows[handle];
	
	if(window->task)
		removeWindowFromTask(window);
	
	if(window == foreground)
		foreground = NULL;
	unownedWindows.erase(window);
	delete window;
	windows.erase(handle);
}

void WindowTracker::windowActivated(HWND handle)
{
	// If we get an activation notice for a window we haven't seen before,
	// handle its creation.
	if(windows.find(handle) == windows.end())
		windowCreated(handle);
	
	// Update the focus
	updateFocus();
}

bool WindowTracker::shouldIgnoreWindow(HWND window)
{
	// Skip hidden windows
	if(!IsWindowVisible(window))
		return true;
	
	// Skip anything that has a parent but isn't a popup
	HWND parent = GetParent(window);
	int windowStyle = GetWindowLong(window, GWL_STYLE);
	if(parent && !(windowStyle & WS_POPUP))
		return true;
	
	// Skip windows which are components of the Litestep desktop (including the VWM itself)
	if(GetWindowLong(window, GWL_USERDATA) == magicDWord)
		return true;

	return false;
}

BOOL CALLBACK WindowTracker::windowChildListBuilder(HWND window, LPARAM param)
{
	vector<HWND> *vec = (vector<HWND>*)param;
	if(!windowTracker->shouldIgnoreWindow(window))
		vec->push_back(window);
	return TRUE;
}

BOOL CALLBACK WindowTracker::windowListBuilder(HWND window, LPARAM param)
{
	vector<HWND> *vec = (vector<HWND>*)param;
	if(!windowTracker->shouldIgnoreWindow(window))
		vec->push_back(window);
	
	// If this is a root window, iterate over its children
	HWND parent = GetParent(window);
	if(!parent)
		EnumChildWindows(window, &windowChildListBuilder, param);
	
	return TRUE;
}

bool WindowTracker::update()
{
	changed = false;
	
	// Enumerate windows
	zOrder.clear();
	EnumWindows(&windowListBuilder, (LPARAM)&zOrder);
	
	// Check for created and destroyed windows
	vector<HWND> newWindows;
	vector<HWND> deletedWindows;
	
	for(map<HWND,WindowData*>::iterator ii=windows.begin(); ii!=windows.end(); ii++)
		ii->second->visited = false;
	
	for(unsigned ii=0; ii<zOrder.size(); ii++) {
		HWND handle = zOrder[ii];
		if(windows.find(handle)==windows.end())
			newWindows.push_back(handle);
		else
			windows[handle]->visited = true;
	}
	
	for(map<HWND,WindowData*>::iterator ii=windows.begin(); ii!=windows.end(); ii++) {
		if(!ii->second->visited)
			deletedWindows.push_back(ii->second->handle);
	}
	
	// Handle deleted windows
	for(unsigned ii=0; ii<deletedWindows.size(); ii++)
		windowDestroyed(deletedWindows[ii]);
	
	// Check for changes to known windows
	// This may lead to windows being destroyed (if we notice that a window
	// being updated isn't around anymore), so iterate through a copy of the
	// list rather than the original.
	vector<WindowData*> windowsToUpdate(windows.size());
	int pos = 0;
	for(map<HWND,WindowData*>::iterator ii=windows.begin(); ii!=windows.end(); ii++)
		windowsToUpdate[pos++] = ii->second;
	for(unsigned ii=0; ii<windowsToUpdate.size(); ii++)
		updateWindow(windowsToUpdate[ii]);
	
	// Handle newly created windows
	for(unsigned ii=0; ii<newWindows.size(); ii++)
		windowCreated(newWindows[ii]);
	
	// Update focus
	updateFocus();
	
	return changed;
}

void WindowTracker::updateFocus()
{
	HWND pos = GetForegroundWindow();
	
	if(windows.find(pos) != windows.end()) {
		WindowData *window = windows[pos];
		if(foreground != window)
			changed = true;
		foreground = windows[pos];
	}
}

bool WindowTracker::checkForChange()
{
	if(changed) {
		changed = false;
		return true;
	} else {
		return false;
	}
}

WindowData *WindowTracker::getForegroundWindow()
{
	return foreground;
}

TaskData *WindowTracker::getForegroundTask()
{
	WindowData *foregroundWindow = getForegroundWindow();
	if(!foregroundWindow)
		return NULL;
	return foregroundWindow->task;
}

/// If the focused window is on another desktop or is the desktop itself, focus
/// on the topmost window of this desktop. If there is no such window, focus on
/// the desktop.
void WindowTracker::raiseLocalForeground()
{
	for(unsigned ii=0; ii<zOrder.size(); ii++)
	{
		HWND handle = zOrder[ii];
		if(windows.find(handle) == windows.end()) continue;
		WindowData *window = windows[handle];
		
		// Only focus something that's on a visible desk
		if(!window->desk->monitor)
			continue;
		// Don't focus minimized windows (that'd be silly)
		if(window->isMinimized())
			continue;
		
		vwm->raiseWindow(window);
		break;
	}
	
	// If we got throught he whole window list without finding something
	// suitable to focus, focus on the desktop.
	SetFocus(getDesktopWindow());
}

vector<TaskData*> WindowTracker::getTasks(VirtualDesktop *desk)
{
	vector<TaskData*> ret;
	
	for(set<TaskData*>::iterator ii=tasks.begin(); ii!=tasks.end(); ii++)
	{
		TaskData *task = *ii;
		
		if(desk)
		{
			vector<VirtualDesktop*> desks = task->getDesks();
			for(unsigned jj=0; jj<desks.size(); jj++) {
				if(desks[jj] == desk) {
					ret.push_back(*ii);
					break;
				}
			}
		}
		else
		{
			ret.push_back(task);
		}
	}
	
	return ret;
}

vector<WindowData*> WindowTracker::getWindows(VirtualDesktop *desk)
{
	vector<WindowData*> ret;
	
	for(unsigned ii=0; ii<zOrder.size(); ii++)
	{
		HWND handle = zOrder[ii];
		if(windows.find(handle) == windows.end())
			continue;
		WindowData *window = windows[handle];
		if(!desk || window->desk == desk)
			ret.push_back(window);
	}
	
	return ret;
}

WindowData *WindowTracker::getWindow(HWND window)
{
	map<HWND,WindowData*>::iterator it = windows.find(window);
	if(it == windows.end()) return NULL;
	else return it->second;
}

bool WindowTracker::deskIsEmpty(VirtualDesktop *desk)
{
	for(unsigned ii=0; ii<zOrder.size(); ii++)
	{
		HWND handle = zOrder[ii];
		if(windows.find(handle) == windows.end())
			continue;
		WindowData *window = windows[handle];
		if(window->desk == desk)
			return false;
	}
	
	return true;
}

void WindowTracker::updateWindowTask(WindowData *window)
{
	if(window->task)
	{
		TaskData *task = window->task;
		WindowData *representative = task->getRepresentativeWindow();
		
		// If this window is the representative of a task, verify that it is
		// still eligible for that role
		if(window == representative)
		{
			if(!window->isTask)
				removeTask(task);
		}
		// If this window is the child of a task, check that this is still
		// correct.
		else if(window->isTask || findParentTaskWindow(window) != representative)
		{
			removeWindowFromTask(window);
			updateWindowTask(window);
		}
	}
	else
	{
		// This window isn't currently considered part of any task, and is
		// eligible to be a task by itself, so make it one.
		if(window->isTask)
		{
			TaskData *task = new TaskData(window);
			window->task = task;
			tasks.insert(task);
			tasksByPid.insert(pair<DWORD,TaskData*>(window->pid, task));
			unownedWindows.erase(window);
			
			// Look through windows that aren't currently owned by a task, and
			// claim any that belong to this window.
			for(set<WindowData*>::iterator ii=unownedWindows.begin(); ii!=unownedWindows.end(); ii++)
			{
				WindowData *child = *ii;
				if(findParentTaskWindow(child) == window) {
					child->task = task;
					task->addWindow(child);
					unownedWindows.erase(child);
					break;
				}
			}
		}
		// This window isn't currently part of any task and isn't eligible to
		// be a task by itself, so look for tasks it could be considered part
		// of.
		else
		{
			WindowData *parentTaskWindow = findParentTaskWindow(window);
			if(parentTaskWindow && parentTaskWindow->task)
			{
				TaskData *task = parentTaskWindow->task;
				
				window->task = task;
				task->addWindow(window);
				unownedWindows.erase(window);
			}
		}
	}
}

void WindowTracker::removeTask(TaskData *task)
{
	vector<WindowData*> windows = task->getWindows();
	WindowData *representative = task->representative;
	
	for(unsigned ii=0; ii<windows.size(); ii++)
		windows[ii]->task = NULL;
	
	tasks.erase(task);
	
	DWORD pid = task->representative->pid;
	for(multimap<DWORD,TaskData*>::iterator ii = tasksByPid.find(pid); ii!=tasksByPid.end(); ii++)
	{
		if(ii->second == task) {
			tasksByPid.erase(ii);
			break;
		}
		if(ii->first != pid)
			break;
	}
	
	delete task;
	
	for(unsigned ii=0; ii<windows.size(); ii++) {
		if(windows[ii] != representative)
			updateWindowTask(windows[ii]);
	}
}

void WindowTracker::removeWindowFromTask(WindowData *window)
{
	TaskData *task = window->task;
	if(!task) return;
	
	window->task = NULL;
	
	if(window == task->representative)
		removeTask(task);
	else
		task->removeWindow(window);
}

WindowData *WindowTracker::findParentTaskWindow(WindowData *window)
{
	// Non-task windows are assigned to the most-closely-related task found.
	// The main effect of this is that these windows move between desks with
	// the window they're assigned to. The preference order is:
	//   - The window's parent
	//   - The window's owner
	//   - Any task window owned by the same PID
	HWND parentHandle = GetParent(window->handle);
	HWND ownerHandle = GetWindow(window->handle, GW_OWNER);
	if(windows.find(parentHandle) != windows.end()) {
		WindowData *parent = windows[parentHandle];
		if(parent->isTask) return parent;
	}
	if(windows.find(ownerHandle) != windows.end()) {
		WindowData *owner = windows[ownerHandle];
		if(owner->isTask) return owner;
	}
	
	multimap<DWORD,TaskData*>::iterator iter = tasksByPid.find(window->pid);
	if(iter != tasksByPid.end())
		return iter->second->representative;
	
	return NULL;
}

/////////////////////////////////////////////////////////////////////////////

TaskData::TaskData(WindowData *representative)
{
	this->representative = representative;
}

vector<WindowData*> TaskData::getWindows()
{
	vector<WindowData*> ret;
	ret.push_back(representative);
	ret.insert(ret.end(), children.begin(), children.end());
	return ret;
}

vector<WindowData*> TaskData::getWindows(VirtualDesktop *desk)
{
	vector<WindowData*> ret;
	if(representative->desk == desk)
		ret.push_back(representative);
	for(unsigned ii=0; ii<children.size(); ii++) {
		if(children[ii]->desk == desk)
			ret.push_back(children[ii]);
	}
	return ret;
}

vector<VirtualDesktop*> TaskData::getDesks()
{
	set<VirtualDesktop*> desks;
	desks.insert(representative->desk);
	for(unsigned ii=0; ii<children.size(); ii++)
		desks.insert(children[ii]->desk);
	
	vector<VirtualDesktop*> ret;
	for(set<VirtualDesktop*>::iterator ii=desks.begin(); ii!=desks.end(); ii++)
		ret.push_back(*ii);
	
	return ret;
}

WindowData *TaskData::getRepresentativeWindow()
{
	return representative;
}

HICON TaskData::getIcon(VirtualDesktop *desk, int size)
{
	return representative->getIcon(size);
}

bool TaskData::containsWindow(WindowData *window)
{
	if(window==representative)
		return true;
	
	for(unsigned ii=0; ii<children.size(); ii++) {
		if(children[ii] == window)
			return true;
	}
	return false;
}

void TaskData::addWindow(WindowData *window)
{
	if(!containsWindow(window))
		children.push_back(window);
}

void TaskData::removeWindow(WindowData *window)
{
	for(vector<WindowData*>::iterator ii=children.begin(); ii!=children.end(); ii++)
	{
		if(*ii == window) {
			children.erase(ii);
			break;
		}
	}
}

