/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

struct TaskListFlowChild
	:public FlowElement::FlowChild
{
	TaskListFlowChild(LayoutElement *element) :FlowChild(element) {}
	void append(vector<FlowElement::FlowCache> &children, ElementContext *context)
	{
		VirtualDesktop *desk = context->desk;
		if(!desk) return;
		
		vector<TaskData*> tasks = windowTracker->getTasks(desk);
		
		vector<WindowData*> windows;
		for(unsigned ii=0; ii<tasks.size(); ii++)
			windows.push_back(tasks[ii]->getRepresentativeWindow());
		
		for(unsigned ii=0; ii<tasks.size(); ii++)
		{
			FlowElement::FlowCache ret;
			ret.element = childType;
			ret.node = NULL;
			ret.context = *context;
			ret.context.task = windows[ii];
			ret.expanding = false;
			children.push_back(ret);
		}
	}
};
struct DeskListFlowChild
	:public FlowElement::FlowChild
{
	DeskListFlowChild(LayoutElement *element) :FlowChild(element) {}
	void append(vector<FlowElement::FlowCache> &children, ElementContext *context)
	{
		for(unsigned ii=0; ii<vwm->desktops.size(); ii++)
		{
			FlowElement::FlowCache ret;
			ret.element = childType;
			ret.node = NULL;
			ret.context = *context;
			ret.context.desk = vwm->desktops[ii];
			ret.expanding = false;
			children.push_back(ret);
		}
	}
};
struct SingletonFlowChild
	:public FlowElement::FlowChild
{
	SingletonFlowChild(LayoutElement *element) :FlowChild(element) {}
	void append(vector<FlowElement::FlowCache> &children, ElementContext *context)
	{
		FlowElement::FlowCache ret;
		ret.element = childType;
		ret.node = NULL;
		ret.context = *context;
		ret.expanding = false;
		children.push_back(ret);
	}
};
struct SpacerFlowChild
	:public SingletonFlowChild
{
	SpacerFlowChild()
		:SingletonFlowChild(NULL), size(-1), expanding(true), optional(true)
		{}
	SpacerFlowChild(int size, bool optional)
		:SingletonFlowChild(NULL), size(size), expanding(false), optional(optional)
		{}
	void append(vector<FlowElement::FlowCache> &children, ElementContext *context)
	{
		FlowElement::FlowCache ret;
		ret.element = NULL;
		ret.node = NULL;
		ret.context = *context;
		ret.expanding = expanding;
		
		if(expanding) {
			ret.preferredLength = ret.minLength = 0;
		} else {
			ret.preferredLength = size;
			if(optional) ret.minLength = 0;
			else ret.minLength = size;
		}
		
		children.push_back(ret);
	}
	
	bool expanding;
	bool optional;
	int size;
};

FlowElement::FlowChild::FlowChild(LayoutElement *childType)
	:childType(childType) { }

FlowElement::FlowElement(string prefix)
	:RectLayoutElement(prefix)
{
	parseChildTypes();
}

FlowElement::~FlowElement()
{
	for(unsigned ii=0; ii<childTypes.size(); ii++)
		delete childTypes[ii];
}

LayoutCacheNode *FlowElement::buildLayout(ElementContext *context, LayoutCacheNode *prev, SizeFallback *sizeFallback)
{
	LayoutCacheNode *ret = RectLayoutElement::buildLayout(context, prev, sizeFallback);
	ret->element = this;
	
	vector<FlowCache> children;
	ElementContext childContext = getChildContext(context);
	getChildren(children, &childContext, true, sizeFallback);
	
	// Arrange child elements, in accordance with the specific type of flow
	// this is (linear flow, grid flow, etc)
	arrangeElements(context, children);
	
	// If there was a previous layout, match up elements in this layout with
	// elements from that one, and reuse any nodes with matching contexts.
	// (This is done mainly so that you can pull out a node when doing drag/
	// drop and replace it temporarily.)
	if(prev)
	{
		for(unsigned ii=0; ii<children.size(); ii++)
		{
			// Skip spacer elements
			if(!children[ii].element)
				continue;
			
			for(unsigned jj=0; jj<prev->children.size(); jj++)
			{
				if(!prev->children[jj]->context.match(children[ii].context))
					continue;
				if(prev->children[jj]->element != children[ii].element)
					continue;
				
				LayoutCacheNode *prevNode = prev->children[jj];
				children[ii].node = prevNode->element->buildLayout(&children[ii].context, prevNode, sizeFallback);
				break;
			}
		}
	}
	
	// Create new nodes for any children which didn't have a match in the
	// previous layout
	for(unsigned ii=0; ii<children.size(); ii++)
	{
		// Skip spacer elements
		if(!children[ii].element)
			continue;
		
		if(!children[ii].node) {
			children[ii].node = children[ii].element->buildLayout(&children[ii].context, NULL, sizeFallback);
		}
	}
	
	ret->children.clear();
	for(unsigned ii=0; ii<children.size(); ii++)
	{
		if(!children[ii].element)
			continue;
		LayoutCacheNode *child = children[ii].node;
		child->parent = ret;
		ret->children.push_back(child);
	}
	
	return ret;
}

void FlowElement::draw(HDC drawContext, LayoutCacheNode *layout)
{
	for(unsigned ii=0; ii<layout->children.size(); ii++)
	{
		LayoutCacheNode *child = layout->children[ii];
		child->element->draw(drawContext, child);
	}
}

void FlowElement::parseChildTypes()
{
	string childList = getConfigLine("Elements", "", prefix.c_str());
	vector<string> tokens;
	tokenizeString(childList, tokens, " \t()");
	
	for(unsigned ii=0; ii<tokens.size(); ii++)
	{
		if(tokens[ii]== ".tasks")
		{
			if(++ii >= tokens.size()) {
				string warning = string(".tasks child in ")+prefix+" requires an argument.\n";
				warn(warning.c_str());
				return;
			}
			
			LayoutElement *element = layoutPool->getElement(tokens[ii]);
			if(element)
				childTypes.push_back(new TaskListFlowChild(element));
		}
		else if(tokens[ii]==".desks")
		{
			if(++ii >= tokens.size()) {
				string warning = string(".desks child in ")+prefix+" requires an argument.\n";
				warn(warning.c_str());
				return;
			}
			
			LayoutElement *element = layoutPool->getElement(tokens[ii]);
			if(element)
				childTypes.push_back(new DeskListFlowChild(element));
		}
		else if(tokens[ii]==".freeSpace")
		{
			childTypes.push_back(new SpacerFlowChild());
		}
		else if(isdigit(tokens[ii][0]))
		{
			int thickness = atoi(tokens[ii].c_str());
			childTypes.push_back(new SpacerFlowChild(thickness, false));
		}
		else if(tokens[ii].length()>1 && tokens[ii][0]=='.' && isdigit(tokens[ii][1]))
		{
			int thickness = atoi(tokens[ii].c_str()+1);
			childTypes.push_back(new SpacerFlowChild(thickness, true));
		}
		else
		{
			LayoutElement *element = layoutPool->getElement(tokens[ii]);
			if(element)
				childTypes.push_back(new SingletonFlowChild(element));
		}
	}
}

/// Get a list of all the elements that will be the children of this flow, and
/// their semantics (context). Results are appended to 'children', which is not
/// cleared first.
/// If 'computeSizes' is set, fill in the minimum and preferred length of each
/// child, and include spacer elements. Otherwise, omit spacers. This size is
/// computed using the bounding rect given in 'childContext', which also
/// provides defaults for all fields which are not part of the definition of the
/// flow.
void FlowElement::getChildren(vector<FlowCache> &children, ElementContext *childContext, bool computeSizes, SizeFallback *sizeFallback)
{
	for(unsigned ii=0; ii<childTypes.size(); ii++)
	{
		if(computeSizes || childTypes[ii]->childType)
			childTypes[ii]->append(children, childContext);
	}
	
	for(unsigned ii=0; ii<children.size(); ii++)
		children[ii].element = sizeFallback->mapElement(children[ii].element);
	
	if(computeSizes)
	{
		for(unsigned ii=0; ii<children.size(); ii++)
		{
			if(children[ii].element)
			{
				// Fill in min and preferred lengths
				pair<int,int> length = children[ii].element->getLength(&children[ii].context, verticalChildren(), sizeFallback);
				children[ii].minLength = length.first;
				children[ii].preferredLength = length.second;
			}
		}
	}
}

bool FlowElement::changed(LayoutCacheNode *node)
{
	ElementContext childContext = getChildContext(&node->context);
	vector<FlowCache> children;
	getChildren(children, &childContext, false, node->sizeFallback);
	
	if(children.size() != node->children.size())
		return true;
	
	for(unsigned ii=0; ii<children.size(); ii++)
	{
		if(childChanged(node, ii, children[ii].element))
			return true;
		if(!children[ii].context.match(node->children[ii]->context))
			return true;
	}
	
	return LayoutElement::changed(node);
}

