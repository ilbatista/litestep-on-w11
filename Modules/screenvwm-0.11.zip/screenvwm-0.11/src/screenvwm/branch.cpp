#include "screenvwm.hpp"

BranchElement::BranchElement(string prefix)
	:LayoutElement(prefix)
{
	char *branchNames = _strdup(getConfigLine("Branches", "", prefix.c_str()).c_str());
	vector<string> tokenizedBranchNames;
	const char *separators = " \t\n";
	char *pos = strtok(branchNames, separators);
	while(pos) {
		tokenizedBranchNames.push_back(pos);
		pos = strtok(NULL, separators);
	}
	free(branchNames);
	
	for(unsigned ii=0; ii<tokenizedBranchNames.size(); ii++) {
		branches.push_back(parseBranch(tokenizedBranchNames[ii]));
	}
}

BranchElement::Branch BranchElement::parseBranch(const string &prefix)
{
	Branch ret;
	ret.element = layoutPool->getElement(prefix);
	string conditionVar = prefix+"Condition";
	string conditionStr = getConfigString(conditionVar.c_str(), "true", "");
	const char *conditionCstr = conditionStr.c_str();
	ret.condition = parseExpression(conditionCstr);
	return ret;
}

BranchElement::~BranchElement()
{
	for(unsigned ii=0; ii<branches.size(); ii++)
		delete branches[ii].condition;
}

LayoutCacheNode *BranchElement::buildLayout(ElementContext *context, LayoutCacheNode *prev, SizeFallback *sizeFallback)
{
	LayoutElement *branch = sizeFallback->mapElement(getBranch(context));
	
	LayoutCacheNode *ret = LayoutElement::buildLayout(context, prev, sizeFallback);
	ret->element = this;
	
	if(branch)
	{
		LayoutCacheNode *child = NULL;
		
		if(prev && prev->children.size() && prev->children[0]->element==branch)
			child = prev->children[0];
		
		child = branch->buildLayout(context, child, sizeFallback);
		ret->children.clear();
		ret->children.push_back(child);
		child->parent = ret;
	}
	else
	{
		ret->children.clear();
	}
	
	return ret;
}

pair<int,int> BranchElement::getLength(ElementContext *context, bool vertical, SizeFallback *sizeFallback)
{
	LayoutElement *branch = sizeFallback->mapElement(getBranch(context));
	if(branch)
		return branch->getLength(context, vertical, sizeFallback);
	else
		return pair<int,int>(0,0);
}

bool BranchElement::changed(LayoutCacheNode *node)
{
	LayoutElement *branch = getBranch(&node->context);
	
	if(branch && !node->children.size())
		return true;
	if(!branch && node->children.size())
		return true;
	if(branch && childChanged(node, 0, branch))
		return true;
	
	return LayoutElement::changed(node);
}

LayoutElement *BranchElement::getBranch(ElementContext *context)
{
	for(unsigned ii=0; ii<branches.size(); ii++)
	{
		if(!branches[ii].condition)
			return branches[ii].element;
		if(branches[ii].condition->evaluate(context))
			return branches[ii].element;
	}
	return NULL;
}

