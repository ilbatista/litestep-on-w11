/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

/////////////////////////////////////////////////////////////////////////////

Layout::Layout(LayoutElement *rootElement, ElementContext rootContext, string sizeFallbacks)
{
	this->rootElement = rootElement;
	this->cachedRoot = NULL;
	this->rootContext = rootContext;
	this->fallbackUsed = 0;
	this->sizeFallbacks = new SizeFallbackChain(sizeFallbacks);
}

Layout::~Layout()
{
	vector<LayoutCacheNode*> cacheNodes;
	
	if(cachedRoot)
	{
		cachedRoot->traverse(cacheNodes);
		
		for(unsigned ii=0; ii<cacheNodes.size(); ii++)
			delete cacheNodes[ii];
	}
}

bool Layout::changed()
{
	if(!cachedRoot)
		return true;
	
	if(cachedRoot->element->changed(cachedRoot))
	{
		if(settings->debugUpdates)
		{
			LayoutCacheNode *changeLocation = findChange(cachedRoot);
			if(changeLocation)
				trace << "Update triggered by change in " << changeLocation->element->prefix << "\n";
			else
				trace << "Update triggered with unidentified cause\n";
		}
		return true;
	}
	else
	{
		if(fallbackUsed > 0 && fallbackFits(fallbackUsed-1))
			return true;
		
		return false;
	}
}

//
// Given a cache node which has changed, find the origin of the change (that
// is, any node which changed for a reason other than because its child did.)
// If there is more than one change, returns the first one.
//
LayoutCacheNode *Layout::findChange(LayoutCacheNode *tree)
{
	for(unsigned ii=0; ii<tree->children.size(); ii++)
	{
		LayoutCacheNode *child = tree->children[ii];
		if(child->element->changed(child))
			return findChange(child);
	}
	
	return tree;
}

void Layout::update()
{
	// FIXME: Vertical layouts are broken here
	// Decide which layout fallback to use
	bool reduced = false;
	while(fallbackUsed > 0 && fallbackFits(fallbackUsed-1))
	{
		fallbackUsed--;
		reduced = true;
	}
	if(!reduced)
	{
		while(fallbackUsed < sizeFallbacks->numFallbacks() && !fallbackFits(fallbackUsed))
			fallbackUsed++;
	}
	
	SizeFallback *fallback = sizeFallbacks->getFallback(fallbackUsed);
	
	// Update
	vector<LayoutCacheNode*> oldNodes;
	if(cachedRoot) cachedRoot->traverse(oldNodes);
	
	cachedRoot = rootElement->buildLayout(&rootContext, cachedRoot, fallback);
	
	vector<LayoutCacheNode*> newNodes;
	cachedRoot->traverse(newNodes);
	
	for(unsigned ii=0; ii<oldNodes.size(); ii++)
		oldNodes[ii]->visited = false;
	for(unsigned ii=0; ii<newNodes.size(); ii++)
		newNodes[ii]->visited = true;
	for(unsigned ii=0; ii<oldNodes.size(); ii++) {
		LayoutCacheNode *node = oldNodes[ii];
		if(!node->visited) {
			if(drag && drag->node == node) {
				// TODO: Handle outside references more elegantly than this (boost::weak_ptr?)
				drag->node = NULL;
			}
			delete oldNodes[ii];
		}
	}
}

bool Layout::fallbackFits(int index)
{
	SizeFallback *fallback = sizeFallbacks->getFallback(index);
	pair<int,int> length = rootElement->getLength(&rootContext, false, fallback);
	int minLength = length.first;
	
	return minLength <= rootContext.boundingRect.width;
}

void Layout::draw(HDC drawContext)
{
	if(!cachedRoot)
		return;
	rootElement->draw(drawContext, cachedRoot);
}

LayoutCacheNode *Layout::elementAtPoint(int x, int y)
{
	if(!cachedRoot)
		return NULL;
	return cachedRoot->elementAtPoint(x, y);
}

void Layout::traverse(vector<LayoutCacheNode*> &visited)
{
	if(!cachedRoot)
		return;
	cachedRoot->traverse(visited);
}

/////////////////////////////////////////////////////////////////////////////

ElementContext::ElementContext()
{ }
ElementContext::ElementContext(VWMPanel *panel, Monitor *monitor, VWM *vwm,
	VirtualDesktop *desk, WindowData *task, const Rect &rect, bool hovered)
	:panel(panel), monitor(monitor), vwm(vwm), desk(desk), task(task), boundingRect(rect), hovered(hovered)
{ }

bool ElementContext::match(const ElementContext &rhs) const
{
	return panel==rhs.panel
	    && vwm==rhs.vwm
	    && desk==rhs.desk
	    && task==rhs.task;
}

/////////////////////////////////////////////////////////////////////////////

LayoutElement::LayoutElement(string prefix)
	:prefix(prefix)
{
	onPress[mouseLeft]   = getConfigLine("OnLeftPress", "", prefix.c_str());
	onPress[mouseRight]  = getConfigLine("OnRightPress", "", prefix.c_str());
	onPress[mouseMiddle] = getConfigLine("OnMiddlePress", "", prefix.c_str());
	onRelease[mouseLeft]  = getConfigLine("OnLeftRelease", "", prefix.c_str());
	onRelease[mouseRight]  = getConfigLine("OnRightRelease", "", prefix.c_str());
	onRelease[mouseMiddle] = getConfigLine("OnMiddleRelease", "", prefix.c_str());
	onClick[mouseLeft]   = getConfigLine("OnLeftClick",  "", prefix.c_str());
	onClick[mouseRight]  = getConfigLine("OnRightClick", "", prefix.c_str());
	onClick[mouseMiddle] = getConfigLine("OnMiddleClick", "", prefix.c_str());
	
	hoverGroup = getConfigBool("HoverGroup", false, prefix.c_str());
	draggable = getConfigBool("Draggable", false, prefix.c_str());
	isMinimizeTarget = getConfigBool("IsMinimizeTarget", false, prefix.c_str());
	
	string dragElementName = getConfigLine("DragElement", "", prefix.c_str());
	string placeholderName = getConfigLine("DragPlaceholder", "", prefix.c_str());
	dragElement = layoutPool->getElement(dragElementName);
	dragPlaceholder = layoutPool->getElement(placeholderName);
}

LayoutElement::~LayoutElement()
	{ }

string LayoutElement::toString() const
{
	return prefix;
}

bool LayoutElement::isModule()
	{ return false; }

void LayoutElement::draw(HDC drawContext, LayoutCacheNode *layout)
{
	for(unsigned ii=0; ii<layout->children.size(); ii++)
	{
		LayoutCacheNode *child = layout->children[ii];
		child->element->draw(drawContext, child);
	}
}

bool LayoutElement::changed(LayoutCacheNode *node)
{
	if(hoverGroup)
	{
		if(isHovered(&node->context) != node->context.hovered)
			return true;
	}
	
	for(unsigned ii=0; ii<node->children.size(); ii++)
	{
		LayoutCacheNode *child = node->children[ii];
		if(child->element->changed(child))
			return true;
	}
	return false;
}

LayoutCacheNode *LayoutElement::buildLayout(ElementContext *context, LayoutCacheNode *prevLayout, SizeFallback *sizeFallback)
{
	if(hoverGroup && isHovered(context))
		context->hovered = true;
	
	if(prevLayout && prevLayout->element == this) {
		prevLayout->context = *context;
		prevLayout->sizeFallback = sizeFallback;
		return prevLayout;
	} else {
		return new LayoutCacheNode(this, context, sizeFallback);
	}
}

bool LayoutElement::isHovered(ElementContext *context)
{
	VWMPanel *panel = context->panel;
	if(panel) {
		Point mousePos = getCursorPos();
		
		// Convert mouse pos to window coordinates
		mousePos -= panel->getTopLeft();
		
		if(context->boundingRect.containsPoint(mousePos.x, mousePos.y))
			return true;
	}
	return false;
}

bool LayoutElement::childChanged(LayoutCacheNode *node, int index, LayoutElement *expectedChild)
{
	if((int)node->children.size() <= index)
	{
		return true;
	}
	else if(node->children[index]->element != expectedChild
	   && node->children[index]->origElement != expectedChild)
	{
		return true;
	}
	else
		return false;
}
