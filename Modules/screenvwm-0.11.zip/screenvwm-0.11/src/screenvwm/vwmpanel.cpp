/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

static const char *vwmWindowClassname = "screenvwm_VWMWindow";
static const char *vwmWindowName = "ScreenVWM";

#define GWL_CLASSPOINTER 0
#define APPBAR_MESSAGE_ID WM_USER

struct PanelEventArg
{
	SHORT size;
	VWMPanel *panel;
};

VWMPanel::VWMPanel(string prefix, Monitor *monitor, HWND parentWindow)
{
	this->prefix = prefix;
	this->monitor = monitor;
	layout = NULL;
	window = NULL;
	
	visible = getConfigBool("Visible", true, prefix.c_str());
	alwaysOnTop = getConfigBool("AlwaysOnTop", false, prefix.c_str());
	
	Rect monitorArea = monitor->getRect();
	
	isAppbar = getConfigBool("Appbar", false, prefix.c_str());
	if(isAppbar)
	{
		string screenEdgeStr = getConfigString("Edge", "bottom", prefix.c_str());
		if(!_stricmp(screenEdgeStr.c_str(), "top"))
			screenEdge = ABE_TOP;
		else if(!_stricmp(screenEdgeStr.c_str(), "left"))
			screenEdge = ABE_LEFT;
		else if(!_stricmp(screenEdgeStr.c_str(), "right"))
			screenEdge = ABE_RIGHT;
		else if(!_stricmp(screenEdgeStr.c_str(), "bottom"))
			screenEdge = ABE_BOTTOM;
		else {
			string message = retprintf("Invalid screen edge '%s' for panel '%s'.", screenEdgeStr.c_str(), prefix.c_str());
			warn(message.c_str());
			screenEdge = ABE_BOTTOM;
		}
		
		thickness = getConfigInt("Thickness", prefix.c_str());
		autoHide = getConfigBool("AutoHide", false, prefix.c_str());
		
		Rect pos = getAppbarPos(NULL);
		x = pos.left;
		y = pos.top;
		width = pos.width;
		height = pos.height;
	}
	else
	{
		x = monitorArea.left + getConfigCoord("X", monitorArea.width, prefix.c_str());
		y = monitorArea.top + getConfigCoord("Y", monitorArea.height, prefix.c_str()),
		width  = getConfigCoord("Width", monitorArea.width, prefix.c_str());
		height = getConfigCoord("Height", monitorArea.height, prefix.c_str());
		
		thickness = -1;
		autoHide = false;
	}
	
	transparent = getConfigBool("Transparent", false, prefix.c_str());
	if(transparent)
		fillColor = RGB(255,0,255);
	else
		fillColor = getConfigColor("BackgroundColor", 0,0,0, prefix.c_str());
	
	string rootElementName = getConfigString("RootElement", NULL, prefix.c_str());
	LayoutElement *rootElement = layoutPool->getElement(rootElementName);
	string sizeFallbacks = getConfigLine("SizeFallbacks", "", prefix.c_str());
	
	layout = new Layout(
		rootElement,
		ElementContext(this, monitor, vwm, NULL, NULL, Rect(0,0,width,height), false),
		sizeFallbacks);
	
	// This is a crappy hack fix to prevent outright crashing on invalid configurations
	// A better fix would be to move all of this code into a init/finalize() routine
	// that can return a failure.
	if(!rootElement)
		return;
	
	PanelEventArg arg = {sizeof(PanelEventArg), this};
	int flags = WS_EX_TOOLWINDOW;
	if(transparent)
		flags |= WS_EX_LAYERED;
	if(isAppbar)
		flags |= WS_EX_TOPMOST;
	
	window = CreateWindowEx(
		flags,
		vwmWindowClassname,
		vwmWindowName,
		WS_POPUP|WS_CLIPCHILDREN,
		x, y, width, height,
		parentWindow,
		NULL, dllInstance, &arg);
	if (!window) {
		fatal("Unable to create VWM window.");
		return;
	}
	
	// Mark this window as 'belonging to Litestep' so that we don't try to operate on ourself
	SetWindowLong(window, GWL_USERDATA, magicDWord);
	
	if(transparent)
		SetLayeredWindowAttributes(window, RGB(255,0,255), 0, LWA_COLORKEY);
	
	DragAcceptFiles(window, TRUE);
	
	initDrawContext();
	
	if(isAppbar)
	{		
		appbarData.cbSize = sizeof(appbarData);
		appbarData.hWnd = window;
		appbarData.uEdge = screenEdge;
		appbarData.rc = getAppbarPos(NULL);
		appbarData.uCallbackMessage = APPBAR_MESSAGE_ID;
		appbarData.lParam = NULL;
		SHAppBarMessage(ABM_NEW, &appbarData);
		
		appbarData.lParam = 0;
		if(alwaysOnTop)
			appbarData.lParam |= ABS_ALWAYSONTOP;
		if(autoHide)
			appbarData.lParam |= ABS_AUTOHIDE;
		SHAppBarMessage(ABM_SETSTATE, &appbarData);
		
		ShowWindow(window, SW_SHOWNORMAL);
		updateAppbarPos();
	}
	else
	{
		if (alwaysOnTop)
			SetWindowPos(window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ShowWindow(window, visible?SW_SHOWNORMAL:SW_HIDE);
	}
}

VWMPanel::~VWMPanel()
{
	if(isAppbar)
		SHAppBarMessage(ABM_REMOVE, &appbarData);
	
	ShowWindow(window, SW_HIDE);
	
	delete layout;
	destroyDrawContext();
	
	DestroyWindow(window);
	window = NULL;
}

Rect VWMPanel::getAppbarPos(const RECT *prevPos)
{
	RECT ret;
	
	if(prevPos) {
		// If there was another appbar on the same edge, Windows may have
		// adjusted this appbar's position, changing its thickness. Produce a
		// new rectangle, with the correct thickness.
		ret = *prevPos;
		return ret;
	} else {
		ret = monitor->getRect();
	}

	switch(screenEdge) {
		case ABE_TOP:    ret.bottom = ret.top    + thickness; break;
		case ABE_LEFT:   ret.right  = ret.left   + thickness; break;
		case ABE_RIGHT:  ret.left   = ret.right  - thickness; break;
		case ABE_BOTTOM: ret.top    = ret.bottom - thickness; break;
	}
	return ret;
}

void VWMPanel::updateAppbarPos()
{
	appbarData.rc = getAppbarPos(NULL);
	SHAppBarMessage(ABM_QUERYPOS, &appbarData);
	Rect finalPos = getAppbarPos(&appbarData.rc);
		x = finalPos.left;
		y = finalPos.top;
		width = finalPos.width;
		height = finalPos.height;
	appbarData.rc = finalPos;
	SHAppBarMessage(ABM_SETPOS, &appbarData);
	
	SetWindowPos(window, HWND_TOPMOST, x, y, width, height, SWP_NOZORDER);
}

VWMFirstPanel::VWMFirstPanel(string prefix, Monitor *monitor, HWND parentWindow)
	:VWMPanel(prefix, monitor, parentWindow)
{
	// Set a timer to update the VWM display (would like to replace this with a hook...)
	if(settings->pollInterval)
		SetTimer(window, TIMER_POLL, settings->pollInterval, NULL);
	if(settings->hoverTrackingInterval)
		SetTimer(window, TIMER_HOVERTRACK, settings->hoverTrackingInterval, NULL);
	
	registerEventHandlers();
}

VWMFirstPanel::~VWMFirstPanel()
{
	unregisterEventHandlers();
}

void VWM::initPanels(HWND parentWindow)
{
	VWMPanel::registerWindowClass();
	
	// Parse swmPanels, creating panelPrefixes, a list of prefixes each
	// of which corresponds to a VWMPanel and has suffixes for window position
	// and settings.
	vector<string> panelPrefixes;
	tokenizeString(settings->panels, panelPrefixes, " \t,;");
	
	bool first = true;
	
	for(unsigned ii=0; ii<panelPrefixes.size(); ii++)
	{
		string prefix = panelPrefixes[ii];
		string monitorSpecifier = getConfigLine("Monitors", "all", prefix.c_str());
		set<Monitor*> monitors = findMonitors(monitorSpecifier);
		
		for(set<Monitor*>::iterator jj=monitors.begin(); jj!=monitors.end(); jj++)
		{
			Monitor *monitor = *jj;
			
			VWMPanel *newPanel;
			if(first) {
				first = false;
				newPanel = new VWMFirstPanel(prefix, monitor, parentWindow);
			} else {
				newPanel = new VWMPanel(prefix, monitor, parentWindow);
			}
			panels.push_back(newPanel);
		}
	}
}

VWMPanel *VWM::findPanel(int x, int y)
{
	for(unsigned ii=0; ii<panels.size(); ii++)
	{
		VWMPanel *panel = panels[ii];
		if(panel->getRect().containsPoint(x, y))
			return panel;
	}
	return NULL;
}

VWMPanel *VWM::getFirstPanel()
{
	return panels[0];
}

void VWM::getPanels(vector<VWMPanel*> *outPanels)
{
	for(unsigned ii=0; ii<panels.size(); ii++)
		outPanels->push_back(panels[ii]);
}

void VWM::destroyPanels()
{
	for(unsigned ii=0; ii<panels.size(); ii++)
		delete panels[ii];
	panels.clear();
	VWMPanel::unregisterWindowClass();
}

void VWM::refreshPanels()
{
	destroyPanels();
	initPanels(parentWindow);
}

static WNDCLASSEX panelWindowClass;

void VWMPanel::registerWindowClass()
{
	memset(&panelWindowClass, 0, sizeof(WNDCLASSEX));
	panelWindowClass.cbSize = sizeof(WNDCLASSEX);
	panelWindowClass.cbWndExtra = sizeof(VWM*);
	panelWindowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	panelWindowClass.lpfnWndProc = VWMPanel::eventHandler;
	panelWindowClass.hInstance = dllInstance;
	panelWindowClass.lpszClassName = vwmWindowClassname;
	panelWindowClass.style = CS_HREDRAW|CS_VREDRAW;

	if (!RegisterClassEx(&panelWindowClass)) {
		// Class could not be registered, try to re-register
		UnregisterClass(vwmWindowClassname, dllInstance);

		if (!RegisterClassEx(&panelWindowClass)) {
			// Still no luck, error out
			fatal("Unable to register window class.");
		}
	}
}

void VWMPanel::unregisterWindowClass()
{
	UnregisterClass(vwmWindowClassname, dllInstance);
}

void VWMPanel::checkForUpdates()
{
	if(!layout)
		return;
	if(layout->changed()) {
		layout->update();
		forcePanelRedraw();
	}
}

LRESULT CALLBACK VWMPanel::eventHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(uMsg == WM_NCCREATE)
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	
	if (uMsg == WM_CREATE) {
		LPVOID &createParams = LPCREATESTRUCT(lParam)->lpCreateParams;

		if (createParams) {
			VWMPanel *panel = ((PanelEventArg*)(createParams))->panel;
			SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)panel);
		} 
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	
	VWMPanel *panel = (VWMPanel*)(GetWindowLong(hWnd, GWL_CLASSPOINTER));
	if(!panel) {
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	
	return panel->handleEvent(uMsg, wParam, lParam);
}

int VWMPanel::handleEvent(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
		case WM_LBUTTONDOWN: return mouseButtonEvent(mouseLeft,   mouseDown, LOWORD(lParam), HIWORD(lParam));
		case WM_RBUTTONDOWN: return mouseButtonEvent(mouseRight,  mouseDown, LOWORD(lParam), HIWORD(lParam));
		case WM_MBUTTONDOWN: return mouseButtonEvent(mouseMiddle, mouseDown, LOWORD(lParam), HIWORD(lParam));
		case WM_LBUTTONUP:   return mouseButtonEvent(mouseLeft,   mouseUp,   LOWORD(lParam), HIWORD(lParam));
		case WM_RBUTTONUP:   return mouseButtonEvent(mouseRight,  mouseUp,   LOWORD(lParam), HIWORD(lParam));
		case WM_MBUTTONUP:   return mouseButtonEvent(mouseMiddle, mouseUp,   LOWORD(lParam), HIWORD(lParam));
		
		case WM_ACTIVATE:
			if(isAppbar) {
				SHAppBarMessage(ABM_ACTIVATE, &appbarData);
			}
			return 0;
			
		case WM_KILLFOCUS:
			if(drag)
				SetCapture(window);
			//if(drag && drag->active)
			//	cancelDrag();
			return 0;
			
		case APPBAR_MESSAGE_ID:
			if(wParam == ABN_POSCHANGED) {
				updateAppbarPos();
			} else if(wParam == ABN_FULLSCREENAPP) {
				int state = SHAppBarMessage(ABM_GETSTATE, &appbarData);
				if(lParam) {
					if(alwaysOnTop) {
						long flags = GetWindowLong(window, GWL_EXSTYLE);
						SetWindowLong(window, GWL_EXSTYLE, flags&~WS_EX_TOPMOST);
					}
				} else {
					if(alwaysOnTop) {
						long flags = GetWindowLong(window, GWL_EXSTYLE);
						SetWindowLong(window, GWL_EXSTYLE, flags|WS_EX_TOPMOST);
					}
				}
			}
			return 0;
		
		case WM_MOUSEACTIVATE: {
			WindowData *foregroundWindow = windowTracker->getForegroundWindow();
			if(foregroundWindow)
				vwm->lastFocus = foregroundWindow->handle;
			else
				vwm->lastFocus = NULL;
			return MA_ACTIVATE;
		}
		
		case WM_MOUSEMOVE: {
			// In window coordinates
			int mouseX = LOWORD(lParam);
			int mouseY = HIWORD(lParam);
			mouseMoveEvent(mouseX, mouseY);
			return 0;
		}
		case WM_MOUSELEAVE: {
			if(drag && !drag->active) {
				SetCapture(window);
				beginDrag();
			}
			if(layout->changed()) {
				vwm->updateLayouts();
				vwm->forceRedraw();
			}
			return 0;
		}
		
		case WM_PAINT:
			onPaint();
			return 0;
			
		case WM_WINDOWPOSCHANGING:
			return onPosChanging(uMsg, wParam, lParam);
			
		default:
			Message message(uMsg, wParam, lParam);
			vwm->windowProc(message, window);
			return message.lResult;
	}
}

ElementContext *clickContext = NULL;

/// Called when a mouse button is pressed over this panel or released anywhere
/// after having been pressed on the panel. x and y are in window coordinates.
int VWMPanel::mouseButtonEvent(MouseButton button, MouseAction action, int x, int y)
{
	bool draggedAndDropped = false;
	vwm->updateLayouts();
	
	LayoutCacheNode *clickedPos = layout->elementAtPoint(x, y);
	if(!clickedPos) return 0;
	
	LayoutCacheNode *pressNode, *releaseNode, *clickNode;
	for(pressNode=clickedPos; pressNode; pressNode=pressNode->parent)
		if(pressNode->element->onPress[button]!="")
			break;
	for(releaseNode=clickedPos; releaseNode; releaseNode=releaseNode->parent)
		if(releaseNode->element->onRelease[button]!="")
			break;
	for(clickNode=clickedPos; clickNode; clickNode=clickNode->parent)
		if(clickNode->element->onClick[button]!="")
			break;
	
	string clickAction = "";
	
	if(action == mouseDown)
	{
		LayoutCacheNode *draggedNode = clickedPos;
		while(draggedNode && !draggedNode->element->draggable) {
			draggedNode = draggedNode->parent;
		}
		if(draggedNode) {
			drag = new DragInfo(draggedNode, x, y, button);
			vwm->forceRedraw();
		}
	}
	else if(action == mouseUp)
	{
		if(drag && drag->active)
			draggedAndDropped = true;
		finishDrag();
	}
	
	bool commandsRun = false;
	if(action==mouseDown && pressNode)
	{
		clickContext = &pressNode->context;
		LSExecute(window, pressNode->element->onPress[button].c_str(), SW_SHOWNORMAL);
		clickContext = NULL;
		commandsRun = true;
	}
	else if(action==mouseUp && releaseNode)
	{
		clickContext = &releaseNode->context;
		LSExecute(window, releaseNode->element->onRelease[button].c_str(), SW_SHOWNORMAL);
		clickContext = NULL;
		commandsRun = true;
	}
	
	if(clickNode)
	{
		clickContext = &clickNode->context;
		if(action==mouseDown)
		{
			lastClickLocation.context = clickNode->context;
			lastClickLocation.element = clickNode->element;
		}
		else if(action==mouseUp)
		{
			if(lastClickLocation.context.match(*clickContext)
			   && lastClickLocation.element == clickNode->element
			   && clickNode->element != NULL
			   && !draggedAndDropped)
			{
				LSExecute(window, clickNode->element->onClick[button].c_str(), SW_SHOWNORMAL);
				commandsRun = true;
			}
			lastClickLocation.element = NULL;
		}
		
		clickContext = NULL;
	}
	
	if(commandsRun)
	{
		// Running commands may have changed the layout
		vwm->updateLayouts();
		clickedPos = layout->elementAtPoint(x, y);
	}
	
	return 0;
}

/// Called when the mouse moves over the panel, or moves anywhere while
/// dragging on a click that started inside the panel. Given in window
/// coordinates, but may outside the window and may be negative.
int VWMPanel::mouseMoveEvent(int x, int y)
{
	// Suppress this event if outside window bounds
	if(x<0 || y<0 || x>=width || y>=height)
		return 1;
	
	// Request notification when the mouse leaves the window
	TRACKMOUSEEVENT args;
		memset(&args, 0, sizeof(args));
		args.cbSize = sizeof(TRACKMOUSEEVENT);
		args.dwFlags = TME_LEAVE;
		args.hwndTrack = window;
	TrackMouseEvent(&args);

	// Sometimes receive this event while unprepared for it
	if(!layout)
		return 1;
	
	if(layout->changed()) {
		layout->update();
		vwm->forceRedraw();
	}
	
	if(drag)
	{
		if(drag->active)
		{
			hoverDraggedObject(drag->element->prefix, x, y);
		}
		else
		{
			int dx = drag->mouseOrigin.x - x;
			int dy = drag->mouseOrigin.y - y;
			if(dx*dx + dy*dy > 25) {
				SetCapture(window);
				beginDrag();
			}
		}
	}
	return 0;
}

string VWMPanel::getPrefix()
	{ return prefix; }

void VWMPanel::setVisible(bool visible)
{
	this->visible = visible;
	if(visible)
		ShowWindow(window, SW_SHOWNOACTIVATE);
	else
		ShowWindow(window, SW_HIDE);
}

void VWMPanel::setAlwaysOnTop(bool onTop)
{
	this->alwaysOnTop = onTop;
	
	DWORD oldStyle = GetWindowLong(window, GWL_STYLE);
	DWORD tempStyle = (oldStyle & ~WS_POPUP) | WS_CHILD;
	DWORD newStyle = (oldStyle & ~WS_CHILD) | WS_POPUP;
	
	SetWindowLong(window, GWL_STYLE, tempStyle);
	SetParent(window, onTop?NULL:getDesktopWindow());
	SetWindowLong(window, GWL_STYLE, newStyle);
	
	SetWindowPos(window, onTop?HWND_TOPMOST:HWND_NOTOPMOST,
        0, 0, 0, 0,
        SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
}

/// This handles WM_WINDOWPOSCHANGING, which is sent when the panel is moved,
/// either by choice or by some other program forcibly moving it. Update
/// internals to reflect the new size.
int VWMPanel::onPosChanging(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LPWINDOWPOS windowPos = (LPWINDOWPOS)lParam;

	if ( !( windowPos->flags & SWP_NOSIZE ) )
	{
		width = windowPos->cx;
		height = windowPos->cy;
	}

	if ( !( windowPos->flags & SWP_NOMOVE ) )
	{
		x = windowPos->x;
		y = windowPos->y;
	}
	return DefWindowProc(window, uMsg, wParam, lParam);
}

bool VWMPanel::getVisible()
	{ return visible; }
bool VWMPanel::getAlwaysOnTop()
	{ return alwaysOnTop; }
HWND VWMPanel::getWindow()
	{ return window; }
Monitor *VWMPanel::getMonitor()
	{ return monitor; }

Rect VWMPanel::getRect()
	{ return Rect(x, y, width, height); }
Point VWMPanel::getTopLeft()
	{ return Point(x, y); }
