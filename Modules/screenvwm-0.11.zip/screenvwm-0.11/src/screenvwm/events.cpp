/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"
#include <CommCtrl.h>

static const int litestepMessageTypes[] = {
	LM_GETREVID,
	LM_SWITCHTON,
	LM_WINDOWACTIVATED,
	LM_LISTDESKTOPS,
	LM_GETDESKTOPOF,
	LM_WINDOWCREATED,
	LM_WINDOWDESTROYED,
	LM_GETMINRECT,
	LM_REDRAW,
	0
};

//=========================================================
// Message handling
//=========================================================
void VWMFirstPanel::registerEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)window, (LPARAM)litestepMessageTypes);
}

void VWMFirstPanel::unregisterEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)window, (LPARAM)litestepMessageTypes);
}

void VWM::windowProc(Message& message, HWND window)
{
	switch (message.uMsg)
	{
		case WM_SYSCOMMAND:
			if (message.wParam == SC_CLOSE)
				PostMessage(getDesktopWindow(), WM_KEYDOWN, LM_SHUTDOWN, 0);
			else
				message.lResult = DefWindowProc(window, message.uMsg, message.wParam, message.lParam);
			break;
		
		case WM_TIMER: {
			int timerID = (int)message.wParam;
			if(timerID == TIMER_HOVERTRACK)
			{
				updateHover();
			}
			else if(timerID == TIMER_POLL)
			{
				if(windowTracker->update())
					forceRedraw();
				for(unsigned ii=0; ii<panels.size(); ii++)
					panels[ii]->checkForUpdates();
			}
			break;
		}
			
		case WM_DROPFILES:
			onDropFiles(message);
			break;
		
		case WM_DISPLAYCHANGE:
			monitors->refresh();
			refreshPanels();
			break;
		
		case WM_KEYDOWN:
		case WM_KEYUP:
		case WM_HOTKEY:
			PostMessage(getDesktopWindow(), message.uMsg, message.wParam, message.lParam);
			break;
			
		case LM_GETREVID:
			onGetRevId(message);
			break;
			
		case LM_SWITCHTON:
			onSwitchToN(message);
			break;
			
		case LM_LISTDESKTOPS:
			onListDesktops(message);
			break;
			
		case LM_GETDESKTOPOF:
			onGetDesktopOf(message);
			break;
			
		case LM_REDRAW: {
			HWND handle = (HWND)message.wParam;
			if(message.lParam != 0) {
				WindowData *window = windowTracker->getWindow(handle);
				if(window)
					window->flashing = true;
			}
			
			// Indicates that a window changed title. (Possibly to what it was
			// before; for example, focusing Vis. Studio generates 2-6 copies
			// of this message). Check for updates.
			// (Which window is given by wParam, but our update-checking
			// interface can't really make use of this information.)
			for(unsigned ii=0; ii<panels.size(); ii++)
				panels[ii]->checkForUpdates();
			break;
		}
		
		case LM_WINDOWCREATED: {
			HWND handle = (HWND)message.wParam;
			windowTracker->windowCreated(handle);
			if(windowTracker->checkForChange())
				forceRedraw();
			break;
		}
			
		case LM_WINDOWDESTROYED: {
			HWND handle = (HWND)message.wParam;
			windowTracker->windowDestroyed(handle);
			if(windowTracker->checkForChange())
				forceRedraw();
			break;
		}
			
		case LM_WINDOWACTIVATED: {
			HWND handle = (HWND)message.wParam;
			windowTracker->windowActivated(handle);
			if(windowTracker->checkForChange())
				forceRedraw();
			
			WindowData *foregroundWindow = windowTracker->getForegroundWindow();
			if(foregroundWindow)
			{
				foregroundWindow->flashing = false;
				
				if(foregroundWindow->desk && !foregroundWindow->desk->monitor)
				{
					Monitor *monitor = findSingleMonitor(settings->altTabMonitor);
					if(!monitor) monitor = monitors->getPrimaryMonitor();
					switchDesk(foregroundWindow->desk, monitor, true);
				}
			}
			
			break;
		}
		
		case LM_GETMINRECT:
		{
			// There are several calling conventions this might be using,
			// because of a bug in older LS versions (0.24.7). If there's
			// both a wParam and an lParam, they're the window and its rect;
			// if there's no lParam, then wParam is an LPSHELLHOOKINFO (which
			// contains both).
			HWND windowHandle;
			LPPOINTS rect;
			
			if(!message.lParam) {
				LPSHELLHOOKINFO shellHookInfo = (LPSHELLHOOKINFO)message.wParam;
				windowHandle = shellHookInfo->hwnd;
				rect = (LPPOINTS)&shellHookInfo->rc;
			} else {
				windowHandle = (HWND)message.wParam;
				rect = (LPPOINTS)message.lParam;
			}
			
			
			// Find any panels on the same monitor as this window
			VirtualDesktop *desk = getDeskFromWnd(windowHandle);
			if(!desk) break;
			Monitor *monitor = desk->monitor;
			if(!monitor) break;
			vector<VWMPanel*> panels = monitor->getPanels();
			
			// Find a layout element with the <prefix>IsMinimizeTarget
			// attribute set on one of those panels
			vector<LayoutCacheNode*> elements;
			for(unsigned ii=0; ii<panels.size(); ii++)
			{
				Layout *layout = panels[ii]->getLayout();
				if(layout) layout->traverse(elements);
			}
			for(unsigned ii=0; ii<elements.size(); ii++)
			{
				if(!elements[ii]->element->isMinimizeTarget)
					continue;
				if(elements[ii]->context.task->handle != windowHandle)
					continue;
				
				VWMPanel *panel = elements[ii]->context.panel;
				Rect boundingRect = elements[ii]->context.boundingRect;
				Point panelPos = panel->getTopLeft();
				boundingRect.left += panelPos.x;
				boundingRect.top += panelPos.y;
				rect[0].x = boundingRect.left;
				rect[0].y = boundingRect.top;
				rect[1].x = boundingRect.getRight();
				rect[1].y = boundingRect.getBottom();
				message.lResult = 1;
				break;
			}
			
			break;
		}
		
		default:
			message.lResult = DefWindowProc(window, message.uMsg, message.wParam, message.lParam);
			break;
	}
}

void VWM::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);
	sprintf(buf, VERSION_STRING);
	message.lResult = strlen(buf);
}

// TODO: Test and rewrite this
void VWM::onDropFiles(Message& message)
{
	/*POINT pt;
	DragQueryPoint( (HDROP)message.wParam, &pt );
	
	VirtualDesktop *newDesk = panelPointToDesk(pt.x, pt.y);
	if(!newDesk) return;
	switchDesk(newDesk);

	int numFiles = DragQueryFile( (HDROP)message.wParam, 0xFFFFFFFF, NULL, 0 );
	for(int i=0; i<numFiles; i++)
	{
		char filename[_MAX_PATH];
		DragQueryFile( (HDROP)message.wParam, i, filename, _MAX_PATH);
		if (filename && *filename)
			LSExecute(NULL, filename, SW_SHOWNORMAL);
	}
	DragFinish( (HDROP)message.wParam );
	forceRedraw(true);*/
}

void VWM::onSwitchToN(Message &message)
{
	message.lResult = TRUE;
	int desk = (int) message.wParam;
	if(desk < 0 || desk >= (int)desktops.size())
		return;
	
	VirtualDesktop *newDesk = desktops[desk];
	switchDesk(newDesk, NULL, true);
}

void VWM::onListDesktops(Message &message)
{
	LSDESKTOPINFO deskInfo;

	for (unsigned ii = 0; ii < desktops.size(); ii++)
	{
		deskInfo.size = sizeof(LSDESKTOPINFO);
		deskInfo.icon = 0;
		deskInfo.isCurrent = desktops[ii]->monitor?1:0;
		deskInfo.number = ii;
		
		string deskname = desktops[ii]->getName();
		strcpy(deskInfo.name, deskname.c_str());

		SendMessage((HWND) message.wParam, LM_DESKTOPINFO, 0, (LPARAM) &deskInfo);
	}

	message.lResult = TRUE;
}

void VWM::onGetDesktopOf(Message &message)
{
	VirtualDesktop *desk = getDeskFromWnd((HWND) message.wParam);
	message.lResult = desk->index;
}
