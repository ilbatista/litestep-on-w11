/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"


class BranchExpression_not :public BranchElement::BranchExpression
{
public:
	BranchExpression_not(BranchElement::BranchExpression *child)
		:child(child) {}
	~BranchExpression_not()
		{ delete child; }
	bool evaluate(ElementContext *context)
		{ return !child->evaluate(context); }
	BranchElement::BranchExpression *child;
};

class BranchExpression_and :public BranchElement::BranchExpression
{
public:
	BranchExpression_and(BranchElement::BranchExpression *a, BranchElement::BranchExpression *b)
		:a(a), b(b) {}
	~BranchExpression_and() {
		delete a;
		delete b;
	}
	bool evaluate(ElementContext *context) {
		return a->evaluate(context) && b->evaluate(context);
	}
	BranchElement::BranchExpression *a, *b;
};

class BranchExpression_or :public BranchElement::BranchExpression
{
public:
	BranchExpression_or(BranchElement::BranchExpression *a, BranchElement::BranchExpression *b)
		:a(a), b(b) {}
	~BranchExpression_or() {
		delete a;
		delete b;
	}
	bool evaluate(ElementContext *context) {
		return a->evaluate(context) || b->evaluate(context);
	}
	BranchElement::BranchExpression *a, *b;
};

class BranchParseException :public std::exception
{
public:
	BranchParseException(const char *msg)
		:std::exception(msg) {}
};

BranchElement::BranchExpression *BranchElement::parseExpression(const char *&pos)
{
	pos = skipwhitespace(pos);
	BranchExpression *lhs = parseUnaryExpression(pos);
	pos = skipwhitespace(pos);
	
	if(*pos == '&') {
		pos++;
		if(*pos=='&')
			pos++;
		pos = skipwhitespace(pos);
		BranchExpression *rhs = parseExpression(pos);
		return new BranchExpression_and(lhs, rhs);
	} else if(*pos == '|') {
		pos++;
		if(*pos=='&')
			pos++;
		pos = skipwhitespace(pos);
		BranchExpression *rhs = parseExpression(pos);
		return new BranchExpression_or(lhs, rhs);
	} else if(*pos==')') {
		return lhs;
	} else if(!*pos) {
		return lhs;
	} else {
		throw BranchParseException("Unrecognized operator");
	}
	
	pos = skipwhitespace(pos);
}

BranchElement::BranchExpression *BranchElement::parseUnaryExpression(const char *&pos)
{
	if(!pos) throw BranchParseException("Internal error: NULL passed to parseUnaryExpression");
	pos = skipwhitespace(pos);
	if(!*pos) throw BranchParseException("Unexpected end of expression");
	
	if(*pos=='(')
	{
		pos++;
		pos = skipwhitespace(pos);
		BranchExpression *ret = parseExpression(pos);
		pos = skipwhitespace(pos);
		if(*pos != ')')
			throw BranchParseException("Mismatched parentheses");
		return ret;
	}
	else if(isalpha(*pos) || *pos=='_')
	{
		string token = "";
		while(isalnum(*pos) || *pos=='_')
			token += *(pos++);
		return parseLeafExpression(token);
	}
	else if(*pos=='!' || *pos=='~')
	{
		pos++;
		return new BranchExpression_not(parseUnaryExpression(pos));
	}
	
	throw BranchParseException("Unrecognized symbol or operator");
}

#define BRANCH_EXPR(name, expr) \
	class name :public BranchElement::BranchExpression { \
		bool evaluate(ElementContext *context) { return(expr); } \
	}

class BranchExpression_hover
	:public BranchElement::BranchExpression
{
	bool evaluate(ElementContext *context)
	{
		if(context->hovered)
			return true;
		
		VWMPanel *panel = context->panel;
		if(!panel) return false;
		Point mousePos = getCursorPos();
		
		// Convert mouse pos to window coordinates
		mousePos -= panel->getTopLeft();
		
		return context->boundingRect.containsPoint(mousePos.x, mousePos.y);
	}
};

class BranchExpression_windowHover
	:public BranchElement::BranchExpression
{
	bool evaluate(ElementContext *context)
	{
		TaskData *task = vwm->getHoveredTask();
		if(!task) return false;
		return task->containsWindow(context->task);
	}
};

BranchElement::BranchExpression *BranchElement::parseLeafExpression(const string &expr)
{
	const char *token = expr.c_str();
	
	if(!_stricmp(token, "minimized"))
	{
		BRANCH_EXPR(MinimizedCondition, context->task && context->task->isMinimized());
		return new MinimizedCondition();
	}
	else if(!_stricmp(token, "thismonitor"))
	{
		BRANCH_EXPR(ThisMonitorCondition,
			context->desk && context->desk->monitor==context->monitor);
		return new ThisMonitorCondition();
	}
	else if(!_stricmp(token, "focused"))
	{
		BRANCH_EXPR(FocusedCondition,
			(context->task && context->task->isFocusedTask())
			|| (!context->task && context->desk && context->desk->monitor));
		return new FocusedCondition();
	}
	else if(!_stricmp(token, "deskfocused"))
	{
		BRANCH_EXPR(DeskFocusedCondition,
			(context->desk && context->desk->monitor));
		return new DeskFocusedCondition();
	}
	else if(!_stricmp(token, "true"))
	{
		BRANCH_EXPR(TrueCondition, true);
		return new TrueCondition();
	}
	else if(!_stricmp(token, "false"))
	{
		BRANCH_EXPR(FalseCondition, false);
		return new FalseCondition();
	}
	else if(!_stricmp(token, "dragging"))
	{
		BRANCH_EXPR(DraggingCondition, ::drag);
		return new DraggingCondition();
	}
	else if(!_stricmp(token, "flashing"))
	{
		BRANCH_EXPR(FlashingCondition,
			(context->task && context->task->flashing));
		return new FlashingCondition();
	}
	else if(!_stricmp(token, "hovered"))
	{
		return new BranchExpression_hover();
	}
	else if(!_stricmp(token, "windowhovered"))
	{
		vwm->enableHoverTracking();
		return new BranchExpression_windowHover();
	}
	else
	{
		class VarCondition
			:public BranchElement::BranchExpression
		{
		public:
			VarCondition(string varname)
				:varname(varname) {}
			bool evaluate(ElementContext *context)
				{ return getConfigBool(varname.c_str(), false, ""); }
		private:
			string varname;
		};
		return new VarCondition(expr);
	}
}
