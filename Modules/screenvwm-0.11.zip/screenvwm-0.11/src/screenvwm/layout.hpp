/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

/////////////////////////////////////////////////////////////////////////////

struct ElementContext
{
	ElementContext();
	ElementContext(VWMPanel *panel, Monitor *monitor, VWM *vwm, VirtualDesktop *desk, WindowData *task, const Rect &boundingRect, bool hovered);
	
	/// True ifef all fields match, except boundingRect and hovered, which may differ
	bool match(const ElementContext &rhs) const;
	
	VWMPanel *panel;
	Monitor *monitor;
	VWM *vwm;
	VirtualDesktop *desk;
	WindowData *task;
	Rect boundingRect;
	bool hovered;
};
extern ElementContext *clickContext;
extern ElementContext *droppedContext;

struct LayoutLocation
{
	LayoutElement *element;
	ElementContext context;
};

/////////////////////////////////////////////////////////////////////////////

class Layout
{
public:
	Layout(LayoutElement *rootElement, ElementContext rootContext, string sizeFallbacks);
	~Layout();
	
	bool changed();
	void update();
	void draw(HDC drawContext);
	LayoutCacheNode *elementAtPoint(int x, int y);
	void traverse(vector<LayoutCacheNode*> &visited);
	
protected:
	LayoutCacheNode *findChange(LayoutCacheNode *tree);
	bool fallbackFits(int index);
	
	LayoutElement *rootElement;
	LayoutCacheNode *cachedRoot;
	ElementContext rootContext;
	
	int fallbackUsed;
	SizeFallbackChain *sizeFallbacks;
};

/////////////////////////////////////////////////////////////////////////////

class LayoutElement
{
public:
	LayoutElement(string prefix);
	virtual ~LayoutElement();
	
	virtual LayoutCacheNode *buildLayout(ElementContext *context, LayoutCacheNode *prevLayout, SizeFallback *sizeFallback);
	
	/// Returns the minimum (first) and preferred (second) length of this
	/// element. In flow layouts, size along one axis (thickness) is fixed
	/// while size on the other axis (length) may vary. Layout may be built
	/// with length less than preferred because total length is limited by the
	/// size of the screen.
	virtual pair<int,int> getLength(ElementContext *context, bool vertical, SizeFallback *sizeFallback)=0;
	
	virtual void draw(HDC drawContext, LayoutCacheNode *layout);
	virtual bool changed(LayoutCacheNode *node);
	
	virtual bool isModule();
	string toString() const;
	
	string prefix;
	
	string onPress[mouseNumButtons];
	string onRelease[mouseNumButtons];
	string onClick[mouseNumButtons];
	bool hoverGroup;
	bool draggable;
	bool isMinimizeTarget;
	LayoutElement *dragElement;
	LayoutElement *dragPlaceholder;
	
protected:
	bool isHovered(ElementContext *context);
	bool childChanged(LayoutCacheNode *node, int index, LayoutElement *expectedChild);
};

/////////////////////////////////////////////////////////////////////////////

class LayoutPool
{
public:
	LayoutPool();
	~LayoutPool();
	
	void parseElementList(const string &elements, vector<LayoutElement*> *elementList);
	LayoutElement *getElement(string prefix);
	
protected:
	LayoutElement *createElement(string prefix);
	vector<LayoutElement*> elements;
};
extern LayoutPool *layoutPool;

