/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

typedef int (*ModuleInitExFunc)(HWND, HINSTANCE, LPCSTR);
typedef int (*ModuleQuitFunc)(HINSTANCE);

ChildModuleElement::ChildModuleElement(string prefix)
	:RectLayoutElement(prefix)
{
	dllName = getConfigString("DLL", NULL, prefix.c_str());
	modulePrefix = getConfigString("Prefix", NULL, prefix.c_str());
	
	bool singleton = getConfigBool("Singleton", true, prefix.c_str());
	if(singleton && getConfigBool("Loaded", false, prefix.c_str())) {
		throw ModuleLoadException();
	}
	setConfigBool("Loaded", true, prefix.c_str());
	
	dllInstance = LoadLibrary(dllName.c_str());
	if(!dllInstance) {
		warn(retprintf("Failed to load library: %s", dllName.c_str()).c_str());
		throw ModuleLoadException();
	}
	
	loaded = false;
	
	initFunc = (ModuleInitExFunc)getModuleFunc("initModuleEx");
	quitFunc = (ModuleQuitFunc)getModuleFunc("quitModule");

	moveCommand   = getConfigLine("MoveCommand",   ("!"+modulePrefix+"Move").c_str(),   prefix.c_str());
	resizeCommand = getConfigLine("ResizeCommand", ("!"+modulePrefix+"Resize").c_str(), prefix.c_str());
	
	varX = getConfigLine("VarX", (modulePrefix+"X").c_str(), prefix.c_str());
	varY = getConfigLine("VarY", (modulePrefix+"Y").c_str(), prefix.c_str());
	
	string widthVars = getConfigLine("VarWidth",  (modulePrefix+"Width").c_str(),  prefix.c_str());
	string heightVars= getConfigLine("VarHeight", (modulePrefix+"Height").c_str(), prefix.c_str());
	
	tokenizeString(widthVars, varWidth, " ");
	tokenizeString(heightVars, varHeight, " ");
	
	lastX = lastY = -1;
	lastWidth = lastHeight = -1;
}


ChildModuleElement::~ChildModuleElement()
{
	quitFunc(dllInstance);
	FreeLibrary(dllInstance);
}

LayoutCacheNode *ChildModuleElement::buildLayout(ElementContext *context, LayoutCacheNode *prev, SizeFallback *sizeFallback)
{
	LayoutCacheNode *ret = RectLayoutElement::buildLayout(context, prev, sizeFallback);
	
	if(!loaded)
	{
		loaded = true;
		updateVars(false, &ret->context);
		initFunc(ret->context.panel->getWindow(), dllInstance, "");
	}
	else
	{
		updateVars(true, &ret->context);
	}
	
	return ret;
}

void ChildModuleElement::updateVars(bool doBangs, ElementContext *context)
{
	bool posChanged = false;
	bool sizeChanged = false;
	const Rect *boundingRect = &context->boundingRect;
	if(lastX != boundingRect->left) {
		lastX = boundingRect->left;
		posChanged = true;
	}
	if(lastY != boundingRect->top) {
		lastY = boundingRect->top;
		posChanged = true;
	}
	
	if(lastWidth != boundingRect->width) {
		lastWidth = boundingRect->width;
		sizeChanged = true;
	}
	if(lastHeight != boundingRect->height) {
		lastHeight = boundingRect->height;
		sizeChanged = true;
	}
	
	if(posChanged)
	{
		setConfigInt("X", boundingRect->left, modulePrefix.c_str());
		setConfigInt("Y", boundingRect->top, modulePrefix.c_str());
		
		if(doBangs) {
			string command = retprintf("%s %i %i", moveCommand.c_str(), lastX, lastY);
			LSExecute(context->panel->getWindow(), command.c_str(), SW_SHOWNORMAL);
		}
	}
	if(sizeChanged)
	{
		for(unsigned ii=0; ii<varWidth.size(); ii++) {
			setConfigInt(varWidth[ii].c_str(), boundingRect->width, "");
		}
		for(unsigned ii=0; ii<varHeight.size(); ii++)
			setConfigInt(varHeight[ii].c_str(), boundingRect->height, "");
		
		if(doBangs) {
			string command = retprintf("%s %i %i", resizeCommand.c_str(), lastWidth, lastHeight);
			LSExecute(context->panel->getWindow(), command.c_str(), SW_SHOWNORMAL);
		}
	}
}

void ChildModuleElement::draw(HDC drawContext, LayoutCacheNode *layout)
{
}
	
FARPROC ChildModuleElement::getModuleFunc(const char *name)
{
	FARPROC ret = GetProcAddress(dllInstance, name);
	if(!ret) {
		string underscoredName = string("_")+name;
		ret = GetProcAddress(dllInstance, underscoredName.c_str());
	}
	return ret;
}