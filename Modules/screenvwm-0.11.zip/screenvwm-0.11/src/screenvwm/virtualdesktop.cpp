/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

void VWM::initDesktops()
{
	if(!settings->autoGather) {
		if(restoreDesktops()>=0)
			return;
	}
	
	// Start with one desktop for each monitor
	for(int ii=0; ii<monitors->numMonitors(); ii++)
	{
		Monitor *monitor = monitors->getMonitor(ii);
		VirtualDesktop *newDesk = new VirtualDesktop(ii, storageManager.getStorageArea());
		
		newDesk->monitor = monitor;
		monitor->setDesk(newDesk);
		
		desktops.push_back(newDesk);
	}
	
	lastDesktop = desktops[desktops.size()-1];
}

int VWM::restoreDesktops()
{
	/*char buf[4096];
	
	if(!SendMessage(GetLitestepWnd(), LM_RESTOREDATA, MAKEWPARAM(sizeof(buf), MODULE_ID), (LPARAM)buf)) {
		return -1;
	}
	
	vector<StorageArea*> deskAreas;
	int focus = storageManager.restore((void*)buf, deskAreas);
	
	for(unsigned ii=0; ii<deskAreas.size(); ii++)
	{
		desktops.push_back(new VirtualDesktop(ii, deskAreas[ii]));
	}
	
	currentDesktop = desktops[focus];
	lastDesktop = currentDesktop;
	desktops[focus]->focused = true;
	
	updateTaskLists(true);
	
	return focus;*/
	// TODO: Redo desk save/restore for multimonitor
	return -1;
}

void VWM::saveDesktops()
{
	/*vector<StorageArea*> deskAreas;
	int focus = 0;
	for(unsigned ii=0; ii<desktops.size(); ii++) {
		deskAreas.push_back(desktops[ii]->offScreenStorage);
		if(desktops[ii]->focused)
			focus = ii;
	}
	
	int len;
	void *data = storageManager.save(&len, focus, deskAreas);
	SendMessage(GetLitestepWnd(), LM_SAVEDATA, MAKEWPARAM(len, MODULE_ID), (LPARAM)data);
	free(data);*/
	// TODO: Redo desk save/restore for multimonitor
}

void VWM::deleteEmptyDesktops()
{
	if(settings->keepEmptyDesktops)
		return;
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		if((int)desktops.size() <= monitors->numMonitors())
			break;
		
		VirtualDesktop *desk = desktops[ii];
		
		if(!windowTracker->deskIsEmpty(desk))
			continue;
		if(desk->monitor && settings->keepEmptyFocusedDesktop)
			continue;
		
		if(destroyDesktop(desk))
			ii--;
	}
}

/////////////////////////////////////////////////////////////////////////////

VirtualDesktop::VirtualDesktop(int index, StorageArea *storage)
{
	this->index = index;
	monitor = NULL;
	this->offScreenStorage = storage;
}

VirtualDesktop::~VirtualDesktop()
{
	delete offScreenStorage;
}

string VirtualDesktop::getName()
{
	char buf[32];
	sprintf(buf, "Desktop %i", index+1);
	return buf;
}

string VirtualDesktop::getLabel()
{
	char buf[16];
	_itoa(index+1, buf, 10);
	return buf;
}

void VirtualDesktop::show(Monitor *monitor)
{
	vector<WindowData*> windows = windowTracker->getWindows(this);
	
	for(unsigned ii=0; ii<windows.size(); ii++)
	{
		WindowData *window = windows[ii];
		if(window->tempSticky)
			continue;
		
		vwm->transferWindow(window, currentSlot(), monitor);
	}
	
	lastMaximizeArea = monitor->getMaximizeArea();
	monitor->unstoreRect(lastMaximizeArea);
	
	this->monitor = monitor;
	monitor->setDesk(this);
}

void VirtualDesktop::hide()
{
	// Can't hide if already hidden
	if(!monitor)
		return;
	
	lastMaximizeArea = monitor->getMaximizeArea();
	monitor->unstoreRect(lastMaximizeArea);
	
	vector<WindowData*> windows = windowTracker->getWindows(this);
	
	for(unsigned ii=0; ii<windows.size(); ii++)
	{
		WindowData *window = windows[ii];
		if(window->tempSticky)
			continue;
		vwm->transferWindow(window, monitor, offScreenStorage);
	}
	
	monitor = NULL;
}

void VirtualDesktop::switchWith(VirtualDesktop *otherDesk)
{
	if(!otherDesk)
		return;
	
	swap(lastMaximizeArea, otherDesk->lastMaximizeArea);
	
	vector<WindowData*> myWindows = windowTracker->getWindows(this);
	vector<WindowData*> otherWindows = windowTracker->getWindows(otherDesk);
	
	for(unsigned ii=0; ii<myWindows.size(); ii++)
	{
		WindowData *window = myWindows[ii];
		if(window->tempSticky)
			continue;
		vwm->transferWindow(window, currentSlot(), otherDesk->currentSlot());
	}
	for(unsigned ii=0; ii<otherWindows.size(); ii++)
	{
		WindowData *window = otherWindows[ii];
		if(window->tempSticky)
			continue;
		vwm->transferWindow(window, otherDesk->currentSlot(), currentSlot());
	}
	
	swap(monitor, otherDesk->monitor);
	otherDesk->monitor->setDesk(otherDesk);
	monitor->setDesk(this);
}

void VirtualDesktop::moveWindowTo(WindowData *window, VirtualDesktop *target)
{
	if(window->desk == target)
		return;
	
	vwm->transferWindow(window, currentSlot(), target->currentSlot());
	window->desk = target;
}

Monitor *VirtualDesktop::getMonitor()
{
	return monitor;
}

DeskSlot *VirtualDesktop::currentSlot()
{
	if(monitor)
		return monitor;
	else
		return offScreenStorage;
}

DeskSlot *VirtualDesktop::getOffScreenStorage()
	{ return offScreenStorage; }