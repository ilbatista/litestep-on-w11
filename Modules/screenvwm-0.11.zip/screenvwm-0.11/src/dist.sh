#!/bin/bash

VERSION=0.11
DISTDIR=dist
PACKAGEDIR=$DISTDIR/screenvwm-$VERSION

if [ -d "$PACKAGEDIR" ]; then
	rm -rf "$PACKAGEDIR"
fi

mkdir -p "$PACKAGEDIR/src"

cp screenvwm/Release/screenvwm.dll "$PACKAGEDIR"
cp screenvwm/Debug/screenvwm.dll "$PACKAGEDIR/screenvwm_debug.dll"
cp screenvwm/screenvwm_hotkeys.rc "$PACKAGEDIR"
cp screenhk/Release/screenhk.dll "$PACKAGEDIR"

cp -R screenhk screenvwm "$PACKAGEDIR/src"
cp dist.sh Doxyfile *.txt *.sln "$PACKAGEDIR/src"
cp README* COPYING.txt "$PACKAGEDIR"

# Remove intermediate files
(
	cd "$PACKAGEDIR/src"
	rm -rf screenvwm/Release screenvwm/Debug screenhk/Release screenhk/Debug
	find . -iname '.svn' |xargs rm -rf
	find . -iname '.user' |grep vcproj |xargs rm -f
)

# Zip it all up
(
	cd $DISTDIR
	zip -r screenvwm-$VERSION.zip "screenvwm-$VERSION"
)

# Put together a theme
THEMEDIR=theme/ScreenWM
mkdir -p "$THEMEDIR/modules"
cp "$PACKAGEDIR/screenvwm.dll" "$THEMEDIR/modules"
cp "$PACKAGEDIR/screenhk.dll" "$THEMEDIR/modules"
cp /bin/system/Litestep/themes/ScreenWM/theme.rc "$THEMEDIR"
cp -R /bin/system/Litestep/themes/ScreenWM/images "$THEMEDIR"

(
    cd theme
    zip -r "screenvwm-${VERSION}_theme.zip" ScreenWM
)

cp theme/screenvwm-${VERSION}_theme.zip dist

