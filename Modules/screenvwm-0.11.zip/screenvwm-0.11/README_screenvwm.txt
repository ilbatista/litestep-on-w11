ScreenVWM 0.11 - a Litestep taskbar and VWM
By Jim Babcock

************
* Contents *
************
* 1. Using ScreenVWM
* 2. Adding ScreenVWM to your theme
* 3. Bang commands
* 4. Misc configuration options
      4.1 Global options
      4.2 Default theme options
* 5. Panels
* 6. Layout options
      6.1 Overview
      6.2 Element Types
      6.3 Branch Elements
      6.4 Flow Elements
      6.5 Group Elements
      6.6 Icon Elements
      6.7 Label Elements
      6.8 Minimap Elements
      6.9 Texture Elements
      6.10 Module Elements
* 7. Child Modules
* 8. Descriptions
      8.1 Overview
      8.2 Desktops
      8.3 Windows
      8.4 Monitors
* 9. Legalities

**********************
* 1. Using ScreenVWM *
**********************
Initially, there will be one virtual desktop shown with all of your tasks in
it. To create a new desktop, drag one of your tasks' icons to an empty part of
the taskbar. You can also switch desktop and move windows between desktops
this way.

The file screenvwm_hotkeys.rc defines a set of hotkeys which all themes that
use ScreenVWM should include. These hotkeys are:
  Win+[1-9]         Switch to the numbered desktop (Win+0 is desk ten).
  Win+Left          Switch to previous desktop.
  Win+Right         Switch to next desktop.
  Win+Down          Merge current desktop with previous desktop.
  Win+Shift+Left    Move current application to previous desktop.
  Win+Shift+Right   Move current application to next desktop.
  Win+Shift+Up      Move current application to a new desktop at the beginning
                    of the list.
  Win+Shift+Down    Move current application to a new desktop at the end of
                    the list.
  Win+Ctrl+Left     Move this desk earlier in the list of desktops
  Win+Ctrl+Right    Move this desk later in the list of desktops
  Win+Ctrl+Down     Combine all desktops into one (gather)
  
*************************************
* 2. Adding ScreenVWM to Your Theme *
*************************************
To add ScreenVWM to your Litestep theme, put
  *NetLoadModule screenvwm.dll
in your theme.rc file. You will then want to configure it; take a look at
defaultSettings.txt for a list of options. In particular, you will at least
want to choose a size and position (the default is a 32-pixel thick bar across
the bottom of the screen), by setting swmPanelX, swmPanelY, swmPanelWidth, and
swmPanelHeight.

IMPORTANT: You cannot use ScreenVWM and another VWM module, such as vwm2 or
rabidvwm, at the same time. When you add the option to load ScreenVWM to your
theme.rc, make sure to disable loading of all other VWMs.

********************
* 3. Bang Commands *
********************
  !swmCloseWindow <window>
    Closes the indicated window.

  !swmCreate
    Creates a new desk containing the foreground task and switch to it. This is
    equivalent to dragging the foreground task to an unused part of the
    taskbar, or '!vwmMoveApp new'.

  !swmDestroy
    Synonym for '!swmMerge prev'

  !swmDesk <desk>
    Switch to the given desk, where <desk> is either a number (eg "!vwmDesk 1")
    or a description (eg "!vwmDesk next"). See "Desk descriptions".

  !swmGather
    Combine all desktops into one, moving all windows on screen.

  !swmMaximizeWindow <window>
    Maximizes the given window. If no window is specified, affects the
    foreground window.

  !swmMerge <desk>
    Merge the current desktop with the specified desktop, leaving one desktop
    with the windows and tasks of both.

  !swmMinimizeWindow <window>
    Minimizes the given window. If no window is specified, affects the
    foreground window.

  !swmMoveApp <window> <desk>
  !swmMoveApp <desk>
    If both arguments are given, moves the specified window to the given desk.
    If only a desk is given, moves the foreground app. In either case, the
    destination desk becomes focused.

  !swmMoveDesk <desk>
    Reorders desktops so that the current desktop is in the specified position.
    For example, "!swmMoveDesk last" moves the current desktop to the end of
    the list, while "!swmMoveDesk prev" moves the current desktop up one.

  !swmMoveWindow
    Moves the foreground window, as though you had picked 'move' from its
    system menu.

  !swmNext/!swmPrev/!swmUp/!swmDown/!swmLeft/!swnRight/!swmDown
    Switches the current desktop. These are  short for !vwmDesk with different
    parameters. See "Desk Descriptions". Up/left means prev and down/right
    means next.

  !swmOntopToggle
    Toggles whether or not ScreenVWM is always on top.

  !swmOpen <desk> <command>
    Switches to the given desk and then runs the given command or program.

  !swmRaiseWindow <window>
    Raises the given window to the foreground.
  
  !swmResizeWindow <window>
    Resizes the specified window, as though you had picked 'resize' from its
    system menu.

  !swmSeparate <desk>
  !swmSeparateAll
    Splits up desktops, making one desktop per window.

  !swmShow/!swmHide
    Makes ScreenVWM visible or invisible.

*********************************
* 4. Misc configuration options *
*********************************
4.1 Global options

  swmUseDefaultConfig [bool]
    Default: true
    Determines whether the builtin default configuration is loaded. This
    includes placement of panels and the layout hierarchy, so if this option
    is disabled, you must define the position of panels and the entire layout
    hierarchy yourself.
  
  swmKeepEmptyDesktops [bool]
  swmKeepEmptyFocusedDesktop
    Default: false
    Whether desktops with no tasks on them should be kept around (true) or
    deleted (false), depending on whether the desk in question is focused or
    not.

  swmAutoGather [bool]
    Default: true
    If true, ScreenVWM will gather (merge all desks) on startup. If false, it
    will attempt to preserve information about what desks tasks were on across
    a recycle.

  swmRescueOffScreenWindows [bool]
    Default: true
    If a window ends up completely off-screen for some reason, this controls
    whether ScreenVWM will move it back. This may cause problems for poorly
    written apps which move windows off-screen as a way to hide them.

  swmPollInterval [int]
    Default: 500
    How often ScreenVWM should refresh the list of windows/tasks. If set to 0,
    polling is disabled; this is not recommended as it will cause the creation of
    new windows to go unnoticed.

  swmHoverTrackingInterval [int]
    Default: 125
    How often ScreenVWM should check which window the mouse cursor is over.
    This is used for a highlight effect with the 'windowhovered' branch
    condition.

  swmAltTabMonitor [monitor]
    Default: cursor
    Controls which monitor is used to display a window when it's on a hidden
    desktop and you alt-tab to it.

4.2 Default theme options

  swmShowMinimaps
    Default: false
    If set, each desktop will be shown with a minimap that shows the position
    of windows on it.

  swmShowTitles
    Default: true
    If set, each task will have its title shown.

*************
* 5. Panels *
*************
ScreenVWM windows are referred to as panels. The list of panels is determined
by the swmPanels variable. By default, there is one panel, named 'swm', which
is placed at the top of each monitor.

  swmPanels [list]
    Default: swmPanel
    A space-separated list of the prefixes of all the panels that will be
    shown.

  <prefix>Monitors [monitor-set]
    Default: all
    The monitor (or monitors) on which this panel appears.

  <prefix>Visible [bool]
    Default: true
    Whether this panel starts visible.

  <prefix>Transparent [bool]
    Default: false
    Whether areas on this panel not covered by elements are transparent.

  <prefix>BackgroundColor [color]
    Default: 000000 (black)
    If not transparent, the panel's background fill color.

  <prefix>AlwaysOnTop [bool]
    Default: false
    Whether this panel starts out always on top

  <prefix>RootElement [identifier]
    Default: swmRoot
    The name of the root layout element which this panel is drawn with.

  <prefix>X [coord]
  <prefix>Y [coord]
  <prefix>Width [coord]
  <prefix>Height [coord]
    The location and size of this panel. Not used if this panel is an appbar.

  <prefix>Appbar [bool]
    Default: false
    If set, makes this panel into an appbar. Rather than using the rect
    specified by <prefix>X,Y,Width,Height, it spans the edge of the screen
    given by <prefix>Edge, with a thickness of <prefix>Thickness.
  
  <prefix>Edge [left|top|right|bottom]
    Default: bottom
    If this panel is an appbar, the edge of the screen which it is docked to.
  
  <prefix>AutoHide [bool]
    Default: false
    Makes this panel automatically hide itself when the cursor is not near it.
    Only available if <prefix>Appbar is true.
  
  <prefix>Thickness [int]
    The thickness of this panel, if it is an appbar. Ignored if it isn't.

*************
* 6. Layout *
*************
6.1 Overview
The layout of ScreenVWM panels is defined by a hierarchy of widgets, each of
which is identified by a string which is also the prefix of all its options.
Every element must have a type, given as <prefix>Type; this defines what the
element does and looks like and what other options are available, and it is an
error to use an element without defining its type. The following options are
available for all elements, regardless of type:

  <prefix>Type
    Mandatory (no default)
    The element's type. See below for a listing of allowed types.

  <prefix>On<Button>Press [command]
  <prefix>On<Button>Release [command]
  <prefix>On<Button>Click [command]
    Default: none
    Button is one of "Left", "Middle", or "Right". OnPress commands run when
    the mouse is pressed, and OnRelease commands when it's released. OnPress
    and OnRelease commands run independently of (and in addition to) drag and
    drop. OnClick commands run when the button is released, but only if the
    same thing is under the mouse as when the click started, and no drag/drop
    has taken place. If the command given is a ScreenVWM bang command,
    'clicked' is a valid desk/task description.

  <prefix>Draggable [bool]
    Default: false
    Whether this element can be picked up and dragged around. In general, it is
    best for draggable elements to be as close to the top of the hierarchy as
    possible; in particular, draggable elements should not be the child of
    branch elements, since if conditions change and the dragged element no
    longer exists, the drag will be cancelled (possibly as soon as it begins!).

  <prefix>DragPlaceholder [element]
    Default: <prefix>
    When this element is picked up and dragged, this is the element which stays
    behind to fill its place.

  <prefix>HoverGroup [bool]
    Default: false
    If set to true, hovering over this element causes all of its children to
    count as being hovered.

  <prefix>OnHover_<element> [command]
    Default: none
    What happens when a dragged <element> is hovered over this element. If this
    is a ScreenVWM bang command, 'dragged' and 'hovered' are valid desk/task
    descriptions.

  <prefix>OnDrop_<element> [command]
    Default: none
    What happens when a dragged <element> is dropped on this element. If this
    is a ScreenVWM bang command, 'dragged' and 'hovered' are valid desk/task
    descriptions.
  
  <prefix>IsMinimizeTarget [command]
    Default: false
    If this element corresponds to a task, it will be used as the target for
    Windows' minimize/restore animation.

6.2 Element Types

The element types are
  branch   One of several children depending on a boolean expression

  flow     A series of elements arranged in sequence, optionally with copies
           for each desk or each task within a desk

  group    A set of elements named in <prefix>Elements drawn on top of
           eachother.

  icon     The icon that belongs to the context task.

  label    A text label with either a fixed string, the context desk's number,
           or the context task's window title.

  minimap  A minimap of the context desk with all its windows.
  
  module   A child module (see section 7)

  null     An empty placeholder for an element

  texture  A button or decoration with an image or draw effect, drawn with
           XPaintClass.


6.3 Branch Elements
  A branch element one of the elements listed in <prefix>Elements. For each of
those elements, <element-name>Condition is a boolean expression which defines
when it should be used. If several conditions are satisfied, the first element
whose conditions are satisfied is the one used.
  Condition expressions may use the & (and), | (or), and ! (not) operators,
boolean RC variables (which are considered false if not defined), plus the
following keywords:

  minimized
    True if the context task is minimized.
  
  flashing
    True if the context task is flashing for attention.
  
  focused
    True if the context task's main window is focused, or if there is no
    context task and the context desk is focused.

  deskfocused
    True if the context desk is focused on any monitor.

  thismonitor
    True if the context desk is displayed on the same monitor as the panel.

  true, false
    The literal values true and false.

  dragging
    True if any element is currently being dragged
  
  hovered
    True if the cursor is over this element
  
  windowhovered
    True if the cursor is over a window belonging to the context task
  
Operators in branch condition expressions are right-associative; & and | have
the same precedence, but may be parenthesized.

6.4 Flow Elements
  A flow element takes a set of elements (including elements that are
duplicated for each task or desk) and arranges them relative to eachother. It
may also resize them to ensure that they all fit. The elements in a flow are
listed in <prefix>Elements. Elements can be either

  [element]
    Where [element] is the name of another layout element, which will be
    shown inside the flow element.

  .desks([element])
    Where [element] is the name of another layout element, which will be
    shown inside the flow element and repeated for every desk. These elements
    get a context desk, which is applied recursively to all their children.
  
  .tasks([element])
    Where [element] is the name of another layout element, which will be
    shown inside the flow element and repeated for every task. These elements
    get a context task, which is applied recursively to all their children.

  [N]
    Where [N] is an integer. Inserts N pixels of empty space.

  .[N]
    Where [N] is an integer. Inserts N pixels of optional empty space, which
    may shrink or be omitted if the flow is full or close to full.

  .freeSpace
    If there is extra space left over, controls where it goes. If there is no
    .freeSpace element, leftover space is added to the end. If there is more
    than one .freeSpace element, free space is divided equally between them,
    with odd pixels going to the first ones.

  Flow elements have <prefix>X, <prefix>Y, <prefix>Width, and <prefix>Height
options, which define the area in which children are allowed to appear. There
is currently no handling for when elements overflow the provided area, but
that is planned for future versions. Currently, the only flow layout option is
<prefix>Vertical, which switches between horizontal and vertical layouts.
Future versions will have multiple types of flow layouts and more options for
customizing them.

6.5 Group Elements
  A group element is a set of elements listed in <prefix>Elements in order
from bottom to top. Where elements overlap, mouse events go to the topmost
one. <prefix>BaseLength adds to the element's size for flow-layout purposes.

6.6 Icon Elements
  Icon elements show the icon of the root window of the context task. Its
size and position are given by <prefix>X, <prefix>Y, <prefix>Width and
<prefix>Height. In general, icons will look best if they are 16x16 or 32x32,
since those are the sizes which other programs provide their icons as; any
other size will be resized and, as a result, less sharp. Also, you may offset
icons so that they are partially clipped using <prefix>OffsetX and
<prefix>OffsetY, which are floats between 0 and 1 defining the fraction of
the icon's size it is offset by..

6.7 Label Elements
  A label element displays text, either a configured string or a property of
the context's desk or task. Labels have the following options:

  <prefix>AlignHoriz [left|center|right]
    default: center
    Whether this text is left, center, or right-aligned. This alignment also
    determines the meaning of <align>X; the left side, center, or right side,
    respectively.
  
  <prefix>AlignVert [top|center|bottom]
    default: center
    Whether this text is top, center, or bottom-aligned. This alignment also
    determines the meaning of <align>Y; the top, center, or bottom,
    respectively.

  <prefix>X [coord]
  <prefix>Y [coord]
    Where the edges of the text are. The default depends on alignment.

  <prefix>MinLength [coord]
    default: 0
    The minimum length for this text. If the text is smaller than this, it will
    be expanded and the extra space left blank.
    
  <prefix>MaxLength
    default: 250
    The maximum length for this text. If the text is larger than this, it will
    be shortened and ellipses ('...') used at the end.

  <prefix>Text
    default: .auto
    Either an arbitrary string, which will be drawn as-is, or .auto, .desknum,
    or .taskname. If it's .desknum, the number of the context's desk; if
    .taskname, the window title of the context's task; if .auto, then .taskname
    if available, .desknum if not, or "?" if neither is available.

Additionally, label elements respect all of the options supported by
XPaintClass's text renderer, which are listed in
  http://www.xdocs.ls-universe.info/pie.php?xPaintText
Some of the more useful of these options are <prefix>Font, <prefix>FontHeight
and <prefix>FontColor.

6.8 Minimap Elements
  A minimap element shows a tiny map of all the elements on the current desk.
This map has no background; use a texture for that. It has the following
options:
  <prefix>TitleBars [bool]
    default: true
  <prefix>TitleBarThickness [int]
    default: 4
  <prefix>Icons [bool]
    default: true
  <prefix>IconSize [int]
    default: 16
  <prefix>WinColor [color]
    default: ffffff
  <prefix>TitleBarColor [color]
    default: 505050
  <prefix>FocusedTitleBarColor [color]
    default: 0000ff
  <prefix>WinBorderColor [color]
    default: 000000

6.9 Texture Elements
  A texture element is a static image or other drawn effect. It is drawn
using XPaintClass, so all of the options given in 
  http://www.xdocs.ls-universe.info/pie.php?xPaintTexture
apply to it. In particular, you need to set <prefix>PaintingMode, usually
to either ".singlecolor" or ".image" (though others are possible).
Additionally, this respects <prefix>X, <prefix>Y, <prefix>Width and
<prefix>Height.

6.10 Module Elements
  A module element is an item drawn by another module, loaded from a DLL and
treated as a child window. For caveats and options, see the Child Modules
section of this readme.

********************
* 7. Child Modules *
********************
  Other modules can be nested inside ScreenVWM panels by using the 'module'
element type. ScreenVWM loads the module, then uses bang commands and
configuration variables to position and control it.
  Since child modules are loaded by ScreenVWM itself, you should not use
*NetLoadModule to load the module as you normally would. Instead, you can use
*NetInstallModule, which verifies that the module is present and ready to be
loaded, but doesn't actually load it.

  <prefix>DLL [string]
    The DLL which corresponding to the module. This should be an absolute path,
    so include $ModulesDir$ in the definition.

  <prefix>Singleton [bool]
    Default: true
    If set, only one instance of this module can be used, even if it appears
    in the layout more than once or if the layout is used for more than one
    panel.

  <prefix>Prefix [string]
    The prefix which this module's configuration variables and bang commands
    start with. This is used only to fill in the defaults for the module's
    variable names and bang commands.

  <prefix>VarX [string]
  <prefix>VarY [string]
  <prefix>VarWidth [string]
  <prefix>VarHeight [string]
    The names of the variables that control the module's placement and
    size. By default, these are created by appending X, Y, Width, and
    Height to the module prefix.

  <prefix>MoveCommand [command]
  <prefix>ResizeCommand [command]
    The names of bang commands that move and resize the module. The new
    position or size is appended to the command when it is run. By default,
    these are created by appending Move and Resize to the module prefix. If
    the move command is incorrectly set or doesn't work, the module will start
    in the right place but will not be able to move in response to changes in
    the layout. If the resize command is incorrectly set or doesn't work, the
    module will be limited to a fixed size.

*******************
* 8. Descriptions *
*******************
8.1 Overview
  Certain bang commands refer to desktops, windows, and monitors, which are
described by identifying some property, and in case nothing matches that
property, a second choice, third choice, and so on. Choices are separated
by slashes, so for example,
    !swmDesk next/first
will switch to the next desk and wrap around to the first desk at the end, but
    !swmDesk next/newnext
will switch to the next desk, but make a new desk rather than wrap around.

8.2 Virtual Desktops
  Wherever a bang command or variable refers to a desktop, you may choose a
desktop using one of the following descriptions. Note that there may not be
such a desktop; for example, if the last desktop is selected, then "next"
doesn't refer to anything. If no parameter is given or if none of the
described desks exists, defaults to clicked/next/prev/current. The available
descriptions are:

    [n]
      The nth desktop. Starts at 1 (there is no 0th desktop). May be any
      positive integer less than or equal to the number of desktops. If
      negative, desk -1 is the last desk, and -n is the Nth to last desk.

    prev(m), next(m)
      Where m is a monitor, or if no monitor is given, the monitor which the
      mouse cursor is on. The desktops before and after the desk which is
      visible on the indicated monitor.

    first, last
      The first and last desktops.
    
    current
      The desktop you are looking at now

    other
      The last desktop you looked at, besides the focused one

    up, left, right, down
      Synonyms for nextwrap and prevwrap provided for compatibility (up/left is
      prevwrap, down/right is nextwrap.)

    newprev(m), newnext(m), newfirst, newlast
      New desktops created in the corresponding positions. Note that empty
      desktops will be automatically deleted, so you must either put something
      on it (eg with !swmMoveApp) or set the swmKeepEmptyDesktops option.
    
    hovered
      The desk defined in the context of the element the mouse is currently
      over, if any. Undefined if the mouse is not over a panel, or if it's
      over a part of a panel which does not correspond to a desk.

    clicked
      If used in a mouse press, release, or click event handler, the desk
      which was clicked on.

    dragged, dropped
      Only meaningful inside a drag 'n drop handler when the dragged (or
      dropped-on) elements have a desk defined in their context.

8.3 Windows
  Whenever a bang command or variable refers to a window, you may choose a
window using one of the following descriptions. (These descriptions are mainly
to support mouse event handling and drag and drop).
  If a task owns more than one window, then layout elements involving it will use
the root window. Most bang commands (like !swmMoveApp) will affect the entire
task, including all its child windows.

    all(m)
      All windows on monitor m. If m is not specified, it is 'all' by default.

    tasks(m)
      All task windows on monitor m. If m is not specified, it is 'all' by
      default. Task windows are windows which would normally appear on the
      taskbar, as opposed to child windows, tool windows, etc.

    focused, foreground
      The current desk's topmost window. Note that this window doesn't have to
      actually have the focus; if a Litestep window has the focus, then the
      topmost window will still be used.
    
    topmost(m)
      The topmost window on the given monitor.

    hovered
      The task defined in the context of the hovered element, if any.
    
    clicked
      If in the context of a mouse click handler, the task which was clicked
      on.
    
    dragged dropped
      If in the context of a drag event handler, the task which is being
      dragged or being dragged onto.

8.4 Monitors
  Whenever a bang command or variable refers to a monitor, you may choose a
monitor using one of the following descriptions. When a monitor is expected
but none is specified, 'cursor' is used as the default.

    1,2,3,...
      The Nth monitor

    clicked
      The monitor that shows the panel that was clicked on

    cursor
      The monitor which the mouse cursor is currently on

    primary
      The primary monitor
    
    secondary
      The second monitor

*****************
* 9. Legalities *
*****************

ScreenVWM is copyright (C) 2008 James Babcock. It contains code derived from
LiteStep, which is copyright (C) 1997-2008 The LiteStep Development Team.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the file license.txt for details.





































