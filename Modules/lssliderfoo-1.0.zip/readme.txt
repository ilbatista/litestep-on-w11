Just a small mod of the lsslider 1.0 source, 
basically converts it to use foobar2000 with the foo_remote plugin.

by thegeek @ efnet.


I don't know how all this works, so if anyone has any objections to me
releasing this, please let me know. I just thought someone(like me)
would really like to use this. I really suck at programming, so the code is probably terrible, in 
addition it is based on ver 1.0 of the module, so basically it sucks;)
However, it does work, just make sure to replace your slider line

from (example): 
*Slider "Track"  $SlidersX$ 12 1 "SliderTrack.png" "SliderHandleT.png" #1HIT [WINAMP] 0
to:
*Slider "Track"  $SlidersX$ 12 1 "SliderTrack.png" "SliderHandleT.png" #1HIT [FOOBAR] 0 


[Ed: I've changed the name of this module from LSSlider-1.0 to LSSliderFoo-1.0 too keep everything kosher.  Sorry. --Cypress]
--
Loose-screws Litestep Module archive
Http://www.loose-screws.com/modules.php