-\\____________________________//-
-//                            \\-
           xParser v0.1
	        by Andymon
	 andymon@ls-universe.info
-\\____________________________//-
-//                            \\-

---------
Overview:
---------

	This is just a Helper Module, which helps to save Time and cfg-Lines in repeated CFG.
	
	It unloads itself after it's work is done and provides no Bangs or anything else.
	
	It adds "ForEach" Loops to the CFG possibilities of LS ( Rough Explanation see below :) )
	
	Comments and Questions in the Forum at http://www.ls-universe.info


----------------------------
!!!!!!!! IMPORTANT: !!!!!!!!
----------------------------

    This Module MUST be loaded BEFORE any other Module, which should use the processed lines!!
    Any Module loaded before xParser-0.1 cannot use the processed lines, cause they are not there!!

    THE SEARCH IN xParser-0.1 IS CASESENSITIVE!!
    
    DON'T USE xParser-0.1 FOR *Settings like *Popup, *(label-name)LeftClickRegion, *Label, ...

    DON'T MAKE NESTED "FOREACH" LOOPS, IN THE BEST CASE THEY SIMPLY WON'T WORK!!

----------------------------
!!!!!!!! IMPORTANT: !!!!!!!!
----------------------------



-----------------------------
Basic Configuration Overview:
-----------------------------

    What does this module do?
    -------------------------

    Example:
    --------

    foreach [string][replace1][replace2][replace3]
    teststring hallo
    endforeach

    These three lines would add the following, usable, CFG to LS

    teststring hallo
    testreplace1 hallo
    testreplace2 hallo
    testreplace3 hallo


    The Replace works in the Evar as well as in the Content!

    foreach [string][replace1][replace2][replace3]
    teststring string
    endforeach

    These three lines would add the following, usable, CFG to LS

    teststring string
    testreplace1 replace1
    testreplace2 replace2
    testreplace3 replace3


    Ok, How does this work?
    -----------------------

    Inside a "foreach" loop all CASESENSITIVE occurrances of the FIRST specified String,
    in our Example "string"
    will be replaced with the following ones ( as many as you want/need ),
    in our Example "replace1", "replace2", "replace3" and so on
    
    Due to LS parsing the "Default" is also an Evar! (See above)


    Ok, For what?
    -----------------------

    Well, you must find a useful purpose in your theme yourself :P


-----------------------------
Examples Overview:
-----------------------------
    
    Try this at your current theme:
    -------------------------------

    *label 0
    *label 2
    *label 4
    *label 6
    *label 8
    foreach [CFG][0][2][4][6][8]
    CFGx $CFG*64$
    CFGsolidcolors CFGCFGCFGCFGCFGCFG
    endforeach


    Another useful option would be for multiple xPopup Configurations!
    Just setup all identical settings with a "ForEach" Loop and only define different settings the normal way.

    foreach [same][xpopup][ypopup]
    sametitlefontheight 20 
    sametitlefontcolor c0c0c0
    sametitlefonttopborder 5 
    sametitlefontleftborder 5 
    sametitlefontrightborder 5 
    sametitlefontbold 
    sametitlefontoutline 
    sametitlefontoutlinecolor 252525
    endforeach

    So xpopup and ypopup would have the same TitleFont Configuration and you must write it only once.
    If you want to have 8 different Popups with only a few differences this really makes sense ;)
    
    Btw: Naturally a xPopup named "same" would have also the TitleFont Configuration!!



-----------------------------
Contact:
-----------------------------

Homepage: Here you find News, Updates, and some more.
          http://www.ls-universe.info



