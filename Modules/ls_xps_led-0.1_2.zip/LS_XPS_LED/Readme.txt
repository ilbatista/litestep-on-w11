       LS_XPS_LED.dll v0.1
LED !Bang Control for Dell XPS Gen2 Laptops
           02/16/06
       Written by Mercutio
-------------------------------------------
A quick and dirty implementation of the LED control
for Dell XPS Gen2 Laptops.  It consists of a single
!bang command.

Usage:
------
!ChangeLed [Color] [Intensity]

Color is a value from 1 to 16, Intensity is a value
from 1 to 7.

Changes:
--------
02/16/06: First Release

Bugs:
-----
None known

Contact info:
-------------
E-mail       : mercutio@theeclectic.net
Website      : http://www.theeclectic.net
Message board: http://www.theeclectic.net/bboard