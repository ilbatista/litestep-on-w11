/****************************************************************
This sourcecode is part of:
filemaster.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)

The program mentioned above is copyrighted freeware
for any noncommercial use or distribution.

The program is provided "as is", without warranty of any kind,
express or implied, including but not limited to warranties of
merchantability, fitness for a particular purpose and
non-infringement. In no event shall I, the author and copyright
holder be liable, whether in action of contract, tort or otherwise,
arising from, out of or in connection with the program or the use
or other dealings in the software.

Mike Edward Moras
e-sushi@gmx.net

This sourcecode is part of:
filemaster.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/

/***************************************************************
changes:

2002-10-12: rabidcow
   - now using LSRegister/RemoveBangList
   - rearranged to use default of FALSE and no ifs
   - grouped common code to reduce size
   - using GetFileAttributesEx to test for exists
   - using TRUE/FALSE for BOOLs instead of true/false (for bools)
   - removed dependency on CRT, added nocrt.cpp and /Gs16384

12OCT02: e-sushi
   - released this as GNU GPL v2
   - NTFS could have bugs, I could not check before release.

****************************************************************/

#include "filemaster.h"

lsBangCmdDef Bangs[] = {
  { "PANIC", bangPanic },
  { NULL, NULL }
};

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  LSRegisterBangList("!",1,Bangs);
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
  LSRemoveBangList("!",1,Bangs);
}


/***************************************************************
  Register/Unregister a list of bang commands. [js]
****************************************************************/

#ifndef LSTOOLS_REV

/*	Bang commands must be 63 chars or fewer.
		I believe this is a restriction in the LS code,
		but I don't wanna look it up right now. */
#define MAX_BANGCMD_LENGTH 64

void LSRegisterBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs)
{
	lsBangCmdDef *pBang;
	char BangString[MAX_BANGCMD_LENGTH];

	ASSERT(READABLE(prefix,(prefixlen+1)*sizeof(char)));
	ASSERT(READABLE(Bangs,sizeof(lsBandCmdDef)));

	lstrcpy(BangString,prefix);

	if (prefixlen<0) prefixlen = lstrlen(prefix);

	/* actually, it should be much less, since */ 
	/* we paste the bang names on after this   */ 
	ASSERT(prefixlen<MAX_BANGCMD_LENGTH);

	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+prefixlen,pBang->Name);
		AddBangCommand(BangString, pBang->Command);
		pBang++;
	}
}

void LSRemoveBangList(const char *prefix,int prefixlen,lsBangCmdDef *Bangs)
{
	lsBangCmdDef *pBang;
	char BangString[MAX_BANGCMD_LENGTH];

	ASSERT(READABLE(prefix,(prefixlen+1)*sizeof(char)));
	ASSERT(READABLE(Bangs,sizeof(lsBandCmdDef)));

	lstrcpy(BangString,prefix);

	if (prefixlen<0) prefixlen = lstrlen(prefix);

	ASSERT(prefixlen<MAX_BANGCMD_LENGTH);

	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+prefixlen,pBang->Name);
		RemoveBangCommand(BangString);
		pBang++;
	}
}

#endif

BOOL CALLBACK EnumWindowsProc( HWND hwnd, LPARAM lParam)
{
    long style;

    if(IsWindowVisible(hwnd))
    {
        style=GetWindowLong(hwnd,GWL_STYLE);
        if(style & WS_OVERLAPPEDWINDOW &&
            (style & WS_POPUP)== false)
        {
			PostMessage(hwnd,WM_CLOSE,0,0);
        }
    }
    
    return true;
}

/****************************************************************
 code: bangFileExist
 bang: !FILEEXIST "c:\path\file.txt" "!bangiffound" "!bangifnotfound"
****************************************************************/

void bangPanic(HWND caller, LPCSTR args)
{
 EnumWindows(EnumWindowsProc,0);
}


/****************************************************************
This sourcecode is part of:
filemaster.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/
