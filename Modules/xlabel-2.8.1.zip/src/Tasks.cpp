#include "common.h"
#include "Tasks.h"

StringList tasksList;

BOOL CALLBACK TaskEnumWindowsProc(HWND hwnd, LPARAM lParam);

BOOL CALLBACK TaskEnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	if (IsAppWindow(hwnd))
	{
		char pszWindowText[1024];
		GetWindowText(hwnd, pszWindowText, sizeof(pszWindowText));

		tasksList.insert(tasksList.end(), pszWindowText);
	}

	return TRUE;
}

string Tasks::UpdateTasks(string sep, bool first)
{
	tasksList.clear();
	// add the contents
	EnumWindows(TaskEnumWindowsProc, (LPARAM)this);

	string result = "";
	if (!first)
	{
		for(StringListIterator it = tasksList.begin(); it != tasksList.end(); it++)
		{
			result.append((*it));
			it++;
			if (it != tasksList.end())
				result.append(sep);
			it--;
		}
	}
	else if (tasksList.begin() != tasksList.end())
		result.append( (*tasksList.begin()) );

	return result;

}