/*
  NetLoadModule LiteStep Module - version 2.02

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
// Remember to fix the include paths and link with lsapi.lib

#include "NetLoadModule.h"
#define _WIN32_WINNT 0x500
#include "Commdlg.h"

void mooBegin(HWND hDlg);
void mooDownload(HWND hDlg);
void mooInstall(HWND hDlg);
void mooDone(HWND hDlg);
void mooDoneAll(HWND hDlg);

#define MODICON_DOT      0
#define MODICON_FAILURE  1
#define MODICON_SUCCESS  2
#define MODICON_DOWNLOAD 3


/*
	Initialize and fill the module list.
*/
bool InitModuleListCtrl(HWND hCtrl)
{
	_TCHAR Label[NLM_PATH_LENGTH];
	LVCOLUMN lvc;
	int TotalWidth;
	RECT r;

	GetClientRect(hCtrl,&r);
	TotalWidth = r.right-r.left;
 
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM; 

	/* Add the columns. */ 
	lvc.pszText = Label;	
	lvc.fmt = LVCFMT_LEFT;

	lvc.iSubItem = 0;
	lvc.cx = (TotalWidth+1)/2;
	LoadString(GlobalData.hInstance, IDS_MODULE + 0, Label, NLM_PATH_LENGTH);
	if (ListView_InsertColumn(hCtrl, 0, &lvc) == -1) 
		return false; 

	lvc.iSubItem = 1;
	lvc.cx = TotalWidth/2;
	LoadString(GlobalData.hInstance, IDS_MODULE + 1, Label, NLM_PATH_LENGTH);
	if (ListView_InsertColumn(hCtrl, 1, &lvc) == -1) 
		return false;

	HIMAGELIST hIL;
	HBITMAP hbm;

	/* don't use all 8 images right now, but whatever */ 
	hIL = ImageList_Create(16,16,ILC_COLOR|ILC_MASK ,8,0);
	if (hIL==NULL) return false;

	/* load the images */ 
	hbm = LoadBitmap(GlobalData.hInstance,MAKEINTRESOURCE(IDB_MODULE_STATE));
	if (ImageList_AddMasked(hIL,hbm,RGB(255,0,255))==-1)
	{
		DeleteObject(hbm);
		return false;
	}
	DeleteObject(hbm);

	/* asign it to the list view                     */ 
	/* (the control now takes responsibility for it) */ 
	ListView_SetImageList(hCtrl,hIL,LVSIL_SMALL);

	/* insert list items */ 
	s_Module *pMod;
	LVITEM lvi;

	pMod = GlobalData.pModules;
	lvi.iItem=0;
	lvi.state=0;
	lvi.stateMask=0;
	while (pMod!=NULL)
	{
		if (!pMod->Exists || GlobalData.bTestMessage)
		{
			/* set first column: module name */ 
			if (pMod->Exists)
				lvi.iImage=MODICON_SUCCESS;
			else
				lvi.iImage=MODICON_DOT;
			lvi.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM | LVIF_STATE;
			lvi.iSubItem=0;
			lvi.lParam = (LPARAM)pMod;
			lvi.pszText = pMod->Name;
			if (ListView_InsertItem(hCtrl, &lvi) == -1)
				return false;

			/* set second column: description or primary site */ 
			lvi.mask = LVIF_TEXT;
			lvi.iSubItem=1;
			if (pMod->Desc==NULL)
				lvi.pszText = pMod->PrimarySite;
			else
				lvi.pszText = pMod->Desc;
			if (lvi.pszText && ListView_SetItem(hCtrl, &lvi) == -1)
				return false;

			/* next position */ 
			lvi.iItem++;
		}
		pMod = pMod->pNext;
	}

	return true; 
}



bool BeginDownload(HWND hDlg)
{
	_TCHAR buffer[NLM_PATH_LENGTH];

	EnableWindow(GetDlgItem(hDlg,IDCANCEL),FALSE);
	EnableWindow(GetDlgItem(hDlg,IDC_DOWNLOAD),FALSE);
	EnableWindow(GetDlgItem(hDlg,IDC_MODULE_LIST),FALSE);
	ShowWindow(GetDlgItem(hDlg,IDCANCEL),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_DOWNLOAD),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_PROGRESS1),SW_SHOW);

	LoadString(GlobalData.hInstance,IDS_DL_MESSAGE,buffer,NLM_PATH_LENGTH);
	SetDlgItemText(hDlg,IDC_MESSAGE,buffer);

	*buffer = 0;
	SetDlgItemText(hDlg,IDC_STATUS,buffer);

	/* switch the dialog to download mode    */ 
	SetWindowLong(hDlg, DWL_DLGPROC, (LONG)&DownloadDlgProc);

	/* detect if any modules fail to install */ 
	GlobalData.bAnyFail = false;

	/* start download                        */ 
	GlobalData.pCurrentModule = GlobalData.pModules;
	GlobalData.pCurrentArchive = NULL;
	GlobalData.CurrentStep = &mooBegin;
	PostMessage(hDlg,WM_ENTERIDLE,NULL,NULL);

	return true;
}

HWND GetListAndItem(HWND hDlg,LVITEM *plvi)
{
	HWND hList;

	hList = GetDlgItem(hDlg,IDC_MODULE_LIST);

	plvi->mask = LVIF_PARAM;
	plvi->iSubItem=0;
	ListView_GetItem(hList,plvi);

	return hList;
}

HWND GetListAndCurrentItem(HWND hDlg,LVITEM *plvi)
{
	HWND hList;

	hList = GetDlgItem(hDlg,IDC_MODULE_LIST);

	plvi->iItem= ListView_GetNextItem(hList,-1,LVNI_ALL|LVNI_FOCUSED);

	return GetListAndItem(hDlg,plvi);
}

s_Module *GetModuleFromList(HWND hDlg)
{
	LVITEM lvi;

	GetListAndCurrentItem(hDlg,&lvi);

	return (s_Module *)lvi.lParam;
}

void ToggleInstallNow(HWND hDlg)
{
	LVITEM lvi;
	HWND hList;
	s_Module *pMod;

	hList = GetListAndCurrentItem(hDlg,&lvi);

	pMod = (s_Module *)lvi.lParam;
	pMod->bDontInstall = !pMod->bDontInstall;

	lvi.mask = LVIF_IMAGE;
	if (pMod->bDontInstall)
		lvi.iImage = MODICON_FAILURE;
	else
		lvi.iImage = MODICON_DOT;
	ListView_SetItem(hList,&lvi);
	ListView_RedrawItems(hList,0,0);
}

void SelectFileAlias(HWND hDlg)
{
	LVITEM lvi;
	HWND hList;
	s_Module *pMod;
	OPENFILENAME ofn;
	_TCHAR file[MAX_PATH_LENGTH];

	/* get the focused item */ 
	hList = GetListAndCurrentItem(hDlg,&lvi);

	pMod = (s_Module *)lvi.lParam;

	/* use a common open dialog to get dll path */ 
	ZeroMemory(&ofn,sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hDlg;
	ofn.lpstrFilter = "Modules (*.dll)\0*.DLL\0All Files\0*.*\0";
	_tcscpy(file,pMod->DllPath);
	ofn.lpstrFile = file;
	ofn.nMaxFile = MAX_PATH_LENGTH;
	ofn.lpstrTitle = "Select Module File";
	ofn.Flags = OFN_DONTADDTORECENT|OFN_NONETWORKBUTTON|OFN_FILEMUSTEXIST|OFN_HIDEREADONLY;

	if (GetOpenFileName(&ofn)==IDOK)
	{
		/* set the path        */ 
		if (pMod->DllPath) delete[] pMod->DllPath;
		pMod->DllPath = new _TCHAR[_tcslen(file)+1];
		_tcscpy(pMod->DllPath,file);

		/* remember it later   */ 
		AddAlias(pMod->Name,pMod->DllPath);

		/* mark it as existing */ 
		pMod->Exists = true;
		lvi.mask = LVIF_IMAGE;
		lvi.iImage = MODICON_SUCCESS;
		ListView_SetItem(hList,&lvi);
		ListView_RedrawItems(hList,0,0);
	}
}

void DoContextMenu(HWND hWnd)
{
	POINT pt;
	HMENU root,context;

	root = LoadMenu(GlobalData.hInstance,MAKEINTRESOURCE(IDR_CONTEXT_MENUS));
	context = GetSubMenu(root,0);

	if (GetModuleFromList(hWnd)->bDontInstall)
		CheckMenuItem(context,ID__DONOTINSTALLTHISMODULENOW,MF_BYCOMMAND|MF_CHECKED);

	GetCursorPos(&pt);
	/* do the context menu, commands are sent to the dialog proc */ 
	TrackPopupMenu(context,TPM_RIGHTBUTTON,pt.x,pt.y,0,hWnd,NULL);

	DestroyMenu(root);
}

// DialogProc -----------------------------------------------------------------

INT_PTR CALLBACK ModListDlgProc(
		HWND hwndDlg,  /* handle to dialog box     */ 
		UINT uMsg,     /* message                  */ 
		WPARAM wParam, /* first message parameter  */ 
		LPARAM lParam  /* second message parameter */ 
	)
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
			GlobalData.hMainDlg = hwndDlg;
			if (InitModuleListCtrl(GetDlgItem(hwndDlg,IDC_MODULE_LIST)))
			{
				return TRUE;
			}
			EndDialog(hwndDlg,IDCANCEL);			
			return TRUE;

		case WM_COMMAND:
			if (HIWORD(wParam)==BN_CLICKED) {
				switch (LOWORD(wParam))
				{
				case IDC_DOWNLOAD:
					// begin download process
					BeginDownload(hwndDlg);
					//EndDialog(hwndDlg,IDOK);

					return TRUE;
				case IDCANCEL:
					EndDialog(hwndDlg,IDCANCEL);
					return TRUE;

				case IDOK:
					EndDialog(hwndDlg,IDOK);
					return TRUE;

				/* context menu commands */ 
				case ID__DONOTINSTALLTHISMODULENOW:
					ToggleInstallNow(hwndDlg);
					return TRUE;
				case ID__SELECTFILE:
					SelectFileAlias(hwndDlg);
					return TRUE;
				}
			}
			break;

		case WM_NOTIFY:
			{
				LPNMHDR pnmh = (LPNMHDR)lParam;
				if (pnmh->idFrom == IDC_MODULE_LIST)
				{
					switch (pnmh->code)
					{
					case NM_RCLICK:
						/* user right-clicked in module list */ 
						if (ListView_GetSelectedCount(pnmh->hwndFrom)>0)
							DoContextMenu(hwndDlg);
						return TRUE;
					}
				}
			}
			break;

		case WM_CLOSE:
			EndDialog(hwndDlg,IDCANCEL);
			return TRUE;
	}
	return FALSE;
}

//
// Installation FSM
//

void mooBegin(HWND hDlg)
{
	_TCHAR message[NLM_PATH_LENGTH];

	LVITEM lvi;
	HWND hList;

	lvi.iItem= GlobalData.iCurrentModule;
	hList = GetListAndItem(hDlg,&lvi);

	GlobalData.pCurrentModule = (s_Module *)lvi.lParam;

	if (GlobalData.pCurrentModule->Exists || GlobalData.pCurrentModule->bDontInstall)
	{
		/* this one's already there, go to the next one */ 
		GlobalData.CurrentStep = &mooDone;
		return;
	}

	lvi.mask = LVIF_IMAGE;
	lvi.iImage=MODICON_DOWNLOAD;
	ListView_SetItem(hList,&lvi);
	ListView_RedrawItems(hList,0,0);
	UpdateWindow(hList);

	LoadString(GlobalData.hInstance,IDS_DOWNLOADING,message,NLM_PATH_LENGTH);
	TRACE(message);
	SetDlgItemText(hDlg,IDC_STATUS,message);

	GlobalData.CurrentStep = &mooDownload;
}

void mooDownload(HWND hDlg)
{
	_TCHAR message[NLM_PATH_LENGTH];
	if (
		DownloadModule(GlobalData.pCurrentModule,GlobalData.CurrentName,NLM_PATH_LENGTH)
		 )
	{
		LoadString(GlobalData.hInstance,IDS_INSTALLING,message,NLM_PATH_LENGTH);
		TRACE(message);
		SetDlgItemText(hDlg,IDC_STATUS,message);
		GlobalData.CurrentStep = &mooInstall;
	}
	else
	{
		GlobalData.CurrentStep = &mooDone;
	}
}

void mooInstall(HWND hDlg)
{
	InstallModule(hDlg,GlobalData.pCurrentModule,GlobalData.CurrentName);
	GlobalData.CurrentStep = &mooDone;
}

void mooDone(HWND hDlg)
{
	WIN32_FILE_ATTRIBUTE_DATA srcdat;

	LVITEM lvi;
	HWND hList;

	/* update existance flag */ 
	GlobalData.pCurrentModule->Exists =
		GetFileAttributesEx(GlobalData.pCurrentModule->DllPath,GetFileExInfoStandard,&srcdat)
		?true:false;

	hList = GetDlgItem(hDlg,IDC_MODULE_LIST);

	lvi.iItem= GlobalData.iCurrentModule;
	lvi.iSubItem=0;
	lvi.mask = LVIF_IMAGE;

	if (GlobalData.pCurrentModule->Exists)
	{
		lvi.iImage=MODICON_SUCCESS;
		TRACE("Success.");
	}
	else
	{
		lvi.iImage=MODICON_FAILURE;
		TRACE("Failure.");
		GlobalData.bAnyFail = true;
	}

	ListView_SetItem(hList,&lvi);
	ListView_RedrawItems(hList,0,0);
	UpdateWindow(hList);

	SetDlgItemText(hDlg,IDC_STATUS,"");

	/* go to the next item */ 
	++GlobalData.iCurrentModule;
	lvi.mask = LVIF_PARAM;
	lvi.iItem = GlobalData.iCurrentModule;

	if (ListView_GetItem(hList,&lvi))
	{
		/* do next file */ 
		GlobalData.CurrentStep = &mooBegin;
	}
	else
	{
		/* no more files */ 
		GlobalData.CurrentStep = &mooDoneAll;
	}
}

void mooDoneAll(HWND hDlg)
{
	_TCHAR message[NLM_PATH_LENGTH];

	/* set proc back to original */ 
	SetWindowLong(hDlg, DWL_DLGPROC, (LONG)&ModListDlgProc);

	ShowWindow(GetDlgItem(hDlg,IDCANCEL),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_DOWNLOAD),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_PROGRESS1),SW_HIDE);
	EnableWindow(GetDlgItem(hDlg,IDC_MODULE_LIST),TRUE);
	EnableWindow(GetDlgItem(hDlg,IDCANCEL),TRUE);

	/* click the nonexistant 'ok' button if all is well */ 
	if (GlobalData.bAnyFail==false)
	{
		PostMessage(hDlg,WM_COMMAND,MAKEWPARAM(IDOK,BN_CLICKED),NULL);
	}
	else
	{
		EnableWindow(GetDlgItem(hDlg,IDC_DOWNLOAD),TRUE);

		LoadString(GlobalData.hInstance,IDS_FAIL_MESSAGE,message,NLM_PATH_LENGTH);
		SetDlgItemText(hDlg,IDC_MESSAGE,message);

		LoadString(GlobalData.hInstance,IDS_FAIL_STATUS,message,NLM_PATH_LENGTH);
		SetDlgItemText(hDlg,IDC_STATUS,message);
	}
}

void DoDownloadStep(HWND hDlg)
{
	/* bad and evil and yucky.  don't look */ 
	static bool bLock = false;
	if (bLock)
	{
		TRACE("got locked WM_ENTERIDLE");
		return;
	}
	bLock = true;
	GlobalData.CurrentStep(hDlg);
	bLock = false;
	PostMessage(hDlg,WM_ENTERIDLE,NULL,NULL);
	/* ok, you can look again now          */ 
}



// DialogProc for the download phase

INT_PTR CALLBACK DownloadDlgProc(
		HWND hwndDlg,  /* handle to dialog box     */ 
		UINT uMsg,     /* message                  */ 
		WPARAM wParam, /* first message parameter  */ 
		LPARAM lParam  /* second message parameter */ 
	)
{
	switch (uMsg)
	{

		case WM_COMMAND:
			if (HIWORD(wParam)==BN_CLICKED) {
				switch (LOWORD(wParam))
				{
				case IDCANCEL:
					EndDialog(hwndDlg,IDCANCEL);
					return TRUE;
				}
			}
			break;

		case WM_CLOSE:
			EndDialog(hwndDlg,IDCANCEL);
			return TRUE;

		case WM_ENTERIDLE:
			/* process the next step */ 
			DoDownloadStep(hwndDlg);
			/* using WM_ENTERIDLE for this turns out to be a bad     */ 
			/* idea because Windows sends them while the multiple    */ 
			/* dll dialog is up, which in turn opens up more of them */ 
			/* this is the reason for the lock in DoDownloadStep     */ 
			return TRUE;
	}
	return FALSE;
}

