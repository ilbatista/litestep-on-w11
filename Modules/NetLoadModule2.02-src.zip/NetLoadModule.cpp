/*
  NetLoadModule LiteStep Module - version 2.02

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// Remember to fix the include paths and link with lsapi.lib

#include "NetLoadModule.h"

#define LS_SUCCESS 0
#define LS_ERROR   1

extern "C" {
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);
}

s_GlobalData GlobalData;



/* actual parsers are in parsers.cpp and lsmod_common.cpp */ 
void FreeSiteProc(void *p);
bool ParseSiteProc(void *p,const _TCHAR *line);
void FreeModuleProc(void *p);
bool ParseModuleProc(void *p,const _TCHAR *line);

inline int ParseSites(void)
{
	return (GlobalData.nSites =
		ParseStarList(CONF_SITE,ParseSiteProc,&GlobalData.pSites,sizeof(s_Site)));
}

inline void FreeSites(void)
{
	FreeStarList(FreeSiteProc,GlobalData.pSites);
}

inline int ParseModules(void)
{
	return
		ParseStarList(CONF_MODULE,ParseModuleProc,&GlobalData.pModules,sizeof(s_Module));
}

inline void FreeModules(void)
{
	FreeStarList(FreeModuleProc,GlobalData.pModules);
}



/*
			LoadModules

	Loop through all the modules, sending a
	LM_RELOADMODULE message to litestep to 
	load each one.
*/
void LoadModules(void)
{
	s_Module *pMod;

	pMod = GlobalData.pModules;
	while (pMod)
	{
		ASSERT(pMod->DllPath!=NULL);

		if (pMod->Exists)
			SendMessage(GlobalData.hLiteStepWnd, LM_RELOADMODULE, (WPARAM)pMod->DllPath, 0);

		pMod = pMod->pNext;
	}
}



/*
		initModuleEx

*/
int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
	TRACE(TITLE);
	START_TRACE;

	/* initialize all global data to zero     */ 
	/* this makes sure all pointers are NULL  */ 
	/* and all bools are false                */ 
	ZeroMemory(&GlobalData,sizeof(s_GlobalData));

	GlobalData.hInstance = dll;
	GlobalData.hLiteStepWnd = GetLitestepWnd();

	/* set up to initialize special controls */ 
	INITCOMMONCONTROLSEX cc; /* woah, common control sex... */ 
	cc.dwSize = sizeof(cc);
	cc.dwICC = ICC_LISTVIEW_CLASSES|ICC_PROGRESS_CLASS;

	_TCHAR buffer[NLM_PATH_LENGTH];

	/* get litestep path                      */ 
	if (!GetRCString(CONF_LITESTEPDIR,buffer,"",NLM_PATH_LENGTH))
	{
		TRACE("GetRCString(LiteStepDir) failed");
		VarExpansion(buffer,PATH_LITESTEPDIR);
	}
	GlobalData.LiteStepPathLen = _tcslen(buffer);
	GlobalData.LiteStepPath = new _TCHAR[GlobalData.LiteStepPathLen+1];
	_tcscpy(GlobalData.LiteStepPath,buffer);

	/* get global alias list                  */ 
	if (!GetRCString(CONF_ALIASFILE,buffer,"",NLM_PATH_LENGTH))
	{
		if (GlobalData.LiteStepPathLen+PATH_ALIASFILE_LEN < NLM_PATH_LENGTH)
		{
			_tcscpy(buffer,GlobalData.LiteStepPath);
			_tcscpy(buffer+GlobalData.LiteStepPathLen,PATH_ALIASFILE);
		}
		else
		{
			/* paths aren't allowed to be this long, */ 
			/* so it will never happen               */ 
			ASSERT(0);
			TRACE("Alias file path overflow.");
		}
	}
	GlobalData.AliasFile = new _TCHAR[_tcslen(buffer)+1];
	_tcscpy(GlobalData.AliasFile,buffer);

	/* read the module path                   */ 
	if (!GetRCString(CONF_MODULEDIR,buffer,"",NLM_PATH_LENGTH))
	{
		if (GlobalData.LiteStepPathLen+PATH_MODULEDIR_LEN < NLM_PATH_LENGTH)
		{
			_tcscpy(buffer,GlobalData.LiteStepPath);
			_tcscpy(buffer+GlobalData.LiteStepPathLen,PATH_MODULEDIR);
		}
		else
		{
			/* paths aren't allowed to be this long, */ 
			/* so it will never happen               */ 
			ASSERT(0);
			TRACE("Module path overflow.");
		}
	}
	if (!*buffer) return LS_ERROR; /* must have a module dir */ 

	GlobalData.ModulePathLen = _tcslen(buffer);
	GlobalData.ModulePath = new _TCHAR[GlobalData.ModulePathLen+1];
	_tcscpy(GlobalData.ModulePath,buffer);
	/* create dir if it's not there  */ 
	CreateDirectory(GlobalData.ModulePath,NULL);

	/* read the documentation path            */ 
	if (!GetRCString(CONF_DOCDIR,buffer,"",NLM_PATH_LENGTH))
	{
		if (GlobalData.ModulePathLen+PATH_DOCDIR_LEN < NLM_PATH_LENGTH)
		{
			_tcscpy(buffer,GlobalData.ModulePath);
			_tcscpy(buffer+GlobalData.ModulePathLen,PATH_DOCDIR);
		}
		else
		{
			/* paths aren't allowed to be this long, */ 
			/* so it will never happen               */ 
			ASSERT(0);
			TRACE("Doc path overflow.");
		}
	}
	/* empty path = don't store documentation */ 
	if (*buffer)
	{
		GlobalData.DocPathLen = _tcslen(buffer);
		GlobalData.DocPath = new _TCHAR[GlobalData.DocPathLen+1];
		_tcscpy(GlobalData.DocPath,buffer);
		/* create dir if it's not there  */ 
		CreateDirectory(GlobalData.DocPath,NULL);
	}

	/* read the path to store zip files       */ 
	if (GetRCString(CONF_ZIPDIR,buffer,"",NLM_PATH_LENGTH)
	/* empty path = don't store zip files     */ 
		&& *buffer)
	{
		GlobalData.ZipPathLen = _tcslen(buffer);
		GlobalData.ZipPath = new _TCHAR[GlobalData.ZipPathLen+1];
		_tcscpy(GlobalData.ZipPath,buffer);
		/* create dir if it's not there  */ 
		CreateDirectory(GlobalData.ZipPath,NULL);
	}


	ParseModules();


	GlobalData.bTestMessage = FALSE!=GetRCBool(CONF_TEST,TRUE);

	if (GlobalData.bAnyFail || GlobalData.bTestMessage)
	{
		ParseSites();

		/* now actually initialize the special controls */ 
		InitCommonControlsEx(&cc);

		/* bring up the "modules not found" dialog box  */ 
		DialogBox(GlobalData.hInstance,MAKEINTRESOURCE(IDD_MODULE_LIST),NULL,ModListDlgProc);
	}

	LoadModules();

/*  Ideally, the module would unload itself at this point.
		Unfortunately, you can't do that from initModuleEx, a
		module can't be unloaded while it is being loaded.

		And we can't set a timer because we don't have any
		windows to recieve the message.
*/
	return LS_SUCCESS;
}



int quitModule(HINSTANCE dll)
{
	/* don't unload the modules,          */ 
	/* litestep takes care of that for us */ 

	FreeSites();
	FreeModules();

	if (GlobalData.LiteStepPath) delete[] GlobalData.LiteStepPath;
	if (GlobalData.AliasFile)    delete[] GlobalData.AliasFile;
	if (GlobalData.DocPath)      delete[] GlobalData.DocPath;
	if (GlobalData.ModulePath)   delete[] GlobalData.ModulePath;
	if (GlobalData.ZipPath)      delete[] GlobalData.ZipPath;

	return LS_SUCCESS;
}

