/*
  NetLoadModule LiteStep Module - version 2.02

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "NetLoadModule.h"
#include "IBindStatusCallback.h"
#include ".\zlib\zlib.h"
#include ".\zlib\contrib\minizip\unzip.h"

//			DownloadModule, ExtractFile, InstallModule




/*

          DownloadModule

*/
bool DownloadModule(s_Module *pMod,_TCHAR *tempfilename,size_t tfnmaxlen)
{
	_TCHAR url[NLM_PATH_LENGTH];
	const _TCHAR *ptr;
	s_Site *pSite;
	int i;

	ASSERT(pMod!=NULL);
	ASSERT(tempfilename!=NULL);

	/* see if it's in the zip directory */ 
	if (GlobalData.ZipPath && 
		(GlobalData.ZipPathLen+pMod->NameLen+ARCHIVE_EXT_LEN)<NLM_PATH_LENGTH)
	{
		WIN32_FILE_ATTRIBUTE_DATA srcdat;
		_tcscpy(url,GlobalData.ZipPath);
		_tcscpy(url+GlobalData.ZipPathLen,pMod->Name);
		_tcscpy(url+GlobalData.ZipPathLen+pMod->NameLen,ARCHIVE_EXT);
		if (GetFileAttributesEx(url,GetFileExInfoStandard,&srcdat)
			&& _tcslen(url)<tfnmaxlen)
		{
			/* use local copy               */ 
			_tcscpy(tempfilename,url);
			TRACE("Found local copy:");
			TRACE(url);
			return true;
		}
	}

	/* try all primary sites in order   */ 
	ptr = pMod->PrimarySite;
	while (GetToken(ptr,url,&ptr,FALSE)==TRUE)
	{
		/* quit if any succeeds                 */ 
		if (URLDownloadToCacheFile(NULL,url,tempfilename,tfnmaxlen,0,&NLMStatusCallback)==S_OK)
		{
			TRACE("Download from primary OK:");
			TRACE(url);
			return true;
		}
		else
		{
			TRACE("Download from primary failed:");
			TRACE(url);
		}
	}

	/* now try each archive site        */ 
	pSite = GlobalData.pNextSite;
	for (i=GlobalData.nSites;i>0;--i)
	{
		/* wrap back around if we reach the end */ 
		if (pSite==NULL) pSite=GlobalData.pSites;

		ASSERT(pSite->Prefix!=NULL);
		ASSERT(pSite->Suffix!=NULL);

		/* skip if it won't fit in the buffer   */ 
		if (pSite->PrefixLen+pMod->NameLen+pSite->SuffixLen < NLM_PATH_LENGTH)
		{
			/* form the address                   */ 
			_tcscpy(url																,pSite->Prefix);
			_tcscpy(url+pSite->PrefixLen							,pMod->Name);
			_tcscpy(url+pSite->PrefixLen+pMod->NameLen,pSite->Suffix);
			/* try it                             */ 
			if (URLDownloadToCacheFile(NULL,url,tempfilename,tfnmaxlen,0,&NLMStatusCallback)==S_OK)
			{
				/* this site worked, next time      */ 
				/* start trying here                */ 
				GlobalData.pNextSite = pSite;
				TRACE("Download from site OK:");
				TRACE(url);
				return true;
			}
			else
			{
				TRACE("Download from site failed:");
				TRACE(url);
			}
		}
		else
		{
			TRACE("Site too long:");
			TRACE(pSite->Prefix);
		}

		pSite = pSite->pNext;
	}

	/* unable to download module        */ 
	return false;
}


#define FILE_MODULE     0
#define FILE_DOC        1
#define FILE_HTML       2
#define FILE_TYPE_COUNT 3



/*
	      ExtractFile
*/
void ExtractFile(unzFile zip,const _TCHAR *file,DWORD size)
{
	void *data = new BYTE[size];
	HANDLE hFile;
	DWORD ignored;
	/* extract it       */ 
	unzOpenCurrentFile(zip);
	unzReadCurrentFile(zip,data,size);
	unzCloseCurrentFile(zip);
	/* write it to disk */ 
	hFile = CreateFile(file,
		GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_ARCHIVE,NULL);
	/* as documented, CREATE_ALWAYS + FILE_ATTRIBUTE_NORMAL fails, but */ 
	/* I have no idea why.  Archive is always set anyway, so use that. */ 
	WriteFile(hFile,data,size,&ignored,NULL);
	CloseHandle(hFile);
	/* free memory      */ 
	delete[] data;
}



/*
	      InstallModule

 pMod -> Module structure
 Archive -> temporary file name

	this doesn't check for buffer overflows as often as other bits
*/
bool InstallModule(HWND hDlg,s_Module *pMod,const _TCHAR *Archive)
{
	_TCHAR filename[NLM_PATH_LENGTH];
	_TCHAR extname[NLM_PATH_LENGTH];
	_TCHAR doc[NLM_PATH_LENGTH];
	_TCHAR *filetype,*nopathname,*nopathname2;
	int Files[FILE_TYPE_COUNT]; bool bHasHTML;
	unzFile zipfile;
	unz_file_info info;

	_TCHAR *dlllist = NULL; /* list of dll files, separated by '|'s */ 
	int dlllistlen=0;
	_TCHAR *temp;

	ZeroMemory(Files,sizeof(Files));
	bHasHTML = false;
	zipfile = unzOpen(Archive);
	if (zipfile==NULL) return false; /* couldn't open downloaded file */ 

/*
			first pass through zip file: count file types
*/
	unzGoToFirstFile(zipfile);
	while (UNZ_OK==unzGetCurrentFileInfo(zipfile,
		&info,filename,NLM_PATH_LENGTH,NULL,0,NULL,0))
	{
		/* check file type */ 
		filetype = _tcsrchr(filename,_T('.'));
		if (filetype)
		{
			if (_tcsicmp(filetype,MODULE_EXT)==0)
			{
				++Files[FILE_MODULE];
				/* add it to the list of dll files */ 
				temp = new _TCHAR[_tcslen(filename)+1+dlllistlen];
				*temp = 0;
				if (dlllist!=NULL)
				{
					CopyMemory(temp,dlllist,dlllistlen);
					delete[] dlllist;
					_tcscat(temp,_T("|"));
				}
				_tcscat(temp,filename);
				dlllistlen += 1+_tcslen(filename);
				dlllist = temp;
			}
			else if (_tcsicmp(filetype,_T(".txt"))==0)
			{
				++Files[FILE_DOC];
			}
			else if (_tcsicmp(filetype,_T(".html"))==0 || _tcsicmp(filetype,_T(".htm"))==0)
			{
				++Files[FILE_DOC];
				bHasHTML = true;
			}
			else if (_tcsicmp(filetype,_T(".gif"))==0 || _tcsicmp(filetype,_T(".jpg"))==0
				|| _tcsicmp(filetype,_T(".png"))==0 || _tcsicmp(filetype,_T(".css"))==0)
			{
				/* file potentially included by html */ 
				/* need to extract all of these,     */ 
				/* but only if there's an html       */ 
				++Files[FILE_HTML];
			}
		}
		/* always remember this bit */ 
		if (unzGoToNextFile(zipfile)==UNZ_END_OF_LIST_OF_FILE) break;
	}

	/* fail if there is no module in this archive */ 
	if (Files[FILE_MODULE]<1)
	{
		const _TCHAR *args[4];
		LoadString(GlobalData.hInstance,IDS_NOMODULES,filename,NLM_PATH_LENGTH);
		args[0] = Archive;
		args[1] = pMod->OrigName;
		if (args[1]==NULL) args[1] = pMod->Name;
		FormatMessage(
			FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_ARGUMENT_ARRAY,
			extname, 0, 0,
			filename, NLM_PATH_LENGTH,
			(va_list *)args);
		/* let the user know             */ 
		MessageBox(NULL,extname,TITLE,MB_OK|MB_ICONERROR);
		unzClose(zipfile);
		return false;
	}

/*
		second pass through zip file: extract documentation
		(so it will be there for the multiple dll dialog)
*/
	if (Files[FILE_DOC]>0 && GlobalData.DocPath!=NULL)
	{

		/* build doc path name           */ 
		_tcscpy(extname,GlobalData.DocPath);
		_tcscpy(extname+GlobalData.DocPathLen,pMod->Name);

		unzGoToFirstFile(zipfile);

		if (Files[FILE_DOC]>1 || (bHasHTML && Files[FILE_HTML]>0))
		{
			/* need to create a folder & extract multiple items */ 
			CreateDirectory(extname,NULL);
			*(extname+GlobalData.DocPathLen+pMod->NameLen) = _T('\\');

			while (UNZ_OK==unzGetCurrentFileInfo(zipfile,
				&info,filename,NLM_PATH_LENGTH,NULL,0,NULL,0))
			{
				/* Collapse path in zip file.        */ 
				/* This may pose a problem if there  */ 
				/* are duplicates, but saves us from */ 
				/* having to worry about creating    */ 
				/* every directory along the way.    */ 
				nopathname = _tcsrchr(filename,_T('\\'));
				nopathname2 = _tcsrchr(filename,_T('/'));
				if (nopathname2>nopathname) nopathname = nopathname2;
				if (nopathname==NULL) nopathname = filename;

				/* check file type                   */ 
				filetype = _tcsrchr(filename,_T('.'));
				if (filetype)
				{
					if (_tcsicmp(filetype,_T(".txt"))==0)
					{
						_tcscpy(extname+GlobalData.DocPathLen+pMod->NameLen+1,nopathname);
						ExtractFile(zipfile,extname,info.uncompressed_size);
					}
					else if (bHasHTML)
					{
						if (_tcsicmp(filetype,_T(".html"))==0 || _tcsicmp(filetype,_T(".htm"))==0)
						{
							_tcscpy(extname+GlobalData.DocPathLen+pMod->NameLen+1,nopathname);
							_tcscpy(doc,extname);
							ExtractFile(zipfile,extname,info.uncompressed_size);
						}
						else if (_tcsicmp(filetype,_T(".gif"))==0 || _tcsicmp(filetype,_T(".jpg"))==0
							|| _tcsicmp(filetype,_T(".png"))==0 || _tcsicmp(filetype,_T(".css"))==0)
						{
							_tcscpy(extname+GlobalData.DocPathLen+pMod->NameLen+1,nopathname);
							ExtractFile(zipfile,extname,info.uncompressed_size);
						}
					}
				}
				if (unzGoToNextFile(zipfile)==UNZ_END_OF_LIST_OF_FILE) break;
			}
			/* now set extname to something appropriate for view docs */ 
			if (bHasHTML) _tcscpy(extname,doc);
		}
		else
		{
			/* extract one item, flat */ 
			while (UNZ_OK==unzGetCurrentFileInfo(zipfile,
				&info,filename,NLM_PATH_LENGTH,NULL,0,NULL,0))
			{
				/* check file type      */ 
				filetype = _tcsrchr(filename,_T('.'));
				if (filetype)
				{
					if (_tcsicmp(filetype,_T(".txt"))==0)
					{
						_tcscpy(extname+GlobalData.DocPathLen+pMod->NameLen,_T(".txt"));
						ExtractFile(zipfile,extname,info.uncompressed_size);
					}
					else if (_tcsicmp(filetype,_T(".html"))==0 || _tcsicmp(filetype,_T(".htm"))==0)
					{
						_tcscpy(extname+GlobalData.DocPathLen+pMod->NameLen,_T(".html"));
						ExtractFile(zipfile,extname,info.uncompressed_size);
					}
				}
				if (unzGoToNextFile(zipfile)==UNZ_END_OF_LIST_OF_FILE) break;
			}
		}
	}

	/* complain if there are multiple DLLs */ 
	s_Archive arc;
	arc.bCreateDllFolder = false;
	if (Files[FILE_MODULE]>1)
	{
		arc.pModule = pMod;
		arc.pName = Archive;
		arc.bHasDocs = Files[FILE_DOC]>0;
		arc.nDlls = Files[FILE_MODULE];
		arc.DllNames = dlllist;
		arc.pDocPath = extname;
		GlobalData.pCurrentArchive = &arc;

		if (IDCANCEL ==
			DialogBox(
				GlobalData.hInstance,
				MAKEINTRESOURCE(IDD_MULTIPLE_DLL),
				hDlg,
				MultiDllDlgProc))
		{
			unzClose(zipfile);
			return false;
		}
	}

/*
			third pass through zip file: extract module
*/

	/* build module path name */ 
	_tcscpy(extname,GlobalData.ModulePath);
	_tcscpy(extname+GlobalData.ModulePathLen,pMod->Name);

	if (arc.bCreateDllFolder)
	{
		CreateDirectory(extname,NULL);
		*(extname+GlobalData.ModulePathLen+pMod->NameLen) = _T('\\');
	}

	unzGoToFirstFile(zipfile);
	while (UNZ_OK==unzGetCurrentFileInfo(zipfile,
		&info,filename,NLM_PATH_LENGTH,NULL,0,NULL,0))
	{
		if (arc.bCreateDllFolder)
		{
			/* Collapse path in zip file.        */ 
			/* This may pose a problem if there  */ 
			/* are duplicates, but saves us from */ 
			/* having to worry about creating    */ 
			/* every directory along the way.    */ 
			nopathname = _tcsrchr(filename,_T('\\'));
			nopathname2 = _tcsrchr(filename,_T('/'));
			if (nopathname2>nopathname) nopathname = nopathname2;
			if (nopathname==NULL) nopathname = filename;

			/* extract it if it's a dll          */ 
			filetype = _tcsrchr(filename,_T('.'));
			if (filetype && _tcsicmp(filetype,MODULE_EXT)==0)
			{
				_tcscpy(extname+GlobalData.ModulePathLen+pMod->NameLen+1,nopathname);
				ExtractFile(zipfile,extname,info.uncompressed_size);
			}
		}
		else
		{
			/* is it the one dll we want? */ 
			if (_tcsicmp(filename,dlllist)==0)
			{
				_tcscpy(extname+GlobalData.ModulePathLen+pMod->NameLen,MODULE_EXT);
				ExtractFile(zipfile,extname,info.uncompressed_size);
			}
		}
		if (unzGoToNextFile(zipfile)==UNZ_END_OF_LIST_OF_FILE) break;
	}

	/* get the path to the one that    */ 
	/* needs loading and set the alias */ 
	if (arc.bCreateDllFolder)
	{
		_tcscpy(extname+GlobalData.ModulePathLen+pMod->NameLen+1,arc.DllNames);
		/* load the right one this time */ 
		if (pMod->DllPath) delete[] pMod->DllPath;
		pMod->DllPath = new _TCHAR[_tcslen(extname)+1];
		_tcscpy(pMod->DllPath,extname);
		/* save to alias list           */ 
		AddAlias(pMod->Name,extname);
	}
	else
	{
		/* if we install it in the right place,  */ 
		/* don't let an alias tell you otherwise */ 
		RemoveAlias(pMod->Name);
	}

	/* save the zip file */ 
	if (GlobalData.ZipPath)
	{
		_tcscpy(extname,GlobalData.ZipPath);
		*(extname+GlobalData.ZipPathLen) = _T('\\');
		_tcscpy(extname+GlobalData.ZipPathLen+1,pMod->Name);
		_tcscpy(extname+GlobalData.ZipPathLen+1+pMod->NameLen,ARCHIVE_EXT);
		CopyFile(Archive,extname,TRUE);
	}

	unzClose(zipfile);
	return true;
}

