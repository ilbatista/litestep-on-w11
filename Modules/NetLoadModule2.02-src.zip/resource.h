//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NetLoadModule2.rc
//
#define IDS_DL_MESSAGE                  1
#define IDS_FAIL_MESSAGE                3
#define IDS_FAIL_STATUS                 4
#define IDS_FILEFILTER                  8
#define IDS_MULTIPLE_DLL                10
#define IDS_NO_DOCS                     11
#define IDS_DOWNLOADING                 20
#define IDS_INSTALLING                  21
#define IDS_NOMODULES                   34
#define IDD_MODULE_LIST                 101
#define IDB_MODULE_STATE                102
#define IDR_CONTEXT_MENUS               103
#define IDD_MULTIPLE_DLL                104
#define IDC_MODULE_LIST                 1000
#define IDS_MODULE                      1000
#define IDS_SITE                        1001
#define IDC_DOWNLOAD                    1002
#define IDC_STATUS                      1003
#define IDC_INSTALL_ALL                 1005
#define IDC_VIEW_DOCS                   1006
#define IDC_TOP_MESSAGE                 1007
#define IDC_FILE_LIST                   1009
#define IDC_MESSAGE                     1010
#define IDS_DLLFILE                     1010
#define IDC_PROGRESS1                   1014
#define ID__DONOTINSTALLTHISMODULENOW   40005
#define ID__SELECTFILE                  40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
