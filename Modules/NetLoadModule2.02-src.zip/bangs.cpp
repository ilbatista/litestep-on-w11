
#include "NetLoadModule.h"

#ifndef TRACE
#define TRACE(n) (void)0
#endif

void BangTest(HWND sender, LPCSTR args);

bangcmddef Bangs[] =
{
	{ "Test",	&BangTest },
	{ NULL, NULL }
};



void RegisterBangs(const char *prefix,int prefixlen,bangcmddef *Bangs)
{
	bangcmddef *pBang;
	char BangString[64];

	TRACE("RegisterBangs");

/*	Bang commands must be 63 chars or fewer.
		I believe this is a restriction in the LS code,
		but I don't wanna look it up right now. */
	strcpy(BangString,prefix);

	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+prefixlen,pBang->Name);
		AddBangCommand(BangString, pBang->Command);
		pBang++;
	}
}

void RemoveBangs(const char *prefix,int prefixlen,bangcmddef *Bangs)
{
	bangcmddef *pBang;
	char BangString[64];

	TRACE("RemoveBangs");

/*	Bang commands must be 63 chars or fewer.
		I believe this is a restriction in the LS code,
		but I don't wanna look it up right now. */
	strcpy(BangString,prefix);

	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+prefixlen,pBang->Name);
		RemoveBangCommand(BangString);
		pBang++;
	}
}



void BangTest(HWND sender, LPCSTR args)
{
}
