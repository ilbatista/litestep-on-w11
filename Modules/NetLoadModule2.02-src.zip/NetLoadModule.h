/*
  NetLoadModule LiteStep Module - version 2.02

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <tchar.h>
#include <windows.h>
#include <urlmon.h>
#include <commctrl.h>
#include "lsapi.h"
#include "lsmod_common.h"
#include "resource.h"

#define MODULE_EXT _T(".dll")
#define MODULE_EXT_LEN 4

#define ARCHIVE_EXT _T(".zip")
#define ARCHIVE_EXT_LEN 4

#define TITLE _T("NetLoadModule v2.02")


#define PATH_LITESTEPDIR			_T("$litestepdir$")
#define PATH_LITESTEPDIR_LEN	(sizeof(PATH_LITESTEPDIR)/sizeof(_TCHAR)-1)
#define PATH_ALIASFILE				_T("modules.ini")
#define PATH_ALIASFILE_LEN		(sizeof(PATH_ALIASFILE)/sizeof(_TCHAR)-1)
#define PATH_MODULEDIR				_T("modules\\")
#define PATH_MODULEDIR_LEN		(sizeof(PATH_MODULEDIR)/sizeof(_TCHAR)-1)
#define PATH_DOCDIR						_T("docs\\")
#define PATH_DOCDIR_LEN				(sizeof(PATH_DOCDIR)/sizeof(_TCHAR)-1)

#define ALIAS_FILE_SECTION		_T("NetLoadModule")

#define CONF_ROOT							_T("NetLoadModule")
#define CONF_ALIASFILE				CONF_ROOT _T("AliasFile")
#define CONF_MODULEDIR				CONF_ROOT _T("Path")
#define CONF_DOCDIR						CONF_ROOT _T("DocPath")
#define CONF_ZIPDIR						CONF_ROOT _T("ZipPath")
#define CONF_TEST							CONF_ROOT _T("TestMessage")
#define CONF_SITE							_T("*") CONF_ROOT _T("Site")
#define CONF_MODULE						_T("*") CONF_ROOT

#define CONF_LITESTEPDIR			_T("LiteStepDir")

#define NLM_PATH_LENGTH 4096


/* assert and return on failure */ 
#ifndef NDEBUG
#define ASSERTR(c,r) if (!c) return r
#else
#define ASSERT(c) (void)0
#define ASSERTR(c,r) (void)0
#endif

//#define DOTRACE

#ifdef DOTRACE
extern DWORD TraceStartTime;
#define START_TRACE TraceStartTime = GetTickCount()
void Trace(const char *line);
#define TRACE_FILE "C:\\NLM.LOG"
#define TRACE(n) Trace(n)
#endif
#ifndef TRACE
#define START_TRACE (void)0
#define TRACE(n) (void)0
#endif

struct s_Module {
	s_Module *pNext;
	_TCHAR *Name; int NameLen;
	_TCHAR *OrigName; /* specified *NetLoadModule name if it has an alias */ 
	_TCHAR *DllPath;
	_TCHAR *PrimarySite;
	_TCHAR *Desc;
	bool Exists;
	bool bDontInstall;
};

struct s_Site {
	s_Site *pNext;
	_TCHAR *Prefix; int PrefixLen;
	_TCHAR *Suffix; int SuffixLen;
};

struct s_Archive {
	const _TCHAR *pName;
	s_Module *pModule;
	bool bHasDocs;
	_TCHAR *pDocPath; /* path to open to view docs */ 
	int nDlls;
	_TCHAR *DllNames;
	bool bCreateDllFolder;
};

/* asking why I'm doing this is forbidden. */ 
struct s_GlobalData {
	HINSTANCE hInstance;
	HWND hLiteStepWnd;

	_TCHAR *ModulePath;   int ModulePathLen;
	_TCHAR *DocPath;      int DocPathLen;
	_TCHAR *ZipPath;      int ZipPathLen;
	_TCHAR *AliasFile;
	_TCHAR *LiteStepPath; int LiteStepPathLen;

	s_Site *pSites,*pNextSite; int nSites;
	s_Module *pModules;

	bool bAnyFail;
	bool bTestMessage;

	_TCHAR CurrentName[NLM_PATH_LENGTH];
	s_Module *pCurrentModule;
	int iCurrentModule;
	s_Archive *pCurrentArchive;
	void (*CurrentStep)(HWND);
	HWND hMainDlg;
};

extern s_GlobalData GlobalData;


INT_PTR CALLBACK ModListDlgProc(
		HWND hwndDlg,  /* handle to dialog box     */ 
		UINT uMsg,     /* message                  */ 
		WPARAM wParam, /* first message parameter  */ 
		LPARAM lParam  /* second message parameter */ 
	);
INT_PTR CALLBACK DownloadDlgProc(
		HWND hwndDlg,  /* handle to dialog box     */ 
		UINT uMsg,     /* message                  */ 
		WPARAM wParam, /* first message parameter  */ 
		LPARAM lParam  /* second message parameter */ 
	);
INT_PTR CALLBACK MultiDllDlgProc(
		HWND hwndDlg,  /* handle to dialog box     */ 
		UINT uMsg,     /* message                  */ 
		WPARAM wParam, /* first message parameter  */ 
		LPARAM lParam  /* second message parameter */ 
	);

bool GetRawModuleName(_TCHAR *buffer,const _TCHAR *name);
bool GetAlias(s_Module *pMod,_TCHAR *buffer,int bufferLen);
bool AddAlias(const _TCHAR *modulename,const _TCHAR *modulepath);
bool RemoveAlias(const _TCHAR *modulename);

bool DownloadModule(s_Module *pMod,_TCHAR *tempfilename,size_t tfnmaxlen);
bool InstallModule(HWND hDlg,s_Module *pMod,const _TCHAR *Archive);
