
#define FILE_MODULE 0
#define FILE_DOC 1
#define FILE_HTML 2
#define FILE_TYPE_COUNT 3

