/*
  NetLoadModule LiteStep Module - version 2.02

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "NetLoadModule.h"

#ifndef TRACE
#define TRACE(n) (void)0
#endif



void FreeSiteProc(void *p)
{
	s_Site *pElem = (s_Site *)p;

	if (pElem->Prefix) delete[] pElem->Prefix;
	if (pElem->Suffix) delete[] pElem->Suffix;
}



bool ParseSiteProc(void *p,const _TCHAR *line)
{
	s_Site *pElem = (s_Site *)p;
	_TCHAR token[NLM_PATH_LENGTH];

	ASSERT(p!=NULL);
	ASSERT(line!=NULL);
	/* should be true by a very large amount */ 
	C_ASSERT(ARCHIVE_EXT_LEN < NLM_PATH_LENGTH);

	/* get prefix                  */ 
	if (GetToken(line,token,&line,FALSE)==FALSE)
		return false;

	pElem->PrefixLen = _tcslen(token);
	pElem->Prefix = new _TCHAR[pElem->PrefixLen+1];
	_tcscpy(pElem->Prefix,token);

	/* get suffix, default to .zip */ 
	if (GetToken(line,token,&line,FALSE)==FALSE)
		_tcscpy(token,ARCHIVE_EXT);

	pElem->SuffixLen = _tcslen(token);
	pElem->Suffix = new _TCHAR[pElem->SuffixLen+1];
	_tcscpy(pElem->Suffix,token);

	return true;
}



void FreeModuleProc(void *p)
{
	s_Module *pElem = (s_Module *)p;

	ASSERT(p!=NULL);

	if (pElem->Name)        delete[] pElem->Name;
	if (pElem->OrigName)    delete[] pElem->OrigName;
	if (pElem->DllPath)     delete[] pElem->DllPath;
	if (pElem->PrimarySite) delete[] pElem->PrimarySite;
	if (pElem->Desc)        delete[] pElem->Desc;
}



bool GetRawModuleName(_TCHAR *buffer,const _TCHAR *name)
{
	_TCHAR *ptr;
	bool fix = false;

	ASSERT(buffer!=NULL);
	ASSERT(name!=NULL);

	VarExpansion(buffer,name);
	/* trim any directiories */ 
	ptr = _tcsrchr(buffer,_T('\\'));
	if (ptr) { _tcscpy(buffer,++ptr); fix = true; }
	ptr = _tcsrchr(buffer,_T('/'));
	if (ptr) { _tcscpy(buffer,++ptr); fix = true; }
	ptr = _tcsrchr(buffer,_T('.'));
	/* clear .dll extensions */ 
	if (ptr && _tcsicmp(ptr,MODULE_EXT)==0)
	{ *ptr = 0; fix = true; }

	return fix;
}



bool ParseModuleProc(void *p,const _TCHAR *line)
{
	s_Module *pElem = (s_Module *)p;
	_TCHAR token[NLM_PATH_LENGTH];
	WIN32_FILE_ATTRIBUTE_DATA srcdat;

	ASSERT(p!=NULL);
	ASSERT(line!=NULL);

	if (GetToken(line,token,&line,FALSE)==FALSE)
		return false;
	/* token = module name                                       */ 
	pElem->NameLen = _tcslen(token);
	pElem->Name = new _TCHAR[pElem->NameLen+1];
	_tcscpy(pElem->Name,token);

	/* Clean up for any path junk they put on that we don't use. */ 
	/* (Save whining from people who don't rtfm!)                */ 
	if (GetRawModuleName(token,pElem->Name))
	{
		pElem->NameLen = _tcslen(token);
		/* may be longer because of VarExpansion  */ 
		delete[] pElem->Name;
		pElem->Name = new _TCHAR[pElem->NameLen+1];
		_tcscpy(pElem->Name,token);
	}

	if (GetToken(line,token,&line,TRUE)!=FALSE && *token)
	{
		/* token = site url(s)                    */ 
		pElem->PrimarySite = new _TCHAR[_tcslen(token)+1];
		_tcscpy(pElem->PrimarySite,token);
	}

	/* use alias as path if there is one                         */  
	/* otherwise, path is ModulePath + name + .dll               */ 
	if (!GetAlias(pElem,token,NLM_PATH_LENGTH))
	{
		if (GlobalData.ModulePathLen+pElem->NameLen+MODULE_EXT_LEN >= NLM_PATH_LENGTH)
		{
			/* Tell the user.  This should NEVER    */ 
			/* happen, but just in case...          */ 
			_TCHAR *ptr = new _TCHAR[pElem->NameLen+sizeof("Module path overflow: ")];
			sprintf(ptr,_T("Module path overflow: %s"),pElem->Name);
			TRACE(ptr);
			delete[] ptr;

			/* would overflow the buffer            */ 
			delete[] pElem->Name;
			if (pElem->PrimarySite) delete[] pElem->PrimarySite;
			return false;
		}

		/* get path to where the module should be */ 
		_tcscpy(token,GlobalData.ModulePath);
		_tcscpy(token+GlobalData.ModulePathLen,pElem->Name);
		_tcscpy(token+GlobalData.ModulePathLen+pElem->NameLen,MODULE_EXT);
	}

	/* save that path          */ 
	pElem->DllPath = new _TCHAR[_tcslen(token)+1];
	_tcscpy(pElem->DllPath,token);

	/* does it exist?          */ 
	if (GetFileAttributesEx(token,GetFileExInfoStandard,&srcdat))
		pElem->Exists = true;
	else
		/* flag for module is already set to      */ 
		/* false (zeroed) in ParseStarList        */ 
		GlobalData.bAnyFail = true;

	/* save description string */ 
	if (line && *line)
	{
		pElem->Desc = new _TCHAR[_tcslen(line)+1];
		_tcscpy(pElem->Desc,line);
	}

	/* parsed successfully     */ 
	return true;
}


