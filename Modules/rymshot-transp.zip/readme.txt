use this if you're having problems with transparent windows
(this version either coincides with rymshot 0.27 or 0.33)
--
module by Lord D. Nattor
http://litestep.waglo.com/modules/rymshot/
--
'readme' by rootrider
http://www.shellfront.org/