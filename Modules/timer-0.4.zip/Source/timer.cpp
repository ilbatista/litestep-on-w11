/*
This is a part of the Timer LiteStep module source code.
Copyright (C) 2001 Erik Christiansson, aka Sci
http://www.alfafish.com/
erik@alfafish.com

Based upon structure of hotkey.dll by LiteStep Development Team
Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "timer.h"

const char rcsRevision[] = "$Revision: 0.3 (Sci)$"; // Our Version
const char rcsId[] = "$Id: timer.cpp,v 0.3 2001/09/09 12:51:00 Sci Exp $"; // The Full RCS ID.
const char szAppName[] = "TimerWindow";

CTimer *timer; // The module

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code = 0;

	AddBangCommand("!TimerStart",		bangStart);
	AddBangCommand("!TimerReset",		bangReset);
	AddBangCommand("!TimerStop",		bangStop);
	AddBangCommand("!TimerKill",		bangKill);
	AddBangCommand("!TimerStartAll",	bangStartAll);
	AddBangCommand("!TimerResetAll",	bangResetAll);
	AddBangCommand("!TimerStopAll",		bangStopAll);
	AddBangCommand("!TimerKillAll",		bangKillAll);
	AddBangCommand("!TimerStartGroup",	bangStartGroup);
	AddBangCommand("!TimerResetGroup",	bangResetGroup);
	AddBangCommand("!TimerStopGroup",	bangStopGroup);
	AddBangCommand("!TimerKillGroup",	bangKillGroup);
	AddBangCommand("!TimerAdd",			bangAdd);
	AddBangCommand("!TimerRemove",		bangRemove);
	AddBangCommand("!TimerRemoveGroup",	bangRemoveGroup);
	AddBangCommand("!TimerRemoveAll",	bangRemoveAll);
	AddBangCommand("!TimerUpdate",		bangUpdate);
	AddBangCommand("!TimerStatus",		bangStatus);

	Window::init(dllInst);
	timer = new CTimer(parentWnd, code);

	return code;
}

void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!TimerStart");
	RemoveBangCommand("!TimerReset");
	RemoveBangCommand("!TimerStop");
	RemoveBangCommand("!TimerKill");
	RemoveBangCommand("!TimerStartAll");
	RemoveBangCommand("!TimerResetAll");
	RemoveBangCommand("!TimerStopAll");
	RemoveBangCommand("!TimerKillAll");
	RemoveBangCommand("!TimerStartGroup");
	RemoveBangCommand("!TimerResetGroup");
	RemoveBangCommand("!TimerStopGroup");
	RemoveBangCommand("!TimerKillGroup");
	RemoveBangCommand("!TimerAdd");
	RemoveBangCommand("!TimerRemove");
	RemoveBangCommand("!TimerRemoveGroup");
	RemoveBangCommand("!TimerRemoveAll");
	RemoveBangCommand("!TimerUpdate");
	RemoveBangCommand("!TimerStatus");

	delete timer;
}

void bangStart(HWND caller, LPCSTR args)		{timer->bangStart(args);		}
void bangReset(HWND caller, LPCSTR args)		{timer->bangReset(args);		}
void bangStop(HWND caller, LPCSTR args)			{timer->bangStop(args);			}
void bangKill(HWND caller, LPCSTR args)			{timer->bangKill(args);			}
void bangStartAll(HWND caller, LPCSTR args)		{timer->bangStartAll();			}
void bangResetAll(HWND caller, LPCSTR args)		{timer->bangResetAll();			}
void bangStopAll(HWND caller, LPCSTR args)		{timer->bangStopAll();			}
void bangKillAll(HWND caller, LPCSTR args)		{timer->bangKillAll();			}
void bangStartGroup(HWND caller, LPCSTR args)	{timer->bangStartGroup(args);	}
void bangResetGroup(HWND caller, LPCSTR args)	{timer->bangResetGroup(args);	}
void bangStopGroup(HWND caller, LPCSTR args)	{timer->bangStopGroup(args);	}
void bangKillGroup(HWND caller, LPCSTR args)	{timer->bangKillGroup(args);	}
void bangAdd(HWND caller, LPCSTR args)			{timer->bangAdd(args);			}
void bangRemove(HWND caller, LPCSTR args)		{timer->bangRemove(args);		}
void bangRemoveGroup(HWND caller, LPCSTR args)	{timer->bangRemoveGroup(args);	}
void bangRemoveAll(HWND caller, LPCSTR args)	{timer->bangRemoveAll();		}
void bangUpdate(HWND caller, LPCSTR args)		{timer->bangUpdate(args);		}
void bangStatus(HWND caller, LPCSTR args)		{timer->bangStatus();			}

CTimer::CTimer(HWND parentWnd, int& code):
Window(szAppName)
{
	if (!createWindow(WS_EX_TOOLWINDOW, "Timer", WS_CHILD, 0, 0, 0, 0, parentWnd))
	{
		MessageBox(NULL, "Error creating window", szAppName, MB_OK);
		code = 1;
		return;
	}
	code = 0;
}

CTimer::~CTimer()
{
	destroyWindow();
}

void CTimer::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onCreate, WM_CREATE)
		MESSAGE(onDestroy, WM_DESTROY)
		MESSAGE(onEndSession, WM_ENDSESSION)
		MESSAGE(onEndSession, WM_QUERYENDSESSION)
		REJECT_MESSAGE(WM_ERASEBKGND)
		REJECT_MESSAGE(WM_PAINT)
		MESSAGE(onGetRevId, LM_GETREVID)
		MESSAGE(onSysCommand, WM_SYSCOMMAND)
		MESSAGE(onTimer, WM_TIMER)
	END_MESSAGEPROC
}

void CTimer::onCreate(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	loadTimers();
}

void CTimer::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	removeTimers();
}

void CTimer::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void CTimer::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
	case 0:
		sprintf(buf, "timer.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
	case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
	default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}

void CTimer::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void CTimer::onTimer(Message& message)
{
	timerItem* pTimer = TimerFromID((long)message.wParam);
	if(pTimer == NULL) return;
	if(pTimer->bRunning == TRUE) KillTimer(hWnd, pTimer->nID);
	pTimer->bRunning = FALSE;
	LSExecute(hWnd, pTimer->szCommand, NULL);
}

void CTimer::bangStart(LPCSTR name)
{
	timerItem* pTimer = TimerFromName(name);
	if(pTimer == NULL) return;
	if(pTimer->bRunning == TRUE) return;
	SetTimer(hWnd, pTimer->nID, pTimer->nTimeout, NULL);
	pTimer->bRunning = TRUE;
}

void CTimer::bangReset(LPCSTR name)
{
	timerItem* pTimer = TimerFromName(name);
	if(pTimer == NULL) return;
	if(pTimer->bRunning == TRUE)
	{
		KillTimer(hWnd, pTimer->nID);
		SetTimer(hWnd, pTimer->nID, pTimer->nTimeout, NULL);
		pTimer->bRunning = TRUE;
	}
}

void CTimer::bangStop(LPCSTR name)
{
	timerItem* pTimer = TimerFromName(name);
	if(pTimer == NULL) return;
	if(pTimer->bRunning == TRUE)
	{
		KillTimer(hWnd, pTimer->nID);
		pTimer->bRunning = FALSE;
		LSExecute(hWnd, pTimer->szCommand, NULL);
	}
}

void CTimer::bangKill(LPCSTR name)
{
	timerItem* pTimer = TimerFromName(name);
	if(pTimer == NULL) return;
	if(pTimer->bRunning == TRUE)
	{
		KillTimer(hWnd, pTimer->nID);
		pTimer->bRunning = FALSE;
	}
}

void CTimer::bangStartAll()
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(pTemp->bRunning == TRUE) continue;
		SetTimer(hWnd, pTemp->nID, pTemp->nTimeout, NULL);
		pTemp->bRunning = TRUE;
		pTemp = pTemp->pNext;
	}
}

void CTimer::bangResetAll()
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(pTemp->bRunning == TRUE)
		{
			KillTimer(hWnd, pTemp->nID);
			SetTimer(hWnd, pTemp->nID, pTemp->nTimeout, NULL);
			pTemp->bRunning = TRUE;
		}
		pTemp = pTemp->pNext;
	}
}

void CTimer::bangStopAll()
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(pTemp->bRunning == TRUE)
		{
			KillTimer(hWnd, pTemp->nID);
			pTemp->bRunning = FALSE;
			LSExecute(hWnd, pTemp->szCommand, NULL);
		}
		pTemp = pTemp->pNext;
	}
}

void CTimer::bangKillAll()
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(pTemp->bRunning == TRUE)
		{
			KillTimer(hWnd, pTemp->nID);
			pTemp->bRunning = FALSE;
		}
		pTemp = pTemp->pNext;
	}
}

void CTimer::bangStartGroup(LPCSTR szName)
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(pTemp->bRunning == TRUE)
			continue;
		else if(strcmpi(pTemp->szGroup, szName) == 0)
		{
			SetTimer(hWnd, pTemp->nID, pTemp->nTimeout, NULL);
			pTemp->bRunning = TRUE;
		}
		pTemp = pTemp->pNext;
	}
}

void CTimer::bangResetGroup(LPCSTR szName)
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if((pTemp->bRunning == TRUE) && (strcmpi(pTemp->szGroup, szName) == 0))
		{
			KillTimer(hWnd, pTemp->nID);
			SetTimer(hWnd, pTemp->nID, pTemp->nTimeout, NULL);
			pTemp->bRunning = TRUE;
		}
		pTemp = pTemp->pNext;
	}
}

void CTimer::bangStopGroup(LPCSTR szName)
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if((pTemp->bRunning == TRUE) && (strcmpi(pTemp->szGroup, szName) == 0))
		{
			KillTimer(hWnd, pTemp->nID);
			pTemp->bRunning = FALSE;
			LSExecute(hWnd, pTemp->szCommand, NULL);
		}
		pTemp = pTemp->pNext;
	}
}

void CTimer::bangKillGroup(LPCSTR szName)
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if((pTemp->bRunning == TRUE) && (strcmpi(pTemp->szGroup, szName) == 0))
		{
			KillTimer(hWnd, pTemp->nID);
			pTemp->bRunning = FALSE;
		}
		pTemp = pTemp->pNext;
	}
}

void CTimer::loadTimers()
{
	FILE *f;
	nTimerCount = 0;
	pTimerList = NULL;
	f = LCOpen (NULL);
	if (f)
	{
		char buffer[4096];
		char token1[4096], token2[4096], token3[4096], token4[4096], extra_text[4096];
		char* tokens[4];

		tokens[0] = token1;
		tokens[1] = token2;
		tokens[2] = token3;
		tokens[3] = token4;

		buffer[0] = 0;
		while (LCReadNextConfig (f, "*Timer", buffer, sizeof (buffer)))
		{
			int count;
			long length = 0;

			token1[0] = token2[0] = token3[0] = token4[0] = extra_text[0] = 0;

			count = LCTokenize (buffer, tokens, 4, extra_text);

			if((token3[0]<'0')||(token3[0]>'9'))
			{
				strcpy(buffer, token3);
				strcpy(token3, token4);
			}
			else
			{
				strcpy(buffer, "");
				strcat(token4, " ");
				strcat(token4, extra_text);
				strcpy(extra_text, token4);
			}

			if(token3[strlen(token3)-1]=='s')
				length=1000;
			else if(token3[strlen(token3)-1]=='m')
				length=60000;
			else if(token3[strlen(token3)-1]=='h')
				length=3600000;
			
			if(length == 0)
				length=1;
			else
				token3[strlen(token3)-1]=0;
			
			length *= atol(token3);

			timerItem* pTemp = new timerItem();
			strcpy(pTemp->szName, token2);
			strcpy(pTemp->szGroup, buffer);
			strcpy(pTemp->szCommand, extra_text);
			pTemp->nTimeout = length;
			pTemp->nID = nTimerCount;
			pTemp->bRunning = FALSE;
			pTemp->pNext = pTimerList;
			pTimerList = pTemp;
			
			nTimerCount++;
		}
		LCClose(f);
	}
}

timerItem* CTimer::TimerFromName(LPCSTR szName)
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(strcmpi(pTemp->szName, szName) == 0) return pTemp;
		pTemp = pTemp->pNext;
	}
	return NULL;
}

timerItem* CTimer::TimerFromID(long nID)
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(pTemp->nID == nID) return pTemp;
		pTemp = pTemp->pNext;
	}
	return NULL;
}

void CTimer::removeTimers()
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(pTemp->bRunning == TRUE) KillTimer(hWnd, pTemp->nID);
		pTemp = pTemp->pNext;
	}
}


void CTimer::bangAdd(LPCSTR szArgs)
{
	char buffer[4096];
	char token1[4096], token2[4096], token3[4096], extra_text[4096];
	char* tokens[3];

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;

	buffer[0] = 0;
	strcpy(buffer, szArgs);

	int count;
	long length = 0;

	token1[0] = token2[0] = token3[0] = extra_text[0] = 0;

	count = LCTokenize (buffer, tokens, 3, extra_text);

	if((token2[0]<'0')||(token2[0]>'9'))
	{
		strcpy(buffer, token2);
		strcpy(token2, token3);
	}
	else
	{
		strcpy(buffer, "");
		strcat(token3, " ");
		strcat(token3, extra_text);
		strcpy(extra_text, token3);
	}

	if(token2[strlen(token2)-1]=='s')
		length=1000;
	else if(token2[strlen(token2)-1]=='m')
		length=60000;
	else if(token2[strlen(token2)-1]=='h')
		length=3600000;
	
	if(length == 0)
		length=1;
	else
		token2[strlen(token2)-1]=0;
	
	length *= atol(token2);

	timerItem* pTemp = new timerItem();
	strcpy(pTemp->szName, token1);
	strcpy(pTemp->szGroup, buffer);
	strcpy(pTemp->szCommand, extra_text);
	pTemp->nTimeout = length;
	pTemp->nID = nTimerCount;
	pTemp->bRunning = FALSE;
	pTemp->pNext = pTimerList;
	pTimerList = pTemp;
	
	nTimerCount++;
}

void CTimer::bangRemove(LPCSTR szName)
{
	timerItem* pPrev = NULL;
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(strcmpi(pTemp->szName, szName) == 0)
		{
			if(pTemp->bRunning == TRUE)
			{
				KillTimer(hWnd, pTemp->nID);
				pTemp->bRunning = FALSE;
			}
			if(pPrev == NULL)
				pTimerList = pTemp->pNext;
			else
				pPrev->pNext = pTemp->pNext;
			delete pTemp;
			break;
		}
		pPrev = pTemp;
		pTemp = pTemp->pNext;
	}
}

void CTimer::bangRemoveGroup(LPCSTR szGroup)
{
	timerItem* pPrev = NULL;
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(strcmpi(pTemp->szGroup, szGroup) == 0)
		{
			if(pTemp->bRunning == TRUE)
			{
				KillTimer(hWnd, pTemp->nID);
				pTemp->bRunning = FALSE;
			}
			if(pPrev == NULL)
				pTimerList = pTemp->pNext;
			else
				pPrev->pNext = pTemp->pNext;
			timerItem* pDel = pTemp;
			pTemp = pTemp->pNext;
			delete pDel;
		}
		else
		{
			pPrev = pTemp;
			pTemp = pTemp->pNext;
		}
	}
}

void CTimer::bangRemoveAll()
{
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		if(pTemp->bRunning == TRUE)
		{
			KillTimer(hWnd, pTemp->nID);
			pTemp->bRunning = FALSE;
		}
		pTimerList = pTemp->pNext;
		delete pTemp;
		pTemp = pTemp->pNext;
	}
}

void CTimer::bangUpdate(LPCSTR szArgs)
{
	char buffer[4096];
	char token1[4096], token2[4096], token3[4096], extra_text[4096];
	char* tokens[3];

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;

	buffer[0] = 0;
	strcpy(buffer, szArgs);

	int count;
	long length = 0;

	token1[0] = token2[0] = token3[0] = extra_text[0] = 0;

	count = LCTokenize (buffer, tokens, 3, extra_text);

	if((token2[0]<'0')||(token2[0]>'9'))
	{
		strcpy(buffer, token2);
		strcpy(token2, token3);
	}
	else
	{
		strcpy(buffer, "");
		strcat(token3, " ");
		strcat(token3, extra_text);
		strcpy(extra_text, token3);
	}

	if(token2[strlen(token2)-1]=='s')
		length=1000;
	else if(token2[strlen(token2)-1]=='m')
		length=60000;
	else if(token2[strlen(token2)-1]=='h')
		length=3600000;
	
	if(length == 0)
		length=1;
	else
		token2[strlen(token2)-1]=0;
	
	length *= atol(token2);

	timerItem* pTemp = TimerFromName(token1);
	if(pTemp)
	{
		strcpy(pTemp->szGroup, buffer);
		strcpy(pTemp->szCommand, extra_text);
		pTemp->nTimeout = length;
		pTemp->nID = nTimerCount;
		pTemp->bRunning = FALSE;
	}
}

void CTimer::bangStatus()
{
	char szMsg[4096] = {0};
	char szTemp[256] = {0};

	strcpy(szMsg, "Timers:\n");
	timerItem* pTemp = pTimerList;
	while(pTemp)
	{
		strcat(szMsg, pTemp->szName);
		strcat(szMsg, " ");
		if(pTemp->szGroup[0])
		{
			strcat(szMsg, pTemp->szGroup);
			strcat(szMsg, " ");
		}
		ltoa(pTemp->nTimeout, szTemp, 10);
		strcat(szMsg, szTemp);
		strcat(szMsg, " ");
		strcat(szMsg, pTemp->szCommand);
		if(pTemp->bRunning) strcat(szMsg, " running");
		strcat(szMsg, "\n");
		pTemp = pTemp->pNext;
	}
	MessageBox(NULL, szMsg, "Timer status", MB_OK | MB_SETFOREGROUND);
}
