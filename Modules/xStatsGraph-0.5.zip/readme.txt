xStatsGraph by thegeek.

----Introduction----

Hi, this is a small graphing module I put together to replace rainmeter.
At the moment it is very basic, but it's under development;P
It uses perfmon counters or xstatsclass to gather data, so you can graph pretty much anything;P
I hope to add more rendering modes later, and I am very open to suggestions/requests:)
Since this module is under heavy development please report any bugs.

----Capabilities----

I use the excellent xpaintclass by andymon, so the graphics for the "background layer" has full support for xpaintclass settings.
The graph itself is rendered ontop of this background, at the moment you can set color and alpha for both the graph "fill" and outer "stroke".
This is a basic example to illustrate a cpu graph:


*xStatsGraph CpuGraph
NetGraphX 40
NetGraphY 30
NetGraphWidth 300
NetGraphHeight 22
NetGraphPaintingMode .singlecolor
;NetGraphImage "horizontalbar_2.png"
NetGraphColors FFFFFF


*CpuGraphSource cpuperf
cpuperfSource perfmon
cpuperfSourceString "\Processor(_Total)\% Processor Time"
cpuperfRefreshRate 200


*CpuGraphSource cpuperf2
cpuperf2RefreshRate 200
cpuperf2Source xstatsclass
cpuperf2SourceString "[cpu]"
;cpuperfDataPoints 1000

*CpuGraphMeter Graph1
Graph1X 0
Graph1Y 0
Graph1Height 17
Graph1Width 90
Graph1RenderMode FillAndStroke
Graph1FillMode LinearGradient
;Graph1FillColor 00ff00
Graph1FillGradientP1Color 0000FF
Graph1FillGradientP1X 0
Graph1FillGradientP1Y 0
Graph1FillGradientP2Color 00FF00
Graph1FillGradientP2X 0
Graph1FillGradientP2Y 15
Graph1StrokeMode Solid
Graph1StrokeColor 000000
Graph1Source cpuperf1
Graph1Scale 100



There are three main sections here:
*xStatsGraph CpuGraph
This is how you define a basic "graph" called "CpuGraph", inside of it you can have different elements, atm the only element avaiable is "Meter".
You can define a meter like this: *CpuGraphMeter Graph1.
Each of these sections have different settings, the xStatsGraph section is basically only xpaintclass settings.



########################################
xStatsGraph settings
########################################
This is a basic xpaintclass background, and you use normal xpaintclass settings here.


########################################
*(xStatsGraph-name)Source settings
########################################

A "source" can have these settings:

RefreshRate
This setting allows you to set the milliseconds between each update, lower bound is 50.
If you use xpaintclass you need to set xStatsCpuStatsUpdateInterval  to the same or lower in order for it to work.

Scale 100
This allows you to set the (vertical) scale of the graph. The data collected is divided by this and then multiplied with the height of the meter.

Source xstatsclass
This setting allows you to choose between xpaintclass and the built-in perfmon code to use for data collection. 
Xpaintclass is a lot easier to use, but perfmon gives you greater freedom and maybe less overhead.

SourceString "[cpu]"
Tis setting is what you use to define the string that either xpaintclass or perfmon uses to gather the data.
For xpaintclass this is pretty easy, and if you are wondering what possibilities you have consult xpaintclass docs.
For perfmon this is a bit harder, if you have trouble formatting this string correctly use the !xStatsGraphShowPerformancePicker bang to get a dialog that allows you to select among all counters. After you have selected the counter you want, click ok and the correct string will be copied to your clipboard.
The default setting is for english windows, if you have another language you will have to change it.

DataPoints 1000
DataPoints allow you to set the number of "points" of collected data that is stored, if you have a very large meter you might have to increase this (default 1000)


########################################
*(xStatsGraph-name)Meter settings
########################################

A "meter" can have these settings:

X 			int
Y 			int
Height 			int
Width 			int
RefreshRate 		int
RenderMode 		FillOnly|StrokeOnly|FillAndStroke
FillMode 		Solid|LinearGradient
FillColor		color
FillAlpha		int(0-255)
FillGradientP1Color 	color
FillGradientP1X		int
FillGradientP2Color 	color
FillGradientP2X 	int
FillGradientP2Y 	int

The P1,P1... are "points" that define how the gradient is painted, you set x,y,color and alpha and the gradient will use these.



----Bangs----
!xStatsGraphCreate 		"name"
!xStatsGraphCreateSource	"name" "sourcename"
!xStatsGraphCreateMeter		"name" "metername"
!xStatsGraphDestroy 		"name"
!xStatsGraphAlwaysOnTop 	"name"
!xStatsGraphHook 		"name"
!xStatsGraphHide 		"name"
!xStatsGraphMove 		"name" 
!xStatsGraphMoveBy 		"name"
!xStatsGraphReposition 		"name"
!xStatsGraphRepositionBy 	"name"
!xStatsGraphResize 		"name"
!xStatsGraphResizeBy 		"name"
!xStatsGraphShow 		"name"
!xStatsGraphToggle 		"name"
!xStatsGraphShowPerformancePicker


----Release History----

--0.5
Massive rework of entire codebase. 
Fixed flickering.
Added support for gradients on both stroke and fill.
Added support for multiple "meters" in each graph.
Added support for multiple "sources" in each graph.

--0.41
Meh, mfc is not worth it.

--0.4
New rendering modes (StrokeOnly, FillOnly and FillAndStroke), different color and alpha settings for stroke and fill.
All rendering is now done through the agg2d abstraction layer for agg (anti-grain geometry), this means it is _much_ easier to code the rendering.

--0.31
Adds support for hookin

--0.3
This release adds support for xpaintclass. 
Also renamed some of the settings for consistency.
Make sure that if you are going to use xpaintclass to set xStatsCpuStatsUpdateInterval to the same as (or lower than) your refreshrate.

--0.2
First public release

--0.1
First alpha.





----Contact----

I am thegeek on efnet and freenode (irc).
You can also reach me by email to okrog@online.no

