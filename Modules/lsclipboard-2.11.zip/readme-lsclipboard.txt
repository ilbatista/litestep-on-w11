////////////////////////////
// Module: LSClipboard 2.1
// Written By: MrJukes
// Released: 8/11/00
//
// Updated:  Jesus_mjjg
// Version:  2.11
// Released: 7th of May 02
//////////////////////////

//////////////////////////
// Usage
//////////////////////////
Any text that is copied to the clipboard should show up in the LSClipboard list.
To get text back into the clipboard, double click on its entry.
To delete text from the list click on it and hit the delete key.
To delete all text from the list use the !CBClear bang command.

//////////////////////////
// New in 2.11
//////////////////////////
CBFile
;the name and path of the ini file where to log the entries
;default: $LitestepDir$lsclipboard.ini

- sometimes, the text shown in the clipboard was ... like no text but anything ... seems fixed
- replaced the localisation of the .ini file from WindowsDir to LitestepDir
- added a vertical (right) scroll bar to the module: easier to search for things
- the list is checked for a similar entry before adding (no need to have more than one time the same entry)
- don't read/write position settings in .ini file, or else what is the point of having that set in step.rc ?

//////////////////////////
// New in 2.1
//////////////////////////
!CBOnTop
!CBNotOnTop
!CBToggleOnTop

- Now displays on all desktops
- Saves contents between recycles

//////////////////////////
// Step.rc
//////////////////////////
LoadModule c:\litestep\lsclipboard.dll
; Uncomment to make LSClipboard always on top
;CBAlwaysOnTop
; This will make LSClipboard start hidden
CBStartHidden
; The x cooridnate
CBX 0
; The y coordinate
CBY 20
; The width
CBWidth 150
; The Height
CBHeight 150
; The height of the top border
CBBorderTop 15
; The width of the right border
CBBorderRight 5
; The height of the bottom border
CBBorderBottom 5
; The width of the left border
CBBorderLeft 5
; The bmp to use for the backgroud of the main window
CBBgBmp lsclipboard.bmp
; The color to use for the background of the list
CBColorListBg 0x00124684
; The color to use for normal text
CBColorListFg 0x00C0C0C0
; The color to use for selected text
CBColorListFgSel 0x00FFFFFF

//////////////////////////
// !Bangs
//////////////////////////
; Shows LSClipboard
!CBShow
; Hides LSClipboard
!CBHide
; Toggles visibility
!CBToggle
; Clears all entries out of the list
!CBClear
//////////////////////////

If you find any bugs or have comments and suggestions, e-mail me at mrjukes@purdue.edu.

Have Fun,
	MrJukes