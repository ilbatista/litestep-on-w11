ClockWork 0.3
by Vendicator (http://pimpin.info/vendicator | vendicator@mail.com)

Analog clock module which should work on desktop/lsbox or in wharf.
Made since I couldn't find a working desktop analog clock module.

Used window&bitmap handling from systray2, clock drawing from aLsClock.
Code is split into several files due to the OOP layout and me wanting
to have modular code snippets.
Note that windows.cpp/.h are the lswinbase from ls (just wanted to have
them included if I wanted to base something else on this)

Note:
You need to use ClockWorkHandType "box" or other transparent compatible
hand type inorder for ClockWork to be visible with completely transparent
backgrounds.


Step.rc Settings:

Size & Placement:
	ClockWorkX
	Int, default: 0
	X placement of the clock window

	ClockWorkY
	Int, default: 0
	Y placement of the clock window

	ClockWorkWidth
	Int, default: 64 (alt. bitmap size)
	Sets width of the clock window

	ClockWorkHeight
	Int, default: 64 (alt. bitmap size)
	Sets height of the clock window


Window & bitmaps:
	ClockWorkHidden
	Bool, default: false
	Set whether to start ClockWork in hidden state

	ClockWorkAlwaysOnTop
	Bool, default: false
	Set whether ClockWork should be placed above all other windows

	ClockWorkBitmap
	String, default: none
	Location of the image to use as bg for ClockWork
	(use a transparent compatible hand when using a completely transparent bg)

	ClockWorkBitmapTiled
	Bool, default: false
	Set whether to tile if on otherwise stretch the image if window size is different from bitmap size

	ClockWorkBorderSize
	Int, default: 0
	Set width of border which isn't stretched/tiled

	ClockWorkBorderTop
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of top border

	ClockWorkBorderLeft
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of left border

	ClockWorkBorderRight
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of right border

	ClockWorkBorderBottom
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of bottom border

	ClockWorkBorderDrag
	Bool, default: false (not activated)
	If specified the user is able to reposition the clock using the mouse

	ClockWorkBGColor
	Color, default: FF00FF
	Background color to use instead of bitmap
	(use a transparent compatible hand when using a completely transparent bg)

	ClockWorkBorderColor
	Color, default: 000000
	Color of border


Clock hands:
	ClockWorkHandType "box" / "line"
	string, default "line"
	Determines the clock hand type that should be used.
	"line" is the standard version, using LineTo()
	(*) "box" is drawn using polygons, because of this the width looks a bit inaccurate sometimes...
	* = transparent compatible, use this if combined with a
	completely transparent region to allow the window region
	to be adapted to include the hands.

	ClockWorkNoSeconds
	BOOL, default: false
	Disable display of the seconds hand

	ClockWorkResolution
	Int, default: 60
	Defines into how many steps the clock is divided (for smoother clocksteps increase this).
	Note that this increases mem usage (8b * Resolution) as well as cpu
	(since you need to update the window more often to see the effect)

	ClockWorkRefresh
	Int, default: 60000 / ClockWorkResolution
	Sets how often the clock should be refreshed, time given in milliseconds.
	With the default ClockWorkResolution=60, the refresh would be once every second.
	Just specifying a different resolution will adapt the refresh to optimum, but
	you have the ability to override the refresh setting if you feel like it.

	ClockWorkDrawOrder ? ? ?
	3 chars, default: h m s
	Determines in what order the hands should be drawn, h=hour, m=minute, s=second
	The hands are drawn above eachother so the last will be on top of the other two.

	ClockWorkHourColor
	Color, default: 0000FF
	Sets color of the hours hand

	ClockWorkMinuteColor
	Color, default: 00FF00
	Sets color of the minutes hand

	ClockWorkSecondColor
	Color, default: FF0000
	Sets color of the seconds hand

	ClockWorkHourWeight
	Int, default: 3
	Sets the width of the hours hand
	  
	ClockWorkMinuteWeight
	Int, default: 2
	Sets the width of the mintes hand

	ClockWorkSecondWeight
	Int, default: 1
	Sets the width of the seconds hand

	ClockWorkHourLength
	Int, default: 70% of the smallest of the window width/height
	Length of the hours hand

	ClockWorkMinuteLength
	Int, default: 90% of the smallest of the window width/height
	Length of the minutes hand

	ClockWorkSecondLength
	Int, default: 90% of the smallest of the window width/height
	Length of the seconds hand


Mouse commands:
	ClockWorkOnLeftDBL
	String, default: !none
	Command to be executed when the user left double clicks the clock

	ClockWorkOnLeftDown
	String, default: !none
	Command to be executed when the user presses the left button on clock

	ClockWorkOnLeftUp
	String, default: !none
	Command to be executed when the user releases the left button on clock

	ClockWorkOnRightDBL
	String, default: !none
	Command to be executed when the user right double clicks the clock

	ClockWorkOnRightDown
	String, default: !none
	Command to be executed when the user presses the right button on clock

	ClockWorkOnRightUp
	String, default: !none
	Command to be executed when the user releases the right button on clock

	ClockWorkOnMiddleDBL
	String, default: !none
	Command to be executed when the user middle double clicks the clock

	ClockWorkOnMiddleDown
	String, default: !none
	Command to be executed when the user presses the middle button on clock

	ClockWorkOnMiddleUp
	String, default: !none
	Command to be executed when the user releases the middle button on clock



Bangs:
	!ClockWorkSetTime
	Brings up the date/time settings from the control panel

	!ClockWorkHook
	Hooks ClockWork to lsbox

	!ClockWorkSetOnTop on/off
	Sets ClockWorks window to be ontop or not, if no argument specified it's turned on.

	!ClockWorkToggleOnTop
	Toggles the on top status

	!ClockWorkShow
	Shows ClockWorks window if hidden

	!ClockWorkHide
	Hides ClockWorks window

	!ClockWorkToggle
	Toggles visible/hidden status of ClockWork

	!ClockWorkMove x y
	Move ClockWork to the given position

	!ClockWorkSize
	Change the size of ClockWork


Changelog:
	Added [Vendicator, 2002-11-12]
	  - Changed the clockface structure to use hand object so different hands
	    can be made and selected.
	  - Added ClockWorkHandType to select which hand type to use
	  - Added clock hand type "box", which is completely transparent compatible

	Added [Vendicator, 2002-11-10]
	  - Ability to specify paint order with ClockWorkDrawOrder x x x

	Added [Vendicator, 2002-11-09]
	  - Initial Release


Todo:
	- percent hand length for stretched clock look
	- More different types of hands? Antialiased lines?
	- Text support? for am,pm/date/time?