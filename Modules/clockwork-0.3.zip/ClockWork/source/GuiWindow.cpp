/*

	Class that encapsulates common gui functions.
	Note that colors&bitmaps aren't included here...

*/

#include "GuiWindow.h"
#include "WinUtils.h"

GuiWindow::GuiWindow(LPCSTR szAppName, HWND parentWnd, bool Wharfed) :
	Window(szAppName),
	nXPos(0),
	nYPos(0),
	nWidth(0),
	nHeight(0),
	bVisible(false),
	bLsBoxed(false),
	bInWharf(Wharfed),
	bOnTop(false),
	hwndParent(parentWnd)
{

}

GuiWindow::~GuiWindow()
{
}

HWND GuiWindow::GetParentHWND(void)
{
	return hwndParent;
}

HWND GuiWindow::GetHWND(void)
{
	return hWnd;
}

void GuiWindow::SetTop(bool ontop)
{
	bOnTop = ontop;
}
bool GuiWindow::IsOnTop(void)
{
	return bOnTop;
}

void GuiWindow::SetVisible(bool visible)
{
	bVisible = visible;
}
bool GuiWindow::IsVisible(void)
{
	return (bool) IsWindowVisible(hWnd);
}

void GuiWindow::SetInWharf(bool wharfed)
{
	bInWharf = wharfed;
}
bool GuiWindow::IsInWharf(void)
{
	return bInWharf;
}

void GuiWindow::SetLsBoxed(bool lsboxed)
{
	bLsBoxed = lsboxed;
}
bool GuiWindow::IsLsBoxed(void)
{
	return bLsBoxed;
}

int GuiWindow::GetX(void)
{
	return nXPos;
}

int GuiWindow::GetY(void)
{
	return nYPos;
}

int GuiWindow::GetWidth(void)
{
	return nWidth;
}

int GuiWindow::GetHeight(void)
{
	return nHeight;
}

void GuiWindow::SetSize(int x_size, int y_size)
{
	nWidth = x_size;
	nHeight = y_size;
}

void GuiWindow::SetPosition(int x_pos, int y_pos)
{
	nXPos = x_pos;
	nYPos = y_pos;
}

void GuiWindow::Size(int x_size, int y_size)
{
	nWidth = x_size;
	nHeight = y_size;
	SetWindowPos(hWnd, NULL, 0, 0, x_size, y_size, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
}

void GuiWindow::Move(int x_pos, int y_pos)
{
	int maxX = 0, maxY = 0;
	// special handling if wharfed/lsboxed?
	/*if (bLsBoxed || bInWharf)
	{
		RECT rc;
		GetClientRect( GetParent(hWnd), &rc );
		maxX = rc.right - rc.left;
		maxY = rc.bottom - rc.top;
	}
	else
	{*/
		maxX = GetSystemMetrics(SM_CXSCREEN);
		maxY = GetSystemMetrics(SM_CYSCREEN);
	//}

	// supports lsbox?
	if (x_pos < 0)
		x_pos += maxX;
	if (y_pos < 0)
		y_pos += maxY;

	// save class variables
	nXPos = x_pos;
	nYPos = y_pos;

#ifdef LOG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "new pos: x:%d,y:%d", x_pos, y_pos);
#endif

	SetWindowPos(hWnd, NULL, x_pos, y_pos, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}

void GuiWindow::Show(void)
{
	bVisible = true;
	ShowWindow(hWnd, SW_SHOWNOACTIVATE);
}

void GuiWindow::Hide(void)
{
	bVisible = false;
	ShowWindow(hWnd, SW_HIDE);
}

void GuiWindow::ToggleVisibility(void)
{
	bVisible = !IsWindowVisible(hWnd);
	if (bVisible)
		ShowWindow(hWnd, SW_HIDE);
	else
		ShowWindow(hWnd, SW_HIDE);
}

void GuiWindow::BoxHook(LPCSTR szArgs)
{

#ifdef LOG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "Attempting to hook to LSBox");
#endif

	char *handle = strrchr(szArgs,' ');
	if (handle) 
	{
		HWND boxwnd = (HWND)atoi(handle+1);
		if (boxwnd) 
		{
			bLsBoxed = true;
			if (boxwnd != GetParent(hWnd))
			{
				SetWindowLong(hWnd, GWL_STYLE, (GetWindowLong(hWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
				SetParent(hWnd, boxwnd);
				hwndParent = boxwnd;
				// set new pos using getrccordinate again with boxwnd size?
			}

#ifdef LOG_EXTRA
			LSLog(LOG_DEBUG, szAppName, "Hooking to LSBox successful");
#endif

		}

#ifdef LOG
		else
		{
			LSLog(LOG_WARNING, szAppName, "Hooking to LSBox failed");
		}
#endif

	}
}

void GuiWindow::SetOnTop(bool fAlwaysOnTop)
{
    if (!bLsBoxed && !bInWharf)
	{
		WinUtils::ModifyStyle(hWnd, WS_POPUP, WS_CHILD);
		SetParent(hWnd, fAlwaysOnTop ? NULL : WinUtils::GetDesktopHWND());
		WinUtils::ModifyStyle(hWnd, WS_CHILD, WS_POPUP);
	}

    SetWindowPos(hWnd, fAlwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
        0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
   
	bOnTop = fAlwaysOnTop;
}

void GuiWindow::ToggleOnTop(void)
{
	bOnTop ? SetOnTop(false) : SetOnTop(true);
}
