#ifndef __CLICKABLE_H
#define __CLICKABLE_H

#include <windows.h>

enum {
	LEFT_DBL,
	LEFT_DOWN,
	LEFT_UP,
	RIGHT_DBL,
	RIGHT_DOWN,
	RIGHT_UP,
	MIDDLE_DBL,
	MIDDLE_DOWN,
	MIDDLE_UP
};

class Clickable
{
public:
	Clickable(LPCSTR prefix);
	~Clickable();

	void ReadClickSettings();
	void BangExecute(const int i);
	virtual HWND GetHWND() = 0;

private:
	const char *Prefix;

	char *OnLeftDBL;
	char *OnLeftDown;
	char *OnLeftUp;
	char *OnRightDBL;
	char *OnRightDown;
	char *OnRightUp;
	char *OnMiddleDBL;
	char *OnMiddleDown;
	char *OnMiddleUp;

};

#endif