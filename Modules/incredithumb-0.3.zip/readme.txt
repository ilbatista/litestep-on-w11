IncrediThumb readme

//===========================================================================
//  Intro
//

IncrediThumb is a simple module I created to test DWM thumbnail features in
litestep. Currently it displays the thumbnail of a single window whose name
is passed in via !IncrediThumbChangeThumb <thumb instance name> <windowname>.

Note: This was supposed to be a simple test module for litestep and could be
abandoned at any time.

//===========================================================================
//  RC Configuration
//

There are some basic settings that can be specified in RC files:

Create a thumbnail using *IncrediThumb <thumb instance name>:
*IncrediThumb thumbOne
*IncrediThumb thumbTwo
*IncrediThumb whatevernameyouwant

Prefix the thumbs settings with the thumbname:

thumbOneX 10
thumbOneY 10

thumbTwoX 60

whatevernameyouwantX 60
whatevernameyouwantAlwaysOnTop true

These are the settings currently supported:

<thumbname>AlwaysOnTop     <true or false> (default = false)
<thumbname>StartHidden     <true or false> (default = true)
<thumbname>X               <screen x position> 
<thumbname>Y               <screen y position>

<thumbname>Width           <any number> (default = 32)
<thumbname>Height          <any number> (default = 32)

    -- Setting the width/height only affects the starting size of the 
       thumbnail window. The window will be resized as soon as a source 
       window is set.


<thumbname>ThumbnailSize   <any number> (default = 128)

    -- Sets the maximum size the thumbnail should be.

    
<thumbname>ThumbnailTransparency  <any number between 0 and 255> (default = 255)

    -- Sets the transparency of the rendered thumbnail.
    
    
<thumbname>SourceWindow   <windowname>

    -- Sets the source window the thumbnail is generated from. If there are 
       multiple windows with the same name it will use the first one it finds. 
       If this value isn't set in the RC or by the bang command, nothing is
       rendered.
       
       
<thumbname>DestinationWindow   <windowname>

    -- Sets the destination window the thumbnail will be rendered to by 
       the window's name. If there are multiple windows with the same name it
       will use the first one it finds. If this value isn't set the thumb
       will be rendered to the module's own window.
       
       
//===========================================================================
//  Bangs
//

All bangs should follow the format !IncrediThumb<bang> <instance name> <value>:

ex: !IncrediThumbChangeThumb thumbOne 'Calculator'

    
    
!IncrediThumbAlwaysOnTop <instance name> <value>

    -- Sets incredithumb to try to stay on top.     


!IncrediThumbChangeThumb <instance name> <sourcename>

    -- Sets the source window for the thumbnail to display. This uses the
       name of the window and will display the FIRST window found with the
       name provided.
       

!IncrediThumbCreate <instance name>

    -- Creates a new thumbnail using default values.
    

!IncrediThumbDestroy <instance name>

    -- Destroys a thumbnail.
    
    
!IncrediThumbHide <instance name>

    -- Hides the module window.
    
!IncrediThumbMoveTo <instance name> <xposition> <yposition>

    -- Moves the module window to the passed position.
    
!IncrediThumbResizeTo <width> <height>

    -- Resizes the module window to the passed size. Useless since the module
       resizes itself anyway.
       
!IncrediThumbShow <instance name>

    -- Shows the module window.
    
!IncrediThumbToggle <instance name>

    -- Toggles the module windows' visiblity to the opposite state that it is
       currently set to.
    
!IncrediThumbToggleAlwaysOnTop <instance name>

    -- Toggles module windows' alwaysOnTop setting to the opposite state that
       it is currently set to.
       
       
//===========================================================================
//  Changes
//

0.1     Initial release.
0.2     Added the ability to set the destination window.
0.3     Added transparency settings.
        Added the ability to have more then one thumb at a time.
        Added the ability to specify the source window in .rc files.
        Added more bangs for creating/manipulating thumbs.
        