This module was formerly a so-called "core module". It is now released
separately.

The documentation for this module is currently being re-written. In the meantime
you can consult the lsdocs (http://lsdocs.shellfront.org - outdated at the time
this was written) and/or the unofficial update by namaide
(http://www.flatface.net/~namaide/lsdocs/) for information on this module.
Note that most but not all former core modules are listed there.

Once the new documentation is done this module zip will be updated. Watch the
LS news sites such as http://www.shellfront.org, http://www.blizzle.com, or
http://www.loose-screws.com for the announcement.


The core modules were compiled using the latest available sourcecode (usually
from the Independent LiteStep CVS). Only minor changes were applied which are
listed below:

* All modules:
- Have version number "2.0" except for sysvwm which is now at 7.0.
- Were compiled with RabidCow's fixed multimon macros, so multimon support was
  improved.


* Popup2:
- Includes Brian Todoroff's focus fixes
- Fixed text offset in auto-resize mode


* Shorcut2:
- Now supports middle click and drag&drop commands. The drag&drop command
  defaults to leftclick (ie. full backwards compatibility).
  
  Old syntax (still supported):
    *Shortcut <CAPTION> <X> <Y> <NORMAL.BMP> <HOVER.BMP> <CLICK.BMP> #<GROUP><FLAGS> <HOVER.WAV> <CLICK.WAV> <ACTION>
  
  New syntax with rightclick, middleclick, drag&drop command; it is necessary
  to put [] brackets around the actions:
    *Shortcut <CAPTION> <X> <Y> <NORMAL.BMP> <HOVER.BMP> <CLICK.BMP> #<GROUP><FLAGS> <HOVER.WAV> <CLICK.WAV> <[leftclick ACTION] [rightclick ACTION] [middleclick ACTION] [drag&drop ACTION]>
  
  Of course any actions that aren't needed can be omitted.


* Systray2:
- In wharf mode the default value of WharfBevelWidth was 0 instead of 1.


* VWM2:
- In wharf mode WharfBevelWidth had no effect.


* Wharf:
- !WharfTasks no longer works and needs to be fixed (it never worked with 0.24.7
  and is now commented out entirely to avoid crashes).