LS Dialer (v0.1) by WhiteShadow (changty@muohio.edu) on 5-11-00
*******************************************************************

This module lets you dial in and disconnect to entries already in
your phonebook (the connections listed in Control Panel->Network
and Dialup Connections).

Installation:

	1. Copy lsdialer.dll into your litestep folder
	2. Add the line 

		LoadModule c:\litestep\lsdialer.dll

	   to your step.rc (with the appropriate drive letter and 
	   path)
	3. Recycle Litestep


Usage:

	Bang Commands
	-------------

	!dialerconnect "Connection name" username password

	   Connection name is what is listed in your phonebook.  The
	   phonebook is what is listed in Control Panel->Network
	   and Dialup Connections or My Computer->Dial Up Networking.
	   It is probably something like "Connection to 5555555" but
	   it may vary on how you have it setup.  Username and 
	   password are your username and password (obviously).

	!dialerhangup

	   This hangs up the connection.


Notes:

	I'll try to add a dialog box that displays the dialing status.  
	Also, currently, !dialerhangup only hangs up the first 
	connection found.  So if you're using two modems at the same
	time, then only one will be disconnected each time you call 
	!dialerhangup (and you can't specify which one).  If someone
	need support for multiple connections, email me and I'll add
	the code to handle that for the next release.


History:

	v0.1 (05-11-00)
	-initial release

Anyway, that's all, enjoy!
Feel free to send me comments or bugs.
WhiteShadow
