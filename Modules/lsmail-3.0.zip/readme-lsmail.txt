////////////////////////
// LSMail 3.0
// By: MrJukes
// Released: 3/24/00
////////////////////////

How to load:
You can load this as a loadmodule or a wharfmodule through the normal methods.

step.rc entries:
LSMailTheme h:\litestep\lsmail.thm
LSMailX 0
LSMailY 0
LSMailTimer 1

Theming:
Do all the graphics theming by editing the lsmail.thm file.
However, when it comes to adding pop3 servers, use the GUI Config in the right-click menu.


Have Fun,
	MrJukes