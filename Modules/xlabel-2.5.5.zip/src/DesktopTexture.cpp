#include "common.h"
#include "DesktopTexture.h"
#include <shellapi.h>
#include <shlobj.h>

// blending raster
// the source image is inverted and the anded with the dest
#define INVERTSRCAND         0x00220326

DesktopTexture::DesktopTexture()
{
	hIcon = 0;

	memoryDC = 0;
	memoryBitmap = 0;
}

DesktopTexture::~DesktopTexture()	// it seems this destructor is never called
{
	if(hIcon)
		DeleteObject(hIcon);

	if(memoryDC)
		DeleteDC(memoryDC);
}

void DesktopTexture::configure(const string &lnkfile, const string &name)
{
	NameValuePair iconTextValues[] = {
	{ "top", 1 },
	{ "bottom", 2 },
	{ "left", 3 },
	{ "right", 4 },
	{ 0, 0 }
	};

	string result;
	string check;
	
	//Remove '"'
	int start = lnkfile.find("\"");
	start = (start < 0) ? 0 : start + 1;

	int end = lnkfile.rfind("\"");
	end = (end < 0) ? lnkfile.length() - 1 : end - 1;

	if (start < end) 
		check = lnkfile.substr(start, end - start + 1);

	//Make Lower
	int length = check.length();
	int i = 0;
	
	while(i < length)
		result.append(1, tolower(check[i++]));

	if (strstr(result.c_str(), ".lnk") != NULL)
		result = GetShortcutTarget(result);

	SHFILEINFO shFileInfo;
    SHGetFileInfo(result.c_str(), NULL, &shFileInfo, sizeof(shFileInfo), SHGFI_ICON);
	hIcon = shFileInfo.hIcon;

	iconSize = GetRCInt("xlabeldesktop" , "IconSize", 32, 16, 64);
	iconTextPosition = GetRCNamedValue("xlabeldesktop", "TextPosition", iconTextValues, 2);
	iconTextSpacing = GetRCInt("xlabeldesktop" , "TextSpacing", 5);
	
	int color;
	char main[32], light[32], dark[32];
	char *buffers[] = {main, light, dark};

	int numTokens = LCTokenize((GetRCLine("xlabeldesktop", "TextBackground", "ff00ff")).c_str(), buffers, 3, NULL);

	if (numTokens == 3)
	{
		color = strtol(light, NULL, 16);
		iconTextBackgroundLight = RGB(GetBValue(color), GetGValue(color), GetRValue(color));

		color = strtol(dark, NULL, 16);
		iconTextBackgroundDark = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
	}
	else
	{
		iconTextBackgroundLight = RGB(255,0,255);
		iconTextBackgroundDark = RGB(255,0,255);
	}
	if(numTokens >= 1)
	{
		color = strtol(main, NULL, 16);
		iconTextBackground = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
	}
	if (numTokens == 2)
	{
		color = strtol(light, NULL, 16);
		iconTextBackgroundLight = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
		iconTextBackgroundDark = iconTextBackgroundLight;
	}


	transparent = true;
	trueTransparency = true;

	_saturation = GetRCInt("xlabeldesktop" , "SaturationIntensity", 255, 0, 255);
	_hueIntensity = GetRCInt("xlabeldesktop" , "HueIntensity", 0, 0, 255);
	_hueColor = GetRCColor("xlabeldesktop", "HueColor", RGB(0, 0, 0));
}

void DesktopTexture::apply(HDC hDC, int x, int y, int width, int height, int imageType)
{
	if(hIcon == NULL)
		return;

	HDC bufferDC = CreateCompatibleDC(hDC);
	HBITMAP bufferBitmap = CreateCompatibleBitmap(hDC, width, height);
	bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
	
	if (memoryBitmap == 0)
	{
		memoryDC = CreateCompatibleDC(hDC);
		memoryBitmap = CreateCompatibleBitmap(hDC, width, height);
		memoryBitmap = (HBITMAP) SelectObject(memoryDC, memoryBitmap);

		HBRUSH hbrush;
		RECT r;
		r.top = 0;
		r.left = 0;
		r.right = width;
		r.bottom = height;
		hbrush = CreateSolidBrush((RGB(254, 0, 254)));
		FillRect(memoryDC, &r, hbrush);

		int xpos, ypos;
		if (iconTextPosition == 1)
		{
			xpos = (width-iconSize)/2;
			ypos = height-iconSize;
			r.top = 0;
			r.left = 0;
			r.right = width;
			r.bottom = height-iconSize-iconTextSpacing;
		}
		else if (iconTextPosition == 2)
		{
			xpos = (width-iconSize)/2;
			ypos = 0;
			r.top = iconSize+iconTextSpacing;
			r.left = 0;
			r.right = width;
			r.bottom = height;
		}
		else if (iconTextPosition == 3)
		{
			xpos = width-iconSize;
			ypos = (height-iconSize)/2;
			r.top = 0;
			r.left = 0;
			r.right = width-iconSize-iconTextSpacing;
			r.bottom = height;
		}
		else if (iconTextPosition == 4)
		{
			xpos = 0;
			ypos = (height-iconSize)/2;
			r.top = 0;
			r.left = iconSize+iconTextSpacing;
			r.right = width;
			r.bottom = height;
		}

		hbrush = CreateSolidBrush(iconTextBackgroundDark);
		FillRect(memoryDC, &r, hbrush);

		r.right = r.right-1;
		r.bottom = r.bottom-1;
		hbrush = CreateSolidBrush(iconTextBackgroundLight);
		FillRect(memoryDC, &r, hbrush);

		r.left = r.left+1;
		r.top = r.top+1;
		hbrush = CreateSolidBrush(iconTextBackground);
		FillRect(memoryDC, &r, hbrush);
	
		DeleteObject(hbrush);

		SetStretchBltMode(memoryDC, STRETCH_DELETESCANS);

		if (hIcon)
		{
			if (_saturation != 255 || _hueIntensity != 0)
			{
				HDC hdcMem = NULL;
				HDC hdcMask = NULL;
				
				HBITMAP hbmMaskOld;

				ICONINFO iconInfo;
							
				// load the icons HBITMAPs (mask & color bitmap)
				GetIconInfo( hIcon, &iconInfo );

				// load the MASK into one dc
				hdcMask = CreateCompatibleDC( memoryDC );
				hbmMaskOld = (HBITMAP) SelectObject( hdcMask, iconInfo.hbmMask );

				// create a dc consist of the new bitmap
				hdcMem = CreateCompatibleDC( memoryDC );

				if ( hdcMem )
				{
					BITMAP bm;					// Get bitmap size
					HBITMAP hbm32;				// the new 32 bit bitmap
					BITMAPINFOHEADER bmInfo;	// bitmapinfoheader for above
					VOID *pbits32;

					// get bitmap size
					GetObject( iconInfo.hbmColor, sizeof(bm), &bm ); 

					// set everything to 0
					memset( &bmInfo, 0, sizeof(BITMAPINFOHEADER) );

					// Create a 32 bits depth bitmap
					bmInfo.biSize = sizeof(BITMAPINFOHEADER);
					bmInfo.biWidth = bm.bmWidth;
					bmInfo.biHeight = bm.bmHeight;
					bmInfo.biPlanes = 1;
					bmInfo.biBitCount = 32;
					bmInfo.biCompression = BI_RGB;
				
					hbm32 = CreateDIBSection( hdcMem,
											  (BITMAPINFO*) &bmInfo,
											  DIB_RGB_COLORS,
											  &pbits32,
											  NULL,
											  0);

					if ( hbm32 )
					{
						// select the new bitmap into memory
						HBITMAP hbmOld32 = (HBITMAP) SelectObject( hdcMem, hbm32 );

						// create a new dc for copying
						HDC hdcSrc = CreateCompatibleDC( memoryDC );

						if ( hdcSrc )
						{
							BITMAP bm32;
							HBITMAP hbmOldSrc;
							BYTE *p32;
							int hy, hx;

							// get the bits from hbm32
							GetObject( hbm32, sizeof(bm32), &bm32 );

							// Get how many bytes per row we have for the bitmap bits (rounded up to 32 bits)
							while ( bm32.bmWidthBytes % 4 )
								bm32.bmWidthBytes++;

							// copy the original bitmap into it's dc
							hbmOldSrc = (HBITMAP) SelectObject( hdcSrc, iconInfo.hbmColor );
							// copy the original bitmaps contents into the new one
							BitBlt(hdcMem, 0, 0, bm.bmWidth, bm.bmHeight, hdcSrc, 0, 0, SRCCOPY);

							// scan each bitmap row from bottom to top (the bitmap is inverted vertically)
							p32 = (BYTE*) bm32.bmBits + (bm32.bmHeight - 1) * bm32.bmWidthBytes;

							for (hy = 0; hy < bm.bmHeight; hy++)
							{
								// go through every pixel from left to right
								for (hx = 0; hx < bm.bmWidth; hx++)
								{
									// *p gets the color value of the pixel,
									// which can be freely modified
									DWORD *p = (DWORD*) p32 + hx;
									BYTE   r = GetRValue( *p );
									BYTE   g = GetGValue( *p );
									BYTE   b = GetBValue( *p );

									// saturnation effect
									if ( _saturation != 255 )
									{
										float fSaturnation = (float)_saturation / (float)255;

										BYTE gray = (BYTE)(r * 0.3086 + g * 0.6094 + b * 0.0820);

										r = (BYTE)( r * fSaturnation + gray * (1 - fSaturnation) );
										g = (BYTE)( g * fSaturnation + gray * (1 - fSaturnation) );
										b = (BYTE)( b * fSaturnation + gray * (1 - fSaturnation) );
									}

									// icon hue effect
									if ( _hueIntensity != 0 )
									{
										float fHueIntensity = (float)_hueIntensity / (float)255;

										// the B & R values of the hue is swapped here, can somebody tell me why it only works that way?
										r = (BYTE)( r * (1 - fHueIntensity) + GetBValue(_hueColor) * fHueIntensity );
										g = (BYTE)( g * (1 - fHueIntensity) + GetGValue(_hueColor) * fHueIntensity );
										b = (BYTE)( b * (1 - fHueIntensity) + GetRValue(_hueColor) * fHueIntensity );

									}

									*p = RGB( r, g, b );

								}

								// Go to next row (remember, the bitmap is inverted vertically)
								p32 -= bm32.bmWidthBytes;
							}

							// Clean up
							SelectObject( hdcSrc, hbmOldSrc );
							DeleteDC( hdcSrc );
							DeleteObject( hbmOldSrc );

							// remove unwanted information from the modified			
							BitBlt( hdcMem,0,0,bm.bmWidth,bm.bmHeight,hdcMask,0,0,INVERTSRCAND );

							// do an "transparency blit onto the destination buffer, using mask as mask and icon as source
							StretchBlt( memoryDC, xpos, ypos, iconSize, iconSize, hdcMask, 0, 0, bm.bmWidth, bm.bmHeight, SRCAND );
							// Combine the foreground with the background
							StretchBlt( memoryDC, xpos, ypos, iconSize, iconSize, hdcMem , 0, 0, bm.bmWidth, bm.bmHeight, SRCPAINT );
						}
						SelectObject( hdcMem, hbmOld32 );
						DeleteObject( hbm32 );
						DeleteObject( hbmOld32 );
					}
					DeleteDC( hdcMem );
				}
				SelectObject( hdcMask, hbmMaskOld );
				DeleteDC( hdcMask );
				DeleteObject( hbmMaskOld );

				DeleteObject( iconInfo.hbmMask  );
				DeleteObject( iconInfo.hbmColor );
			}
			else
				DrawIconEx(memoryDC, xpos, ypos, hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);
		}
	}

	BitBlt( bufferDC, 0, 0, width, height, memoryDC, 0, 0, SRCCOPY );

	TransparentBltLS(hDC, x, y, width, height,
		bufferDC, 0, 0,
		RGB(255, 0, 255));

	DeleteDC(bufferDC);
	DeleteObject(bufferBitmap);
}

bool DesktopTexture::isTransparent() const
{
	return true;
}

string DesktopTexture::GetShortcutTarget(const string LinkFileName)
{
	HRESULT hres;
	
	string Info;
	char szGotPath [MAX_PATH];

	IShellLink* psl;

	//Create the ShellLink object
	hres = CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER,
				IID_IShellLink, (LPVOID*) &psl);
	
	if (SUCCEEDED(hres))
	{
		IPersistFile* ppf;
		//Bind the ShellLink object to the Persistent File
		hres = psl->QueryInterface( IID_IPersistFile, (LPVOID *) &ppf);
		if (SUCCEEDED(hres))
		{
			WORD wsz[MAX_PATH];
			//Get a UNICODE wide string wsz from the Link path
			MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, LinkFileName.c_str(), -1, wsz, MAX_PATH);
			
			//Read the link into the persistent file
			hres = ppf->Load(wsz, 0);
			
			if (SUCCEEDED(hres))
			{
				//Read the target information from the link object
				//UNC paths are supported (SLGP_UNCPRIORITY)
				psl->GetPath(szGotPath, 1024, NULL, SLGP_UNCPRIORITY);
				Info = szGotPath;

				//Read the arguments from the link object
				//psl->GetArguments(szGotPath, 1024);
				//Info = (Info + " " + szGotPath);
			}
		}
	}
	psl->Release();

	//Return the Target (and the Argument) as a string
	return Info;
}

