#if !defined(__VERINFO_H)
#define __VERINFO_H

#define V_AUTHOR "X, modified by Andymon, Seg@"
#define V_NAME "xLabel"
#define V_VERSION "2.5.5"

#endif
