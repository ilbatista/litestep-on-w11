# e:\Perl\ -w
#############################################################################
# lsDrinks 2.1.1                                                              
# Hacked up by : nf0 <nf0@10500bc.org>                                       
#                                                                           
# Thanks to Charlie <ishamael@orodruin.ddns.org> for making asDrinks        
# Thanks to Flip for making flipsthing.
# Thanks to Spawn@desktopz.org for helping out and making suggestions
#                                                                                                                                           
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to:
#   the Free Software Foundation, Inc.
#   59 Temple Place - Suite 330
#   Boston, MA  02111-1307, USA.
###############################################################################

require 5.004;
use strict;
use Socket;

my $rcfile   = "lsdrinks.rc";

my %drinkvals;
my $drinkvals = "$rcfile";
open(DRINKVALS, $drinkvals);

 while (<DRINKVALS>) {
 	chomp;
        next if /^\s*\#/;
        next unless /=/;
        my ($key, $value) = split(/=/, $_, 2);
        $value =~ s/(\$(\w+))/$drinkvals{$2}/g;

        $drinkvals{$key} = $value;
        
            }
close(DRINKVALS);

my $startdir    = $drinkvals{maindir};
my $feedback    = $drinkvals{feedback};
my $folderval   = $drinkvals{folderval};
my $pageval     = $drinkvals{pageval};
my $pagename    = $drinkvals{pagename};
my $slashdir 	= $drinkvals{slashdot_dir};
my $fmdir 	= $drinkvals{freshmeat_dir};
my $segdir 	= $drinkvals{segfault_dir};
my $ltdir 	= $drinkvals{linuxtoday_dir};
my $todir 	= $drinkvals{tintoys_dir};
my $ttdir 	= $drinkvals{technotronic_dir};
my $gndir 	= $drinkvals{geeknews_dir};
my $bitsdir 	= $drinkvals{bits32_dir};
my $bndir 	= $drinkvals{betanews_dir};
my $atdir 	= $drinkvals{arstechnica_dir};
my $fldir 	= $drinkvals{floach_dir};
my $lscdir 	= $drinkvals{litestepcom_dir};
my $lsodir 	= $drinkvals{litesteporg_dir};  
my $bendir 	= $drinkvals{benews_dir};
my $becdir 	= $drinkvals{beoscentral_dir};
my $thodir 	= $drinkvals{themesorg_dir};
my $scdir 	= $drinkvals{solariscentral_dir};
my $lndir 	= $drinkvals{lancednet_dir};
my $lgdir 	= $drinkvals{linuxgames_dir};
my $ladir 	= $drinkvals{linuxapps_dir};
my $hndir 	= $drinkvals{hackernews_dir};
my $hpndir 	= $drinkvals{happypenguinnews_dir};
my $hpudir 	= $drinkvals{happypenguinupdates_dir};
my $hpadir 	= $drinkvals{happypenguinadd_dir};
my $lqdir 	= $drinkvals{linuxquake_dir};
my $agdir  	= $drinkvals{absolutegamers_dir};
my $l3ddir 	= $drinkvals{linux3d_dir};
my $f3ddir 	= $drinkvals{fullon3d_dir};
my $g3ddir  	= $drinkvals{gizmo3d_dir};
my $blndir      = $drinkvals{bluesnews_dir};
my $vedir	= $drinkvals{voodooextreme_dir};
my $cmdir       = $drinkvals{chunkymunky_dir};
my $podir 	= $drinkvals{python_dir};
my @which       = ($drinkvals{slashdot},$drinkvals{freshmeat},$drinkvals{segfault},$drinkvals{linuxtoday},
                   $drinkvals{tintoys},$drinkvals{technotronic},$drinkvals{geeknews},$drinkvals{bits32},
                   $drinkvals{betanews},$drinkvals{arstechnica},$drinkvals{floach},$drinkvals{litestepcom},
                   $drinkvals{litesteporg},$drinkvals{benews},$drinkvals{beoscentral},$drinkvals{themesorg},
                   $drinkvals{solariscentral},$drinkvals{lancednet},$drinkvals{linuxgames},$drinkvals{linuxapps},
                   $drinkvals{hackernews},$drinkvals{happypenguinnews},$drinkvals{happypenguinupdates},
                   $drinkvals{happypenguinadd},$drinkvals{linuxquake},$drinkvals{absolutegamers},
                   $drinkvals{linux3d},$drinkvals{fullon3d},$drinkvals{gizmo3d},
                   $drinkvals{bluesnews},$drinkvals{voodooextreme},$drinkvals{chunkymunky},$drinkvals{python});
my $border	= $drinkvals{border};
my $back	= $drinkvals{back};
my $entryback	= $drinkvals{entryback};
my $bodyback	= $drinkvals{bodyback};
my $bodytext	= $drinkvals{bodytext};
my $bodylink	= $drinkvals{bodylink};
my $bodyvlink	= $drinkvals{bodyvlink};
my $bodyalink   = $drinkvals{bodyalink};
my $limit = $drinkvals{limit};
$limit = $limit - 1;
my ($remote,$file,$backend);
my ($port,$iaddr,$paddr,$proto);
my ($line,$first,$second,$third,$fourth,$fifth,$pattern,$pattern2,$pattern3,$pattern4,$flag);
my ($linecount,$linenumber,$topic,$blocklength,$num,$fromtop,$topicline,$linkline,$dir,$x);





# Get the news.

if ($pageval == 1){
     createpage();
     header();
}

if ($which[0] == 1) {
 if ($feedback == 1) {	
 	print "Getting Slashdot headlines.\n";
 }    
 lsVodka();
}
if ($which[1] == 1) {
 if ($feedback == 1) {	
 	print "Getting Freshmeat headlines.\n";
 } 	
 lsWhiskey();
}
if ($which[2] == 1) {
 if ($feedback == 1) {	
 	print "Getting Segfault news.\n";
 }	
 lsRum();
}
if ($which[3] == 1) {
 if ($feedback == 1) {	
 	print "Getting Linux Today headlines.\n";
 }	
 lsGin();
}
if ($which[4] == 1) {
 if ($feedback == 1) {	
 	print "Getting Tin Toys News.\n";
 }	
 lsHotDamn();
}
if ($which[5] == 1) {
 if ($feedback == 1) {	
 	print "Getting Technotronic News.\n";
 }	
 lsBeer();
}
if ($which[6] == 1) {
 if ($feedback == 1) {	
 	print "Getting Geeknews.\n";
 }	
 lsJolt();
}
if ($which[7] == 1) {
 if ($feedback == 1) {	
 	print "Getting 32bits Online news.\n";
 }	
 lsWine();
}
if ($which[8] == 1) {
 if ($feedback == 1) {
 	print "Getting BetaNews.\n";
 }	
 lsAfterShock();
}
if ($which[9] == 1) {
 if ($feedback == 1) {	
 	print "Getting Ars Technica headlines.\n";
 }
 lsButterScotch();
}
if ($which[10] == 1) {
 if ($feedback == 1) {	
 	print "Getting Floach headlines. \n";
 }	
 lsScotch();
}
if ($which[11] == 1) {
 if ($feedback == 1) {	
 	print "Getting LiteStep.com News. \n";
 }	
 lsBrandy();
}
if ($which[12] == 1) {
 if ($feedback == 1) {
 	print "Getting LiteStep.org News. \n";
 }	
 lsCognac();
}
if ($which[13] == 1) {
 if ($feedback == 1) {	
 	print "Getting BeNews. \n";
 }	
 lsMartini();
}
if ($which[14] == 1) {
 if ($feedback == 1) {	
 	print "Getting BeOS Central News. \n";
 }	
 lsAbsolut();
}
if ($which[15] == 1) {
 if ($feedback == 1) {	
 print "Getting Themes.Org. \n";
 }
 lsMalibu();
}
if ($which[16] == 1) {
 if ($feedback == 1) {	
 print "Getting Solaris Central News. \n";
 }
 lsSouthernComfort ();
}
if ($which[17] == 1) {
 if ($feedback == 1) {	
 print "Getting Lanced.Net. \n";
 }
 lsLN();
}
if ($which[18] == 1) {
 if ($feedback == 1) {
 print "Getting LinuxGames.com News. \n";
 }
 lsLG();
}
if ($which[19] == 1) {
 if ($feedback == 1) {	
 print "Getting LinuxApps.com.  \n";
 }
 lsLA();
}
if ($which[20] == 1) {
 if ($feedback == 1) {	
 print "Getting Hacker News.  \n";
 }
 lsHN();
}
if ($which[21] == 1) {
 if ($feedback == 1) {	
 print "Getting Happy Penguin News. \n";
 }
 lsHPN();
}
if ($which[22] == 1) {
 if ($feedback == 1) {	
 print "Getting Happy Penguin Updates. \n";
 }
 lsHPU();
}
if ($which[23] == 1) {
 if ($feedback == 1) {	
 print "Getting Happy Penguin Additions. \n";
 }
 lsHPA();
} 
if ($which[24] == 1) {
 if ($feedback == 1) {	
 print "Getting Linux Quake News. \n";
 }
 lsLQ();
}
if ($which[25] == 1) {
 if ($feedback == 1) {	 
 print "Gettting Absolute Gamers Files. \n";
 }
 lsAGF();
}
if ($which[26] == 1) {
 if ($feedback == 1) {	
 print "Getting Linux3D News. \n";
 }
 lsL3D();
}
if ($which[27] == 1) {
 if ($feedback == 1) {	
 print "Getting FullON3D News. \n";
 }
 lsF3D();
}
if ($which[28] == 1) {
 if ($feedback == 1) {	
 print "Getting Gizmo 3D News. \n";
 }
 lsG3D();
}
if ($which[29] == 1) {
 if ($feedback == 1) {	
 print "Getting BluesNews. \n";
 }
 lsBLN();
}
if ($which[30] == 1) {
 if ($feedback == 1) {	
 print "Getting VodooExtreme. \n";
 }
 lsVE();
}
if ($which[31] == 1) {
 if ($feedback == 1) {	
 print "Getting ChunkyMunky.com. \n";
 }
 lsCM();
}
if ($which[32] == 1) {
 if ($feedback == 1) {	
 print "Getting Python.org. \n";
 }
 lsPO();
}

if ($pageval == 1){
	footer();
}

#############################################################################
# lsVodka section Slashdot
sub lsVodka {	
    	$remote = "Slashdot.org";
    	$file   = "ultramode.txt";
    	$backend= "backend.slashdot";
    	getbackend();
        $fromtop = 1;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 10;
    	$dir = $slashdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
    	
}
#
#############################################################################


#############################################################################
# lsWhiskey section freshmeat
sub lsWhiskey {
 	$remote = "Freshmeat.net";
    	$file   = "backend/recentnews.txt";
    	$backend= "backend.freshmeat";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $fmdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
    	
}
#
#############################################################################

#############################################################################
# lsGin section LinuxToday
sub lsGin {
	$remote = "linuxtoday.com";
    	$file   = "lthead.txt";
    	$backend= "backend.linuxtoday";
	getbackend();
	$fromtop = 4;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $ltdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
 
}
#
#############################################################################





#############################################################################
# lsRum section Segfault
sub lsRum {
 	$remote = "segfault.org";
    	$file   = "stories.txt HTTP/1.1\nHost: segfault.org:80";
    	$backend= "backend.segfault";
    	getbackend();
    	$fromtop = 19;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 7;
    	$dir = $segdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsHotDamn section Tin_Toys
sub lsHotDamn {
 	$remote = "tinomen.pimpin.net";
    	$file   = "/includes/recentnews.txt";
    	$backend= "backend.tintoys";
    	getbackend();
    	$fromtop = 4;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $todir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}

#
#############################################################################



#############################################################################
# lsBeer section Technotronic
sub lsBeer {
 	$remote = "www.technotronic.com";
    	$file   = "backend/headlines.txt";
    	$backend= "backend.technotronic";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $ttdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# lsJolt section Geeknews
sub lsJolt {
 	$remote = "geeknews.net";
    	$file   = "news/backend.txt";
    	$backend= "backend.geeknews";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 6;
    	$linkline = 7;
    	$blocklength = 7;
    	$dir = $gndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsWine  32BitsOnline
sub lsWine {
 	$remote = "www.32bitsonline.com";
    	$file   = "index.php3";
    	$backend= "backend.32bits";
    	$pattern = "<a href=\"http:\/\/www.32bitsonline.com\/article.php3";
    	$pattern2 = "<br><b><font size=";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $bitsdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# lsAfterShock section betanewsnews
sub lsAfterShock {
 	$remote = "betanews.efront.com";
    	$file   = "backend.php3 HTTP/1.1\nHost: betanews.efront.com:80";
    	$backend= "backend.betanews";
    	getbackend();
    	$fromtop = 7;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $bndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsButterScotch section arsTechnica
sub lsButterScotch {
 	$remote = "arstechnica.com";
    	$file   = "heads.txt";
    	$backend= "backend.ars";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $atdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsScotch Floach
sub lsScotch {
 	$remote = "floach.pimpin.net";
    	$file   = "backend.txt HTTP/1.1\nHost: floach.pimpin.net:80";
    	$backend= "backend.floach";
    	getbackend();
    	$fromtop = 8;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $fldir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################




#############################################################################
# lsBrandy LiteStep.Com
sub lsBrandy {
 	$remote = "www.litestep.com";
    	$file   = "backend.txt";
    	$backend= "backend.lsc";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 6;
    	$linkline = 7;
    	$blocklength = 7;
    	$dir = $lscdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# lsCognac LiteStep.Org
sub lsCognac {
 	$remote = "www.litestep.org";
    	$file   = "index.html HTTP/1.1\nHost: www.litestep.org:80";
    	$backend= "backend.lso";
    	$pattern = "<!--NewsIndex";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $lsodir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# lsMartini BeNews
sub lsMartini {
 	$remote = "www.benews.com";
    	$file   = "/story/headlines/10 HTTP/1.1\nHost: www.benews.com:80\n";
    	$backend= "backend.ben";
    	getbackend();
    	$fromtop = 8;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $bendir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
    	
}
#
#############################################################################


#############################################################################
# lsAbsolut BeOS Central
sub lsAbsolut {
 	$remote = "www.beoscentral.com";
    	$file   = "powerbosc.txt HTTP/1.1\nHost: www.beoscentral.com:80\n";
    	$backend= "backend.bec";
    	getbackend();
    	$fromtop = 9;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $becdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsMalibu Themes.Org
sub lsMalibu {
 	$remote = "www.themes.org";
    	$file   = "news.rdf.phtml HTTP/1.1\nHost: www.themes.org:80";
    	$backend= "backend.tho";
    	getbackend();
    	fixbackend();
    	$fromtop = 17;
    	$topicline = 2;
    	$linkline = 4;
    	$blocklength = 12;
    	$dir = $thodir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsSouthernComfort  Solaris Central
sub lsSouthernComfort {
 	$remote = "www.solariscentral.org";
    	$file   = "news/ultramode.txt HTTP/1.1\nHost: www.solariscentral.org:80";
    	$backend= "backend.sc";
    	getbackend();
    	$fromtop = 16;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $scdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Lanced net
sub lsLN {
 	$remote = "www.lanced.net";
    	$file   = "index.shtml HTTP/1.1\nHost: www.lanced.net:80";
    	$backend= "backend.ln";
    	$pattern = "<p><b><font color=\"silver\">";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $lndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Linux Games
sub lsLG {
 	$remote = "www.linuxgames.com";
    	$file   = "index.shtml HTTP/1.1\nHost: www.linuxgames.com:80";
    	$backend= "backend.lg";
    	$pattern = "<B><A NAME=\"";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $lgdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# lsLA section Linux Apps
sub lsLA {
 	$remote = "www.linuxapps.com";
    	$file   = "backend/detailed.txt HTTP/1.1\nHost: www.linuxapps.com:80";
    	$backend= "backend.la";
    	getbackend();
    	$fromtop = 9;
    	$topicline = 2;
    	$linkline = 8;
    	$blocklength = 9;
    	$dir = $ladir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsHN section Hackernews
sub lsHN {
 	$remote = "www.hackernews.com";
    	$file   = "misc/hnn.xml";
    	$backend= "backend.hn";
    	$pattern = "<item>";
      $pattern2 = "</channel>";
    	$x = 0;
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 3;
    	$linkline = 2;
    	$blocklength = 3;
    	$dir = $hndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Happypenguin Org News
sub lsHPN {
 	$remote = "happypenguin.org";
    	$file   = "html/news.txt HTTP/1.1\nHost: happypenguin.org:80";
    	$backend= "backend.hpn";
    	$pattern = "Content-Type: text/plain";
    	$x = 0;
    	getbackend();
    	fixbackend();
    	$fromtop = 8;
    	$topicline = 2;
    	$linkline = 4;
    	$blocklength = 4;
    	$dir = $hpndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# Happy Penguin Updates
sub lsHPU {
 	$remote = "happypenguin.org";
    	$file   = "html/updates.txt HTTP/1.1\nHost: happypenguin.org:80";
    	$backend= "backend.hpu";
    	getbackend();
    	fixbackend();
    	$fromtop = 36;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $hpudir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# Happy Penguin Adds
sub lsHPA {
 	$remote = "happypenguin.org";
    	$file   = "html/additions.txt HTTP/1.1\nHost: happypenguin.org:80";
    	$backend= "backend.hpa";
    	getbackend();
    	fixbackend();
    	$fromtop = 36;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $hpadir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Linux Quake
sub lsLQ {
 	$remote = "linuxquake.com";
    	$file   = "last20.txt";
    	$backend= "backend.lq";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $lqdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# Absolute Gamers
sub lsAGF {
 	$remote = "files.gameaholic.com";
    	$file   = "agfa.rdf HTTP/1.1\nHost: files.gameaholic.com:80";
    	$backend= "backend.ag";
    	getbackend();
    	fixbackend();
    	$fromtop = 4;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $agdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Linux 3d
sub lsL3D {
 	$remote = "www.linux3d.net";
    	$file   = "index.shtml";
    	$backend= "backend.l3d";
        $pattern = "<font face=\"Arial, Helvetica\" size=\"2\"><a href=\"http:\/\/www.linux3d.net\/index.shtml";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $l3ddir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# Fullon 3d
sub lsF3D {
 	$remote = "www.fullon3d.com";
    	$file   = "index.shtml";
    	$backend= "backend.f3d";
    	$pattern = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/hardware\/";
        $pattern2 = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/games\/";
        $pattern3 = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/opinionated\/";
        $pattern4 = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/general\/";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $f3ddir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub lsG3D {
 	$remote = "www.linux3d.net";
    	$file   = "/gizmo3d/main.shtml";
    	$backend= "backend.g3d";
    	$pattern = "<p><strong><font face=\"Lucida Console\" size=\"3\" color=\"\#";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $g3ddir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub lsBLN {
 	$remote = "www.bluesnews.com";
    	$file = "/cgi-bin/blammo.pl?mode=headlines";
    	$backend= "backend.bln";
    	$pattern = "HREF=\"http:\/\/www.bluesnews.com\/cgi-bin\/blammo.pl?display=";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 3;
    	$linkline = 2;
    	$blocklength = 3;
    	$dir = $blndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub lsVE {
 	$remote = "www.voodooextreme.com";
    	$file   = "/quick_load.mv?1";
    	$backend= "backend.ve";
    	$pattern = "<input type=\"checkbox\" name=\"x";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $vedir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub lsCM {
 	$remote = "www.chunkymunky.com";
    	$file   = "index.shtml";
    	$backend= "backend.cm";
    	$pattern = "<font face=\"Verdana,Arial,Geneva\" size=\"4\"><b>";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $cmdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsPO {
 	$remote = "www.python.org";
    	$file   = "channews.rdf";
    	$backend= "backend.po";
    	getbackend();
    	fixbackend();
    	$fromtop = 6;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $podir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub getbackend{
    $port = 80;
    $iaddr = inet_aton($remote) ||  "no host: $remote"; #return;
    $paddr = sockaddr_in($port, $iaddr);
    $proto = getprotobyname('tcp');
    socket(SOCK, PF_INET, SOCK_STREAM, $proto) ||  "socket: $!"; #return;
    connect(SOCK, $paddr) || "couldn't connect: $remote";#die "connect: $!";
    select(SOCK); $| = 1; select(STDOUT);
    if($remote ne "tinomen.pimpin.net"){
	    print SOCK "GET /$file\n\n";
	  } 
	  else {
	      print SOCK "GET http://$remote$file\n\n";
	  }
	  unlink($backend);
    open(BACKEND,">>$backend");
	   while(<SOCK>){
		       print BACKEND "$_";
	   }
	  close(BACKEND);
	  close(SOCK) || die "close: $!";
  }
#
############################################################################# 

sub fixbackend{
  open(BACKEND,"<$backend") || "Can't open $backend\n"; #return;
       while(<BACKEND>) {  
         $line = $_;
         my $i;
         $i = 0;
         if ("$backend" eq "backend.technotronic"){
             
             $line =~ s/<b>/x&&/;
             $line =~ s/<\/b>/&&/;
             ($first,$second,$third) = split(/&&/ , $line);
             chomp($second);
        
             if ($second ne ""){
                 open(TEMP,">>temp");
                    print TEMP "$second\n";
                    print TEMP "http://$remote\n";
                 close(TEMP);  
             }
         }
         elsif ("$backend" eq "backend.32bits"){
        	if ($line =~ /^$pattern|$pattern2/) {
        	    $flag = 0;
                    $line=~ s/issues/&&/;
                    $line=~ s/\">/&&/g;
                    $line=~ s/<\/a>/&&/;
                    
                    ($first,$second,$third,$fourth,$fifth) = split(/&&/ , $line,5);
                    open(TEMP,">>temp");
                    if ($fifth =~ /<\/font>/){
                    	print TEMP "$fourth\n";
                    	print TEMP "http://$remote/article.php3?file=issues$third\n";
                    	$flag = 1}
                    elsif($fourth=~ /.../ && $flag ne 1){
                         print TEMP "$third\n";
                         print TEMP "http://$remote/article.php3?file=issues$second\n";
                    close(TEMP);
                    }
                    
                 }
                    
         }
         elsif("$backend" eq "backend.lso"){
                if ($line =~ /$pattern/) {
         	    $line =~ s/=\"/&/;
                    $line =~ s/\">/&/;
                    $line =~ s/<\/a>/&/;
                    ($first, $second, $third) = split(/&/,$line);
                    open(TEMP, ">>temp");
         	      chomp($third);
         	      print TEMP "$third\n";
         	      print TEMP "http://$remote/index.html$second\n";
         	    close(TEMP);
                 }
         }        
         elsif("$backend" eq "backend.ln"){
                if ($line =~ /$pattern/) {
                    $line =~ s/<i>/&&/;
                    $line =~ s/<\/i><\/b><br>/ &&/;
                    ($first, $third, $second) = split(/&&/,$line);
                    $second = "";
                    open(TEMP, ">>temp");
         	      print TEMP "$third\n";
         	      print TEMP "http://$remote/index.shtml$second\n";
         	    close(TEMP);
                 }        
         }
         elsif("$backend" eq "backend.lg"){
                if ($line =~ /$pattern/) {
                    $line =~ s/<B><A NAME=\"/xx&&/;
         	    $line =~ s/\"><\/A>/ &&/;
         	    ($first, $second, $third) = split(/&&/,$line);
                    $third = $second;
                    open(TEMP, ">>temp");
         	      print TEMP "$third\n";
         	      print TEMP "http://$remote/index.shtml\n";
         	    close(TEMP);
                 }        
         }
         elsif("$backend" eq "backend.hn"){
               if ($line =~ /^$pattern/)  { 
		                $x = 1;
		               }
                if ($line =~ /^$pattern2/) {
                    $x = 0;
                   }
                if ($x == 1){
                    open(TEMP, ">>temp");
                    $line =~ s/<item>/&&/;
                    $line =~ s/<\/item>//;
                    $line =~ s/<link>//;
                    $line =~ s/<\/link>//;
                    $line =~ s/<title>//;
                    $line =~ s/<\/title>//;
                    if ($line ne "\n"){
                        print TEMP $line;
                       }
                    close(TEMP);
                }
         }
         elsif("$backend" eq "backend.hpn"){
               
               
               if ($line =~ /^$pattern/)  { 
                   $line =~ s/^$pattern//;
		               $x = 1;
		           }
		           if ($x == 1){
                   $line =~ s/\n//;
                   ($first, $second, $third) = split(/~@~#~/,$line);
                    open(TEMP, ">>temp");
                    $first =~ s/\n//;
         	          print TEMP "&&\n$first\n";
         	          print TEMP "$second\n";
         	          print TEMP "http://$remote\n";
         	    }
              close(TEMP);
         }
         elsif(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu") or ("$backend" eq "backend.lq")){
         	($first, $second, $third) = split(/~@~#~/,$line);
                open(TEMP, ">>temp");
         	     print TEMP "$first\n";
         	     print TEMP "$second\n";
         	     print TEMP "$third\n";
         	close(TEMP);
         }
         
         elsif("$backend" eq "backend.ag"){
         	if ($line =~ /<title>|<link>/){
         	    $line =~ s/<link>//gi; $line =~ s/<\/link>//;
		    $line =~ s/<title>//;  $line =~ s/<\/title>//;
		    $line =~ s/\s//;
                    open(TEMP, ">>temp");
         	      print TEMP $line;
         	    close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.l3d"){
         	if ($line =~ /$pattern/){
         	    $line =~ s/$pattern/xx&/;
         	    $line =~ s/\">/&/;
         	    $line =~ s/<\/a>/&/;
                    ($first, $second, $third) = split(/&/,$line);
         	    open(TEMP, ">>temp");
         	      print TEMP "&&\n";
         	      print TEMP "$third\n";
         	      print TEMP "http://$remote/$file$second\n";
         	    close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.f3d"){
         	if ($line =~ /$pattern|$pattern2|$pattern3|$pattern4/) {
                    $line =~ s/href=\"/xx&/;
                    $line =~ s/\">/&/;
                    $line =~ s/<\/a>/&/;
                    ($first, $second, $third) = split(/&/,$line);
                    open(TEMP, ">>temp");
         	      print TEMP "$third\n";
         	      print TEMP "$second\n";
         	    close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.g3d"){
         	if ($line =~ /$pattern/){
         	    $line =~ s/\">/xx&/;
                    $line =~ s/<\/font>/&/;
                    ($first, $second, $third) = split(/&/,$line);
                     chomp($second);
                     open(TEMP, ">>temp");
         	      print TEMP "$second\n";
         	      print TEMP "http://$remote$file\n";
         	     close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.x11"){
         	if ($line =~ /^$pattern/)  {
                     $line =~ s/<strong>\[Messages\]<br>//;
                     $line =~ s/<strong>\[Screenshots\]<br>//;
                     $flag = 1;
                     $line =~ s/\">/xx&/;
                     $line =~ s/<\/font>/&/;
                     $line =~ s/\//_/;
                     $line =~ s/\//_/;
                     $line =~ s/\(//;
                     $line =~ s/\)//;
                     $line =~ s/://;
                     $line =~ s/\s//;
                     ($first, $second, $third) = split(/&/,$line);
                     chomp($second);
                     if ("$second" ne ""){
                         open(TEMP, ">>temp");
         	           print TEMP "$second\n";
         	           print TEMP "http://$remote$file\n";
         	         close(TEMP);
         	     }
                 }  
         }
         elsif("$backend" eq "backend.mdt"){
         	if ($line =~ /$pattern/){
         	    $line =~ s/"><B>/&&/;
                    $line =~ s/<\/B>/&&/;
                    ($first, $third, $second) = split(/&&/,$line,3);
                    chomp($third);
                    if ("$second" ne ""){
                         open(TEMP, ">>temp");
         	           print TEMP "$third\n";
         	           print TEMP "http://$remote/$file\n";
         	         close(TEMP);
         	    }
                 }  
         }
         elsif("$backend" eq "backend.bln"){
          if ($line =~ /<\/strong><\/font><font face=\"Arial, Helvetica\" size=\"1\">/){
           $line =~ s/<\/strong><\/font><font face=\"Arial, Helvetica\" size=\"1/&&/;
           $line =~ s/<A HREF=\"//g;
           $line =~ s/\">/\n/g;
           $line =~ s/<\/A><BR>/\n&&\n/g;
           $line =~ s/<\/font><\/p>//;
           open(TEMP, ">>temp");
             print  TEMP $line;
           close(TEMP);
          }
         	
         }
         elsif("$backend" eq "backend.ve"){
         	if ($line =~ /$pattern/){
         	    $line =~ s/$pattern//;
                    $line =~ s/\"> <a href=\"/&&/;
                    $line =~ s/\" target=\"new\">/&&/;
                    $line =~ s/<\/a>/&&/;
                    ($first, $second, $third, $fourth) = split(/&&/,$line,4);
                    chomp($second);
                    chomp($third);
                    open(TEMP, ">>temp");
                      print  TEMP "&&\n";
                      print  TEMP "$third\n";
                      print  TEMP "http://$remote/$second\n";
         	    close(TEMP);
         	    
                 }  
         }
         elsif("$backend" eq "backend.cm"){
         	if ($line =~ /^$pattern/){
         	    $line =~ s/$pattern/xx&&/;
                    $line =~ s/<\/b>/&&/;
                    ($first, $third, $second) = split(/&&/,$line);
                    chomp($third);
         	    open(TEMP, ">>temp");
         	      print  TEMP "$third\n";
         	      print  TEMP "http://$remote/$file\n";
         	    close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.po"){
         
              if ($line =~ /<link>/){
                  $line =~ s/    <link>//gi; $line =~ s/<\/link>//gi;
                  $second = $line;
              }
              if ($line =~ /<title>/){
                 $line =~ s/    <title>//gi; $line =~ s/<\/title>//gi;
                 $first = $line;
                 chomp $first; chomp $second;
                 open(TEMP, ">>temp");
         	      print  TEMP "&&\n";
         	      print  TEMP "$first\n";
         	      print  TEMP "$second\n";
         	    close(TEMP);
                 }
         }
         elsif("$backend" eq "backend.tho"){
             
             $line =~ s/<title>//gi; $line =~ s/<\/title>//gi;
		          $line =~ s/<link>//gi; $line =~ s/<\/link>//gi;
		          chomp $line;
         	    open(TEMP, ">>temp");
         	      print  TEMP "$line\n";
         	    close(TEMP);
         }              
        }
  close(BACKEND);
  unlink($backend);
  rename("temp",$backend);
  unlink("temp");
}

sub addfolder{
  checkdir();
  
  chdir ("$startdir$dir");
  unlink <*.htm>;
  chdir ("$startdir");
  $linecount = 0;
  $linenumber = 0;
  my $topiccount = 0;
  open(BACKEND,"<$backend") || "Can't open $backend\n"; #return;
       while(<BACKEND>) {  
             ++$linecount;
             if($linecount>$fromtop){
		           ++$linenumber;
	           }
	           if($linenumber == $topicline){
	             ++$topiccount;
	     	       if( ("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu")){
		  		     }
		           else{
		             chop;
		           }
		
		           $topic="$_";$topic=~ s/\"|:|>|<|\/|\|*|\?|\||\=//gi;$topic=~ s/\+/plus/gi;$topic=~ s/\s//;
		           if("$backend" eq "backend.ag"){
		           }
	             else{
	               $topic=~ s/$topic/$topic /;
	             }
	           }  
	     	     elsif($linenumber == $linkline && $topic ne "" && $topiccount <= $limit){
		           chop;
		           open(NUMFILE, ">$dir/$topic.htm");
		             print  NUMFILE "<meta HTTP-Equiv=\"REFRESH\" Content=\"0;url=$_\">";
		           close(NUMFILE);
		         }  
	           if($linenumber == $blocklength) {
	             $linenumber=0;
	           }
       }
  close(BACKEND);
}

#############################################################################
# Checkdir

sub checkdir {

 if (-e $dir) {
  return;
 }
 die "Error: no $dir";
}

#############################################################################

sub createpage {
    open(FILE,">$pagename.htm");
}

sub header{
print FILE <<HEADER;
<html>

<head>
<title>$pagename</title>
<base TARGET="_self">
</head>
<body BGCOLOR="#$back" TEXT="#$bodytext" LINK="#$bodylink" 
LEFTMARGIN="0" VLINK="#$bodyvlink" ALINK="#$bodyalink">

<table BORDER="0" WIDTH="100%">
  <tr>
    <td WIDTH="8%"></td>
    <td WIDTH="83%">
HEADER
}



sub footer{
print FILE <<FOOTER;

    </td>
    <td WIDTH="9%"></td>
  </tr>
</table>

<p>&nbsp;</p>
</body>
</html>


FOOTER
}



sub tabletitle{
print FILE <<TITLE;
   <div align="center">
            <center>
               <table BORDER="1" WIDTH="536"
                      BORDERCOLOR="#$border" CELLSPACING="0" BORDERCOLORLIGHT="#$border" BORDERCOLORDARK="#$border"
                      BGCOLOR="#$entryback">
                      <tr>
                         <td WIDTH="100%">
                            
                              <big>
                                 <strong>$remote
                                 </strong>
                             </big>
                         </td>
                      </tr>
               </table>
            </center>
        </div>

TITLE

}

sub tablerow{
print FILE<<TROWT;
<div align="center">
             <center>
                <table BORDER="1" WIDTH="536"
                       BGCOLOR="#$bodyback" BORDERCOLOR="#$border" CELLSPACING="0" BORDERCOLORLIGHT="#$border" BORDERCOLORDARK="#$border">
                       <tr>
                          <td>
                            
TROWT

  $linecount = 0;
  $num = 0;
  $linenumber = 0;
  
  my $topiccount = 0;
  open(BACKEND,"<$backend") || print "Can't open $backend\n"; 
       while(<BACKEND>) {  
             ++$linecount;
             ++$num;
	     if($linecount>$fromtop){
		      ++$linenumber;
	       }
	     if($linenumber == $topicline){
	     	++$topiccount;
	     	if(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu")){
        }
		   else{
		        chop;
		   }
		$topic="$_";$topic=~ s/:|>|<|\/|\|*|\?|\||\=//gi;$topic=~ s/\+/plus/gi;$topic=~ s/\s//;
		if("$backend" eq "backend.ag"){
		}
	        else{
	          $topic=~ s/$topic/$topic /;
	        }
	     }
	     
	     elsif($linenumber == $linkline && $topic ne "" && $topiccount <= $limit){
		   chop;
		   print  FILE "<li><A href='$_'>$topic</a></li>\n";
		   
             }  
	     if($linenumber == $blocklength){
	        $linenumber=0;
	     }
       
       }
  close(BACKEND);




print FILE <<TROWB;  
                        </td>
                      </tr>
               </table>
             </center>
       </div><p>&nbsp;

TROWB
}