/****************************************************************************
* LSHideExplorer                                                            *
* Brian Hartvigsen                                                          *
* (c) 2002 Brian Hartvigsen (tresni@coreshell.info)                         *
*                                                                           *
* This module does nothing more then hide the appearance of Explorer while  *
* Litestep is running and the module is loaded..                            *
*                                                                           *
* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- *
* To Use:                                                                   *
*  LoadModule $ModulesDir$LSHideExplorer.exe                                *
*                                                                           *
* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- *
* Change Log:                                                               *
*                                                                           *
* 0.1 (28 JUNE 2002)                                                        *
*  -Initial Release (BAH)                                                   *
****************************************************************************/
