/*
  jDesk LiteStep Module - version 0.71

	Copyright (C) 1999 Chris Rempel
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __JDESK_H
#define __JDESK_H

#define WM_MOUSEWHEEL 0x020A
#define WM_XBUTTONDOWN 0x020B
#define WM_XBUTTONUP 0x020C
#define WM_XBUTTONDBLCLK 0x020D

#define MK_XBUTTON1 0x0020
#define MK_XBUTTON2 0x0040
#define XBUTTON1 0x0001
#define XBUTTON2 0x0002

const int MAXLEN = 256;

struct jDeskSettings
{
	BOOL DisableDoubleClick, DisableMButton1, DisableMButton2, DisableMButton3, DisableMButtonX1, DisableMButtonX2, DisableMWheelScroll;
	BOOL ClearWorkAreaOnExit, RecycleOnRezChange, WorkArea;
	UINT DoubleClickTime;
	char DesktopFolder[MAX_PATH];
};

struct MDataList
{
	char *modKey;
	char *actionDown;
	char *actionUp;
	char *actionDblClk;
};

struct MBClickVal
{
	WPARAM wp;
	char dblclk;
};

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModuleEx( HWND, HINSTANCE, LPCSTR );
__declspec( dllexport ) void quitModule( HINSTANCE );

#ifdef __cplusplus
}
#endif

#endif
