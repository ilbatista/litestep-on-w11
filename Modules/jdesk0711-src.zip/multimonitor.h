/*
  jDesk LiteStep Module - version 0.71
	Core MultiMonitor Section

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/* I recommend against using this structure directly,
   mainly because GetMonitor may return LSMONITOR_NONE
	 or LSMONITOR_ALL rather than a valid pointer to this,
	 but also because someone may decide to change it at
	 some point, and it's so  much happier if all the code
	 that relies on it is in one place.
*/
typedef struct lsMonitorData {
	char *Name;
	HMONITOR Handle;
	MONITORINFO mInfo;
	int Number;
} const *LSMONITOR;

#define LSMONITOR_NONE (LSMONITOR)0
#define LSMONITOR_ALL (LSMONITOR)-1

void LSInitMultiMon(void); /* load monitor info */ 
void LSQuitMultiMon(void); /* free monitor info */ 

LSMONITOR LSGetMonitor(const char *name);            /* convert string name to LSMONITOR */ 
bool LSGetMonitorScreenRect(LSMONITOR mon,LPRECT r); /* get rect for whole screen        */ 
bool LSGetMonitorDeskRect(LSMONITOR mon,LPRECT r);   /* get rect for desktop area        */ 
HMONITOR LSGetMonitorHandle(LSMONITOR mon);          /* get windows' handle              */ 

typedef bool MonitorProc(LSMONITOR,LPARAM);      /* return true to keep going */ 
LSMONITOR LSForEachMonitor(MonitorProc*,LPARAM); /* run code for each monitor */ 
