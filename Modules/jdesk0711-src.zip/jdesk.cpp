/*
  jDesk LiteStep Module - version 0.71

	Copyright (C) 1999 Chris Rempel
  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <windows.h>
#include "jdesk.h"
#include "multimonitor.h"

#ifdef DARKSTEP
	#include "../../dssdk/dsapi.h"
#else
	#include "lsapi.h"
#endif

#define SHELL_GETREVID 9265  /* LM_GETREVID  or  DM_GETREVID */ 
#define SHELL_REGISTERMESSAGE 9263 /* LM_REGISTERMESSAGE  or  DM_REGISTERMESSAGE */ 
#define SHELL_UNREGISTERMESSAGE 9264 /* LM_UNREGISTERMESSAGE  or  DM_UNREGISTERMESSAGE */ 
#define SHELL_MAGICNUMBER 0x49474541

const char buildName[] = TEXT("jdesk.dll"); // Build (module) Name
const char buildRev[] = TEXT("0.711"); // Build Version
const char buildDate[] = TEXT("2002.05.22"); // Build Date
const char buildAuthor[] = TEXT("rabidcow"); // Who Modified

#ifdef DARKSTEP
	char rcPath[MAX_PATH];
#endif

#ifdef DARKSTEP
	#define RegBang AddBang
	#define UnRegBang DelBang
	//#define ExecuteBang BangExec
	#define ExecuteValue CmdExec
	#define ExecValParams NULL, NULL
	#define jIniSec TEXT("jDesk")
#else
	#define RegBang AddBangCommand
	#define UnRegBang RemoveBangCommand
	//#define ExecuteBang ParseBangCommand
	#define ExecuteValue LSExecute
	#define ExecValParams 0
#endif

const char szAppName[] = TEXT("");
const char szAppClass[] = TEXT("DesktopBackgroundClass");

HWND hMainWnd; // main window handle (desktop)
HWND hParentWnd; // Shell window handle

jDeskSettings jds;

MBClickVal mb1;
MBClickVal mb2;
MBClickVal mb3;
MBClickVal mbx;

HINSTANCE dll;
BOOL bIsFirst;

RECT rScreen, rWorkArea, rbkWA;

int numMB1Events, numMB2Events, numMB3Events, numMBX1Events, numMBX2Events, numMWSEvents;

MDataList* MB1Data = NULL;
MDataList* MB2Data = NULL;
MDataList* MB3Data = NULL;
MDataList* MBX1Data = NULL;
MDataList* MBX2Data = NULL;
MDataList* MWSData = NULL;

LRESULT CALLBACK WndProc( HWND, UINT, WPARAM, LPARAM);
void ProcessClicks( UINT, WPARAM );
void SetWorkArea( void );
void ClearWorkArea( void );
void JDeskSetWorkArea( HWND, const char* );
void JDeskResetWorkArea( HWND, const char* );

BOOL StripWS( char* );

MDataList* LoadItems(LPCSTR command, int* numMBEvents)
{
	MDataList* MBData = NULL;

	int i;
	BOOL skipThis;
	char** tokens;
	char* bufPtr;

	#ifdef DARKSTEP
		LONG ptr = 0;
		char* buffer;
	#else
		FILE* f;
		char buffer[4096];
	#endif

	if (command == NULL || numMBEvents == NULL)
		return MBData;

	#ifndef DARKSTEP
		f = LCOpen(NULL);
		if (!f) return MBData;
	#endif

	*numMBEvents = 0;
	tokens = (char**)malloc(sizeof(char*)*4);

	#ifdef DARKSTEP
		while (buffer = RCReadValue(rcPath, jIniSec, command, &ptr))
	#else
		while (LCReadNextConfig(f, command, buffer, sizeof(buffer)))
	#endif
	{
		skipThis = FALSE;
		bufPtr = NULL;

		if (strchr(buffer, TEXT('[')) && strrchr(buffer, TEXT(']'))){
			char *ptr1;
			bufPtr = strchr(buffer, TEXT('['));
			ptr1 = strrchr(buffer, TEXT(']'));
			if (bufPtr > ptr1)
				continue;
			*bufPtr = 0;
			*ptr1 = 0;
			if (!StripWS(++bufPtr))
				continue;
		}else
			continue;

		tokens[0] = strtok(bufPtr, TEXT(";"));
			if (tokens[0] == NULL) continue; // need all those parameters!
		tokens[1] = strtok(NULL, TEXT(";"));
			if (tokens[1] == NULL) continue; // need all those parameters!
		tokens[2] = strtok(NULL, TEXT(";"));
			if (tokens[2] == NULL) continue; // need all those parameters!
		tokens[3] = strtok(NULL, TEXT(";"));
			if (tokens[3] == NULL) 
				tokens[3] = tokens[2];	//Allow same action to be taken on DblClick and ButtonUp action.

		for (i=0;i<4;i++)
			if (!StripWS(tokens[i]))
				skipThis = TRUE; // can't use 'continue' here, as it'd just do the next interation of the for loop.
		if (skipThis) continue;

		if (!(*tokens[0] && *tokens[1] && *tokens[2] && *tokens[3])) continue; // they won't be NULL at this point

		for (i=0;i<*numMBEvents;i++)// check to see if mod key already exists, if so ignore this full *jDeskxxx line.
			if (!_stricmp(MBData[i].modKey, tokens[0]))
				skipThis = TRUE; // can't used 'continue' here, as it'd just do the next interation of the for loop.
		if (skipThis) continue;

		{// only want 'tmpMBData' to be on the stack inside here.
			MDataList* tmpMBData = NULL;
			if (!MBData)
				MBData = (MDataList *)malloc(sizeof(MDataList));
			else{
				tmpMBData = MBData;
				MBData = (MDataList *)realloc(MBData, (*numMBEvents+1)*sizeof(MDataList));
			}
			if (MBData == NULL){
				MBData = tmpMBData;
				tmpMBData = NULL;
				continue;
			}
		}
		MBData[*numMBEvents].modKey = new char[strlen(tokens[0])+1];
			strcpy(MBData[*numMBEvents].modKey, tokens[0]);

		MBData[*numMBEvents].actionDown = new char[strlen(tokens[1])+1];
			strcpy(MBData[*numMBEvents].actionDown, tokens[1]);

		MBData[*numMBEvents].actionUp = new char[strlen(tokens[2])+1];
			strcpy(MBData[*numMBEvents].actionUp, tokens[2]);

		MBData[*numMBEvents].actionDblClk = new char[strlen(tokens[3])+1];
			strcpy(MBData[*numMBEvents].actionDblClk, tokens[3]);
		++*numMBEvents;
	}
	#ifndef DARKSTEP
		LCClose(f);
	#endif
	if (tokens)
		free(tokens);
	if (!*numMBEvents && MBData){
		free(MBData); // I really hope this would never happen. If it does, this isn't going to be too clean.
		MBData = NULL;
	}
	return MBData;
}

jDeskSettings ReadSettings(void)
{
	jDeskSettings settings;

	#ifdef DARKSTEP
		settings.DisableDoubleClick = RCReadBool(rcPath, jIniSec, TEXT("DisableDoubleClick"));
		settings.DisableMButton1 = RCReadBool(rcPath, jIniSec, TEXT("DisableMButton1")) ? TRUE:!(MB1Data = LoadItems(TEXT("MButton1"), &numMB1Events));
		settings.DisableMButton2 = RCReadBool(rcPath, jIniSec, TEXT("DisableMButton2")) ? TRUE:!(MB2Data = LoadItems(TEXT("MButton2"), &numMB2Events));
		settings.DisableMButton3 = RCReadBool(rcPath, jIniSec, TEXT("DisableMButton3")) ? TRUE:!(MB3Data = LoadItems(TEXT("MButton3"), &numMB3Events));
		settings.DisableMButtonX1 = RCReadBool(rcPath, jIniSec, TEXT("DisableMButtonX1")) ? TRUE:!(MBX1Data = LoadItems(TEXT("MButtonX1"), &numMBX1Events));
		settings.DisableMButtonX2 = RCReadBool(rcPath, jIniSec, TEXT("DisableMButtonX2")) ? TRUE:!(MBX2Data = LoadItems(TEXT("MButtonX2"), &numMBX2Events));
		settings.DisableMWheelScroll = RCReadBool(rcPath, jIniSec, TEXT("DisableMWheelScroll")) ? TRUE:!(MBWSData = LoadItems(TEXT("MWheelScroll"), &numMWSEvents));
	#else
		settings.DisableDoubleClick = GetRCBool(TEXT("jDeskDisableDoubleClick"), TRUE);
		settings.DisableMButton1 = GetRCBool(TEXT("jDeskDisableMButton1"), TRUE) ? TRUE:((MB1Data = LoadItems(TEXT("*jDeskMButton1"), &numMB1Events)) == NULL);
		settings.DisableMButton2 = GetRCBool(TEXT("jDeskDisableMButton2"), TRUE) ? TRUE:((MB2Data = LoadItems(TEXT("*jDeskMButton2"), &numMB2Events)) == NULL);
		settings.DisableMButton3 = GetRCBool(TEXT("jDeskDisableMButton3"), TRUE) ? TRUE:((MB3Data = LoadItems(TEXT("*jDeskMButton3"), &numMB3Events)) == NULL);
		settings.DisableMButtonX1 = GetRCBool(TEXT("jDeskDisableMButtonX1"), TRUE) ? TRUE:((MBX1Data = LoadItems(TEXT("*jDeskMButtonX1"), &numMBX1Events)) == NULL);
		settings.DisableMButtonX2 = GetRCBool(TEXT("jDeskDisableMButtonX2"), TRUE) ? TRUE:((MBX2Data = LoadItems(TEXT("*jDeskMButtonX2"), &numMBX2Events)) == NULL);
		settings.DisableMWheelScroll = GetRCBool(TEXT("jDeskDisableMWheelScroll"), TRUE) ? TRUE:((MWSData = LoadItems(TEXT("*jDeskMWheelScroll"), &numMWSEvents)) == NULL);
	#endif

	#ifdef DARKSTEP
		strcpy(settings.DesktopFolder, RCReadString(rcPath, jIniSec, TEXT("DesktopFolder"), TEXT("")));
		settings.RecycleOnRezChange = RCReadBool(rcPath, jIniSec, TEXT("RecycleOnRezChange"));
			// NEED TO VERIFY INT RETRIEVAL
		//settings.DoubleClickTime = RCReadInt(rcPath, jIniSec, TEXT("DoubleClickTime"));
	#else
		GetRCString(TEXT("jDeskDesktopFolder"), settings.DesktopFolder, TEXT(""), MAX_PATH);
		settings.RecycleOnRezChange = GetRCBool(TEXT("jDeskRecycleOnRezChange"), TRUE);
		settings.DoubleClickTime = GetRCInt(TEXT("jDeskDoubleClickTime"), GetDoubleClickTime());
	#endif

	{
		// workarea for other monitors
		#ifdef DARKSTEP

		#error You're compiling for darkstep.  Stop that.  (or write the appropriate code for this)

		#else

		FILE *f;
		char line[MAXLEN];
		char one[MAXLEN],two[MAXLEN];
		char *tokens[] = { one };

		f = LCOpen(NULL);
		if (f)
		{
			while (LCReadNextConfig (f, TEXT("*jDeskWorkArea"), line, MAXLEN))
			{
				// strip off the key name
				LCTokenize(line,tokens,1,two);

				// set work area in a nice cheatery way
				JDeskSetWorkArea(NULL,two);
			}
			LCClose(f);
		}

		#endif
	}

	{ // Workarea stuff
		//   Primary monitor is done last so it takes
		//   effect properly if there's only one monitor.
		char tmp[MAXLEN];

		#ifdef DARKSTEP
			settings.ClearWorkAreaOnExit = RCReadBool(rcPath, jIniSec, TEXT("ClearWorkAreaOnExit"));
			settings.WorkArea = RCReadBool(rcPath, jIniSec, TEXT("UseWorkArea"));
			strcpy(tmp, RCReadString(rcPath, jIniSec, TEXT("WorkArea"), TEXT("0,0,0,0")));
		#else
			settings.ClearWorkAreaOnExit = GetRCBool(TEXT("jDeskClearWorkAreaOnExit"), TRUE);
			settings.WorkArea = GetRCBool(TEXT("jDeskWorkArea"), TRUE);
			GetRCLine(TEXT("jDeskWorkArea"), tmp, MAXLEN, TEXT("0,0,0,0"));
		#endif

		SystemParametersInfo(SPI_GETWORKAREA,0,&rWorkArea,0);
		JDeskSetWorkArea(NULL, tmp);
		bIsFirst = FALSE;
		CopyRect(&rbkWA, &rWorkArea);

	}

	return settings;
}


int initModuleEx(HWND parent, HINSTANCE dllInst, const char* szPath)
{
	szPath=szPath;

	#ifdef DARKSTEP
		strcpy(rcPath, GetShellSet(DM_RCPATH));
	#endif

	dll = dllInst;
	hParentWnd = parent;
	bIsFirst = TRUE;

	LSInitMultiMon();

	{// Register the jDesk desktop window class
		WNDCLASS wc;
		memset(&wc,0,sizeof(wc));
		wc.hCursor = LoadCursor(NULL, IDC_ARROW);
		wc.lpfnWndProc = WndProc;
		wc.hInstance = dllInst;
		wc.lpszClassName = szAppClass;
		wc.style = CS_DBLCLKS;
		if (!RegisterClass(&wc)){
			MessageBox(NULL,TEXT("Error registering Desktop window class"),TEXT("jDesk"),MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
			return 1;
		}
	}

	SetRectEmpty(&rWorkArea);
	//SetRect(&rScreen, 0,0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
	LSGetMonitorScreenRect(LSGetMonitor("all"),&rScreen);

	{// Create jDesk desktop window
		hMainWnd = CreateWindowEx(WS_EX_TOOLWINDOW,szAppClass,szAppName,WS_POPUP|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,rScreen.left,rScreen.top,rScreen.right,rScreen.bottom,NULL,NULL,dll,NULL);
		if (!hMainWnd){
			MessageBox(NULL,TEXT("Error creating Desktop window!"),TEXT("jDesk"),MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
			return 1;
		}
	}

		// Get all of our user configuration info
	jds = ReadSettings();

	RegBang(TEXT("!JDESKSETWORKAREA"),&JDeskSetWorkArea);
	RegBang(TEXT("!JDESKRESETWORKAREA"),&JDeskResetWorkArea);

	{//register message for version info
		UINT Msgs[2];
		Msgs[0] = SHELL_GETREVID;
		Msgs[1] = 0;
		SendMessage(hParentWnd, SHELL_REGISTERMESSAGE, (WPARAM)hMainWnd, (LPARAM)Msgs); 
	}

	//Final desktop window settings and display
	if (GetFileAttributes(jds.DesktopFolder) != 0xFFFFFFFF)
		DragAcceptFiles(hMainWnd, TRUE);
	SetWindowLong(hMainWnd, GWL_USERDATA, SHELL_MAGICNUMBER);
	SetWindowPos(hMainWnd, HWND_BOTTOM, 0,0,0,0, SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
	ShowWindow(hMainWnd,SW_SHOWNOACTIVATE);

	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	int i;

	if (jds.ClearWorkAreaOnExit)
		ClearWorkArea();

	for (i=0;i<numMB1Events;i++){
		delete [] MB1Data[i].actionDown;
		delete [] MB1Data[i].actionUp;
		delete [] MB1Data[i].actionDblClk;
		delete [] MB1Data[i].modKey;
	} if (MB1Data){
			free(MB1Data);
		}

	for (i=0;i<numMB2Events;i++){
		delete [] MB2Data[i].actionDown;
		delete [] MB2Data[i].actionUp;
		delete [] MB2Data[i].actionDblClk;
		delete [] MB2Data[i].modKey;
	} if (MB2Data){
			free(MB2Data);
		}

	for (i=0;i<numMB3Events;i++){
		delete [] MB3Data[i].actionDown;
		delete [] MB3Data[i].actionUp;
		delete [] MB3Data[i].actionDblClk;
		delete [] MB3Data[i].modKey;
	} if (MB3Data){
			free(MB3Data);
		}

	for (i=0;i<numMBX1Events;i++){
		delete [] MBX1Data[i].actionDown;
		delete [] MBX1Data[i].actionUp;
		delete [] MBX1Data[i].actionDblClk;
		delete [] MBX1Data[i].modKey;
	} if (MBX1Data){
			free(MBX1Data);
		}

	for (i=0;i<numMBX2Events;i++){
		delete [] MBX2Data[i].actionDown;
		delete [] MBX2Data[i].actionUp;
		delete [] MBX2Data[i].actionDblClk;
		delete [] MBX2Data[i].modKey;
	} if (MBX2Data){
			free(MBX2Data);
		}

	for (i=0;i<numMWSEvents;i++){
		delete [] MWSData[i].actionDown;
		delete [] MWSData[i].actionUp;
		delete [] MWSData[i].actionDblClk;
		delete [] MWSData[i].modKey;
	} if (MWSData){
			free(MWSData);
		}

	{//unregister message for version info
		UINT Msgs[2];
		Msgs[0] = SHELL_GETREVID; // LM_GETREVID  or  DM_GETREVID
		Msgs[1] = 0;
		SendMessage(hParentWnd, SHELL_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	}

	UnRegBang(TEXT("!JDESKSETWORKAREA"));
	UnRegBang(TEXT("!JDESKRESETWORKAREA"));

	DestroyWindow(hMainWnd); // delete jDesk desktop window
	UnregisterClass(szAppClass,dllInst); // unregister jDesk desktop window class

	LSQuitMultiMon();

	return;
}


LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case SHELL_GETREVID:
			{
				char* buf = (char*)lParam;
				#ifdef DARKSTEP
						sprintf(buf, TEXT("%s: %s - %s - %s"), buildName, buildRev, buildDate, buildAuthor);
				#else
					if (wParam == 0)
						sprintf(buf, TEXT("%s: %s"), buildName, buildRev);
					else if (wParam == 1)
						sprintf(buf, TEXT("%s: %s - %s - %s"), buildName, buildRev, buildDate, buildAuthor);
					else
						strcpy(buf, TEXT(""));
				#endif
				return strlen(buf);
			}
		case WM_DISPLAYCHANGE:
				// Screen resolution has changed. Update stored settings and resize desktop window and workarea.
			if (!jds.RecycleOnRezChange){
				/* none of this will work properly as is -- WorkArea isn't remembered for non-primary monitors
				(see devinfo.txt)
				LSQuitMultiMon();
				LSInitMultiMon();
				SetWindowPos(hMainWnd, HWND_BOTTOM, 0,0,0,0,SWP_NOACTIVATE);
				GetMonitorRect(NULL,&rScreen);
				SetWorkArea();
				*/
			}else
				PostMessage(hParentWnd, LM_RECYCLE, 0,0);
			break;
		case WM_WINDOWPOSCHANGING:
			{
				LSGetMonitorScreenRect(LSGetMonitor("all"),&rScreen);
				// Trap windowposchanging messages
				WINDOWPOS *c = (WINDOWPOS*)lParam;
				c->hwnd = hMainWnd;
				c->hwndInsertAfter = HWND_BOTTOM;
				c->x = rScreen.left;
				c->y = rScreen.top;
				c->cx = rScreen.right;
				c->cy = rScreen.bottom;
				c->flags = c->flags & ~SWP_NOZORDER; //not really needed, as I never send a command with it.
				c->flags |= SWP_NOACTIVATE|SWP_NOSENDCHANGING;
//#ifdef _DEBUG
//	OutputDebugString("\n\njDesk got focus - WM_WINDOWPOSCHANGING\n");
//#endif
				return 0;
			}
		case WM_DROPFILES:
			{// need to implement CTRL-copy, SHIFT-move, CTRL+SHIFT-shortcut modifier keys
				char szFullFileName[MAX_PATH];
				char* szFileName = NULL;
				char buffer[MAX_PATH];
				int numFiles;
				UINT len;
				numFiles = DragQueryFile((HDROP)wParam, 0xFFFFFFFF, NULL, NULL);
				for (int i=0;i<numFiles;i++){
					len = DragQueryFile((HDROP)wParam, i, szFullFileName, sizeof(szFullFileName));
					while (len && szFullFileName[len-1] != '\\')
						--len;
					szFileName = szFullFileName + len;
//#ifdef _DEBUG
//	OutputDebugString("\n\rjDesk: ");
//	OutputDebugString(szFileName);
//	OutputDebugString("\n\r");
//#endif

					strcpy(buffer, jds.DesktopFolder);
					if (buffer[strlen(buffer)-1] != '\\')
						strcat(buffer, TEXT("\\"));
					strcat(buffer, szFileName);
					if (GetFileAttributes(szFullFileName) != 0xFFFFFFFF){
						if (!CopyFile(szFullFileName, buffer, TRUE))
							if (MessageBox(NULL, TEXT("File already exists. Overwrite?"), buffer, MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON1|MB_SYSTEMMODAL) == IDYES)
								if (!CopyFile(szFullFileName, buffer, FALSE))
									MessageBox(NULL, TEXT("Operation Failed!"), TEXT("jDesk - ERROR!"), MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
					}else // not really sure why this would happen, but you never know what crazy things go on in your computer!
						MessageBox(NULL, TEXT("File does not exist!"), TEXT("jDesk - ERROR!"), MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
				}
				DragFinish((HDROP)wParam);
				return 0;
			}
		case WM_ERASEBKGND:
			PaintDesktop((HDC)wParam);
			return 1;
		case WM_CLOSE:
				// If someone trys to exit the desktop window, lets make it a windows shutdown.
			PostMessage(hParentWnd, LM_RECYCLE, 3, 0);
			return 0;
		case WM_SYSCOMMAND:
			switch (wParam){
					//For using the standard alt+F4 to shutdown windows
				case SC_CLOSE:
					PostMessage(hParentWnd, LM_RECYCLE, 3, 0);
					return 0;
				default:
					break;
			}
			break;
		case WM_TIMER:
			if (!jds.DisableDoubleClick){
				KillTimer(hMainWnd, wParam);
				switch (wParam){
					case 1:
						ProcessClicks(WM_LBUTTONUP, mb1.wp);
						break;
					case 2:
						ProcessClicks(WM_RBUTTONUP, mb2.wp);
						break;
					case 3:
						ProcessClicks(WM_MBUTTONUP, mb3.wp);
						break;
					case 4:
						ProcessClicks(WM_XBUTTONUP, mbx.wp);
						break;
				}
				return 0;
			}
			break;
		case WM_MOUSEWHEEL:
			ProcessClicks(message, wParam);
			return 0;
		case WM_LBUTTONDOWN:
			if (!jds.DisableDoubleClick){
				KillTimer(hMainWnd, 1);
				mb1.dblclk = 0;
				mb1.wp = 0;
			}
			ProcessClicks(message, wParam);
			return 0;
		case WM_RBUTTONDOWN:
			if (!jds.DisableDoubleClick){
				KillTimer(hMainWnd, 2);
				mb2.dblclk = 0;
				mb2.wp = 0;
			}
			ProcessClicks(message, wParam);
			return 0;
		case WM_MBUTTONDOWN:
			if (!jds.DisableDoubleClick){
				KillTimer(hMainWnd, 3);
				mb3.dblclk = 0;
				mb3.wp = 0;
			}
			ProcessClicks(message, wParam);
			return 0;
		case WM_XBUTTONDOWN:
			if (!jds.DisableDoubleClick){
				KillTimer(hMainWnd, 4);
				mbx.dblclk = 0;
				mbx.wp = 0;
			}
			ProcessClicks(message, wParam);
			return 0;
		case WM_LBUTTONUP:
			if (!jds.DisableDoubleClick){
				if (!mb1.dblclk){
					SetTimer(hMainWnd, 1, jds.DoubleClickTime, (TIMERPROC)NULL);
					mb1.wp = wParam;
				}else
					ProcessClicks(WM_LBUTTONDBLCLK, wParam);
			}else
				ProcessClicks(message, wParam);
			return 0;
		case WM_RBUTTONUP:
			if (!jds.DisableDoubleClick){
				if (!mb2.dblclk){
					SetTimer(hMainWnd, 2, jds.DoubleClickTime, (TIMERPROC)NULL);
					mb2.wp = wParam;
				}else
					ProcessClicks(WM_RBUTTONDBLCLK, wParam);
			}else
				ProcessClicks(message, wParam);
			return 0;
		case WM_MBUTTONUP:
			if (!jds.DisableDoubleClick){
				if (!mb3.dblclk){
					SetTimer(hMainWnd, 3, jds.DoubleClickTime, (TIMERPROC)NULL);
					mb3.wp = wParam;
				}else
					ProcessClicks(WM_MBUTTONDBLCLK, wParam);
			}else
				ProcessClicks(message, wParam);
			return 0;
		case WM_XBUTTONUP:
			if (!jds.DisableDoubleClick){
				if (!mbx.dblclk){
					SetTimer(hMainWnd, 4, jds.DoubleClickTime, (TIMERPROC)NULL);
					mbx.wp = wParam;
				}else
					ProcessClicks(WM_XBUTTONDBLCLK, wParam);
			}else
				ProcessClicks(message, wParam);
			return 0;
		case WM_LBUTTONDBLCLK:
			if (!jds.DisableDoubleClick){
				KillTimer(hMainWnd, 1);
				mb1.dblclk = 1;
			}else
				ProcessClicks(WM_LBUTTONDOWN, wParam);
			return 0;
		case WM_RBUTTONDBLCLK:
			if (!jds.DisableDoubleClick){
				KillTimer(hMainWnd, 2);
				mb2.dblclk = 1;
			}else
				ProcessClicks(WM_RBUTTONDOWN, wParam);
			return 0;
		case WM_MBUTTONDBLCLK:
			if (!jds.DisableDoubleClick){
				KillTimer(hMainWnd, 3);
				mb3.dblclk = 1;
			}else
				ProcessClicks(WM_MBUTTONDOWN, wParam);
			return 0;
		case WM_XBUTTONDBLCLK:
			if (!jds.DisableDoubleClick){
				KillTimer(hMainWnd, 4);
				mbx.dblclk = 1;
			}else
				ProcessClicks(WM_XBUTTONDOWN, wParam);
			return 0;

		case WM_CHILDACTIVATE:
		case WM_NCACTIVATE:
		case WM_SETFOCUS:
		case WM_KILLFOCUS:
		case WM_ACTIVATEAPP:
		case WM_ACTIVATE:
		case WM_PARENTNOTIFY:
			SetWindowPos(hMainWnd,HWND_BOTTOM,0,0,0,0,SWP_NOACTIVATE);
			break;

/*		case WM_NCCALCSIZE:
				OutputDebugString("\n\njDesk - WM_NCCALCSIZE\n");
			break;
		case WM_CHILDACTIVATE:
				OutputDebugString("\n\njDesk child got focus - WM_CHILDACTIVATE\n");
			break;
		case WM_NCACTIVATE:
			if ((BOOL)wParam)
				OutputDebugString("\n\njDesk got focus - WM_NCACTIVATE\n");
			else
				OutputDebugString("\n\njDesk lost focus - WM_NCACTIVATE\n");
			break;
		case WM_SETFOCUS:
				OutputDebugString("\n\njDesk got keyboard focus - WM_SETFOCUS\n");
			break;
		case WM_KILLFOCUS:
				OutputDebugString("\n\njDesk lost keyboard focus - WM_KILLFOCUS\n");
			break;
		case WM_ACTIVATEAPP:
			if ((BOOL)wParam)
				OutputDebugString("\n\njDesk got focus - WM_ACTIVATEAPP\n");
			else
				OutputDebugString("\n\njDesk lost focus - WM_ACTIVATEAPP\n");
			break;
		case WM_ACTIVATE:
			if (wParam == WA_INACTIVE)
				OutputDebugString("\n\njDesk lost focus - WM_ACTIVATE\n");
			else
				OutputDebugString("\n\njDesk got focus - WM_ACTIVATE\n");
			break;
		case WM_PARENTNOTIFY:
			OutputDebugString("\n\njDesk got WM_PARENTNOTIFY\n");
			break;*/
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

void ProcessClicks( UINT clickmsg, WPARAM modkeys )
{
	char tmp[256];
	int i;

	if ((LOWORD(modkeys) & (MK_CONTROL|MK_SHIFT)) == (MK_CONTROL|MK_SHIFT))
		strcpy(tmp, TEXT("CTRL+SHIFT"));
	else if ((LOWORD(modkeys) & MK_CONTROL) == MK_CONTROL)
		strcpy(tmp, TEXT("CTRL"));
	else if ((LOWORD(modkeys) & MK_SHIFT) == MK_SHIFT)
		strcpy(tmp, TEXT("SHIFT"));
	else
		strcpy(tmp, TEXT(".none"));

	switch (clickmsg){
		case WM_MOUSEWHEEL:
			for (i=0;i<numMWSEvents;i++){
				if (!_stricmp(MWSData[i].modKey, tmp)){
					if ((short)(HIWORD(modkeys)) < 0)
						ExecuteValue(hMainWnd, MWSData[i].actionDown, ExecValParams);
					else
						ExecuteValue(hMainWnd, MWSData[i].actionUp, ExecValParams);
				}
				i=numMWSEvents;
			}
			break;

		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_LBUTTONDBLCLK:
			for (i=0;i<numMB1Events;i++){
				if (!_stricmp(MB1Data[i].modKey, tmp)){
					switch (clickmsg){
						case WM_LBUTTONDOWN:
							ExecuteValue(hMainWnd, MB1Data[i].actionDown, ExecValParams);
							break;
						case WM_LBUTTONUP:
							ExecuteValue(hMainWnd, MB1Data[i].actionUp, ExecValParams);
							break;
						case WM_LBUTTONDBLCLK:
							ExecuteValue(hMainWnd, MB1Data[i].actionDblClk, ExecValParams);
							break;
					}
					i=numMB1Events;
				}
			}
			break;

		case WM_RBUTTONDOWN:
		case WM_RBUTTONUP:
		case WM_RBUTTONDBLCLK:
			for (i=0;i<numMB2Events;i++){
				if (!_stricmp(MB2Data[i].modKey, tmp)){
					switch (clickmsg){
						case WM_RBUTTONDOWN:
							ExecuteValue(hMainWnd, MB2Data[i].actionDown, ExecValParams);
							break;
						case WM_RBUTTONUP:
							ExecuteValue(hMainWnd, MB2Data[i].actionUp, ExecValParams);
							break;
						case WM_RBUTTONDBLCLK:
							ExecuteValue(hMainWnd, MB2Data[i].actionDblClk, ExecValParams);
							break;
					}
					i=numMB2Events;
				}
			}
			break;

		case WM_MBUTTONDOWN:
		case WM_MBUTTONUP:
		case WM_MBUTTONDBLCLK:
			for (i=0;i<numMB3Events;i++){
				if (!_stricmp(MB3Data[i].modKey, tmp)){
					switch (clickmsg){
						case WM_MBUTTONDOWN:
							ExecuteValue(hMainWnd, MB3Data[i].actionDown, ExecValParams);
							break;
						case WM_MBUTTONUP:
							ExecuteValue(hMainWnd, MB3Data[i].actionUp, ExecValParams);
							break;
						case WM_MBUTTONDBLCLK:
							ExecuteValue(hMainWnd, MB3Data[i].actionDblClk, ExecValParams);
							break;
					}
					i=numMB3Events;
				}
			}
			break;

		case WM_XBUTTONDOWN:
		case WM_XBUTTONUP:
		case WM_XBUTTONDBLCLK:
			if (HIWORD(modkeys) == XBUTTON1){
				for (i=0;i<numMBX1Events;i++){
					if (!_stricmp(MBX1Data[i].modKey, tmp)){
						switch (clickmsg){
							case WM_XBUTTONDOWN:
								ExecuteValue(hMainWnd, MBX1Data[i].actionDown, ExecValParams);
								break;
							case WM_XBUTTONUP:
								ExecuteValue(hMainWnd, MBX1Data[i].actionUp, ExecValParams);
								break;
							case WM_XBUTTONDBLCLK:
								ExecuteValue(hMainWnd, MBX1Data[i].actionDblClk, ExecValParams);
								break;
						}
						i=numMBX1Events;
					}
				}
			}
			else if (HIWORD(modkeys) == XBUTTON2){
				for (i=0;i<numMBX2Events;i++){
					if (!_stricmp(MBX2Data[i].modKey, tmp)){
						switch (clickmsg){
							case WM_XBUTTONDOWN:
								ExecuteValue(hMainWnd, MBX2Data[i].actionDown, ExecValParams);
								break;
							case WM_XBUTTONUP:
								ExecuteValue(hMainWnd, MBX2Data[i].actionUp, ExecValParams);
								break;
							case WM_XBUTTONDBLCLK:
								ExecuteValue(hMainWnd, MBX2Data[i].actionDblClk, ExecValParams);
								break;
						}
						i=numMBX2Events;
					}
				}
			}
			break;

		default:
			break;
	}
	return;
}

void SetWorkArea(void)
{
		//Allowing a minimum of 200x200 work area.
		//Anything less is even more rediculous then that,
		//plus impossible to access a max'd window.
	#define minSize 200
	if (jds.WorkArea){

		/*
		if (rWorkArea.left<0)
			rWorkArea.left = rWorkArea.left+rScreen.right;
		if (rWorkArea.left >= rScreen.right-minSize)
			rWorkArea.left = 0;

		if (rWorkArea.right<0)
			rWorkArea.right = rWorkArea.right+rScreen.right;
		if (rWorkArea.right <= rWorkArea.left+minSize)
			rWorkArea.right = rScreen.right;

		if (rWorkArea.top<0)
			rWorkArea.top = rWorkArea.top+rScreen.bottom;
		if (rWorkArea.top >= rScreen.bottom-minSize)
			rWorkArea.top = 0;

		if (rWorkArea.bottom<0)
			rWorkArea.bottom = rWorkArea.bottom+rScreen.bottom;
		if (rWorkArea.bottom <= rWorkArea.top+minSize)
			rWorkArea.bottom = rScreen.bottom;
		*/

		if (EqualRect(&rScreen, &rWorkArea) || IsRectEmpty(&rWorkArea))
			jds.WorkArea = FALSE;
	}

	//SystemParametersInfo(SPI_SETWORKAREA,(bIsFirst ? 0:1),(jds.WorkArea ? &rWorkArea:NULL),SPIF_SENDCHANGE);
	SystemParametersInfo(SPI_SETWORKAREA,(bIsFirst ? 0:1),(jds.WorkArea ? &rWorkArea:&rScreen),SPIF_SENDCHANGE);

	// refresh monitor info
	// This shouldn't be needed because LSGetMonitorDeskRect gets it from the system each time.
	//LSQuitMultiMon();
	//LSInitMultiMon();

	return;
}

bool ClearMonitorWorkAreaProc(LSMONITOR Mon,LPARAM rect)
{
	/* set the work area to full screen */ 
	LSGetMonitorScreenRect(Mon,reinterpret_cast<RECT *>(rect));
	SystemParametersInfo(SPI_SETWORKAREA,0,reinterpret_cast<RECT *>(rect),SPIF_SENDCHANGE);

	return true;
}

void ClearWorkArea(void)
{
	RECT rect;
	LSForEachMonitor(&ClearMonitorWorkAreaProc,reinterpret_cast<LPARAM>(&rect));

// This only works on the primary monitor.
// Do it anyway, just in case there's a difference.
	SystemParametersInfo(SPI_SETWORKAREA,0,NULL,SPIF_SENDCHANGE);
	return;
}

void JDeskSetWorkArea(HWND caller, const char *a)
{
	char *args = (char *)a;
	LSMONITOR m;

	caller=caller;

	if (!args)
		jds.WorkArea = FALSE;
	else{
		jds.WorkArea = TRUE;

		args = strtok(args, TEXT("\'\"\t ,"));

		if (*args<'0' || *args>'9' && *args!='.')
		{
			// get rect for proper monitor
			m = LSGetMonitor(args);
			// get next param
			args = strtok(NULL, TEXT("\'\"\t ,"));
		}
		else
		{
			// primary monitor
			m = LSGetMonitor(NULL);
		}
		LSGetMonitorDeskRect(m,&rWorkArea);
		LSGetMonitorScreenRect(m,&rScreen);

			if (args != NULL && _stricmp(args, TEXT(".none")))
			{
				if ((rWorkArea.left = atoi(args))<0)
					rWorkArea.left += rScreen.right;
				else
					rWorkArea.left += rScreen.left;
			}
		args = strtok(NULL, TEXT("\'\"\t ,"));
			if (args != NULL && _stricmp(args, TEXT(".none")))
			{
				if ((rWorkArea.top = atoi(args))<0)
					rWorkArea.top += rScreen.bottom;
				else
					rWorkArea.top += rScreen.top;
			}
		args = strtok(NULL, TEXT("\'\"\t ,"));
			if (args != NULL && _stricmp(args, TEXT(".none")))
			{
				if ((rWorkArea.right = atoi(args))<=0)
					rWorkArea.right += rScreen.right;
				else
					rWorkArea.right += rScreen.left;
			}
		args = strtok(NULL, TEXT("\'\"\t ,"));
			if (args != NULL && _stricmp(args, TEXT(".none")))
			{
				if ((rWorkArea.bottom = atoi(args))<=0)
					rWorkArea.bottom += rScreen.bottom;
				else
					rWorkArea.bottom += rScreen.top;
			}
	}
	SetWorkArea();
	return;
}

// reset work area for primary monitor (see devinfo.txt)
void JDeskResetWorkArea(HWND, const char*)
{
	jds.WorkArea = TRUE;
	CopyRect(&rWorkArea, &rbkWA);
	LSGetMonitorScreenRect(LSGetMonitor(NULL),&rScreen);
	SetWorkArea();
	return;
}

BOOL StripWS ( char* buffer )
{
	UINT length = buffer != NULL ? strlen(buffer):0;
	while (length && isspace(*buffer))
	{ // strip leading white space, but do not move pointer, copy contents instead.
		length--;
		strcpy(buffer, buffer+1);
	}
	while (length && isspace(buffer[length-1]))
	{ // strip trailing white space, just move the terminating null character down.
		buffer[--length] = 0;
	}
	if (length) return TRUE;
	if (buffer != NULL) // if the buffer is NULL, we don't want to modify it as it may never have been initialized.
		*buffer = 0;
	return FALSE;
}