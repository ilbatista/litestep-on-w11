/*
  jDesk LiteStep Module - version 0.71
	Core MultiMonitor Section

  Copyright (C) 2002 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <windows.h>
#include "jdesk.h"
#include "multimonitor.h"
#include "lsapi.h"

#ifdef LS_AUTHORIZATION_UNAVAILABLE
#error Wrong LSAPI.H.  Make sure the path is right.
#endif

// step.rc option for setting the names of the monitors
#define MONITOR_NAMES_CFG "MonitorNames"

// debug macros
#ifndef ASSERTR
#define ASSERTR(n,r) (void)0
#endif
#ifndef ASSERT
#define ASSERT(n) (void)0
#endif
#ifndef TRACE
#define TRACE(n) (void)0
#endif
#ifndef NDEBUG
# ifndef DCLEAR
# define DCLEAR(n) { n = NULL; }
# endif
# ifndef DFREE
# define DFREE(n) { void *a = n; ASSERT(n!=NULL); n = NULL; delete[] a; }
# endif
# ifndef DALLOC
# define DALLOC(n,a) { ASSERT(n==NULL); n = new a; }
# endif
#else
# ifndef DCLEAR
# define DCLEAR(n) (void)0
# endif
# ifndef DFREE
# define DFREE(n) { delete[] n; n = NULL; }
# endif
# ifndef DALLOC
# define DALLOC(n,a) n = new a
# endif
#endif

// use litestep multimonitor functions if dynamic or statically linked ones aren't used
#ifndef dGetMonitorInfo
#define dGetMonitorInfo LSGetMonitorInfo
#endif
#ifndef dEnumDisplayMonitors
#define dEnumDisplayMonitors LSEnumDisplayMonitors
#endif


typedef lsMonitorData s_MonitorData;
struct s_MultiMonData {
	int cMonitors;
	s_MonitorData *pMonitors;
	s_MonitorData *pPriMon;
	RECT VirtualArea;
} MultiMonData;



BOOL CALLBACK GetMonitorDataProc(HMONITOR hMonitor,
																 HDC hdcMonitor,
																 LPRECT lprcMonitor,
																 LPARAM dwData)			/* -> pointer to monitor data struct */ 
{
	s_MonitorData **pp;

	(void)hdcMonitor;
	(void)lprcMonitor;

	pp = reinterpret_cast<s_MonitorData **>(dwData);

	(*pp)->Handle = hMonitor;
	(*pp)->mInfo.cbSize = sizeof(MONITORINFO);
	dGetMonitorInfo(hMonitor,&(*pp)->mInfo);

	++(*pp);

	return TRUE;
}

/* used to count monitors, including "detatched" ones */ 
BOOL CALLBACK CountMonitorProc(HMONITOR hMonitor,
															 HDC hdcMonitor,
															 LPRECT lprcMonitor,
															 LPARAM dwData)			/* -> count */ 
{
	(void)hMonitor;
	(void)hdcMonitor;
	(void)lprcMonitor;

	++(*(reinterpret_cast<int *>(dwData)));
	return TRUE;
}

//
// load monitor names, rectangles, flags, etc and cache them
//
void LSInitMultiMon(void)
{
	s_MonitorData *p;
	char line[MAX_LINE_LENGTH];
	char one[MAX_PATH],two[MAX_LINE_LENGTH];
	char *tokens[] = { one };
	int x,y;

	if (GetSystemMetrics(SM_CMONITORS)<2)
	{
		TRACE("Using fake multimonitor stuff.");
		/* emulation values */ 
		MultiMonData.cMonitors = 1;
		DALLOC(MultiMonData.pMonitors,s_MonitorData[1]);
		ZeroMemory(MultiMonData.pMonitors,sizeof(s_MonitorData));

		SetRect(&MultiMonData.VirtualArea,0,0,
			GetSystemMetrics(SM_CXSCREEN),
			GetSystemMetrics(SM_CYSCREEN));

		MultiMonData.pPriMon = MultiMonData.pMonitors;
		MultiMonData.pPriMon->Number = 0;

		CopyRect(&MultiMonData.pPriMon->mInfo.rcMonitor,&MultiMonData.VirtualArea);
		SystemParametersInfo(SPI_GETWORKAREA,0,&MultiMonData.pPriMon->mInfo.rcWork,0);
		MultiMonData.pPriMon->Name = NULL;
		return;
	}

	MultiMonData.cMonitors = 1;
	/* Can't use GetSystemMetrics(SM_CMONITORS) because that doesn't */ 
	/* include detached monitors while EnumDisplayMonitors does.     */ 
	dEnumDisplayMonitors(NULL,NULL,&CountMonitorProc,(LPARAM)&MultiMonData.cMonitors);

#if !defined(NDEBUG) && defined(TRACE_FILE)
	sprintf(one,"EnumDisplayMonitors: %i monitors",MultiMonData.cMonitors);
	TRACE(one);
#endif

	DALLOC(MultiMonData.pMonitors,s_MonitorData[MultiMonData.cMonitors]);
	ZeroMemory(MultiMonData.pMonitors,sizeof(s_MonitorData)*MultiMonData.cMonitors);

	p = MultiMonData.pMonitors;
	dEnumDisplayMonitors(NULL,NULL,&GetMonitorDataProc,(LPARAM)&p);

	x = GetSystemMetrics(SM_XVIRTUALSCREEN);
	y = GetSystemMetrics(SM_YVIRTUALSCREEN);
	SetRect(&MultiMonData.VirtualArea,x,y,
		GetSystemMetrics(SM_CXVIRTUALSCREEN),
		GetSystemMetrics(SM_CYVIRTUALSCREEN));

	/* number the monitors */ 
	x=1;
	p=MultiMonData.pMonitors;
	y=MultiMonData.cMonitors;
	while (--y)
	{
		/* primary monitor comes first */ 
		if (p->mInfo.dwFlags&MONITORINFOF_PRIMARY)
		{
			p->Number = 0;
			MultiMonData.pPriMon = p;
		}
		/* then the others in order */ 
		else
		{
			p->Number = x;
			++x;
		}
		++p;
	}

	/* read monitor names from step.rc */ 
	if (GetRCLine(MONITOR_NAMES_CFG,line,MAX_LINE_LENGTH,NULL))
	{
		*two=*one=0;
		LCTokenize(line,tokens,1,two); lstrcpy(line,two);
		/* primary monitor is first, other monitors are in order */ 
		if (*one)
		{
			DALLOC(MultiMonData.pPriMon->Name,char[lstrlen(one)+1]);
			lstrcpy(MultiMonData.pPriMon->Name,one);
			/* should I force to upper case? */ 

			p=MultiMonData.pMonitors;
			y=MultiMonData.cMonitors;
			while (--y)
			{
				if (p->mInfo.dwFlags&MONITORINFOF_PRIMARY) { ++p; continue; }

				*two=*one=0;
				LCTokenize(line,tokens,1,two); lstrcpy(line,two);
				if (*one==0) break;

				DALLOC(p->Name,char[lstrlen(one)+1]);
				lstrcpy(p->Name,one);

				++p;
			}
		}
	}

#if !defined(NDEBUG) && defined(TRACE_FILE)
	p=MultiMonData.pMonitors;
	y=MultiMonData.cMonitors;
	while (--y)
	{
		sprintf(line,"Mon[%2i] = %c {%5i,%5i,%5i,%5i } {%5i,%5i,%5i,%5i } %s",
			p->Number, ((p->mInfo.dwFlags&MONITORINFOF_PRIMARY)?'P':'-'),
			p->mInfo.rcMonitor.left, p->mInfo.rcMonitor.top, p->mInfo.rcMonitor.right, p->mInfo.rcMonitor.bottom,
			p->mInfo.rcWork.left, p->mInfo.rcWork.top, p->mInfo.rcWork.right, p->mInfo.rcWork.bottom,
			(p->Name?p->Name:"."));
		TRACE(line);
		++p;
	}
#endif
}

//
// free multimonitor data cache
//
void LSQuitMultiMon(void)
{
	s_MonitorData *p;
	int i;

	if (MultiMonData.pMonitors)
	{
		p = MultiMonData.pMonitors;
		i = MultiMonData.cMonitors;
		while (--i)
		{
			if (p->Name) DFREE(p->Name);
			++p;
		}

		DCLEAR(MultiMonData.pPriMon);
		DFREE(MultiMonData.pMonitors);
	}
}

bool LSGetMonitorByNameProc(LSMONITOR Mon,LPARAM Name)
{
	/* return false (and exit LSForEachMonitor with Mon) if: */ 
	return 
		/* only one monitor, or ran out of monitor names */ 
		Mon->Name!=NULL &&
		/* monitor name matches                          */ 
		lstrcmpi(Mon->Name,reinterpret_cast<const char *>(Name))!=0;
}

//
// lookup monitor by name
//
// This can return LSMONITOR_NONE if no monitor matches
// or LSMONITOR_ALL if the special name "all" is given.
//
LSMONITOR LSGetMonitor(const char *name)
{
#if(0)
	s_MonitorData *p;
	int i;
#endif

	/* primary monitor if not specified */ 
	if (name==NULL || *name==0)
	{
		ASSERTR(MultiMonData.pPriMon!=NULL,LSMONITOR_NONE);
		return (MultiMonData.pPriMon);
	}
	/* all = total combined area */ 
	if (lstrcmpi(name,"all")==0 || (name[0]=='0' && name[1]==0))
	{
		return (LSMONITOR_ALL);
	}

	ASSERTR(MultiMonData.pMonitors!=NULL,LSMONITOR_NONE);

	return LSForEachMonitor(&LSGetMonitorByNameProc,reinterpret_cast<LPARAM>(name));
#if(0)
	/* reference by name */ 
	p = MultiMonData.pMonitors;
	i = MultiMonData.cMonitors;
	while (--i)
	{
		/* NULL monitor name is either only monitor, or after we ran out of names */ 
		/* return this one rather than just failing and having to guess           */ 
		if (p->Name==NULL || lstrcmpi(name,p->Name)==0)
		{
			return (p);
		}
		++p;
	}
	/* give up */ 
	return (LSMONITOR_NONE);
#endif
}

//
// get rectangle defining edges of visible area on screen
//
bool LSGetMonitorScreenRect(LSMONITOR p,LPRECT r)
{
	if (p==LSMONITOR_NONE) return false; /* fail -> r is unchanged */ 
	if (p==LSMONITOR_ALL)
	{
		CopyRect(r,&MultiMonData.VirtualArea);
		return true;
	}
	CopyRect(r,&p->mInfo.rcMonitor);
	return true;
}

//
// get rectangle defining edges of maximized window area
//
bool LSGetMonitorDeskRect(LSMONITOR p,LPRECT r)
{
	if (p==LSMONITOR_NONE) return false; /* fail -> r is unchanged */ 
	if (p==LSMONITOR_ALL)
	{
		CopyRect(r,&MultiMonData.VirtualArea);
		return true;
	}
	/* get from system to make sure it's up to date */ 
	dGetMonitorInfo(p->Handle,const_cast<MONITORINFO *>(&p->mInfo));
	CopyRect(r,&p->mInfo.rcWork);
	return true;
}

//
// get handle for window for use with api calls
//
HMONITOR LSGetMonitorHandle(LSMONITOR p)
{
	if (p==LSMONITOR_NONE
		||p==LSMONITOR_ALL) return NULL;

	return p->Handle;
}

//
// execute user defined code for each monitor
//
LSMONITOR LSForEachMonitor(MonitorProc *UserMonitorProc,LPARAM lParam)
{
	s_MonitorData *pMonitor;
	int nLeft;

	pMonitor = MultiMonData.pMonitors;
	nLeft = MultiMonData.cMonitors;
	while (--nLeft)
	{
		if (UserMonitorProc(pMonitor,lParam)!=true) return pMonitor;

		++pMonitor;
	}
	return LSMONITOR_NONE;
}

