#ifndef __ACTIVETASKS_H_
#define __ACTIVETASKS_H_

#define LM_GETLSOBJECT 9400
#define LM_WINDOWCREATED 9501
#define LM_WINDOWDESTROYED 9502
#define LM_WINDOWACTIVATED 9504
#define LM_REDRAW 9506


#define TMR_UPDATE 1

const int MAXLEN = 1024;

struct TaskType
{
	PTSTR appTitle;
	PTSTR appClass;
	long x, y;
	HBITMAP pix;
	HICON icon;
	HWND hwnd;
	HWND appHandle; // Handles all mouse interaction, and display looks in terms of activation and minimize etc.
	HWND appHandle2; // for top level windows that have an owner, and so use two different HWND's for various things, used for title and such. This is the -true- window, but not always the one the user is interacting with.
	BOOL IsActive;
	BOOL IsCustomIcon;
	BOOL IsIconic;
	BOOL IsMoved;
};

struct TasksSettings
{
	//Main Task Settings
	int Direction, Display, DragDistance, MaxTiles, SetTimer, SpacingX, SpacingY, Transparency, WrapCount, WrapDirection, zOrder;
	int Height, Width, X, Y;
	int IconSize, IconX, IconY, MinIconX, MinIconY, SelIconX, SelIconY;
	int PixX, PixY, MinPixX, MinPixY, SelPixX, SelPixY;

	BOOL AutoArrange, HideMinAppBar, MoveAll, NoMinimizeOnClick, NoMove, Sort, StartHidden, UseSystemHook;
	BOOL HighLightMinimized, HighLightSelected, NoHints, NoIcons, UseWindowsSettings;

	COLORREF BgColor, DarkColor, LightColor, MinBgColor, MinDarkColor, MinLightColor, SelBgColor, SelDarkColor, SelLightColor;

	HBITMAP BgImage, MinBgImage, SelBgImage;

	PTSTR MButton3, MButton2, MButton1, EmptyCmd;

	HWND DockWindow;

	//Title Task Settings
	int TitleHeight, TitleWidth, TitleMinHeight, TitleMinWidth, TitleSelHeight, TitleSelWidth;
	int TitleX, TitleY, TitleMinX, TitleMinY, TitleSelX, TitleSelY;
	int TitleIconX, TitleIconY, TitleMinIconX, TitleMinIconY, TitleSelIconX, TitleSelIconY;
	int TitlePixX, TitlePixY, TitleMinPixX, TitleMinPixY, TitleSelPixX, TitleSelPixY;
	int TitleFontSize, TitleMinFontSize, TitleSelFontSize;

	BOOL Titles, TitleItalicize, TitleNoEllipsis, TitleUnderline, TitleAlignCenter, TitleMinimized, TitleMinItalicize, TitleMinNoEllipsis, TitleMinUnderline, TitleMinAlignCenter, TitleSelected, TitleSelItalicize, TitleSelNoEllipsis, TitleSelUnderline, TitleSelAlignCenter;

	PTSTR TitleFont, TitleMinFont, TitleSelFont;

	COLORREF TitleBgColor, TitleDarkColor, TitleFontColor, TitleLightColor, TitleMinBgColor, TitleMinDarkColor, TitleMinFontColor, TitleMinLightColor, TitleSelBgColor, TitleSelDarkColor, TitleSelFontColor, TitleSelLightColor;
};

struct ClassList
{
	PTSTR match; // string to look for in class name or title
	PTSTR name; // substitute class name
};

struct IconList
{
	PTSTR match; // string to look for in titlebar, or class name
	PTSTR name; // path to icon
	int icon; // icon # to load when name is found
};

struct AddList
{
	PTSTR match; // string to look for in titlebar, or class name
};

struct IgnoreList
{
	PTSTR match; // string to look for in titlebar, or class name
};

struct PixList
{
	PTSTR match; // string to look for in titlebar, or class name
	PTSTR pix; // path to pix to load
};

struct WrapCmdList
{
	int index;
	PTSTR cmd;
};

#ifdef __cplusplus
	extern "C" {
#endif
	__declspec( dllexport ) int initModuleEx( HWND, HINSTANCE, LPCTSTR);
	__declspec( dllexport ) void quitModule( HINSTANCE );
#ifdef __cplusplus
	}
#endif


#endif /*__ACTIVETASKS_H_*/

