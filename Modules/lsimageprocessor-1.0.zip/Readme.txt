LSImageProcessor-1.0
----------------
+DESCRIPTION+
This module brings advanced image processing features to litestep, such as the ability to resize and save images regardless of the type (within reason).
It was spawned from the need to automate image handling in advanced themes and it makes a heavy use of the ImageMagick library (build into the module with static linking).

+SUPPORTED FILETYPES+
Most of file types supported by ImageMagick (all should work, but I have not checked all of them).

+BANGS+
!ImageCheckExistence STRING
STRING: Path in the file system.
- Looks for the existence of the given file in the filesystem path provided and sets the PictureResult EVAR to true if exists, false if not. This EVAR should be checked right away because it is used for all result passings. This bang is not restricted to images but can check the existence of all files and folders.

!ImageScaleAndCopy STRING STRING WIDTH HEIGHT
STRING: Path of the source image.
STRING: Path of the destination image. If file already exists, it will be overwritten.
WIDTH: Width of the destination image in pixels or percents of the source pictures width.
HEIGHT: Height of the destination picture in pixels or percents of the source pictures height.
- Creates a new image in the destination path by modifying the image in the source path by scaling it to given values. Already existing destination image will be overwritten. This function will check for the existance of the source image before anything is done.
PictureResult is set to FALSE if not successful (for whatever reason) or TRUE if scaling and writing was successful.

!ImageGetDimensions STRING
STRING: Path of the target image.
- Finds out the dimensions of the target image, if it exists, and saves them to ImageWidth and ImageHeight EVARS as well as sets ImageResult to true. These EVARS can be overwritten at any time by other bangs that need them, so they should be checked immediately. If no target picture exists the bang will set the dimension EVARS to 0 and PictureResult to false.

+EVARS+
ImageInfoAuthor
ImageInfoName
ImageInfoVersion
- Information about the module.

ImageResult
- Used to pass information from the module to user. Is either TRUE or FALSE depending the success of previous operation.

ImageWidth and ImageHeight
- Image dimensions found by the module and passed on to the user. Never used for internal messaging, only to set results.

+FUTURE PLANS+
ImageVocal EVAR
- Let's the user decide if debug information messages should be shown.

Image creation
- Add an interface to use VisualMagick's image creation features.

Image editing
- Give access to VisualMagick's image editing features.

Type conversion
- Let the user convert files from one type to another (possibly by just writing it out with a new extension).

+CONTACT+
If you have questions, requests or bug reports you can contact me through LS-Universe forums or by email: draugo.silverscale@gmail.com.

+VERSION HISTORY+
1.0
- First released version