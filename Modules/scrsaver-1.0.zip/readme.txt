SCRSAVER.DLL 1.0
Screen Saver Bang Commands:
---------------------------

!ScreenSaver
!ScreenSaverEnable
!ScreenSaverDisable
!ScreenSaverToggle


------------------------------------
mailto: pavel.vitis@seznam.cz
www   : http://come.to/pavel.vitis/
