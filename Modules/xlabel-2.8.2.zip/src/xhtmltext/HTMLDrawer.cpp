// HTMLDrawer.cpp: implementation of the CHTMLDrawer class.
//
//////////////////////////////////////////////////////////////////////
// (c) Jerome Sopocko 2003
// this code worked last time I saw it
//////////////////////////////////////////////////////////////////////
// v1.0 : 25/3/2003 
//        First version
// v1.1 : 11/4/2003
//        Added support for <P> <A HREF> and <CENTER>
//        Corrected alignment of fonts of different sizes
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "HTMLDrawer.h"

#include "HTMLAtom.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHTMLDrawer::CHTMLDrawer()
{

}

CHTMLDrawer::~CHTMLDrawer()
{
	CHTMLAtom::DeleteArray(m_arrDisplayAtoms);
}

/////////////////////////////////////////////////////////////
// DrawText : static implementation
/////////////////////////////////////////////////////////////
// Parameters:
// pDC : Device context
// strText: Text to be drawn
// fntDefault : Default font to be used
// rctPosition : Rectangle in which the text is to be drawn
// nAlignment: 0 (left) or 1 (centered) or 2 (right)
/////////////////////////////////////////////////////////////
void CHTMLDrawer::DrawText(CDC * pDC, const CString & strText,const CHTMLFont & fntDefault,CRect & rctPosition,short nAlignment,short nVAlignment, bool lineBreak)
{
	// Find where each item is to be drawn
	CObArray arrDisplayAtoms;
	FindDisplayAtoms(pDC, strText,fntDefault,rctPosition,nAlignment,nVAlignment,lineBreak,arrDisplayAtoms);

	// Draw them (the highlight settings will not be used)
	DrawAtoms(pDC,arrDisplayAtoms);

	// Free memory
	CHTMLAtom::DeleteArray(arrDisplayAtoms);
}

POINT CHTMLDrawer::MeasureText(CDC * pDC, const CString & strText,const CHTMLFont & fntDefault,CRect & rctPosition,short nAlignment,short nVAlignment, bool lineBreak)
{
	POINT returnValues;
	int maxWidth = 0;
	int maxHeight = 0;

	CObArray arrDisplayAtoms;
	FindDisplayAtoms(pDC, strText,fntDefault,rctPosition,nAlignment,nVAlignment,lineBreak,arrDisplayAtoms);

	for ( int nAtom = 0; nAtom < arrDisplayAtoms.GetSize(); nAtom++ )
	{
		CHTMLAtom * pAtom = (CHTMLAtom *) arrDisplayAtoms.GetAt(nAtom);
	
		if (nAlignment == 0 || nAlignment == 1)
		{
			if (maxWidth < pAtom->GetPosition().right)
				maxWidth = pAtom->GetPosition().right;
		}
		else
		{
			if (maxWidth > pAtom->GetPosition().left)
				maxWidth = pAtom->GetPosition().left;
		}

		if (maxHeight < pAtom->GetPosition().bottom)
			maxHeight = pAtom->GetPosition().bottom;
	}

	// Free memory
	CHTMLAtom::DeleteArray(arrDisplayAtoms);

	if (nAlignment == 1)
		maxWidth = maxWidth*2;
	else if (nAlignment == 2)
		maxWidth = -maxWidth;

	returnValues.x = maxWidth;
	returnValues.y = maxHeight;

	return returnValues;
}

/////////////////////////////////////////////////////////////
// Prepare Draw : caches the atoms so the repaint would be faster
/////////////////////////////////////////////////////////////
// Parameters:
// pDC : Device context
// strText: Text to be drawn
// fntDefault : Default font to be used
// rctPosition : Rectangle in which the text is to be drawn
// nAlignment: 0 (left) or 1 (centered) or 2 (right)
/////////////////////////////////////////////////////////////
int CHTMLDrawer::PrepareDraw(CDC * pDC, const CString & strText,const CHTMLFont & fntDefault,CRect & rctPosition,short nAlignment,short nVAlignment, bool lineBreak)
{
	// Free memory
	CHTMLAtom::DeleteArray(m_arrDisplayAtoms);
	m_arrAnchors.RemoveAll();

	// Find where each item is to be drawn
	return FindDisplayAtoms(pDC, strText,fntDefault,rctPosition,nAlignment,nVAlignment,lineBreak,m_arrDisplayAtoms,&m_arrAnchors);
}

/////////////////////////////////////////////////////////////
// Draw : draws the cached atoms (call PrepareDraw before)
/////////////////////////////////////////////////////////////
// Parameters:
// pDC : Device context
/////////////////////////////////////////////////////////////
void CHTMLDrawer::Draw(CDC * pDC)
{
	// Draw them
	DrawAtoms(pDC,m_arrDisplayAtoms);
}


int CHTMLDrawer::FindDisplayAtoms(CDC * pDC, const CString & strText,const CHTMLFont & fntDefault,CRect & rctPosition,short nAlignment,short nVAlignment, bool lineBreak, CObArray & arrDisplayAtoms,CObArray * parrAnchors/*=NULL*/)
{
	// Parse the text to break into atoms having the same settings
	CObArray arrAtoms;
	ParseHTMLText(strText,fntDefault,arrAtoms,nAlignment);

	// If no text return
	if ( arrAtoms.GetSize() == 0 )
		return 0;

	// Break into smaller atoms according to end of line
	BreakIntoLines(pDC,arrAtoms,arrDisplayAtoms,rctPosition,parrAnchors,lineBreak);

	CHTMLAtom::DeleteArray(arrAtoms);

	// Find the lowest position to center vertically
	int nLowest = 0;
	for ( int nAtom = 0; nAtom < arrDisplayAtoms.GetSize(); nAtom++)
	{
		CHTMLAtom * pAtom = (CHTMLAtom *) arrDisplayAtoms.GetAt(nAtom);
		if ( pAtom->GetPosition().bottom > nLowest )
			nLowest = pAtom->GetPosition().bottom;
	}

	int nShiftVertically = 0;

	//Vertical Alignment
	if (nVAlignment == 0)
	{
		if ( nLowest < rctPosition.Height() )
			nShiftVertically = 0;
	}
	else if (nVAlignment == 1)
	{
		if ( nLowest < rctPosition.Height() )
			nShiftVertically = (rctPosition.Height()-nLowest) / 2;
	}
	else if (nVAlignment == 2)
	{
		if ( nLowest < rctPosition.Height() )
			nShiftVertically = (rctPosition.Height()-nLowest);
	}

	ApplyAlignments(arrDisplayAtoms,nShiftVertically,rctPosition.right);

	return nLowest+nShiftVertically;
}


void CHTMLDrawer::ParseHTMLText(const CString & strSource,const CHTMLFont & fntDefault,CObArray & arrAtoms,short nDefaultAlignment)
{
	CString strText(strSource);
	CHTMLFont fntCurrent(fntDefault);

	CObArray arrFontStack;
	int nTagStart;
	short nAlignment=nDefaultAlignment;
	bool isLastAtomNewLine=true;
	while ( (nTagStart = strText.Find('<')) != -1 )
	{
		int nTagEnd = strText.Find('>',nTagStart);
		if ( nTagEnd == -1 )
		{
			break;
		}
		if ( AddText(arrAtoms,strText.Left(nTagStart),fntCurrent,nAlignment) )
			isLastAtomNewLine = false;

		CString strTag=strText.Mid(nTagStart+1,nTagEnd-nTagStart-1);
		bool isNewLine=false;
		UpdatePoliceAccordingToTag(strTag,fntCurrent,arrFontStack,isNewLine,nAlignment,nDefaultAlignment,isLastAtomNewLine);
		strText = strText.Mid(nTagEnd+1);
		if ( isNewLine )
		{
			AddText(arrAtoms,_T("\r\n"),fntCurrent,nAlignment);
			isLastAtomNewLine = true;
		}
	}
	if ( !strText.IsEmpty() )
	{
		AddText(arrAtoms,strText,fntCurrent,nAlignment);
	}
	CHTMLFont::DeleteArray(arrFontStack);
}

bool CHTMLDrawer::AddText(CObArray & arrAtoms,const CString & strCodedText,CHTMLFont & polCurrent,short nAlignment)
{
	if ( strCodedText.IsEmpty() )
		return false;

	// Translate &quot; &lt; &gt; and &amp;
	CString strText(strCodedText);

	int nTagStart = 0;
	while ( (nTagStart = strText.Find('&', nTagStart)) != -1 )
	{
		int nTagEnd = strText.Find(';',nTagStart);
	
		if (nTagEnd == -1)
			break;

		CString strEnd=strText.Mid(nTagEnd+1);
		CString strTag=strText.Mid(nTagStart+1,nTagEnd-nTagStart-1);
		strText=strText.Left(nTagStart);
		if ( strTag.CompareNoCase(_T("quot")) == 0 )
			strText+='\"';
		else if ( strTag.CompareNoCase(_T("lt")) == 0 )
			strText+='<';
		else if ( strTag.CompareNoCase(_T("gt")) == 0 )
			strText+='>';
		else if ( strTag.CompareNoCase(_T("amp")) == 0 )
			strText+='&';
		else
		{
			strText+="&";
			strText+=strTag;
			if ( nTagEnd != -1)
				strText+=";";
		}
		strText+=strEnd;
		nTagStart++;
	}

	CHTMLAtom * pAtom=new CHTMLAtom;
	pAtom->SetText(strText);
	pAtom->SetHTMLFont(polCurrent);
	pAtom->SetAlignment(nAlignment);
	arrAtoms.Add(pAtom);

	return true;
}

void CHTMLDrawer::UpdatePoliceAccordingToTag(CString & strTag,CHTMLFont & polCurrent,CObArray & arrFontStack,bool & isNewLine,short & nAlignment,short nDefaultAlignment,bool isLastAtomNewLine)
{
	strTag.TrimLeft();
	strTag.TrimRight();
	if ( strTag.CompareNoCase(_T("b")) == 0 )
	{
		polCurrent.SetBold(true);
	}
	else if ( strTag.CompareNoCase(_T("strong")) == 0 )
	{
		polCurrent.SetBold(true);
	}
	else if ( strTag.CompareNoCase(_T("/b")) == 0 )
	{
		polCurrent.SetBold(false);
	}
	else if ( strTag.CompareNoCase(_T("/strong")) == 0 )
	{
		polCurrent.SetBold(false);
	}
	else if ( strTag.CompareNoCase(_T("i")) == 0 )
	{
		polCurrent.SetItalic(true);
	}
	else if ( strTag.CompareNoCase(_T("/i")) == 0 )
	{
		polCurrent.SetItalic(false);
	}
	else if ( strTag.CompareNoCase(_T("em")) == 0 )
	{
		polCurrent.SetItalic(true);
	}
	else if ( strTag.CompareNoCase(_T("/em")) == 0 )
	{
		polCurrent.SetItalic(false);
	}
	else if ( strTag.CompareNoCase(_T("u")) == 0 )
	{
		polCurrent.SetUnderline(true);
	}
	else if ( strTag.CompareNoCase(_T("/u")) == 0 )
	{
		polCurrent.SetUnderline(false);
	}
	else if ( strTag.CompareNoCase(_T("br")) == 0 )
	{
		isNewLine = true;
	}
	else if ( strTag.Left(1).CompareNoCase(_T("p")) == 0 )
	{
		if ( !isLastAtomNewLine)
			isNewLine = true;

		if ( strTag.GetLength() == 1 )
			return;
		CStringArray arrNames,arrValues;
		FindTagAttributes(strTag.Mid(2),arrNames,arrValues);

		for ( int nAttribute = 0; nAttribute < arrNames.GetSize(); nAttribute++)
		{
			if ( arrNames.GetAt(nAttribute).CompareNoCase(_T("align")) == 0 )
			{
				CString strValue(arrValues.GetAt(nAttribute));
				if ( strValue.CompareNoCase(_T("left")) == 0 )
				{
					nAlignment=0;
				}
				else if ( strValue.CompareNoCase(_T("center")) == 0 )
				{
					nAlignment=1;
				}
				else if ( strValue.CompareNoCase(_T("right")) == 0 )
				{
					nAlignment=2;
				}
			}
		}
	}
	else if ( strTag.CompareNoCase(_T("/p")) == 0 )
	{
		if ( !isLastAtomNewLine)
			isNewLine = true;
		nAlignment=nDefaultAlignment;
	}
	else if ( strTag.CompareNoCase(_T("center")) == 0 )
	{
		if ( !isLastAtomNewLine)
			isNewLine = true;
		nAlignment=1;
	}
	else if ( strTag.CompareNoCase(_T("/center")) == 0 )
	{
		if ( !isLastAtomNewLine)
			isNewLine = true;
		nAlignment=nDefaultAlignment;
	}
	else if ( strTag.Left(4).CompareNoCase(_T("font")) == 0 )
	{
		// Store previous police and color in stack
		arrFontStack.Add((CObject *) new CHTMLFont(polCurrent));

		CStringArray arrNames,arrValues;
		FindTagAttributes(strTag.Mid(4),arrNames,arrValues);

		for ( int nAttribute = 0; nAttribute < arrNames.GetSize(); nAttribute++)
		{
			CString strValue(arrValues.GetAt(nAttribute));
			if ( !strValue.IsEmpty() )
			{
				CString strName(arrNames.GetAt(nAttribute));

				// Update current police
				if ( strName.CompareNoCase(_T("face")) == 0 )
				{
					polCurrent.SetName(strValue);
				}
				else if ( strName.CompareNoCase(_T("size")) == 0 )
				{
					int nSize = ToLong(strValue);
				
					polCurrent.SetSize(nSize);
				}
				else if ( strName.CompareNoCase(_T("color")) == 0 )
				{
					if ( strValue[0] == '#' )
					{
						strValue = strValue.Mid(1);
						if ( strValue.GetLength() < 6 )
						{
							CString strTemp;
							strTemp.Format(_T("%0*d%s"),6-strValue.GetLength(),0,strValue);
							strValue = strTemp;
						}
						polCurrent.SetColor(RGB(FromHex(strValue.Left(2)),FromHex(strValue.Mid(2,2)),FromHex(strValue.Mid(4,2))));
					}
				}
			}
		}
	}
	else if ( strTag.Left(5).CompareNoCase(_T("/font")) == 0 )
	{
		if ( arrFontStack.GetSize() >0 )
		{
			CHTMLFont * pFont = (CHTMLFont *) arrFontStack.GetAt(arrFontStack.GetSize()-1);
			polCurrent = *pFont;
			delete pFont;
			arrFontStack.SetSize(arrFontStack.GetSize()-1);
		}
	}
}

void CHTMLDrawer::FindTagAttributes(const CString & strAttributes,CStringArray & arrNames,CStringArray & arrValues)
{
	CString strInfo = strAttributes;
	while ( true )
	{
		int nPos = strInfo.Find(_T('='));
		if ( nPos == -1 )
			break;

		// Find the name of the property
		CString strName = strInfo.Left(nPos);
		strName.TrimLeft();
		strName.TrimRight();

		// Find the start of the value
		strInfo = strInfo.Mid(nPos+1);
		while ( strInfo[0] == ' ')
			strInfo = strInfo.Mid(1);

		// Find the value
		CString strValue;
		if ( strInfo[0] == '"' )
		{
			nPos = strInfo.Find('"',1);
			if ( nPos != -1 )
			{
				strValue=strInfo.Mid(1,nPos-1);
				strInfo = strInfo.Mid(nPos+1);
			}
		}
		else
		{
			nPos = strInfo.Find(' ');
			if ( nPos != -1 )
			{
				strValue=strInfo.Left(nPos);
				strInfo = strInfo.Mid(nPos+1);
			}
			else
			{
				strValue=strInfo;
				strInfo.Empty();
			}
		}

		arrNames.Add(strName);
		arrValues.Add(strValue);
	}
}


void CHTMLDrawer::BreakIntoLines(CDC * pDC,CObArray & arrAtoms,CObArray & arrDisplayAtoms,CRect & rctPosition,CObArray * parrAnchors, bool lineBreak)
{
	// Select the font
	CFont* pCurrentFont = NULL;
	CFont* pOldFont=NULL;

	int nY = rctPosition.top;
	int nX = rctPosition.left;
	int nXMax = rctPosition.right;
	int nStartLineAtom = 0;
	int nLowestAscent = 0;
	int nLine = 0;
	for ( int nAtom = 0; nAtom < arrAtoms.GetSize(); nAtom++)
	{
		CHTMLAtom * pAtom = (CHTMLAtom *) arrAtoms.GetAt(nAtom);

		// Find if there is a line break in the text
		bool isLineBreak = false;
		int nPos = pAtom->GetText().Find(_T("\r\n"));
		if ( nPos != -1 )
		{
			// Split this atom into 2
			CString strTextBefore = pAtom->GetText().Left(nPos);
			CString strTextAfter = pAtom->GetText().Mid(nPos+2);
			
			if ( !strTextAfter.IsEmpty() )
			{
				CHTMLAtom * pNewAtom = new CHTMLAtom(*pAtom);
				pNewAtom->SetText(strTextAfter);
				arrAtoms.InsertAt(nAtom+1,pNewAtom);
			}
			pAtom->SetText(strTextBefore);

			isLineBreak = true;
		}

		
		// Select the current font
		if ( pCurrentFont == NULL )
		{
			pCurrentFont = pAtom->GetHTMLFont().GetFont(pDC);
			pOldFont = pDC->SelectObject(pCurrentFont);
		}
		else
		{
			CFont * pNewFont = pAtom->GetHTMLFont().GetFont(pDC);
			pDC->SelectObject(pNewFont);
			delete pCurrentFont;
			pCurrentFont = pNewFont;
		}

		// Find the size of the text
		CString strTextToWrite = pAtom->GetText();
		while ( !strTextToWrite.IsEmpty() )
		{
			bool isCreateNewLine = false;
			CSize sizText = pDC->GetTextExtent(strTextToWrite);

			// If it does not fit in the current line
			CString strPart=strTextToWrite;

			if (lineBreak)
			{
				isCreateNewLine = false;
				while ( nX + sizText.cx >= nXMax)
				{
					RemoveLastWord(strPart);
					sizText = pDC->GetTextExtent(strPart);
					isCreateNewLine = true;
					if ( strPart.IsEmpty())
						break;
				}

				// If nothing fits, 
				if ( strPart.IsEmpty() )
				{
					// If the current line is empty
					if ( nStartLineAtom == arrDisplayAtoms.GetSize() )
					{
						// We have to break up anywhere
						strPart=strTextToWrite[0];
						for ( int nChar = 1; nChar < strTextToWrite.GetLength(); nChar++)
						{
							strPart+=strTextToWrite[nChar];
							sizText = pDC->GetTextExtent(strPart);
							if ( nX + sizText.cx > nXMax)
							{
								strPart = strPart.Left(strPart.GetLength()-1);
								break;
							}
						}
					}
				}
			}

			if ( !strPart.IsEmpty() )
			{
				// We can draw strPart
				sizText = pDC->GetTextExtent(strPart);
				CRect rctTextPosition(nX,nY,nX+sizText.cx,nY+sizText.cy);

				// Get the text metrics so we can align text of different sizes
				TEXTMETRIC tmMetrics;
				pDC->GetTextMetrics(&tmMetrics);

				CHTMLAtom * pDisplayAtom = new CHTMLAtom(*pAtom);
				pDisplayAtom->SetText(strPart);
				pDisplayAtom->SetPosition(rctTextPosition);
				pDisplayAtom->SetAscent(tmMetrics.tmAscent);
				pDisplayAtom->SetLine(nLine);
				arrDisplayAtoms.Add(pDisplayAtom);

				nX = rctTextPosition.right;
				strTextToWrite = strTextToWrite.Mid(strPart.GetLength());

				// Find the lowest position on the lign to align properly
				if ( tmMetrics.tmAscent> nLowestAscent )
					nLowestAscent = sizText.cy;
			}

			if (lineBreak)
			{
				if ( isCreateNewLine )
				{
					// Align to lowest position
					AlignLineAccordingToAscent(arrDisplayAtoms,nLowestAscent,nStartLineAtom);

					CreateNewLine(pDC,arrDisplayAtoms,nStartLineAtom,nY);
					nX=rctPosition.left;
					strTextToWrite.TrimLeft();
					nLine++;
				}
			}
		}	
		if ( isLineBreak )
		{
			// Align to lowest position
			AlignLineAccordingToAscent(arrDisplayAtoms,nLowestAscent,nStartLineAtom);
			nLowestAscent=0;

			CreateNewLine(pDC,arrDisplayAtoms,nStartLineAtom,nY);
			nX=rctPosition.left;
			nLine++;
		}
	}

	// Align to lowest position
	AlignLineAccordingToAscent(arrDisplayAtoms,nLowestAscent,nStartLineAtom);
	nLowestAscent=0;

	if ( pOldFont )
		pDC->SelectObject(pOldFont);
	delete pCurrentFont;
}

void CHTMLDrawer::AlignLineAccordingToAscent(CObArray & arrDisplayAtoms,int nLowestAscent,int nStartLineAtom)
{
	for ( int nAtom = nStartLineAtom; nAtom < arrDisplayAtoms.GetSize(); nAtom++)
	{
		CHTMLAtom * pAtom = (CHTMLAtom *) arrDisplayAtoms.GetAt(nAtom);
		if ( pAtom->GetAscent() != nLowestAscent )
		{
			CRect * pRect = pAtom->GetAdrPosition();
			*pRect+= CPoint(0,nLowestAscent-pAtom->GetAscent());
		}
	}
}


void CHTMLDrawer::CreateNewLine(CDC * pDC,CObArray & arrDisplayAtoms,int & nStartLineAtom,int & nY)
{
	// If no atom has been created for this line, create a dummy empty atom 
	if ( nStartLineAtom == arrDisplayAtoms.GetSize() )
	{
		CString strText=_T(" ");
		CSize sizText = pDC->GetTextExtent(strText);
		CRect rctTextPosition(0,nY,0+sizText.cx,nY+sizText.cy);

		CHTMLAtom * pDisplayAtom = new CHTMLAtom;
		pDisplayAtom->SetText(strText);
		pDisplayAtom->SetPosition(rctTextPosition);
		arrDisplayAtoms.Add(pDisplayAtom);

		nY=rctTextPosition.bottom+1;
		nStartLineAtom = arrDisplayAtoms.GetSize();

		return;
	}

	// Find the lowest atom on this line
	int nMaxBottom = nY;
	for ( int nAtom = nStartLineAtom; nAtom < arrDisplayAtoms.GetSize(); nAtom++)
	{
		CHTMLAtom * pLineAtom=(CHTMLAtom *) arrDisplayAtoms.GetAt(nAtom);
		if ( pLineAtom->GetPosition().bottom > nMaxBottom )
		{
			nMaxBottom = pLineAtom->GetPosition().bottom;
		}
	}
	/*
	// Align them to the lowest
	for ( nAtom = nStartLineAtom; nAtom < arrDisplayAtoms.GetSize(); nAtom++)
	{
		CHTMLAtom * pLineAtom=(CHTMLAtom *) arrDisplayAtoms.GetAt(nAtom);
		CRect rctPosition = pLineAtom->GetPosition();
		int nShift = nMaxBottom - rctPosition.bottom;
		rctPosition.top+=nShift;
		rctPosition.bottom+=nShift;
		pLineAtom->SetPosition(rctPosition);
	}
	*/
	nY=nMaxBottom+1;
	nStartLineAtom = arrDisplayAtoms.GetSize();
}

void CHTMLDrawer::RemoveLastWord(CString & strText)
{
	bool isOneCharRemoved = false;
	while ( strText.GetLength() != 0 )
	{
		TCHAR car = strText[strText.GetLength()-1];
		if ( ( ( car < 'a' ) || ( car > 'z' ) ) && ( ( car < 'A' ) || ( car > 'Z' ) ) )
		{
			if (!isOneCharRemoved )
				strText = strText.Left(strText.GetLength()-1);
			break;
		}
		strText = strText.Left(strText.GetLength()-1);
		isOneCharRemoved = true;
	}
}

void CHTMLDrawer::ApplyAlignments(CObArray & arrDisplayAtoms,int nShiftVertically,int nRight)
{
	int nLine=-1;
	int nShiftX = 0;
	for ( int nAtom = 0; nAtom < arrDisplayAtoms.GetSize(); nAtom++)
	{
		CHTMLAtom * pAtom = (CHTMLAtom *) arrDisplayAtoms.GetAt(nAtom);

		// If we have changed line
		if ( nLine != pAtom->GetLine() )
		{
			nLine = pAtom->GetLine();
			// If there is an alignent for this line
			if ( pAtom->GetAlignment() == 0 )
			{
				nShiftX = 0;
			}
			else
			{
				// Find the extent of the line
				int nMaxRight = pAtom->GetPosition().right;
				for ( int nFollowingAtom = nAtom+1; nFollowingAtom < arrDisplayAtoms.GetSize(); nFollowingAtom++)
				{
					CHTMLAtom * pFollowingAtom = (CHTMLAtom *) arrDisplayAtoms.GetAt(nFollowingAtom);
					if ( nLine != pFollowingAtom->GetLine() )
						break;
					nMaxRight = pFollowingAtom->GetPosition().right;
				}
				if (pAtom->GetAlignment() == 1) 
					nShiftX = (nRight - nMaxRight)/2;
				else
					nShiftX = nRight - nMaxRight-1;
			}
		}

		// Change the position of the atom
		*pAtom->GetAdrPosition() += CPoint(nShiftX,nShiftVertically);
	}
}

void CHTMLDrawer::DrawAtoms(CDC * pDC,CObArray & arrDisplayAtoms)
{
	// Prepare the settings to be restored
	CFont* pCurrentFont = NULL;
	CFont* pOldFont;
	COLORREF rgbOldColor;
	pDC->SetBkMode(TRANSPARENT);

	for ( int nAtom = 0; nAtom < arrDisplayAtoms.GetSize(); nAtom++)
	{
		CHTMLAtom * pAtom = (CHTMLAtom *) arrDisplayAtoms.GetAt(nAtom);

		CHTMLFont htmlFont(pAtom->GetHTMLFont());

		// Select the font
		if ( pCurrentFont == NULL )
		{
			pCurrentFont = htmlFont.GetFont(pDC);
			pOldFont = pDC->SelectObject(pCurrentFont);
			rgbOldColor  = pDC->SetTextColor(htmlFont.GetColor());
		}
		else
		{
			CFont * pNewFont = htmlFont.GetFont(pDC);
			pDC->SelectObject(pNewFont);
			delete pCurrentFont;
			pCurrentFont = pNewFont;
			pDC->SetTextColor(htmlFont.GetColor());
		}

		// Draw the text
		pDC->DrawText(pAtom->GetText(),pAtom->GetAdrPosition(),DT_LEFT | DT_NOPREFIX | DT_SINGLELINE);
	}

	// Restore the settings
	pDC->SelectObject(pOldFont);
	pDC->SetTextColor(rgbOldColor);
	delete pCurrentFont;
}


long CHTMLDrawer::FromHex(const CString & strHex)
{
	CString strHexa(strHex);
	strHexa.TrimRight();
	strHexa.TrimLeft();
	long nRes=0;
	long nBase=1;
	for ( int nChar = strHexa.GetLength()-1; nChar >= 0; nChar--)
	{
		switch (strHexa[nChar])
		{
		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			nRes+=(strHexa[nChar]-'0')*nBase;
			break;
		case 'a':
		case 'b':
		case 'c':
		case 'd':
		case 'e':
		case 'f':
			nRes+=(10+strHexa[nChar]-'a')*nBase;
			break;
		case 'A':
		case 'B':
		case 'C':
		case 'D':
		case 'E':
		case 'F':
			nRes+=(10+strHexa[nChar]-'A')*nBase;
			break;
		}
		nBase*=16;
	}
	return nRes;
}


long CHTMLDrawer::ToLong(LPCTSTR lpszText)
{
	ASSERT(lpszText != NULL);

	while (*lpszText == ' ' || *lpszText == '\t')
		lpszText++;
	TCHAR chFirst = lpszText[0];
	long l;
	l = _tcstol(lpszText, (LPTSTR*)&lpszText, 10);

	if (l == 0 && chFirst != '0')
		return 0;   // could not convert

	while (*lpszText == ' ' || *lpszText == '\t')
		lpszText++;
	if (*lpszText != '\0')
		return 0;   // not terminated properly

	// all ok
	return l;
}


bool CHTMLDrawer::IsPointInAnchor(CPoint & pntMouse,CHTMLAtom *& pAnchor)
{
	for ( int nAnchor = 0; nAnchor < m_arrAnchors.GetSize(); nAnchor++)
	{
		pAnchor = (CHTMLAtom *) m_arrAnchors.GetAt(nAnchor);
		if( pAnchor->GetPosition().PtInRect(pntMouse) )
			return true;
	}

	return false;
}
