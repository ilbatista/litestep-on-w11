#if !defined(__TEXTURE_H)
#define __TEXTURE_H

class Texture
{
public:
	virtual ~Texture() {}
	virtual void configure(const string &prefix, const string &subKey) = 0;
	virtual void apply(HDC hDC, int x, int y, int width, int height, int transparencyMode, int imageType) = 0;
	virtual void applyAnim(HDC hDC, int x, int y, int width, int height, int transparencyMode, int imageType, int count) = 0;

	virtual bool isTransparencyNeeded() = 0;
};

#endif
