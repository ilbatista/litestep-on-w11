LSEyes 1.2     (c) 1998 Christoph Handel
========================================
    The famous X-Eyes for Litestep








What it does:

A Pair of Eyes watching your Mousearrow. 



Installation:

Just put the DLL in your LS-Directory, the BMP in your IMG-Dir
and this in your RC
*Wharf text LSEyes.bmp @c:\Litestep\lssdk.dll

To set Colors and Radius put this in your modules.ini
[LSEyes]
BallColor = 0xFF0000
BallPenColor = 0x00FF00
ELLIPSE_A =   7;
ELLIPSE_B =   22;
BALL_RADIUS = 5;

BallColor:     The Color used for filling the Eyeball
BallPenColor:  The Color used for drawing the Line of the Eyeball
ELLIPSE_A:     The Horizontal ellipse-radius  for the ball-point
ELLIPSE_B:     The vertical ellispe-radius for the ball-point
BALL_RADIUS:   The Radius of the ball-point

The Ellipse is the bounding for the Eyeball-Center. You need to substract the Ball-Radius.

All colors are given in hex Values. blue-green-red. Wrong colors will
hopefully result in a normal black Eyeballs and no crash.

I only draw the two Eyeballs. For a complete eye, you need to use a 
background (like LSEyes.bmp). Transparency is supported.



Contact:

eMail to handel@hrzpub.tu-darmstadt.de
SEND comments, questions, bug-reports, and hints! And 
if you like the programm a PICTUREPOSTCARD to:

   christoph handel
   pallaswiesenstr.14
   d-64289 darmstadt
   germany




Known Bugs:

Eyes won't move when Arrow is in Titlebar or Scrollbar of a window 
(this IS a windows-bug, there's no MouseMessage sent, blame Microsoft)






Technical:

Made with Delphi 2.0. Tested under NT 4.0 SP1 and SP3.
This is not a port of the X-Eyes. I don't have the source for that...
I made it all by myself.




Thanks:

Bryan Kilian for the port of the LSSDK and for explaining me the Bitmap
The LS-Developers for the great Shell



story:


26.09.98 1.2   I won't draw the Eye's anymore (The white surrounding). Instead I
         will use the background bitmap. You need to specify such a bitmap. Or you
         will only see two black balls moving arround. A Standard is included.
16.09.98 1.1b  Ok, the code is reduced. Delphi is a bit silly. Now I use API-Calls
         for reading the Ini-File.
13.09.98 1.1   Colors read from Modules.ini (Who wanted this feature? DLL is 
         50k instead of 30k)
24.08.98 1.0   background is painted (thanks to Bryan)
19.08.98 �0.91 fixed the HookChain (what a silly misstake).
18.08.98 Ready with �0.9 First Public Release.
         Found an untrapped Exception.
17.08.98 Success in defining global DLL-Variables using memory-mapped files.
16.08.98 Started programming.
15.08.98 Got LS �23e. Found a LSSDK for delphi. Just missed the cdecl.
10.06.98 Trying to transport LSSDK to Delphi. Failed.

