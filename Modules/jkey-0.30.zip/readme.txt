===================================================
===================================================
== jKey.dll - nice hotkeys ========================
===================================================
===================================================
====== Written by: ================================
================== Chris Rempel (jugg) ============
===================================================
================== http://jugg.logicpd.com/ =======
================== jugg@dylern.com ================
===================================================
===================================================
= Version: 0.30 = Release Date: 00.08.26 ==========
===================================================
===================================================

-=ToC=-
I. Introduction
II. Installation
III. Information
 A} Commands
 B} Changes
IV. Tips & Tricks
V. Disclaimer


=====================
== I. Introduction ==
=====================
===================================================

jKey.dll is Hotkey manager for Win32 Shells. jKey
is based off the idea of LiteStep's Hotkey.dll, but
offers more features and configuration options.

=====================
== II. Istallation ==
=====================
===================================================

Extract "jKey.dll" to your LiteStep directory
(c:\litestep\). Open up your step.rc (LiteStep
configuration file) and find the section where all
of your "LoadModule" lines are located. Now, add a
new line that looks like this:

LoadModule c:\litestep\jkey.dll

Of course, adjust the path as necessary. Save your
step.rc and issue the LiteStep Recycle command
(!Recycle).

NOTE: If you are migrating from LiteSteps hotkey
module, and do not want to have to update all of
your "*Hotkey" lines, make sure to set the command
"jKeyUseHotkeyDef" in your configuration file. If
you don't, you have to change all instances of
"*Hotkey" to "*jKey" in your configuration file.


======================
== III. Information ==
======================
===================================================
= A} Commands =
===============

jKeyCtrlEscKey "!Popup"
  - Sets the command to be executed when the
    CTRL+ESC key sequence is executed.

    *Note: "jKeyCtrlEscKey" must be set for it to
           execute anything. Set with no parameters
           to use default setting.

  - Accepts any !Bang command or Executable.

  - Defaults to: "!Popup"


jKeyLWinKey "!Popup"
  - Sets the command to be executed when the
    LEFT WinKey is pressed by itself.

    *Note: Command will be executed after the time
           specified by "jKeyLWinKeyTimeout"
           setting.

    *Note: "jKeyLWinKey" must be set for it to
           execute anything. Set with no parameters
           to use default setting.

  - Accepts any !Bang command or Executable.

  - Defaults to: "!Popup"


jKeyRWinKey "!Popup"
  - Sets the command to be executed when the
    RIGHT WinKey is pressed by itself.

    *Note: Command will be executed after the time
           specified by "jKeyRWinKeyTimeout"
           setting.

    *Note: "jKeyRWinKey" must be set for it to
           execute anything. Set with no parameters
           to use default setting.

  - Accepts any !Bang command or Executable.

  - Defaults to: "!Popup"


jKeyLWinKeyTimeout 750
  - Sets the delay from the time the Left WinKey is
    pressed to the time the command specified by
    "jKeyLWinKey" is executed.

  - Accepts any positive integer in milliseconds.

    *Note: Anything less the 400 will probably will
           cause things to behave irradically.

  - Defaults to: 750


jKeyRWinKeyTimeout 750
  - Sets the delay from the time the Left WinKey is
    pressed to the time the command specified by
    "jKeyLWinKey" is executed.

  - Accepts any positive integer in milliseconds.

    *Note: Anything less the 400 will probably will
           cause things to behave irradically.

  - Defaults to: 750

jKeyNoWarn
  - If Set no warning will be issued when a hotkey
    fails to register correctly.

  - boolean value: true if set, otherwise false.

jKeyUseHotkeyDef
  - If Set the "*Hotkey" definition syntax will be
    used instead of the native "*jKey" definition.
    (See explanation of "*jKey")

  - boolean value: true if set, otherwise false.

*jKey
  - parameters: <modkey> <hotkey> <command>

    <modkey> can be one or more of the following
             seperated by a plus (+) sign.

      CTRL, SHIFT, WIN, ALT

    <hotkey> can be any alpha numeric key or one of
             the following special key identifiers.

        F1, F2, F3, F4, F5, F6
        F7, F8, F9, F10, F11, F12
        NUM0, NUM1, NUM2, NUM3, NUM4
        NUM5, NUM6, NUM7, NUM8, NUM9
        HOME, END, PAGEUP, PAGEDOWN
        INSERT, DELETE, BACKSPACE
        ESCAPE, SPACEBAR, APPS
        LEFT, RIGHT, UP, DOWN

    <command> can be any !Bang command or
              executable that is to be executed
              when the specified key combination
              is pressed.

  - Multiple settings of this command are
    allowed and the maximum number is limited by
    system memory.

  - It is used to define the Hotkeys and the
    commands to be executed when the hotkey
    sequence is pressed.

    *Note: You can substitute "*Hotkey" for "*jKey"
           if you set the following command in your
           configuration file: "jKeyUseHotkeyDef"



===================================================
= B} Changes =
==============

- 0.30 -
--------
  + Initial release.
  + Supports configuration of individual WinKeys
    and Ctrl+Esc sequence.
  + Supports standard LiteStep Hotkey syntax.
  + Supports MS "APPS" key (odd key to the right of
    the right WinKey).



=====================
= IV. Tips & Tricks =
=====================
===================================================
If the LiteStep setting "LSNoShellWarning" (or its
older counterpart "ExplorerNoWarn") is set, then
execution of the individual WinKeys and CtrlEsc
sequence is disabled. (you still use them as
modifier keys)

Just read the rest of this file and you should be
fine.  This module does not behave like the
hotkey.dll module with it default settings. You
must enable certain aspects of it to gain the same
functionality. Like I said. Read the rest of this
file.



=================
= V. Disclaimer =
=================
===================================================

Copyright (C) 1999, Chris Rempel

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT  WARRANTY
OF ANY KIND, EXPRESS OR  IMPLIED, INCLUDING BUT NOT
LIMITED  TO  THE   WARRANTIES  OF  MERCHANTABILITY,
FITNESS  FOR   A   PARTICULAR   PURPOSE   AND  NON-
INFRINGEMENT.  IN  NO  EVENT  SHALL THE  AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,  DAMAGES
OR  OTHER  LIABILITY,   WHETHER  IN  AN  ACTION  OF
CONTRACT,  TORT OR OTHERWISE,  ARISING FROM, OUT OF
OR IN CONNECTION  WITH  THE  SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
