# e:\Perl\ -w
#############################################################################
# lsDrinks 2.3                                                              
# Hacked up by : nf0 <nf0@10500bc.org>                                       
#                                                                           
# Thanks to Charlie <ishamael@orodruin.ddns.org> for making asDrinks        
# Thanks to Flip for making flipsthing.
# Thanks to Spawn@desktopz.org for helping out and making suggestions
# Thanks to Tin_Omin <desktopian.org> for the best site on the net and
# helping the community with with some backends.                           
# Thanks to MrJukes and geekMASTR for provinding community backends.                                                                                                               
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to:
#   the Free Software Foundation, Inc.
#   59 Temple Place - Suite 330
#   Boston, MA  02111-1307, USA.
###############################################################################

require 5.004;
use strict;
use Socket;

my $rcfile   = "lsdrinks.rc";

my %drinkvals;
my $drinkvals = "$rcfile";
open(DRINKVALS, $drinkvals);

 while (<DRINKVALS>) {
 	chomp;
        next if /^\s*\#/;
        next unless /=/;
        my ($key, $value) = split(/=/, $_, 2);
        $value =~ s/(\$(\w+))/$drinkvals{$2}/g;

        $drinkvals{$key} = $value;
        
            }
close(DRINKVALS);

my $startdir    = $drinkvals{maindir};
my $feedback    = $drinkvals{feedback};
my $folderval   = $drinkvals{folderval};
my $pageval     = $drinkvals{pageval};
my $pagename    = $drinkvals{pagename};
my $slashdir 	= $drinkvals{slashdot_dir};
my $fmdir 	= $drinkvals{freshmeat_dir};
my $segdir 	= $drinkvals{segfault_dir};
my $ltdir 	= $drinkvals{linuxtoday_dir};
my $dtdir 	= $drinkvals{desktopian_dir};
my $ttdir 	= $drinkvals{technotronic_dir};
my $gndir 	= $drinkvals{geeknews_dir};
my $bitsdir 	= $drinkvals{bits32_dir};
my $bndir 	= $drinkvals{betanews_dir};
my $atdir 	= $drinkvals{arstechnica_dir};
my $fldir 	= $drinkvals{floach_dir};
my $lscdir 	= $drinkvals{litestepcom_dir};
my $lsodir 	= $drinkvals{litesteporg_dir};  
my $bendir 	= $drinkvals{benews_dir};
my $becdir 	= $drinkvals{beoscentral_dir};
my $thodir 	= $drinkvals{themesorg_dir};
my $scdir 	= $drinkvals{solariscentral_dir};
my $lndir 	= $drinkvals{lancednet_dir};
my $lgdir 	= $drinkvals{linuxgames_dir};
my $ladir 	= $drinkvals{linuxapps_dir};
my $hndir 	= $drinkvals{hackernews_dir};
my $hpndir 	= $drinkvals{happypenguinnews_dir};
my $hpudir 	= $drinkvals{happypenguinupdates_dir};
my $hpadir 	= $drinkvals{happypenguinadd_dir};
my $lqdir 	= $drinkvals{linuxquake_dir};
my $agdir  	= $drinkvals{absolutegamers_dir};
my $l3ddir 	= $drinkvals{linux3d_dir};
my $f3ddir 	= $drinkvals{fullon3d_dir};
my $g3ddir  = $drinkvals{gizmo3d_dir};
my $blndir  = $drinkvals{bluesnews_dir};
my $vedir	  = $drinkvals{voodooextreme_dir};
my $cmdir   = $drinkvals{chunkymunky_dir};
my $podir 	= $drinkvals{python_dir};
my $ufdir   = $drinkvals{uf_dir};
my $apoddir    = $drinkvals{apod_dir};
my $fileforumdir = $drinkvals{fileforum_dir};
my $dilbertdir   = $drinkvals{dilbert_dir};
my $shellcitydir = $drinkvals{shellcity_dir};
my $aftery2kdir  = $drinkvals{aftery2k_dir};
my $litestepnetdir = $drinkvals{litestepnet_dir};
my $litestepnetssdir = $drinkvals{litestepnetss_dir};
my $litestepnettdir = $drinkvals{litestepnett_dir};
my $geeknewsorgdir = $drinkvals{geeknewsorg_dir};
my @which       = ($drinkvals{slashdot},$drinkvals{freshmeat},$drinkvals{segfault},$drinkvals{linuxtoday},
                   $drinkvals{desktopian},$drinkvals{technotronic},$drinkvals{geeknews},$drinkvals{bits32},
                   $drinkvals{betanews},$drinkvals{arstechnica},$drinkvals{floach},$drinkvals{litestepcom},
                   $drinkvals{litesteporg},$drinkvals{benews},$drinkvals{beoscentral},$drinkvals{themesorg},
                   $drinkvals{solariscentral},$drinkvals{lancednet},$drinkvals{linuxgames},$drinkvals{linuxapps},
                   $drinkvals{hackernews},$drinkvals{happypenguinnews},$drinkvals{happypenguinupdates},
                   $drinkvals{happypenguinadd},$drinkvals{linuxquake},$drinkvals{absolutegamers},
                   $drinkvals{linux3d},$drinkvals{fullon3d},$drinkvals{gizmo3d},
                   $drinkvals{bluesnews},$drinkvals{voodooextreme},$drinkvals{chunkymunky},$drinkvals{python},
                   $drinkvals{userfriendly},$drinkvals{apod},$drinkvals{fileforum},$drinkvals{dilbert},
                   $drinkvals{shellcity},$drinkvals{aftery2k},$drinkvals{litestepnet},$drinkvals{litestepnetss},
                   $drinkvals{litestepnett},$drinkvals{geeknewsorg});
my $border	= $drinkvals{border};
my $back	= $drinkvals{back};
my $entryback	= $drinkvals{entryback};
my $bodyback	= $drinkvals{bodyback};
my $bodytext	= $drinkvals{bodytext};
my $bodylink	= $drinkvals{bodylink};
my $bodyvlink	= $drinkvals{bodyvlink};
my $bodyalink   = $drinkvals{bodyalink};
my $limit = $drinkvals{limit};
$limit = $limit - 1;
my ($remote,$file,$backend);
my ($port,$iaddr,$paddr,$proto);
my ($line,$first,$second,$third,$fourth,$fifth,$pattern,$pattern2,$pattern3,$pattern4,$flag);
my ($linecount,$linenumber,$topic,$blocklength,$num,$fromtop,$topicline,$linkline,$dir,$x);
my ($header1,$header2);





# Get the news.

if ($pageval == 1){
     createpage();
     header();
}

if ($which[0] == 1) {
 if ($feedback == 1) {	
 	print "Getting Slashdot headlines.\n";
 }    
 lsVodka();
}
if ($which[1] == 1) {
 if ($feedback == 1) {	
 	print "Getting Freshmeat headlines.\n";
 } 	
 lsWhiskey();
}
if ($which[2] == 1) {
 if ($feedback == 1) {	
 	print "Getting Segfault news.\n";
 }	
 lsRum();
}
if ($which[3] == 1) {
 if ($feedback == 1) {	
 	print "Getting Linux Today headlines.\n";
 }	
 lsGin();
}
if ($which[4] == 1) {
 if ($feedback == 1) {	
 	print "Getting Desktopian News.\n";
 }	
 lsHotDamn();
}
if ($which[5] == 1) {
 if ($feedback == 1) {	
 	print "Getting Technotronic News.\n";
 }	
 lsBeer();
}
if ($which[6] == 1) {
 if ($feedback == 1) {	
 	print "Getting Geeknews.\n";
 }	
 lsJolt();
}
if ($which[7] == 1) {
 if ($feedback == 1) {	
 	print "Getting 32bits Online news.\n";
 }	
 lsWine();
}
if ($which[8] == 1) {
 if ($feedback == 1) {
 	print "Getting BetaNews.\n";
 }	
 lsAfterShock();
}
if ($which[9] == 1) {
 if ($feedback == 1) {	
 	print "Getting Ars Technica headlines.\n";
 }
 lsButterScotch();
}
if ($which[10] == 1) {
 if ($feedback == 1) {	
 	print "Getting Floach headlines. \n";
 }	
 lsScotch();
}
if ($which[11] == 1) {
 if ($feedback == 1) {	
 	print "Getting LiteStep.com News. \n";
 }	
 lsBrandy();
}
if ($which[12] == 1) {
 if ($feedback == 1) {
 	print "Getting LiteStep.org News. \n";
 }	
 lsCognac();
}
if ($which[13] == 1) {
 if ($feedback == 1) {	
 	print "Getting BeNews. \n";
 }	
 lsMartini();
}
if ($which[14] == 1) {
 if ($feedback == 1) {	
 	print "Getting BeOS Central News. \n";
 }	
 lsAbsolut();
}
if ($which[15] == 1) {
 if ($feedback == 1) {	
 print "Getting Themes.Org. \n";
 }
 lsMalibu();
}
if ($which[16] == 1) {
 if ($feedback == 1) {	
 print "Getting Solaris Central News. \n";
 }
 lsSouthernComfort ();
}
if ($which[17] == 1) {
 if ($feedback == 1) {	
 print "Getting Lanced.Net. \n";
 }
 lsLN();
}
if ($which[18] == 1) {
 if ($feedback == 1) {
 print "Getting LinuxGames.com News. \n";
 }
 lsLG();
}
if ($which[19] == 1) {
 if ($feedback == 1) {	
 print "Getting LinuxApps.com.  \n";
 }
 lsLA();
}
if ($which[20] == 1) {
 if ($feedback == 1) {	
 print "Getting Hacker News.  \n";
 }
 lsHN();
}
if ($which[21] == 1) {
 if ($feedback == 1) {	
 print "Getting Happy Penguin News. \n";
 }
 lsHPN();
}
if ($which[22] == 1) {
 if ($feedback == 1) {	
 print "Getting Happy Penguin Updates. \n";
 }
 lsHPU();
}
if ($which[23] == 1) {
 if ($feedback == 1) {	
 print "Getting Happy Penguin Additions. \n";
 }
 lsHPA();
} 
if ($which[24] == 1) {
 if ($feedback == 1) {	
 print "Getting Linux Quake News. \n";
 }
 lsLQ();
}
if ($which[25] == 1) {
 if ($feedback == 1) {	 
 print "Getting Absolute Gamers Files. \n";
 }
 lsAGF();
}
if ($which[26] == 1) {
 if ($feedback == 1) {	
 print "Getting Linux3D News. \n";
 }
 lsL3D();
}
if ($which[27] == 1) {
 if ($feedback == 1) {	
 print "Getting FullON3D News. \n";
 }
 lsF3D();
}
if ($which[28] == 1) {
 if ($feedback == 1) {	
 print "Getting Gizmo 3D News. \n";
 }
 lsG3D();
}
if ($which[29] == 1) {
 if ($feedback == 1) {	
 print "Getting BluesNews. \n";
 }
 lsBLN();
}
if ($which[30] == 1) {
 if ($feedback == 1) {	
 print "Getting VodooExtreme. \n";
 }
 lsVE();
}
if ($which[31] == 1) {
 if ($feedback == 1) {	
 print "Getting ChunkyMunky.com. \n";
 }
 lsCM();
}
if ($which[32] == 1) {
 if ($feedback == 1) {	
 print "Getting Python.org. \n";
 }
 lsPO();
}
if ($which[33] == 1) {
 if ($feedback == 1) {	
 print "Getting Userfriendly. \n";
 }
 lsUF();
}
if ($which[34] == 1) {
 if ($feedback == 1) {	
 print "Getting Astronomy Picture of the Day. \n";
 }
 lsAPOD();
}
if ($which[35] == 1) {
 if ($feedback == 1) {	
 print "Getting FileForum. \n";
 }
 lsff();
}
if ($which[36] == 1) {
 if ($feedback == 1) {	
 print "Getting Dilbert. \n";
 }
 lsDil();
}
if ($which[37] == 1) {
 if ($feedback == 1) {	
 print "Getting ShellCity. \n";
 }
 lsSCity();
}
if ($which[38] == 1) {
  if ($feedback == 1){
    print "Getting After Y2k. \n";
  }
  lsAY2k();
}
if ($which[39] == 1) {
  if ($feedback == 1){
    print "Getting Litestep.Net. \n";
  }
  lsLSnet();
}
if ($which[40] == 1) {
  if ($feedback == 1){
    print "Getting Litestep.Net Screen Shots. \n";
  }
  lsLSnetss();
}
if ($which[41] == 1) {
  if ($feedback == 1){
    print "Getting Litestep.Net Themes. \n";
  }
  lsLSnett();
}
if ($which[42] == 1) {
  if ($feedback == 1){
    print "Getting Geek News Org. \n";
  }
  lsGeekNewsOrg();
}
if ($pageval == 1){
	footer();
}

#############################################################################
# lsVodka section Slashdot
sub lsVodka {	
      $header1 = "Slashdot";
      $header2 = "slashdot.org";
    	$remote = "Slashdot.org";
    	$file   = "ultramode.txt";
    	$backend= "backend.slashdot";
    	getbackend();
        $fromtop = 1;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 10;
    	$dir = $slashdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
    	
}
#
#############################################################################


#############################################################################
# lsWhiskey section freshmeat
sub lsWhiskey {
 	    $header1 = "Freshmeat";
 	    $header2 = "freshmeat.net";
 	    $remote = "Freshmeat.net";
    	$file   = "backend/recentnews.txt";
    	$backend= "backend.freshmeat";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $fmdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
    	
}
#
#############################################################################

#############################################################################
# lsGin section LinuxToday
sub lsGin {
      $header1 = "LinuxToday";
 	    $header2 = "linuxtoday.com";
	    $remote = "linuxtoday.com";
    	$file   = "lthead.txt";
    	$backend= "backend.linuxtoday";
	    getbackend();
	    $fromtop = 4;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $ltdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
 
}
#
#############################################################################


#############################################################################
# lsRum section Segfault
sub lsRum {
 	    $header1 = "Segfault";
 	    $header2 = "segfault.org";
 	    $remote = "segfault.org";
    	$file   = "stories.txt HTTP/1.1\nHost: segfault.org:80";
    	$backend= "backend.segfault";
    	getbackend();
    	$fromtop = 20;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 7;
    	$dir = $segdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsHotDamn section Desktopian
sub lsHotDamn {
      $header1 = "Desktopian";
 	    $header2 = "www.desktopian.org";
 	    $remote = "www.desktopian.org";
    	$file   = "/includes/recentnews.txt";
    	$backend= "backend.desktopian";
    	getbackend();
    	$fromtop = 4;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $dtdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}

#
#############################################################################


#############################################################################
# lsBeer section Technotronic
sub lsBeer {
 	    $header1 = "Technotronic";
 	    $header2 = "www.technotronic.com";
 	    $remote = "www.technotronic.com";
    	$file   = "backend/headlines.txt";
    	$backend= "backend.technotronic";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $ttdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# lsJolt section Geeknews
sub lsJolt {
      $header1 = "Geeknews";
 	    $header2 = "geeknews.net";
 	    $remote = "geeknews.net";
    	$file   = "news/backend.txt";
    	$backend= "backend.geeknews";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 6;
    	$linkline = 7;
    	$blocklength = 7;
    	$dir = $gndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsWine  32BitsOnline
sub lsWine {
 	    $header1 = "32BitsOnline";
 	    $header2 = "www.32bitsonline.com";
 	    $remote = "www.32bitsonline.com";
 	    $file   = "index.php3";
    	$backend= "backend.32bits";
    	$pattern = "<a href=\"http:\/\/www.32bitsonline.com\/article.php3";
    	$pattern2 = "<br><b><font size=";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $bitsdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# lsAfterShock section betanewsnews
sub lsAfterShock {
      $header1 = "Betanews";
 	    $header2 = "betanews.efront.com";
 	    $remote = "betanews.efront.com";
    	$file   = "backend.php3 HTTP/1.1\nHost: betanews.efront.com:80";
    	$backend= "backend.betanews";
    	getbackend();
    	$fromtop = 7;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $bndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsButterScotch section arsTechnica
sub lsButterScotch {
 	    $header1 = "arsTechnica";
 	    $header2 = "arstechnica.net";
 	    $remote = "arstechnica.com";
    	$file   = "heads.txt";
    	$backend= "backend.ars";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $atdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsScotch Floach
sub lsScotch {
 	    $header1 = "Floach";
 	    $header2 = "floach.pimpin.net";
 	    $remote = "www.desktopian.org";
    	$file = "/includes/fpn.xml HTTP/1.1\nHost: www.desktopian.org:80";
    	$backend= "backend.floach";
    	getbackend();
    	fixbackend();
    	$fromtop = 19;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 5;
    	$dir = $fldir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################




#############################################################################
# lsBrandy LiteStep.Com
sub lsBrandy {
 	    $header1 = "Litestep.com";
 	    $header2 = "www.litestep.com";
 	    $remote = "www.litestep.com";
    	$file   = "backend.txt";
    	$backend= "backend.lsc";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 6;
    	$linkline = 7;
    	$blocklength = 7;
    	$dir = $lscdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# lsCognac LiteStep.Org
sub lsCognac {
 	    $header1 = "LiteStep.org";
 	    $header2 = "www.litestep.org";
 	    $remote = "www.litestep.org";
    	$file   = "index.html HTTP/1.1\nHost: www.litestep.org:80";
    	$backend= "backend.lso";
    	$pattern = "<!--NewsIndex";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $lsodir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsMartini BeNews
sub lsMartini {
 	    $header1 = "BeNews";
 	    $header2 = "www.benews.com";
 	    $remote = "www.benews.com";
    	$file   = "/story/headlines/10 HTTP/1.1\nHost: www.benews.com:80\n";
    	$backend= "backend.ben";
    	getbackend();
    	$fromtop = 8;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $bendir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
    	
}
#
#############################################################################


#############################################################################
# lsAbsolut BeOS Central
sub lsAbsolut {
 	    $header1 = "BeOS Central";
 	    $header2 = "www.beoscentral.com";
 	    $remote = "www.beoscentral.com";
    	$file   = "powerbosc.txt HTTP/1.1\nHost: www.beoscentral.com:80\n";
    	$backend= "backend.bec";
    	getbackend();
    	$fromtop = 9;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $becdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsMalibu Themes.Org
sub lsMalibu {
      $header1 = "Themes.org";
 	    $header2 = "www.themes.org";
 	    $remote = "www.themes.org";
    	$file   = "news.rdf.phtml HTTP/1.1\nHost: www.themes.org:80";
    	$backend= "backend.tho";
    	getbackend();
    	fixbackend();
    	$fromtop = 17;
    	$topicline = 2;
    	$linkline = 4;
    	$blocklength = 12;
    	$dir = $thodir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsSouthernComfort  Solaris Central
sub lsSouthernComfort {
      $header1 = "Solaris Central";
 	    $header2 = "www.solariscentral.rog";
 	    $remote = "www.solariscentral.org";
    	$file   = "news/ultramode.txt HTTP/1.1\nHost: www.solariscentral.org:80";
    	$backend= "backend.sc";
    	getbackend();
    	$fromtop = 16;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $scdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Lanced net
sub lsLN {
      $header1 = "Lanced net";
 	    $header2 = "www.lanced.net";
 	    $remote = "www.lanced.net";
    	$file   = "index.shtml HTTP/1.1\nHost: www.lanced.net:80";
    	$backend= "backend.ln";
    	$pattern = "<p><b><font color=\"silver\">";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $lndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Linux Games
sub lsLG {
 	    $remote = "www.linuxgames.com";
 	    $header1 = "Linux Games";
 	    $header2 = "www.linuxgames.com";
    	$file   = "index.shtml HTTP/1.1\nHost: www.linuxgames.com:80";
    	$backend= "backend.lg";
    	$pattern = "<B><A NAME=\"";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $lgdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# lsLA section Linux Apps
sub lsLA {
      $header1 = "Linux Apps";
 	    $header2 = "www.linuxapps.com";
 	    $remote = "www.linuxapps.com";
    	$file   = "backend/detailed.txt HTTP/1.1\nHost: www.linuxapps.com:80";
    	$backend= "backend.la";
    	getbackend();
    	$fromtop = 9;
    	$topicline = 2;
    	$linkline = 8;
    	$blocklength = 9;
    	$dir = $ladir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# lsHN section Hackernews
sub lsHN {
 	    $header1 = "Hackernews";
 	    $header2 = "www.hackernews.com";
 	    $remote = "www.hackernews.com";
    	$file   = "misc/hnn.xml";
    	$backend= "backend.hn";
    	$pattern = "<item>";
      $pattern2 = "</channel>";
    	$x = 0;
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 3;
    	$linkline = 2;
    	$blocklength = 3;
    	$dir = $hndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Happypenguin Org News
sub lsHPN {
 	    $header1 = "Happy Penguin News";
 	    $header2 = "happypenguin.org";
 	    $remote = "happypenguin.org";
    	$file   = "html/news.txt HTTP/1.1\nHost: happypenguin.org:80";
    	$backend= "backend.hpn";
    	$pattern = "Content-Type: text/plain";
    	$x = 0;
    	getbackend();
    	fixbackend();
    	$fromtop = 8;
    	$topicline = 2;
    	$linkline = 4;
    	$blocklength = 4;
    	$dir = $hpndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# Happy Penguin Updates
sub lsHPU {
      $header1 = "Happy Penquin Updates";
 	    $header2 = "happypenguin.org";
 	    $remote = "happypenguin.org";
    	$file   = "html/updates.txt HTTP/1.1\nHost: happypenguin.org:80";
    	$backend= "backend.hpu";
    	getbackend();
    	fixbackend();
    	$fromtop = 36;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $hpudir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# Happy Penguin Adds
sub lsHPA {
 	    $header1 = "Happy Penguin Adds";
 	    $header2 = "happypenguin.org";
 	    $remote = "happypenguin.org";
    	$file   = "html/additions.txt HTTP/1.1\nHost: happypenguin.org:80";
    	$backend= "backend.hpa";
    	getbackend();
    	fixbackend();
    	$fromtop = 36;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $hpadir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Linux Quake
sub lsLQ {
 	    $remote = "linuxquake.com";
 	    $header1 = "LinuxQuake";
 	    $header2 = "linuxquake.com";
    	$file   = "last20.txt";
    	$backend= "backend.lq";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 3;
    	$blocklength = 4;
    	$dir = $lqdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# Absolute Gamers
sub lsAGF {
 	    $header1 = "Absolute Gamers";
 	    $header2 = "files.gameaholic.com";
 	    $remote = "files.gameaholic.com";
    	$file   = "agfa.rdf HTTP/1.1\nHost: files.gameaholic.com:80";
    	$backend= "backend.ag";
    	getbackend();
    	fixbackend();
    	$fromtop = 4;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $agdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# Linux 3d
sub lsL3D {
      $header1 = "Linux 3d";
 	    $header2 = "www.linux3d.net";
 	    $remote = "www.linux3d.net";
    	$file   = "index.shtml";
    	$backend= "backend.l3d";
        $pattern = "<font face=\"Arial, Helvetica\" size=\"2\"><a href=\"http:\/\/www.linux3d.net\/index.shtml";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $l3ddir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################



#############################################################################
# Fullon 3d
sub lsF3D {
      $header1 = "Fullon 3d";
 	    $header2 = "www.fullon3d.com";
 	    $remote = "www.fullon3d.com";
    	$file   = "index.shtml";
    	$backend= "backend.f3d";
    	$pattern = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/hardware\/";
      $pattern2 = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/games\/";
      $pattern3 = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/opinionated\/";
      $pattern4 = "<a class=\"sides\" href=\"http:\/\/fullon3d.com\/general\/";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $f3ddir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub lsG3D {
 	    $header1 = "Gizmo 3d";
 	    $header2 = "www.linux3d.net/gizmo3d/";
 	    $remote = "www.linux3d.net";
    	$file   = "/gizmo3d/main.shtml";
    	$backend= "backend.g3d";
    	$pattern = "<p><strong><font face=\"Lucida Console\" size=\"3\" color=\"\#";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $g3ddir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub lsBLN {
      $header1 = "BluesNews";
 	    $header2 = "www.bluesnews.com";
 	    $remote = "www.bluesnews.com";
    	$file = "/cgi-bin/blammo.pl?mode=headlines";
    	$backend= "backend.bln";
    	$pattern = "HREF=\"http:\/\/www.bluesnews.com\/cgi-bin\/blammo.pl?display=";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 3;
    	$linkline = 2;
    	$blocklength = 3;
    	$dir = $blndir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub lsVE {
 	    $header1 = "VooDoo Extreme";
 	    $header2 = "www.voodooextreme.com";
 	    $remote = "www.voodooextreme.com";
    	$file   = "/quick_load.mv?1";
    	$backend= "backend.ve";
    	$pattern = "<input type=\"checkbox\" name=\"x";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $vedir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub lsCM {
      $header1 = "ChunkyMunky";
 	    $header2 = "www.chunkymunky.com";
 	    $remote = "www.chunkymunky.com";
    	$file   = "index.shtml";
    	$backend= "backend.cm";
    	$pattern = "<font face=\"Verdana,Arial,Geneva\" size=\"4\"><b>";
    	getbackend();
    	fixbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 2;
    	$dir = $cmdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsPO {
 	    $header1 = "Python";
 	    $header2 = "www.python.org";
 	    $remote = "www.python.org";
    	$file   = "channews.rdf";
    	$backend= "backend.po";
    	getbackend();
    	fixbackend();
    	$fromtop = 6;
    	$topicline = 2;
    	$linkline = 3;
    	$blocklength = 3;
    	$dir = $podir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsUF {
 	    $header1 = "UserFriendly";
 	    $header2 = "www.userfriendly.org";
 	    $remote = "www.userfriendly.org";
    	$file   = "static/index.html";
    	$backend= "backend.uf";
    	getbackend();
    	fixbackend();
    	$dir = $ufdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsAPOD {
 	    $header1 = "Astronomy Picture of the Day";
 	    $header2 = "antwrp.gsfc.nasa.gov/apod/ap.html";
 	    $remote = "antwrp.gsfc.nasa.gov";
    	$file   = "apod/ap.html";
    	$backend= "backend.apod";
    	getbackend();
    	fixbackend();
    	$dir = $apoddir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsff {
      $header1 = "File Forum";
 	    $header2 = "fileforum.efront.com";
 	    $remote = "fileforum.efront.com";
    	$file   = "backend.php3 HTTP/1.1\nHost: fileforum.efront.com:80";
    	$backend= "backend.fileforum";
    	getbackend();
    	$fromtop = 7;
    	$topicline = 1;
    	$linkline = 5;
    	$blocklength = 5;
    	$dir = $fileforumdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsDil {
      $header1 = "Dilbert";
 	    $header2 = "www.unitedmedia.com/comics/dilbert/index.html";
  	  $remote = "www.unitedmedia.com";
    	$file   = "comics/dilbert/index.html";
    	$backend= "backend.dilbert";
    	getbackend();
    	fixbackend();
    	$dir = $dilbertdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsSCity {
 	    $header1 = "Shell City";
 	    $header2 = "www.shellcity.net";
 	    $remote = "www.shellcity.net";
    	$file   = "citynews.txt HTTP/1.1\nHost: www.shellcity.net:80";
    	$backend= "backend.shellcity";
    	getbackend();
    	$fromtop = 16;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 4;
    	$dir = $podir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsAY2k {
      $header1 = "After Y2K";
 	    $header2 = "www.geekculture.com/geekycomics/Aftery2k/aftery2kmain.html";
  	  $remote = "www.geekculture.com";
    	$file   = "geekycomics/Aftery2k/aftery2kmain.html";
    	$backend= "backend.ay2k";
    	getbackend();
    	fixbackend();
    	$dir = $aftery2kdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub lsLSnet {
 	    $header1 = "LiteStep.Net News";
 	    $header2 = "www.litestep.net";
 	    $remote = "www.pimpin.net";
    	$file   = "~lsnews/lsnet-news.news";
    	$backend= "backend.lsLSnet";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 4;
    	$dir = $litestepnetdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsLSnetss {
 	    $header1 = "LiteStep.Net Screen Shots";
 	    $header2 = "www.litestep.net";
 	    $remote = "www.pimpin.net";
    	$file   = "~lsnews/lsnet-ss.news";
    	$backend= "backend.lsLSnetss";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 4;
    	$dir = $litestepnetssdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsLSnett {
 	    $header1 = "LiteStep.Net Themes";
 	    $header2 = "www.litestep.net";
 	    $remote = "www.pimpin.net";
    	$file   = "~lsnews/lsnet-themes.news";
    	$backend= "backend.lsLSnett";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 4;
    	$dir = $litestepnettdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################


#############################################################################
# 
sub lsGeekNewsOrg {
      $header1 = "GeekNews.Org";
 	    $header2 = "www.geeknews.org";
 	    $remote = "www.geeknews.org";
    	$file   = "headlines.txt";
    	$backend= "backend.geeknewsorg";
    	getbackend();
    	$fromtop = 0;
    	$topicline = 1;
    	$linkline = 2;
    	$blocklength = 3;
    	$dir = $geeknewsorgdir;
    	if ($folderval == 1){
    	    addfolder();
    	}
    	if ($pageval == 1){
    	    tabletitle();
    	    tablerow();
    	}
}
#
#############################################################################

#############################################################################
# 
sub getbackend{
    $port = 80;
    $iaddr = inet_aton($remote) ||  "no host: $remote"; #return;
    $paddr = sockaddr_in($port, $iaddr);
    $proto = getprotobyname('tcp');
    socket(SOCK, PF_INET, SOCK_STREAM, $proto) ||  "socket: $!"; #return;
    connect(SOCK, $paddr) || "couldn't connect: $remote";#die "connect: $!";
    select(SOCK); $| = 1; select(STDOUT);
    if($remote ne "www.desktopian.org"){
	    print SOCK "GET /$file\n\n";
	  } 
	  else {
	      print SOCK "GET http://$remote$file\n\n";
	  }
	  unlink($backend);
    open(BACKEND,">>$backend");
	   while(<SOCK>){
		       print BACKEND "$_";
		       
	   }
	  close(BACKEND);
	  close(SOCK) || die "close: $!";
  }
#
############################################################################# 

sub fixbackend{
  open(BACKEND,"<$backend") || "Can't open $backend\n"; #return;
       while(<BACKEND>) {  
         $line = $_;
         my $i;
         $i = 0;
         if ("$backend" eq "backend.technotronic"){
             
             $line =~ s/<b>/x&&/;
             $line =~ s/<\/b>/&&/;
             ($first,$second,$third) = split(/&&/ , $line);
             chomp($second);
        
             if ($second ne ""){
                 open(TEMP,">>temp");
                    print TEMP "$second\n";
                    print TEMP "http://$remote\n";
                 close(TEMP);  
             }
         }
         elsif ("$backend" eq "backend.32bits"){
        	if ($line =~ /^$pattern|$pattern2/) {
        	    $flag = 0;
                    $line=~ s/issues/&&/;
                    $line=~ s/\">/&&/g;
                    $line=~ s/<\/a>/&&/;
                    
                    ($first,$second,$third,$fourth,$fifth) = split(/&&/ , $line,5);
                    open(TEMP,">>temp");
                    if ($fifth =~ /<\/font>/){
                    	print TEMP "$fourth\n";
                    	print TEMP "http://$remote/article.php3?file=issues$third\n";
                    	$flag = 1}
                    elsif($fourth=~ /.../ && $flag ne 1){
                         print TEMP "$third\n";
                         print TEMP "http://$remote/article.php3?file=issues$second\n";
                    close(TEMP);
                    }
                    
                 }
                    
         }
         elsif("$backend" eq "backend.lso"){
                if ($line =~ /$pattern/) {
         	    $line =~ s/=\"/&/;
                    $line =~ s/\">/&/;
                    $line =~ s/<\/a>/&/;
                    ($first, $second, $third) = split(/&/,$line);
                    open(TEMP, ">>temp");
         	      chomp($third);
         	      print TEMP "$third\n";
         	      print TEMP "http://$remote/index.html$second\n";
         	    close(TEMP);
                 }
         }        
         elsif("$backend" eq "backend.ln"){
                if ($line =~ /$pattern/) {
                    $line =~ s/<i>/&&/;
                    $line =~ s/<\/i><\/b><br>/ &&/;
                    ($first, $third, $second) = split(/&&/,$line);
                    $second = "";
                    open(TEMP, ">>temp");
         	      print TEMP "$third\n";
         	      print TEMP "http://$remote/index.shtml$second\n";
         	    close(TEMP);
                 }        
         }
         elsif("$backend" eq "backend.lg"){
                if ($line =~ /$pattern/) {
                    $line =~ s/<B><A NAME=\"/xx&&/;
         	    $line =~ s/\"><\/A>/ &&/;
         	    ($first, $second, $third) = split(/&&/,$line);
                    $third = $second;
                    open(TEMP, ">>temp");
         	      print TEMP "$third\n";
         	      print TEMP "http://$remote/index.shtml\n";
         	    close(TEMP);
                 }        
         }
         elsif("$backend" eq "backend.hn"){
               if ($line =~ /^$pattern/)  { 
		                $x = 1;
		               }
                if ($line =~ /^$pattern2/) {
                    $x = 0;
                   }
                if ($x == 1){
                    open(TEMP, ">>temp");
                    $line =~ s/<item>/&&/;
                    $line =~ s/<\/item>//;
                    $line =~ s/<link>//;
                    $line =~ s/<\/link>//;
                    $line =~ s/<title>//;
                    $line =~ s/<\/title>//;
                    if ($line ne "\n"){
                        print TEMP $line;
                       }
                    close(TEMP);
                }
         }
         
         elsif("$backend" eq "backend.hpn"){
               
               
               if ($line =~ /^$pattern/)  { 
                   $line =~ s/^$pattern//;
		               $x = 1;
		           }
		           if ($x == 1){
                   $line =~ s/\n//;
                   ($first, $second, $third) = split(/~@~#~/,$line);
                    open(TEMP, ">>temp");
                    $first =~ s/\n//;
         	          print TEMP "&&\n$first\n";
         	          print TEMP "$second\n";
         	          print TEMP "http://$remote\n";
         	    }
              close(TEMP);
         }
         elsif(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu") or ("$backend" eq "backend.lq")){
         	($first, $second, $third) = split(/~@~#~/,$line);
                open(TEMP, ">>temp");
         	     print TEMP "$first\n";
         	     print TEMP "$second\n";
         	     print TEMP "$third\n";
         	close(TEMP);
         }
         
         elsif("$backend" eq "backend.ag"){
         	if ($line =~ /<title>|<link>/){
         	    $line =~ s/<link>//gi; $line =~ s/<\/link>//;
		    $line =~ s/<title>//;  $line =~ s/<\/title>//;
		    $line =~ s/\s//;
                    open(TEMP, ">>temp");
         	      print TEMP $line;
         	    close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.l3d"){
         	if ($line =~ /$pattern/){
         	    $line =~ s/$pattern/xx&/;
         	    $line =~ s/\">/&/;
         	    $line =~ s/<\/a>/&/;
                    ($first, $second, $third) = split(/&/,$line);
         	    open(TEMP, ">>temp");
         	      print TEMP "&&\n";
         	      print TEMP "$third\n";
         	      print TEMP "http://$remote/$file$second\n";
         	    close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.f3d"){
         	if ($line =~ /$pattern|$pattern2|$pattern3|$pattern4/) {
                    $line =~ s/href=\"/xx&/;
                    $line =~ s/\">/&/;
                    $line =~ s/<\/a>/&/;
                    ($first, $second, $third) = split(/&/,$line);
                    open(TEMP, ">>temp");
         	      print TEMP "$third\n";
         	      print TEMP "$second\n";
         	    close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.g3d"){
         	if ($line =~ /$pattern/){
         	    $line =~ s/\">/xx&/;
                    $line =~ s/<\/font>/&/;
                    ($first, $second, $third) = split(/&/,$line);
                     chomp($second);
                     open(TEMP, ">>temp");
         	      print TEMP "$second\n";
         	      print TEMP "http://$remote$file\n";
         	     close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.x11"){
         	if ($line =~ /^$pattern/)  {
                     $line =~ s/<strong>\[Messages\]<br>//;
                     $line =~ s/<strong>\[Screenshots\]<br>//;
                     $flag = 1;
                     $line =~ s/\">/xx&/;
                     $line =~ s/<\/font>/&/;
                     $line =~ s/\//_/;
                     $line =~ s/\//_/;
                     $line =~ s/\(//;
                     $line =~ s/\)//;
                     $line =~ s/://;
                     $line =~ s/\s//;
                     ($first, $second, $third) = split(/&/,$line);
                     chomp($second);
                     if ("$second" ne ""){
                         open(TEMP, ">>temp");
         	           print TEMP "$second\n";
         	           print TEMP "http://$remote$file\n";
         	         close(TEMP);
         	     }
                 }  
         }
         elsif("$backend" eq "backend.mdt"){
         	if ($line =~ /$pattern/){
         	    $line =~ s/"><B>/&&/;
                    $line =~ s/<\/B>/&&/;
                    ($first, $third, $second) = split(/&&/,$line,3);
                    chomp($third);
                    if ("$second" ne ""){
                         open(TEMP, ">>temp");
         	           print TEMP "$third\n";
         	           print TEMP "http://$remote/$file\n";
         	         close(TEMP);
         	    }
                 }  
         }
         elsif("$backend" eq "backend.bln"){
          if ($line =~ /<\/strong><\/font><font face=\"Arial, Helvetica\" size=\"1\">/){
           $line =~ s/<\/strong><\/font><font face=\"Arial, Helvetica\" size=\"1/&&/;
           $line =~ s/<A HREF=\"//g;
           $line =~ s/\">/\n/g;
           $line =~ s/<\/A><BR>/\n&&\n/g;
           $line =~ s/<\/font><\/p>//;
           open(TEMP, ">>temp");
             print  TEMP $line;
           close(TEMP);
          }
         	
         }
         elsif("$backend" eq "backend.ve"){
         	if ($line =~ /$pattern/){
         	    $line =~ s/$pattern//;
                    $line =~ s/\"> <a href=\"/&&/;
                    $line =~ s/\" target=\"new\">/&&/;
                    $line =~ s/<\/a>/&&/;
                    ($first, $second, $third, $fourth) = split(/&&/,$line,4);
                    chomp($second);
                    chomp($third);
                    open(TEMP, ">>temp");
                      print  TEMP "&&\n";
                      print  TEMP "$third\n";
                      print  TEMP "http://$remote/$second\n";
         	    close(TEMP);
         	    
                 }  
         }
         elsif("$backend" eq "backend.cm"){
         	if ($line =~ /^$pattern/){
         	    $line =~ s/$pattern/xx&&/;
                    $line =~ s/<\/b>/&&/;
                    ($first, $third, $second) = split(/&&/,$line);
                    chomp($third);
         	    open(TEMP, ">>temp");
         	      print  TEMP "$third\n";
         	      print  TEMP "http://$remote/$file\n";
         	    close(TEMP);
                 }  
         }
         elsif("$backend" eq "backend.po"){
         
              if ($line =~ /<link>/){
                  $line =~ s/    <link>//gi; $line =~ s/<\/link>//gi;
                  $second = $line;
              }
              if ($line =~ /<title>/){
                 $line =~ s/    <title>//gi; $line =~ s/<\/title>//gi;
                 $first = $line;
                 chomp $first; chomp $second;
                 open(TEMP, ">>temp");
         	      print  TEMP "&&\n";
         	      print  TEMP "$first\n";
         	      print  TEMP "$second\n";
         	    close(TEMP);
                 }
         }
         elsif("$backend" eq "backend.tho"){
             
             $line =~ s/<title>//gi; $line =~ s/<\/title>//gi;
		          $line =~ s/<link>//gi; $line =~ s/<\/link>//gi;
		          chomp $line;
         	    open(TEMP, ">>temp");
         	      print  TEMP "$line\n";
         	    close(TEMP);
         }
         elsif("$backend" eq "backend.uf"){
              if ($line =~ /<IMG ALT=\"Latest Strip\" width=576 BORDER=0 SRC=\"/){
              chomp $line;
         	    open(TEMP, ">>temp");
         	      print  TEMP "$line";
         	    close(TEMP);
              }  
         }      
         elsif("$backend" eq "backend.apod"){
              if ($line =~ /<IMG SRC=\"image/){
               $line=~ s/<IMG SRC=\"//;
               $line=~ s/\"><\/a>//;
               chomp $line;
               $line= "<IMG ALT=\"Latest Image\"  BORDER=0 SRC=\"http:\/\/$remote\/apod\/$line\"></A>";
              chomp $line;
         	    open(TEMP, ">>temp");
         	      print  TEMP "$line";
         	    close(TEMP);
              }  
         }   
         elsif("$backend" eq "backend.dilbert"){
              if ($line =~ /<IMG SRC=\"\/comics\/dilbert\/archive\/images\//){
                  $line =~ s/\"//gi;
                  $line =~ s/<IMG SRC=/&&/;
                  $line =~ s/.gif/.gif&&/gi;
                  ($first, $second, $third) = split(/&&/,$line);
                  chomp($third);
         	    open(TEMP, ">>temp");
         	      print  TEMP "<IMG ALT=\"Latest Strip\" BORDER=0 SRC=\"http:\/\/$remote$third\"></A>";
         	    close(TEMP);
              }  
         }   
         elsif("$backend" eq "backend.floach"){
                $line =~ s/<description><\/description>//gi;
                $line =~ s/<title>//gi; 
                $line =~ s/<\/title>//gi; 
                $line =~ s/<link>//gi; 
                $line =~ s/<\/link>//gi; 
                open(TEMP, ">>temp");
         	        print TEMP $line;
         	      close(TEMP);
         }     
         elsif("$backend" eq "backend.ay2k"){
              if ($line =~ /<img src=\"y2Kimages\//){
               $line=~ s/			<img src=\"y2Kimages\///;
               $line=~ s/\" border=\"0\"/&&/;
               ($first,$second) = split(/&&/,$line);
               chomp $first;
               $first = "<IMG ALT=\"Latest After Y2K Image\"  BORDER=0 SRC=\"http://www.geekculture.com/geekycomics/Aftery2k/y2Kimages/$first\"></A>";
              chomp $first;
         	    open(TEMP, ">>temp");
         	      print  TEMP "$first";
         	    close(TEMP);
              }  
         }               
        }
  close(BACKEND);
  unlink($backend);
  rename("temp",$backend);
  unlink("temp");
}

sub addfolder{
  checkdir();
  
  chdir ("$startdir$dir");
  unlink <*.htm>;
  chdir ("$startdir");
  $linecount = 0;
  $linenumber = 0;
  my $topiccount = 0;
  open(BACKEND,"<$backend") || "Can't open $backend\n"; #return;
       while(<BACKEND>) {  
             ++$linecount;
             if($backend eq "backend.apod"){
               $_=~ s/<IMG ALT=\"Latest Image\"  BORDER=0 SRC=\"//;
               $_=~ s/\"><\/A>//;
                open(NUMFILE, ">$dir/APOD.htm");
		              print  NUMFILE "<meta HTTP-Equiv=\"REFRESH\" Content=\"0;url=$_\">";
		            close(NUMFILE);
             }
             elsif($backend eq "backend.uf"){
                $_=~ s/<IMG ALT=\"Latest Strip\" width=576 BORDER=0 SRC=\"//;
                $_=~ s/\"><\/A>//;
                open(NUMFILE, ">$dir/Daily_Static.htm");
		              print  NUMFILE "<meta HTTP-Equiv=\"REFRESH\" Content=\"0;url=$_\">";
		            close(NUMFILE);
             }
             elsif($backend eq "backend.dilbert"){
                $_=~ s/<IMG ALT=\"Latest Strip\" BORDER=0 SRC=\"//;
                $_=~ s/\"><\/A>//;
                open(NUMFILE, ">$dir/Daily_Comic.htm");
		              print  NUMFILE "<meta HTTP-Equiv=\"REFRESH\" Content=\"0;url=$_\">";
		            close(NUMFILE);
             }
             elsif($backend eq "backend.ay2k"){
                $_=~ s/<IMG ALT=\"Latest After Y2k Strip\" BORDER=0 SRC=\"//;
                $_=~ s/\"><\/A>//;
                open(NUMFILE, ">$dir/Daily_Comic.htm");
		              print  NUMFILE "<meta HTTP-Equiv=\"REFRESH\" Content=\"0;url=$_\">";
		            close(NUMFILE);
             }
             else{
               if($linecount>$fromtop){
		              ++$linenumber;
	             }
	             if($linenumber == $topicline){
	                ++$topiccount;
	     	          if( ("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu")){
		  		        }
		              else{
		                chop;
		              }
		
		              $topic="$_";$topic=~ s/\"|:|>|<|\/|\|*|\?|\||\=//gi;$topic=~ s/\+/plus/gi;$topic=~ s/\s//;
		              if("$backend" eq "backend.ag"){
		              }
	                else{
	                  $topic=~ s/$topic/$topic /;
	                }
	             }  
	     	       elsif($linenumber == $linkline && $topic ne "" && $topiccount <= $limit){
		             chop;
		             open(NUMFILE, ">$dir/$topic.htm");
		               print  NUMFILE "<meta HTTP-Equiv=\"REFRESH\" Content=\"0;url=$_\">";
		             close(NUMFILE);
		           }  
	             if($linenumber == $blocklength) {
	               $linenumber=0;
	             }
           }	        
       }
  close(BACKEND);
}

#############################################################################
# Checkdir

sub checkdir {

 if (-e $dir) {
  return;
 }
 mkdir("$dir",0777) || die "Cannot mkdir $dir: $!";
 
}

#############################################################################

sub createpage {
    open(FILE,">$pagename.htm");
}

sub header{
print FILE <<HEADER;
<html>

<head>
<title>$pagename</title>
<base TARGET="_self">
</head>
<body BGCOLOR="#$back" TEXT="#$bodytext" LINK="#$bodylink" 
LEFTMARGIN="0" VLINK="#$bodyvlink" ALINK="#$bodyalink">

<table BORDER="0" WIDTH="100%">
  <tr>
    <td WIDTH="8%"></td>
    <td WIDTH="83%">
HEADER
}



sub footer{
print FILE <<FOOTER;

    </td>
    <td WIDTH="9%"></td>
  </tr>
</table>

<p>&nbsp;</p>
</body>
</html>


FOOTER
}



sub tabletitle{
print FILE <<TITLE;
   <div align="center">
            <center>
               <table BORDER="1" WIDTH="536"
                      BORDERCOLOR="#$border" CELLSPACING="0" BORDERCOLORLIGHT="#$border" BORDERCOLORDARK="#$border"
                      BGCOLOR="#$entryback">
                      <tr>
                         <td WIDTH="100%">
                            
                              <big>
                                 <strong><A href=http:\/\/$header2>$header1</a></strong>
                             </big>
                         </td>
                      </tr>
               </table>
            </center>
        </div>

TITLE

}

sub tablerow{
print FILE<<TROWT;
<div align="center">
             <center>
                <table BORDER="1" WIDTH="536"
                       BGCOLOR="#$bodyback" BORDERCOLOR="#$border" CELLSPACING="0" BORDERCOLORLIGHT="#$border" BORDERCOLORDARK="#$border">
                       <tr>
                          <td>
                            
TROWT

  $linecount = 0;
  $num = 0;
  $linenumber = 0;
  
  my $topiccount = 0;
  
  open(BACKEND,"<$backend") || print "Can't open $backend\n"; 
       while(<BACKEND>) {  
             ++$linecount;
             ++$num;
             if($backend eq "backend.uf"){
                print FILE $_;
             }
             elsif($backend eq "backend.apod"){
                print FILE $_;
             }
             elsif($backend eq "backend.dilbert"){
                print FILE $_;
             }
             elsif($backend eq "backend.ay2k"){
                print FILE $_;
             }
             else{
	             if($linecount>$fromtop){
		              ++$linenumber;
	             }
	             if($linenumber == $topicline){
	     	          ++$topiccount;
	     	          if(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu")){
                  }
		              else{
		                chop;
		              }
		              $topic="$_";$topic=~ s/:|>|<|\/|\|*|\?|\||\=//gi;$topic=~ s/\+/plus/gi;$topic=~ s/\s//;
		              if("$backend" eq "backend.ag"){
		              }
	                else{
	                  $topic=~ s/$topic/$topic /;
	                }
	            }
	     
	            elsif($linenumber == $linkline && $topic ne "" && $topiccount <= $limit){
		            chop;
		            print  FILE "<li><A href='$_'>$topic</a></li>\n";
              }  
	            if($linenumber == $blocklength){
	               $linenumber=0;
	            }
	          }  
       }
  close(BACKEND);

print FILE <<TROWB;  
                        </td>
                      </tr>
               </table>
             </center>
       </div><p>&nbsp;

TROWB
}


# 2.1.6  Added Geeknews.org, Fixed Segfault
# 2.1.5  Added After Y2k Cartoon
#        Added LiteStep.Net,Litestep.net Screen Shots (using backends from MrJukes and geekMASTR)
#        Added the ability for the script to create a directory if one doesn't exist so in including
#        as the sub dirs is no longer needed.
# 2.1.4  Changed floach to read from Desktopian * Thanks Tin_Omen *, Changed Tin_Toys to Desktopian
#        Changed the htm page to added a differnt header and url, Added Shell City
# 2.1.3  Added Astronomy Pic of the Day, Dilbert.FileForum Changed the Way Floach Works.
# 2.1.2  Added User Friendly Strip