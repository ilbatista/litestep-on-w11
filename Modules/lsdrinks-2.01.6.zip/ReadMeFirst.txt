#############################################################################
# lsDrinks 2.1.6                                                              #
# Hacked up by : nf0 <nf0@10500bc.org                                       #
#                                                                           #
# Thanks to Charlie <ishamael@orodruin.ddns.org> for making asDrinks        #
# Thanks to Flip for making FlipsThing                                      #
# Thanks to Spawn @ desktopz.org for suggestions                            #
# Thanks to Tin_Omen of http://tinomen.cjb.net/                             #
# For pointing out some errors and making suggestions                       #
#                                                                           #
#                                                                           #
#############################################################################


What it Does:
It checks SlashDot, FreshMeat, Linux Today, Segfault, Technotronic, DeskTopian,
Geeknews, BetaNews, 32BitOnline, ArsTechnica, Floach, LiteStepCom(?),
LiteStepOrg(?),BeNews, BeOSCentral, ThemesOrg, SolarisCentral,
Lanced Net(?),Linux Games,Linux Apps,HackerNews,Happy Penguin News,
Happy Penguin Updates, Happy Penguin updates, Linux Quake,Absolutegamers
Linux 3d, Fullon 3d, Gizmo 3d, Blues news, Voodoo Extreme, Chunkymunky,
Python,FileForum,LiteStep.Net News, Litestep.Net Screen Shots,Litestep.Net Themes,
and Geeknews.org for news. 
Then Creates an Htm link in its folder. Then you can Look at your popup under 
the selected folder and see the news. To follow the link just click on the one
you want and it will open it up in your browser.


Suggestions:
If you have any suggestion or no of any other sites that you would like added email me.
The sites must have some sort of text backend to work. If any of you with Litestep sites
would like to have your stuff added let me know.


How to Use it:
There are now 2 ways to use this script one is todo the same as always put the news in
folders and the second is to have it create an .htm page for you to open with your Browser.
Or you can do both. More details are in the lsdrinks.rc file please read that.

Way number 1 put the files in folders

1. You must already have Perl installed on you machine. It must also be in the path.

2. Extract the File to your litestep Dir with the paths. It is assumed that this is a 
   default install to C:\litestep. If not then you may need to change some of the paths 
   in the lsdrinks.pl

3. a. If you use the Default Litestep Popups:
      *Important* Don't delete the x.x files from the subdirs. LS crashes when the folders
      are empty when you look at your popups. 
   b. If you use Re5ource's popup.dll :
      You can remove the x.x files it wont crash.

4. Create entries like the following:

   a. If you use the Default Litestep Popups:
      	*Popup "SlashDot" "!PopupDynamicFolder:c:\Litestep\lsdrinks\Slashdot"
      	*Popup "FreshMeat" "!PopupDynamicFolder:c:\Litestep\lsdrinks\FreshMeat"
      	*Popup "Linux Today" "!PopupDynamicFolder:c:\Litestep\lsdrinks\LinuxToday"
      	*Popup "Segfault" "!PopupDynamicfolder:c:\Litestep\lsdrinks\Segfault"
      	*Popup "Technotronic" "!PopupDynamicfolder:c:\Litestep\lsdrinks\technotronic"
      	*Popup "DeskTopian" "!PopupDynamicFolder:c:\Litestep\lsdrinks\DeskTopian"
      	*Popup "Geeknews" "!PopupDynamicFolder:c:\Litestep\lsdrinks\Geeknews"
      	*Popup "32BitsOnline" "!PopupDynamicFolder:c:\Litestep\lsdrinks\32BitsOnline"
      	*Popup "BetaNews" "!PopupDynamicFolder:c:\Litestep\lsdrinks\betanews"
      	*Popup "ArsTechnica" "!PopupDynamicFolder:c:\Litestep\lsdrinks\ArsTechnica"
      	*Popup "Floach" "!PopupDynamicFolder:c:\Litestep\lsdrinks\Floach"
      	*Popup "LiteStepCom" "!PopupDynamicFolder:c:\Litestep\lsdrinks\LiteStepCom"
      	*Popup "BeNews" "!PopupDynamicFolder:c:\Litestep\lsdrinks\BeNews"
      	*Popup "BeOSCentral" "!PopupDynamicFolder:c:\Litestep\lsdrinks\BeOSCentral"
      	*Popup "ThemesOrg" "!PopupDynamicFolder:c:\Litestep\lsdrinks\ThemesOrg"
      	*Popup "SolarisCentral" "!PopupDynamicFolder:c:\Litestep\lsdrinks\SolarisCentral"   
      	*Popup "LancedNet" "!PopupDynamicFolder:c:\Litestep\lsdrinks\LancedNet"
	      *Popup "LinuxGames" "!PopupDynamicFolder:c:\Litestep\lsdrinks\LinuxGames"
	      *Popup "LinuxApps" "!PopupDynamicFolder:c:\Litestep\lsdrinks\LinuxApps"
	      *Popup "HackerNews " "!PopupDynamicFolder:c:\Litestep\lsdrinks\HackerNews"
	      *Popup "HappyPenguinNews" "!PopupDynamicFolder:c:\Litestep\lsdrinks\HappyPenguinNews"
	      *Popup "HappyPenguinUpdtes" "!PopupDynamicFolder:c:\Litestep\lsdrinks\HappyPenguinUpdtes"
	      *Popup "HappyPenguinAdd" "!PopupDynamicFolder:c:\Litestep\lsdrinks\HappyPenguinAdd"
	      *Popup "LinuxQuake" "!PopupDynamicFolder:c:\Litestep\lsdrinks\LinuxQuake"
	      *Popup "LinuxQuakePage" "!PopupDynamicFolder:c:\Litestep\lsdrinks\LinuxQuakePage"
	      *Popup "AbsoluteGamers" "!PopupDynamicFolder:c:\Litestep\lsdrinks\AbsoluteGamers"
	      *Popup "Linux3d" "!PopupDynamicFolder:c:\Litestep\lsdrinks\Linux3d"
	      *Popup "Fullon3d" "!PopupDynamicFolder:c:\Litestep\lsdrinks\Fullon3d"
	      *Popup "Gizmo3d" "!PopupDynamicFolder:c:\Litestep\lsdrinks\Gizmo3d"
	      *Popup "BluesNews" "!PopupDynamicFolder:c:\Litestep\lsdrinks\luesNews"
	      *Popup "VoodooExtreme" "!PopupDynamicFolder:c:\Litestep\lsdrinks\VoodooExtreme"
	      *Popup "ChunkyMunky" "!PopupDynamicFolder:c:\Litestep\lsdrinks\ChunkyMunky"
	      *Popup "Python" "!PopupDynamicFolder:c:\Litestep\lsdrinks\Python"
   
   b. If you use Re5ource's popup.dll :
      In there own Top Level Folder (Doesn't work under the default LS Popup.dll)

      *Popup "lsDrinks" Folder
         *Popup "SlashDot" "!DynamicFolder:c:\Litestep\lsdrinks\Slashdot"
         *Popup "FreshMeat" "!DynamicFolder:c:\Litestep\lsdrinks\FreshMeat"
         *Popup "Linux Today" "!DynamicFolder:c:\Litestep\lsdrinks\LinuxToday"
         *Popup "Segfault" "!Dynamicfolder:c:\Litestep\lsdrinks\Segfault"
         *Popup "Technotronic" "!Dynamicfolder:c:\Litestep\lsdrinks\technotronic"
         *Popup "DeskTopian" "!DynamicFolder:c:\Litestep\lsdrinks\DeskTopian"
         *Popup "Geeknews" "!DynamicFolder:c:\Litestep\lsdrinks\Geeknews"
         *Popup "32BitsOnline" "!DynamicFolder:c:\Litestep\lsdrinks\32BitsOnline"
         *Popup "BetaNews" "!DynamicFolder:c:\Litestep\lsdrinks\betanews"
         *Popup "ArsTechnica" "!DynamicFolder:c:\Litestep\lsdrinks\ArsTechnica"
         *Popup "Floach" "!DynamicFolder:c:\Litestep\lsdrinks\Floach"
         *Popup "BeNews" "!DynamicFolder:c:\Litestep\lsdrinks\BeNews"
         *Popup "BeOSCentral" "!DynamicFolder:c:\Litestep\lsdrinks\BeOSCentral"
         *Popup "ThemesOrg" "!DynamicFolder:c:\Litestep\lsdrinks\ThemesOrg"
         *Popup "SolarisCentral" "!DynamicFolder:c:\Litestep\lsdrinks\SolarisCentral"   
         *Popup "LinuxGames" "!DynamicFolder:c:\Litestep\lsdrinks\LinuxGames"
	       *Popup "LinuxApps" "!DynamicFolder:c:\Litestep\lsdrinks\LinuxApps"
	       *Popup "HackerNews " "!DynamicFolder:c:\Litestep\lsdrinks\HackerNews"
	       *Popup "HappyPenguinNews" "!DynamicFolder:c:\Litestep\lsdrinks\HappyPenguinNews"
	       *Popup "HappyPenguinUpdtes" "!DynamicFolder:c:\Litestep\lsdrinks\HappyPenguinUpdtes"
	       *Popup "HappyPenguinAdd" "!DynamicFolder:c:\Litestep\lsdrinks\HappyPenguinAdd"
	       *Popup "LinuxQuake" "!DynamicFolder:c:\Litestep\lsdrinks\LinuxQuake"
	       *Popup "AbsoluteGamers" "!DynamicFolder:c:\Litestep\lsdrinks\AbsoluteGamers"
	       *Popup "Linux3d" "!DynamicFolder:c:\Litestep\lsdrinks\Linux3d"
	       *Popup "Fullon3d" "!DynamicFolder:c:\Litestep\lsdrinks\Fullon3d"
	       *Popup "Gizmo3d" "!DynamicFolder:c:\Litestep\lsdrinks\Gizmo3d"
	       *Popup "BluesNews" "!DynamicFolder:c:\Litestep\lsdrinks\luesNews"
	       *Popup "VoodooExtreme" "!DynamicFolder:c:\Litestep\lsdrinks\VoodooExtreme"
	       *Popup "ChunkyMunky" "!DynamicFolder:c:\Litestep\lsdrinks\ChunkyMunky"
	       *Popup "Python" "!DynamicFolder:c:\Litestep\lsdrinks\Python"
       *Popup ~Folder
      
      Or in Seperate Folders:

      *Popup "SlashDot" "!DynamicFolder:c:\Litestep\lsdrinks\Slashdot"
      *Popup "FreshMeat" "!DynamicFolder:c:\Litestep\lsdrinks\FreshMeat"
      *Popup "Linux Today" "!DynamicFolder:c:\Litestep\lsdrinks\LinuxToday"
      *Popup "Segfault" "!Dynamicfolder:c:\Litestep\lsdrinks\Segfault"
      *Popup "Technotronic" "!Dynamicfolder:c:\Litestep\lsdrinks\technotronic"
      *Popup "DeskTopian" "!DynamicFolder:c:\Litestep\lsdrinks\DeskTopian"
      *Popup "Geeknews" "!DynamicFolder:c:\Litestep\lsdrinks\Geeknews"
      *Popup "32BitsOnline" "!DynamicFolder:c:\Litestep\lsdrinks\32BitsOnline"
      *Popup "BetaNews" "!DynamicFolder:c:\Litestep\lsdrinks\betanews"
      *Popup "ArsTechnica" "!DynamicFolder:c:\Litestep\lsdrinks\ArsTechnica"
      *Popup "Floach" "!DynamicFolder:c:\Litestep\lsdrinks\Floach"
      *Popup "BeNews" "!DynamicFolder:c:\Litestep\lsdrinks\BeNews"
      *Popup "BeOSCentral" "!DynamicFolder:c:\Litestep\lsdrinks\BeOSCentral"
      *Popup "ThemesOrg" "!DynamicFolder:c:\Litestep\lsdrinks\ThemesOrg"
      *Popup "SolarisCentral" "!DynamicFolder:c:\Litestep\lsdrinks\SolarisCentral"  
      *Popup "LancedNet" "!DynamicFolder:c:\Litestep\lsdrinks\LancedNet"
      *Popup "LinuxGames" "!DynamicFolder:c:\Litestep\lsdrinks\LinuxGames"
      *Popup "LinuxApps" "!DynamicFolder:c:\Litestep\lsdrinks\LinuxApps"
      *Popup "HackerNews " "!DynamicFolder:c:\Litestep\lsdrinks\HackerNews"
      *Popup "HappyPenguinNews" "!DynamicFolder:c:\Litestep\lsdrinks\HappyPenguinNews"
      *Popup "HappyPenguinUpdtes" "!DynamicFolder:c:\Litestep\lsdrinks\HappyPenguinUpdtes"
      *Popup "HappyPenguinAdd" "!DynamicFolder:c:\Litestep\lsdrinks\HappyPenguinAdd"
      *Popup "LinuxQuake" "!DynamicFolder:c:\Litestep\lsdrinks\LinuxQuake"
      *Popup "AbsoluteGamers" "!DynamicFolder:c:\Litestep\lsdrinks\AbsoluteGamers"
      *Popup "Linux3d" "!DynamicFolder:c:\Litestep\lsdrinks\Linux3d"
      *Popup "Fullon3d" "!DynamicFolder:c:\Litestep\lsdrinks\Fullon3d"
      *Popup "Gizmo3d" "!DynamicFolder:c:\Litestep\lsdrinks\Gizmo3d"
      *Popup "X11spy" "!DynamicFolder:c:\Litestep\lsdrinks\X11spy"
      *Popup "BluesNews" "!DynamicFolder:c:\Litestep\lsdrinks\luesNews"
      *Popup "VoodooExtreme" "!DynamicFolder:c:\Litestep\lsdrinks\VoodooExtreme"
      *Popup "ChunkyMunky" "!DynamicFolder:c:\Litestep\lsdrinks\ChunkyMunky"
      *Popup "Python" "!DynamicFolder:c:\Litestep\lsdrinks\Python"      

5. To run Manually:       At the Command Line Type: perl lsdrinks.pl
   To run Automatically:  Use the Start.bat file. That will start the Wincron program
   and update it every hour at the 30 minute mark. This uses a file called WinCron.dat. This can be 
   changed according to how often you want it to update. Read: \lsdrinks\bin\wincron.txt
   for more information.

6. To make further tweaks just open up the lsdrinks.pl in your favorite text editor. The file
   is documented fairly well. You can turn on and turn off any of the news that you choose.

Way Number 2 As a WebPage
Please look at lsdrinks.rc to make the changes.


# 2.1.6  Added Geeknews.org, Fixed Segfault
# 2.1.5  Added After Y2k Cartoon
#        Added LiteStep.Net,Litestep.net Screen Shots (using backends from MrJukes and geekMASTR)
#        Added the ability for the script to create a directory if one doesn't exist so in including
#        as the sub dirs is no longer needed.
# 2.1.4  Changed floach to read from Desktopian * Thanks Tin_Omen *, Changed Tin_Toys to Desktopian
#        Changed the htm page to added a differnt header and url, Added Shell City
# 2.1.3  Added Astronomy Pic of the Day, Dilbert,FileForum Changed the Way Floach Works.
# 2.1.2  Added User Friendly Strip
# 2.1.1  Lots of cleanup. Several sites are gone and many have changed.
#        I also added a few more formating options for the .htm page.
#        I added a limit to the number of stories that will be shown.
#        Lots of bug fixes and it will now automatically skip a site if
#        its down.
# 2.0    Some more new code, bug fixes and cleanup.
# 1.9    Add the .htm part of the script
# 1.8    Totally rewrote all the code to be more like and engine.
# 1.7    Update Sites Started Changin code
# 1.6    Updated some to the sites that changed there backends and add a few new ones.
#        Desktopz.org,Litestep.org,PCParadox,LancedNet,LinuxGames,LinuxApps
#        HackerNews   # Slow times out on slow connections,HappyPenguinNews
#        HappyPenguinUpdtes,HappyPenguinAdd,LinuxQuake,LinuxQuakePage,AbsoluteGamers
#        Linux3d,Fullon3d,740,Gizmo3d,X11spy,Polyester,MyDesktop,BluesNews
#        VoodooExtreme,ChunkyMunky,Python
# 1.5    Updated some of the existing sites that no longer worked and/or moved there backend files.
#        Added Floach, LiteStepCom, BeNews, BeOSCentral, MattsHouse, ThemesOrg and SolarisCentral 
# 1.4    Added ArsTechnica,Changed some of the code
# 1.3    Added 32BitsOnline, lsNews, and Betanews. 
#        Bugs: 32BitsOnline doesn't format the headlines very well.
# 1.2    Added Tin_Omen, Technotronic, and Geeknews. Tweaked the Code just a bit.
# 1.1    After Tin_Omen suggested better ways to do the popups I have remove the recycle.exe file.
#        It was in the wrong place to begin with :(
#        I also removed the Targ checking as the site is closing down. The How to was update to 
#        reflect the suggestions from Tin_Omen.
