/*

	ClockFace class that handles all the clock functions

*/

#include <math.h>
#include "ClockFace.h"

#include "LSUtils.h"
#include "..\current\lsapi\lsapi.h"

#include "log_on.h"


/* ClockFace */

ClockFace::ClockFace(LPCSTR prefix) :
	bNoSeconds(false),
	Prefix(prefix),
	nResolution(60),
	n12PartSteps(0),
	n60PartSteps(0)
{
	order[0] = 0;
	order[1] = 0;
	order[2] = 0;
}

ClockFace::~ClockFace()
{
	delete minute;
	delete hour;
	if (!bNoSeconds)
		delete second;

	delete ClockHand::sinus;
	delete ClockHand::cosinus;

	//hands.clear();
}

int ClockFace::GetRefresh()
{
	return nRefresh;
}

// buffer which sinus index to use
void ClockFace::CalcIndexBuffers()
{
	int i = 0;
	int j = 0;

	// hours
	for (i=0; i<24; i++)
	{
		for (j=0; j<60; j++)
		{
			HourIndexBuffer[i][j] = (double)(i % 12 + (double)j/60) * n12PartSteps;
		}
	}

	// minutes
	for (i=0; i<60; i++)
	{
		for (j=0; j<60; j++)
		{
			MinuteIndexBuffer[i][j] = (double)(i + (double)j/60) * n60PartSteps;
		}
	}

	// seconds
	for (i=0; i<60; i++)
	{
		for (j=0; j<1000; j++)
		{
			SecondIndexBuffer[i][j] = (double)(i + (double)j/1000) * n60PartSteps;
		}
	}
}

// drawing function, originally from aLsClock
void ClockFace::DrawClock(const HDC hdc, HRGN hrgn)
{
	SYSTEMTIME time;
	GetLocalTime(&time);

	for (int i=0; i<3; i++)
	{
		switch(order[i])
		{
			#ifdef SPAMDEBUG
				LSLogPrintf(LOG_DEBUG, Prefix, "order: %s, t: %d", order[i], time.wSecond);
			#endif

			case 'h':
				//hours
				DrawHours(hdc, hrgn, time);
			break;

			case 'm':
				// minutes
				DrawMinutes(hdc, hrgn, time);
			break;

			case 's':
				//seconds
				if (!bNoSeconds)
				{
					DrawSeconds(hdc, hrgn, time);
				}
			break;

			default:
			break;
		}
	}

	/*
	// test lines
	void (*tst1)(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);
	tst1 = DrawHours;
	tst1(hdc, hrgn, time);

	// test lines
	void (ClockFace::*tst2)(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);
	tst2 = DrawHours;
	tst2(hdc, hrgn, time);

	// use function pointers in given order instead of switching on every update
	HandDrawer temp;
	for (vector<HandDrawer>::iterator i = hands.begin(); i != hands.end(); i++)
	{
		temp = (HandDrawer)(*i);
		temp(hdc, hrgn, time);
	}*/
}

void ClockFace::DrawHours(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	int index = 0;
	// calc hour&minute to base of the given buffer precision
	// index = (double)(time.wHour % 12 + (double)time.wMinute/60) * n12PartSteps;
	index = HourIndexBuffer[time.wHour][time.wMinute];
	#ifdef SPAMDEBUG
		LSLogPrintf(LOG_DEBUG, Prefix, "hi: %d", index);
	#endif
	hour->DrawHand(hdc, hrgn, index);
}

void ClockFace::DrawMinutes(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	int index = 0;
	// index = (double)(time.wMinute + (double)time.wSecond/60) * n60PartSteps;
	index = MinuteIndexBuffer[time.wMinute][time.wSecond];
	#ifdef SPAMDEBUG
		LSLogPrintf(LOG_DEBUG, Prefix, "mi: %d", index);
	#endif
	minute->DrawHand(hdc, hrgn, index);
}

void ClockFace::DrawSeconds(const HDC hdc, HRGN hrgn, const SYSTEMTIME time)
{
	int index = 0;
	// index = (double)(time.wSecond + (double)time.wMilliseconds/1000) * n60PartSteps;
	index = SecondIndexBuffer[time.wSecond][time.wMilliseconds];
	#ifdef SPAMDEBUG
		LSLogPrintf(LOG_DEBUG, Prefix, "si: %d", index);
	#endif
	second->DrawHand(hdc, hrgn, index);
}

void ClockFace::CalcCenter(int width, int height)
{
	// calculate center
	ClockHand::SetCenter((float)width / 2, (float)height / 2);
}

void ClockFace::ReadClockSettings()
{
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "Looking for prefix: %s", Prefix);
#endif

	char szMainHand[MAX_LINE_LENGTH];
	char szTemp[MAX_LINE_LENGTH];
	COLORREF ci, co;
	int w, l, b_main, b, a_main, a;
	int nCenterX = ClockHand::GetCenterX();
	int nCenterY = ClockHand::GetCenterY();

	LSUtils::PrefixedGetRCString(Prefix, "HandType", szMainHand, "line" , MAX_LINE_LENGTH);
	a_main = LSUtils::PrefixedGetRCInt(Prefix, "HandAlpha", 255);
	a_main = max(min(a_main, 255), 0);
	b_main = LSUtils::PrefixedGetRCInt(Prefix, "HandBorder", 1);

	ClockHand::SetAdaptRegion(LSUtils::PrefixedGetRCBool(Prefix, "NoAdaptRegion", TRUE));

	// seconds:
	bNoSeconds = LSUtils::PrefixedGetRCBool(Prefix, "NoSeconds", TRUE);
	if (!bNoSeconds)
	{
		LSUtils::PrefixedGetRCString(Prefix, "SecondHandType", szTemp, szMainHand , MAX_LINE_LENGTH);
		co = LSUtils::PrefixedGetRCColor(Prefix, "SecondColor", RGB(255, 0, 0));
		ci = LSUtils::PrefixedGetRCColor(Prefix, "SecondInnerColor", co);
		b = LSUtils::PrefixedGetRCInt(Prefix, "SecondBorderWidth", b_main);
		w = LSUtils::PrefixedGetRCInt(Prefix, "SecondWeight", 1);
		l = LSUtils::PrefixedGetRCInt(Prefix, "SecondLength", 0.9*min(nCenterX, nCenterY));
		a = LSUtils::PrefixedGetRCInt(Prefix, "SecondAlpha", a_main);
		second = LoadHand(szTemp, ci, co, l, w, b, a);
	}
	
	// minutes:
	LSUtils::PrefixedGetRCString(Prefix, "MinuteHandType", szTemp, szMainHand , MAX_LINE_LENGTH);
	co = LSUtils::PrefixedGetRCColor(Prefix, "MinuteColor", RGB(0, 255, 0));
	ci = LSUtils::PrefixedGetRCColor(Prefix, "MinuteInnerColor", co);
	b = LSUtils::PrefixedGetRCInt(Prefix, "MinuteBorderWidth", b_main);
	l = LSUtils::PrefixedGetRCInt(Prefix, "MinuteLength", 0.9*min(nCenterX, nCenterY));
	w = LSUtils::PrefixedGetRCInt(Prefix, "MinuteWeight", 2);
	a = LSUtils::PrefixedGetRCInt(Prefix, "MinuteAlpha", a_main);
	minute = LoadHand(szTemp, ci, co, l, w, b, a);

	// hours:
	LSUtils::PrefixedGetRCString(Prefix, "HourHandType", szTemp, szMainHand , MAX_LINE_LENGTH);
	co = LSUtils::PrefixedGetRCColor(Prefix, "HourColor", RGB(0, 0, 255));
	ci = LSUtils::PrefixedGetRCColor(Prefix, "HourInnerColor", co);
	b = LSUtils::PrefixedGetRCInt(Prefix, "HourBorderWidth", b_main);
	l = LSUtils::PrefixedGetRCInt(Prefix, "HourLength", 0.7*min(nCenterX, nCenterY));
	w = LSUtils::PrefixedGetRCInt(Prefix, "HourWeight", 3);
	a = LSUtils::PrefixedGetRCInt(Prefix, "HourAlpha", a_main);
	hour = LoadHand(szTemp, ci, co, l, w, b, a);

	nResolution = min(LSUtils::PrefixedGetRCInt(Prefix, "Resolution", 60), 60000);
	nRefresh = LSUtils::PrefixedGetRCInt(Prefix, "Refresh", 60000/nResolution);
	n12PartSteps = (double)nResolution / 12;
	n60PartSteps = (double)nResolution / 60;

	ClockHand::sinus = new SinBuffer(nResolution, 0);
	ClockHand::cosinus = new CosBuffer(nResolution, -(nResolution)/2);

	char t1[MAX_LINE_LENGTH], t2[MAX_LINE_LENGTH], t3[MAX_LINE_LENGTH];
	char* tokens[3] = {t1, t2, t3};

	LSUtils::PrefixedGetRCLine(Prefix, "DrawOrder", szTemp, MAX_LINE_LENGTH, "h m s");
	int count = LCTokenize(szTemp, tokens, 3, NULL);

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "order string: %s, c: %d", szTemp, count);
#endif
	
	for (int i = 0; i < count; i++)// count
	{
		order[i] = tokens[i][0];

		/*
		trying to compile a list in what order functions should be run
		since this is needs only be done once...
		*/
		/*switch(order[i])
		{
			case 'h':
				hands.push_back(this->DrawHours);
			break;

			case 'm':
				hands.push_back(ClockFace::DrawMinutes);
			break;

			case 's':
				if (!bNoSeconds)
				{
					hands.push_back(DrawSeconds);
				}
			break;
		}*/
	}

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "order: %s, c: %d", order, count);
	LSLogPrintf(LOG_DEBUG, Prefix, "lengths: h %d, m %d s %d", hour->GetLength(), minute->GetLength(), second->GetLength());
#endif

	// use the read data to calc trigbuffer indexes
	CalcIndexBuffers();

}

ClockHand* ClockFace::LoadHand(LPCSTR type, COLORREF ci, COLORREF co, int l, int w, int b, int a)
{
	if (stricmp(type, "box") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading boxhand");
#endif
		return new BoxHand(ci, co, l, w, b, a);
	}
	else if (stricmp(type, "triangle") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading trihand");
#endif
		return new TriHand(ci, co, l, w, b, a);
	}
	else if (stricmp(type, "aaline") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading AALineHand");
#endif
		return new AALineHand(ci, co, l, w, b, a);
	}
	else if (stricmp(type, "aabox") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading AABoxHand");
#endif
		return new AABoxHand(ci, co, l, w, b, a);
	}
	else if (stricmp(type, "aatriangle") == 0)
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading AATriHand");
#endif
		return new AATriHand(ci, co, l, w, b, a);
	}
	else 
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, Prefix, "Loading Linehand (default)");
#endif
		return new LineHand(ci, co, l, w, b, a);
	}
}