#ifndef __CLOCKFACE_H
#define __CLOCKFACE_H

#include "TrigBuffer.h"
#include "ClockHand.h"
#include <windows.h>

/*#include <vector>
using namespace std;*/


/* ClockFace */

class ClockFace
{
// trying to use function pointers
// adding ClockFace:: , makes calls go wrong
typedef void (*HandDrawer)(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);

public:
	ClockFace(LPCSTR prefix);
	~ClockFace();
	void DrawClock(const HDC hdc, HRGN hrgn);
	void CalcCenter(int, int);
	void ReadClockSettings();
	ClockHand* LoadHand(LPCSTR type, COLORREF ci, COLORREF co, int l, int w, int b, int a);
	int GetRefresh();
	void CalcIndexBuffers();

	void DrawHours(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);
	void DrawMinutes(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);
	void DrawSeconds(const HDC hdc, HRGN hrgn, const SYSTEMTIME time);

private:
	int HourIndexBuffer[24][60];
	int MinuteIndexBuffer[60][60];
	int SecondIndexBuffer[60][1000];

	const char *Prefix;

	char order[3];

	BOOL bNoSeconds;

	int nResolution;
	int nRefresh;

	//vector<HandDrawer> hands;

	ClockHand *second;
	ClockHand *minute;
	ClockHand *hour;

	double n12PartSteps;
	double n60PartSteps;

};

#endif