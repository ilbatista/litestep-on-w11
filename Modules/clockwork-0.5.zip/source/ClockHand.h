#ifndef __CLOCKHAND_H
#define __CLOCKHAND_H

#include <windows.h>
#include <gdiplus.h>
using namespace Gdiplus;

#include "TrigBuffer.h"

typedef struct
{
	double x;
	double y;
} POINTF;

// for hands & drawing
class ClockHand
{
public:
	ClockHand(COLORREF ci, COLORREF co, int l, int w, int b, int a);
	int GetLength();
	int GetWeight();
	int GetBorder();
	int GetAlpha();
	COLORREF GetColor();
	COLORREF GetInnerColor();

	static void CalcBoxPoints(PointF points[], const int index, const int weight, const int length);
	static void CalcTriPoints(PointF points[], const int index, const int weight, const int length);
	static float GetCenterX();
	static float GetCenterY();
	static void SetCenter(float, float);
	static void SetAdaptRegion(bool bNoAdapt);
	static bool GetAdaptRegion();
	static void ConvertToGDIPoint(POINT out[], const PointF in[], const int size);

	static SinBuffer *sinus;
	static CosBuffer *cosinus;

	virtual void DrawHand(const HDC hdc, HRGN hrgn, const int index) = 0;

private:
	static bool bNoAdaptRegion;

	static float nCenterX;
	static float nCenterY;

	COLORREF clrOut;
	COLORREF clrIn;
	int nWeight;
	int nLength;
	int nBorder;
	int nAlpha;

};


class AATriHand : public ClockHand
{
public:
	AATriHand(COLORREF ci, COLORREF co, int l, int w, int b, int a);
	void DrawHand(const HDC hdc, HRGN hrgn, const int index);
};

class TriHand : public ClockHand
{
public:
	TriHand(COLORREF ci, COLORREF co, int l, int w, int b, int a);
	void DrawHand(const HDC hdc, HRGN hrgn, const int index);
};

class AABoxHand : public ClockHand
{
public:
	AABoxHand(COLORREF ci, COLORREF co, int l, int w, int b, int a);
	void DrawHand(const HDC hdc, HRGN hrgn, const int index);
};

class BoxHand : public ClockHand
{
public:
	BoxHand(COLORREF ci, COLORREF co, int l, int w, int b, int a);
	void DrawHand(const HDC hdc, HRGN hrgn, const int index);
};

class AALineHand : public ClockHand
{
public:
	AALineHand(COLORREF ci, COLORREF co, int l, int w, int b, int a);
	void DrawHand(const HDC hdc, HRGN hrgn, const int index);
};

class LineHand : public ClockHand
{
public:
	LineHand(COLORREF ci, COLORREF co, int l, int w, int b, int a);
	void DrawHand(const HDC hdc, HRGN hrgn, const int index);
};

#endif