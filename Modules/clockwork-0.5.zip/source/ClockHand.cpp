/* ClockHand */

#include <math.h>
#include "ClockHand.h"
#include <gdiplus.h>
using namespace Gdiplus;
#include "log_on.h"

#ifdef DEBUG
	#include "..\current\lsapi\lsapi.h"
#endif

SinBuffer* ClockHand::sinus = NULL;
CosBuffer* ClockHand::cosinus = NULL;
float ClockHand::nCenterX = 0;
float ClockHand::nCenterY = 0;
bool ClockHand::bNoAdaptRegion = false;


ClockHand::ClockHand(COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	clrIn(ci),
	clrOut(co),
	nLength(l),
	nWeight(w),
	nBorder(b),
	nAlpha(a)
{

}

COLORREF ClockHand::GetColor()
{
	return clrOut;
}

COLORREF ClockHand::GetInnerColor()
{
	return clrIn;
}

int ClockHand::GetAlpha()
{
	return nAlpha;
}

int ClockHand::GetBorder()
{
	return nBorder;
}

int ClockHand::GetWeight()
{
	return nWeight;
}

int ClockHand::GetLength()
{
	return nLength;
}

void ClockHand::SetCenter(float cx, float cy)
{
	nCenterX = cx;
	nCenterY = cy;
}

float ClockHand::GetCenterX()
{
	return nCenterX;
}

float ClockHand::GetCenterY()
{
	return nCenterY;
}

void ClockHand::SetAdaptRegion(bool bNoAdapt)
{
	bNoAdaptRegion = bNoAdapt;
}

bool ClockHand::GetAdaptRegion()
{
	return !bNoAdaptRegion;
}

int round(double x)
{
	return (x - floor(x) >= 0.5) ? (int) x+1 : (int) x;

	/*if (x - floor(x) >= 0.5)
		return (int) x+1;
	else
		return (int) x;*/
}

// static convert between gdi+/gdi points
void ClockHand::ConvertToGDIPoint(POINT out[], const PointF in[], const int size)
{
	for (int i = 0; i < size; i++)
	{
		out[i].x = (int)(in[i].X);
		out[i].y = (int)(in[i].Y);
	}
}


/* LineHand, for drawing using lines */
LineHand::LineHand(COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(ci, co, l, w, b, a)
{
}

void LineHand::DrawHand(const HDC hdc, HRGN hrgn, const int index)
{
	HPEN hpen;
	HPEN hpenold;
	int end_x, end_y;

	end_x = GetCenterX() + GetLength() * (*sinus)[index];
	end_y = GetCenterY() + GetLength() * (*cosinus)[index];

	hpen = CreatePen(PS_SOLID, GetWeight(), GetColor());
	hpenold = (HPEN) SelectObject(hdc, hpen);

	MoveToEx(hdc, GetCenterX(), GetCenterY(), NULL);
	LineTo(hdc, end_x, end_y);
	SelectObject(hdc, hpenold);
	DeleteObject(hpen);
}


/* AALineHand, for drawing using gdi+ lines */
AALineHand::AALineHand(COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(ci, co, l, w, b, a)
{
}

void AALineHand::DrawHand(const HDC hdc, HRGN hrgn, const int index)
{
	Graphics graphics(hdc);

	graphics.SetSmoothingMode(SmoothingModeAntiAlias);
	
	Color line(GetAlpha(), GetRValue(GetColor()), GetGValue(GetColor()), GetBValue(GetColor()));
	Pen linePen(line, GetWeight());

	// Initialize the coordinates of the points that define the line.
	REAL x1 = GetCenterX();
	REAL y1 = GetCenterY();
	REAL x2 = GetCenterX() + GetLength() * (*sinus)[index];
	REAL y2 = GetCenterY() + GetLength() * (*cosinus)[index];

	// Draw the line.
	graphics.DrawLine(&linePen, x1, y1, x2, y2);

}


// static, calcs points for a box..
void ClockHand::CalcBoxPoints(PointF points[], const int index, const int weight, const int length)
{
	/*int lwidth = (weight/2) + (weight%2);
	int rwidth = weight/2;*/
	double width = weight/2;

	points[0].X = GetCenterX() - width * (*cosinus)[index]; // l
	points[0].Y = GetCenterY() + width * (*sinus)[index]; // l

	points[1].X = points[0].X + length * (*sinus)[index];
	points[1].Y = points[0].Y + length * (*cosinus)[index];

	points[3].X = GetCenterX() + width * (*cosinus)[index]; // r
	points[3].Y = GetCenterY() - width * (*sinus)[index]; // r

	points[2].X = points[3].X + length * (*sinus)[index];
	points[2].Y = points[3].Y + length * (*cosinus)[index];
}


/* AABoxHand, for drawing using boxes and adding the region */
AABoxHand::AABoxHand(COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(ci, co, l, w, b, a)
{
}

void AABoxHand::DrawHand(const HDC hdc, HRGN hrgn, const int index)
{
	Graphics graphics(hdc);

	//graphics.SetCompositingQuality(CompositingQualityGammaCorrected);
	graphics.SetSmoothingMode(SmoothingModeAntiAlias);
	
	Color poly(GetAlpha(), GetRValue(GetColor()), GetGValue(GetColor()), GetBValue(GetColor()));
	Pen polyPen(poly, GetBorder());
	Color in(GetAlpha(), GetRValue(GetInnerColor()), GetGValue(GetInnerColor()), GetBValue(GetInnerColor()));
	SolidBrush polyBrush(in);

	PointF points[4];
	CalcBoxPoints(points, index, GetWeight(), GetLength());
	POINT ps[4];
	ConvertToGDIPoint(ps, points, 4);

	if ( RGB(255, 0, 255) != GetInnerColor())
		graphics.FillPolygon(&polyBrush, points, 4);

	graphics.DrawPolygon(&polyPen, points, 4);

	if (GetAdaptRegion())
	{
		// adapt region to it as well
		HRGN add = CreatePolygonRgn(ps, 4, WINDING);
		CombineRgn(hrgn, hrgn, add, RGN_OR);
		DeleteObject(add);
	}
}


/* BoxHand, for drawing using boxes and adding the region */
BoxHand::BoxHand(COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(ci, co, l, w, b, a)
{
}

void BoxHand::DrawHand(const HDC hdc, HRGN hrgn, const int index)
{
	HPEN hpen;
	HPEN hpenold;
	HBRUSH hbrush;
	HBRUSH hbrushold;

	PointF points[4];
	CalcBoxPoints(points, index, GetWeight(), GetLength());
	POINT ps[4];
	ConvertToGDIPoint(ps, points, 4);

	SetPolyFillMode(hdc, WINDING);
	hpen = CreatePen(PS_SOLID, GetBorder(), GetColor());
	hpenold = (HPEN) SelectObject(hdc, hpen);

	hbrush = CreateSolidBrush( GetInnerColor() );
	hbrushold = (HBRUSH) SelectObject(hdc, hbrush);

	// draw using box polygon
	Polygon(hdc, ps, 4);

	if (GetAdaptRegion())
	{
		// adapt region to it as well
		HRGN add = CreatePolygonRgn(ps, 4, WINDING);
		CombineRgn(hrgn, hrgn, add, RGN_OR);
		DeleteObject(add);
	}

	SelectObject(hdc, hbrushold);
	DeleteObject(hbrush);

	SelectObject(hdc, hpenold);
	DeleteObject(hpen);
}

// static, calcs points for a triangle..
void ClockHand::CalcTriPoints(PointF points[], const int index, const int weight, const int length)
{
	/*int lwidth = (weight/2) + (weight%2);
	int rwidth = weight/2;*/
	double width = weight/2;

	points[0].X = GetCenterX() - width * (*cosinus)[index]; // l
	points[0].Y = GetCenterY() + width * (*sinus)[index]; // l

	points[1].X = GetCenterX() + length * (*sinus)[index];
	points[1].Y = GetCenterY() + length * (*cosinus)[index];

	points[2].X = GetCenterX() + width * (*cosinus)[index]; // r
	points[2].Y = GetCenterY() - width * (*sinus)[index]; // r
}

/* AATriHand, for drawing using a triangle polygon and adding the region */
AATriHand::AATriHand(COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(ci, co, l, w, b, a)
{
}

void AATriHand::DrawHand(const HDC hdc, HRGN hrgn, const int index)
{
	Graphics graphics(hdc);

	graphics.SetCompositingQuality(CompositingQualityGammaCorrected);

	graphics.SetSmoothingMode(SmoothingModeAntiAlias);
	
	Color poly(GetAlpha(), GetRValue(GetColor()), GetGValue(GetColor()), GetBValue(GetColor()));
	Pen polyPen(poly, GetBorder());
	Color in(GetAlpha(), GetRValue(GetInnerColor()), GetGValue(GetInnerColor()), GetBValue(GetInnerColor()));
	SolidBrush polyBrush(in);
	polyPen.SetBrush(&polyBrush);

	PointF points[3];
	CalcTriPoints(points, index, GetWeight(), GetLength());
	POINT ps[3];
	ConvertToGDIPoint(ps, points, 3);

	if ( RGB(255, 0, 255) != GetInnerColor())
		graphics.FillPolygon(&polyBrush, points, 3);

	graphics.DrawPolygon(&polyPen, points, 3);

	if (GetAdaptRegion())
	{
		// adapt region to it as well
		HRGN add = CreatePolygonRgn(ps, 3, WINDING);
		CombineRgn(hrgn, hrgn, add, RGN_OR);
		DeleteObject(add);
	}
}


/* TriHand, for drawing using a triangle polygon and adding the region */
TriHand::TriHand(COLORREF ci, COLORREF co, int l, int w, int b, int a) :
	ClockHand(ci, co, l, w, b, a)
{
}

void TriHand::DrawHand(const HDC hdc, HRGN hrgn, const int index)
{
	HPEN hpen;
	HPEN hpenold;
	HBRUSH hbrush;
	HBRUSH hbrushold;

	PointF points[3];
	CalcTriPoints(points, index, GetWeight(), GetLength());
	POINT ps[3];
	ConvertToGDIPoint(ps, points, 3);

	SetPolyFillMode(hdc, WINDING);
	hpen = CreatePen(PS_SOLID, GetBorder(), GetColor());
	hpenold = (HPEN) SelectObject(hdc, hpen);

	hbrush = CreateSolidBrush( GetInnerColor() );
	hbrushold = (HBRUSH) SelectObject(hdc, hbrush);

	// draw using triangle polygon
	Polygon(hdc, ps, 3);
	if (GetAdaptRegion())
	{
		// adapt region to it as well
		HRGN add = CreatePolygonRgn(ps, 3, WINDING);
		CombineRgn(hrgn, hrgn, add, RGN_OR);
		DeleteObject(add);
	}

	SelectObject(hdc, hbrushold);
	DeleteObject(hbrush);

	SelectObject(hdc, hpenold);
	DeleteObject(hpen);
}