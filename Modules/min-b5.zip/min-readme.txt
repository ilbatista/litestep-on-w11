///////////////////////////////
// Minimize to Desktop Icon
// By: MrJukes (Bret Anderson)
// Released: 4/4/99
///////////////////////////////

// Settings in win.ini
// The format is 0x00BBGGRR
[min]
BackgroundColor=0x00000000 
TextColor=0x00FFFFFF

Left click and drag will drag the icon around.
Double click with the left will restore the window.
Right click will bring up the popup menu.

To load in your step.rc put this line AFTER loading desktop.dll:
	LoadModule c:\litestep\min.dll

Have fun,
	MrJukes