#include "common.h"
#include "Label.h"
#include "LabelSettings.h"
#include "Font.h"
#include "Texture.h"
#include "SystemInfo.h"

#include "ShowStyle.h"
#include "contextmenu.h"

#include <shellapi.h>
#include <shlobj.h>

#define TIMER_MOUSETRACK 1
#define TIMER_UPDATE 2
#define TIMER_SCROLL 3
#define TIMER_AUTOHIDE 4
#define TIMER_MOUSETRACK_MOVE 5
#define TIMER_ALPHAFADEIN 6
#define TIMER_ALPHAFADEOUT 7
#define TIMER_FRAMEANIMATION 8
#define TIMER_AUTOSIZEUPDATE 9

extern LabelList labelList;
extern LabelList desktoplabelList;
extern LabelList shortcutlabelList;

Label::Label(const string &name):actualheight(0),actualwidth(0),actualx(0),actualy(0)
{
	this->name = name;

	mousePressed = false;
	mouseInside = false;

	movemodifierkeyPressed = false;
	moveButtonPressed = 0;

	hWnd = 0;
	hInstance = 0;
	box = 0;

	canBeVisible = true;
	visible = false;
	bUsingDefSkin = false;
	bInDestructor = false;

	autoWidthMode = 0;
	autoHeightMode = 0;

	scroll = 0;
	scrollBackup = 0;
	frozen = false;
	scrollLimit = 0;
	scrollPosition = 0;
	
	backgroundDC = 0;
	bufferDC = 0;
	backgroundBitmap = 0;
	bufferBitmap = 0;

	hoverActive = false;
	pressedActive = false;

	useHover = false;
	usePressed = false;

	background = 0;
	font = 0;

	originalText.push_back("");
	current = 0;

	textChange = false;

	labelType = 0;

	newlineCounter = 1;

	alphaFade = false;

	//Animations
	frameCounter = 0;
	loopCounter = -1;
	normalAnim = false;
	hoverAnim = false;

	paintInProgress = false;
	reallyOverBlend = false;
	overblendStyle = 0;

	//Plugins
	htmltext = false;
	maxHtmlTextWidth = 0;
	maxHtmlTextHeight = 0;

	anim = false;
}

Label::~Label()
{
	bInDestructor = true;

	if (m_PluginHtmlText != NULL)
	{
		FreeLibrary(m_PluginHtmlText);
		m_PluginHtmlText = NULL;
	}
	if (m_PluginAnim != NULL)
	{
		FreeLibrary(m_PluginAnim);
		m_PluginAnim = NULL;
	}

	if (hWnd && TooltipHints)
	{
		removeHint(hWnd);
		DestroyWindow(TooltipHints);
	}

	if(IsWindow(hWnd))
	{
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
		KillTimer(hWnd, TIMER_MOUSETRACK);
		KillTimer(hWnd, TIMER_UPDATE);
		KillTimer(hWnd, TIMER_SCROLL);
		KillTimer(hWnd, TIMER_AUTOHIDE);
		KillTimer(hWnd, TIMER_ALPHAFADEIN);
		KillTimer(hWnd, TIMER_ALPHAFADEOUT);
		KillTimer(hWnd, TIMER_FRAMEANIMATION);
		KillTimer(hWnd, TIMER_AUTOSIZEUPDATE);

		DestroyWindow(hWnd);
	}

	if(backgroundBitmap)
	{
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
		DeleteObject(backgroundBitmap);
	}
	if (backgroundDC)
		DeleteDC(backgroundDC);

	if(bufferBitmap)
	{
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
		DeleteObject(bufferBitmap);
	}
	if (bufferDC)
		DeleteDC(bufferDC);

	if(!bUsingDefSkin)
		delete background;

	if(font != defaultSettings->font)
		delete font;
}

void Label::load(HINSTANCE hInstance, HWND box)
{
	this->hInstance = hInstance;
	
	if (IsWindow(box))
	{
		this->box = box;
	}
	else
	{
		this->box = NULL;
	}
	
	if (IsWindow(hWnd))	// window already exists...
		return;

	hWnd = CreateWindowEx(box ? 0 : WS_EX_TOOLWINDOW,
		"xLabel",
		name.c_str(),
		box ? WS_CHILD : WS_POPUP,
		actualx, actualy,			// FIXME they're all 0, the window will be repositioned
		actualwidth, actualheight,	// FIXME see above
		box ? box : GetLitestepWnd(), // GetLitestepDesktop(), FIXME: this way there aren't as many z-order problems =)
		0,
		hInstance,
		this);

	if(IsOS(OS_2KXP))
		ModifyStyleEx(hWnd, 0, WS_EX_LAYERED);
		
	if (hWnd)
	{
		SetWindowLong(hWnd, GWL_USERDATA, MAGIC_DWORD);

		//ToolTips for Labels
		if ( !(GetRCString(name.c_str(), "Tooltip", "")).empty() )
		{
			TooltipHints = CreateWindow(TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP,
										  CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
										  NULL, NULL, hInstance, NULL);
			if (TooltipHints)
				SetWindowPos(TooltipHints, HWND_TOPMOST, 0, 0, 0, 0,
							 SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
		}

		reconfigure(); 
		textChange = true;
		if ( autoWidthMode != 0 || autoHeightMode != 0 )
			SetTimer(hWnd, TIMER_AUTOSIZEUPDATE, 500, NULL);
		repaint();
	}
	else
		delete this;
}

void Label::desktopload(HINSTANCE hInstance, string configLine)
{
	this->hInstance = hInstance;
	
    this->box = NULL;
	
	if (IsWindow(hWnd))	// window already exists...
		return;
		
	hWnd = CreateWindowEx(box ? 0 : WS_EX_TOOLWINDOW,
		"xLabel",
		name.c_str(),
		box ? WS_CHILD : WS_POPUP,
		actualx, actualy,			// FIXME they're all 0, the window will be repositioned
		actualwidth, actualheight,	// FIXME see above
		box ? box : GetLitestepWnd(), // GetLitestepDesktop(), FIXME: this way there aren't as many z-order problems =)
		0,
		hInstance,
		this);
		
	if(IsOS(OS_2KXP))
		ModifyStyleEx(hWnd, 0, WS_EX_LAYERED);

	if (hWnd)
	{
		SetWindowLong(hWnd, GWL_USERDATA, MAGIC_DWORD);
		
		//ToolTips for Icons
		TooltipHints = CreateWindow(TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP,
									  CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
									  NULL, NULL, hInstance, NULL);
		if (TooltipHints)
			SetWindowPos(TooltipHints, HWND_TOPMOST, 0, 0, 0, 0,
						 SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);

		desktopreconfigure(configLine);
		repaint();
	}
	else
		delete this;

}

void Label::shortcutload(HINSTANCE hInstance, string configLine, int lastx, int lasty)
{
	this->hInstance = hInstance;
	
    this->box = NULL;
	
	if (IsWindow(hWnd))	// window already exists...
		return;
		
	hWnd = CreateWindowEx(box ? 0 : WS_EX_TOOLWINDOW,
		"xLabel",
		name.c_str(),
		box ? WS_CHILD : WS_POPUP,
		actualx, actualy,			// FIXME they're all 0, the window will be repositioned
		actualwidth, actualheight,	// FIXME see above
		box ? box : GetLitestepWnd(), // GetLitestepDesktop(), FIXME: this way there aren't as many z-order problems =)
		0,
		hInstance,
		this);
		
	if(IsOS(OS_2KXP))
		ModifyStyleEx(hWnd, 0, WS_EX_LAYERED);

	if (hWnd)
	{
		SetWindowLong(hWnd, GWL_USERDATA, MAGIC_DWORD);

		//ToolTips for Shortcut2
		TooltipHints = CreateWindow(TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP,
									  CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
									  NULL, NULL, hInstance, NULL);
		if (TooltipHints)
			SetWindowPos(TooltipHints, HWND_TOPMOST, 0, 0, 0, 0,
						 SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);

		shortcutreconfigure(configLine, lastx, lasty);
		repaint();
	}
	else
		delete this;

}

void Label::reconfigure()
{
	LabelSettings settings(name.c_str());
	
	transparencyMode = settings.transparencyMode;
	alphaTransparency = settings.alphaTransparency;

	setBackground(settings.skin);		// FIXME: this does not check if old == new on !refresh
	setFont(settings.font);				// FIXME: see above
	
	autoWidthMode = settings.autoWidthMode;
	autoHeightMode = settings.autoHeightMode;
	autoMinWidth = settings.width;
	autoMinHeight = settings.height;
	autoMaxWidth = settings.autoMaxWidth;
	autoMaxHeight = settings.autoMaxHeight;
	startCenterX = settings.x+(settings.width/2);
	startCenterY = settings.y+(settings.height/2);

	reposition(settings.x, settings.y, settings.width, settings.height);	// FIXME? doesn't check old == new;

	tooltip = settings.tooltip;
	if (!tooltip.empty())
	{
		char tooltiptext[256];
		strcpy(tooltiptext, (systemInfo->processLabelText(tooltip, this, &dynamicText)).c_str());
		addHint(this->hWnd, tooltiptext);
		strcpy(oldtooltiptext, tooltiptext);
	}

	labelGroup = settings.labelGroup;

	bUseFahrenheit = settings.bUseFahrenheit;
	
	if ( !(GetRCString(name.c_str(), "HoverImage", "")).empty() || !(GetRCString(name.c_str(), "HoverFrames", "")).empty())
		useHover = true;
	if ( !(GetRCString(name.c_str(), "PressedImage", "")).empty() )
		usePressed = true;

	setAlign(settings.align);
	setVertAlign(settings.vertAlign);

	setText(settings.text);

	lineBreak = settings.lineBreak;

	alwaysUpdateContent = settings.alwaysUpdateContent;
	setUpdateInterval(settings.updateInterval);

	setLeftBorder(settings.leftBorder);
	setTopBorder(settings.topBorder);
	setRightBorder(settings.rightBorder);
	setBottomBorder(settings.bottomBorder);

	leftClickCommand = settings.leftClickCommand;
	leftDoubleClickCommand = settings.leftDoubleClickCommand;
	middleClickCommand = settings.middleClickCommand;
	middleDoubleClickCommand = settings.middleDoubleClickCommand;
	rightClickCommand = settings.rightClickCommand;
	rightDoubleClickCommand = settings.rightDoubleClickCommand;
	wheelDownCommand = settings.wheelDownCommand;
	wheelUpCommand = settings.wheelUpCommand;
	enterCommand = settings.enterCommand;
	leaveCommand = settings.leaveCommand;
	dropCommand = settings.dropCommand;
	textChangeCommand = settings.textChangeCommand;

	scrollPadLength = settings.scrollPadLength;
	scrollInterval = settings.scrollInterval;
	scrollSpeed = settings.scrollSpeed;
	setScrolling(settings.scroll);

	moveable = settings.moveable;
	moveKey = settings.moveKey;
	moveButton = settings.moveButton;
	
	labelLeftClickRegions = settings.labelLeftClickRegions;
	labelRightClickRegions = settings.labelRightClickRegions;
	labelMiddleClickRegions = settings.labelMiddleClickRegions;

	enterleaveRegion = settings.enterleaveRegion;

	imageLoop = settings.imageLoop;
	imageFrameCount = settings.imageFrameCount;
	if (imageFrameCount != 0)
		normalAnim = true;
	imageFrameDelay = settings.imageFrameDelay;

	hoverimageLoop = settings.hoverimageLoop;
	hoverimageFrameCount = settings.hoverimageFrameCount;
	if (hoverimageFrameCount != 0)
		hoverAnim = true;
	hoverimageFrameDelay = settings.hoverimageFrameDelay;

	if (normalAnim)
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);

	overblendStyle = settings.overblendStyle;

	if (hWnd)
	{
		if(IsOS(OS_2KXP))
			UpdateWindowTransparent(hWnd, alphaTransparency);
		setGhosted(settings.ghosted);

		htmltext = settings.htmltext;
		if (htmltext)
		{
			if (!InitializeDLL("xhtmltext.dll"))
				htmltext = false;
		}
		anim = settings.anim;
		if (anim)
		{
			int tmpEffect = settings.animEffect;
			if (tmpEffect == -1)
				animEffect = Random;
			else if (tmpEffect == 0)
				animEffect = Spin;
			else if (tmpEffect == 1)
				animEffect = Vortex;
			else if (tmpEffect == 2)
				animEffect = ScatterGather;
			else if (tmpEffect == 3)
				animEffect = Spike;
			else if (tmpEffect == 4)
				animEffect = Fireworks;

			animSteps = settings.animSteps;
			animAfterSteps = settings.animAfterSteps;
			animDelay = settings.animDelay;
		    if (!InitializeDLL("xanim.dll"))
				anim = false;
		}
		alphaFade = settings.alphaFade;

		if (dropCommand.empty())
			DragAcceptFiles(hWnd, FALSE);
		else
			DragAcceptFiles(hWnd, TRUE);

		RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW);
		settings.startHidden ? hide() : show();
		RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW);
	}

	setAlwaysOnTop(settings.alwaysOnTop);	
}

void Label::desktopreconfigure(string configLine)
{
	NameValuePair iconTextValues[] = {
		{ "top", 1 },
		{ "bottom", 2 },
		{ "left", 3 },
		{ "right", 4 },
		{ 0, 0 }
	};

	ghosted = false;
	labelType = 1;
	labelGroup = "xlabeldesktop";
	lineBreak = true;
	int iconSize = GetRCInt("xlabeldesktop", "IconSize", 32);
	int iconTextAlign = GetRCNamedValue("xlabeldesktop", "TextPosition", iconTextValues, 2);
	int iconTextSpacing = GetRCInt("xlabeldesktop" , "TextSpacing", 5);
	
	rememberPosition = GetRCBoolean("xlabeldesktop", "RememberPosition", false);
	configSavePath = GetRCString("xlabeldesktop", "ConfigFile", "");

	bUseFahrenheit = false;
	
	char name[32], ix[16], iy[16], path[128];
	char *buffers[] = {name, ix, iy};

	if(LCTokenize(configLine.c_str(), buffers, 3, path) >= 3)
	{
		actualwidth = GetRCInt("xlabeldesktop", "ItemWidth", 125);
		actualheight = GetRCInt("xlabeldesktop", "ItemHeight", 50);
	}

	transparencyMode = 1;
	alphaTransparency = GetRCInt("xlabeldesktop", "AlphaTransparency", 255, 0 , 255);

	actualx = ParseCoord(ix, 0, GetSystemMetrics(SM_CXSCREEN));
	actualy = ParseCoord(iy, 0, GetSystemMetrics(SM_CXSCREEN));

	setBackground( GetDesktopTexture(path, this->getName()) );		// FIXME: this does not check if old == new on !refresh
	setFont( GetRCFont("xlabeldesktop") );							// FIXME: see above

	reposition(actualx, actualy , actualwidth, actualheight);

	string result;
	
	//Find Filename
	string s = path;
	int i = s.rfind("\\");
	i = (i < 0) ? 0 : i + 1;
	s = s.substr(i, s.length() - i);

	//Remove Extention
	i = s.find(".");
	i = (i < 0) ? s.length() : i;
	s = s.substr(0, i);

	result = s;

	setAlign(DT_CENTER);

	setText(result);

	autoWidthMode = 0;
	autoHeightMode = 0;
	/*autoMinWidth = actualwidth;
	autoMinHeight = actualheight;
	autoMaxWidth = 300;
	autoMaxHeight = 200;
	startCenterX = actualx+(actualwidth/2);
	startCenterY = actualy+(actualheight/2);*/

	alwaysUpdateContent = false;
	setUpdateInterval(1000);

	if (iconTextAlign == 1 || iconTextAlign == 2)
	{
		setLeftBorder(0);
		setRightBorder(0);
	}
	else if (iconTextAlign == 3)
	{
		setLeftBorder(0);
		setRightBorder(iconSize+iconTextSpacing+1);
	}
	else if (iconTextAlign == 4)
	{
		setLeftBorder(iconSize+iconTextSpacing+1);
		setRightBorder(0);
	}

	if (iconTextAlign == 1)
	{
		setTopBorder(0);
		setBottomBorder(iconSize+iconTextSpacing+1);
		setVertAlign(ALIGN_BOTTOM);
	}
	else if (iconTextAlign == 2)
	{
		setTopBorder(iconSize+iconTextSpacing+1);
		setBottomBorder(0);
		setVertAlign(ALIGN_TOP);
	}
	else if (iconTextAlign == 3 || iconTextAlign == 4)
	{
		setTopBorder(0);
		setBottomBorder(0);
		setVertAlign(ALIGN_CENTER);
	}

	iconCommand = path;
	//Strip '"' or anything else surrounding ;)
	iconCommand = iconCommand.substr(1, iconCommand.length() - 2);

	//ToolTip
	strcpy(path, "File: ");
	strcat(path, iconCommand.c_str());
	addHint(this->hWnd, path);

	leftClickCommand = "";
	leftDoubleClickCommand = ("!execute [\"" + iconCommand + "\"]");
	middleClickCommand = "!labelupdate xlabeldesktop";
	middleDoubleClickCommand = "";
	rightClickCommand = ".contextmenu";
	rightDoubleClickCommand = "";
	wheelDownCommand = "";
	wheelUpCommand = "";
	enterCommand = "";
	leaveCommand = "";
	dropCommand = "";
	textChangeCommand = "";

	scrollPadLength = 10;
	scrollInterval = 100;
	scrollSpeed = 1;
	setScrolling(0);

	moveable = true;
	moveKey = 1;
	moveButton = 1;

	//labelLeftClickRegions = settings.labelLeftClickRegions;
	//labelRightClickRegions = settings.labelRightClickRegions;
	//labelMiddleClickRegions = settings.labelMiddleClickRegions;

	enterleaveRegion = "0 0 -0 -0";

	if (hWnd)
	{
		if(IsOS(OS_2KXP))
			UpdateWindowTransparent(hWnd, alphaTransparency);

		DragAcceptFiles(hWnd, false);
		RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW);
		GetRCBoolean("xlabeldesktop", "StartHidden") ? hide() : show();
		RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW);
	}

	setAlwaysOnTop(false);	

	HDC tmpDC = CreateCompatibleDC(bufferDC);
	HBITMAP tmpBmp = CreateBitmap(actualwidth, actualheight, 1, 32, NULL);
	HGDIOBJ tmpObj = SelectObject(tmpDC, tmpBmp);

	background->apply(tmpDC, 0, 0, actualwidth, actualheight, transparencyMode, 0);

	SelectObject(tmpDC, tmpObj);

	// region handling a la MickeM =)
	HRGN region = BitmapToRegion(tmpBmp, RGB(254, 0, 254), 0, 0, 0);
	HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
	CombineRgn(windowRgn, region, NULL, RGN_COPY);

	if (!SetWindowRgn(hWnd, windowRgn, true))
		DeleteObject(windowRgn);

	DeleteObject(tmpBmp);
	DeleteObject(tmpObj);
	DeleteDC(tmpDC);	
}

void Label::shortcutreconfigure(string configLine, int lastx, int lasty)
{
	labelType = 2;

	char name[32], ix[16], iy[16], normal[64], hover[64], pressed[64], rest[256];
	char *buffers[] = {name, ix, iy, normal, hover, pressed};

	LCTokenize(configLine.c_str(), buffers, 6, rest);

	if ( stricmp(hover, ".none") != 0 )
		useHover = true;
	if ( stricmp(pressed, ".none") != 0 )
		usePressed = true;
	
	//Initializing
	LPSTR fLCommand = "";
    LPSTR fRCommand = "";
    LPSTR fMCommand = "";
	LPSTR fDropCommand = "";

	bool IsVisible;
	bool AcceptInput;
	bool Transparency;
	bool UseTooltip = GetRCBoolean("shortcut", "ShowCaptions", true);

	labelGroup = "0";
	char token[4096];
	LPCSTR nextToken = rest;
	bool hasCommand = true;

	if (GetToken(nextToken, token, &nextToken, false))
	{
		if (token[0] == '#')
		{
			//Lowercase
			strlwr(token);
			int tmpGroup = atoi(&token[1]);
			char buffer[16];
			labelGroup = itoa( tmpGroup, buffer, 10 );
			AcceptInput = !strchr(token, 'k');
            IsVisible = !strchr(token, 'h');
			alwaysOnTop = strchr(token, 't') != 0;
			Transparency = !strchr(token, 'o') != 0;
			moveable = strchr(token, 'm') != 0;
			rememberPosition = strchr(token, 's') != 0;

			if (UseTooltip)
				UseTooltip = !strchr(token, 'c');
			else
				UseTooltip = strchr(token, 'c') != 0;
          
            hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		}

		//Start Compatibility Modus to filter out sound definitions
		if (StrIPos(token, ".wav"))
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		else if (StrIPos(token, ".none"))
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		else if (StrIPos(token, ".def"))
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
	
		if (StrIPos(token, ".wav"))
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		else if (StrIPos(token, ".none"))
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		else if (StrIPos(token, ".def"))
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		//End Compatibility Modus to filter out sound definitions

        // ugly hack
        if (hasCommand)
        {
            char szCommands[4096];
            char szLCommand[4096] = { 0 };
            char szRCommand[4096] = { 0 };
            char szMCommand[4096] = { 0 };
            char szDropCommand[4096] = { 0 };
            
            if (nextToken)
            {
                sprintf(szCommands, "[%s] %s", token, nextToken);
            }
            else
            {
                sprintf(szCommands, "[%s]", token);
            }

            if (token[0] == '[')
            {
                LPSTR lpszCommands[] = { szLCommand, szRCommand, szMCommand, szDropCommand };
                CommandTokenize(szCommands, lpszCommands, 4, NULL);
            }
            else
            {
                // compatibility mode, leftclick only
                strcpy(szLCommand, szCommands);
            }
           
            if (szLCommand[0])
            {
                fLCommand = new char[strlen(szLCommand) + 1];
                strcpy(fLCommand, szLCommand);
            }

            if (szRCommand[0])
            {
                fRCommand = new char[strlen(szRCommand) + 1];
                strcpy(fRCommand, szRCommand);
            }

            if (szMCommand[0])
            {
                fMCommand = new char[strlen(szMCommand) + 1];
                strcpy(fMCommand, szMCommand);
            }

            if (szDropCommand[0])
            {
                fDropCommand = new char[strlen(szDropCommand) + 1];
                strcpy(fDropCommand, szDropCommand);
            }
            else if (szLCommand[0])
            {
                // default drag&drop command to leftclick command
                fDropCommand = new char[strlen(szLCommand) + 1];
                strcpy(fDropCommand, szLCommand);
            }
        }
	}

	configSavePath = GetRCString("shortcut", "ConfigFile", "");	

	string images = normal;
	images.append(" ");
	images.append(hover);
	images.append(" ");
	images.append(pressed);

	string trans;
	if (Transparency)
	{
		transparencyMode = 1;
		trans = "true";
	}
	else
	{
		transparencyMode = 3;
		trans = "false";
	}

	setBackground( GetShortcutTexture(images, trans) );		// FIXME: this does not check if old == new on !refresh
	setFont( GetRCFont("") );								// FIXME: see above
	
	HBITMAP	checkbitmap = LoadLSImage(normal, 0);
	GetLSBitmapSize(checkbitmap, &actualwidth, &actualheight);

	reposition(ParseCoord(ix, 0, GetSystemMetrics(SM_CXSCREEN), lastx), ParseCoord(iy, 0, GetSystemMetrics(SM_CYSCREEN), lasty), actualwidth, actualheight);	// FIXME? doesn't check old == new;

	if (UseTooltip)
		addHint(this->hWnd, name);

	//bUseFahrenheit = settings.bUseFahrenheit;
	
	//setAlign(settings.align);
	//setVertAlign(settings.vertAlign);
	//setText(settings.text);

	lineBreak = false;

	//alwaysUpdateContent = settings.alwaysUpdateContent;
	//setUpdateInterval(settings.updateInterval);

	//setLeftBorder(settings.leftBorder);
	//setTopBorder(settings.topBorder);
	//setRightBorder(settings.rightBorder);
	//setBottomBorder(settings.bottomBorder);

	if (AcceptInput)
	{
		leftClickCommand = fLCommand;
		//leftDoubleClickCommand = settings.leftDoubleClickCommand;
		middleClickCommand = fMCommand;
		//middleDoubleClickCommand = settings.middleDoubleClickCommand;
		rightClickCommand = fRCommand;
		//rightDoubleClickCommand = settings.rightDoubleClickCommand;
		//wheelDownCommand = settings.wheelDownCommand;
		//wheelUpCommand = settings.wheelUpCommand;
		//enterCommand = settings.enterCommand;
		//leaveCommand = settings.leaveCommand;
		//dropCommand = fDropCommand;
		//textChangeCommand = settings.textChangeCommand;
	}
	else 
		setGhosted(true);

	//scrollPadLength = settings.scrollPadLength;
	//scrollInterval = settings.scrollInterval;
	//scrollSpeed = settings.scrollSpeed;
	//setScrolling(0);

	moveKey = 1;
	moveButton = 1;

	//labelLeftClickRegions = settings.labelLeftClickRegions;
	//labelRightClickRegions = settings.labelRightClickRegions;
	//labelMiddleClickRegions = settings.labelMiddleClickRegions;

	enterleaveRegion = "0 0 -0 -0";

	if (hWnd)
	{
		if(IsOS(OS_2KXP))
			UpdateWindowTransparent(hWnd, 255);

		DragAcceptFiles(hWnd, FALSE);
		RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW);
		IsVisible ? show() : hide();
		RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW);
	}

	setAlwaysOnTop(alwaysOnTop);

	//CleanUp
	if (fLCommand)
		delete[] fLCommand;
    if (fRCommand)
        delete[] fRCommand;
    if (fMCommand)
        delete[] fMCommand;
    if (fDropCommand)
        delete[] fDropCommand;
}

void Label::mzscriptvarcopy(string var)
{
	string bang = ("!varset " + var + " \"" + text + "\"");
	LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
}

void Label::posmzscriptvarcopy(string varx, string vary)
{
	if (box)
		return;

	string bang;
	string posx, posy;

	RECT cr;
	GetWindowRect(this->hWnd, &cr);

	char buffer[32];
	sprintf(buffer, "%d", cr.left);
	posx = buffer;
	sprintf(buffer, "%d", cr.top);
	posy = buffer;

	bang = ("!varset " + varx + " \"" + posx + "\"");
	LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);

	bang = ("!varset " + vary + " \"" + posy + "\"");
	LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
}

void Label::sizemzscriptvarcopy(string varcx, string varcy)
{
	if (box)
		return;

	string bang;
	string cx, cy;

	RECT cr;
	GetWindowRect(this->hWnd, &cr);

	char buffer[32];
	sprintf(buffer, "%d", cr.right-cr.left);
	cx = buffer;
	sprintf(buffer, "%d", cr.bottom-cr.top);
	cy = buffer;

	bang = ("!varset " + varcx + " \"" + cx + "\"");
	LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);

	bang = ("!varset " + varcy + " \"" + cy + "\"");
	LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
}

void Label::setAlwaysOnTop(bool alwaysOnTop)
{
	this->alwaysOnTop = alwaysOnTop;
	
	if (box)
		return;
	
	if(hWnd)
	{
		ModifyStyle(hWnd, WS_POPUP, WS_CHILD);
		SetParent(hWnd, alwaysOnTop ? 0 : GetLitestepDesktop());
		ModifyStyle(hWnd, WS_CHILD, WS_POPUP);
		
		SetWindowPos(hWnd, alwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
			0, 0, 0, 0,
			SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
	}
}

void Label::setBox(HWND newparent)
{
	if (this->box == newparent)
		return;

	if (this->alwaysOnTop) this->setAlwaysOnTop(FALSE);
	
	this->box = newparent;
	
	ModifyStyle(hWnd, WS_POPUP, WS_CHILD);
	SetParent(hWnd, newparent);
}

void Label::setScrolling(int scrolling)
{
	if (scrolling != 0 && scroll == 0)
	{
		scrollPosition = 0;
		SetTimer(hWnd, TIMER_SCROLL, scrollInterval, 0);
	}
	else if (scrolling == 0 && scroll != 0)
	{
		KillTimer(hWnd, TIMER_SCROLL);
		scrollPosition = 0;
		repaint();
	}

	scrollLimit = 0;
	scroll = scrolling;
	if (scrolling != 0)
		scrollBackup = scrolling;
}

void Label::setScrollLimit(int limit)
{
	if (limit >= 0)
	{
		setScrolling(scrollBackup);
		scrollLimit = limit + 1;
	}
	else
		setScrolling(0);
}

void Label::setBackground(Texture *background)
{
	if(!bUsingDefSkin)
		delete this->background;

	this->background = background;

	bUsingDefSkin = (background == defaultSettings->skin);
	
	repaint(true);
}

void Label::setFont(Font *font)
{
	if(this->font != defaultSettings->font)
		delete this->font;

	this->font = font;
	repaint();
}

void Label::setUpdateInterval(int updateInterval)
{
	this->updateInterval = updateInterval;
	if(hWnd && (dynamicText || alwaysUpdateContent))
		SetTimer(hWnd, TIMER_UPDATE, updateInterval, 0);
}

void Label::setAlign(int align)
{
	if (this->align == align)
		return;

	this->align = align;
	repaint();
}

void Label::setVertAlign(int vertAlign)
{
	if (this->vertAlign == vertAlign)
		return;

	this->vertAlign = vertAlign;
	repaint();
}

void Label::setText(const string &text)
{
	originalText = split(text, ";");
		
	current = 0;
	update();
}

void Label::setLeftBorder(int leftBorder)
{
	if (this->leftBorder == leftBorder)
		return;

	this->leftBorder = leftBorder;
	repaint();
}

void Label::setTopBorder(int topBorder)
{
	if (this->topBorder == topBorder)
		return;

	this->topBorder = topBorder;
	repaint();
}

void Label::setRightBorder(int rightBorder)
{
	if (this->rightBorder == rightBorder)
		return;

	this->rightBorder = rightBorder;
	repaint();
}

void Label::setBottomBorder(int bottomBorder)
{
	if (this->bottomBorder == bottomBorder)
		return;

	this->bottomBorder = bottomBorder;
	repaint();
}

void Label::setAlpha(int factor)
{
	if (factor >= 0 && factor <= 255 && IsOS(OS_2KXP) )
	{
		UpdateWindowTransparent(hWnd, factor);
		this->alphaTransparency = factor;
	}
}

void Label::setGhosted(bool ghosted)
{
	this->ghosted = ghosted;
	
	if (box)
		return;
	
	if(hWnd)
	{
		if (ghosted)
			ModifyStyleEx(hWnd, 0, WS_EX_TRANSPARENT);
		else
			ModifyStyleEx(hWnd, WS_EX_TRANSPARENT, 0);
	}
}

void Label::setAnimation(bool start, int loops)
{
	this->imageLoop = loops;
	this->normalAnim = start;

	if (start)
	{
		frameCounter = 1;
		loopCounter = 0;
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
	}
	else
	{
		frameCounter = 0;
		loopCounter = 0;
		KillTimer(hWnd, TIMER_FRAMEANIMATION);
		repaint(true);
	}	
}

void Label::repaint(bool invalidateCache)
{
	if(hWnd)
	{
		if(invalidateCache)
		{
			if(backgroundDC && backgroundBitmap)
			{
				backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
				DeleteObject(backgroundBitmap);
				backgroundBitmap = 0;
			}
		}

		InvalidateRect(hWnd, 0, FALSE);
	}
}

void Label::move(int newx, int newy, int steps, int time, bool moveBy)
{
	if (steps > 0 && time > 0)
	{
		if (time > 50)
			time = 50;

		int counter = 0;
		int deltax = newx - actualx;
		int deltay = newy - actualy;

		bool growx;
		bool growy;
		if (deltax < 0)
			growx = false;
		else
			growx = true;

		if (deltay < 0)
			growy = false;
		else
			growy = true;

		div_t div_result = div( deltax, steps );
		deltax = div_result.quot;
		div_result = div( deltay, steps );
		deltay = div_result.quot;

		if (deltax == 0 && growx)
			deltax = 1;
		else if (deltax == 0 && !growx)
			deltax = -1;

		if (deltay == 0 && growy)
			deltay = 1;
		else if (deltay == 0 && !growy)
			deltay = -1;

		int dynx = actualx;
		int dyny = actualy;

		if(hWnd)
		{
			int stopper = 0;
			while (counter <= steps)
			{
				stopper = 0; // Stop if x and y finished, stopper = 2
				dynx = dynx+deltax;
				if (growx && dynx > newx)
				{
					dynx = newx;
					stopper++;
				}
				else if (!growx && dynx < newx)
				{
					dynx = newx;
					stopper++;
				}

				dyny = dyny+deltay;
				if (growy && dyny > newy)
				{
					dyny = newy;
					stopper++;
				}
				else if (!growy && dyny < newy)
				{
					dyny = newy;
					stopper++;
				}
				
				SetWindowPos(hWnd, 0, dynx, dyny, 0, 0,
					SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);

				SendMessage(hWnd, WM_PAINT, 0, 0);

				if (stopper == 2)
					counter = steps;
				
				counter++;

				Sleep(time);
			}
			SetWindowPos(hWnd, 0, newx, newy, 0, 0,
					SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
		}

		actualx = newx;
		actualy = newy;
	}
	else
	{
		if(hWnd)
		{
			if (moveBy)
			{
				newx = actualx + newx;
				newy = actualy + newy;
			}

			SetWindowPos(hWnd, 0, newx, newy, 0, 0,
				SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
		}

		actualx = newx;
		actualy = newy;
	}

	if (autoWidthMode != 0 || autoHeightMode != 0)
	{
		startCenterX = actualx+(actualwidth/2);
		startCenterY = actualy+(actualheight/2);
	}
}

void Label::reposition(int newx, int newy, int newwidth, int newheight, int steps, int time)
{
	if (steps > 0 && time > 0)
	{
		if (time > 50)
			time = 50;

		int counter = 0;
		int deltax = newx - actualx;
		int deltay = newy - actualy;
		int deltasizex = newwidth - actualwidth;
		int deltasizey = newheight - actualheight;

		bool growx;
		bool growy;
		bool growsizex;
		bool growsizey;
		
		if (deltax < 0)
			growx = false;
		else
			growx = true;
		if (deltay < 0)
			growy = false;
		else
			growy = true;
		
		if (deltasizex < 0)
			growsizex = false;
		else
			growsizex = true;
		if (deltasizey < 0)
			growsizey = false;
		else
			growsizey = true;

		div_t div_result;
		div_result = div( deltax, steps );
		deltax = div_result.quot;
		div_result = div( deltay, steps );
		deltay = div_result.quot;

		div_result = div( deltasizex, steps );
		deltasizex = div_result.quot;
		div_result = div( deltasizey, steps );
		deltasizey = div_result.quot;

		if (deltax == 0 && growx)
			deltax = 1;
		else if (deltax == 0 && !growx)
			deltax = -1;
		if (deltay == 0 && growy)
			deltay = 1;
		else if (deltay == 0 && !growy)
			deltay = -1;

		if (deltasizex == 0 && growsizex)
			deltasizex = 1;
		else if (deltasizex == 0 && !growsizex)
			deltasizex = -1;
		if (deltasizey == 0 && growsizey)
			deltasizey = 1;
		else if (deltasizey == 0 && !growsizey)
			deltasizey = -1;

		int dynx = actualx;
		int dyny = actualy;
		int dynwidth = actualwidth;
		int dynheight = actualheight;

		if(hWnd)
		{
			int stopper = 0;
			while (counter <= steps)
			{
				stopper = 0; // Stop if x, y, width and height are finished, stopper = 4
				dynx = dynx+deltax;
				if (growx && dynx > newx)
				{
					dynx = newx;
					stopper++;
				}
				else if (!growx && dynx < newx)
				{
					dynx = newx;
					stopper++;
				}

				dyny = dyny+deltay;
				if (growy && dyny > newy)
				{
					dyny = newy;
					stopper++;
				}
				else if (!growy && dyny < newy)
				{
					dyny = newy;
					stopper++;
				}

				dynwidth = dynwidth+deltasizex;
				if (growsizex && dynwidth > newwidth)
				{
					dynwidth = newwidth;
					stopper++;
				}
				else if (!growsizex && dynwidth < newwidth)
				{
					dynwidth = newwidth;
					stopper++;
				}

				dynheight = dynheight+deltasizey;
				if (growsizey && dynheight > newheight)
				{
					dynheight = newheight;
					stopper++;
				}
				else if (!growsizey && dynheight < newheight)
				{
					dynheight = newheight;
					stopper++;
				}
				
				SetWindowPos(hWnd, 0, dynx, dyny, dynwidth, dynheight,
					SWP_NOACTIVATE | SWP_NOZORDER);
				
				SendMessage(hWnd, WM_PAINT, 0, 0);

				if (stopper == 4)
					counter = steps;

				counter++;

				Sleep(time);
			}
			SetWindowPos(hWnd, 0, newx, newy, newwidth, newheight,
				SWP_NOACTIVATE | SWP_NOZORDER);

			actualx = newx;
			actualy = newy;
			actualwidth = newwidth;
			actualheight = newheight;
		}
	}
	else
	{
		if(hWnd)
		{
			SetWindowPos(hWnd, 0, newx, newy, newwidth, newheight,
				SWP_NOACTIVATE | SWP_NOZORDER);
		}

		actualx = newx;
		actualy = newy;
		actualheight = newheight;
		actualwidth = newwidth;
	}

	if ((transparencyMode == 1 && labelType != 1) || box != NULL)
		updateRegion(0);

	if (autoWidthMode != 0 || autoHeightMode != 0)
	{
		startCenterX = actualx+(actualwidth/2);
		startCenterY = actualy+(actualheight/2);
	}
}

void Label::resize(int newwidth, int newheight, int steps, int time, int sizeMode)
{
	if (steps > 0 && time > 0)
	{
		if (time > 50)
			time = 50;

		int counter = 0;
		int deltax = newwidth - actualwidth;
		int deltay = newheight - actualheight;

		bool growx;
		bool growy;
		if (deltax < 0)
			growx = false;
		else
			growx = true;

		if (deltay < 0)
			growy = false;
		else
			growy = true;

		div_t div_result = div( deltax, steps );
		deltax = div_result.quot;
		div_result = div( deltay, steps );
		deltay = div_result.quot;

		if (deltax == 0 && growx)
			deltax = 1;
		else if (deltax == 0 && !growx)
			deltax = -1;
		if (deltay == 0 && growy)
			deltay = 1;
		else if (deltay == 0 && !growy)
			deltay = -1;

		int dynwidth = actualwidth;
		int dynheight = actualheight;

		if(hWnd)
		{
			int stopper = 0;
			while (counter <= steps)
			{
				stopper = 0;  // Stop if width and height are finished, stopper = 2
				dynwidth = dynwidth+deltax;
				if (growx && dynwidth > newwidth)
				{
					dynwidth = newwidth;
					stopper++;
				}
				else if (!growx && dynwidth < newwidth)
				{
					dynwidth = newwidth;
					stopper++;
				}

				dynheight = dynheight+deltay;
				if (growy && dynheight > newheight)
				{
					dynheight = newheight;
					stopper++;
				}
				else if (!growy && dynheight < newheight)
				{
					dynheight = newheight;
					stopper++;
				}
				
				SetWindowPos(hWnd, 0, 0, 0, dynwidth, dynheight,
					SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
				
				SendMessage(hWnd, WM_PAINT, 0, 0);

				if (stopper == 2)
					counter = steps;

				counter++;

				Sleep(time);
			}
			SetWindowPos(hWnd, 0, 0, 0, newwidth, newheight,
					SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);

			actualheight = newheight;
			actualwidth = newwidth;
		}
	}
	else
	{
		if(hWnd)
		{
			if (sizeMode == -1)
			{
				if (newwidth > 0)
					newwidth = actualwidth - newwidth;
				else
					newwidth = actualwidth;
				if (newheight > 0)
					newheight = actualheight - newheight;
				else
					newheight = actualheight;
			}
			else if (sizeMode == 1)
			{
				if (newwidth > 0)
					newwidth = actualwidth + newwidth;
				else
					newwidth = actualwidth;
				if (newheight > 0)
					newheight = actualheight + newheight;
				else
					newheight = actualheight;
			}

			SetWindowPos(hWnd, 0, 0, 0, newwidth, newheight,
				SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
		}

		actualheight = newheight;
		actualwidth = newwidth;
	}

	if ((transparencyMode == 1 && labelType != 1) || box != NULL)
		updateRegion(0);
}

void Label::internalHide()
{
	canBeVisible = false;

	if(hWnd)
	{
		ShowWindow(hWnd, SW_HIDE);
	}
}

void Label::internalShow()
{
	canBeVisible = true;

	if(hWnd && visible)
	{
		ShowWindow(hWnd, SW_SHOWNOACTIVATE);
	}
}

void Label::hide()
{
	if(hWnd)
	{
		visible = false;
		if (alphaFade && IsOS(OS_2KXP))
		{
			UpdateAlpha = alphaTransparency;

			SetTimer(hWnd, TIMER_ALPHAFADEOUT, 25, NULL);
		}
		else
		{
			ShowWindow(hWnd, SW_HIDE);
			if (anim)
			{
				RECT r;
				GetWindowRect(hWnd, &r);
				if (pAnimHide != NULL)
					pAnimHide(r, animEffect, animSteps, animAfterSteps, animDelay);
			}
		}
		KillTimer(hWnd, TIMER_AUTOHIDE);

		if (normalAnim || hoverAnim)
			KillTimer(hWnd, TIMER_FRAMEANIMATION);
	}
}

void Label::show()
{
	if (!hWnd)
		load(hInstance, box);
	
	if(hWnd)
	{
		visible = true;
		KillTimer(hWnd, TIMER_AUTOHIDE);

		if(canBeVisible)
		{
			//Plugin Border Animation
			if (anim)
			{
				RECT r;
				GetWindowRect(hWnd, &r);
				if (pAnimShow != NULL)
					pAnimShow(r, animEffect, animSteps, animAfterSteps, animDelay);
			}
			if (alphaFade && IsOS(OS_2KXP))
			{
				UpdateWindowTransparent(hWnd, 0);

				// Show it _first_
				ShowWindow(hWnd, SW_SHOWNOACTIVATE);	

				// Redraw contents NOW - no flickering since the window's not visible
				RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW); 
				
				UpdateAlpha = 0;

				SetTimer(hWnd, TIMER_ALPHAFADEIN, 25, NULL);
			}
			else
				ShowWindow(hWnd, SW_SHOWNOACTIVATE);

			if (normalAnim)
			{
				frameCounter = 1;
				loopCounter = 0;
				SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
			}
		}
	}
}

void Label::showHide(double timeout)
{
	show();
	SetTimer(hWnd, TIMER_AUTOHIDE, timeout * 1000, NULL);
}

void Label::previous()
{
	current--;
	if(current < 0) current = originalText.size() - 1;
	update();
}

void Label::next()
{
	current++;
	if(current >= originalText.size()) current = 0;
	update();
}

void Label::update()
{
	bool dynamicTooltip = false;
	string oldText = text;

	//Tooltips
	if (!tooltip.empty() && TooltipHints)
	{
		char tooltiptext[256];
		strcpy(tooltiptext, (systemInfo->processLabelText(tooltip, this, &dynamicText)).c_str());
		if ( stricmp(tooltiptext, oldtooltiptext) != 0 )
		{
			updateHint(this->hWnd, tooltiptext);
			strcpy(oldtooltiptext, tooltiptext);
		}

		dynamicTooltip = dynamicText;
	}

	text = systemInfo->processLabelText(originalText[current], this, &dynamicText);
	
	//Start: Split in Multilines and check for longest line
	if(text != oldText)
	{
		vector<string> tmpLongest;
		int iter = 0;
		int longest = 0;
		string longestText;

		tmpLongest = split(text, "\n");
		longest = tmpLongest[iter].length();
		longestText = tmpLongest[iter];

		iter++;
		while (iter < tmpLongest.size())
		{
			if (longest < tmpLongest[iter].length())
			{
				longest = tmpLongest[iter].length();
				longestText = tmpLongest[iter];
			}
			iter++;
		}
		longestTextLine = longestText;
		newlineCounter = iter;

		textChange = true;
	}
	//End: Split in Multilines and check for longest line

	if(hWnd)
	{
		if(dynamicText || dynamicTooltip || alwaysUpdateContent)
			SetTimer(hWnd, TIMER_UPDATE, updateInterval, 0);
		else
			KillTimer(hWnd, TIMER_UPDATE);
	}

	if(text != oldText)
	{
		if(!textChangeCommand.empty())
			LSExecute(NULL, textChangeCommand.c_str(), SW_SHOWNORMAL);
	}

	repaint();
}

void Label::clipboardCopy(string prefix)
{
	string toCopy = prefix.empty() ? text : (prefix + " " + text);
	SetClipboardText(hWnd, toCopy.c_str());
}

void Label::clipboardPaste(string prefix)
{
	char buffer[256];

	if(GetClipboardText(hWnd, buffer, 256))
	{
		string toPaste = prefix.empty() ? string(buffer) : (prefix + " " + string(buffer));
		setText(toPaste);
	}
}

void Label::relayMouseMessageToBox(UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	pt.x = GET_X_LPARAM(lParam);
	pt.y = GET_Y_LPARAM(lParam);

	if (box)
	{
		MapWindowPoints(hWnd, box, &pt, 1);
		PostMessage(box, message, wParam, MAKELPARAM((short) pt.x, (short) pt.y));
	}
	else
	{
		MapWindowPoints(hWnd, GetLitestepDesktop(), &pt, 1);
		PostMessage(GetLitestepDesktop(), message, wParam, MAKELPARAM((short) pt.x, (short) pt.y));
	}
}

void Label::onLButtonDblClk(int x, int y)
{
	if(leftDoubleClickCommand.length() > 0)
		LSExecute(hWnd, leftDoubleClickCommand.c_str(), SW_SHOWNORMAL);
	if (this->getBox() == 0)
		ReorderZOrder();
}

bool Label::checkRegion(int x, int y, StringList inputlist)
{
	bool found = false;
	if (!inputlist.empty())
	{
		for(StringListIterator it = inputlist.begin(); it != inputlist.end(); it++)
		{
			char left[16], top[16], right[16], bottom[16], command[128];
			char *buffers[] = {left, top, right, bottom};

			if(LCTokenize((*it).c_str(), buffers, 4, command) >= 4)
			{
				RECT rc;
				GetClientRect(hWnd, &rc);

				int intleft = ParseCoord(left, 0, rc.right-rc.left);
				int intright = ParseCoord(right, -0, rc.right-rc.left);
				int inttop = ParseCoord(top, 0, rc.bottom-rc.top);
				int intbottom  = ParseCoord(bottom, -0, rc.bottom-rc.top);

				if (intleft < intright && inttop < intbottom)
				{
					POINT pt;
					pt.x = x;
					pt.y = y;

					if(pt.x >= intleft && pt.x <= intright && pt.y >= inttop && pt.y <= intbottom)
					{
						if((*it).length() > 0)
						{	
							string temp = command;
							string bang = ("!execute [" + temp + "]");
							LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
							found = true;
							return found;
						}	
					}
				}
			}
		}
	}
	return found;
}

bool Label::checkenterleaveRegion(int x, int y)
{
	bool inside = false;
	char left[16], top[16], right[16], bottom[16];
	char *buffers[] = {left, top, right, bottom};
	if(LCTokenize(enterleaveRegion.c_str(), buffers, 4, NULL) >= 4)
	{
		POINT pt;
		pt.x = x;
		pt.y = y;

		RECT rc;
		GetClientRect(hWnd, &rc);

		int intleft = ParseCoord(left, 0, rc.right-rc.left);
		int intright = ParseCoord(right, -0, rc.right-rc.left);
		int inttop = ParseCoord(top, 0, rc.bottom-rc.top);
		int intbottom = ParseCoord(bottom, -0, rc.bottom-rc.top);

		if (intleft < intright && inttop < intbottom)
		{
			if(pt.x >= intleft && pt.x <= intright && pt.y >= inttop && pt.y <= intbottom)
				inside = true;
		}
	}

	return inside;
 }

void Label::onLButtonDown(int x, int y)
{
	//Stop Animation Timer (Normal & Hover)
	KillTimer(hWnd, TIMER_FRAMEANIMATION);

	if(moveable && moveButton == 1)
	{
		if(!mousePressed && !movemodifierkeyPressed)
			mousePressed = true;
		else if (!mousePressed && movemodifierkeyPressed)
		{
			if (box)
				return;
			mousePressed = true;
			moveButtonPressed = 1;
			GetCursorPos(&savedpt);
			ScreenToClient(hWnd, &savedpt);
			SetCapture(hWnd);
		}
	}
	else
	{
		if(!mousePressed)
			mousePressed = true;
	}

	if (usePressed)
	{
		hoverActive = false;
		pressedActive = true;
		reallyOverBlend = true;
		repaint(true);
	
		if ((transparencyMode == 1 && labelType != 1) || box != NULL)
			updateRegion(2);
	}
	if (this->getBox() == 0)
		ReorderZOrder();
}

	
void Label::onLButtonUp(int x, int y)
{	
	if(moveable && moveButton == 1)
	{
		if(mousePressed && !movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			
			if (!checkRegion(x, y, labelLeftClickRegions))
			{
				POINT pt;
				pt.x = x;
				pt.y = y;

				RECT rc;
				GetClientRect(hWnd, &rc);

				if(PtInRect(&rc, pt))
				{
					if(leftClickCommand.length() > 0)
						LSExecute(hWnd, leftClickCommand.c_str(), SW_SHOWNORMAL);
				}
			}
			
			if ( rememberPosition )
			{
				string bang;
				bang = ("!labeldesktopsave " + this->name);
				LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
			}

			mousePressed = false;
			moveButtonPressed = 0;
		}
		else if (mousePressed && movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

			if ( rememberPosition )
			{
				string bang;
				bang = ("!labeldesktopsave " + this->name);
				LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
			}

			mousePressed = false;
			moveButtonPressed = 0;
		}
	}
	else
	{
		//To be on the save side
		ReleaseCapture();
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

		if(mousePressed && !checkRegion(x, y, labelLeftClickRegions))
		{
			POINT pt;
			pt.x = x;
			pt.y = y;

			RECT rc;
			GetClientRect(hWnd, &rc);

			if(PtInRect(&rc, pt))
			{
				if(leftClickCommand.length() > 0)
					LSExecute(hWnd, leftClickCommand.c_str(), SW_SHOWNORMAL);
			}
		}
		mousePressed = false;
		moveButtonPressed = 0;
	}

	if (usePressed)
	{
		hoverActive = true;
		pressedActive = false;
		reallyOverBlend = true;
		repaint(true);

		if ((transparencyMode == 1 && labelType != 1) || box != NULL)
			updateRegion(1);
	}
	else if (labelType == 1)
		repaint();

	//Animation RESTART
	if (useHover)
	{
		//Restart Hover Anim
		if (hoverAnim)
		{
			frameCounter = 1;
			loopCounter = 0;
			SetTimer(hWnd, TIMER_FRAMEANIMATION, hoverimageFrameDelay, NULL);
		}
	}
	//Restart Normal Anim
	else if (normalAnim)
	{
		frameCounter = 1;
		loopCounter = 0;
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
	}

	if (this->getBox() == 0)	
		ReorderZOrder();
}

void Label::onMButtonDblClk(int x, int y)
{
	if(middleDoubleClickCommand.length() > 0)
		LSExecute(hWnd, middleDoubleClickCommand.c_str(), SW_SHOWNORMAL);
	if (this->getBox() == 0)
		ReorderZOrder();
}

void Label::onMButtonDown(int x, int y)
{
	//Stop Animation Timer (Normal & Hover)
	KillTimer(hWnd, TIMER_FRAMEANIMATION);

	if(moveable && moveButton == 3)
	{
		if(!mousePressed && !movemodifierkeyPressed)
			mousePressed = true;
		else if (!mousePressed && movemodifierkeyPressed)
		{
			if (box)
				return;
			mousePressed = true;
			moveButtonPressed = 3;
			GetCursorPos(&savedpt);
			ScreenToClient(hWnd, &savedpt);
			SetCapture(hWnd);
		}
	}
	else
	{
		if(!mousePressed)
			mousePressed = true;
	}

	if (usePressed)
	{
		hoverActive = false;
		pressedActive = true;
		reallyOverBlend = true;
		repaint(true);
	
		if ((transparencyMode == 1 && labelType != 1) || box != NULL)
			updateRegion(2);
	}
	if (this->getBox() == 0)
		ReorderZOrder();
}

void Label::onMButtonUp(int x, int y)
{
	if(moveable && moveButton == 3)
	{
		if(mousePressed && !movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			
			if (!checkRegion(x, y, labelMiddleClickRegions))
			{
				POINT pt;
				pt.x = x;
				pt.y = y;

				RECT rc;
				GetClientRect(hWnd, &rc);

				if(PtInRect(&rc, pt))
				{
					if(middleClickCommand.length() > 0)
						LSExecute(hWnd, middleClickCommand.c_str(), SW_SHOWNORMAL);
				}
			}
			
			mousePressed = false;
			moveButtonPressed = 0;
		}
		else if (mousePressed && movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

			mousePressed = false;
			moveButtonPressed = 0;
		}
	}
	else
	{
		//To be on the save side
		ReleaseCapture();
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

		if(mousePressed && !checkRegion(x, y, labelMiddleClickRegions))
		{
			POINT pt;
			pt.x = x;
			pt.y = y;

			RECT rc;
			GetClientRect(hWnd, &rc);

			if(PtInRect(&rc, pt))
			{
				if(middleClickCommand.length() > 0)
					LSExecute(hWnd, middleClickCommand.c_str(), SW_SHOWNORMAL);
			}
		}
		mousePressed = false;
		moveButtonPressed = 0;
	}

	if (usePressed)
	{
		hoverActive = true;
		pressedActive = false;
		reallyOverBlend = true;
		repaint(true);

		if ((transparencyMode == 1 && labelType != 1) || box != NULL)
			updateRegion(1);
	}

	//Animation RESTART
	if (useHover)
	{
		//Restart Hover Anim
		if (hoverAnim)
		{
			frameCounter = 1;
			loopCounter = 0;
			SetTimer(hWnd, TIMER_FRAMEANIMATION, hoverimageFrameDelay, NULL);
		}
	}
	//Restart Normal Anim
	else if (normalAnim)
	{
		frameCounter = 1;
		loopCounter = 0;
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
	}

	if (this->getBox() == 0)
		ReorderZOrder();
}

void Label::onRButtonDblClk(int x, int y)
{
	if(rightDoubleClickCommand.length() > 0)
		LSExecute(hWnd, rightDoubleClickCommand.c_str(), SW_SHOWNORMAL);
	if (this->getBox() == 0)
		ReorderZOrder();
}

void Label::onRButtonDown(int x, int y)
{
	//Stop Animation Timer (Normal & Hover)
	KillTimer(hWnd, TIMER_FRAMEANIMATION);

	if(moveable && moveButton == 2)
	{
		if(!mousePressed && !movemodifierkeyPressed)
			mousePressed = true;
		else if (!mousePressed && movemodifierkeyPressed)
		{
			if (box)
				return;
			mousePressed = true;
			moveButtonPressed = 2;
			GetCursorPos(&savedpt);
			ScreenToClient(hWnd, &savedpt);
			SetCapture(hWnd);
		}
	}
	else
	{
		if(!mousePressed)
			mousePressed = true;
	}

	if (usePressed)
	{
		hoverActive = false;
		pressedActive = true;
		reallyOverBlend = true;
		repaint(true);
	
		if ((transparencyMode == 1 && labelType != 1) || box != NULL)
			updateRegion(2);
	}
	if (this->getBox() == 0)
		ReorderZOrder();
}

void Label::onRButtonUp(int x, int y)
{
	if(moveable && moveButton == 2)
	{
		if(mousePressed && !movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			
			if (!checkRegion(x, y, labelRightClickRegions))
			{
				POINT pt;
				pt.x = x;
				pt.y = y;

				RECT rc;
				GetClientRect(hWnd, &rc);

				if(PtInRect(&rc, pt))
				{
					if(rightClickCommand.length() > 0)
						LSExecute(hWnd, rightClickCommand.c_str(), SW_SHOWNORMAL);
				}
			}
			
			mousePressed = false;
			moveButtonPressed = 0;
		}
		else if (mousePressed && movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

			mousePressed = false;
			moveButtonPressed = 0;
		}
	}
	else 
	{
		//To be on the save side
		ReleaseCapture();
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

		if(mousePressed && !checkRegion(x, y, labelRightClickRegions))
		{
			POINT pt;
			pt.x = x;
			pt.y = y;

			RECT rc;
			GetClientRect(hWnd, &rc);

			if(PtInRect(&rc, pt))
			{
				if(rightClickCommand.length() > 0 && rightClickCommand != ".contextmenu")
					LSExecute(hWnd, rightClickCommand.c_str(), SW_SHOWNORMAL);
				else
					ContextMenu(iconCommand.c_str());
			}
		}
		mousePressed = false;
		moveButtonPressed = 0;
	}

	if (usePressed)
	{
		hoverActive = true;
		pressedActive = false;
		reallyOverBlend = true;
		repaint(true);

		if ((transparencyMode == 1 && labelType != 1) || box != NULL)
			updateRegion(1);
	}

	//Animation RESTART
	if (useHover)
	{
		//Restart Hover Anim
		if (hoverAnim)
		{
			frameCounter = 1;
			loopCounter = 0;
			SetTimer(hWnd, TIMER_FRAMEANIMATION, hoverimageFrameDelay, NULL);
		}
	}
	//Restart Normal Anim
	else if (normalAnim)
	{
		frameCounter = 1;
		loopCounter = 0;
		SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
	}

	if (this->getBox() == 0)
		ReorderZOrder();
}

void Label::onWheelDown(int x, int y)
{
	if(wheelDownCommand.length() > 0)
		LSExecute(hWnd, wheelDownCommand.c_str(), SW_SHOWNORMAL);
	if (this->getBox() == 0)
		ReorderZOrder();
}

void Label::onWheelUp(int x, int y)
{
	if(wheelUpCommand.length() > 0)
		LSExecute(hWnd, wheelUpCommand.c_str(), SW_SHOWNORMAL);
	if (this->getBox() == 0)
		ReorderZOrder();
}

void Label::onMouseEnter()
{
	if (useHover)
	{
		//Kill AnimTimer from Normal Animation
		if (normalAnim)
			KillTimer(hWnd, TIMER_FRAMEANIMATION);

		//If HoverAnim is set (hoverframecount != 0)
		if (hoverAnim)
		{
			hoverActive = true;
			pressedActive = false;
			frameCounter = 1;
			loopCounter = 0;
			//Start AnimTimer from Hover Animation
			SetTimer(hWnd, TIMER_FRAMEANIMATION, hoverimageFrameDelay, NULL);
		}
		//If HoverAnim is not set (hoverframecount == 0)
		else
		{
			frameCounter = 0;
			hoverActive = true;
			pressedActive = false;
			reallyOverBlend = true;
			repaint(true);

			if ((transparencyMode == 1 && labelType != 1) || box != NULL)
				updateRegion(1);
		}
	}	
	
	if(enterCommand.length() > 0)
		LSExecute(hWnd, enterCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onMouseLeave()
{
	if (useHover)
	{
		//If HoverAnim was active (hoverframecount != 0)
		if (hoverAnim)
		{
			hoverActive = false;
			pressedActive = false;
			frameCounter = 0;
			//Kill AnimTimer from Hover Animation
			KillTimer(hWnd, TIMER_FRAMEANIMATION);

			//If NormalAnim is set (framecount != 0)
			if (normalAnim)
			{
				frameCounter = 1;
				loopCounter = 0;
				SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
			}
			//If NormalAnim is not set (framecount == 0)
			else
			{
				reallyOverBlend = true;
				repaint(true);
				if ((transparencyMode == 1 && labelType != 1) || box != NULL)
					updateRegion(0);
			}
		}
		else
		{
			hoverActive = false;
			pressedActive = false;
			//If NormalAnim is set (framecount != 0)
			if (normalAnim)
			{
				frameCounter = 1;
				SetTimer(hWnd, TIMER_FRAMEANIMATION, imageFrameDelay, NULL);
			}
			//If NormalAnim is not set (framecount == 0)
			else
			{
				reallyOverBlend = true;
				repaint(true);
				if ((transparencyMode == 1 && labelType != 1) || box != NULL)
					updateRegion(0);
			}
		}
	}

	if(leaveCommand.length() > 0)
		LSExecute(hWnd, leaveCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onMouseMove(int x, int y)
{
	if(moveable)
	{
		if (mousePressed && movemodifierkeyPressed && moveButtonPressed == moveButton)
			SetTimer(hWnd, TIMER_MOUSETRACK_MOVE, 2, 0);
		else
		{
			if (autoWidthMode != 0 || autoHeightMode != 0)
			{
				startCenterX = actualx+(actualwidth/2);
				startCenterY = actualy+(actualheight/2);
			}

			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			KillTimer(hWnd, TIMER_MOUSETRACK);

			if(!mouseInside)
			{
				if(checkenterleaveRegion(x, y))
				{
					mouseInside = true;
					onMouseEnter();
				}
			}

			SetTimer(hWnd, TIMER_MOUSETRACK, 100, 0);
		}
	}
	else if (!moveable)
	{
		if(!mouseInside)
		{
			if(checkenterleaveRegion(x, y))
			{
				mouseInside = true;
				onMouseEnter();
			}
		}

		SetTimer(hWnd, TIMER_MOUSETRACK, 100, 0);
	}
}

void Label::onPaint(HDC hDC)
{
	bool useFrames = false;
	RECT r;
	GetWindowRect(hWnd, &r);

	int width = r.right - r.left;
	int height = r.bottom - r.top;

	// keep a cached rendition of the background
	if(!backgroundBitmap)
	{
		if(!backgroundDC)
			backgroundDC = CreateCompatibleDC(hDC);

		backgroundBitmap = CreateCompatibleBitmap(hDC, width, height);
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);

		//True Transparency
		if (transparencyMode == 1)
		{
			HBRUSH hbrush;
			RECT r;
			r.top = 0;
			r.left = 0;
			r.right = width;
			r.bottom = height;
			hbrush = CreateSolidBrush((RGB(255, 0, 255)));
			FillRect(backgroundDC, &r, hbrush);
			DeleteObject(hbrush);

		}
		//PrePaint Background (Fake Transparency)
		else if(transparencyMode == 2)
		{
			if(box)
			{
				// save the previous DC contents as the background
				BitBlt(backgroundDC, 0, 0, width, height, hDC, 0, 0, SRCCOPY);
			}
			else
			{
				// paint desktop on display DC and then into background buffer
				PaintDesktopEx(backgroundDC, 0, 0, width, height, r.left, r.top, FALSE);
			}
		}
		//Default Background
		else if (transparencyMode == 3)
		{
			RECT r;

			r.left = 0;
			r.top = 0;
			r.right = width;
			r.bottom = height;

			DrawEdge(backgroundDC,
				&r,
				EDGE_RAISED,
				BF_RECT | BF_MIDDLE);
		}
		
		//Normal Background Painting if no Animation
		if ( (!normalAnim && !hoverAnim) || frameCounter == 0 || (usePressed && pressedActive))
		{
			if (hoverActive && useHover)
				background->apply(backgroundDC, 0, 0, width, height, transparencyMode, 1);
			else if (pressedActive && usePressed)
				background->apply(backgroundDC, 0, 0, width, height, transparencyMode, 2);
			else
				background->apply(backgroundDC, 0, 0, width, height, transparencyMode, 0);
		}
		//Special Background Painting if Animation (normal or hover)
		else
		{
			useFrames = true;
			if (hoverActive && useHover)
				background->applyAnim(backgroundDC, 0, 0, width, height, transparencyMode, 1, frameCounter);
			else
				background->applyAnim(backgroundDC, 0, 0, width, height, transparencyMode, 0, frameCounter);
		}
	}

	// double buffer for flicker-free paint
	if(!bufferBitmap)
	{
		if(!bufferDC)
			bufferDC = CreateCompatibleDC(hDC);

		bufferBitmap = CreateCompatibleBitmap(hDC, width, height);
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
	}

	// blt background into double buffer
	BitBlt(bufferDC, 0, 0, width, height, backgroundDC, 0, 0, SRCCOPY);

	//--------------------------------------------------------------------------------
	// start rendering text
	//--------------------------------------------------------------------------------
	//Create Region in which text drawing is allowed
	HRGN drawArea = CreateRectRgn( 0, 0, actualwidth, actualheight );
	HRGN allowedArea = CreateRectRgn( leftBorder, topBorder, width - rightBorder, height - bottomBorder );
	SelectClipRgn(bufferDC, allowedArea);
	DeleteObject(allowedArea);
	
	long textWidth;
	long textHeight;

	font->measure(bufferDC, longestTextLine, 0, &textWidth, &textHeight);

	if (htmltext && pMeasureHtmlParsedText != NULL)
	{
		RECT tmp;
		tmp.left = 0;
		tmp.right = 0;
		tmp.top = 0;
		tmp.bottom = 0;

		//POINT structure contains maximal width and height of HtmlText
		POINT sizeHtml = pMeasureHtmlParsedText(bufferDC, text.c_str(), font->GetLFont(), font->GetColor(), tmp, align, vertAlign, lineBreak);

		maxHtmlTextWidth = sizeHtml.x;
		maxHtmlTextHeight = sizeHtml.y;
	}

	int placeHolderWidth;
	int placeHolderHeight;

	if (!htmltext)
	{
		placeHolderWidth = textWidth;
		placeHolderHeight = newlineCounter*textHeight;
	}
	else if (htmltext)
	{
		placeHolderWidth = maxHtmlTextWidth;
		placeHolderHeight = maxHtmlTextHeight;
	}

	//For AUTOWIDTH/HEIGHT MODE
	int newx;
	int newy;
	int newwidth;
	int newheight;

	if ( (autoWidthMode != 0 || autoHeightMode != 0) && textChange )
	{ 
		int deltax;
		int deltay;

		if (autoWidthMode != 0)
			deltax = placeHolderWidth - (width - leftBorder - rightBorder);
		else
			deltax = 0;

		if (autoHeightMode != 0)
			deltay = placeHolderHeight - (height - topBorder - bottomBorder);
		else
			deltay = 0;

		newx = r.left;
		newy = r.top;
		newwidth = width + deltax;
		newheight = height + deltay;

		//Check MIN/MAX
		if (newwidth < autoMinWidth || newwidth > autoMaxWidth)
		{
			if (newwidth < autoMinWidth)
			{
				deltax = deltax + (autoMinWidth-newwidth);
				newwidth = autoMinWidth;
			}
			if (newwidth > autoMaxWidth)
			{
				deltax = deltax - (newwidth-autoMaxWidth);
				newwidth = autoMaxWidth;
			}
		}
		if (newheight < autoMinHeight || newheight > autoMaxHeight)
		{
			if (newheight < autoMinHeight)
			{
				deltay = deltay + (autoMinHeight-newheight);
				newheight = autoMinHeight;
			}
			if (newheight > autoMaxHeight)
			{
				deltay = deltay - (newheight-autoMaxHeight);
				newheight = autoMaxHeight;
			}
		}

		if ((autoWidthMode == 0 || autoWidthMode == 1) && (autoHeightMode == 0 || autoHeightMode == 1))
		{
			newx = r.left;
			newy = r.top;
		}
		else if ((autoWidthMode == 0 || autoWidthMode == 1) && autoHeightMode == 2)
		{
			newx = r.left;
			newy = r.top-deltay;
		}
		else if ((autoWidthMode == 0 || autoWidthMode == 1) && autoHeightMode == 3)
		{
			newx = r.left;
			newy = startCenterY-(newheight/2);
		}
		else if (autoWidthMode == 2 && (autoHeightMode == 0 || autoHeightMode == 1))
		{
			newx = r.left-deltax;
			newy = r.top;
		}
		else if (autoWidthMode == 2 && autoHeightMode == 2)
		{
			newx = r.left-deltax;
			newy = r.top-deltay;
		}
		else if (autoWidthMode == 2 && autoHeightMode == 3)
		{
			newx = r.left-deltax;
			newy = startCenterY-(newheight/2);
		}
		else if (autoWidthMode == 3 && (autoHeightMode == 0 || autoHeightMode == 1))
		{
			newx = startCenterX-(newwidth/2);
			newy = r.top;
		}
		else if (autoWidthMode == 3 && autoHeightMode == 2)
		{
			newx = startCenterX-(newwidth/2);
			newy = r.top-deltay;
		}
		else if (autoWidthMode == 3 && autoHeightMode == 3)
		{
			newx = startCenterX-(newwidth/2);
			newy = startCenterY-(newheight/2);
		}
		
		if (!htmltext)
		{
			font->apply(bufferDC,
					leftBorder,
					topBorder,
					width - leftBorder - rightBorder,
					height - topBorder - bottomBorder,
					text,
					align | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS | (lineBreak ? DT_WORDBREAK : 0),
					vertAlign);
		}
		else if (htmltext)
		{
			RECT tmp;
				
			tmp.left = leftBorder;
			tmp.right = width - rightBorder;
			tmp.top = topBorder;
			tmp.bottom = height - bottomBorder;
		
			pDrawHtmlParsedText(bufferDC, text.c_str(), font->GetLFont(), font->GetColor(), tmp, align, vertAlign, lineBreak);
		}
	}
	else if ( ((scroll == 1 || scroll == 3) && placeHolderWidth > width - leftBorder - rightBorder) || ((scroll == 2 || scroll == 4) && placeHolderHeight > height - topBorder - bottomBorder) )
	{			
		if (scroll == 1 || scroll == 3)
		{
			if(scrollPosition <= 0)
			{
				scrollPosition = placeHolderWidth + scrollPadLength;
					
				if (scrollLimit)
				{
					scrollLimit--;
					if (scrollLimit == 0)
						setScrolling(0);
				}
			}

			if(scrollPosition > placeHolderWidth + scrollPadLength )
				scrollPosition = 0;
		}
		else if (scroll == 2 || scroll == 4)
		{
			if(scrollPosition <= 0)
			{
				scrollPosition = placeHolderHeight + scrollPadLength;
					
				if (scrollLimit)
				{
					scrollLimit--;
					if (scrollLimit == 0)
						setScrolling(0);
				}
			}

			if(scrollPosition > placeHolderHeight + scrollPadLength )
				scrollPosition = 0;
		}
		
		if (!htmltext)
		{
			if (scroll == 1 || scroll == 3)
			{
				font->apply(bufferDC,
						leftBorder,
						topBorder,
						scrollPosition - scrollPadLength,
						height - topBorder - bottomBorder,
						text,
						DT_RIGHT | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS ,
						vertAlign);

				font->apply(bufferDC,
						scrollPosition + leftBorder,
						topBorder,
						placeHolderWidth,
						height - topBorder - bottomBorder,
						text,
						DT_LEFT | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS ,
						vertAlign);
			}
			else if (scroll == 2 || scroll == 4)
			{
				font->apply(bufferDC,
					leftBorder,
					topBorder,
					width - leftBorder - rightBorder,
					scrollPosition - scrollPadLength,
					text,
					align | DT_NOPREFIX | DT_EXPANDTABS ,
					2);

				font->apply(bufferDC,
					leftBorder,
					scrollPosition + topBorder,
					width - leftBorder - rightBorder,
					placeHolderHeight,
					text,
					align | DT_NOPREFIX | DT_EXPANDTABS ,
					0);
			}
		}
		else if (htmltext)
		{
			if (pDrawHtmlParsedText != NULL)
			{	
				if (scroll == 1 || scroll == 3)
				{
					RECT tmp;
						
					tmp.left = leftBorder;
					tmp.right = leftBorder + scrollPosition - scrollPadLength;
					tmp.top = topBorder;
					tmp.bottom = height - bottomBorder;
				
					pDrawHtmlParsedText(bufferDC, text.c_str(), font->GetLFont(), font->GetColor(), tmp, DT_RIGHT, vertAlign, false);
						
					tmp.left = leftBorder + scrollPosition;
					tmp.right = leftBorder + placeHolderWidth;
					tmp.top = topBorder;
					tmp.bottom = height - bottomBorder;
				
					pDrawHtmlParsedText(bufferDC, text.c_str(), font->GetLFont(), font->GetColor(), tmp, DT_LEFT, vertAlign, false);
				}
				else if (scroll == 2 || scroll == 4)
				{
					RECT tmp;
						
					tmp.left = leftBorder;
					tmp.right = width - rightBorder;
					tmp.top = scrollPosition;
					tmp.bottom = scrollPosition - scrollPadLength;
				
					pDrawHtmlParsedText(bufferDC, text.c_str(), font->GetLFont(), font->GetColor(), tmp, align, 2, false);
						
					tmp.left = leftBorder;
					tmp.right = width - rightBorder;
					tmp.top = scrollPosition - scrollPadLength - placeHolderHeight;
					tmp.bottom = placeHolderHeight;
				
					pDrawHtmlParsedText(bufferDC, text.c_str(), font->GetLFont(), font->GetColor(), tmp, align, 0, false);
				}
			}
		}
	}
	else
	{
		if (!htmltext)
		{
			if (labelType == 1 && !mousePressed)
			{
				RECT complete;
				complete.left = 0;
				complete.right = width;
				complete.top = 0;
				complete.bottom = height;

				//1. Make all MagicPink
				HBRUSH hbrush;
				hbrush = CreateSolidBrush((RGB(255, 0, 255)));
				FillRect(bufferDC, &complete, hbrush);

				//2. Draw text on Pink
				font->apply(bufferDC,
					leftBorder,
					topBorder,
					width - leftBorder - rightBorder,
					height - topBorder - bottomBorder,
					text,
					align | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS  | (lineBreak ? DT_WORDBREAK : 0),
					vertAlign);

				//3. Create region around text (from remaining Pink)
				HDC tmpDC = CreateCompatibleDC(bufferDC);
				HBITMAP tmpBmp = CreateBitmap(width, height, 1, 32, NULL);
				HGDIOBJ tmpObj = SelectObject(tmpDC, tmpBmp);
				BitBlt(tmpDC, 0, 0, width, height, bufferDC, 0, 0, SRCCOPY);
				SelectObject(tmpDC, tmpObj);
				HRGN region = BitmapToRegion(tmpBmp, RGB(255, 0, 255), 0, 0, 0);
		
				HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
				HRGN tmpRgn = CreateRectRgn(0, 0, width, height);
				CombineRgn(windowRgn, region, tmpRgn, RGN_XOR);

				//4. Copy Bg in
				PaintDesktopEx(bufferDC, 0, 0, width, height, r.left, r.top, FALSE);

				//5. Fill region around text again with MagicPink
				hbrush = CreateSolidBrush((RGB(255, 0, 255)));
				FillRgn(bufferDC, windowRgn, hbrush);

				//6. Draw again text on BG this Time
				font->apply(bufferDC,
					leftBorder,
					topBorder,
					width - leftBorder - rightBorder,
					height - topBorder - bottomBorder,
					text,
					align | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS  | (lineBreak ? DT_WORDBREAK : 0),
					vertAlign);

				//7. Copy in buffer without MagicPink
				int iy = 0;
				int ix = 0;
				COLORREF cl = 0;
				BYTE r = 0;
				BYTE g = 0;
				BYTE b = 0;
				COLORREF cl1 = 0;
				BYTE r1 = 0;
				BYTE g1 = 0;
				BYTE b1 = 0;
				for(iy = 0; iy < height; iy++)
				{
					for(ix = 0; ix < width; ix++)
					{
						cl = GetPixel(bufferDC, ix, iy);
						r = GetRValue(cl);
						g = GetGValue(cl);
						b = GetBValue(cl);
						cl1 = GetPixel(backgroundDC, ix, iy);
						r1 = GetRValue(cl1);
						g1 = GetGValue(cl1);
						b1 = GetBValue(cl1);

						if( !( r == 255 && g == 0 && b == 255 ) )
							SetPixel(bufferDC, ix, iy, RGB(r, g, b));
						else
							SetPixel(bufferDC, ix, iy, RGB(r1, g1, b1));
					}
				}
			
				//8. Cleanup
				DeleteObject(hbrush);
				DeleteObject(tmpBmp);
				DeleteObject(tmpObj);
				DeleteDC(tmpDC);		
			}
			else if (labelType == 1 && mousePressed)
			{
			}
			else
			{
				font->apply(bufferDC,
					leftBorder,
					topBorder,
					width - leftBorder - rightBorder,
					height - topBorder - bottomBorder,
					text,
					align | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS  | (lineBreak ? DT_WORDBREAK : 0),
					vertAlign);
			}
		}
		else if (pDrawHtmlParsedText != NULL)
		{	
			RECT tmp;
				
			tmp.left = leftBorder;
			tmp.right = width - rightBorder;
			tmp.top = topBorder;
			tmp.bottom = height - bottomBorder;
		
			pDrawHtmlParsedText(bufferDC, text.c_str(), font->GetLFont(), font->GetColor(), tmp, align, vertAlign, lineBreak);
		}
	}

	//Reset Region in which text drawing is allowed
	SelectClipRgn(bufferDC, drawArea);
	DeleteObject(drawArea);
	//--------------------------------------------------------------------------------
	// stop rendering text
	//--------------------------------------------------------------------------------

	//Normal Image Switch
	if (overblendStyle == 0 || useFrames || !reallyOverBlend)
	{
		// blt the double buffer to the display
		BitBlt(hDC, 0, 0, width, height, bufferDC, 0, 0, SRCCOPY);
	}
	//OverblendStyle Image Switch
	else if (overblendStyle == -1)
		MagicShow( bufferDC, 0, 0, hDC, 0, 0, width, height, 5, 2, rand()%20 );
	else
		MagicShow( bufferDC, 0, 0, hDC, 0, 0, width, height, 5, 2, overblendStyle );	

	//Reposition to NEW Pos/Size ( ONLY IN AUTOWIDTH-, AUTOHEIGHT-MODE )
	if ( (autoWidthMode != 0 || autoHeightMode != 0) && textChange )
	{
		reposition(newx, newy , newwidth, newheight);
		textChange = false;
	}

	//Set to idle ;) Only OverBlend on MouseOver or Pressed Events and back to normal
	reallyOverBlend = false;
}

void Label::onSize(int width, int height)
{
	actualheight = height;
	actualwidth = width;

	if(backgroundDC && backgroundBitmap)
	{
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
		DeleteObject(backgroundBitmap);
		backgroundBitmap = 0;
	}

	if(bufferDC && bufferBitmap)
	{
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
		DeleteObject(bufferBitmap);
		bufferBitmap = 0;
	}

	InvalidateRect(hWnd, 0, FALSE);
}

void Label::onTimer(int timerID)
{
	switch(timerID)
	{
		case TIMER_MOUSETRACK:

			POINT pt;
			GetCursorPos(&pt);
			ScreenToClient(hWnd, &pt);

			if(!checkenterleaveRegion(pt.x, pt.y))
			{
				if (mouseInside)
				{
					onMouseLeave();	
					mouseInside = false;
				}
			}

			RECT rc;
			GetWindowRect(hWnd, &rc);
			GetCursorPos(&pt);

			if(!PtInRect(&rc, pt))
			{
				KillTimer(hWnd, TIMER_MOUSETRACK);
				mouseInside = false;
				mousePressed = false;
			}

		break;

		case TIMER_MOUSETRACK_MOVE:

			POINT newpt;
			GetCursorPos(&newpt);
			
			newpt.x = newpt.x-savedpt.x;
			newpt.y = newpt.y-savedpt.y;
			move(newpt.x, newpt.y, 0, 0);
		
		break;

		case TIMER_UPDATE:

			update();

		break;

		case TIMER_AUTOSIZEUPDATE:

			update();
			KillTimer(hWnd, TIMER_AUTOSIZEUPDATE);

		break;
		
		case TIMER_SCROLL:

			if (!frozen)
			{
				if (scroll == 1 || scroll == 2)
					scrollPosition -= scrollSpeed;
				else if (scroll == 3 || scroll == 4)
					scrollPosition += scrollSpeed;
				repaint();
			}

		break;

		case TIMER_AUTOHIDE:

			hide();

		break;

		case TIMER_ALPHAFADEIN:

			if (UpdateAlpha <= alphaTransparency)
			{
				// Raise the alpha value (towards alphatransparency) and update the window.
				UpdateAlpha += 5;
				UpdateWindowTransparent(hWnd, UpdateAlpha);
			}
			else
			{
				// Reached maximum alpha. Kill the timer
				KillTimer(hWnd, TIMER_ALPHAFADEIN);
				UpdateAlpha = alphaTransparency;
				UpdateWindowTransparent(hWnd, UpdateAlpha);
			}

		break;

		case TIMER_ALPHAFADEOUT:

			if (UpdateAlpha >= 5)
			{
				// Reduce the alpha value (towards transparency) and update the window.
				UpdateAlpha -= 5;
				UpdateWindowTransparent(hWnd, UpdateAlpha);
			}
			else
			{
				// Reached minimum alpha. Kill the timer
				KillTimer(hWnd, TIMER_ALPHAFADEOUT);
				UpdateAlpha = 0;
				UpdateWindowTransparent(hWnd, UpdateAlpha);
				ShowWindow(hWnd, SW_HIDE);
				if (anim)
				{
					RECT r;
					GetWindowRect(hWnd, &r);
					if (pAnimHide != NULL)
						pAnimHide(r, animEffect, animSteps, animAfterSteps, animDelay);
				}
			}

		break;

		case TIMER_FRAMEANIMATION:

			if (hoverActive && useHover)
			{
				if (frameCounter == hoverimageFrameCount)
				{
					frameCounter = 0;
					loopCounter++;
				}
				if (loopCounter == hoverimageLoop)
				{
					frameCounter = -1;
					loopCounter = 0;
					KillTimer(hWnd, TIMER_FRAMEANIMATION);
				}
				
			}
			else
			{
				if (frameCounter == imageFrameCount)
				{
					frameCounter = 0;
					loopCounter++;
				}
				if (loopCounter == imageLoop)
				{
					frameCounter = -1;
					loopCounter = 0;
					KillTimer(hWnd, TIMER_FRAMEANIMATION);
				}
			}
			frameCounter++;
			repaint(true);

		break;
	}
}

void Label::onWindowPosChanged(WINDOWPOS *windowPos)
{
	repaint(true);
}

bool Label::onWindowMessage(UINT message, WPARAM wParam, LPARAM lParam, LRESULT &lResult)
{
	extern HWND messageHandler;
	
	if (labelType == 0 || labelType == 2)
	{
		if (moveKey == 3)
			movemodifierkeyPressed = (0x8000 & GetKeyState(VK_CONTROL)) && (0x8000 & GetKeyState(VK_SHIFT));
		else if (moveKey == 2)
			movemodifierkeyPressed = (0x8000 & GetKeyState(VK_SHIFT));
		else if (moveKey == 1)
			movemodifierkeyPressed = (0x8000 & GetKeyState(VK_CONTROL));
		else 
			movemodifierkeyPressed = (0x8000 & GetKeyState(VK_CONTROL));
	}
	else if (labelType == 1)
		movemodifierkeyPressed = true;

	if (moveable && !movemodifierkeyPressed)
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

	switch(message)
	{
		case LM_SETLABELTEXT:
		{
			setText(string((const char *) lParam));
			return true;
		}

		case WM_COPYDATA:
		{
			COPYDATASTRUCT *cds = (COPYDATASTRUCT *) lParam;
			
			if(cds->dwData == LM_SETLABELTEXT)
				setText(string((const char *) cds->lpData));

			return false;
		}

		case WM_CLOSE:
		{
			lResult = 0;
			return true;
		}

		case WM_DESTROY:
		{
			if(box)		// FIXME: this is the old workaround
			{
				box = NULL;
				hide();
			}
				
			hWnd = NULL;	// FIXME: dirty hack
			
			return false;
		}

		case WM_DROPFILES:
		{
			if(dropCommand.empty())	// we shouldn't get here... but somehow we did :p
				break;

			char *szSourceFiles = NULL;
			char buffer[MAX_PATH], szTarget[MAX_PATH];
			int numFiles;
			UINT len,scursor = 0;
			int intFileAction;

			char action[32];
			char *buffers[] = {action};

			LCTokenize(dropCommand.c_str(), buffers, 1, szTarget);

			if (stricmp(action, "move") == 0)
				intFileAction = 1;
			else if (stricmp(action, "copy") == 0)
				intFileAction = 2;
			else if (stricmp(action, "delete") == 0)
				intFileAction = 0;

			string targetPath = szTarget;
			targetPath = targetPath.substr(1, targetPath.length() - 2);

			numFiles = DragQueryFile((HDROP) wParam, 0xFFFFFFFF, NULL, NULL);

			szSourceFiles = new char[MAX_PATH*numFiles+1];
			scursor = 0;

			for (int i=0;i<numFiles;i++)
			{
				len = DragQueryFile((HDROP) wParam, i, buffer, MAX_PATH);
				
				strcpy(szSourceFiles+scursor,buffer);
				scursor += len + 1;
			}
				
			DragFinish((HDROP) wParam);

			string check = (targetPath + "*");
			
			//Test Path for Existence
			WIN32_FIND_DATA FindData;
			HANDLE hFindHandle = FindFirstFile(check.c_str(), &FindData);

			if(hFindHandle != INVALID_HANDLE_VALUE)
			{
				szSourceFiles[scursor] = 0;
				strcpy(buffer, targetPath.c_str());
				buffer[strlen(buffer)+1] = 0;
				
				SHFILEOPSTRUCT shfop;
				shfop.hwnd = NULL;
				if (intFileAction == 1)
					shfop.wFunc = FO_MOVE;
				else if (intFileAction == 2)
					shfop.wFunc = FO_COPY;
				else if (intFileAction == 0)
					shfop.wFunc = FO_DELETE;
				shfop.pFrom = szSourceFiles;
				shfop.pTo = buffer;
				shfop.fFlags = FOF_NOCONFIRMMKDIR;
				SHFileOperation(&shfop);
			}
			
			delete[] szSourceFiles;
			
			return 0;
		}
		
		case WM_LBUTTONDBLCLK:
		{
			if(leftDoubleClickCommand.empty())
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onLButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_LBUTTONDOWN:
		{
			if(leftDoubleClickCommand.empty() && leftClickCommand.empty() && labelLeftClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onLButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_LBUTTONUP:
		{
			if(leftDoubleClickCommand.empty() && leftClickCommand.empty() && labelLeftClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onLButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONDBLCLK:
		{
			if(middleDoubleClickCommand.empty())
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onMButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONDOWN:
		{
			if(middleDoubleClickCommand.empty() && middleClickCommand.empty() && labelMiddleClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onMButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONUP:
		{
			if(middleDoubleClickCommand.empty() && middleClickCommand.empty() && labelMiddleClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onMButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONDBLCLK:
		{
			if(rightDoubleClickCommand.empty())
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onRButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONDOWN:
		{
			if(rightDoubleClickCommand.empty() && rightClickCommand.empty() && labelRightClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onRButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONUP:
		{
			if(rightDoubleClickCommand.empty() && rightClickCommand.empty() && labelRightClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onRButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MOUSEWHEEL:
		{
			if ((short)(HIWORD(wParam)) < 0)
			{
				if(wheelDownCommand.empty())
				{
					relayMouseMessageToBox(message, wParam, lParam);
					return true;
				}

				onWheelDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
				return true;
			}
			else
			{
				if(wheelUpCommand.empty())
				{
					relayMouseMessageToBox(message, wParam, lParam);
					return true;
				}
				
				onWheelUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
				return true;
			}
		}

		case WM_MOUSEMOVE:
		{
			onMouseMove((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_PAINT:
		{
			//Only Start New PAINT if old is finished ;)
			if (!paintInProgress)
			{
				paintInProgress = true;

				PAINTSTRUCT ps;
				HDC hDC;

				if(!wParam)
					hDC = BeginPaint(hWnd, &ps);
				else
					hDC = (HDC) wParam;

				onPaint(hDC);

				if(!wParam)
					EndPaint(hWnd, &ps);

				paintInProgress = false;
			}

			return true;
		}

		case WM_SIZE:
		{
			onSize((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_TIMER:
		{
			onTimer((int) wParam);
			return true;
		}

		case WM_WINDOWPOSCHANGED:
		{
			onWindowPosChanged((WINDOWPOS *) lParam);
			return false;
		}
	}

	return false;
}

LRESULT Label::windowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	Label *label = NULL;

	if(message == WM_NCCREATE)
	{
		label = (Label *) ((CREATESTRUCT *) lParam)->lpCreateParams;
		label->hWnd = hWnd;
		SetWindowLong(hWnd, 0, (LONG) label);
	}
	else
		label = (Label *) GetWindowLong(hWnd, 0);

	if(label)
	{
		LRESULT lResult = 0;

		if(label->onWindowMessage(message, wParam, lParam, lResult))
			return lResult;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

//Tooltips
void Label::addHint(HWND hWnd, LPSTR caption)
{
	TOOLINFO ti;
	RECT clientRect;

	if (!TooltipHints)
		return ;
	GetClientRect(hWnd, &clientRect);
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = clientRect;
	ti.hinst = hInstance;
	ti.lpszText = caption;
	ti.lParam = 0;
	SendMessage(TooltipHints, TTM_ADDTOOL, 0, LPARAM(&ti));
}

void Label::updateHint(HWND hWnd, LPSTR caption)
{
	TOOLINFO ti;
	RECT clientRect;

	if (!TooltipHints)
		return ;
	GetClientRect(hWnd, &clientRect);
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = clientRect;
	ti.hinst = hInstance;
	ti.lpszText = caption;
	ti.lParam = 0;
	SendMessage(TooltipHints, TTM_UPDATETIPTEXT, 0, LPARAM(&ti));
}

void Label::removeHint(HWND hWnd)
{
	TOOLINFO ti;
	RECT emptyRect = {0, 0, 0, 0};

	if (!TooltipHints)
		return ;
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = emptyRect;
	ti.hinst = hInstance;
	ti.lpszText = NULL;
	ti.lParam = 0;
	SendMessage(TooltipHints, TTM_DELTOOL, 0, LPARAM(&ti));
}

BOOL Label::UpdateWindowTransparent(HWND hWnd, unsigned char factor)
{
   /* First, see if we can get the API call we need. If we've tried
    * once, we don't need to try again. */
   if (!initialized)
   {
		HMODULE hDLL = LoadLibrary ("user32");

		pSetLayeredWindowAttributes = 
		  (PSLWA) GetProcAddress(hDLL, "SetLayeredWindowAttributes");

		initialized = TRUE;
   }

   if (pSetLayeredWindowAttributes == NULL)
      return FALSE;
  
   SetLastError(0);

   if (GetLastError())
      return FALSE;

   /* Now, we need to set the 'layered window attributes'. This
    * is where the alpha values get set. */
   	if (transparencyMode == 1)
	{
		return pSetLayeredWindowAttributes (hWnd, 
											RGB(255, 0, 255), 
											factor,
											LWA_COLORKEY | LWA_ALPHA);
	}
	else
	{
		return pSetLayeredWindowAttributes (hWnd, 
											0, 
											factor,
											LWA_ALPHA);
	}
}

void Label::ReorderZOrder()
{
	LabelListIterator iter;
	for( iter = labelList.begin(); iter != labelList.end(); iter++)
	{
		if((*iter)->name.c_str() == this->name.c_str())
		{
			iter++;
			if (iter != NULL)
			{
				SetWindowPos(this->hWnd, (*iter)->hWnd,
					0, 0, 0, 0,
					SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
			}
			break;
		}
	}
	for( iter = shortcutlabelList.begin(); iter != shortcutlabelList.end(); iter++)
	{
		if((*iter)->name.c_str() == this->name.c_str())
		{
			iter++;
			if (iter != NULL)
			{
				SetWindowPos(this->hWnd, (*iter)->hWnd,
					0, 0, 0, 0,
					SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
			}
			break;
		}
	}
}

void Label::updateRegion(int drawImage)
{
	if ((transparencyMode == 1 && !IsOS(OS_2KXP)) || box != NULL)
	{
		HDC tmpDC = CreateCompatibleDC(bufferDC);
		HBITMAP tmpBmp = CreateBitmap(actualwidth, actualheight, 1, 32, NULL);
		HGDIOBJ tmpObj = SelectObject(tmpDC, tmpBmp);

		//Draw Image: 0 normal, 1 hover, 2 pressed
		background->apply(tmpDC, 0, 0, actualwidth, actualheight, transparencyMode, drawImage);

		SelectObject(tmpDC, tmpObj);

		// region handling a la MickeM =)
		HRGN region = BitmapToRegion(tmpBmp, RGB(255, 0, 255), 0, 0, 0);
		HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(windowRgn, region, NULL, RGN_COPY);

		if (!SetWindowRgn(hWnd, windowRgn, true))
		{
			DeleteObject(windowRgn);
		}

		DeleteObject(tmpBmp);
		DeleteObject(tmpObj);
		DeleteDC(tmpDC);		
	}
}

bool Label::InitializeDLL(string pluginName)
{
	//Load Plugin DLL's
	if (stricmp(pluginName.c_str(), "xhtmltext.dll") == 0)
	{
		m_PluginHtmlText = LoadLibrary(pluginName.c_str());
		
		if(m_PluginHtmlText == NULL)
		{
			char tmpSz[4096];
			// Try to load from xLabel.dll's folder
			string currentBuild = V_NAME;
			currentBuild.append("-");
			currentBuild.append(V_VERSION);
			currentBuild.append(".dll");

			GetModuleFileName(GetModuleHandle(currentBuild.c_str()), tmpSz, 4096);
			tmpSz[strlen(tmpSz) - currentBuild.length()] = 0;	// Remove the DLL name
			strcat(tmpSz, pluginName.c_str());

			m_PluginHtmlText = LoadLibrary(tmpSz);

			if(m_PluginHtmlText == NULL)
			{
				pluginName = "Plugin not found!\n\n";
				pluginName.append(tmpSz);
				pluginName.append("\n\nPlease check Path and PluginName!\nIf it still refuses to work, copy xhtmltext.dll into your LitestepDir!");
				MessageBox(NULL, pluginName.c_str(), "xLabel Plugin Informations", MB_SETFOREGROUND);
				return false;
			}
		}

		if (m_PluginHtmlText != NULL)
		{
			pDrawHtmlParsedText = (PDHPT)GetProcAddress(m_PluginHtmlText, "DrawHtmlParsedText");
			pMeasureHtmlParsedText = (PMHPT)GetProcAddress(m_PluginHtmlText, "MeasureHtmlParsedText");
		
			if (pDrawHtmlParsedText == NULL || pMeasureHtmlParsedText == NULL)
			{
				MessageBox(NULL, "Couldn't initialise PluginFunctions!\n\nMaybe you use an older xhtmltext.dll version, than xlabel.dll version!", "xLabel Plugin Informations", MB_SETFOREGROUND);
				return false;
			}
			else
				return true;
		}
	}
	else if (stricmp(pluginName.c_str(), "xanim.dll") == 0)
	{
		m_PluginAnim = LoadLibrary(pluginName.c_str());

		if(m_PluginAnim == NULL)
		{
			char tmpSz[4096];
			// Try to load from xLabel.dll's folder
			string currentBuild = V_NAME;
			currentBuild.append("-");
			currentBuild.append(V_VERSION);
			currentBuild.append(".dll");

			GetModuleFileName(GetModuleHandle(currentBuild.c_str()), tmpSz, 4096);
			tmpSz[strlen(tmpSz) - currentBuild.length()] = 0;	// Remove the DLL name
			strcat(tmpSz, pluginName.c_str());
			m_PluginAnim = LoadLibrary(tmpSz);

			if(m_PluginAnim == NULL)
			{
				pluginName = "Plugin not found!\n\n";
				pluginName.append(tmpSz);
				pluginName.append("\n\nPlease check Path and PluginName!\nIf it still refuses to work, copy xanim.dll into your LitestepDir!");
				MessageBox(NULL, pluginName.c_str(), "xLabel Plugin Informations", MB_SETFOREGROUND);
				return false;
			}
		}

		if (m_PluginAnim != NULL)
		{
			pAnimShow = (PAS)GetProcAddress(m_PluginAnim, "AnimEffectShow");
			pAnimHide = (PAH)GetProcAddress(m_PluginAnim, "AnimEffectHide");
		
			if (pAnimShow == NULL || pAnimHide == NULL)
			{
				MessageBox(NULL, "Couldn't initialise PluginFunctions!\nMaybe you use an older xanim.dll version, than xlabel.dll version!", "xLabel Plugin Informations", MB_SETFOREGROUND);
				return false;
			}
			else
				return true;
		}
	}

	return false;
}