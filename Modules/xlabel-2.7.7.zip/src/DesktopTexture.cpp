#include "common.h"
#include "Label.h"
#include "DesktopTexture.h"

#include <shellapi.h>
#include <shlobj.h>

extern LabelList desktoplabelList;

DesktopTexture::DesktopTexture()
{
	hIcon = 0;

	memoryDC = 0;
	memoryBitmap = 0;
}

DesktopTexture::~DesktopTexture()
{
	if(hIcon)
		DeleteObject(hIcon);

	if(memoryDC)
		DeleteDC(memoryDC);
}

void DesktopTexture::configure(const string &lnkfile, const string &name)
{
	NameValuePair iconTextValues[] = {
		{ "top", 1 },
		{ "bottom", 2 },
		{ "left", 3 },
		{ "right", 4 },
		{ 0, 0 }
	};

	curName = name;

	string result;
	string check;
	
	//Remove '"'
	int start = lnkfile.find("\"");
	start = (start < 0) ? 0 : start + 1;

	int end = lnkfile.rfind("\"");
	end = (end < 0) ? lnkfile.length() - 1 : end - 1;

	if (start < end) 
		check = lnkfile.substr(start, end - start + 1);

	//Make Lower
	int length = check.length();
	int i = 0;
	
	while(i < length)
		result.append(1, tolower(check[i++]));

	if (strstr(result.c_str(), ".lnk") != NULL)
		result = GetShortcutTarget(result);

	SHFILEINFO shFileInfo;
    SHGetFileInfo(result.c_str(), NULL, &shFileInfo, sizeof(shFileInfo), SHGFI_ICON);
	hIcon = shFileInfo.hIcon;

	iconSize = GetRCInt("xlabeldesktop" , "IconSize", 32, 16, 64);
	iconTextPosition = GetRCNamedValue("xlabeldesktop", "TextPosition", iconTextValues, 2);
	iconTextSpacing = GetRCInt("xlabeldesktop" , "TextSpacing", 5);
	
	int color;
	char main[32], light[32], dark[32];
	char *buffers[] = {main, light, dark};

	int numTokens = LCTokenize((GetRCLine("xlabeldesktop", "TextBackground", "ff00ff")).c_str(), buffers, 3, NULL);

	if (numTokens == 3)
	{
		color = strtol(light, NULL, 16);
		iconTextBackgroundLight = RGB(GetBValue(color), GetGValue(color), GetRValue(color));

		color = strtol(dark, NULL, 16);
		iconTextBackgroundDark = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
	}
	else
	{
		iconTextBackgroundLight = RGB(255,0,255);
		iconTextBackgroundDark = RGB(255,0,255);
	}
	if(numTokens >= 1)
	{
		color = strtol(main, NULL, 16);
		iconTextBackground = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
	}
	if (numTokens == 2)
	{
		color = strtol(light, NULL, 16);
		iconTextBackgroundLight = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
		iconTextBackgroundDark = iconTextBackgroundLight;
	}

	_saturation = GetRCInt("xlabeldesktop" , "SaturationIntensity", 255, 0, 255);
	_hueIntensity = GetRCInt("xlabeldesktop" , "HueIntensity", 0, 0, 255);
	_hueColor = GetRCColor("xlabeldesktop", "HueColor", RGB(0, 0, 0));
}

void DesktopTexture::apply(HDC hDC, int x, int y, int width, int height, int transparencyMode, int imageType)
{
	if(hIcon == NULL)
		return;
	
	memoryDC = CreateCompatibleDC(hDC);
	memoryBitmap = CreateCompatibleBitmap(hDC, width, height);
	memoryBitmap = (HBITMAP) SelectObject(memoryDC, memoryBitmap);

	HBRUSH hbrush;
	RECT r, r1;
	r.top = 0;
	r.left = 0;
	r.right = width;
	r.bottom = height;
	hbrush = CreateSolidBrush((RGB(254, 0, 254)));
	FillRect(memoryDC, &r, hbrush);

	int xpos, ypos;
	if (iconTextPosition == 1)
	{
		xpos = (width-iconSize)/2;
		ypos = height-iconSize;
		r.top = 0;
		r.left = 0;
		r.right = width;
		r.bottom = height-iconSize-iconTextSpacing;
	}
	else if (iconTextPosition == 2)
	{
		xpos = (width-iconSize)/2;
		ypos = 0;
		r.top = iconSize+iconTextSpacing;
		r.left = 0;
		r.right = width;
		r.bottom = height;
	}
	else if (iconTextPosition == 3)
	{
		xpos = width-iconSize;
		ypos = (height-iconSize)/2;
		r.top = 0;
		r.left = 0;
		r.right = width-iconSize-iconTextSpacing;
		r.bottom = height;
	}
	else if (iconTextPosition == 4)
	{
		xpos = 0;
		ypos = (height-iconSize)/2;
		r.top = 0;
		r.left = iconSize+iconTextSpacing;
		r.right = width;
		r.bottom = height;
	}

	r1.left = xpos;
	r1.top = ypos;
	r1.right = r1.left+iconSize;
	r1.bottom = r1.top+iconSize;

	hbrush = CreateSolidBrush(RGB(255,0,255));
	FillRect(memoryDC, &r1, hbrush);

	hbrush = CreateSolidBrush(iconTextBackgroundDark);
	FillRect(memoryDC, &r, hbrush);

	r.right = r.right-1;
	r.bottom = r.bottom-1;
	hbrush = CreateSolidBrush(iconTextBackgroundLight);
	FillRect(memoryDC, &r, hbrush);

	r.left = r.left+1;
	r.top = r.top+1;
	hbrush = CreateSolidBrush(iconTextBackground);
	FillRect(memoryDC, &r, hbrush);
	
	DeleteObject(hbrush);

	SetStretchBltMode(memoryDC, STRETCH_DELETESCANS);

	int curx = 0;
	int cury = 0;
	for ( LabelListIterator iter = desktoplabelList.begin(); iter != desktoplabelList.end(); iter++)
	{
		if((*iter)->getName().c_str() == curName.c_str())
		{
			curx = (*iter)->getX();
			cury = (*iter)->getY();
			break;
		}
	}

	PaintDesktopEx(memoryDC, xpos, ypos, iconSize, iconSize, curx+xpos, cury+ypos, false);

	if (hIcon)
	{
		if (_saturation != 255 || _hueIntensity != 0)
		{
			ICONINFO ii;
			GetIconInfo(hIcon, &ii);

			HDC hdcBuffer = CreateCompatibleDC(memoryDC);
			SelectObject(hdcBuffer, ii.hbmColor);

			HDC hdcMask = CreateCompatibleDC(hdcBuffer);
			HBITMAP hbmMask = CreateCompatibleBitmap(hdcBuffer, iconSize, iconSize);
			SelectObject(hdcMask, hbmMask);

			// Mask of the icon
			DrawIconEx(hdcMask, 0, 0, hIcon, iconSize, iconSize, 0, NULL, DI_MASK);

			int iy = 0;
			int ix = 0;
			COLORREF cl = 0;
			BYTE r = 0;
			BYTE g = 0;
			BYTE b = 0;
			for(iy = 0; iy < iconSize; iy++)
			{
				for(ix = 0; ix < iconSize; ix++)
				{
					// Loop through all transparent pixels...
					// If the mask-pixel is white, then break
					if(!GetPixel(hdcMask, ix, iy))
					{
						cl = GetPixel(hdcBuffer, ix, iy);
						r = GetRValue(cl);
						g = GetGValue(cl);
						b = GetBValue(cl);

						// Saturation effect
						if(_saturation != 255)
						{
							BYTE gray = (BYTE)(r * 0.3086 + g * 0.6094 + b * 0.0820);

							r = (BYTE)((r * _saturation + gray * (255 - _saturation) + 255) >> 8);
							g = (BYTE)((g * _saturation + gray * (255 - _saturation) + 255) >> 8);
							b = (BYTE)((b * _saturation + gray * (255 - _saturation) + 255) >> 8);
						}

						// Hue effect
						if(_hueIntensity != 0)
						{
							// The B & R values of the hue is swapped here, can somebody tell me why it only works that way?
							// test normal
							r = (BYTE)((r * (255 - _hueIntensity) + GetRValue(_hueColor) * _hueIntensity + 255) >> 8);
							g = (BYTE)((g * (255 - _hueIntensity) + GetGValue(_hueColor) * _hueIntensity + 255) >> 8);
							b = (BYTE)((b * (255 - _hueIntensity) + GetBValue(_hueColor) * _hueIntensity + 255) >> 8);
						}

						SetPixel(hdcBuffer, ix, iy, RGB(r, g, b));
					}
				}
			}

			StretchBlt( memoryDC, xpos, ypos, iconSize, iconSize, hdcMask, 0, 0, iconSize, iconSize, SRCAND );
			// Combine the foreground with the background
			StretchBlt( memoryDC, xpos, ypos, iconSize, iconSize, hdcBuffer , 0, 0, iconSize, iconSize, SRCPAINT );
			
			DeleteObject(hbmMask);
			DeleteDC(hdcMask);
			DeleteDC(hdcBuffer);
		}
		else
			DrawIconEx(memoryDC, xpos, ypos, hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);
	}

	BitBlt( hDC, x, y, width, height, memoryDC, 0, 0, SRCCOPY );
}

string DesktopTexture::GetShortcutTarget(const string LinkFileName)
{
	HRESULT hres;
	
	string Info;
	char szGotPath [MAX_PATH];

	IShellLink* psl;

	//Create the ShellLink object
	hres = CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER,
				IID_IShellLink, (LPVOID*) &psl);
	
	if (SUCCEEDED(hres))
	{
		IPersistFile* ppf;
		//Bind the ShellLink object to the Persistent File
		hres = psl->QueryInterface( IID_IPersistFile, (LPVOID *) &ppf);
		if (SUCCEEDED(hres))
		{
			WORD wsz[MAX_PATH];
			//Get a UNICODE wide string wsz from the Link path
			MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, LinkFileName.c_str(), -1, wsz, MAX_PATH);
			
			//Read the link into the persistent file
			hres = ppf->Load(wsz, 0);
			
			if (SUCCEEDED(hres))
			{
				//Read the target information from the link object
				//UNC paths are supported (SLGP_UNCPRIORITY)
				psl->GetPath(szGotPath, 1024, NULL, SLGP_UNCPRIORITY);
				Info = szGotPath;
			}
		}
	}
	psl->Release();

	//Return the Target (and the Argument) as a string
	return Info;
}

