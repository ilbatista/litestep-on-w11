#if !defined(__COMMON_H)
#define __COMMON_H

#include <fstream>
#include <string>
#include <list>
#include <vector>
#include <map>

using namespace std;

class Label;

typedef list<string> StringList;
typedef list<string>::iterator StringListIterator;
typedef list<Label *> LabelList;
typedef list<Label *>::iterator LabelListIterator;

typedef unsigned __int64 largeInt;

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <windowsx.h>
#include <winsock.h>
#include <snmp.h>
#include <tchar.h>
#include "lsapi.h"

#include "utility.h"
#include "verInfo.h"
#include "strsafe.h"

#define ALIGN_LEFT 0
#define ALIGN_TOP 0
#define ALIGN_CENTER 1
#define ALIGN_RIGHT 2
#define ALIGN_BOTTOM 2

#define LM_SETLABELTEXT 9600

#ifndef WM_MOUSEWHEEL
	#define WM_MOUSEWHEEL 0x020A
#endif

#endif
