#ifndef __LITESTEP_H
#define __LITESTEP_H

#ifdef __cplusplus
extern "C" {
#endif

#define LM_SHUTDOWN 8889
#define LM_REPAINT 8890
#define LM_BRINGTOFRONT 8891
#define LM_SAVEDATA 8892
#define LM_RESTOREDATA 8893
#define LM_POPUP 9182
#define LM_HIDEPOPUP 9183
#define LM_FIRSTDESKTOPPAINT 9184
#define LM_LSSELECT 9185
#define LM_SETTASKBARONTOP 9186
#define LM_SAVESYSTRAY 9210
#define LM_RESTORESYSTRAY 9211
#define LM_CHECKFORAPPBAR 9212
#define LM_SENDSYSTRAY 9213
#define LM_SYSTRAY 9214 
#define LM_SYSTRAYREADY 9215
#define LM_RECYCLE 9260
#define LM_REGISTERMESSAGE 9263
#define LM_UNREGISTERMESSAGE 9264
#define LM_GETREVID 9265
#define LM_UNLOADMODULE 9266
#define LM_RELOADMODULE 9267
#define LM_SHADETOGGLE 9300
#define LM_REFRESH 9305
#define LM_WINDOWCREATED 9501
#define LM_WINDOWDESTROYED 9502
#define LM_ACTIVATESHELLWINDOW 9503
#define LM_WINDOWACTIVATED 9504
#define LM_GETMINRECT 9505
#define LM_REDRAW 9506
#define LM_TASKMAN 9507
#define LM_LANGUAGE 9508
#define LM_ACCESSIBILITYSTATE 9511
#define LM_APPCOMMAND 9512
#define LOG_ERROR 1
#define LOG_WARNING 2
#define LOG_NOTICE 3
#define LOG_DEBUG 4
#define MAGIC_DWORD 0x49474541
#define MAX_BANGCOMMAND 64
#define MAX_BANGARGS 256
#define MAX_RCCOMMAND 64
#define MAX_RCLINE 4096

typedef void (*PFNBANGCOMMAND)(HWND hwndCaller, LPCSTR pszArgs);
typedef void (*PFNBANGCOMMANDEX)(HWND hwndCaller, LPCSTR pszBangCommand, LPCSTR pszArgs);

BOOL AddBangCommand(LPCSTR pszBangCommand, PFNBANGCOMMAND pfnCallback);
BOOL AddBangCommandEx(LPCSTR pszBangCommand, PFNBANGCOMMANDEX pfnCallback);
HRGN BitmapToRegion(HBITMAP hbmBitmap, COLORREF crTransparent, COLORREF crTolerance, int xOffset, int yOffset);
int CommandTokenize(LPCSTR pszInput, LPSTR *ppszBuffers, UINT cBuffers, LPSTR pszExtraBuffer);
HWND GetLitestepWnd();
void GetLSBitmapSize(HBITMAP hbmBitmap, int *pnWidth, int *pnHeight);
BOOL GetRCBool(LPCSTR pszKey, BOOL fIfFound);
BOOL GetRCBoolDef(LPCSTR pszKey, BOOL fDefault);
COLORREF GetRCColor(LPCSTR pszKey, COLORREF crDefault);
int GetRCCoordinate(LPCSTR pszKey, int nDefault, int nMax);
int GetRCInt(LPCSTR pszKey, int nDefault);
BOOL GetRCLine(LPCSTR pszKey, LPSTR pszBuffer, UINT cbBuffer, LPCSTR pszDefault);
BOOL GetRCString(LPCSTR pszKey, LPSTR pszBuffer, LPCSTR pszDefault, UINT cbBuffer);
BOOL GetToken(LPCSTR pszInput, LPSTR pszBuffer, LPCSTR *ppszNextToken, BOOL fUseBrackets);
BOOL LCClose(LPVOID pvHandle);
LPVOID LCOpen(LPCSTR pszFile);
BOOL LCReadNextCommand(LPVOID pvHandle, LPSTR pszBuffer, UINT cbBuffer);
BOOL LCReadNextConfig(LPVOID pvHandle, LPCSTR pszPrefix, LPSTR pszBuffer, UINT cbBuffer);
BOOL LCReadNextLine(LPVOID pvHandle, LPSTR pszBuffer, UINT cbBuffer);
int LCTokenize(LPCSTR pszInput, LPSTR *ppszBuffers, UINT cBuffers, LPSTR pszExtraBuffer);
HBITMAP LoadLSImage(LPCSTR pszFile, LPCSTR pszReserved);
HINSTANCE LSExecute(HWND hwndOwner, LPCSTR pszFile, int nCmdShow);
HINSTANCE LSExecuteEx(HWND hwndOwner, LPCSTR pszOperation, LPCSTR pszFile, LPCSTR pszArgs, LPCSTR pszDirectory, int nCmdShow);
BOOL LSGetVariable(LPCSTR pszVariable, LPSTR pszBuffer);
BOOL LSGetVariableEx(LPCSTR pszVariable, LPSTR pszBuffer, UINT cbBuffer);
BOOL WINAPI LSLog(int nLevel, LPCSTR pszModule, LPCSTR pszMessage);
BOOL WINAPIV LSLogPrintf(int nLevel, LPCSTR pszModule, LPCSTR pszFormat, ...);
void LSSetVariable(LPCSTR pszVariable, LPCSTR pszValue);
BOOL ParseBangCommand(HWND hwndCaller, LPCSTR pszBangCommand, LPCSTR pszArgs);
BOOL RemoveBangCommand(LPCSTR pszBangCommand);
void TransparentBltLS(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, COLORREF crTransparent);
void VarExpansion(LPSTR pszBuffer, LPCSTR pszInput);
void VarExpansionEx(LPSTR pszBuffer, LPCSTR pszInput, UINT cbBuffer);

#ifdef __cplusplus
};
#endif

#endif
