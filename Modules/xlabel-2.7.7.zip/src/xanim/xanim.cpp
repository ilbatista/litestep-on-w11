#include "stdafx.h"
#include "AnimEffect.h"

#define _MERGE_RDATA_
#include "AggressiveOptimize.h"

extern "C"
{
__declspec( dllexport ) void AnimEffectShow(RECT rcWindow, EffectType effect, int iSteps, int iAfterimages, int iDelay);
__declspec( dllexport ) void AnimEffectHide(RECT rcWindow, EffectType effect, int iSteps, int iAfterimages, int iDelay);
}

void AnimEffectShow(RECT rcWindow, EffectType effect, int iSteps, int iAfterimages, int iDelay)
{
	CRect window;
	window.left = rcWindow.left;
	window.right = rcWindow.right;
	window.top = rcWindow.top;
	window.bottom = rcWindow.bottom;

	AnimEffect anim;
	anim.Effect( effect);
	anim.Setup(iSteps, iAfterimages, iDelay);
	anim.Open(window);
}

void AnimEffectHide(RECT rcWindow, EffectType effect, int iSteps, int iAfterimages, int iDelay)
{
	CRect window;
	window.left = rcWindow.left;
	window.right = rcWindow.right;
	window.top = rcWindow.top;
	window.bottom = rcWindow.bottom;

	AnimEffect anim;
	anim.Effect( effect);
	anim.Setup(iSteps, iAfterimages, iDelay);
	anim.Close(window);
}

