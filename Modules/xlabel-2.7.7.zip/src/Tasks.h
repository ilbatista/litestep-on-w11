#if !defined(AFX_TASKS_H__683CFFC6_25E6_4AED_BB51_E216D62DBD54__INCLUDED_)
#define AFX_TASKS_H__683CFFC6_25E6_4AED_BB51_E216D62DBD54__INCLUDED_

class Tasks  
{
public:

	string UpdateTasks(string sep);

};

#endif // !defined(AFX_TASKS_H__683CFFC6_25E6_4AED_BB51_E216D62DBD54__INCLUDED_)
