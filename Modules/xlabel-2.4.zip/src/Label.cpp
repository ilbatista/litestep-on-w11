#include "common.h"
#include "LabelSettings.h"
#include "Font.h"
#include "Label.h"
#include "SystemInfo.h"
#include "Texture.h"
#include "wa3remote.h"
#include <shellapi.h>

#include "contextmenu.h"

#define TIMER_MOUSETRACK 1
#define TIMER_UPDATE 2
#define TIMER_SCROLL 3
#define TIMER_AUTOHIDE 4

//Andymon Moving Extention
//andymon@ls-universe.info
//************************
#define TIMER_MOUSETRACK_MOVE 5
//************************

//Andymon WA StatusBang Extention
//andymon@ls-universe.info
//************************
#define TIMER_WA_CHECK 6
//************************

extern LabelList labelList;
extern LabelList desktoplabelList;

Label::Label(const string &name)
:height(0),width(0),x(0),y(0)
{
	this->name = name;

	mousePressed = false;
	mouseInside = false;

	//Andymon Moving Extention
	//andymon@ls-universe.info
	//************************
	movemodifierkeyPressed = false;
	moveButtonPressed = 0;
	//************************

	hWnd = 0;
	hInstance = 0;
	box = 0;

	canBeVisible = true;
	visible = false;
	bUsingDefSkin = false;
	bInDestructor = false;

	scroll = false;
	scrollLimit = 0;
	scrollPosition = 0;
	
	backgroundDC = 0;
	bufferDC = 0;
	backgroundBitmap = 0;
	bufferBitmap = 0;

	background = 0;
	font = 0;

	originalText.push_back("");
	current = 0;
}

Label::~Label()
{
	bInDestructor = true;

	if(IsWindow(hWnd))
	{
		// just in case...
		//Andymon Extentions
		//andymon@ls-universe.info
		//************************
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
		KillTimer(hWnd, TIMER_WA_CHECK);
		//************************
		KillTimer(hWnd, TIMER_MOUSETRACK);
		KillTimer(hWnd, TIMER_UPDATE);
		KillTimer(hWnd, TIMER_SCROLL);
		DestroyWindow(hWnd);
	}

	if(backgroundBitmap)
	{
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
		DeleteObject(backgroundBitmap);
	}
	if (backgroundDC)
		DeleteDC(backgroundDC);

	if(bufferBitmap)
	{
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
		DeleteObject(bufferBitmap);
	}
	if (bufferDC)
		DeleteDC(bufferDC);

	if(!bUsingDefSkin)
		delete background;
	if(font != defaultSettings->font)
		delete font;
}

void Label::load(HINSTANCE hInstance, HWND box)
{
	this->hInstance = hInstance;
	
    if (IsWindow(box))
    {
        this->box = box;
    }
    else
    {
        this->box = NULL;
    }
	
	if (IsWindow(hWnd))	// window already exists...
		return;

	hWnd = CreateWindowEx(box ? 0 : WS_EX_TOOLWINDOW,
		"xLabel",
		name.c_str(),
		box ? WS_CHILD : WS_POPUP,
		x, y,			// FIXME they're all 0, the window will be repositioned
		width, height,	// FIXME see above
		box ? box : GetLitestepWnd(), // GetLitestepDesktop(), FIXME: this way there aren't as many z-order problems =)
		0,
		hInstance,
		this);
		
	if (hWnd)
	{
		SetWindowLong(hWnd, GWL_USERDATA, MAGIC_DWORD);

		reconfigure();
		repaint();
	}
	else
		delete this;
}

//Andymon WA StatusBang Extention
//andymon@ls-universe.info
//************************
void Label::xlabelload(HINSTANCE hInstance)
{
	this->hInstance = hInstance;
	
    this->box = NULL;
	
	if (IsWindow(hWnd))	// window already exists...
		return;
		
	hWnd = CreateWindowEx(box ? 0 : WS_EX_TOOLWINDOW,
		"xLabel",
		name.c_str(),
		box ? WS_CHILD : WS_POPUP,
		x, y,			// FIXME they're all 0, the window will be repositioned
		width, height,	// FIXME see above
		box ? box : GetLitestepWnd(), // GetLitestepDesktop(), FIXME: this way there aren't as many z-order problems =)
		0,
		hInstance,
		this);
		
	if (hWnd)
	{
		//Andymon WA StatusBang Extention
		//andymon@ls-universe.info
		//************************
		waRunning = false;
		waClosed = true;
		waPlaying = false;
		waPaused = false;
		waStopped = false;
		//************************

		waRunningCommand = GetRCLine("xlabel", "OnWinampRunning", "!none");
		waClosedCommand = GetRCLine("xlabel", "OnWinampClosed", "!none");
		waPlayCommand = GetRCLine("xlabel", "OnWinampPlaying", "!none");
		waPauseCommand = GetRCLine("xlabel", "OnWinampPaused", "!none");
		waStopCommand = GetRCLine("xlabel", "OnWinampStopped", "!none");
	
		waCheckInterval = GetRCInt("xlabel", "WinampCheckInterval", 5);

		SetWindowLong(hWnd, GWL_USERDATA, MAGIC_DWORD);
		if (waRunningCommand != "!none" || waClosedCommand != "!none" || waPlayCommand != "!none" || waPauseCommand != "!none" || waStopCommand != "!none" ) 
		{
			if (waCheckInterval != 0)
				SetTimer(hWnd, TIMER_WA_CHECK, waCheckInterval*1000, 0);
		}
	}
	else
		delete this;
}

//Desktop
void Label::xlabeldesktopload(HINSTANCE hInstance, string configLine)
{
	this->hInstance = hInstance;
	
    this->box = NULL;
	
	if (IsWindow(hWnd))	// window already exists...
		return;
		
	hWnd = CreateWindowEx(box ? 0 : WS_EX_TOOLWINDOW,
		"xLabel",
		name.c_str(),
		box ? WS_CHILD : WS_POPUP,
		x, y,			// FIXME they're all 0, the window will be repositioned
		width, height,	// FIXME see above
		box ? box : GetLitestepWnd(), // GetLitestepDesktop(), FIXME: this way there aren't as many z-order problems =)
		0,
		hInstance,
		this);
		
	if (hWnd)
	{
		SetWindowLong(hWnd, GWL_USERDATA, MAGIC_DWORD);

		desktopreconfigure(configLine);
		repaint();
	}
	else
		delete this;

}
//************************

void Label::desktopreconfigure(string configLine)
{
	NameValuePair iconTextValues[] = {
	{ "top", 1 },
	{ "bottom", 2 },
	{ "left", 3 },
	{ "right", 4 },
	{ 0, 0 }
	};

	LabelSettings settings("xlabeldesktop");
		
	alwaysUpdateContent = false;

	setAlwaysOnTop(false);

	iconSize = GetRCInt("xlabelDesktop", "IconSize", 32);
	iconTextAlign = GetRCNamedValue("xlabelDesktop", "TextPosition", iconTextValues, 2);
	savepath = GetRCString("xlabelDesktop", "ConfigFile", "");
	rememberPosition = GetRCBoolean("xlabelDesktop", "RememberPosition", false);
	
	setAlign(DT_CENTER);

	if (iconTextAlign == 1 || iconTextAlign == 2)
	{
		setLeftBorder(0);
		setRightBorder(0);
	}
	else if (iconTextAlign == 3)
	{
		setLeftBorder(0);
		setRightBorder(iconSize+5);
	}
	else if (iconTextAlign == 4)
	{
		setLeftBorder(iconSize+5);
		setRightBorder(0);
	}

	if (iconTextAlign == 1)
	{
		setTopBorder(0);
		setBottomBorder(iconSize+5);
		setVertAlign(ALIGN_BOTTOM);
	}
	else if (iconTextAlign == 2)
	{
		setTopBorder(iconSize+5);
		setBottomBorder(0);
		setVertAlign(ALIGN_TOP);
	}
	else if (iconTextAlign == 3 || iconTextAlign == 4)
	{
		setTopBorder(0);
		setBottomBorder(0);
		setVertAlign(ALIGN_CENTER);
	}

	char temp[64], name[32], ix[16], iy[16], path[128];
	char *buffers[] = {temp, name, ix, iy};

	string result;	

	if(LCTokenize(configLine.c_str(), buffers, 4, path) >= 4)
	{
		this->width = GetRCInt("xlabelDesktop", "ItemWidth", 125);
		this->height = GetRCInt("xlabelDesktop", "ItemHeight", 50);

		reposition(ParseCoord(ix, 0, GetSystemMetrics(SM_CXSCREEN)), ParseCoord(iy, 0, GetSystemMetrics(SM_CXSCREEN)), this->width, this->height, 0, 0);
	}

	//find filename
	string s = path;
	int i = s.rfind("\\");
	i = (i < 0) ? 0 : i + 1;
	s = s.substr(i, s.length() - i);

	//remove extention
	i = s.find(".");
	i = (i < 0) ? s.length() : i;
	s = s.substr(0, i);

	result = s;

	setBackground( GetDesktopTexture(path) );
	setFont(settings.font);	
	setText(result);

	/*long textWidth;
	long textHeight;

	if (bufferDC)
		font->measure(bufferDC, text, 0, &textWidth, &textHeight);

	int tempwidth = textWidth; 

	if ( (result.find(" ") < 0) && (tempwidth > GetRCInt("xlabeldesktop", "ItemWidth", 125)) )
	{
		string e;

		//before
		i = s.rfind(" ");
		i = (i < 0) ? 0 : i + 1;
		e = s.substr(i, s.length() - i);
		//after
		i = s.rfind(" ");
		i = (i < 0) ? s.length() : i ;
		s = s.substr(0, i);
		//combine
		result = (s + "\\n" + e);
		
		setText(result);
	}*/

	iconcommand = path;
	//Strip '"' or anything else surrounding ;)
	iconcommand = iconcommand.substr(1, iconcommand.length() - 2);

	leftDoubleClickCommand = ("!execute [\"" + iconcommand + "\"]");
	rightClickCommand = ".contextmenu";
	middleClickCommand = "!labelupdate xlabeldesktop";
	//enterleaveRegion = settings.enterleaveRegion;
	//enterCommand = ("!labelupdate " + this->name);

	setScrolling(false);

	shadowY = font->shadowY;

	trueTransparency = true;
	
	moveable = true;
	moveKey = 1;
	moveButton = 1;

	if (hWnd)
		settings.startHidden ? hide() : show();

	// FIXME
	if(background->isTransparent() && trueTransparency)
	{
		//set the window region that pink areas aren't part of it
		HDC tmpDC=CreateCompatibleDC(NULL);
		HBITMAP tmpBmp = CreateBitmap(width, height, 1, 32, NULL);
		HGDIOBJ tmpObj = SelectObject(tmpDC, tmpBmp);
		background->apply(tmpDC, 0, 0, width, height);
		SelectObject(tmpDC, tmpObj);

		// region handling a la MickeM =)
		HRGN region;
		region = BitmapToRegion(tmpBmp, RGB(254, 0, 254), 0, 0, 0);
		HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(windowRgn, region, NULL, RGN_COPY);

		if (!SetWindowRgn(hWnd, windowRgn, TRUE))
		{
			::DeleteObject(windowRgn);
		}

		//SetWindowRgn(hWnd, BitmapToRegion(tmpBmp, RGB(255, 0, 255), 0, 0, 0), false);
		DeleteObject(tmpBmp);
		DeleteObject(tmpObj);
		DeleteDC(tmpDC);
	}
}

void Label::reconfigure()
{
	LabelSettings settings(name.c_str());

	rememberPosition = false;

	setAlwaysOnTop(settings.alwaysOnTop);	
	reposition(settings.x, settings.y, settings.width, settings.height, 0, 0);	// FIXME? doesn't check old == new; ".0,0" at the end is from animation setup ;)

	bUseFahrenheit = settings.bUseFahrenheit;
	
	setBackground(settings.skin);		// FIXME: this does not check if old == new on !refresh
	setFont(settings.font);				// FIXME: see above
	setAlign(settings.align);
	setVertAlign(settings.vertAlign);
	setText(settings.text);

	alwaysUpdateContent = settings.alwaysUpdateContent;
	setUpdateInterval(settings.updateInterval);

	setLeftBorder(settings.leftBorder);
	setTopBorder(settings.topBorder);
	setRightBorder(settings.rightBorder);
	setBottomBorder(settings.bottomBorder);

	leftClickCommand = settings.leftClickCommand;
	leftDoubleClickCommand = settings.leftDoubleClickCommand;
	middleClickCommand = settings.middleClickCommand;
	middleDoubleClickCommand = settings.middleDoubleClickCommand;
	rightClickCommand = settings.rightClickCommand;
	rightDoubleClickCommand = settings.rightDoubleClickCommand;
	wheelDownCommand = settings.wheelDownCommand;
	wheelUpCommand = settings.wheelUpCommand;
	enterCommand = settings.enterCommand;
	leaveCommand = settings.leaveCommand;
	dropCommand = settings.dropCommand;
	textChangeCommand = settings.textChangeCommand;

	scrollPadLength = settings.scrollPadLength;
	scrollInterval = settings.scrollInterval;
	scrollSpeed = settings.scrollSpeed;
	setScrolling(settings.scroll);

	shadowY = font->shadowY;

	trueTransparency = settings.trueTransparency;

	//Andymon Moving Extention
	//andymon@ls-universe.info
	//************************
	moveable = settings.moveable;
	moveKey = settings.moveKey;
	moveButton = settings.moveButton;
	//************************
	
	//Andymon Regions Extention
	//andymon@ls-universe.info
	//************************
	labelLeftClickRegions = settings.labelLeftClickRegions;
	labelRightClickRegions = settings.labelRightClickRegions;
	labelMiddleClickRegions = settings.labelMiddleClickRegions;

	enterleaveRegion = settings.enterleaveRegion;
	//************************

	if (hWnd)
	{
		DragAcceptFiles(hWnd, !dropCommand.empty());
		settings.startHidden ? hide() : show();
	}

	// FIXME
	if(background->isTransparent() && trueTransparency)
	{
		//set the window region that pink areas aren't part of it
		HDC tmpDC=CreateCompatibleDC(NULL);
		HBITMAP tmpBmp = CreateBitmap(width, height, 1, 32, NULL);
		HGDIOBJ tmpObj = SelectObject(tmpDC, tmpBmp);
		background->apply(tmpDC, 0, 0, width, height);
		SelectObject(tmpDC, tmpObj);

		// region handling a la MickeM =)
		HRGN region;
		region = BitmapToRegion(tmpBmp, RGB(255, 0, 255), 0, 0, 0);
		HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(windowRgn, region, NULL, RGN_COPY);

		if (!SetWindowRgn(hWnd, windowRgn, TRUE)) {
			::DeleteObject(windowRgn);
		}

		//SetWindowRgn(hWnd, BitmapToRegion(tmpBmp, RGB(255, 0, 255), 0, 0, 0), false);
		DeleteObject(tmpBmp);
		DeleteObject(tmpObj);
		DeleteDC(tmpDC);
	}
}

//Andymon WA StatusBang Extention
//andymon@ls-universe.info
//************************
void Label::onwaChecking()
{
	HWND hwndWA2 = FindWindow("Winamp v1.x", NULL);
	HWND hwndWA3 = FindWindow(WA3REMOTE_WNDCLASS, NULL);

	if(hwndWA2)
	{
		if(!waRunningCommand.empty() && !waRunning)
			LSExecute(NULL, waRunningCommand.c_str(), SW_SHOWNORMAL);
		waRunning = true;
		waClosed = false;

		// WA2
		int status = SendMessage(hwndWA2, WM_USER, 0, 104);

		switch(status)
		{
		case 1:
			{
				if(!waPlayCommand.empty() && !waPlaying)
					LSExecute(NULL, waPlayCommand.c_str(), SW_SHOWNORMAL);
				waPlaying = true;
				waPaused = false;
				waStopped = false;
			}
			break;
			

		case 3:
			{
				if(!waPauseCommand.empty() && !waPaused)
					LSExecute(NULL, waPauseCommand.c_str(), SW_SHOWNORMAL);
				waPlaying = false;
				waPaused = true;
				waStopped = false;
			}
			break;

		default:
			{
				if(!waStopCommand.empty() && !waStopped)
					LSExecute(NULL, waStopCommand.c_str(), SW_SHOWNORMAL);
				waPlaying = false;
				waPaused = false;
				waStopped = true;
			}
			break;
		}
	}
	else if(hwndWA3)
	{
		if(!waRunningCommand.empty() && !waRunning)
			LSExecute(NULL, waRunningCommand.c_str(), SW_SHOWNORMAL);
		waRunning = true;
		waClosed = false;

		// WA3 (wa3remote.wac)
		int status = SendMessage(hwndWA3, WA3REMOTE_WM_GETSTATUS, 0, 0);

		switch(status)
		{
		case 1:
			{
				if(!waPlayCommand.empty() && !waPlaying)
					LSExecute(NULL, waPlayCommand.c_str(), SW_SHOWNORMAL);
				waPlaying = true;
				waPaused = false;
				waStopped = false;
			}
			break;

		case -1:
			{
				if(!waPauseCommand.empty() && !waPaused)
					LSExecute(NULL, waPauseCommand.c_str(), SW_SHOWNORMAL);
				waPlaying = false;
				waPaused = true;
				waStopped = false;
			}
			break;

		default:
			{
				if(!waStopCommand.empty() && !waStopped)
					LSExecute(NULL, waStopCommand.c_str(), SW_SHOWNORMAL);
				waPlaying = false;
				waPaused = false;
				waStopped = true;
			}
			break;
		}
	}
	else
	{
		if(waRunning)
			waRunning = false;
		if (!waClosedCommand.empty() && !waClosed)
			LSExecute(NULL, waClosedCommand.c_str(), SW_SHOWNORMAL);
		waClosed = true;
		waPlaying = false;
		waPaused = false;
		waStopped = false;
	}
}
//************************

//Andymon Extention
//andymon@ls-universe.info
//************************
void Label::mzscriptvarcopy(string var)
{
	string bang = ("!varset " + var + " \"" + text + "\"");
	LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
}

void Label::posmzscriptvarcopy(string varx, string vary)
{
	if (box)
		return;

	string bang;
	string posx, posy;

	RECT cr;
	GetWindowRect(this->hWnd, &cr);
	
	if (cr.left > GetSystemMetrics(SM_CXSCREEN)/3*2)
		cr.left = cr.left-GetSystemMetrics(SM_CXSCREEN);
	if (cr.top > GetSystemMetrics(SM_CYSCREEN)/3*2)
		cr.top = cr.top-GetSystemMetrics(SM_CYSCREEN);

	char buffer[32];
	sprintf(buffer, "%d", cr.left);
	posx = buffer;
	sprintf(buffer, "%d", cr.top);
	posy = buffer;

	bang = ("!varset " + varx + " \"" + posx + "\"");
	LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);

	bang = ("!varset " + vary + " \"" + posy + "\"");
	LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
}
//************************

void Label::setAlwaysOnTop(bool alwaysOnTop)
{
	this->alwaysOnTop = alwaysOnTop;
	
	if (box)
		return;
	
	if(hWnd)
	{
		ModifyStyle(hWnd, WS_POPUP, WS_CHILD);
		SetParent(hWnd, alwaysOnTop ? 0 : GetLitestepDesktop());
		ModifyStyle(hWnd, WS_CHILD, WS_POPUP);
		
		SetWindowPos(hWnd, alwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
			0, 0, 0, 0,
			SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
	}
}

void Label::setBox(HWND newparent)
{
	if (this->box == newparent)
		return;

	if (this->alwaysOnTop) this->setAlwaysOnTop(FALSE);
	
	this->box = newparent;
	
	ModifyStyle(hWnd, WS_POPUP, WS_CHILD);
	SetParent(hWnd, newparent);
//	ModifyStyle(hWnd, WS_CHILD, WS_POPUP);
}

void Label::setScrolling(bool scrolling)
{
	if (scrolling && !this->scroll)
	{
		scrollPosition = 0;
		SetTimer(hWnd, TIMER_SCROLL, scrollInterval, 0);
	}
	else if (!scrolling && this->scroll)
	{
		KillTimer(hWnd, TIMER_SCROLL);
		scrollPosition=0;
		repaint();
	}

	scrollLimit = 0;
	this->scroll = scrolling;
}

void Label::setScrollLimit(int limit)
{
	if (limit >= 0)
	{
		setScrolling(true);
		scrollLimit = limit + 1;
	}
	else
		setScrolling(false);

}

void Label::setBackground(Texture *background)
{
	if(!bUsingDefSkin)
		delete this->background;

	this->background = background;

	bUsingDefSkin = (background == defaultSettings->skin);
	
	repaint(true);
}

void Label::setFont(Font *font)
{
	if(this->font != defaultSettings->font)
		delete this->font;

	this->font = font;
	repaint();
}

void Label::setUpdateInterval(int updateInterval)
{
	this->updateInterval = updateInterval;
	if(hWnd && (dynamicText || alwaysUpdateContent))
		SetTimer(hWnd, TIMER_UPDATE, updateInterval, 0);
}

void Label::setAlign(int align)
{
	if (this->align == align)
		return;

	this->align = align;
	repaint();
}

void Label::setVertAlign(int vertAlign)
{
	if (this->vertAlign == vertAlign)
		return;

	this->vertAlign = vertAlign;
	repaint();
}

void Label::setText(const string &text)
{
	originalText = split(text, ";");
	current = 0;
	update();
}

void Label::setLeftBorder(int leftBorder)
{
	if (this->leftBorder == leftBorder)
		return;

	this->leftBorder = leftBorder;
	repaint();
}

void Label::setTopBorder(int topBorder)
{
	if (this->topBorder == topBorder)
		return;

	this->topBorder = topBorder;
	repaint();
}

void Label::setRightBorder(int rightBorder)
{
	if (this->rightBorder == rightBorder)
		return;

	this->rightBorder = rightBorder;
	repaint();
}

void Label::setBottomBorder(int bottomBorder)
{
	if (this->bottomBorder == bottomBorder)
		return;

	this->bottomBorder = bottomBorder;
	repaint();
}

void Label::repaint(bool invalidateCache)
{
	if(hWnd)
	{
		if(invalidateCache)
		{
			if(backgroundDC && backgroundBitmap)
			{
				backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
				DeleteObject(backgroundBitmap);
				backgroundBitmap = 0;
			}
		}

		InvalidateRect(hWnd, 0, FALSE);
	}
}

//Andymon Animation Extention
//andymon@ls-universe.info
//**************************

void Label::move(int x, int y, int steps, int time)
{
	if (steps > 0 && time > 0)
	{
	//---------------------------------
	int counter = 0;
	int deltax = x-this->x;
	int deltay = y-this->y;

	bool growx;
	bool growy;
	if (deltax < 0)
		growx = false;
	else
		growx = true;

	if (deltay < 0)
		growy = false;
	else
		growy = true;

	div_t div_result = div( deltax, steps );
    deltax = div_result.quot;
	div_result = div( deltay, steps );
    deltay = div_result.quot;

	if (deltax == 0)
		deltax = 1;
	if (deltay == 0)
		deltay = 1;

	int dynx = this->x;
	int dyny = this->y;

	this->x = x;
	this->y = y;

	if(hWnd)
	{
		while (counter <= steps)
		{
			dynx = dynx+deltax;
			if (growx && dynx > x)
				dynx = x;
			else if (!growx && dynx < x)
				dynx = x;

			dyny = dyny+deltay;
			if (growy && dyny > y)
				dyny = y;
			else if (!growy && dyny < y)
				dyny = y;
			
			SetWindowPos(hWnd, 0, dynx, dyny, 0, 0,
				SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);

			counter++;

			MSG msg;
			unsigned long lTime = GetTickCount();

			if( time > 0 )
			{
				while( (GetTickCount() - lTime) < time )
				{
					if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
					{
						TranslateMessage( &msg );
						DispatchMessage( &msg );
					}
				}
			}
		}
		SetWindowPos(hWnd, 0, x, y, 0, 0,
				SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
	}
	//---------------------------------
	}
	else
	{
		this->x = x;
		this->y = y;

		if(hWnd)
		{
			SetWindowPos(hWnd, 0, x, y, 0, 0,
			SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
		}
	}
}

//**************************

//Andymon Animation Extention
//andymon@ls-universe.info
//**************************

void Label::reposition(int x, int y, int width, int height, int steps, int time)
{
	if (steps > 0 && time > 0)
	{
	//---------------------------------
	int counter = 0;
	int deltax = x-this->x;
	int deltay = y-this->y;
	int deltasizex = width-this->width;
	int deltasizey = height-this->height;

	bool growx;
	bool growy;
	bool growsizex;
	bool growsizey;
	
	if (deltax < 0)
		growx = false;
	else
		growx = true;
	if (deltay < 0)
		growy = false;
	else
		growy = true;
	
	if (deltasizex < 0)
		growsizex = false;
	else
		growsizex = true;
	if (deltasizey < 0)
		growsizey = false;
	else
		growsizey = true;

	div_t div_result;
	div_result = div( deltax, steps );
    deltax = div_result.quot;
	div_result = div( deltay, steps );
    deltay = div_result.quot;

	div_result = div( deltasizex, steps );
    deltasizex = div_result.quot;
	div_result = div( deltasizey, steps );
    deltasizey = div_result.quot;

	if (deltax == 0)
		deltax = 1;
	if (deltay == 0)
		deltay = 1;
	if (deltasizex == 0)
		deltasizex = 1;
	if (deltasizey == 0)
		deltasizey = 1;

	int dynx = this->x;
	int dyny = this->y;
	int dynwidth = this->width;
	int dynheight = this->height;

	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;

	if(hWnd)
	{
		while (counter <= steps)
		{
			dynx = dynx+deltax;
			if (growx && dynx > x)
				dynx = x;
			else if (!growx && dynx < x)
				dynx = x;

			dyny = dyny+deltay;
			if (growy && dyny > y)
				dyny = y;
			else if (!growy && dyny < y)
				dyny = y;

			dynwidth = dynwidth+deltasizex;
			if (growsizex && dynwidth > width)
				dynwidth = width;
			else if (!growsizex && dynwidth < width)
				dynwidth = width;

			dynheight = dynheight+deltasizey;
			if (growsizey && dynheight > height)
				dynheight = height;
			else if (!growsizey && dynheight < height)
				dynheight = height;
			
			SetWindowPos(hWnd, 0, dynx, dyny, dynwidth, dynheight,
				SWP_NOACTIVATE | SWP_NOZORDER);

			counter++;

			MSG msg;
			unsigned long lTime = GetTickCount();

			if( time > 0 )
			{
				while( (GetTickCount() - lTime) < time )
				{
					if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
					{
						TranslateMessage( &msg );
						DispatchMessage( &msg );
					}
				}
			}
		}
		SetWindowPos(hWnd, 0, x, y, width, height,
			SWP_NOACTIVATE | SWP_NOZORDER);
	}
	//---------------------------------
	}
	else
	{
		this->x = x;
		this->y = y;
		this->height = height;
		this->width = width;

		if(hWnd)
		{
			SetWindowPos(hWnd, 0, x, y, width, height,
				SWP_NOACTIVATE | SWP_NOZORDER);
		}
	}
}

//**************************

//Andymon Animation Extention
//andymon@ls-universe.info
//**************************

void Label::resize(int width, int height, int steps, int time)
{
	if (steps > 0 && time > 0)
	{
	//---------------------------------
	int counter = 0;
	int deltax = width-this->width;
	int deltay = height-this->height;

	bool growx;
	bool growy;
	if (deltax < 0)
		growx = false;
	else
		growx = true;

	if (deltay < 0)
		growy = false;
	else
		growy = true;

	div_t div_result = div( deltax, steps );
    deltax = div_result.quot;
	div_result = div( deltay, steps );
    deltay = div_result.quot;

	if (deltax == 0)
		deltax = 1;
	if (deltay == 0)
		deltay = 1;

	int dynwidth = this->width;
	int dynheight = this->height;

	this->height = height;
	this->width = width;

	if(hWnd)
	{
		while (counter <= steps)
		{
			dynwidth = dynwidth+deltax;
			if (growx && dynwidth > width)
				dynwidth = width;
			else if (!growx && dynwidth < width)
				dynwidth = width;

			dynheight = dynheight+deltay;
			if (growy && dynheight > height)
				dynheight = height;
			else if (!growy && dynheight < height)
				dynheight = height;
			
			SetWindowPos(hWnd, 0, 0, 0, dynwidth, dynheight,
				SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);

			counter++;

			MSG msg;
			unsigned long lTime = GetTickCount();

			if( time > 0 )
			{
				while( (GetTickCount() - lTime) < time )
				{
					if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
					{
						TranslateMessage( &msg );
						DispatchMessage( &msg );
					}
				}
			}
		}
		SetWindowPos(hWnd, 0, 0, 0, width, height,
				SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
	}
	//---------------------------------
	}
	else
	{
		this->height = height;
		this->width = width;

		if(hWnd)
		{
			SetWindowPos(hWnd, 0, 0, 0, width, height,
				SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
		}
	}
}

//**************************

void Label::internalHide()
{
	canBeVisible = false;

	if(hWnd)
	{
		ShowWindow(hWnd, SW_HIDE);
	}
}

void Label::internalShow()
{
	canBeVisible = true;

	if(hWnd && visible)
	{
		ShowWindow(hWnd, SW_SHOWNOACTIVATE);
	}
}

void Label::hide()
{
	if(hWnd)
	{
		visible = false;
		ShowWindow(hWnd, SW_HIDE);
		KillTimer(hWnd, TIMER_AUTOHIDE);
	}
}

void Label::show()
{
	if (!hWnd)
		load(hInstance, box);
	
	if(hWnd)
	{
		visible = true;
		KillTimer(hWnd, TIMER_AUTOHIDE);

		if(canBeVisible)
		{
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);
		}
	}
}

void Label::showHide(double timeout)
{
	show();
	SetTimer(hWnd, TIMER_AUTOHIDE, timeout * 1000, NULL);
}

void Label::previous()
{
	current--;
	if(current < 0) current = originalText.size() - 1;
	update();
}

void Label::next()
{
	current++;
	if(current >= originalText.size()) current = 0;
	update();
}

void Label::update()
{
	string oldText = text;
	text = systemInfo->processLabelText(originalText[current], this, &dynamicText);

	if(hWnd)
	{
		if(dynamicText || alwaysUpdateContent)
			SetTimer(hWnd, TIMER_UPDATE, updateInterval, 0);
		else
			KillTimer(hWnd, TIMER_UPDATE);
	}

	if(text != oldText)
	{
		if(!textChangeCommand.empty())
			LSExecute(NULL, textChangeCommand.c_str(), SW_SHOWNORMAL);
	}

	repaint();
}

void Label::clipboardCopy(string prefix)
{
	string toCopy = prefix.empty() ? text : (prefix + " " + text);
	SetClipboardText(hWnd, toCopy.c_str());
}

void Label::clipboardPaste(string prefix)
{
	char buffer[256];

	if(GetClipboardText(hWnd, buffer, 256))
	{
		string toPaste = prefix.empty() ? string(buffer) : (prefix + " " + string(buffer));
		setText(toPaste);
	}
}

void Label::relayMouseMessageToBox(UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	pt.x = GET_X_LPARAM(lParam);
	pt.y = GET_Y_LPARAM(lParam);

	MapWindowPoints(hWnd, box, &pt, 1);
	PostMessage(box, message, wParam, MAKELPARAM((short) pt.x, (short) pt.y));
}

void Label::onLButtonDblClk(int x, int y)
{
	if(leftDoubleClickCommand.length() > 0)
		LSExecute(hWnd, leftDoubleClickCommand.c_str(), SW_SHOWNORMAL);
}

//Andymon Regions Extention
//andymon@ls-universe.info
//************************
bool Label::checkRegion(int x, int y, StringList inputlist)
{
	bool found = false;
	if (!inputlist.empty())
	{
		for(StringListIterator it = inputlist.begin(); it != inputlist.end(); it++)
		{
			char temp[32], left[16], top[16], right[16], bottom[16], command[128];
			char *buffers[] = {temp, left, top, right, bottom};

			if(LCTokenize((*it).c_str(), buffers, 5, command) >= 5)
			{
				RECT rc;
				GetClientRect(hWnd, &rc);

				int intleft = ParseCoord(left, 0, rc.right-rc.left);
				int intright = ParseCoord(right, -0, rc.right-rc.left);
				int inttop = ParseCoord(top, 0, rc.bottom-rc.top);
				int intbottom  = ParseCoord(bottom, -0, rc.bottom-rc.top);

				if (intleft < intright && inttop < intbottom)
				{
					POINT pt;
					pt.x = x;
					pt.y = y;

					if(pt.x >= intleft && pt.x <= intright && pt.y >= inttop && pt.y <= intbottom)
					{
						if((*it).length() > 0)
						{	
							string temp = command;
							string bang = ("!execute [" + temp + "]");
							LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
							found = true;
							return found;
						}	
					}
				}
			}
		}
	}
	return found;
}

bool Label::checkenterleaveRegion(int x, int y)
{
	bool inside = false;
	char left[16], top[16], right[16], bottom[16];
	char *buffers[] = {left, top, right, bottom};
	if(LCTokenize(enterleaveRegion.c_str(), buffers, 4, NULL) >= 4)
	{
		POINT pt;
		pt.x = x;
		pt.y = y;

		RECT rc;
		GetClientRect(hWnd, &rc);

		int intleft = ParseCoord(left, 0, rc.right-rc.left);
		int intright = ParseCoord(right, -0, rc.right-rc.left);
		int inttop = ParseCoord(top, 0, rc.bottom-rc.top);
		int intbottom = ParseCoord(bottom, -0, rc.bottom-rc.top);

		if (intleft < intright && inttop < intbottom)
		{
			if(pt.x >= intleft && pt.x <= intright && pt.y >= inttop && pt.y <= intbottom)
				inside = true;
		}
	}

	return inside;
 }
//************************


//Andymon Moving Extention
//andymon@ls-universe.info
//************************

void Label::onLButtonDown(int x, int y)
{
	if(moveable && moveButton == 1)
	{
		if(!mousePressed && !movemodifierkeyPressed)
			mousePressed = true;
		else if (!mousePressed && movemodifierkeyPressed)
		{
			if (box)
				return;
			mousePressed = true;
			moveButtonPressed = 1;
			GetCursorPos(&savedpt);
			ScreenToClient(hWnd, &savedpt);
			SetCapture(hWnd);
		}
	}
	else
	{
		if(!mousePressed)
			mousePressed = true;
	}
}

	
void Label::onLButtonUp(int x, int y)
{	
	if(moveable && moveButton == 1)
	{
		if(mousePressed && !movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			
			if (!checkRegion(x, y, labelLeftClickRegions))
			{
				POINT pt;
				pt.x = x;
				pt.y = y;

				RECT rc;
				GetClientRect(hWnd, &rc);
				this->x = rc.left;
				this->y = rc.top;

				if(PtInRect(&rc, pt))
				{
					if(leftClickCommand.length() > 0)
						LSExecute(hWnd, leftClickCommand.c_str(), SW_SHOWNORMAL);
				}
			}
			
			if ( rememberPosition )
			{
				string bang;
				bang = ("!labeldesktopsave " + this->name);
					LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
			}

			mousePressed = false;
			moveButtonPressed = 0;
		}
		else if (mousePressed && movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

			if ( rememberPosition )
			{
				string bang;
				bang = ("!labeldesktopsave " + this->name);
					LSExecute(hWnd, bang.c_str(), SW_SHOWNORMAL);
			}

			mousePressed = false;
			moveButtonPressed = 0;
		}
	}
	else
	{
		//To be on the save side
		ReleaseCapture();
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

		if(mousePressed && !checkRegion(x, y, labelLeftClickRegions))
		{
			POINT pt;
			pt.x = x;
			pt.y = y;

			RECT rc;
			GetClientRect(hWnd, &rc);
			this->x = rc.left;
			this->y = rc.top;

			if(PtInRect(&rc, pt))
			{
				if(leftClickCommand.length() > 0)
					LSExecute(hWnd, leftClickCommand.c_str(), SW_SHOWNORMAL);
			}
		}
		mousePressed = false;
		moveButtonPressed = 0;
	}
}

//************************

void Label::onMButtonDblClk(int x, int y)
{
	if(middleDoubleClickCommand.length() > 0)
		LSExecute(hWnd, middleDoubleClickCommand.c_str(), SW_SHOWNORMAL);
}

//Andymon Moving Extention
//andymon@ls-universe.info
//************************

void Label::onMButtonDown(int x, int y)
{
	if(moveable && moveButton == 3)
	{
		if(!mousePressed && !movemodifierkeyPressed)
			mousePressed = true;
		else if (!mousePressed && movemodifierkeyPressed)
		{
			if (box)
				return;
			mousePressed = true;
			moveButtonPressed = 3;
			GetCursorPos(&savedpt);
			ScreenToClient(hWnd, &savedpt);
			SetCapture(hWnd);
		}
	}
	else
	{
		if(!mousePressed)
			mousePressed = true;
	}
}

void Label::onMButtonUp(int x, int y)
{
	if(moveable && moveButton == 3)
	{
		if(mousePressed && !movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			
			if (!checkRegion(x, y, labelMiddleClickRegions))
			{
				POINT pt;
				pt.x = x;
				pt.y = y;

				RECT rc;
				GetClientRect(hWnd, &rc);
				this->x = rc.left;
				this->y = rc.top;

				if(PtInRect(&rc, pt))
				{
					if(middleClickCommand.length() > 0)
						LSExecute(hWnd, middleClickCommand.c_str(), SW_SHOWNORMAL);
				}
			}
			
			mousePressed = false;
			moveButtonPressed = 0;
		}
		else if (mousePressed && movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

			mousePressed = false;
			moveButtonPressed = 0;
		}
	}
	else
	{
		//To be on the save side
		ReleaseCapture();
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

		if(mousePressed && !checkRegion(x, y, labelMiddleClickRegions))
		{
			POINT pt;
			pt.x = x;
			pt.y = y;

			RECT rc;
			GetClientRect(hWnd, &rc);
			this->x = rc.left;
			this->y = rc.top;

			if(PtInRect(&rc, pt))
			{
				if(middleClickCommand.length() > 0)
					LSExecute(hWnd, middleClickCommand.c_str(), SW_SHOWNORMAL);
			}
		}
		mousePressed = false;
		moveButtonPressed = 0;
	}
}

//************************

void Label::onRButtonDblClk(int x, int y)
{
	if(rightDoubleClickCommand.length() > 0)
		LSExecute(hWnd, rightDoubleClickCommand.c_str(), SW_SHOWNORMAL);
}

//Andymon Moving Extention
//andymon@ls-universe.info
//************************

void Label::onRButtonDown(int x, int y)
{
	if(moveable && moveButton == 2)
	{
		if(!mousePressed && !movemodifierkeyPressed)
			mousePressed = true;
		else if (!mousePressed && movemodifierkeyPressed)
		{
			if (box)
				return;
			mousePressed = true;
			moveButtonPressed = 2;
			GetCursorPos(&savedpt);
			ScreenToClient(hWnd, &savedpt);
			SetCapture(hWnd);
		}
	}
	else
	{
		if(!mousePressed)
			mousePressed = true;
	}
}

void Label::onRButtonUp(int x, int y)
{
	if(moveable && moveButton == 2)
	{
		if(mousePressed && !movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			
			if (!checkRegion(x, y, labelRightClickRegions))
			{
				POINT pt;
				pt.x = x;
				pt.y = y;

				RECT rc;
				GetClientRect(hWnd, &rc);
				this->x = rc.left;
				this->y = rc.top;

				if(PtInRect(&rc, pt))
				{
					if(rightClickCommand.length() > 0)
						LSExecute(hWnd, rightClickCommand.c_str(), SW_SHOWNORMAL);
				}
			}
			
			mousePressed = false;
			moveButtonPressed = 0;
		}
		else if (mousePressed && movemodifierkeyPressed)
		{
			//To be on the save side
			ReleaseCapture();
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

			mousePressed = false;
			moveButtonPressed = 0;
		}
	}
	else 
	{
		//To be on the save side
		ReleaseCapture();
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);

		if(mousePressed && !checkRegion(x, y, labelRightClickRegions))
		{
			POINT pt;
			pt.x = x;
			pt.y = y;

			RECT rc;
			GetClientRect(hWnd, &rc);
			this->x = rc.left;
			this->y = rc.top;

			if(PtInRect(&rc, pt))
			{
				if(rightClickCommand.length() > 0 && rightClickCommand != ".contextmenu")
					LSExecute(hWnd, rightClickCommand.c_str(), SW_SHOWNORMAL);
				else
					ContextMenu(iconcommand.c_str());
			}
		}
		mousePressed = false;
		moveButtonPressed = 0;
	}
}

//************************

void Label::onWheelDown(int x, int y)
{
	if(wheelDownCommand.length() > 0)
		LSExecute(hWnd, wheelDownCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onWheelUp(int x, int y)
{
	if(wheelUpCommand.length() > 0)
		LSExecute(hWnd, wheelUpCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onMouseEnter()
{
	if(enterCommand.length() > 0)
		LSExecute(hWnd, enterCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onMouseLeave()
{
	if(leaveCommand.length() > 0)
		LSExecute(hWnd, leaveCommand.c_str(), SW_SHOWNORMAL);
}

//Andymon Moving Extention
//andymon@ls-universe.info
//************************

void Label::onMouseMove(int x, int y)
{
	if(moveable)
	{
		if (mousePressed && movemodifierkeyPressed && moveButtonPressed == moveButton)
			SetTimer(hWnd, TIMER_MOUSETRACK_MOVE, 5, 0);
		else
		{
			KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
			KillTimer(hWnd, TIMER_MOUSETRACK);

			if(!mouseInside)
			{
				if(checkenterleaveRegion(x, y))
				{
					mouseInside = true;
					onMouseEnter();
				}
			}

			SetTimer(hWnd, TIMER_MOUSETRACK, 100, 0);
		}
	}
	else if (!moveable)
	{
		if(!mouseInside)
		{
			if(checkenterleaveRegion(x, y))
			{
				mouseInside = true;
				onMouseEnter();
			}
		}

		SetTimer(hWnd, TIMER_MOUSETRACK, 100, 0);
	}
}

//************************

void Label::onDrop(const string &file)
{
	// TODO: this should make a bit more sense... and should be more flexible
	string fullCommand = dropCommand + " \"" + file + "\""; // FIXME: ugly hack
	LSExecute(hWnd, fullCommand.c_str(), SW_SHOWNORMAL);
}

void Label::onPaint(HDC hDC)
{
	RECT r;
	GetWindowRect(hWnd, &r);

	int width = r.right - r.left;
	int height = r.bottom - r.top;

	// keep a cached rendition of the background
	if(!backgroundBitmap)
	{
		if(!backgroundDC)
			backgroundDC = CreateCompatibleDC(hDC);

		backgroundBitmap = CreateCompatibleBitmap(hDC, width, height);
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);

		if(background->isTransparent())
		{
			if(box)
			{
				// save the previous DC contents as the background
				BitBlt(backgroundDC, 0, 0, width, height, hDC, 0, 0, SRCCOPY);
			}
			else
			{
				// paint desktop on display DC and then into background buffer
				PaintDesktopEx(backgroundDC, 0, 0, width, height, r.left, r.top, FALSE);
				// PaintDesktop(hDC);
				// BitBlt(backgroundDC, 0, 0, width, height, hDC, 0, 0, SRCCOPY);
			}
		}
		
		background->apply(backgroundDC, 0, 0, width, height);
	}

	// double buffer for flicker-free paint
	if(!bufferBitmap)
	{
		if(!bufferDC)
			bufferDC = CreateCompatibleDC(hDC);

		bufferBitmap = CreateCompatibleBitmap(hDC, width, height);
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
	}

	// blt background into double buffer
	BitBlt(bufferDC, 0, 0, width, height, backgroundDC, 0, 0, SRCCOPY);

	// render text
	long textWidth;
	long textHeight;

	font->measure(bufferDC, text, 0, &textWidth, &textHeight);

	//don't scroll if text fits into label
	if(!(scroll && textWidth > width - leftBorder - rightBorder))
	{
		font->apply(bufferDC,
			leftBorder,
			topBorder,
			width - leftBorder - rightBorder,
			height - topBorder - bottomBorder,
			text,
			align /* | DT_SINGLELINE */ | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS,
			vertAlign);
	}
	else
	{
		if(scrollPosition <= 0)
		{
			scrollPosition = textWidth + scrollPadLength;
			
			if (scrollLimit)
			{
				scrollLimit--;
				if (scrollLimit == 0)
					setScrolling(false);
			}
		}

		if(scrollPosition > textWidth + scrollPadLength )
		{
			scrollPosition = 0;
		}

		HRGN oldRGN = NULL;
		HRGN newRGN = NULL;
		GetClipRgn(bufferDC, oldRGN);
		// positive shadows
		if (shadowY >= 0 && (shadowY-bottomBorder)<0 )
		{
			newRGN=CreateRectRgn(leftBorder, topBorder, width - rightBorder, height - bottomBorder + shadowY); // V
		}
		else if (shadowY >= 0)
		{
			newRGN=CreateRectRgn(leftBorder, topBorder, width - rightBorder, height - bottomBorder); // V
		}
		// handle negative shadows
		else if (shadowY<0 && topBorder+shadowY >= 0)
		{
			newRGN=CreateRectRgn(leftBorder, topBorder + shadowY, width - rightBorder, height - bottomBorder); // V
		}
		else
		{
			newRGN=CreateRectRgn(leftBorder, 0, width - rightBorder, height - bottomBorder); // V
		}
		
		SelectClipRgn(bufferDC, newRGN);
		DeleteObject(newRGN);

		font->apply(bufferDC,
			leftBorder, //(width - textWidth) / 2 - 2,
			topBorder,
			scrollPosition - scrollPadLength,
			height - topBorder - bottomBorder,
			text,
			DT_RIGHT | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS,
			vertAlign);

		font->apply(bufferDC,
			scrollPosition + leftBorder,
			topBorder,
			textWidth,
			height - topBorder - bottomBorder,
			text,
			DT_LEFT | DT_VCENTER | DT_NOPREFIX | DT_EXPANDTABS,
			vertAlign);

		SelectClipRgn(bufferDC, oldRGN);
		DeleteObject(oldRGN);
	};

	// blt the double buffer to the display
	BitBlt(hDC, 0, 0, width, height, bufferDC, 0, 0, SRCCOPY);
}

void Label::onSize(int width, int height)
{
	this->height = height;
	this->width = width;

	if(backgroundDC && backgroundBitmap)
	{
		backgroundBitmap = (HBITMAP) SelectObject(backgroundDC, backgroundBitmap);
		DeleteObject(backgroundBitmap);
		backgroundBitmap = 0;
	}

	if(bufferDC && bufferBitmap)
	{
		bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
		DeleteObject(bufferBitmap);
		bufferBitmap = 0;
	}

	InvalidateRect(hWnd, 0, FALSE);
}

void Label::onTimer(int timerID)
{
	switch(timerID)
	{
		case TIMER_MOUSETRACK:

			POINT pt;
			GetCursorPos(&pt);
			ScreenToClient(hWnd, &pt);

			if(!checkenterleaveRegion(pt.x, pt.y))
			{
				if (mouseInside)
				{
					onMouseLeave();	
					mouseInside = false;
				}
			}

			RECT rc;
			GetWindowRect(hWnd, &rc);
			GetCursorPos(&pt);

			if(!PtInRect(&rc, pt))
			{
				KillTimer(hWnd, TIMER_MOUSETRACK);
				mouseInside = false;
				mousePressed = false;
			}

		break;

		//Andymon Moving Extention
		//andymon@ls-universe.info
		//************************

		case TIMER_MOUSETRACK_MOVE:

			POINT newpt;
			GetCursorPos(&newpt);
			
			newpt.x = newpt.x-savedpt.x;
			newpt.y = newpt.y-savedpt.y;
			move(newpt.x, newpt.y, 0, 0);
		
		break;

		//************************

		//Andymon WA StatusBang Extention
		//andymon@ls-universe.info
		//************************

		case TIMER_WA_CHECK:

			onwaChecking();

		break;

		//************************

		case TIMER_UPDATE:

			update();

		break;

		case TIMER_SCROLL:

			scrollPosition -= scrollSpeed;
			repaint();

		break;

		case TIMER_AUTOHIDE:

			hide();

		break;
	}
}

void Label::onWindowPosChanged(WINDOWPOS *windowPos)
{
	repaint(true);
}

bool Label::onWindowMessage(UINT message, WPARAM wParam, LPARAM lParam, LRESULT &lResult)
{
	extern HWND messageHandler;
	
	//Andymon Moving Extention
	//andymon@ls-universe.info
	//************************
	if (moveKey == 3)
		movemodifierkeyPressed = (0x8000 & GetKeyState(VK_CONTROL)) && (0x8000 & GetKeyState(VK_SHIFT));
	else if (moveKey == 2)
		movemodifierkeyPressed = (0x8000 & GetKeyState(VK_SHIFT));
	else if (moveKey == 1)
		movemodifierkeyPressed = (0x8000 & GetKeyState(VK_CONTROL));
	else 
		movemodifierkeyPressed = (0x8000 & GetKeyState(VK_CONTROL));

	if (moveable && !movemodifierkeyPressed)
		KillTimer(hWnd, TIMER_MOUSETRACK_MOVE);
	//************************

	switch(message)
	{
		case LM_SETLABELTEXT:
		{
			setText(string((const char *) lParam));
			return true;
		}

		case WM_COPYDATA:
		{
			COPYDATASTRUCT *cds = (COPYDATASTRUCT *) lParam;
			
			if(cds->dwData == LM_SETLABELTEXT)
				setText(string((const char *) cds->lpData));

			return false;
		}

		case WM_CLOSE:
		{
			lResult = 0;
			return true;
		}

		case WM_DESTROY:
		{
			if(box)		// FIXME: this is the old workaround
			{
				box = NULL;
				hide();
			}
				
			hWnd = NULL;	// FIXME: dirty hack
			
			return false;
		}

		case WM_DROPFILES:
		{
			if(dropCommand.empty())	// we shouldn't get here... but somehow we did :p
				break;
			
			int numDropped, i;
			char szFile[MAX_PATH];
			
			numDropped = DragQueryFile((HDROP) wParam, 0xFFFFFFFF, NULL, 0);
			for (i = 0; i < numDropped; i++)
			{
				DragQueryFile((HDROP) wParam, i, (char *)&szFile, MAX_PATH);
				if (szFile && szFile[0])
				{
					onDrop(szFile);
				}
			}
			DragFinish((HDROP) wParam);
			
			return 0;
		}
		
		case WM_LBUTTONDBLCLK:
		{
			if(leftDoubleClickCommand.empty())
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onLButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_LBUTTONDOWN:
		{
			//Andymon Moving Extention
			if(leftDoubleClickCommand.empty() && leftClickCommand.empty() && labelLeftClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onLButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_LBUTTONUP:
		{
			//Andymon Moving Extention
			if(leftDoubleClickCommand.empty() && leftClickCommand.empty() && labelLeftClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onLButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONDBLCLK:
		{
			if(middleDoubleClickCommand.empty())
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onMButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONDOWN:
		{
			//Andymon Moving Extention
			if(middleDoubleClickCommand.empty() && middleClickCommand.empty() && labelMiddleClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onMButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MBUTTONUP:
		{
			//Andymon Moving Extention
			if(middleDoubleClickCommand.empty() && middleClickCommand.empty() && labelMiddleClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onMButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONDBLCLK:
		{
			if(rightDoubleClickCommand.empty())
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onRButtonDblClk((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONDOWN:
		{
			//Andymon Moving Extention
			if(rightDoubleClickCommand.empty() && rightClickCommand.empty() && labelRightClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onRButtonDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_RBUTTONUP:
		{
			//Andymon Moving Extention
			if(rightDoubleClickCommand.empty() && rightClickCommand.empty() && labelRightClickRegions.empty() && !moveable)
			{
				relayMouseMessageToBox(message, wParam, lParam);
				return true;
			}

			onRButtonUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_MOUSEWHEEL:
		{
			if ((short)(HIWORD(wParam)) < 0)
			{
				if(wheelDownCommand.empty())
				{
					relayMouseMessageToBox(message, wParam, lParam);
					return true;
				}

				onWheelDown((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
				return true;
			}
			else
			{
				if(wheelUpCommand.empty())
				{
					relayMouseMessageToBox(message, wParam, lParam);
					return true;
				}
				
				onWheelUp((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
				return true;
			}
		}

		case WM_MOUSEMOVE:
		{
			onMouseMove((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hDC;

			if(!wParam)
				hDC = BeginPaint(hWnd, &ps);
			else
				hDC = (HDC) wParam;

			onPaint(hDC);

			if(!wParam)
				EndPaint(hWnd, &ps);

			return true;
		}

		case WM_SIZE:
		{
			onSize((int) (short) LOWORD(lParam), (int) (short) HIWORD(lParam));
			return true;
		}

		case WM_TIMER:
		{
			onTimer((int) wParam);
			return true;
		}

		case WM_WINDOWPOSCHANGED:
		{
			onWindowPosChanged((WINDOWPOS *) lParam);
			return false;
		}
	}

	return false;
}

LRESULT Label::windowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	Label *label = NULL;

	if(message == WM_NCCREATE)
	{
		label = (Label *) ((CREATESTRUCT *) lParam)->lpCreateParams;
		label->hWnd = hWnd;
		SetWindowLong(hWnd, 0, (LONG) label);
	}
	else
		label = (Label *) GetWindowLong(hWnd, 0);

	if(label)
	{
		LRESULT lResult = 0;

		if(label->onWindowMessage(message, wParam, lParam, lResult))
			return lResult;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}
