//---------------------------------------------------------------------------
// Network Statistics
//---------------------------------------------------------------------------
// Parts of this code were adapted from code written by Stas Khirman
// (stas@rocketmail.com)
//---------------------------------------------------------------------------

#include "common.h"
#include "NetStats.h"

NetStats::NetStats()
{
	hinstInetMib = NULL;
	pfnSnmpExtensionQuery = NULL;
	pfnSnmpExtensionInit = NULL;
	hThread = NULL;

	for(int i = 0; i < NUM_SAMPLES; i++)
	{
		nSamplesIn[i] = 0;
		nSamplesOut[i] = 0;
	}

	iSample = 0;
	nBytesPerSecIn = 0;
	nBytesPerSecOut = 0;
}

NetStats::~NetStats()
{
	Stop();
}

int
NetStats::GetBytesPerSecIn()
{
	return nBytesPerSecIn;
}

int
NetStats::GetBytesPerSecOut()
{
	return nBytesPerSecOut;
}

BOOL
NetStats::IsConnAvailable()
{
	return (GetDefRouteIfIndex() != 0) ? TRUE : FALSE;
}

BOOL
NetStats::Start()
{
	HANDLE hPollForTrapEvent;
	AsnObjectIdentifier SupportedView;
	DWORD dwThreadId;

	hinstInetMib = LoadLibrary("INETMIB1.DLL");

	if(!hinstInetMib)
		return FALSE;

	pfnSnmpExtensionQuery = (PFNSNMPEXTENSIONQUERY) GetProcAddress(hinstInetMib, "SnmpExtensionQuery");
	pfnSnmpExtensionInit = (PFNSNMPEXTENSIONINIT) GetProcAddress(hinstInetMib, "SnmpExtensionInit");

	if(!pfnSnmpExtensionQuery || !pfnSnmpExtensionInit)
	{
		FreeLibrary(hinstInetMib);
		hinstInetMib = NULL;
		return FALSE;
	}

	if(!(*pfnSnmpExtensionInit)(GetTickCount(), &hPollForTrapEvent, &SupportedView))
	{
		FreeLibrary(hinstInetMib);
		hinstInetMib = NULL;
		return FALSE;
	}

	fFirstUpdate = TRUE;
	dwLastUpdateTime = GetTickCount();
	hThread = CreateThread(NULL, 0, ThreadProc, this, 0, &dwThreadId);
	return TRUE;
}

void
NetStats::Stop()
{
	if(hThread)
	{
		TerminateThread(hThread, 0);
		CloseHandle(hThread);
		hThread = NULL;
	}

	if(hinstInetMib)
	{
		FreeLibrary(hinstInetMib);
		hinstInetMib = NULL;
	}

	nBytesPerSecIn = 0;
	nBytesPerSecOut = 0;
}

void
NetStats::Update()
{
	DWORD dwTime;
	DWORD dwElapsedTime;
	int ifIndex;
	int ifInOctets;
	int ifOutOctets;
	int nSumIn = 0;
	int nSumOut = 0;

	dwTime = GetTickCount();
	dwElapsedTime = dwTime - dwLastUpdateTime;
	dwLastUpdateTime = dwTime;

	if((ifIndex = GetDefRouteIfIndex()) != 0)
	{
		GetIfStats(ifIndex, &ifInOctets, &ifOutOctets);

		if(!fFirstUpdate)
		{
			nSamplesIn[iSample] = ((ifInOctets - ifInOctetsLast) * 1000) / dwElapsedTime;
			nSamplesOut[iSample] = ((ifOutOctets - ifOutOctetsLast) * 1000) / dwElapsedTime;
			iSample = (iSample + 1) % NUM_SAMPLES;

			for(int i = 0; i < NUM_SAMPLES; i++)
			{
				nSumIn += nSamplesIn[i];
				nSumOut += nSamplesOut[i];
			}

			nBytesPerSecIn = nSumIn / NUM_SAMPLES;
			nBytesPerSecOut = nSumOut / NUM_SAMPLES;
		}

		ifInOctetsLast = ifInOctets;
		ifOutOctetsLast = ifOutOctets;
		fFirstUpdate = FALSE;
	}
}

DWORD WINAPI
NetStats::ThreadProc(LPVOID pvThis)
{
	NetStats *pThis = (NetStats *) pvThis;

	while(TRUE)
	{
		Sleep(SAMPLE_INTERVAL);
		pThis->Update();
	}

	return 0;
}

int
NetStats::GetDefRouteIfIndex()
{
	if(!hinstInetMib)
		return 0;

	RFC1157VarBind varBind[2];
	RFC1157VarBindList varBindList = {varBind, 2};
	AsnInteger errStatus;
	AsnInteger errIndex;
	BYTE defAddr[] = {0, 0, 0, 0};
	int ifIndex = 0;

	UINT OID_ipRouteDest[] = {1, 3, 6, 1, 2, 1, 4, 21, 1, 1};
	AsnObjectIdentifier MIB_ipRouteDest = {sizeof(OID_ipRouteDest) / sizeof(UINT), OID_ipRouteDest};
	UINT OID_ipRouteIfIndex[] = {1, 3, 6, 1, 2, 1, 4, 21, 1, 2};
	AsnObjectIdentifier MIB_ipRouteIfIndex = {sizeof(OID_ipRouteIfIndex) / sizeof(UINT), OID_ipRouteIfIndex};

	SnmpUtilOidCpy(&varBind[0].name, &MIB_ipRouteDest);
	SnmpUtilOidCpy(&varBind[1].name, &MIB_ipRouteIfIndex);

	while((*pfnSnmpExtensionQuery)(ASN_RFC1157_GETNEXTREQUEST, &varBindList, &errStatus, &errIndex))
	{
		if(SnmpUtilOidNCmp(&varBind[0].name, &MIB_ipRouteDest, MIB_ipRouteDest.idLength) != 0)
		{
			break;
		}

		if(memcmp(defAddr, varBind[0].value.asnValue.address.stream, 4) == 0)
		{
			ifIndex = varBind[1].value.asnValue.number;
			break;
		}
	}

	SnmpUtilVarBindFree(&varBind[0]);
	SnmpUtilVarBindFree(&varBind[1]);

	return ifIndex;
}

int
NetStats::GetIfStats(int ifIndex, int *ifInOctetsPtr, int *ifOutOctetsPtr)
{
	if(!hinstInetMib)
		return 0;

	RFC1157VarBind varBind[3];
	RFC1157VarBindList varBindList = {varBind, 3};
	AsnInteger errStatus;
	AsnInteger errIndex;
	int ifInOctets = 0;
	int ifOutOctets = 0;
	
	UINT OID_ifIndex[] = {1, 3, 6, 1, 2, 1, 2, 2, 1, 1};
	AsnObjectIdentifier MIB_ifIndex = {sizeof(OID_ifIndex) / sizeof(UINT), OID_ifIndex};
	UINT OID_ifInOctets[] = {1, 3, 6, 1, 2, 1, 2, 2, 1, 10};
	AsnObjectIdentifier MIB_ifInOctets = {sizeof(OID_ifInOctets) / sizeof(UINT), OID_ifInOctets};
	UINT OID_ifOutOctets[] = {1, 3, 6, 1, 2, 1, 2, 2, 1, 16};
	AsnObjectIdentifier MIB_ifOutOctets = {sizeof(OID_ifOutOctets) / sizeof(UINT), OID_ifOutOctets};

	SnmpUtilOidCpy(&varBind[0].name, &MIB_ifIndex);
	SnmpUtilOidCpy(&varBind[1].name, &MIB_ifInOctets);
	SnmpUtilOidCpy(&varBind[2].name, &MIB_ifOutOctets);
	
	while((*pfnSnmpExtensionQuery)(ASN_RFC1157_GETNEXTREQUEST, &varBindList, &errStatus, &errIndex))
	{
		if(SnmpUtilOidNCmp(&varBind[0].name, &MIB_ifIndex, MIB_ifIndex.idLength) != 0)
		{
			break;
		}
		
		if(varBind[0].value.asnValue.number == ifIndex)
		{
			ifInOctets = varBind[1].value.asnValue.number;
			ifOutOctets = varBind[2].value.asnValue.number;
			break;
		}
	}
	
	SnmpUtilVarBindFree(&varBind[0]);
	SnmpUtilVarBindFree(&varBind[1]);
	SnmpUtilVarBindFree(&varBind[2]);
	
	if(ifInOctetsPtr) *ifInOctetsPtr = ifInOctets;
	if(ifOutOctetsPtr) *ifOutOctetsPtr = ifOutOctets;

	return 1;
}

int SNMP_FUNC_TYPE
SnmpUtilOidCpy(AsnObjectIdentifier *oidDest, AsnObjectIdentifier *oidSrc)
{
	oidDest->ids = (UINT *) GlobalAlloc(GMEM_ZEROINIT, oidSrc->idLength * sizeof(UINT));
	
	if(!oidDest->ids)
		return 0;
	
	memcpy(oidDest->ids, oidSrc->ids, oidSrc->idLength * sizeof(UINT));
	oidDest->idLength = oidSrc->idLength;
	return 1;
}

void SNMP_FUNC_TYPE
SnmpUtilOidFree(AsnObjectIdentifier *oid)
{
	GlobalFree(oid->ids);
	oid->ids = NULL;
	oid->idLength = 0;
}

int SNMP_FUNC_TYPE
SnmpUtilOidNCmp(AsnObjectIdentifier *oidA, AsnObjectIdentifier *oidB, UINT len)
{
	int diff;
	int i;
	
	if(oidA->idLength < len)
		len = oidA->idLength;
	
	if(oidB->idLength < len)
		len = oidB->idLength;
	
	for(i = 0; i < len; i++)
	{
		diff = oidA->ids[i] - oidB->ids[i];
		
		if(diff != 0)
			return diff;
	}
	
	return 0;
}

void SNMP_FUNC_TYPE
SnmpUtilVarBindFree(RFC1157VarBind *vb)
{
	SnmpUtilOidFree(&vb->name);
	
	switch(vb->value.asnType)
	{
	case ASN_OBJECTIDENTIFIER:
		SnmpUtilOidFree(&vb->value.asnValue.object);
		break;
	
	case ASN_OCTETSTRING:
	case ASN_RFC1155_IPADDRESS:
	case ASN_RFC1155_OPAQUE:
	case ASN_SEQUENCE:
		if(vb->value.asnValue.string.dynamic)
			GlobalFree(vb->value.asnValue.string.stream);
		
		break;
	}
	
	vb->value.asnType = ASN_NULL;
}
