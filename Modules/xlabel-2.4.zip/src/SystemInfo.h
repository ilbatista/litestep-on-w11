#if !defined(__SYSTEMINFO_H)
#define __SYSTEMINFO_H

class Label;
class NetStats;

class SystemInfo
{
public:

	SystemInfo();
	virtual ~SystemInfo();

	string processLabelText(const string &text, Label *label, bool *dynamic = 0);

private:

	bool usingCPU;

	string evaluateFunction(const string &functionName, const vector<string> &arguments, Label *label, bool *dynamic);
	string process(const string &text, int &i, int length, Label *label, bool *dynamic);

	// if/elseif/else/endif
	void doIf(const string& test);
	void doElseIf(const string& test);
	void doElse();
	void doEndIf();

	// date and time info
	string getDate(const vector<string> &arguments, bool *dynamic);
	string getInternetTime(bool *dynamic);
	string getTime(const vector<string> &arguments, bool *dynamic);
	string getUptime(const vector<string> &arguments, bool *dynamic);

	// memory and disk space info
	string getDiskAvailable(const vector<string> &arguments, bool *dynamic);
	string getDiskInUse(const vector<string> &arguments, bool *dynamic);
	string getDiskTotal(const vector<string> &arguments, bool *dynamic);
	string getMemAvailable(const vector<string> &arguments, bool *dynamic);
	string getMemInUse(const vector<string> &arguments, bool *dynamic);
	string getMemTotal(const vector<string> &arguments, bool *dynamic);
	string getSwapAvailable(const vector<string> &arguments, bool *dynamic);
	string getSwapInUse(const vector<string> &arguments, bool *dynamic);
	string getSwapTotal(const vector<string> &arguments, bool *dynamic);

	// power info
	string getPowerSource(const vector<string> &arguments, bool *dynamic);
	string getBattery(bool *dynamic);

	// network-related info
	string getComputerName(bool *dynamic);
	string getConnected(bool *dynamic);
	string getHostName(bool *dynamic);
	string getIP(const vector<string> &arguments, bool *dynamic);
	string getNetIn(const vector<string> &arguments, bool *dynamic);
	string getNetOut(const vector<string> &arguments, bool *dynamic);
	string getUserName(bool *dynamic);

	// Winamp info
	string getWinampSong(bool *dynamic);
	string getWinampTime(bool *dynamic);
	string getWinampRemainTime(bool *dynamic);
	string getWinampTotalTime(bool *dynamic);
	string getWinampStatus(bool *dynamic);
	string getWinampPlaying(bool *dynamic);

	// MotherBoard Monitor 5 (MBM5) info
	string getMBMData(const char, const vector<string> &arguments, bool *dynamic, bool &bUseFahrenheit);;
	string getMBMLoaded(bool *dynamic);
	
	// file info
	string getDateCreated(const vector<string> &arguments, bool *dynamic);
	string getDateLastModified(const vector<string> &arguments, bool *dynamic);
	string getFileExists(const string &file, bool *dynamic);
	string getFirstLine(const string &file, bool *dynamic);
	string getLastLine(const string &file, bool *dynamic);
	string getLine(const vector<string> &arguments, bool *dynamic);
	string getLineCount(const string &file, bool *dynamic);
	string getRandomLine(const string &file, bool *dynamic);
	string getSize(const vector<string> &arguments, bool *dynamic);

	// miscellaneous info
	string getActiveTask(bool *dynamic);
	string getCPU(bool *dynamic);
	string getLSVar(const string &name, bool *dynamic);
	string getOS(bool *dynamic);
	string getWindowTitle(const string &windowClass, bool *dynamic);

	// formatting functions
	string capitalize(const string &s);
	string lowerCase(const string &s);
	string after(const string &s, const string &search);
	string afterLast(const string &s, const string &search);
	string before(const string &s, const string &search);
	string beforeLast(const string &s, const string &search);
	string between(const string &s, const string &left, const string &right);
	string trim(const string &s);
	string upperCase(const string &s);

	// miscellaneous functions
	string hideIfEmpty(const string &s, Label *label, bool *dynamic);
	string empty(const string &s, bool *dynamic);
	string notEmpty(const string &s, bool *dynamic);

	void getDiskFreeSpace(const string &drive, largeInt &freeBytes, largeInt &totalBytes);

	string formatByteSize(largeInt byteSize, largeInt total, int units);
	string formatDateTime(const string &format, const SYSTEMTIME &st, int span);
	void getLocalizedTime(SYSTEMTIME *pst, const string &timezone);

	char *getLocaleInfo(LCTYPE type);

private:
	string getKeyboardLayoutShortName(bool *dynamic);
	string getKeyboardLayoutName(bool *dynamic);

	vector<bool> condStack;
	vector<int> depthStack;
	vector<bool> maskStack;

	char *am;
	char *pm;

	char *shortWeekdays[7];
	char *weekdays[7];
	char *shortMonths[12];
	char *months[12];

	NetStats *netStats;
};

extern SystemInfo *systemInfo;
#endif
