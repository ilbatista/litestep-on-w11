!ModulePos !movecmd 

for example: 
!ModulePos !vwmmove 

Move the mouse around, click. It will give you coords from 
upper left, lower right, center, and the closest percent 
above/below with offset. 

It could be nicer, but I whipped it up really quick a 
while ago, and I think there was some fundamental problem 
with it or something. I forget.
--
rabidcow
'released' on the lokai.org forums 2002.11.04

[this package created by rootrider - ShellFront.org]