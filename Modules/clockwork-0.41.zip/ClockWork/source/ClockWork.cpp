/****************************************************************************

ClockWork 0.41
by Vendicator (http://pimpin.info/vendicator | vendicator@mail.com)

Analog clock module which should work on desktop/lsbox or in wharf.
Made since I couldn't find a working desktop analog clock module.

Used window&bitmap handling from systray2, clock drawing from aLsClock.
Code is split into several files due to the OOP layout and me wanting
to have modular code snippets.
Note that windows.cpp/.h are the lswinbase from ls (just wanted to have
them included if I wanted to base something else on this)

Note:
You need to use ClockWorkHandType "box" or other transparent compatible
hand type inorder for ClockWork to be visible with completely transparent
backgrounds.


Step.rc Settings:

Size & Placement:
	ClockWorkX
	Int, default: 0
	X placement of the clock window

	ClockWorkY
	Int, default: 0
	Y placement of the clock window

	ClockWorkWidth
	Int, default: 64 (alt. bitmap size)
	Sets width of the clock window

	ClockWorkHeight
	Int, default: 64 (alt. bitmap size)
	Sets height of the clock window


Window & bitmaps:
	ClockWorkHidden
	Bool, default: false
	Set whether to start ClockWork in hidden state

	ClockWorkAlwaysOnTop
	Bool, default: false
	Set whether ClockWork should be placed above all other windows

	ClockWorkBitmap
	String, default: none
	Location of the image to use as bg for ClockWork
	(use a transparent compatible hand when using a completely transparent bg)

	ClockWorkBitmapTiled
	Bool, default: false
	Set whether to tile if on otherwise stretch the image if window size is different from bitmap size

	ClockWorkBorderSize
	Int, default: 0
	Set width of border which isn't stretched/tiled

	ClockWorkBorderTop
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of top border

	ClockWorkBorderLeft
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of left border

	ClockWorkBorderRight
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of right border

	ClockWorkBorderBottom
	Int, defaults to whatever ClockWorkBorderSize is set to
	Individual setting of bottom border

	ClockWorkBorderDrag
	Bool, default: false (not activated)
	If specified the user is able to reposition the clock using the mouse

	ClockWorkBGColor
	Color, default: FFFFFF
	Background color to use instead of bitmap
	(use a transparent compatible hand when using a completely transparent bg)

	ClockWorkBorderColor
	Color, default: 000000
	Color of border

	ClockWorkDoNotAlignUsingBorders
	Bool, default: false
	When this is set to false (default) clockwork will use the borders to find
	the size & center of the clock (not specifying clock hand length will also
	cause the hands to be shorter).
	When this is set to true, the center will be calculated using the specified
	size of the clockwork window.


Clock hands:
	ClockWorkHandType "box" / "line" / "triangle"
	string, default "line"
	Determines the clock hand type that should be used.
	"line" is the standard version, using LineTo()
	(*) "box" similar to line, but drawn using polygons
	(*) "triangle" also drawn using polygons, wide base to pointy end
	* = polygon based and therefore transparent compatible,
	use this if combined with a completely transparent region
	to allow the window region to be adapted to include the hands.
	Rounding errors might make the width of these modes look inaccurate at times.

	ClockWorkNoSeconds
	BOOL, default: false
	Disable display of the seconds hand

	ClockWorkResolution
	Int, default: 60
	Defines into how many steps the clock is divided (for smoother clocksteps increase this).
	Note that this increases mem usage (8b * Resolution) as well as cpu
	(since you need to update the window more often to see the effect)

	ClockWorkRefresh
	Int, default: 60000 / ClockWorkResolution
	Sets how often the clock should be refreshed, time given in milliseconds.
	With the default ClockWorkResolution=60, the refresh would be once every second.
	Just specifying a different resolution will adapt the refresh to optimum, but
	you have the ability to override the refresh setting if you feel like it.

	ClockWorkDrawOrder ? ? ?
	3 chars, default: h m s
	Determines in what order the hands should be drawn, h=hour, m=minute, s=second
	The hands are drawn above eachother so the last will be on top of the other two.

	ClockWorkHourColor
	Color, default: 0000FF
	Sets color of the hours hand

	ClockWorkMinuteColor
	Color, default: 00FF00
	Sets color of the minutes hand

	ClockWorkSecondColor
	Color, default: FF0000
	Sets color of the seconds hand

	ClockWorkHourInnerColor
	Color, default: what ClockWorkHourColor is set to
	Sets the internal color of the hours hand in polygon hand types (ie. box),
	the normal color is then used as a 1pixel wide border around the hand shape

	ClockWorkMinuteInnerColor
	Color, default: what ClockWorkMinuteColor is set to
	Sets the internal color of the minutes hand in polygon hand types (ie. box),
	the normal color is then used as a 1pixel wide border around the hand shape

	ClockWorkSecondInnerColor
	Color, default: what ClockWorkSecondColor is set to
	Sets the internal color of the seconds hand in polygon hand types (ie. box),
	the normal color is then used as a 1pixel wide border around the hand shape

	ClockWorkHourWeight
	Int, default: 3
	Sets the width of the hours hand
	  
	ClockWorkMinuteWeight
	Int, default: 2
	Sets the width of the mintes hand

	ClockWorkSecondWeight
	Int, default: 1
	Sets the width of the seconds hand

	ClockWorkHourLength
	Int, default: 70% of the smallest of the window width/height
	Length of the hours hand

	ClockWorkMinuteLength
	Int, default: 90% of the smallest of the window width/height
	Length of the minutes hand

	ClockWorkSecondLength
	Int, default: 90% of the smallest of the window width/height
	Length of the seconds hand


Mouse commands:
	ClockWorkOnLeftDBL
	String, default: !none
	Command to be executed when the user left double clicks the clock

	ClockWorkOnLeftDown
	String, default: !none
	Command to be executed when the user presses the left button on clock

	ClockWorkOnLeftUp
	String, default: !none
	Command to be executed when the user releases the left button on clock

	ClockWorkOnRightDBL
	String, default: !none
	Command to be executed when the user right double clicks the clock

	ClockWorkOnRightDown
	String, default: !none
	Command to be executed when the user presses the right button on clock

	ClockWorkOnRightUp
	String, default: !none
	Command to be executed when the user releases the right button on clock

	ClockWorkOnMiddleDBL
	String, default: !none
	Command to be executed when the user middle double clicks the clock

	ClockWorkOnMiddleDown
	String, default: !none
	Command to be executed when the user presses the middle button on clock

	ClockWorkOnMiddleUp
	String, default: !none
	Command to be executed when the user releases the middle button on clock



Bangs:
	!ClockWorkSetTime
	Brings up the date/time settings from the control panel

	!ClockWorkHook
	Hooks ClockWork to lsbox

	!ClockWorkSetOnTop on/off
	Sets ClockWorks window to be ontop or not, if no argument specified it's turned on.

	!ClockWorkToggleOnTop
	Toggles the on top status

	!ClockWorkShow
	Shows ClockWorks window if hidden

	!ClockWorkHide
	Hides ClockWorks window

	!ClockWorkToggle
	Toggles visible/hidden status of ClockWork

	!ClockWorkMove x y
	Move ClockWork to the given position

	!ClockWorkSize
	Change the size of ClockWork


Changelog:
	Fixed [Vendicator, 2002-11-13]
	  - Switched color variables so that InnerColor actually sets the right one =)
	  - Renamed readme file to ClockWork.txt (yay!)

	Added [Vendicator, 2002-11-13]
	  - Changed default behaviour to use borders when calculating center
	  - ClockWorkDoNotAlignUsingBorders to specify center alignment
	    without taking borders into consideration
	  - Added ClockWorkSecondInnerColor, ClockWorkMinuteInnerColor, ClockWorkHourInnerColor
	    to be able to specify an inner color for polygon based clock hand types
	  - Added new clock hand type: triangle

	Added [Vendicator, 2002-11-12]
	  - Start of support for different inner & outer colors for polygon hands

	Added [Vendicator, 2002-11-12]
	  - Fixed color being painted even tho a bitmap was used
	  - Changed default bgcolor to FFFFFF
	  - Changed the clockface structure to use hand object so different hands
	    can be made and selected.
	  - Added ClockWorkHandType to select which hand type to use
	  - Added clock hand type "box", which is completely transparent compatible

	Added [Vendicator, 2002-11-10]
	  - Ability to specify paint order with ClockWorkDrawOrder x x x

	Added [Vendicator, 2002-11-09]
	  - Initial Release


Todo:
	- overlay for hour markers..
	- percent hand length for stretched clock look
	- More different types of hands? Antialiased lines?
	- Text support? for am,pm/date/time?

****************************************************************************/

#include <math.h>
#include "ClockWork.h"
#include "Clickable.h"
#include "WinUtils.h"
#include "LSUtils.h"
#include "TrigBuffer.h"

// prefix for all settings to be read
const char SettingsPrefix[] = "ClockWork";

// messages that we want to listen to
const int LSMsgs[] = {LM_GETREVID, LM_REFRESH, 0};

const char szAppName[] = "ClockWork"; // Our window class, etc
const char rcsRevision[] = "$Revision: 0.41 $"; // Our Version
const char rcsId[] = "$Id: ClockWork.cpp,v 0.41 19:46:35 Vendicator Exp $"; // The Full RCS ID.
ClockWork *clockwork; // The module

//#define DEBUG

// bang entry
struct Bang
{
	const char *bangName;
	void (*bangFunc) (HWND, LPCSTR);
};

// register these bangs
const Bang BangList[] =
{
	{"!ClockWorkSetTime", &BangSetTime},
	{"!ClockWorkHook", &BangHook},
	{"!ClockWorkSetOnTop", &BangSetOnTop},
	{"!ClockWorkToggleOnTop", &BangToggleOnTop},
	{"!ClockWorkShow", &BangShow},
	{"!ClockWorkHide", &BangHide},
	{"!ClockWorkToggle", &BangToggle},
	{"!ClockWorkMove", &BangMove},
	{"!ClockWorkSize", &BangSize},
};

// calculate how many bangs there are
const int NrOfBangs = sizeof(BangList) / sizeof(BangList[0]);


//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	clockwork = new ClockWork(GetLitestepWnd(), code, false);
	return code;
}

int initWharfModule(HWND parentWnd, HINSTANCE dllInst, void *wharfData)
{
	int code;
	Window::init(dllInst);
	clockwork = new ClockWork(parentWnd, code, true);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete clockwork;
}

void quitWharfModule(HINSTANCE dllInst)
{
	delete clockwork;
}


//=========================================================
// Bang commands
//=========================================================

void BangSetTime(HWND caller, LPCTSTR szArgs)
{
	// from Popup2, originally from aLsClock
	char WinDir[256];
	GetSystemDirectory(WinDir, 256);
	ShellExecute(clockwork->GetHWND(), "open", "rundll32.exe",
		"shell32.dll,Control_RunDLL timedate.cpl",
		WinDir, SW_SHOWNORMAL);
}

void BangHook(HWND caller, LPCTSTR szArgs)
{
	clockwork->BoxHook(szArgs);
}

void BangSetOnTop(HWND caller, LPCSTR args)
{
	if (stricmp(args, "off") == 0)
		clockwork->SetOnTop(false);
	else
		clockwork->SetOnTop(true);
}

void BangToggleOnTop(HWND caller, LPCSTR args)
{
	clockwork->ToggleOnTop();
}

void BangShow(HWND caller, LPCSTR args)
{
	clockwork->Show();
}

void BangHide(HWND caller, LPCSTR args)
{
	clockwork->Hide();
}

void BangToggle(HWND caller, LPCSTR args)
{
	clockwork->ToggleVisibility();
}

void BangMove(HWND caller, LPCSTR args)
{
	char szX[MAX_LINE_LENGTH], szY[MAX_LINE_LENGTH];
	char *tokens[2] = {szX, szY};
	LCTokenize( args, tokens, 2, NULL );
	clockwork->Move(atoi(szX), atoi(szY));
}

void BangSize(HWND caller, LPCSTR args)
{
	char szCX[MAX_LINE_LENGTH], szCY[MAX_LINE_LENGTH];
	char *tokens[2] = {szCX, szCY};
	LCTokenize( args, tokens, 2, NULL );
	clockwork->Size(atoi(szCX), atoi(szCY));
}


//=========================================================
// Module code
//=========================================================

void ClockWork::CreateBackground()
{
	HDC hdcScreen, hdcDst;
	HBITMAP hbmDstOld;

	// delete old objects if necessary...
	if ( hbmBack )
		DeleteObject( hbmBack );
	hbmBack = NULL;

	if ( hrgnBack )
		DeleteObject( hrgnBack );
	hrgnBack = NULL;

	// initiate a new destination dc
	hdcScreen = GetDC(hWnd);

	hdcDst = CreateCompatibleDC(hdcScreen);
	hbmBack = CreateCompatibleBitmap(hdcScreen, GetWidth(), GetHeight());
	hbmDstOld = (HBITMAP)SelectObject(hdcDst, hbmBack);

	ReleaseDC(hWnd, hdcScreen);

	// if the background colors are needed put them on...
	if ((!hbmSkin) ) // || bTranspSkin
	{
		RECT r;
		HBRUSH brush;

		// fill the border with the border colors
		if (borderTop || borderLeft || borderBottom || borderTop)
		{
			brush = CreateSolidBrush(clrBorder);

			if (borderTop)
			{
				SetRect(&r, 0, 0, GetWidth(), borderTop);
				FillRect(hdcDst, &r, brush);
			}
			if (borderLeft)
			{
				SetRect(&r, 0, borderTop, borderLeft, GetHeight() - borderBottom);
				FillRect(hdcDst, &r, brush);
			}
			if (borderRight)
			{
				SetRect(&r, GetWidth() - borderRight, borderTop, GetWidth(), GetHeight() - borderBottom);
				FillRect(hdcDst, &r, brush);
			}
			if (borderBottom)
			{
				SetRect(&r, 0, GetHeight() - borderBottom, GetWidth(), GetHeight());
				FillRect(hdcDst, &r, brush);
			}
			DeleteObject(brush);
		}

		// now fill the inner rectangle (excluding the borders) with the background color
		brush = CreateSolidBrush(clrBack);

		SetRect(&r, borderLeft, borderTop, GetWidth() - borderRight, GetHeight() - borderBottom);
		FillRect(hdcDst, &r, brush);

		DeleteObject(brush);
	}

	// if a background image is provided, put it on...
	if (hbmSkin)
	{

		HDC hdcSrc;
		HBITMAP hbmSrcOld;
		BITMAP bm;
		int innerWidth, innerHeight, bmInnerWidth, bmInnerHeight;

		// get info from the bitmap
		GetObject(hbmSkin, sizeof(BITMAP), &bm);

		// this is to prevent negative values on the width
		innerWidth = max(GetWidth() - (borderLeft + borderRight), 0);
		innerHeight = max(GetHeight() - (borderTop + borderBottom), 0);
		bmInnerWidth = max(bm.bmWidth - (borderLeft + borderRight), 1);
		bmInnerHeight = max(bm.bmHeight - (borderTop + borderBottom), 1);

		hdcSrc = CreateCompatibleDC(hdcDst);
		hbmSrcOld = (HBITMAP)SelectObject(hdcSrc, hbmSkin);

		if (borderTop || borderLeft || borderBottom || borderTop)
		{

			// paint the four corners first, and then the borders
			// topleft, topright, bottomright, bottomleft
			CopyBlt(hdcDst, 0, 0, borderLeft, borderTop, hdcSrc, 0, 0);
			CopyBlt(hdcDst, GetWidth() - borderRight, 0, borderRight, borderTop, hdcSrc, bm.bmWidth - borderRight, 0);
			CopyBlt(hdcDst, GetWidth() - borderRight, GetHeight() - borderBottom, borderRight, borderBottom, hdcSrc, bm.bmWidth - borderRight, bm.bmHeight - borderBottom);
			CopyBlt(hdcDst, 0, GetHeight() - borderBottom, borderLeft, borderBottom, hdcSrc, 0, bm.bmHeight - borderBottom);

			if (borderTop && innerWidth)
				SizeBlt(hdcDst, borderLeft, 0, innerWidth, borderTop, hdcSrc, borderLeft, 0, bmInnerWidth, borderTop);
			if (borderLeft && innerHeight)
				SizeBlt(hdcDst, 0, borderTop, borderLeft, innerHeight, hdcSrc, 0, borderTop, borderLeft, bmInnerHeight);
			if (borderRight && innerHeight)
				SizeBlt(hdcDst, GetWidth() - borderRight, borderTop, borderRight, innerHeight, hdcSrc, bm.bmWidth - borderRight, borderTop, borderRight, bmInnerHeight);
			if (borderBottom && innerWidth)
				SizeBlt(hdcDst, borderLeft, GetHeight() - borderBottom, innerWidth, borderBottom, hdcSrc, borderLeft, bm.bmHeight - borderBottom, bmInnerWidth, borderBottom);
		}

		// draw area in the middle
		if (innerWidth && innerHeight)
			SizeBlt(hdcDst, borderLeft, borderTop, innerWidth, innerHeight, hdcSrc, borderLeft, borderTop, bmInnerWidth, bmInnerHeight);

		SelectObject( hdcSrc, hbmSrcOld );
		DeleteDC( hdcSrc );
	}

	SelectObject( hdcDst, hbmDstOld );
	DeleteDC( hdcDst );

	if (!bTranspSkin)
	{
		// if the bitmap skin wasn't transparent the bg functions shouldn't bother
		bTranspBack = FALSE;
	}
	else
	{
		HRGN hOpaqueRgn = CreateRectRgn(0, 0, GetWidth(), GetHeight());
		// FIX: region color
		hrgnBack = BitmapToRegion(hbmBack, RGB(255, 0, 255), 0x101010, 0, 0);

		// to see if any pixels are transparent
		bTranspBack = !EqualRgn(hrgnBack, hOpaqueRgn);
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "TranspBack: %d, checked w:%d, h:%d", bTranspBack, GetWidth(), GetHeight());
#endif

		DeleteObject(hOpaqueRgn);

		if (!bTranspBack)
		{
			DeleteObject(hrgnBack);
			hrgnBack = NULL;
		}
	}
}

void ClockWork::PaintBackground( HDC hdcDst, HRGN hrgnDst )
{
	HDC hdcSrc;
	HBITMAP hbmOld;

	// if the background isn't there, make one...
	if (!hbmBack)
	{
		CreateBackground();
	}
	else
	{
		BITMAP bm;
		GetObject(hbmBack, sizeof(BITMAP), &bm);
		if (bm.bmWidth != GetWidth() || bm.bmHeight != GetHeight())
		{
			CreateBackground();
		}
	}

	// if there is no background now... do nothing
	if (!hbmBack)
		return ;

	hdcSrc = CreateCompatibleDC(hdcDst);
	hbmOld = (HBITMAP)SelectObject(hdcSrc, hbmBack);

	BitBlt(hdcDst, 0, 0, GetWidth(), GetHeight(), hdcSrc, 0, 0, SRCCOPY);

	SelectObject(hdcSrc, hbmOld);
	DeleteDC(hdcSrc);

	if ( hrgnBack && bTranspBack )
		CombineRgn(hrgnDst, hrgnBack, NULL, RGN_COPY);

}

// grd Blitting functions...
// to enable transp / not transp painting
// and to enable tile / stretch resizing
int ClockWork::CopyBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc)
{
	if (bTranspSkin)
		TransparentBltLS(hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, RGB(255, 0, 255));
	else
		return BitBlt(hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, SRCCOPY);

	return 0;
}

int ClockWork::SizeBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc)
{
	HDC	hdcTmp;
	HBITMAP hbmTmp, hbmOld;
	int tmpX, tmpY;

	if (bTranspSkin)
	{
		hdcTmp = CreateCompatibleDC( hdcDst );
		hbmTmp = CreateCompatibleBitmap( hdcDst, cxDst, cyDst );
		hbmOld = (HBITMAP)SelectObject( hdcTmp, hbmTmp );
		tmpX = 0, tmpY = 0;
	}
	else
	{
		hdcTmp = hdcDst;
		tmpX = xDst, tmpY = yDst;
	}

	if (bSkinTiled)
	{
		int x, y;
		// fill the first row of images
		for (x = 0; x < cxDst; x += cxSrc)
			BitBlt(hdcTmp, tmpX + x, tmpY, min(cxSrc, cxDst - x), min(cySrc, cyDst), hdcSrc, xSrc, ySrc, SRCCOPY);
		// copy this row down the y axis...
		for (y = cySrc; y < cyDst; y += cySrc)
			BitBlt(hdcTmp, tmpX, tmpY + y, cxDst, min(cySrc, cyDst - y), hdcTmp, tmpX, tmpY, SRCCOPY);

	}
	else
	{
		// stretch it
		StretchBlt(hdcTmp, tmpX, tmpY, cxDst, cyDst, hdcSrc, xSrc, ySrc, cxSrc, cySrc, SRCCOPY);
	}

	// blit the resulting image onto the destination dc
	if (bTranspSkin)
	{
		TransparentBltLS(hdcDst, xDst, yDst, cxDst, cyDst, hdcTmp, tmpX, tmpY, RGB(255, 0, 255));

		// cleanup
		SelectObject( hdcTmp, hbmOld );
		DeleteObject( hbmTmp );
		DeleteDC( hdcTmp );
	}
	return 0;
}

HWND ClockWork::GetHWND()
{
	return GuiWindow::GetHWND();
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------

ClockWork::ClockWork(HWND parentWnd, int& code, bool Wharfed) :
	GuiWindow(szAppName, parentWnd, Wharfed),
	Clickable(SettingsPrefix),
	hrgnBack(NULL),
	hbmBack(NULL),
	bTranspBack(FALSE),
	clock(SettingsPrefix)
{

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_WARNING, szAppName, "*Debug* Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#else
	LSLogPrintf(LOG_DEBUG, szAppName, "Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#endif

	// get desktop & ls window handle
	HWND desktop = WinUtils::GetDesktopHWND();
	HWND litestep = GetLitestepWnd();

	if (!litestep) {
		LSLog(LOG_ERROR, szAppName, "Could not find litestep window, aborting");
		code = 2;
		return;
	}

	// First read gui props to get a bitmap to use for size when no size specified
	ReadGUIProps();
	ReadSizeAndPos();
	ReadClickSettings();

	if (bDoNotAlignUsingBorders)
		clock.CalcCenter(GetWidth(), GetHeight());
	else
		clock.CalcCenter(GetWidth()-(borderLeft+borderRight), GetHeight()-(borderTop+borderBottom));

	clock.ReadClockSettings();
	
	// FIXME: this logging stuff might need an update
	LSLogPrintf(LOG_DEBUG, szAppName, "Creating Window, pos:%d,%d size:%d,%d, p:%d, l:%d, d:%d", GetX(), GetY(), GetWidth(), GetHeight(), GetParentHWND(), litestep, desktop);
	
	if (!createWindow(WS_EX_TOOLWINDOW, szAppName, IsInWharf() ? WS_CHILD : WS_POPUP,
		GetX(), GetY(), GetWidth(), GetHeight(), IsInWharf() ? GetParentHWND() : desktop))
	{
		LSLog(LOG_ERROR, szAppName, "Unable to create window");
		MessageBox(NULL, "Unable to create window", szAppName, MB_TOPMOST);
		code = 1;
		return ;
	}
	else
	{
		LSLogPrintf(LOG_DEBUG, szAppName, "Window created, 0x%X", GetHWND());
	}
	
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)LSMsgs);
	
	if ( !IsInWharf() )
	{
		LSLogPrintf(LOG_DEBUG, szAppName, "Entering %d bang commands", NrOfBangs);
		for (int i = 0; i < NrOfBangs; i++)
			AddBangCommand(BangList[i].bangName, *BangList[i].bangFunc);
	}

	// Set a timer for clock
	SetTimer(GetHWND(), 0, clock.GetRefresh(), NULL);

	code = 0;
}

// get the position and size of the main window
// using different method if it's docked in the wharf
void ClockWork::ReadSizeAndPos()
{
	if ( IsInWharf() )
	{
		LSLog(LOG_DEBUG, szAppName, "Loaded in Wharf, reading Wharf settings");
		RECT rc;
		int wharfBorder;

		// get the wharf window size
		GetClientRect( GetParentHWND(), &rc );
		wharfBorder = GetRCInt( "WharfBevelWidth", 0 );

#ifdef DEBUG_EXTRA
		LSLogPrintf(LOG_DEBUG, szAppName, "wharf: p: %d,%d, s:%d,%d", rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top);
#endif

		SetPosition(wharfBorder, wharfBorder);
		SetSize(rc.right - 2 * wharfBorder, rc.bottom - 2 * wharfBorder);

		LSLog(LOG_DEBUG, szAppName, "Done reading wharf settings");
	}
	else
	{
		int defaultX = 64, defaultY = 64;
		if (hbmSkin)
		{
			BITMAP bm;
			GetObject( hbmSkin, sizeof(BITMAP), &bm );
			defaultX = bm.bmWidth;
			defaultY = bm.bmHeight;
		}

		LSLog(LOG_DEBUG, szAppName, "not in wharf, reading size settings");

		SetPosition(LSUtils::PrefixedGetRCCoordinate(SettingsPrefix, "X", 0, GetSystemMetrics(SM_CXSCREEN)), LSUtils::PrefixedGetRCCoordinate(SettingsPrefix, "Y", 0, GetSystemMetrics(SM_CYSCREEN)));
		SetSize(LSUtils::PrefixedGetRCInt(SettingsPrefix, "Width", defaultX), LSUtils::PrefixedGetRCInt(SettingsPrefix, "Height", defaultY));

		LSLog(LOG_DEBUG, szAppName, "Done reading size settings");
	}
}

void ClockWork::ReadGUIProps()
{
	char szTemp[256];
	int tmpInteger = 0;

	// load settings here
	// ===========================================
	BOOL hidden = LSUtils::PrefixedGetRCBool(SettingsPrefix, "Hidden", TRUE);
	SetVisible(IsInWharf() || !hidden);

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "Hidden: %d, Visible: %d", hidden, visible);
#endif

	SetTop(!IsInWharf() && LSUtils::PrefixedGetRCBool(SettingsPrefix, "AlwaysOnTop", TRUE));
	tmpInteger = LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderSize", 0);
	borderTop = max(LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderTop", tmpInteger), 0);
	borderLeft = max(LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderLeft", tmpInteger), 0);
	borderRight = max(LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderRight", tmpInteger), 0);
	borderBottom = max(LSUtils::PrefixedGetRCInt(SettingsPrefix, "BorderBottom", tmpInteger), 0);
	borderDrag = !IsInWharf() && LSUtils::PrefixedGetRCBool(SettingsPrefix, "BorderDrag", TRUE);
	bDoNotAlignUsingBorders = LSUtils::PrefixedGetRCBool(SettingsPrefix, "DoNotAlignUsingBorders", TRUE);

	// colors
	clrBack = LSUtils::PrefixedGetRCColor(SettingsPrefix, "BGColor", RGB(255, 255, 255));
	clrBorder = LSUtils::PrefixedGetRCColor(SettingsPrefix, "BorderColor", RGB(0, 0, 0));

	// skinning
	LSUtils::PrefixedGetRCString(SettingsPrefix, "Bitmap", szTemp, "" , 256);
	bSkinTiled = LSUtils::PrefixedGetRCBool(SettingsPrefix, "BitmapTiled", TRUE);

	// if only using colors:
	if ( szTemp[0] == '\0' )
	{
		hbmSkin = NULL;
		bTranspSkin = (clrBack == RGB(255, 0, 255));
		if (!bTranspSkin)
			bTranspSkin = (borderTop + borderLeft + borderRight + borderBottom > 0) && (clrBorder == RGB(255, 0, 255));
	}
	// check bitmaps
	else
	{
		BITMAP bm;
		HRGN hBitmapRgn, hOpaqueRgn;

		hbmSkin = LoadLSImage(szTemp, NULL);

		// get info from the bitmap
		GetObject( hbmSkin, sizeof(BITMAP), &bm );

		hBitmapRgn = BitmapToRegion( hbmSkin, RGB(255, 0, 255), 0x101010, 0, 0);
		hOpaqueRgn = CreateRectRgn( 0, 0, bm.bmWidth, bm.bmHeight );

		// to see if any pixels are transparent
		bTranspSkin = !EqualRgn( hBitmapRgn, hOpaqueRgn );
		LSLogPrintf(LOG_DEBUG, szAppName, "TranspSkin: %d", bTranspSkin);

		DeleteObject( hBitmapRgn );
		DeleteObject( hOpaqueRgn );
	}

}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
ClockWork::~ClockWork()
{
	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)LSMsgs);

	if ( !IsInWharf() )
	{
		for (int i = 0; i < NrOfBangs; i++)
			RemoveBangCommand(BangList[i].bangName);
	}

	KillTimer(GetHWND(), 0);

	destroyWindow();
}


//=========================================================
// Registered messages
//=========================================================

void ClockWork::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onEndSession,       WM_ENDSESSION)
		MESSAGE(onEndSession,       WM_QUERYENDSESSION)
		MESSAGE(onCreate,			WM_CREATE)
		MESSAGE(onDestroy,			WM_DESTROY)
		MESSAGE(onGetRevId,         LM_GETREVID)
		MESSAGE(onSysCommand,       WM_SYSCOMMAND)
		MESSAGE(onPaint,			WM_PAINT)
		MESSAGE(onTimer,			WM_TIMER)
		MESSAGE(onMouse,			WM_LBUTTONDBLCLK)
		MESSAGE(onMouse,			WM_LBUTTONDOWN)
		MESSAGE(onMouse,			WM_LBUTTONUP)
		MESSAGE(onMouse,			WM_RBUTTONDBLCLK)
		MESSAGE(onMouse,			WM_RBUTTONDOWN)
		MESSAGE(onMouse,			WM_RBUTTONUP)
		MESSAGE(onMouse,			WM_MBUTTONDBLCLK)
		MESSAGE(onMouse,			WM_MBUTTONDOWN)
		MESSAGE(onMouse,			WM_MBUTTONUP)
	END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================

void ClockWork::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void ClockWork::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
	case 0:
		sprintf(buf, "ClockWork.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
	case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
	default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}

void ClockWork::onCreate(Message& message)
{
	LSLog(LOG_DEBUG, szAppName, "Setting ClockWork Window Props.");
	
	// make sure it handle dblclicks... =)
	SetClassLong(hWnd, GCL_STYLE, CS_DBLCLKS | GetClassLong(hWnd, GCL_STYLE));

	CreateBackground();

	// set always on top
	if (IsOnTop())
		SetOnTop(true);
	else
		SetOnTop(false);

	// show window
	ShowWindow( hWnd, IsVisible() ? SW_HIDE : SW_SHOWNOACTIVATE );
	InvalidateRect( hWnd, NULL, TRUE );

}

void ClockWork::onDestroy(Message& message)
{
	// delete gdi objects...
	if (hbmSkin)
		DeleteObject( hbmSkin );
	if (hbmBack)
		DeleteObject( hbmBack );
	if (hrgnBack)
		DeleteObject( hrgnBack );
}

void ClockWork::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void ClockWork::onPaint(Message& message)
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "onPaint received");
#endif

	HDC hdcBuffer;
	HBITMAP hbmBuffer, hbmBufOld;
	HRGN hrgn = NULL;

	PAINTSTRUCT ps;
	HDC	hdcScreen = BeginPaint(hWnd, &ps);

	hdcBuffer = CreateCompatibleDC(hdcScreen);
	hbmBuffer = CreateCompatibleBitmap(hdcScreen, GetWidth(), GetHeight());
	hbmBufOld = (HBITMAP)SelectObject(hdcBuffer, hbmBuffer);

	if (bTranspBack)
		hrgn = CreateRectRgn( 0, 0, 0, 0 );

	// blit the skin
	PaintBackground(hdcBuffer, hrgn);

	// draw clock on the buffer here...
	clock.DrawClock(hdcBuffer, hrgn);

	// set the windowRgn
	if (bTranspBack)
	{
		// FIX: create region from clock lines or from the painted dc, but how?
		// hrgn = BitmapToRegion( hbmBuffer, RGB(255, 0, 255), 0x101010, 0, 0);
		SetWindowRgn(hWnd, hrgn, TRUE);
	}

	// when the region is applied you can use a simple SRCCOPY from the buffer
	BitBlt(hdcScreen, 0, 0, GetWidth(), GetHeight(), hdcBuffer, 0, 0, SRCCOPY);

	// reselect the oldBitmap and kill the new one
	SelectObject(hdcBuffer, hbmBufOld);
	DeleteObject(hbmBuffer);

	// remove the memory DC
	DeleteDC(hdcBuffer);

	EndPaint(hWnd, &ps);
}

void ClockWork::onTimer(Message& message)
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "onTimer received");
#endif

	InvalidateRect(GetHWND(), NULL, TRUE);
}

void ClockWork::onMouse(Message& message)
{
	BangExecute(message.uMsg);
}
