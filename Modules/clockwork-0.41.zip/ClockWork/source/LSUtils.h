#ifndef __LSUTILS_H
#define __LSUTILS_H

#include <windows.h>

class LSUtils
{
public:
	static HINSTANCE LoggedBangExecute(LPCSTR szAppName, HWND Owner, LPCSTR szCommand, int nShowCmd);

	// to default to maxline length...
	static BOOL PrefixedGetRCLine(LPCSTR prefix, LPCSTR setting, LPSTR buffer, char *defaultVal);
	static BOOL PrefixedGetRCLine(LPCSTR prefix, LPCSTR setting, LPSTR buffer, UINT maxLen, char *defaultVal);
	static BOOL PrefixedGetRCString(LPCSTR prefix, LPCSTR setting, LPSTR buffer, LPCSTR defaultString, int maxLen);
	static BOOL PrefixedGetRCBool(LPCSTR prefix, LPCSTR setting, bool def);
	static int PrefixedGetRCInt(LPCSTR prefix, LPCSTR setting, int nDefault);
	static int PrefixedGetRCCoordinate(LPCSTR prefix, LPCSTR setting, int nDefault, int maxVal);
	static COLORREF PrefixedGetRCColor(LPCSTR prefix, LPCSTR setting, COLORREF colDef);
};

#endif