/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenbar.hpp"
#include <stdarg.h>
#pragma warning (disable: 4800) // Forcing value to bool 'true' or 'false' (performance warning)

void warn(const char *warning)
{
	trace << "WARNING: "<<warning<<"\n";;
	MessageBox(NULL, warning, PROJECT_NAME, MB_TOPMOST);
}

set<string> warningsGiven;
void warnOnce(const char *warning)
{
	if(warningsGiven.find(string(warning)) != warningsGiven.end())
		return;
	warningsGiven.insert(warning);
	warn(warning);
}

void fatal(const char *error)
{
	trace << "Fatal error: "<<error<<"\n";
	MessageBox(NULL, error, PROJECT_NAME, MB_TOPMOST);
	throw;
}

HWND getDesktopWindow()
{
	HWND desktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktop)
		desktop = GetDesktopWindow();
	return desktop;
}

Point getCursorPos()
{
	CURSORINFO cursorInfo;
	cursorInfo.cbSize = sizeof(CURSORINFO);
	
	GetCursorInfo(&cursorInfo);
	return cursorInfo.ptScreenPos;
}

string retprintf(const char *fmt, ...)
{
	char buf[4096];
	va_list args;
	va_start(args, fmt);
	vsnprintf(buf, 4096, fmt, args);
	va_end(args);
	return buf;
}

void tokenizeString(const string &str, vector<string> &result, const char *separators)
{
	char *copy = _strdup(str.c_str());
	char *pos = strtok(copy, separators);
	while(pos) {
		result.push_back(pos);
		pos = strtok(NULL, separators);
	}
}

const char *skipwhitespace(const char *pos)
{
	while(*pos && isspace(*pos))
		pos++;
	return pos;
}

vector<string> separateArgs(const char *args)
{
	const char *pos = args;
	char buf[4096];
	vector<string> ret;
	
	while(GetToken(pos, buf, &pos, 0))
		ret.push_back(string(buf));
	
	return ret;
}
