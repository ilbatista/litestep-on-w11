/*
This is part of Screenbar, which is based in part on the Litestep
shell source code.

Copyright (C) 2008-2009 Jim Babcock
Copyright (C) 1997-2009 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenbar.hpp"

static const char *vwmWindowClassname = "screenbar_VWMWindow";
static const char *vwmWindowName = "Screenbar";

#define GWL_CLASSPOINTER 0
#define APPBAR_MESSAGE_ID WM_USER

struct PanelEventArg
{
	SHORT size;
	VWMPanel *panel;
};

VWMPanel::VWMPanel(string prefix, Monitor *monitor, HWND parentWindow)
{
	this->prefix = prefix;
	this->monitor = monitor;
	layout = NULL;
	window = NULL;
	this->isEventHandler = false;
	
	bool vertical;
	
	visible = getConfigBool("Visible", true, prefix.c_str());
	alwaysOnTop = getConfigBool("AlwaysOnTop", false, prefix.c_str());
	
	Rect monitorArea = monitor->getRect();
	Rect initialRect;
	
	isAppbar = getConfigBool("Appbar", false, prefix.c_str());
	if(isAppbar)
	{
		string screenEdgeStr = getConfigString("Edge", "bottom", prefix.c_str());
		if(!_stricmp(screenEdgeStr.c_str(), "top")) {
			screenEdge = ABE_TOP;
			vertical = false;
		} else if(!_stricmp(screenEdgeStr.c_str(), "left")) {
			screenEdge = ABE_LEFT;
			vertical = true;
		} else if(!_stricmp(screenEdgeStr.c_str(), "right")) {
			screenEdge = ABE_RIGHT;
			vertical = true;
		} else if(!_stricmp(screenEdgeStr.c_str(), "bottom")) {
			screenEdge = ABE_BOTTOM;
			vertical = false;
		} else {
			string message = retprintf("Invalid screen edge '%s' for panel '%s'.", screenEdgeStr.c_str(), prefix.c_str());
			warn(message.c_str());
			screenEdge = ABE_BOTTOM;
		}
		
		thickness = getConfigInt("Thickness", prefix.c_str());
		autoHide = getConfigBool("AutoHide", false, prefix.c_str());
		hiddenThickness = getConfigInt("HiddenThickness", 1, prefix.c_str());
		autoHideDelay = getConfigInt("HideDelay", 1000, prefix.c_str());
		
		visibleRect = getAppbarPos(NULL, false);
		
		if(autoHide)
			initialRect = getAppbarPos(NULL, true);
		else
			initialRect = visibleRect;
	}
	else
	{
		visibleRect = Rect(
			monitorArea.left + getConfigCoord("X", monitorArea.width, prefix.c_str()),
			monitorArea.top + getConfigCoord("Y", monitorArea.height, prefix.c_str()),
			getConfigCoord("Width", monitorArea.width, prefix.c_str()),
			getConfigCoord("Height", monitorArea.height, prefix.c_str())
			);
		initialRect = visibleRect;
		
		vertical = getConfigBool("Vertical", false, prefix.c_str());
		
		// Assign the panel a fake screen edge, based on whichever it's closest to
		if(visibleRect.top==0 && visibleRect.width>visibleRect.height)
			screenEdge = ABE_TOP;
		else if(visibleRect.top+visibleRect.height>=monitorArea.height && visibleRect.width>visibleRect.height)
			screenEdge = ABE_BOTTOM;
		else if(visibleRect.left==0 && visibleRect.height>visibleRect.width)
			screenEdge = ABE_LEFT;
		else if(visibleRect.left+visibleRect.width>=monitorArea.width && visibleRect.height>visibleRect.width)
			screenEdge = ABE_RIGHT;
		else
			screenEdge = -1;
		
		thickness = -1;
		autoHide = false;
	}
	
	transparent = getConfigBool("Transparent", false, prefix.c_str());
	if(transparent)
		fillColor = RGB(255,0,255);
	else
		fillColor = getConfigColor("BackgroundColor", 0,0,0, prefix.c_str());
	
	string rootElementName = getConfigString("RootElement", NULL, prefix.c_str());
	LayoutElement *rootElement = layoutPool->getElement(rootElementName);
	
	// This is a crappy hack fix to prevent outright crashing on invalid configurations
	// A better fix would be to move all of this code into a init/finalize() routine
	// that can return a failure.
	if(!rootElement)
		throw std::exception("Invalid or missing root element");
	
	string sizeFallbacks = getConfigLine("SizeFallbacks", "", prefix.c_str());
	
	layout = new Layout(
		rootElement,
		ElementContext(this, monitor, NULL, NULL, vertical),
		visibleRect,
		sizeFallbacks);
	
	PanelEventArg arg = {sizeof(PanelEventArg), this};
	int flags = WS_EX_TOOLWINDOW;
	if(transparent)
		flags |= WS_EX_LAYERED;
	if(isAppbar)
		flags |= WS_EX_TOPMOST;
	
	window = CreateWindowEx(
		flags,
		vwmWindowClassname,
		vwmWindowName,
		WS_POPUP|WS_CLIPCHILDREN,
		initialRect.left, initialRect.top, initialRect.width, initialRect.height,
		parentWindow,
		NULL, dllInstance, &arg);
	
	if (!window)
		throw std::exception("Failed to create window");
	
	// Mark this window as 'belonging to Litestep' so that we don't try to operate on ourself
	SetWindowLong(window, GWL_USERDATA, magicDWord);
	
	if(transparent)
		SetLayeredWindowAttributes(window, RGB(255,0,255), 0, LWA_COLORKEY);
	
	initDrawContext();
	
	DragAcceptFiles(window, TRUE);
	
	if(isAppbar)
	{
		appbarData.cbSize = sizeof(appbarData);
		appbarData.hWnd = window;
		appbarData.uEdge = screenEdge;
		appbarData.rc = getAppbarPos(NULL, autoHide);
		appbarData.uCallbackMessage = APPBAR_MESSAGE_ID;
		appbarData.lParam = NULL;
		SHAppBarMessage(ABM_NEW, &appbarData);
		
		HWND autoHideWindow = (HWND)SHAppBarMessage(ABM_GETAUTOHIDEBAR, &appbarData);
		if(autoHideWindow != NULL) {
			warn(retprintf(
				"Panel %s cannot auto-hide because there is already an auto-hiding appbar on the same edge.\n",
				prefix.c_str()).c_str());
			autoHide = false;
		} else {
			appbarData.lParam = TRUE;
			if(!SHAppBarMessage(ABM_SETAUTOHIDEBAR, &appbarData)) {
				warn(retprintf("Failed setting %s to auto-hide.\n", prefix.c_str()).c_str());
				autoHide = false;
			}
			appbarData.lParam = NULL;
		}
		
		updateAppbarPos();
		
		ShowWindow(window, SW_SHOWNOACTIVATE);
		
		hidden = autoHide;
	}
	else
	{
		if(alwaysOnTop)
			SetWindowPos(window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ShowWindow(window, visible?SW_SHOWNOACTIVATE:SW_HIDE);
	}
	
	registerEventHandlers();
	
	layout->update();
}

VWMPanel::~VWMPanel()
{
	unregisterEventHandlers();
	
	if(window)
	{
		if(isAppbar)
			SHAppBarMessage(ABM_REMOVE, &appbarData);
		DragAcceptFiles(window, FALSE);
		ShowWindow(window, SW_HIDE);
		DestroyWindow(window);
		destroyDrawContext();
	}
	
	delete layout;
}

Rect VWMPanel::getAppbarPos(const RECT *prevPos, bool hidden)
{
	RECT ret;
	
	if(prevPos) {
		// If there was another appbar on the same edge, Windows may have
		// adjusted this appbar's position, changing its thickness. Produce a
		// new rectangle, with the correct thickness.
		ret = *prevPos;
	} else {
		ret = monitor->getRect();
	}
	
	int appbarThickness = hidden ? hiddenThickness : thickness;
	
	switch(screenEdge) {
		case ABE_TOP:    ret.bottom = ret.top    + appbarThickness; break;
		case ABE_LEFT:   ret.right  = ret.left   + appbarThickness; break;
		case ABE_RIGHT:  ret.left   = ret.right  - appbarThickness; break;
		case ABE_BOTTOM: ret.top    = ret.bottom - appbarThickness; break;
	}
	
	return ret;
}

void VWMPanel::hide()
{
	if(hidden)
		return;
	if(layout && !layout->allowAutoHide())
		return;
	
	Rect visiblePos = getRect();
	Rect hiddenPos = visiblePos;
	
	switch(screenEdge)
	{
		case ABE_TOP:
			hiddenPos.height = hiddenThickness;
			break;
		case ABE_LEFT:
			hiddenPos.width = hiddenThickness;
			break;
		case ABE_RIGHT:
			hiddenPos.left = visiblePos.getRight() - hiddenThickness;
			hiddenPos.width = hiddenThickness;
			break;
		case ABE_BOTTOM:
			hiddenPos.top = visiblePos.getBottom() - hiddenThickness;
			hiddenPos.height = hiddenThickness;
			break;
	}
	
	SetWindowPos(window, 0,
		hiddenPos.left, hiddenPos.top,
		hiddenPos.width, hiddenPos.height,
		SWP_NOZORDER | SWP_NOACTIVATE);
	
	KillTimer(window, TIMER_AUTOUNHIDE);
	
	hidden = true;
}

void VWMPanel::unhide()
{
	if(!hidden)
		return;
	
	Rect visiblePos = getRect();
	
	SetWindowPos(window, HWND_TOP,
		visiblePos.left, visiblePos.top,
		visiblePos.width, visiblePos.height,
		SWP_NOACTIVATE);
	
	KillTimer(window, TIMER_AUTOUNHIDE);
	SetTimer(window, TIMER_AUTOHIDE, autoHideDelay, NULL);
	
	hidden = false;
}

void VWMPanel::updateAppbarPos()
{
	appbarData.rc = getAppbarPos(NULL, autoHide);
	SHAppBarMessage(ABM_QUERYPOS, &appbarData);
	
	visibleRect = getAppbarPos(&appbarData.rc, false);
	
	Rect hiddenRect = getAppbarPos(&appbarData.rc, autoHide);
	appbarData.rc = hiddenRect;
	SHAppBarMessage(ABM_SETPOS, &appbarData);
	
	Rect setRect = hidden ? hiddenRect : visibleRect;
	SetWindowPos(window, HWND_TOPMOST, setRect.left, setRect.top, setRect.width, setRect.height, SWP_NOZORDER|SWP_NOACTIVATE);
}

void VWM::initPanels(HWND parentWindow)
{
	VWMPanel::registerWindowClass();
	
	// Parse sbPanels, creating panelPrefixes, a list of prefixes each
	// of which corresponds to a VWMPanel and has suffixes for window position
	// and settings.
	vector<string> panelPrefixes;
	tokenizeString(settings->panels, panelPrefixes, " \t,;");
	
	bool first = true;
	
	for(unsigned ii=0; ii<panelPrefixes.size(); ii++)
	{
		string prefix = panelPrefixes[ii];
		string monitorSpecifier = getConfigLine("Monitors", "all", prefix.c_str());
		set<Monitor*> monitors = findMonitors(monitorSpecifier);
		
		for(set<Monitor*>::iterator jj=monitors.begin(); jj!=monitors.end(); jj++)
		{
			Monitor *monitor = *jj;
			
			try {
				panels.push_back(new VWMPanel(prefix, monitor, parentWindow));
			} catch(exception e) {
				warn(e.what());
			}
		}
	}
}

VWMPanel *VWM::findPanel(int x, int y)
{
	for(unsigned ii=0; ii<panels.size(); ii++)
	{
		VWMPanel *panel = panels[ii];
		if(panel->getRect().containsPoint(x, y))
			return panel;
	}
	return NULL;
}

VWMPanel *VWM::getFirstPanel()
{
	return panels[0];
}

void VWM::getPanels(vector<VWMPanel*> *outPanels)
{
	for(unsigned ii=0; ii<panels.size(); ii++)
		outPanels->push_back(panels[ii]);
}

void VWM::destroyPanels()
{
	for(unsigned ii=0; ii<panels.size(); ii++)
		delete panels[ii];
	panels.clear();
	VWMPanel::unregisterWindowClass();
}

void VWM::refreshPanels()
{
	destroyPanels();
	
	delete layoutPool;
	layoutPool = new LayoutPool();
	
	initPanels(parentWindow);
}

static WNDCLASSEX panelWindowClass;

void VWMPanel::registerWindowClass()
{
	memset(&panelWindowClass, 0, sizeof(WNDCLASSEX));
	panelWindowClass.cbSize = sizeof(WNDCLASSEX);
	panelWindowClass.cbWndExtra = sizeof(VWM*);
	panelWindowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	panelWindowClass.lpfnWndProc = VWMPanel::eventHandler;
	panelWindowClass.hInstance = dllInstance;
	panelWindowClass.lpszClassName = vwmWindowClassname;
	panelWindowClass.style = CS_HREDRAW|CS_VREDRAW;

	if (!RegisterClassEx(&panelWindowClass)) {
		// Class could not be registered, try to re-register
		UnregisterClass(vwmWindowClassname, dllInstance);

		if (!RegisterClassEx(&panelWindowClass)) {
			// Still no luck, error out
			fatal("Unable to register window class.");
		}
	}
}

void VWMPanel::unregisterWindowClass()
{
	UnregisterClass(vwmWindowClassname, dllInstance);
}

void VWMPanel::checkForUpdates()
{
	if(!layout)
		return;
	if(layout->update())
		forcePanelRedraw();
}

LRESULT CALLBACK VWMPanel::eventHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(uMsg == WM_NCCREATE)
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	
	if (uMsg == WM_CREATE) {
		LPVOID &createParams = LPCREATESTRUCT(lParam)->lpCreateParams;

		if (createParams) {
			VWMPanel *panel = ((PanelEventArg*)(createParams))->panel;
			SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)panel);
		} 
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	
	VWMPanel *panel = (VWMPanel*)(GetWindowLong(hWnd, GWL_CLASSPOINTER));
	if(!panel) {
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	
	return panel->handleEvent(uMsg, wParam, lParam);
}

LRESULT VWMPanel::handleEvent(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
		case WM_LBUTTONDOWN: return mouseButtonEvent(mouseLeft,   mouseDown, LOWORD(lParam), HIWORD(lParam));
		case WM_RBUTTONDOWN: return mouseButtonEvent(mouseRight,  mouseDown, LOWORD(lParam), HIWORD(lParam));
		case WM_MBUTTONDOWN: return mouseButtonEvent(mouseMiddle, mouseDown, LOWORD(lParam), HIWORD(lParam));
		case WM_LBUTTONUP:   return mouseButtonEvent(mouseLeft,   mouseUp,   LOWORD(lParam), HIWORD(lParam));
		case WM_RBUTTONUP:   return mouseButtonEvent(mouseRight,  mouseUp,   LOWORD(lParam), HIWORD(lParam));
		case WM_MBUTTONUP:   return mouseButtonEvent(mouseMiddle, mouseUp,   LOWORD(lParam), HIWORD(lParam));
		
		case WM_ACTIVATE: {
			if(isAppbar)
				SHAppBarMessage(ABM_ACTIVATE, &appbarData);
			
			if(autoHide && hidden && (wParam==WA_ACTIVE || wParam==WA_CLICKACTIVE))
				unhide();
			
			return 0;
		}
		
		case WM_TIMER: {
			if(wParam == TIMER_AUTOHIDE)
			{
				if(autoHide && !hidden && !drag)
				{
					Point cursorPos = getCursorPos();
					if(!getRect().containsPoint(cursorPos.x, cursorPos.y))
						hide();
				}
			}
			else if(wParam == TIMER_AUTOUNHIDE)
			{
				if(hidden)
					unhide();
			}
			else
			{
				return vwm->windowProc(window, uMsg, wParam, lParam);
			}
		}
		
		case WM_KILLFOCUS:
			if(drag)
				SetCapture(window);
			//if(drag && drag->active)
			//	cancelDrag();
			return 0;
			
		case APPBAR_MESSAGE_ID:
			if(wParam == ABN_POSCHANGED)
			{
				updateAppbarPos();
			}
			else if(wParam == ABN_FULLSCREENAPP)
			{
				int state = SHAppBarMessage(ABM_GETSTATE, &appbarData);
				if(lParam) {
					if(alwaysOnTop) {
						long flags = GetWindowLong(window, GWL_EXSTYLE);
						SetWindowLong(window, GWL_EXSTYLE, flags&~WS_EX_TOPMOST);
					}
					SetWindowPos(window, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
				} else {
					if(alwaysOnTop) {
						long flags = GetWindowLong(window, GWL_EXSTYLE);
						SetWindowLong(window, GWL_EXSTYLE, flags|WS_EX_TOPMOST);
					}
					SetWindowPos(window, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
				}
			}
			return 0;
		
		case WM_MOUSEACTIVATE: {
			WindowData *foregroundWindow = windowTracker->getForegroundWindow();
			if(foregroundWindow)
				vwm->lastFocus = foregroundWindow->handle;
			else
				vwm->lastFocus = NULL;
			return MA_ACTIVATE;
		}
		
		case WM_SETCURSOR:
			if(hidden)
				SetTimer(window, TIMER_AUTOUNHIDE, 0, NULL);
			return 0;
			
		case WM_MOUSEMOVE: {
			if(hidden)
				unhide();
			
			// In window coordinates
			int mouseX = LOWORD(lParam);
			int mouseY = HIWORD(lParam);
			mouseMoveEvent(mouseX, mouseY);
			return 0;
		}
		case WM_MOUSELEAVE: {
			if(drag && !drag->active) {
				SetCapture(window);
				beginDrag();
			}
			checkForUpdates();
			return 0;
		}
		
		case WM_PAINT:
			onPaint(hidden);
			return 0;
			
		case WM_WINDOWPOSCHANGING: {
			// This is sent when the panel is moved, either by choice or by
			// some other program forcibly moving it. Update internals to
			// reflect the new size.
			LPWINDOWPOS windowPos = (LPWINDOWPOS)lParam;
			
			if(isAppbar)
				SHAppBarMessage(ABM_WINDOWPOSCHANGED, &appbarData);
			
			/*if( !(windowPos->flags & SWP_NOSIZE) ) {
				width = windowPos->cx;
				height = windowPos->cy;
			}
			if( !(windowPos->flags & SWP_NOMOVE) ) {
				x = windowPos->x;
				y = windowPos->y;
			}*/
			
			return DefWindowProc(window, uMsg, wParam, lParam);
		}
			
		default:
			return vwm->windowProc(window, uMsg, wParam, lParam);
	}
}

LayoutReference *clickContext = NULL;

/// Called when a mouse button is pressed over this panel or released anywhere
/// after having been pressed on the panel. x and y are in window coordinates.
int VWMPanel::mouseButtonEvent(MouseButton button, MouseAction action, int x, int y)
{
	bool draggedAndDropped = false;
	vwm->updateLayouts();
	
	LayoutReference *clickedRef = layout->elementAtPoint(x, y);
	if(!clickedRef) return 0;
	
	LayoutCacheNode *clickedPos = clickedRef->getNode();
	if(!clickedPos) {
		delete clickedRef;
		return 0;
	}
	
	LayoutCacheNode *pressNode, *releaseNode, *clickNode;
	for(pressNode=clickedPos; pressNode; pressNode=pressNode->parent)
		if(pressNode->element->onPress[button]!="")
			break;
	for(releaseNode=clickedPos; releaseNode; releaseNode=releaseNode->parent)
		if(releaseNode->element->onRelease[button]!="")
			break;
	for(clickNode=clickedPos; clickNode; clickNode=clickNode->parent)
		if(clickNode->element->onClick[button]!="")
			break;
	
	string clickAction = "";
	
	if(action == mouseDown)
	{
		LayoutCacheNode *draggedNode = clickedPos;
		while(draggedNode && !draggedNode->element->draggable) {
			draggedNode = draggedNode->parent;
		}
		if(draggedNode) {
			drag = new DragInfo(layout->getReferenceTo(draggedNode), x, y, button);
			vwm->forceRedraw();
		}
	}
	else if(action == mouseUp)
	{
		if(drag && drag->active)
			draggedAndDropped = true;
		finishDrag();
	}
	
	bool commandsRun = false;
	
	if(clickNode && action==mouseDown)
	{
		lastClickLocation.context = clickNode->context;
		lastClickLocation.element = clickNode->element;
	}
	if(clickNode && action==mouseUp)
	{
		clickContext = layout->getReferenceTo(clickNode);
		
		if(lastClickLocation.context.match(clickNode->context)
		   && lastClickLocation.element == clickNode->element
		   && clickNode->element != NULL
		   && !draggedAndDropped)
		{
			LSExecute(window, clickNode->element->onClick[button].c_str(), SW_SHOWNORMAL);
			commandsRun = true;
		}
		lastClickLocation.element = NULL;
	
		delete clickContext;
		clickContext = NULL;
	}
	
	if(action==mouseDown && pressNode)
	{
		clickContext = layout->getReferenceTo(pressNode);
		commandsRun = true;
		
		LSExecute(window, pressNode->element->onPress[button].c_str(), SW_SHOWNORMAL);
		
		delete clickContext;
		clickContext = NULL;
	}
	else if(action==mouseUp && releaseNode && !commandsRun)
	{
		clickContext = layout->getReferenceTo(releaseNode);
		commandsRun = true;
		
		LSExecute(window, releaseNode->element->onRelease[button].c_str(), SW_SHOWNORMAL);
		
		delete clickContext;
		clickContext = NULL;
	}

	if(commandsRun)
	{
		// Running commands may have changed the layout
		vwm->updateLayouts();
	}
	
	delete clickedRef;
	return 0;
}

/// Called when the mouse moves over the panel, or moves anywhere while
/// dragging on a click that started inside the panel. Given in window
/// coordinates, but may outside the window and may be negative.
int VWMPanel::mouseMoveEvent(int x, int y)
{
	// Suppress this event if outside window bounds
	if(x<0 || y<0 || x>=visibleRect.width || y>=visibleRect.height)
		return 1;
	
	// Request notification when the mouse leaves the window
	TRACKMOUSEEVENT args;
		memset(&args, 0, sizeof(args));
		args.cbSize = sizeof(TRACKMOUSEEVENT);
		args.dwFlags = TME_LEAVE;
		args.hwndTrack = window;
	TrackMouseEvent(&args);

	// Sometimes receive this event while unprepared for it
	if(!layout)
		return 1;
	
	if(layout->updateHover())
		forcePanelRedraw();
	
	if(drag)
	{
		if(drag->active)
		{
			hoverDraggedObject(drag->element->prefix, x, y);
		}
		else
		{
			int dx = drag->mouseOrigin.x - x;
			int dy = drag->mouseOrigin.y - y;
			if(dx*dx + dy*dy > 25) {
				SetCapture(window);
				beginDrag();
			}
		}
	}
	return 0;
}

string VWMPanel::getPrefix()
	{ return prefix; }

void VWMPanel::setVisible(bool visible)
{
	this->visible = visible;
	if(visible)
		ShowWindow(window, SW_SHOWNOACTIVATE);
	else
		ShowWindow(window, SW_HIDE);
}

void VWMPanel::setAlwaysOnTop(bool onTop)
{
	this->alwaysOnTop = onTop;
	
	DWORD oldStyle = GetWindowLong(window, GWL_STYLE);
	DWORD tempStyle = (oldStyle & ~WS_POPUP) | WS_CHILD;
	DWORD newStyle = (oldStyle & ~WS_CHILD) | WS_POPUP;
	
	SetWindowLong(window, GWL_STYLE, tempStyle);
	SetParent(window, onTop?NULL:getDesktopWindow());
	SetWindowLong(window, GWL_STYLE, newStyle);
	
	SetWindowPos(window, onTop?HWND_TOPMOST:HWND_NOTOPMOST,
        0, 0, 0, 0,
        SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
}

bool VWMPanel::getVisible()
	{ return visible; }
bool VWMPanel::getAlwaysOnTop()
	{ return alwaysOnTop; }
HWND VWMPanel::getWindow()
	{ return window; }
Monitor *VWMPanel::getMonitor()
	{ return monitor; }

Rect VWMPanel::getRect()
	{ return visibleRect; }
Point VWMPanel::getTopLeft()
	{ return visibleRect.topLeft(); }

Point VWMPanel::getMenuPos(Rect buttonRect)
{
	Point ret;
	
	switch(screenEdge)
	{
		case ABE_LEFT:   ret = Point(buttonRect.getRight(), buttonRect.top); break;
		case ABE_RIGHT:  ret = Point(buttonRect.left, buttonRect.top); break;
		case ABE_BOTTOM: ret = Point(buttonRect.left, buttonRect.top); break;
		default:
		case ABE_TOP:    ret = Point(buttonRect.left, buttonRect.getBottom()); break;
	}
	
	ret += getTopLeft();
	return ret;
}

string VWMPanel::getMenuEdge()
{
	switch(screenEdge)
	{
		case ABE_LEFT:   return "left";
		case ABE_RIGHT:  return "right";
		case ABE_TOP:    return "top";
		case ABE_BOTTOM: return "bottom";
		default: return "";
	}
}
