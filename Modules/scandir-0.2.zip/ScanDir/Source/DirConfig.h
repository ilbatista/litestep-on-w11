#ifndef __DIRCONFIG_H
#define __DIRCONFIG_H

#include <Windows.h>
#include "FileOutput.h"
#include "BangOutput.h"
#include <vector>
using namespace std;

enum
{
	FIND_DOS = 1,
	FIND_DIRS,
	FIND_FILES,
	FIND_EXT,
	FIND_FONTS,
	FIND_ARCHIVE,
	FIND_HIDDEN,
	FIND_NORMAL,
	FIND_SYSTEM,
	FIND_ALL
};

class Dir
{
public:
	char *path;
	char *files;
};

class DirConfig : public Dir
{
public:
	DirConfig(char* nm);
	~DirConfig();
	void ReadConfig();
	void SetFilter();
	BOOL Scan();

	char *name;

	int findWhat;
	int filter;

	BOOL IncludeRootSelf; // for "." and ".."
	BOOL DisableStartupScan;

	FileOutput *file;
	BangOutput *bang;

	vector<WIN32_FIND_DATA> ResultBuffer;

};

#endif