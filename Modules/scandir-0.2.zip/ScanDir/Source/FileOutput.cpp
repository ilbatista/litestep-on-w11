#include "FileOutput.h"
#include "../current/lsapi/lsapi.h"
#include "LSUtils.h"
#include <stdio.h>
#include <windows.h>
#include <io.h>
#include "Log.h"

FileOutput::FileOutput(char* name, char* out) : Output(name), outputFile(NULL)
{
	char szTemp[MAX_LINE_LENGTH];

	outfile = new char[strlen(out)+1];
	strcpy(outfile, out);

	if ( LSUtils::PrefixedGetRCLine(name, "FileOutPutFormat", szTemp, "") )
	{
		format = new char[strlen(szTemp)+1];
		strcpy(format, szTemp);
	}
	else format = NULL;

	if ( LSUtils::PrefixedGetRCLine(name, "FileFoundString", szTemp, "") )
	{
		foundString = new char[strlen(szTemp)+1];
		strcpy(foundString, szTemp);
	}
	else foundString = NULL;

	if ( LSUtils::PrefixedGetRCLine(name, "FileNothingString", szTemp, "") )
	{
		nothingString = new char[strlen(szTemp)+1];
		strcpy(nothingString, szTemp);
	}
	else nothingString = NULL;

	// specific items for file output
	if ( LSUtils::PrefixedGetRCLine(name, "FileOutPutPrefix", szTemp, "") )
	{
		prefix = new char[strlen(szTemp)+1];
		strcpy(prefix, szTemp);
	}
	else prefix = NULL;
	
	if ( LSUtils::PrefixedGetRCLine(name, "FileOutPutSuffix", szTemp, "") )
	{
		suffix = new char[strlen(szTemp)+1];
		strcpy(suffix, szTemp);
	}
	else suffix = NULL;
}

FileOutput::~FileOutput()
{
	delete [] outfile;
	if (format)
		delete [] format;

	if (nothingString)
		delete [] nothingString;
	if (foundString)
		delete [] foundString;
	if (prefix)
		delete [] prefix;
	if (suffix)
		delete [] suffix;

	CloseFile();
}

void FileOutput::OpenFile()
{
	outputFile = fopen(outfile, "wt");
	LSLogPrintf(LOG_DEBUG, "ScanDir", "Opening file: %s, %d.", outfile, outputFile);
}

void FileOutput::CloseFile()
{
	if (outputFile)
	{
		LSLogPrintf(LOG_DEBUG, "ScanDir", "Closing file: %s, %d.", outfile, outputFile);
		fclose(outputFile);
		outputFile = NULL;
	}
}

void FileOutput::OutputPrefix()
{
	if (outputFile)
	{
		if (prefix)
			fputs(prefix, outputFile);
	}
};

void FileOutput::OutputSuffix()
{
	if (outputFile)
	{
		if (suffix)
			fputs(suffix, outputFile);
	}
};

void FileOutput::OutputFound()
{
	if (outputFile)
	{
		if (foundString)
			fputs(foundString, outputFile);
	}
};

void FileOutput::OutputNothing()
{
	if (outputFile)
	{
		if (nothingString)
			fputs(nothingString, outputFile);
	}
};

void FileOutput::Emit(const char *path, const WIN32_FIND_DATA Result, const int nr, const int total)
{
	int res;
	if (outputFile)
	{
	#ifdef DEBUG
		LSLog(LOG_DEBUG, "ScanDir", "Preparing to write to file");
	#endif

		char output[MAX_LINE_LENGTH];
		memset(output, 0, MAX_LINE_LENGTH);
		ParseCommands(output, path, Result, nr, total);
		res = fprintf(outputFile, "%s\n", output);

	#ifdef DEBUG
		if (res < 0)
			LSLogPrintf(LOG_ERROR, "ScanDir", "Error outputting string: %s", output);
		else
			LSLogPrintf(LOG_DEBUG, "ScanDir", "Outputresult: %s", output);
	#endif

	}
	else
		LSLogPrintf(LOG_ERROR, "ScanDir", "Unable to open file: %s for output", outfile);
}