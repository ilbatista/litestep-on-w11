#ifndef __FILEOUTPUT_H
#define __FILEOUTPUT_H

#include "Output.h"
#include <stdio.h>

class FileOutput : public Output
{
public:
	FileOutput(char* name, char* out);
	~FileOutput();

	void CloseFile();
	void OpenFile();
	void OutputPrefix();
	void OutputSuffix();
	void OutputFound();
	void OutputNothing();

	FILE *outputFile;

	char *outfile;
	char *prefix;
	char *suffix;
	
	char *foundString;
	char *nothingString;

	void Emit(const char *path, const WIN32_FIND_DATA Result, const int nr, const int total);
};

#endif