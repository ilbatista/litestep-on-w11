/****************************************************************************

ScanDir (0.2):
by Vendicator

The purpose of this module is to make some config scenarios more dynamic.
So far it's been tested as a popup based theme switcher and fontselecting
could be made to work with textedit, but probably you can come up with even
more uses than I can...

Config:

ScanDirs name1 name2
	Specify the names of the scandirconfigs you want to use
	will look for name1Path, name1Files, name1OutputFile, name1OutputFormat etc..

[NAME]Path:
	Directory which to scan

[NAME]Files (nothing tested):
	[dirs] - lists only directories
	[files] - opposite to dirs
	[fonts] - lists only fonts
	[archive] - only with attribute archive set
	[hidden] - only with attribute hidden set
	[normal] - only with attribute normal set
	[system] - only with attribute system set
	[all] - same as *.*
	dos commands like *.*, *.exe etc.

[NAME]OutputFile:
	Path and filename of where to output the data.

[NAME]OutputBang:
	Bool to enable bang output, needs separate config

[NAME][File/Bang]OutputFormat:
	[filename] - name of hit
	[path] - full path to dir with hit
	[filenr] - sequentially increasing nr for each file hit
	[filestotal] - total nr of files found in search
	[fontname] - name in a .ttf file, doesn't seem to work with all fonts
	[modified] - date of modification, not tested
	[created] - date of creation, not tested
	[accessed] - date of last access, not tested
	[extension] - extension of file, not tested
	[size] - file size, in bytes, not tested
	[attrib] - normal, hidden, system etc.

	Escape codes: \n, \t, \v, \", \', \\
	ex:	[\n] - makes a new line
		[\t] - horizontal tab
		[\v] - vertical tab
		[\"] - "
		[\'] - '
		[\\] - backslash \
		[\{] - [
		[\}] - ]
		[\@] - $

Optional:

[NAME]FileFoundString
	Additional string to output in the file if something is found in dir

[NAME]FileNothingString
	Additional string to output in the file if dir was empty

[NAME]BangFoundCmd
	Additional !bang to run if something is found in dir

[NAME]BangNothingCmd
	Additional !bang to run if dir was empty

[NAME]FileOutputPrefix, not tested
	Additional string to output first in file

[NAME]FileOutputSuffix, not tested
	Additional string to output last in file

[NAME]IncludeRootSelf:
	to include folder like "." & ".."

[NAME]DisableStartupScan
	Disables scan of this config folder at startup & recycle,
	requires manual scan through !scandir [NAME]

Example of themes switching:
	ScanDirs			Themes
	ThemesPath			$litestepdir$themes\
	ThemesFiles			*.*
	ThemesOutputFile	$litestepdir$personal\themeselect.rc
	ThemesFileOutputFormat	*Popup [filename] !scandirSetTheme [filename]

Example of font setting:
	ScanDirs			fonts
	fontsPath			$windir$fonts
	fontsfiles			*.ttf
	fontsoutputfile		$litestepdir$personal\fontselect.rc
	fontsfileoutputformat	*popup Setfont: [fontname] !BangToChangeFontTo [fontname]

!bangs:

!ScanDir [NAME]
	Scans the dir with that config name ([all], or no args for all dirs)
	ie. ScanDir Themes, [all], etc

!ScanDirSetTheme
	Tries to set the current theme in step.rc to the foldername given,
	looks for a step.rc in folder first,
	assumes themesdir is $litestepdir$themes when writing the step.rc (is this ever false?)
	Note: Currently ScanDir rewrites the litestep\step.rc file to only point
	to the themes step.rc (everything else in it will be lost, just like using LSCP)


Todo:

  - Output specific nr of files / dirs
  - Pre command parse for [path] and escape codes
  - Resource, handle leak?
  - Recursion for subdirs?
  - special handling of first/last found entry
  - Name sorting, would need data buffering
  - .lnk reading to output icon, path etc..
  - mp3 tag reading


Changelog:

- Fixed [Vendicator, 02-12-18, release: 0.2]
  - Fixed uninitialized var sometimes preventing scanning to run
  - Rewrote command parsing code, handles combinations of [] much better
  - Threaded scanning from recycle
  - Source clean enough for release :)

- Added [Vendicator, 02-12-17]
  - Added [filestotal] for outputting nr of files found
  - Buffered search results in order for above feature to work

- Fixed [Vendicator, 02-12-16]
  - Finally finished the recoding, can now output using bangs
  - Fixed filetime outputting

- Added [Vendicator, 02-08-19]
  - Added messagebox warning when trying to switch theme when there is no step.rc in folder

- Fixed [Vendicator, 02-08-14]
  - Fixed small memleak
  - Termination of thread if still running when closing module

- Fixed [Vendicator, 02-08-12]
  - Seemed stable enough to allow for a beta1 release, yay!
  - Fixed fontscanning.
  - Fixed stupid bug when no found/nothing strings were entered
  - Unknown commands are simply outputted to file, with warning to log about which they were...

- Added [Vendicator, 02-08-04]
  - Added [NAME]FoundString, [NAME]NothingString to output of file
  - Implemented escape code, must be in brackets []

- Fixed [Vendicator, 02-08-03]
  - Threaded ScanAllFolders, should address any startup delays...

- Fixed [Vendicator, 02-08-02]
  - Added handling when running !scandir without arguments
  - Added [NAME]DisableStartupScan so you don't need to trash your disk on each recycle

- Added [Vendicator, 02-07-28]
  - Added !ScanDirSetTheme to enable use of ScanDir as a themeswitcher

- Fixed [Vendicator/MickeM, 02-07-27]
  - Found stupid bug in font name reader that prevented some names to be read

- Added [Vendicator, 02-07-26]
  - Added fontname reader, from codeproject article by Philip Patrick,
    thanks to Message for finding my stupid misstakes.

- Added [Vendicator, 02-07-25]
  - Fixed the dir scanning thanks to MickeM
  - Implemented the rest of the modules functions, parsing, output etc.

- Added [Vendicator, 02-07-23]
  - First work, did multiple settings loader

****************************************************************************/

#include "ScanDir.h"
#include "Log.h"

scandir *ScanDir; // The module


//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	ScanDir = new scandir(ParentWnd, code);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete ScanDir;
}


//=========================================================
// Bang commands
//=========================================================
void BangScan(HWND caller, LPCSTR args)
{
	ScanDir->BangScanDir(caller, args);
}

void BangTheme(HWND caller, LPCSTR args)
{
	ScanDir->BangSetTheme(caller, args);
}

#ifdef FONT_DEBUG
void BangTestFont(HWND caller, LPCSTR args)
{
	char buffer[MAX_PATH];
	memset(buffer, 0, MAX_PATH);

	char szPath[MAX_PATH];

	LPITEMIDLIST pidl;
	IMalloc *pMalloc;
	HRESULT hr;
	BOOL fResult = FALSE;

	if (SUCCEEDED(SHGetMalloc(&pMalloc)))
	{
		hr = SHGetSpecialFolderLocation(NULL, CSIDL_FONTS, &pidl);

		if (SUCCEEDED(hr))
		{
			fResult = SHGetPathFromIDList(pidl, szPath);

			if (fResult)
				lstrcat(szPath, "\\");

			pMalloc->Free(pidl);
			pMalloc->Release();
		}
	}

	if (args != NULL)
	{
		LSLogPrintf(LOG_DEBUG, szAppName, "args != NULL: %s", args);
		strcat(szPath, args);
	}
	else
		strcat(szPath, "arial.ttf");

	getFontNameFromFile(szPath, buffer);
	LSLog(LOG_DEBUG, szAppName, "name function done");
	LSLogPrintf(LOG_DEBUG, szAppName, "outputted fontname: %s", buffer);
}
#endif

//=========================================================
// Module code
//=========================================================

// static function for threading
void scandir::ScanAllFolders()
{
	if (ScanDir->Scanning)
	{
		LSLog(LOG_NOTICE, szAppName, "Scan is already running");
		return;
	}

	LSLog(LOG_DEBUG, szAppName, "Starting scan");
	ScanDir->Scanning = TRUE;
	int i;
	for(i=0; i<ScanDir->NrConfigs; i++)
	{
		// do all if startup is done, or the disable isn't set
		if (ScanDir->StartupDone || !ScanDir->configs[i].config->DisableStartupScan)
			ScanDir->configs[i].config->Scan();
	}
	// set startup done after first scan
	ScanDir->StartupDone = TRUE;
	ScanDir->Scanning = FALSE;
	LSLog(LOG_DEBUG, szAppName, "Scan done");
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
scandir::scandir(HWND parentWnd, int& code):
Window(szAppName),
StartupDone(FALSE),
Scanning(FALSE)
{

	int msgs[] = {LM_GETREVID, LM_RECYCLE, 0};


	if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
                    0, 0, 0, 0, parentWnd))
	{
		MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
		code = 1;
	return;
	}

	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	readConfig();

	AddBangCommand("!ScanDir", BangScan);
	AddBangCommand("!ScanDirSetTheme", BangTheme);
#ifdef FONT_DEBUG
	AddBangCommand("!ScanDirTestFont", BangTestFont);
#endif

	code = 0;
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "Trying to start scan thread");
#endif
	hScanThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ScanDir->ScanAllFolders, (LPVOID)NULL, 0, &ScanThreadID);
	if (hScanThread == NULL)
		LSLogPrintf(LOG_ERROR, szAppName, "Error creating scan thread: %d", GetLastError());

	//ScanAllFolders();
}

void scandir::readConfig()
{
	char szTemp[MAX_LINE_LENGTH];
	char Name[MAX_LINE_LENGTH];
	char extra[MAX_LINE_LENGTH];
	char *tokens[1] = {Name};

	// get dir name configs
	GetRCLine("ScanDirs", szTemp, MAX_LINE_LENGTH, "");
	
	NrConfigs = 0;
	configs = NULL;

	LSLog(LOG_DEBUG, szAppName, "Starting Config Parsing");

	do
	{
		LCTokenize( szTemp, tokens, 1, extra );

		if (!configs)
			configs = (ConfigList *)malloc(sizeof(ConfigList));
		else
			configs = (ConfigList *)realloc(configs, (NrConfigs+1)*sizeof(ConfigList));

		configs[NrConfigs].config = new DirConfig(Name);
		
		NrConfigs++;

		// process the remainding configs
		strcpy(szTemp, extra);
	}
	while(extra[0] != '\0');

	LSLogPrintf(LOG_DEBUG, szAppName, "Parsing complete, %d configs found", NrConfigs);
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
scandir::~scandir()
{
	int msgs[] = {LM_GETREVID, LM_RECYCLE, 0};

	if (Scanning) {
		TerminateThread(hScanThread, NULL);
	}

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	RemoveBangCommand("!ScanDir");
	RemoveBangCommand("!ScanDirSetTheme");
#ifdef FONT_DEBUG
	RemoveBangCommand("!ScanDirTestFont");
#endif

	removeConfig();
	destroyWindow();
}

void scandir::removeConfig()
{
	int i;
	for (i=0; i<NrConfigs; i++)
	{
		if (configs[i].config)
			delete configs[i].config; // always allocated
	}
	free(configs);
}

//=========================================================
// Registered messages
//=========================================================

void scandir::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	MESSAGE(onEndSession,        WM_ENDSESSION)
	MESSAGE(onEndSession,        WM_QUERYENDSESSION)
	MESSAGE(onGetRevId,          LM_GETREVID)
	MESSAGE(onSysCommand,        WM_SYSCOMMAND)
	MESSAGE(onLMRecycle,     LM_RECYCLE)
	END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void scandir::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void scandir::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
	case 0:
		sprintf(buf, "ScanDir.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
	break;
	case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
	default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}


void scandir::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void scandir::onLMRecycle(Message& message)
{
	removeConfig();
	readConfig();

	// what to do with previous scan thread?
	if (!Scanning)
		hScanThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ScanDir->ScanAllFolders, (LPVOID)NULL, 0, &ScanThreadID);
}


//=========================================================
// Bang command handling
//=========================================================

/*rcStep "step.rc";
dirTheme "$LitestepDir$themes\THEMENAME\";
include "$dirTheme$$rcStep$";*/

void scandir::BangSetTheme(HWND caller, LPCSTR args)
{
	char stepRC[MAX_PATH];
	char themeRC[MAX_PATH];
	LSGetLitestepPath(stepRC, MAX_PATH);
	
	strcpy(themeRC, stepRC);
	strcpy(themeRC, "themes\\");
	strcat(themeRC, args);

	strcat(themeRC, "\\step.rc");
	strcat(stepRC, "\\step.rc");

	FILE *themeRCFile;
	if (themeRCFile = fopen(themeRC, "r"))
	{
		FILE *rcFile;
		if (rcFile = fopen(stepRC, "w"))
		{
			fprintf(rcFile, "rcStep \"step.rc\"; \n");
			fprintf(rcFile, "dirTheme \"$LitestepDir$themes\\%s\\\"; \n", args);
			fprintf(rcFile, "include \"$dirTheme$$rcStep$\"; \n");
			fclose(rcFile);
		}
		else
		{
			LSLogPrintf(LOG_ERROR, szAppName, "couldn't open step.rc: %s, ", stepRC);
		}

	fclose(themeRCFile);
	LSExecute(GetLitestepWnd(), "!Recycle", NULL);
	}
	else
	{
		char temp[256];
		sprintf(temp, "No step.rc found for theme: \"%s\"\nSearch path: \"%s\"", args, themeRC);
		MessageBox(hWnd, temp, "Missing step.rc", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
		LSLogPrintf(LOG_ERROR, szAppName, "Didn't find step.rc in theme: %s, path: %s", args, themeRC);
	}	
}

void scandir::BangScanDir(HWND caller, LPCSTR args)
{
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "Configs to check: %d", NrConfigs);
#endif

	bool found = false;
	int i = 0;
	if ( args == NULL || !stricmp("[all]", args) ) {
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "Scanning all configed dirs");
#endif
		if (args == NULL)
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "argument == NULL, scanning all dirs");
#endif
		// threaded better way...
		if (!Scanning)
			hScanThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ScanDir->ScanAllFolders, (LPVOID)NULL, 0, &ScanThreadID);
		// old way, delays startup of ls...
		//ScanAllFolders();
	}
	else
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, szAppName, "Looking for specific config");
#endif
		for (i=0; i<NrConfigs; i++)
		{
			if ( !stricmp(configs[i].config->name, args) ) {
#ifdef DEBUG
		LSLog(LOG_DEBUG, szAppName, "Trying to scan folder");
#endif
				configs[i].config->Scan();
				found = true;
				break;
			}
		}
		if (!found)
			LSLogPrintf(LOG_WARNING, szAppName, "No scandir config with name \"%s\" found", args);
	}
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "Dir scanned");
#endif
	
}

