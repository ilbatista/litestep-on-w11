#include <windows.h>
#include "BangOutput.h"
#include "LSUtils.h"
#include "..\current\lsapi\lsapi.h"
#include "Log.h"

BangOutput::BangOutput(char* name) : Output(name)
{
	char szTemp[MAX_LINE_LENGTH];
	if ( LSUtils::PrefixedGetRCLine(name, "BangOutPutFormat", szTemp, "") )
	{
		format = new char[strlen(szTemp)+1];
		strcpy(format, szTemp);
	}
	else format = NULL;

	if ( LSUtils::PrefixedGetRCLine(name, "BangFoundCmd", szTemp, "") )
	{
		foundCmd = new char[strlen(szTemp)+1];
		strcpy(foundCmd, szTemp);
	}
	else foundCmd = NULL;

	if ( LSUtils::PrefixedGetRCLine(name, "BangNothingCmd", szTemp, "") )
	{
		nothingCmd = new char[strlen(szTemp)+1];
		strcpy(nothingCmd, szTemp);
	}
	else nothingCmd = NULL;
}

BangOutput::~BangOutput()
{
	if (nothingCmd)
		delete [] nothingCmd;
	if (foundCmd)
		delete [] foundCmd;

	if (format)
		delete [] format;
}

void BangOutput::Emit(const char *path, const WIN32_FIND_DATA Result, const int nr, const int total)
{
#ifdef DEBUG
	LSLog(LOG_DEBUG, "ScanDir", "Preparing for bang output");
#endif

	char output[MAX_LINE_LENGTH];
	memset(output, 0, MAX_LINE_LENGTH);
	ParseCommands(output, path, Result, nr, total);
	LSExecute(NULL, output, NULL); // !bang, don't have hwnd here..

#ifdef DEBUG
	LSLog(LOG_DEBUG, "ScanDir", "Output done");
#endif

}
