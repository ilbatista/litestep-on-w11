#include "ttf.h"

bool getFontNameFromFile(LPCSTR fontPath, char *fontName)
{
	FILE *fontFile;
	int i;
	//int nPos;
	int nameLength;
	bool bFound = false;

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "testing font: %s", fontPath);
#endif

	if ( fontFile = fopen(fontPath, "rb") )
	{
#ifdef DEBUG
		LSLog(LOG_DEBUG, szAppName, "opened font");
#endif
		TT_OFFSET_TABLE ttOffsetTable;
		fread(&ttOffsetTable, sizeof(TT_OFFSET_TABLE), 1, fontFile);
		ttOffsetTable.uNumOfTables = SWAPWORD(ttOffsetTable.uNumOfTables);
		ttOffsetTable.uMajorVersion = SWAPWORD(ttOffsetTable.uMajorVersion);
		ttOffsetTable.uMinorVersion = SWAPWORD(ttOffsetTable.uMinorVersion);

		//check is this is a true type font and the version is 1.0
		if (ttOffsetTable.uMajorVersion != 1 || ttOffsetTable.uMinorVersion != 0)
		{
			LSLogPrintf(LOG_WARNING, szAppName, "wrong font version: %s", fontPath);
			return bFound;
		}
		
		TT_TABLE_DIRECTORY tblDir;
		char szTemp[MAX_PATH];
		memset(szTemp, 0, MAX_PATH);
		
#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "looking for name table, %d total", ttOffsetTable.uNumOfTables);
#endif
		for (i=0; i< ttOffsetTable.uNumOfTables; i++)
		{
			fread(&tblDir, sizeof(TT_TABLE_DIRECTORY), 1, fontFile);
			strncpy(szTemp, tblDir.szTag, 4);
			//LSLogPrintf(LOG_DEBUG, szAppName, "table%d: %s", i, szTemp);
			if ( stricmp(szTemp, "name") == 0 )
			{
				bFound = true;
#ifdef DEBUG
				LSLog(LOG_DEBUG, szAppName, "found name table");
#endif
				tblDir.uLength = SWAPLONG(tblDir.uLength);
				tblDir.uOffset = SWAPLONG(tblDir.uOffset);
				break;
			}
		}
		
		if (bFound)
		{
#ifdef DEBUG
			LSLog(LOG_DEBUG, szAppName, "looking up name table");
#endif
			fseek(fontFile, tblDir.uOffset, SEEK_SET);
			TT_NAME_TABLE_HEADER ttNTHeader;
			fread(&ttNTHeader, sizeof(TT_NAME_TABLE_HEADER), 1, fontFile);
			ttNTHeader.uNRCount = SWAPWORD(ttNTHeader.uNRCount);
			ttNTHeader.uStorageOffset = SWAPWORD(ttNTHeader.uStorageOffset);
			TT_NAME_RECORD ttRecord;
			bFound = false;
			
			for (i=0; i<ttNTHeader.uNRCount; i++)
			{
				fread(&ttRecord, sizeof(TT_NAME_RECORD), 1, fontFile);
#ifdef DEBUG
				LSLogPrintf(LOG_DEBUG, szAppName, "reading name record: %d", i);
#endif
				ttRecord.uNameID = SWAPWORD(ttRecord.uNameID);
				if (ttRecord.uNameID == 4)
				{
					ttRecord.uStringLength = SWAPWORD(ttRecord.uStringLength);
					ttRecord.uStringOffset = SWAPWORD(ttRecord.uStringOffset);
					int nPos = ftell(fontFile);
#ifdef DEBUG
					LSLog(LOG_DEBUG, szAppName, "seeking name pos");
#endif
					fseek(fontFile, tblDir.uOffset + ttRecord.uStringOffset + ttNTHeader.uStorageOffset, SEEK_SET);
#ifdef DEBUG
					LSLogPrintf(LOG_DEBUG, szAppName, "reading name, length: %d", ttRecord.uStringLength);
#endif
					fread(szTemp, sizeof(char), ttRecord.uStringLength, fontFile);
#ifdef DEBUG
					LSLogPrintf(LOG_DEBUG, szAppName, "read data: \"%s\"", szTemp);
#endif
					nameLength = strlen(szTemp);
					if (nameLength > 0)
					{
						szTemp[nameLength] = '\0';
#ifdef DEBUG
						LSLogPrintf(LOG_DEBUG, szAppName, "font name: %s", szTemp);
#endif
						strcpy(fontName, szTemp);
						bFound = true;
						break;
					}
#ifdef DEBUG
					LSLogPrintf(LOG_DEBUG, szAppName, "seek npos: %d", nPos);
#endif
					fseek(fontFile, nPos, SEEK_SET);
				}
			}		
		}
		fclose(fontFile);
	}
	else
	{
		LSLogPrintf(LOG_WARNING, szAppName, "unable to open font: %s", fontPath);
		bFound = false;
	}

	return bFound;
}
