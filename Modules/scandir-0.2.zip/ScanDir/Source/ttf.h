#ifndef __TTF_H
#define __TTF_H

#include <io.h>
#include <stdio.h>
#include <windows.h>

#include "scandir.h"

typedef struct
{
	unsigned short uMajorVersion;
	unsigned short uMinorVersion;
	unsigned short uNumOfTables;
	unsigned short uSearchRange;
	unsigned short uEntrySelector;
	unsigned short uRangeShift;
} TT_OFFSET_TABLE;

typedef struct
{
	char			szTag[4];
	unsigned long	uCheckSum;
	unsigned long	uOffset;
	unsigned long	uLength;
} TT_TABLE_DIRECTORY;

typedef struct
{
	unsigned short uFSelector;
	unsigned short uNRCount;
	unsigned short uStorageOffset;
} TT_NAME_TABLE_HEADER;

typedef struct
{
	unsigned short uPlatformID;
	unsigned short uEncodingID;
	unsigned short uLanguageID;
	unsigned short uNameID;
	unsigned short uStringLength;
	unsigned short uStringOffset;
} TT_NAME_RECORD;

#ifdef ONE
string getFontNameFromFile(LPCSTR FilePath);
#else
bool getFontNameFromFile(LPCSTR fontPath, char *fontName);
#endif

#define SWAPWORD(x) MAKEWORD( HIBYTE(x), LOBYTE(x) )
#define SWAPLONG(x) MAKELONG( SWAPWORD(HIWORD(x)), SWAPWORD(LOWORD(x)) )

#endif