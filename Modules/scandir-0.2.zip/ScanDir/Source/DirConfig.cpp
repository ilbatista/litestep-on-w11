#include "DirConfig.h"
#include "..\current\lsapi\lsapi.h"
#include "LSUtils.h"
#include "Log.h"

DirConfig::DirConfig(char* nm) :
	file(NULL),
	bang(NULL),
	findWhat(FIND_EXT),
	filter(0)
{
	name = new char[strlen(nm)+1];
	strcpy(name, nm);

	ReadConfig();
	SetFilter();
}

void DirConfig::ReadConfig()
{
	char szTemp[MAX_LINE_LENGTH];
	IncludeRootSelf = LSUtils::PrefixedGetRCBool(name, "IncludeBaseRoot", TRUE);
	DisableStartupScan = LSUtils::PrefixedGetRCBool(name, "DisableStartupScan", TRUE);

	if ( LSUtils::PrefixedGetRCLine(name, "Path", szTemp, "") )
	{
		path = new char[strlen(szTemp)+1];
		strcpy(path, szTemp);
		if (path[strlen(path)-1] != '\\')
			strcat(path, "\\");
	}
	else path = NULL;

	if ( LSUtils::PrefixedGetRCLine(name, "Files", szTemp, "") )
	{
		files = new char[strlen(szTemp)+1];
		strcpy(files, szTemp);
	}
	else files = NULL;
	
	// if file output
	if ( LSUtils::PrefixedGetRCLine(name, "OutPutFile", szTemp, "") )
	{
		file = new FileOutput(name, szTemp);
	}
	
	// if bang output
	if ( LSUtils::PrefixedGetRCBool(name, "OutPutBang", TRUE) )
	{
		bang = new BangOutput(name);
	}

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, "ScanDir", "%s config: path:%s, files:%s, fileformat:%s.", name, path, files, file->format);
#endif
}

void DirConfig::SetFilter()
{
	// setup filters according to files we're searching for
	if ( !stricmp(files, "[dirs]") )
	{
		findWhat = FIND_DIRS;
		filter = FILE_ATTRIBUTE_DIRECTORY;
	}
	else if ( !stricmp(files, "[files]") )
	{
		findWhat = FIND_FILES;
		filter = FILE_ATTRIBUTE_DIRECTORY;
	}
	else if ( !stricmp(files, "[archive]") )
	{
		findWhat = FIND_ARCHIVE;
		filter = FILE_ATTRIBUTE_ARCHIVE;
	}
	else if ( !stricmp(files, "[hidden]") )
	{
		findWhat = FIND_HIDDEN;
		filter = FILE_ATTRIBUTE_HIDDEN;
	}
	else if ( !stricmp(files, "[system]") )
	{
		findWhat = FIND_SYSTEM;
		filter = FILE_ATTRIBUTE_SYSTEM;
	}
	else if ( !stricmp(files, "[normal]") )
	{
		findWhat = FIND_NORMAL;
		filter = FILE_ATTRIBUTE_NORMAL;
	}
	else if ( !stricmp(files, "[fonts]") )
	{
		findWhat = FIND_FONTS;
	}
	else if ( !stricmp(files, "[all]") )
	{
		findWhat = FIND_ALL;
	}
	//else
	//	findWhat = FIND_ALL;
}

DirConfig::~DirConfig()
{
	delete [] name;

	if (files)
		delete [] files;
	if (path)
		delete [] path;

	if (file)
		delete file;
	if (bang)
		delete bang;
}

BOOL DirConfig::Scan()
{
	int filenr = 0;
	HANDLE dirValue;
	WIN32_FIND_DATA dirResult;
	BOOL result = FALSE;

	LSLogPrintf(LOG_DEBUG, "ScanDir", "Starting process of config: %s", name);

	char dirScan[MAX_PATH];
	strcpy(dirScan, path);

	if (findWhat == FIND_EXT)
		strcat(dirScan, files);
	else if (findWhat == FIND_FONTS)
		strcat(dirScan, "*.ttf");
	else
		strcat(dirScan, "*.*");

	// output prefix
	if (file)
	{
		file->OpenFile();
		file->OutputPrefix();
	}

	LSLogPrintf(LOG_DEBUG, "ScanDir", "Starting scan of: %s (%s)", path, dirScan);
	dirValue = FindFirstFile(dirScan, &dirResult);
	if (dirValue != INVALID_HANDLE_VALUE )
	{
		// if no restrictions, or if the filter works...
		if ( (findWhat == FIND_EXT || findWhat == FIND_ALL || findWhat == FIND_FONTS)
			|| (dirResult.dwFileAttributes & filter || (findWhat == FIND_FILES && !dirResult.dwFileAttributes & filter) ) )
		{
#ifdef DEBUG
	LSLog(LOG_DEBUG, "ScanDir", "First file matched");
#endif
			if (IncludeRootSelf || (strcmp(dirResult.cFileName, ".") && strcmp(dirResult.cFileName, "..")) )
			{
				result = TRUE;
				//filenr++;

				// add fileoutput for foundstring
				if (file)
					file->OutputFound();
			
				/*if (file)
					file->Emit(path, IncludeRootSelf, dirResult, filecount);
				if (bang)
					bang->Emit(path, IncludeRootSelf, dirResult, filecount);*/
				ResultBuffer.push_back(dirResult);
			}
		}
		else // first wasn't printed, set to zero for next line to be nr correctly
		{
			LSLog(LOG_DEBUG, "ScanDir", "First file didn't match");
			result = FALSE;
		}

#ifdef DEBUG
	LSLog(LOG_DEBUG, "ScanDir", "Checking rest of files in dir");
#endif
		while (FindNextFile(dirValue, &dirResult))
		{
			if ( (findWhat == FIND_EXT || findWhat == FIND_ALL) || dirResult.dwFileAttributes & filter )
			{
				if (IncludeRootSelf || (strcmp(dirResult.cFileName, ".") && strcmp(dirResult.cFileName, "..")) )
				{
					if (!result)
					{
						result = TRUE;
						if (file)
							file->OutputFound();
					}
					//filecount++;
					/*if (file)
						file->Emit(path, IncludeRootSelf, dirResult, filecount);
					if (bang)
						bang->Emit(path, IncludeRootSelf, dirResult, filecount);*/
					ResultBuffer.push_back(dirResult);
				}
			}
		}
		FindClose(dirValue);
		LSLog(LOG_DEBUG, "ScanDir", "Scan complete");

		int totalcount = ResultBuffer.size();
		for (vector<WIN32_FIND_DATA>::iterator i = ResultBuffer.begin(); i != ResultBuffer.end(); i++)
		{
			filenr++;
			if (file)
				file->Emit(path, *i, filenr, totalcount);
			if (bang)
				bang->Emit(path, *i, filenr, totalcount);
		}
		ResultBuffer.clear();

		// add nothingstring
		if (!result && file)
			file->OutputNothing();
	}
	else
		LSLogPrintf(LOG_NOTICE, "ScanDir", "Unable to find files in: %s", dirScan);

	// add suffix
	if (file)
	{
		file->OutputSuffix();
		file->CloseFile();
	}
	
	return result;
}