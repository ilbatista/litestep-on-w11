#ifndef __OUTPUT_H
#define __OUTPUT_H

#include <windows.h>

class Output
{
public:
	Output(char* name);
	~Output();
#ifdef DEBUG
	virtual void Emit(const char *path, const WIN32_FIND_DATA Result, const int nr, const int total);
#else
	virtual void Emit(const char *path, const WIN32_FIND_DATA Result, const int nr, const int total) = 0;
#endif

	void ParseCommands(char *output, const char *path, const WIN32_FIND_DATA Result, const int nr, const int total);
	//void OutputResult(DirConfig *config, const WIN32_FIND_DATA Result, int nr);
	void ParseEscapeCode(const char *command, char *buffer);
	int AppendSpecial(char *output, const char *command, const WIN32_FIND_DATA Result, const char *path, const int nr, const int total);
	int AppendSpecial(char *output, const char *command, const int nr, const int total);

	char *format;
};

#endif