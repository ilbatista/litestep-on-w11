#ifndef __LOG_H
#define __LOG_H

//#define DEBUG

#endif