#ifndef __BANGOUTPUT_H
#define __BANGOUTPUT_H

#include "Output.h"

class BangOutput : public Output
{
public:
	BangOutput(char* name);
	~BangOutput();

	char *foundCmd;
	char *nothingCmd;

	void Emit(const char *path, const WIN32_FIND_DATA Result, const int nr, const int total);
};

#endif