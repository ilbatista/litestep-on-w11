#include "Output.h"
#include "..\current\lsapi\lsapi.h"
#include "ttf.h"
#include "Log.h"

Output::Output(char* name)
{
}

Output::~Output()
{
}

#ifdef DEBUG
void Output::Emit(const char *path, const WIN32_FIND_DATA Result, const int nr, const int total)
{
	LSLogPrintf(LOG_DEBUG, szAppName, "dummy output for %s", path);
}
#endif

void Output::ParseCommands(char *output, const char *path, const WIN32_FIND_DATA Result, const int nr, const int total)
{
	int CommandI = 0;
	int OutI = 0; // where in output
	unsigned int ParseI = 0; // parse counter, where in input
	char *command;
	int comLength;
	//memset(output, 0, strlen(output));
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "Starting build of output string");
#endif
	for (ParseI=0; ParseI < strlen(format); ParseI++)
	{
		if (format[ParseI] == '[')
		{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "[ found");
	LSLogPrintf(LOG_DEBUG, szAppName, "output so far: \"%s\"", output);
#endif
			comLength = 0;
			int ends = 1;
			while (ends > 0 && ParseI+comLength<strlen(format)) //format[ParseI+comLength] != ']'
			{
				if (format[ParseI+comLength+1] == '[')
					ends++;
				else if (format[ParseI+comLength+1] == ']')
					ends--;

				comLength++;
				
			}
			// back up one since we found a ]
			comLength--;

			// get mem for temp command
			command = new char[comLength+1];

			for (CommandI=0; CommandI < comLength; CommandI++)
			{
				command[CommandI] = format[ParseI+CommandI+1];
			}
			command[CommandI] = '\0';
	#ifdef DEBUG
			LSLogPrintf(LOG_DEBUG, szAppName, "command found: %s", command);
	#endif

			int add = AppendSpecial(output, command, Result, path, nr, total);

			// this command was matched
			if (add > 0)
			{
				OutI += add;
				// pass by the length of the command and trailing ]
				ParseI +=(comLength+1);
#ifdef DEBUG
				LSLogPrintf(LOG_DEBUG, szAppName, "increasing parse pos with: %d, next char: %c", comLength+1, format[ParseI]);
#endif
			}
			else
			{
				output[OutI] = '[';
				OutI++;
#ifdef DEBUG
				LSLog(LOG_DEBUG, szAppName, "no strlen from added, outputting [");
#endif
			}

			// free mem of temp command
			delete [] command;
		}
		else 
		{
			output[OutI] = format[ParseI];
#ifdef DEBUG
			LSLogPrintf(LOG_DEBUG, szAppName, "writing %c on %d, from parse %d", output[OutI], OutI, ParseI);
#endif
			OutI++;
		}
	}
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "output string: %s", output);
#endif
}

/*
void Output::ParseCommands(char *output, char *path, const WIN32_FIND_DATA Result, const int nr, const int total)
{
	int CommandI = 0;
	int OutI = 0;
	unsigned int ParseI = 0;
	char *command;
	int comLength;
	memset(output, 0, strlen(output));
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "Starting build of output string");
#endif
	for (ParseI=0; ParseI < strlen(format); ParseI++, OutI++)
	{
		if (format[ParseI] == '[')
		{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "[ found");
	LSLogPrintf(LOG_DEBUG, szAppName, "output so far: \"%s\"", output);
#endif
			ParseI++;
			if (format[ParseI] == '[')
			{
				output[OutI] = '[';
				OutI++;
				ParseI++;
			}
			else
			{
				comLength = 0;
				while (format[ParseI+comLength] != ']')
				{
					comLength++;
				}
				// get mem for temp command
				command = new char[comLength+1];

				for (CommandI=0; CommandI < comLength; CommandI++)
				{
					command[CommandI] = format[ParseI+CommandI];
				}
				command[CommandI] = '\0';
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "command found: %s", command);
#endif
				OutI += AppendSpecial(output, command, Result, path, nr, total)-1;
				ParseI +=comLength;

				// free mem of temp command
				delete [] command;
			}
		}
		else if (format[ParseI] == ']')
		{
#ifdef DEBUG
	LSLog(LOG_DEBUG, szAppName, "] found");
#endif
			ParseI++;
			if (format[ParseI] == ']')
			{
				output[OutI] = ']';
				OutI++;
				ParseI++;
			}
		}
		else
			output[OutI] = format[ParseI];
	}
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "output string: %s", output);
#endif
}
*/

int Output::AppendSpecial(char *output, const char *command, const int nr, const int total)
{
	char buffer[MAX_PATH-1];
	memset(buffer, 0, MAX_PATH-1);

	#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "trying command: %s", command);
	#endif

	if (command[0] == '\\')
	{
		ParseEscapeCode(command, buffer);
	}

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "Appending text from command \"%s\": %s", command, buffer);
	LSLogPrintf(LOG_DEBUG, szAppName, "Current length of output \"%s\" : %d", output, strlen(output));
#endif
	
	strcat(output, buffer);
	return strlen(buffer);

}

int Output::AppendSpecial(char *output, const char *command, const WIN32_FIND_DATA Result, const char *path, const int nr, const int total)
{
	char buffer[MAX_PATH-1];
	memset(buffer, 0, MAX_PATH-1);

	#ifdef DEBUG
		LSLogPrintf(LOG_DEBUG, szAppName, "trying command: %s", command);
	#endif

	if (command[0] == '\\')
	{
		ParseEscapeCode(command, buffer);
	}
	else
	{
		if ( !stricmp(command, "filename") )
			sprintf(buffer, "%s", Result.cFileName);

		else if ( !stricmp(command, "path") )
			sprintf(buffer, "%s", path);

		else if ( !stricmp(command, "filenr") )
			sprintf(buffer, "%d", nr);

		else if ( !stricmp(command, "filestotal") )
			sprintf(buffer, "%d", total);

		else if ( !stricmp(command, "fontname") ) {
			char *fontPath;
			fontPath = new char[strlen(Result.cFileName) + strlen(path) + 2];
			strcpy(fontPath, path);
			strcat(fontPath, "\\");
			strcat(fontPath, Result.cFileName);
			getFontNameFromFile(fontPath, buffer);
			delete [] fontPath;
		}

		else if ( !stricmp(command, "modified") )
		{
			SYSTEMTIME tm;
			FileTimeToSystemTime(&(Result.ftLastWriteTime), &tm);
			sprintf(buffer, "%04d-%02d-%02d %02d:%02d:%02d", tm.wYear, tm.wMonth, tm.wDay, tm.wHour, tm.wMinute, tm.wSecond);
			//sprintf(buffer, "%s", Result->ftLastWriteTime);
		}

		else if ( !stricmp(command, "created") )
		{
			SYSTEMTIME tm;
			FileTimeToSystemTime(&(Result.ftCreationTime), &tm);
			sprintf(buffer, "%04d-%02d-%02d %02d:%02d:%02d", tm.wYear, tm.wMonth, tm.wDay, tm.wHour, tm.wMinute, tm.wSecond);
			//sprintf(buffer, "%s", Result->ftCreationTime);
		}

		else if ( !stricmp(command, "accessed") )
		{
			SYSTEMTIME tm;
			FileTimeToSystemTime(&(Result.ftLastAccessTime), &tm);
			sprintf(buffer, "%04d-%02d-%02d %02d:%02d:%02d", tm.wYear, tm.wMonth, tm.wDay, tm.wHour, tm.wMinute, tm.wSecond);
			//sprintf(buffer, "%s", Result->ftLastAccessTime);
		}

		else if ( !stricmp(command, "size") )
			sprintf(buffer, "%d", (Result.nFileSizeHigh * (MAXDWORD+1)) + Result.nFileSizeLow);

		else if ( !stricmp(command, "extension") )
		{
			if (strrchr(Result.cFileName, '.') )
				strcpy(buffer, strrchr(Result.cFileName, '.') );
			else
				strcpy(buffer, " ");
		}
		else if ( !stricmp(command, "attrib") )
		{
			if (Result.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE)
				strcpy(buffer, "archive");
			else if (Result.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				strcpy(buffer, "folder");
			else 
				strcpy(buffer, "unknown");

			if (Result.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)
				strcat(buffer, ", hidden");
			if (Result.dwFileAttributes & FILE_ATTRIBUTE_READONLY)
				strcat(buffer, ", read only");
			if (Result.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM)
				strcat(buffer, ", system file");
			if (Result.dwFileAttributes & FILE_ATTRIBUTE_ENCRYPTED)
				strcat(buffer, ", system file");
			}
		else
		{
			// unknown command handling
			//sprintf(buffer, "[%s]", command);
			buffer[0] = '\0';
			LSLogPrintf(LOG_WARNING, szAppName, "no command match found for: %s", command);
		}
	}
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, szAppName, "Appending text from command \"%s\": %s", command, buffer);
	LSLogPrintf(LOG_DEBUG, szAppName, "Current length of output \"%s\" : %d", output, strlen(output));
#endif
	
	strcat(output, buffer);
	return strlen(buffer);
}

// converts escape codes
void Output::ParseEscapeCode(const char *codestring, char *buffer)
{
	if (codestring[1] == 'n')
		buffer[0] = '\n';
	else if (codestring[1] == 't')
		buffer[0] = '\t';
	else if (codestring[1] == 'v')
		buffer[0] = '\v';
	else if (codestring[1] == '\"')
		buffer[0] = '\"';
	else if (codestring[1] == '\'')
		buffer[0] = '\'';
	else if (codestring[1] == '\\')
		buffer[0] = '\\';
	else if (codestring[1] == '{')
		buffer[0] = '[';
	else if (codestring[1] == '}')
		buffer[0] = ']';
	else if (codestring[1] == '@')
		buffer[0] = '$';
	else
	{
		// some one did a config mistake, but don't hold it against them...
		LSLogPrintf(LOG_WARNING, szAppName, "unknown escape code: %s", codestring);
		//buffer[0] = '\\';
		
		// return empty string
		buffer[0] = '\0';
	}
	// close string
	buffer[1] = '\0';

}