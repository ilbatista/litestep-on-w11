#ifndef __SCANDIR_H
#define __SCANDIR_H

//#define DEBUG
//#define FONT_DEBUG

#ifdef FONT_DEBUG
	#include <shlobj.h>
#endif

#include <windows.h>
#include "DirConfig.h"
#include "BangOutput.h"
#include "FileOutput.h"
#include "../current/lsapi/lsapi.h"
#include "../current/lsapi/lswinbase.h"

const char szAppName[] = "ScanDir"; // Our window class, etc
const char rcsRevision[] = "$Revision: 0.2 $"; // Our Version
const char rcsId[] = "$Id: ScanDir.cpp,v 0.2 17:42:48 Vendicator Exp $"; // The Full RCS ID.

#define CODE_ERROR -1
#define CODE_OK 1

struct ConfigList
{
	DirConfig *config;
};

class scandir : public Window
{
private:
	ConfigList *configs;
	int NrConfigs;
	bool StartupDone;
	bool Scanning;
	DWORD ScanThreadID;
	HANDLE hScanThread;

public:
	scandir(HWND parentWnd, int& code);
	~scandir();

	static void ScanAllFolders();

	void BangSetTheme(HWND, LPCSTR);
	void BangScanDir(HWND, LPCSTR);

private:
	void readConfig();
	void removeConfig();
	BOOL GetRCLineJoinedName(const char *name, const char *setting, char *buffer, char *defaultVal);
	void GetRCBoolJoinedName(const char *name, const char *setting, BOOL *retValue, bool def);

	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
	void onLMRecycle(Message& message);
};

void BangTheme(HWND, LPCSTR);
void BangScan(HWND, LPCSTR);

#ifdef DEBUG
	void BangTestFont(HWND, LPCSTR);
#endif


extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
};

#endif
