/////////////////////////////
// Module: LSCount v1.0
// Author: MrJukes
// Released: 6/22/00
//

The purpose of this module is to get an accurate account of how many people run LiteSTEP.
Thank you for helping us out with this.

To Load:
  LoadModule c:\litestep\lscount.dll

Usage:
  There really is no usage.  It will connect to the server running on pimpin.net ONLY
  the first time you run the module.  After that it will never connect again.  You
  can have it display your user number on your desktop in any manner you wish, or you
  can disable that feature.  After the first time you run the module, you do not need
  to load it again if you do not want to display your number on your desktop.

*NOTE*
  Try to not recycle while the module is registering with the server.  I would consider
  this action "playing with fire".  There is no cancel button while it is registering.
  It should happen pretty quickly, but if it can't connect to the server, it will
  time out after a minute.

Step.rc:
  LSCountX 0 ; X Position on desktop (Negative values accepted)
  LSCountY 0 ; Y Position on desktop (Negative values accepted)
  LSCountW 100 ; Width
  LSCountH 24  ; Height
  LSCountPreText "LS User: " ; What to display in front of your user number
  LSCountFontFace Arial ; Font to use to display
  LSCountFontSize 16    ; Size of that font
  LSCountFontColor 0x00000000 ; Color of the font
  LSCountNoDisplay ; If this is present, LSCount does not display your LS User #
  LSCountAlwaysOnTop ; If this is present, LSCount will always be on top.

Have Fun,
	MrJukes

*DISCLAIMER*
This module does not send any information about you, the user, or you computer.
It simply connects to the server, sends the server its own password to verify
that it is the module connecting to the server (and not somebody trying to screw
up the count), and then disconnects.  Besides, if I wanted all your passwords, LSMail
would have been a better choice for me anyway. =P