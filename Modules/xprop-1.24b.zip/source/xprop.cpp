#include <windows.h>
#include "../2001-08-25/lsapi/lsapi.h"
#include "exports.h"

#ifndef CAPTUREBLT
#define CAPTUREBLT 0x40000000
#endif
#undef COPYCONTENTS

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
VOID CALLBACK TimerMouse(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime);
void LoadSetup();

int magnify=2;
int ScreenX, ScreenY;
char* szAppName = "xprop";
HWND hwndMain, hwndDesktop, hwndParent;
HBITMAP hbmpBG;
HBITMAP hCrosshair;
int iCrosshairH, iCrosshairW, iCrosshairX, iCrosshairY;
BOOL crosshair_fInvert;
BITMAP bmpBG;
HFONT font;
HPEN pen;
POINT p, o;
COLORREF text_color, crosshair_color, color_inverted, clrToInvert;
char format[256] = "";
int timer, offset_x, offset_y;
int x, y;
int mag_x, mag_y, mag_w, mag_h;
int text_x, text_y, text_w, text_h;
int crosshair_size;
BOOL FOLLOW=TRUE, LOCKED=FALSE, FROZEN=FALSE;

// Clipboard copying stuff
HBITMAP hbmpClipboard = NULL;
BOOL fEnableClipboard = FALSE;
COLORREF g_clrLastPixel = RGB(0,0,0);

// Color box options
BOOL fEnableColorBox = FALSE;
RECT rColorBox;

// Other stuff
BOOL fOnTop = TRUE;
BOOL fNotMoveable = FALSE;
BOOL fEnableTrans = FALSE;

void BangToggleInversion(HWND caller, const char* args)
{
	crosshair_fInvert = !crosshair_fInvert;
}

void BangZoomIn(HWND caller, const char* args)
{
	magnify*=2;
	InvalidateRect(hwndMain, NULL, TRUE);
}

void BangZoomOut(HWND caller, const char* args)
{
	magnify/=2;
	if (magnify == 0) magnify=1;
	InvalidateRect(hwndMain, NULL, TRUE);
}

void BangShow(HWND caller, const char* args) 
{
	SetTimer(hwndMain, 0, timer, (TIMERPROC)TimerMouse);
	ShowWindow(hwndMain, SW_SHOW); 
}

void BangHide(HWND caller, const char* args) 
{ 
	ShowWindow(hwndMain, SW_HIDE);
	KillTimer(hwndMain, 0);
}

void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void BangSetOrigin(HWND caller, const char* args) 
{ 
	o = p;
	InvalidateRect(hwndMain, NULL, TRUE);
}

void BangResetOrigin(HWND caller, const char* args) 
{ 
	o.x = 0;
	o.y = 0;
	InvalidateRect(hwndMain, NULL, TRUE);
}

void BangLock(HWND caller, const char* args)
{
	if (LOCKED)
	{
		LOCKED=FALSE;
	}
	else
	{
		LOCKED=TRUE;
	}
}

void BangFreeze(HWND caller, const char* args)
{
	if (FROZEN)
	{
		FROZEN=FALSE;
	}
	else
	{
		FROZEN=TRUE;
	}
}

void BangToggleOnTop(HWND caller, const char* args)
{
	if ( fOnTop ) {
		SetWindowPos(hwndMain, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	}
	else {
		SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	}
	fOnTop = !fOnTop;
}


void BangCopyContents(HWND caller, const char* args)
{
	if (  OpenClipboard(hwndMain) ) {
			EmptyClipboard();
			HBITMAP hTemp = (HBITMAP) CopyImage(hbmpClipboard, IMAGE_BITMAP, 0, 0, 0);
			SetClipboardData(CF_BITMAP, hTemp);
			CloseClipboard();
			DeleteObject(hTemp);
	}
}

void BangCopyHexCode(HWND caller, const char* args)
{
	
	if ( OpenClipboard(hwndMain) ) {
		EmptyClipboard();
		
		//size_t iLen = 7;
		HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, 7);
		if ( hGlobal != NULL ) {
			TCHAR * lock = (LPTSTR) GlobalLock(hGlobal);
			sprintf(lock, "%02X%02X%02X", GetRValue(g_clrLastPixel), GetGValue(g_clrLastPixel), GetBValue(g_clrLastPixel));
			//memcpy(lock, s, iLen );
			GlobalUnlock(hGlobal);
			SetClipboardData(CF_TEXT, hGlobal);
		}
	}
	CloseClipboard();
}

void BangMoveable(HWND caller, const char* args)
{
	fNotMoveable = !fNotMoveable;
}

VOID CALLBACK TimerMouse(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
	POINT np;
	GetCursorPos(&np);

	if (p.x != np.x || p.y != np.y)
	{
		p = np;
		if (!LOCKED) SetWindowPos(hwndMain, HWND_TOPMOST, p.x+offset_x, p.y+offset_y, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE);
	}

	if (!FROZEN) InvalidateRect(hwndMain, NULL, TRUE);
}

void LoadSetup()
{
	char temp[256] = "";
	int itemp;

	o.x = 0;
	o.y = 0;

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);
	hwndDesktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!hwndDesktop) hwndDesktop = GetDesktopWindow();
	if (!hwndDesktop)
	{
		MessageBox(NULL, "Error: Could not locate the desktop window", szAppName, MB_OK | MB_ICONERROR);
		return;
	}

	AddBangCommand("!XPropZoomIn", BangZoomIn);
	AddBangCommand("!XPropZoomOut", BangZoomOut);
	AddBangCommand("!XPropShow", BangShow);
	AddBangCommand("!XPropHide", BangHide);
	AddBangCommand("!XPropToggle", BangToggle);
	AddBangCommand("!XPropSetOrigin", BangSetOrigin);
	AddBangCommand("!XPropResetOrigin", BangResetOrigin);
	AddBangCommand("!XPropFreeze", BangFreeze);
	AddBangCommand("!XPropLock", BangLock);
	AddBangCommand("!XPropToggleInversion", BangToggleInversion);
	AddBangCommand("!XPropToggleOnTop", BangToggleOnTop);
	AddBangCommand("!XPropMoveable", BangMoveable);
	AddBangCommand("!XPropCopyHexCode", BangCopyHexCode);
	
	// ------- Clipboard options
	fEnableClipboard = GetRCBool("XPropEnableClipboard", TRUE);

	if ( fEnableClipboard )
		AddBangCommand("!XPropCopyContents", BangCopyContents);

	// ------- Basic Cross hair options
	crosshair_size = GetRCInt("XPropCrosshairSize", 10);
	crosshair_color = GetRCColor("XPropCrosshairColor", 0x00000000);
	crosshair_fInvert = GetRCBool("XPropCrosshairInvert", TRUE);

	pen = CreatePen(PS_DOT, 0, crosshair_color);
	
	timer = GetRCInt("XPropTimer", 50);
	offset_x = GetRCInt("XPropOffsetX", 25);
	offset_y = GetRCInt("XPropOffsetY", 25);

	x = GetRCInt("XPropX", 0);
	y = GetRCInt("XPropY", 0);
	LOCKED = GetRCBool("XPropStartLocked", TRUE);

	mag_x = GetRCInt("XPropMagWindowX", 6);
	mag_y = GetRCInt("XPropMagWindowY", 6);
	mag_w = GetRCInt("XPropMagWindowW", 88);
	mag_h = GetRCInt("XPropMagWindowH", 88);

	text_x = GetRCInt("XPropTextWindowX", 7);
	text_y = GetRCInt("XPropTextWindowY", 98);
	text_w = GetRCInt("XPropTextWindowW", 88);
	text_h = GetRCInt("XPropTextWindowH", 31);

	itemp = GetRCInt("XPropFontSize", 11);
	GetRCString("XPropFontFace", temp, "Arial", 256);
	font = CreateFont(itemp, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);
	GetRCString("XPropFormat", format, "X: %d Y: %d\nR: %d G: %d\nB: %d - #%06lx", 256);
	char* c;
	while ((c = strstr(format, "\\n")) != NULL)
	{
		char* q;
		*c='\n';
		c++;
		for (q=c+1; *q; q++, c++)
		{
			*c = *q;
		}
		*c = '\0';
	}
	text_color = GetRCColor("XPropFontColor", 0x00000000);

	GetRCString("XPropBG", temp, "xprop.bmp", 256);
	hbmpBG = LoadLSImage(temp, temp);

	// ------ Bitmap cross hair options
	GetRCString("XPropCrosshairBitmap", temp, ".none", 256);
	hCrosshair = LoadLSImage(temp, temp);

	iCrosshairW = GetRCInt("XPropCrosshairBitmapW", 15);
	iCrosshairH = GetRCInt("XPropCrosshairBitmapH", 15);
	// make a guess for X & Y
	iCrosshairX = GetRCInt("XPropCrosshairBitmapX", (iCrosshairW%2 == 1) ? mag_x+(mag_w/2)-(iCrosshairW/2) : mag_x+(mag_w/2)-(iCrosshairW/2) + 1);
	iCrosshairY = GetRCInt("XPropCrosshairBitmapY", (iCrosshairH%2 == 1) ? mag_y+(mag_h/2)-(iCrosshairH/2) : mag_y+(mag_h/2)-(iCrosshairH/2) + 1);

	color_inverted = GetRCColor("XPropInvertedColor", 0xFF000000);
	if ( color_inverted == 0xFF000000 )
		clrToInvert = RGB(255,255,255);
	else
		clrToInvert = color_inverted;

	// ------ Color Box Options
	fEnableColorBox = GetRCBool("XPropColorBox", TRUE);
	rColorBox.top = GetRCInt("XPropColorBoxY", 0);
	rColorBox.left = GetRCInt("XPropColorBoxX", 0);
	rColorBox.bottom = GetRCInt("XPropColorBoxH", 5) + rColorBox.top;
	rColorBox.right = GetRCInt("XPropColorBoxW", 5) + rColorBox.left;

	// ------ Other settings
	fOnTop = GetRCBool("XPropNotAlwaysOnTop", FALSE);
	fNotMoveable = GetRCBool("XPropNotMoveable", TRUE);
	fEnableTrans = GetRCBool("XPropZoomTransparentWindows", TRUE);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{

	WNDCLASS wc;

	hwndParent = parent;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}
 
	LoadSetup();

	if (hbmpBG)
	{
		int msgs[] = {LM_GETREVID, 0};

		GetObject(hbmpBG, sizeof(bmpBG), &bmpBG);

		hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, 
								  szAppName, szAppName, 
								  WS_POPUP, 
								  x, y, 
								  bmpBG.bmWidth, bmpBG.bmHeight, 
								  NULL, NULL, dllInst, NULL);
		SetWindowLong(hwndMain, GWL_USERDATA, 0x49474541);
		if (!hwndMain) return 1;

		
		if (fOnTop)
		{
			SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
		}

		SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);

		//SetWindowBitmapRgn(hwndMain, hbmpBG);
		HRGN hrgn = BitmapToRegion(hbmpBG, RGB(255,0,255), 0, 0, 0);
		SetWindowRgn(hwndMain, hrgn, TRUE);
		/*if ( !DeleteObject(hrgn) )
		{
			char msg[1000];
			sprintf(msg, "Unable to delete object, possible GDI leak.\nHandle is %X", hrgn);
			MessageBox(0, msg, "xprop - Error!", MB_OK);
		}*/
		if (GetRCBool("XPropStartHidden", FALSE))
		{
			SetTimer(hwndMain, 0, timer, (TIMERPROC)TimerMouse);
			ShowWindow(hwndMain, SW_SHOWNORMAL);
		}
	}
	
	return 0;
}

int quitModule(HINSTANCE dll)
{
	int msgs[] = {LM_GETREVID, 0};

	RemoveBangCommand("!XPropZoomIn");
	RemoveBangCommand("!XPropZoomOut");
	RemoveBangCommand("!XPropShow");
	RemoveBangCommand("!XPropHide");
	RemoveBangCommand("!XPropToggle");
	RemoveBangCommand("!XPropSetOrigin");
	RemoveBangCommand("!XPropResetOrigin");
	RemoveBangCommand("!XPropFreeze");
	RemoveBangCommand("!XPropLock");
	RemoveBangCommand("!XPropToggleInversion");
	RemoveBangCommand("!XPropToggleOnTop");
	RemoveBangCommand("!XPropMoveable");
	RemoveBangCommand("!XPropCopyHexCode");
	if ( fEnableClipboard ) {
		RemoveBangCommand("!XPropCopyContents");
		if ( hbmpClipboard )
			DeleteObject(hbmpClipboard);
	}

	DeleteObject(hbmpBG);
	DeleteObject(font);
	DeleteObject(pen);
	DeleteObject(hCrosshair);
	KillTimer(hwndMain, 0);

	SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	DestroyWindow(hwndMain);

	UnregisterClass(szAppName, dll);

	return 0;
}

// This is a modified version of TransparentBltLS.  I didn't want to use 
// Microsoft's TransparentBlt because on 98 systems it causes memory leaks (and its
// not available on Win95).  This modification handles the inversion.
void TransparentBltXProp( HDC hdcDst, int nXDest, int nYDest, int nWidth, int nHeight, HDC hdcSrc, int nXSrc, int nYSrc, COLORREF colorTransparent)
{
		HDC hdcMem, hdcMask, hdcDstCpy;
		HBITMAP hbmMask, hbmMem, hbmDstCpy;
		HBITMAP hbmOldMem, hbmOldMask, hbmOldDstCpy;

		// create a destination compatble dc containing
		// a copy of the destination dc
		hdcDstCpy	= CreateCompatibleDC(hdcDst);
		hbmDstCpy	= CreateCompatibleBitmap(hdcDst, nWidth, nHeight);
		hbmOldDstCpy = (HBITMAP)SelectObject(hdcDstCpy, hbmDstCpy);

		BitBlt(hdcDstCpy,0,0,nWidth,nHeight,hdcDst,nXDest,nYDest,SRCCOPY);
		
		// create a destination compatble dc containing
		// a copy of the source dc
		hdcMem	= CreateCompatibleDC(hdcDst);
		hbmMem	= CreateCompatibleBitmap(hdcDst, nWidth, nHeight);
		hbmOldMem = (HBITMAP)SelectObject(hdcMem, hbmMem);

		BitBlt(hdcMem,0,0,nWidth,nHeight,hdcSrc,nXSrc,nYSrc,SRCCOPY);

		// the transparent color should be selected as
		// bkcolor into the memory dc
		SetBkColor(hdcMem, colorTransparent);

		// Create monochrome bitmap for the mask
		hdcMask	= CreateCompatibleDC(hdcDst);
		hbmMask = CreateBitmap(nWidth, nHeight, 1, 1, NULL);
		hbmOldMask = (HBITMAP)SelectObject(hdcMask, hbmMask);
		

		// Create the mask from the memory dc
		BitBlt(hdcMask,0,0,nWidth,nHeight,hdcMem,0,0,SRCCOPY);

		// Set the background in hdcMem to black. Using SRCPAINT with black
		// and any other color results in the other color, thus making
		// black the transparent color
		SetBkColor(hdcMem, RGB(0,0,0));
		SetTextColor(hdcMem, RGB(255,255,255));

		BitBlt(hdcMem,0,0,nWidth,nHeight,hdcMask,0,0,SRCAND);

		// Set the foreground to black. See comment above.
		SetBkColor(hdcDst, RGB(255,255,255));
		SetTextColor(hdcDst, RGB(0,0,0));

		BitBlt(hdcDstCpy,0,0,nWidth,nHeight,hdcMask,0,0,SRCAND);

		// Combine the foreground with the background
		BitBlt(hdcDstCpy,0,0,nWidth,nHeight,hdcMem,0,0,SRCPAINT);
		
		if ( crosshair_fInvert ) {
			COLORREF clrOrig, clrInverted;
			int x, y;
			
			// go through each row/column and invert the appropriate pixels
			for ( x = 0; x < nWidth; x++ ) {
				for ( y = 0; y < nHeight; y++ ) {
					clrOrig = GetPixel(hdcDst, x + iCrosshairX, y + iCrosshairY);
					if ( clrOrig > RGB(119,119,119) && clrOrig < RGB(137, 137, 137) )
						clrInverted = RGB(0,0,0);
					else
						clrInverted = RGB( ~GetRValue(clrOrig), ~GetGValue(clrOrig), ~GetBValue(clrOrig));
					
					// if the user hasn't specified an invert color then we invert the whole crosshair
					if ( color_inverted == 0xFF000000  && GetPixel(hdcMask, x, y) != RGB(255,255,255) ) {
						SetPixel(hdcDstCpy, x, y, clrInverted );
					}
					// otherwise just invert the crosshair pixels that are the same as clrToInvert
					else if ( GetPixel(hdcSrc, x, y) == clrToInvert ) {
						SetPixel(hdcDstCpy, x, y, clrInverted );
					}
				}
			}
		}


		// now we have created the image we want to blt
		// in the destination copy dc
		BitBlt(hdcDst,nXDest,nYDest,nWidth,nHeight,hdcDstCpy,0,0,SRCCOPY);

		SelectObject(hdcMask, hbmOldMask);
		DeleteObject(hbmMask);
		DeleteDC(hdcMask);

		SelectObject(hdcMem, hbmOldMem);
		DeleteObject(hbmMem);
		DeleteDC(hdcMem);

		SelectObject(hdcDstCpy, hbmOldDstCpy);
		DeleteObject(hbmDstCpy);
		DeleteDC(hdcDstCpy);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (msg == LM_GETREVID)
	{
		LPSTR buf = (LPSTR)(lParam);

		switch (wParam)
		{
			case 0:
				sprintf(buf, "XProp 1.24b (repugnant)\0");
			break;
			case 1:
				sprintf(buf, "XProp 1.24b (repugnant)\0");
			break;
			default:
				sprintf(buf, "XProp 1.24b (repugnant)\0");
		}
		return strlen(buf);
	}

	switch (msg)
	{
		case WM_ERASEBKGND: return 0;

		case WM_NCHITTEST:
		{
			if ( ! fNotMoveable ) return HTCAPTION;
		}

		case WM_NCPAINT:
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC ddc = GetWindowDC(hwndDesktop);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp, oldbuf, oldsrc;
			COLORREF pix;
			RECT r;
			char to[256] = "";
			
			bufbmp = CreateCompatibleBitmap(hdc, bmpBG.bmWidth, bmpBG.bmHeight);
			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);

			oldsrc = (HBITMAP)SelectObject(src, hbmpBG);
			BitBlt(buf, 0, 0, bmpBG.bmWidth, bmpBG.bmHeight, src, 0, 0, SRCCOPY);
			SelectObject(src, oldsrc);

			if (!FROZEN) 
			{
				if ( fEnableTrans )
				{
					//BitBlt(buf, mag_x, mag_y, mag_w, mag_h, ddc, p.x-mag_w/(magnify*2), p.y-mag_h/(magnify*2), CAPTUREBLT|SRCCOPY);
					
					HDC transBuf = CreateCompatibleDC(NULL);
					HBITMAP transBmp = CreateCompatibleBitmap(hdc, bmpBG.bmWidth, bmpBG.bmHeight);
					HBITMAP oldTransBmp = (HBITMAP)SelectObject(transBuf, transBmp);
					BitBlt(transBuf, 0, 0, mag_w, mag_h, ddc, p.x-mag_w/(magnify*2), p.y-mag_h/(magnify*2), CAPTUREBLT|SRCCOPY);
					StretchBlt(buf, mag_x, mag_y, mag_w, mag_h, transBuf, 0, 0, mag_w/magnify, mag_h/magnify,SRCCOPY); //CAPTUREBLT
					//StretchBlt(buf, mag_x, mag_y, mag_w, mag_h, transBuf, p.x-mag_w/(magnify*2), p.y-mag_h/(magnify*2), mag_w/magnify, mag_h/magnify, 0x40000000|SRCCOPY); //CAPTUREBLT
					SelectObject(transBuf, oldTransBmp);
					if ( !DeleteObject(transBmp) ) 
						MessageBox(0, "Error", 0, MB_OK);
					if ( ! DeleteDC(transBuf) )
						MessageBox(0, "ErrorDC", 0, MB_OK);
					
				}
				else {
					StretchBlt(buf, mag_x, mag_y, mag_w, mag_h, ddc, p.x-mag_w/(magnify*2), p.y-mag_h/(magnify*2), mag_w/magnify, mag_h/magnify, 0x40000000|SRCCOPY); //CAPTUREBLT
				}
				//BitBlt(buf, mag_x, mag_y, mag_w, mag_h, ddc, p.x-mag_w/(magnify*2), p.y-mag_h/(magnify*2), CAPTUREBLT|SRCCOPY);
				if ( fEnableClipboard ) {
					if ( hbmpClipboard) 
						if ( !DeleteObject(hbmpClipboard) )
							MessageBox(0, "Unable to delete bitmap.  Please email repugnant2k@hotmail.com", "XProp - WndProc", MB_OK);
					HDC mdc2 = CreateCompatibleDC(ddc);
					hbmpClipboard = CreateCompatibleBitmap(ddc, mag_w, mag_h);
					HGDIOBJ obj = SelectObject(mdc2, hbmpClipboard);
					//StretchBlt(mdc2, 0, 0, mag_w, mag_h, ddc, p.x-mag_w/(magnify*2), p.y-mag_h/(magnify*2), mag_w/magnify, mag_h/magnify, SRCCOPY);
					BitBlt(mdc2, 0, 0, mag_w, mag_h, buf, mag_x, mag_y, SRCCOPY);
					hbmpClipboard = (HBITMAP) SelectObject(mdc2, obj);
					if ( !DeleteDC(mdc2) ) MessageBox(0, "Unable to delete device context.  Please email repugnant2k@hotmail.com", "XProp - WndProc", MB_OK);
				}
				SelectObject(buf, font);
				SetBkMode(buf, TRANSPARENT);
				SetTextColor(buf, text_color);
				g_clrLastPixel = pix = GetPixel(buf, mag_x+(mag_w/2), mag_y+(mag_h/2));
				sprintf(to, format, p.x-o.x, p.y-o.y, GetRValue(pix), GetGValue(pix), GetBValue(pix), RGB(GetBValue(pix), GetGValue(pix), GetRValue(pix)));
				SetRect(&r, text_x, text_y, text_x+text_w, text_y+text_h);
				DrawText(buf, to, strlen(to), &r, DT_EDITCONTROL | DT_WORDBREAK | DT_NOCLIP);

				if ( fEnableColorBox ) {
					HBRUSH hBrush = CreateSolidBrush(pix);
					FillRect(buf, &rColorBox, hBrush);
					DeleteObject(hBrush);
				}
			}

			// if we have a crosshair bitmap then paint that, otherwise use the old style.
			if ( hCrosshair  ) {
				HDC hairBuf = CreateCompatibleDC(NULL);
				SelectObject(hairBuf, hCrosshair);
				TransparentBltXProp(buf, iCrosshairX, iCrosshairY, iCrosshairW, iCrosshairH, hairBuf, 0,0, 0xFF00FF);
				DeleteDC(hairBuf);
			}
			else {
				if ( crosshair_fInvert )
					SetROP2(buf, R2_NOT);

				SelectObject(buf, pen);
				
				MoveToEx(buf, mag_x+(mag_w/2), mag_y+(mag_h/2)-crosshair_size, NULL);
				LineTo(buf, mag_x+(mag_w/2), mag_y+(mag_h/2)+crosshair_size);

				MoveToEx(buf, mag_x+(mag_w/2)-crosshair_size, mag_y+(mag_h/2), NULL);
				LineTo(buf, mag_x+(mag_w/2)+crosshair_size, mag_y+(mag_h/2));

				if ( crosshair_fInvert )
					SetROP2(buf, R2_COPYPEN);
			}

			BitBlt(hdc, 0, 0, bmpBG.bmWidth, bmpBG.bmHeight, buf, 0, 0, SRCCOPY);

			DeleteDC(src);
			DeleteObject(oldsrc);
			SelectObject(buf, oldbuf);
			DeleteObject(bufbmp);
			DeleteDC(buf);
			DeleteObject(oldbuf);
			ReleaseDC(hwndDesktop, ddc);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;

			if (pos->x < 0) pos->x = 0;
			else if (pos->x + bmpBG.bmWidth > ScreenX) 
			{
				if (!LOCKED) pos->x = p.x - bmpBG.bmWidth - offset_x;
				else pos->x = ScreenX - bmpBG.bmWidth;
			}

			if (pos->y < 0) pos->y = 0;
			else if (pos->y + bmpBG.bmHeight > ScreenY) 
			{
				if (!LOCKED) pos->y = p.y - bmpBG.bmHeight - offset_y;
				else pos->y = ScreenY - bmpBG.bmHeight;
			}
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}
