//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#include "common.h"
#include "Button.h"
#include "ButtonMgr.h"
#include "Window.h"

//----------------------------------------------------------------------------
// Constructor
//----------------------------------------------------------------------------

ButtonMgr::ButtonMgr()
{
	m_hwndToolTips = NULL;
	m_rgButtons = NULL;
	m_cButtons = 0;
}

//----------------------------------------------------------------------------
// Destructor
//----------------------------------------------------------------------------

ButtonMgr::~ButtonMgr()
{
}

//----------------------------------------------------------------------------
// AlwaysOnTop
//----------------------------------------------------------------------------

void
ButtonMgr::AlwaysOnTop(LPCTSTR pszName)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->AlwaysOnTop();
	}
}

//----------------------------------------------------------------------------
// Create
//----------------------------------------------------------------------------

BOOL
ButtonMgr::Create(HINSTANCE hInstance)
{
	m_hInstance = hInstance;

	// Create main window
	m_hWnd = CreateWindowEx(WS_EX_TOOLWINDOW,
		WC_LSBUTTONMGR, NULL,
		WS_CHILD,
		0, 0, 0, 0,
		GetLitestepWnd(), NULL, hInstance, this);

	if (!m_hWnd)
	{
		return FALSE;
	}

	// Create tooltip control
	m_hwndToolTips = CreateWindowEx(WS_EX_TOPMOST,
		TOOLTIPS_CLASS, NULL,
		TTS_ALWAYSTIP | TTS_NOPREFIX,
		0, 0, 0, 0,
		m_hWnd, NULL, hInstance, NULL);

	if (!m_hwndToolTips)
	{
		DestroyWindow(m_hWnd);
		m_hWnd = NULL;
		return FALSE;
	}

	// Create buttons
	CreateButtons();

	// Register for messages from LS
	UINT rguMsgs[] = { LM_GETREVID };
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM) m_hWnd, (LPARAM) rguMsgs);

	return TRUE;
}

//----------------------------------------------------------------------------
// CreateButton
//----------------------------------------------------------------------------

void
ButtonMgr::CreateButton(LPCTSTR pszName, HWND hwndParent)
{
	// Ignore requests to create buttons that already exist
	if (FindButton(pszName) >= 0)
	{
		return;
	}

	// Create the button
	Button *pButton = new Button(pszName);

	if (!pButton)
	{
		return;
	}

	if (!pButton->Create(m_hInstance, hwndParent))
	{
		delete pButton;
		return;
	}

	// Add a tooltip for the button
	TOOLINFO ti;

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_IDISHWND | TTF_SUBCLASS;
	ti.hwnd = m_hWnd;
	ti.uId = (UINT_PTR) pButton->GetWindow();
	ti.lpszText = LPSTR_TEXTCALLBACK;

	SendMessage(m_hwndToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti);

	// Add it to the list
	m_rgButtons = (Button **) realloc(m_rgButtons, (m_cButtons + 1) * sizeof(Button *));

	if (!m_rgButtons)
	{
		m_cButtons = 0;
		return;
	}

	m_rgButtons[m_cButtons++] = pButton;
}

//----------------------------------------------------------------------------
// CreateButtons
//----------------------------------------------------------------------------

void
ButtonMgr::CreateButtons()
{
	LPVOID pvFile = LCOpen(NULL);

	if (pvFile)
	{
		TCHAR szLine[MAX_LINE];

		// Read all the *Button lines from step.rc
		while (LCReadNextConfig(pvFile, _T("*Button"), szLine, MAX_LINE))
		{
			TCHAR szKey[MAX_KEY];
			TCHAR szName[MAX_NAME];
			LPTSTR rgszBuffers[2];
			
			rgszBuffers[0] = szKey;
			rgszBuffers[1] = szName;

			if (LCTokenize(szLine, rgszBuffers, 2, NULL) >= 2)
			{
				// For each one we find, create a button
				CreateButton(szName);
			}
		}

		LCClose(pvFile);
	}
}

//----------------------------------------------------------------------------
// Destroy
//----------------------------------------------------------------------------

void
ButtonMgr::Destroy()
{
	// Destroy all the buttons
	if (m_rgButtons)
	{
		for (int i = 0; i < m_cButtons; i++)
		{
			if (m_rgButtons[i])
			{
				m_rgButtons[i]->Destroy();
				delete m_rgButtons[i];
				m_rgButtons[i] = NULL;
			}
		}

		free(m_rgButtons);
		m_rgButtons = NULL;
	}
	
	if (m_hWnd)
	{
		// Destroy the tooltip control
		if (m_hwndToolTips)
		{
			DestroyWindow(m_hwndToolTips);
			m_hwndToolTips = NULL;
		}

		// Unregister LS messages
		UINT rguMsgs[] = { LM_GETREVID };
		SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM) m_hWnd, (LPARAM) rguMsgs);

		// Destroy our window
		DestroyWindow(m_hWnd);
		m_hWnd = NULL;
	}
}

//----------------------------------------------------------------------------
// DestroyButton
//----------------------------------------------------------------------------

void
ButtonMgr::DestroyButton(LPCTSTR pszName)
{
	// Ignore requests to destroy a button that doesn't exist
	int i = FindButton(pszName);

	if (i >= 0)
	{
		// Remove the button's tooltip
		TOOLINFO ti;

		ti.cbSize = sizeof(TOOLINFO);
		ti.hwnd = m_hWnd;
		ti.uId = (UINT_PTR) m_rgButtons[i]->GetWindow();

		SendMessage(m_hwndToolTips, TTM_DELTOOL, 0, (LPARAM) &ti);

		// Destroy it
		m_rgButtons[i]->Destroy();
		delete m_rgButtons[i];
		m_rgButtons[i] = NULL;

		// Remove it from the list
		for (int j = i; j < m_cButtons - 1; j++)
		{
			m_rgButtons[j] = m_rgButtons[j + 1];
		}

		m_rgButtons = (Button **) realloc(m_rgButtons, (m_cButtons - 1) * sizeof(Button *));

		if (!m_rgButtons)
		{
			m_cButtons = 0;
			return;
		}

		m_cButtons--;
	}
}

//----------------------------------------------------------------------------
// FindButton
//----------------------------------------------------------------------------

int
ButtonMgr::FindButton(LPCTSTR pszName) const
{
	for (int i = 0; i < m_cButtons; i++)
	{
		if (StrCompareIgnoreCase(pszName, m_rgButtons[i]->GetName()) == 0)
		{
			return i;
		}
	}

	return (-1);
}

//----------------------------------------------------------------------------
// Hide
//----------------------------------------------------------------------------

void
ButtonMgr::Hide(LPCTSTR pszName)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->Hide();
	}
}

//----------------------------------------------------------------------------
// MoveBy
//----------------------------------------------------------------------------

void
ButtonMgr::MoveBy(LPCTSTR pszName, int dx, int dy)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->MoveBy(dx, dy);
	}
}

//----------------------------------------------------------------------------
// MoveTo
//----------------------------------------------------------------------------

void
ButtonMgr::MoveTo(LPCTSTR pszName, int x, int y)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->MoveTo(x, y);
	}
}

//----------------------------------------------------------------------------
// OnGetRevID
//----------------------------------------------------------------------------

int
ButtonMgr::OnGetRevID(LPTSTR pszBuffer)
{
	return StrPrintf(pszBuffer, 40, _T("%s %s (%s)"), V_NAME, V_VERSION, V_AUTHOR);
}

//----------------------------------------------------------------------------
// OnNotify
//----------------------------------------------------------------------------

LRESULT
ButtonMgr::OnNotify(int idCtrl, LPNMHDR pnmh)
{
	if (pnmh->code == TTN_GETDISPINFO)
	{
		Button *pButton = (Button *) GetWindowLongPtr((HWND) pnmh->idFrom, GWLP_THIS);
		((LPNMTTDISPINFO) pnmh)->lpszText = (LPTSTR) pButton->GetToolTipText();
	}

	return 0;
}

//----------------------------------------------------------------------------
// PinToDesktop
//----------------------------------------------------------------------------

void
ButtonMgr::PinToDesktop(LPCTSTR pszName)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->PinToDesktop();
	}
}

//----------------------------------------------------------------------------
// RegisterWindowClass
//----------------------------------------------------------------------------

void
ButtonMgr::RegisterWindowClass(HINSTANCE hInstance)
{
	WNDCLASSEX wc;
	
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_DBLCLKS | CS_GLOBALCLASS;
	wc.lpfnWndProc = ExternalWindowProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = sizeof(Window *);
	wc.hInstance = hInstance;
	wc.hIcon = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = WC_LSBUTTONMGR;
	wc.hIconSm = NULL;
	
	RegisterClassEx(&wc);
}

//----------------------------------------------------------------------------
// ResizeBy
//----------------------------------------------------------------------------

void
ButtonMgr::ResizeBy(LPCTSTR pszName, int dx, int dy)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->ResizeBy(dx, dy);
	}
}

//----------------------------------------------------------------------------
// ResizeTo
//----------------------------------------------------------------------------

void
ButtonMgr::ResizeTo(LPCTSTR pszName, int nWidth, int nHeight)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->ResizeTo(nWidth, nHeight);
	}
}

//----------------------------------------------------------------------------
// SetAlpha
//----------------------------------------------------------------------------

void
ButtonMgr::SetAlpha(LPCTSTR pszName, int nAlpha)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->SetAlpha(nAlpha);
	}
}

//----------------------------------------------------------------------------
// SetIcon
//----------------------------------------------------------------------------

void
ButtonMgr::SetIcon(LPCTSTR pszName, LPCTSTR pszIcon, int nIconSize)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->SetIcon(pszIcon, nIconSize);
	}
}

//----------------------------------------------------------------------------
// SetText
//----------------------------------------------------------------------------

void
ButtonMgr::SetText(LPCTSTR pszName, LPCTSTR pszText)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->SetText(pszText);
	}
}

//----------------------------------------------------------------------------
// SetToolTipText
//----------------------------------------------------------------------------

void
ButtonMgr::SetToolTipText(LPCTSTR pszName, LPCTSTR pszToolTipText)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->SetToolTipText(pszToolTipText);
	}
}

//----------------------------------------------------------------------------
// Show
//----------------------------------------------------------------------------

void
ButtonMgr::Show(LPCTSTR pszName)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->Show();
	}
}

//----------------------------------------------------------------------------
// Toggle
//----------------------------------------------------------------------------

void
ButtonMgr::Toggle(LPCTSTR pszName)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->Toggle();
	}
}

//----------------------------------------------------------------------------
// ToggleAlwaysOnTop
//----------------------------------------------------------------------------

void
ButtonMgr::ToggleAlwaysOnTop(LPCTSTR pszName)
{
	int i = FindButton(pszName);

	if (i >= 0)
	{
		m_rgButtons[i]->ToggleAlwaysOnTop();
	}
}

//----------------------------------------------------------------------------
// UnregisterWindowClass
//----------------------------------------------------------------------------

void
ButtonMgr::UnregisterWindowClass(HINSTANCE hInstance)
{
	UnregisterClass(WC_LSBUTTONMGR, hInstance);
}

//----------------------------------------------------------------------------
// WindowProc
//----------------------------------------------------------------------------

LRESULT
ButtonMgr::WindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		DISPATCH_MSG(LM_GETREVID, wParam, lParam, OnGetRevID);
		DISPATCH_MSG(WM_NOTIFY, wParam, lParam, OnNotify);
	}

	return DefWindowProc(m_hWnd, uMsg, wParam, lParam);
}
