//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#include "common.h"
#include "Window.h"

//----------------------------------------------------------------------------
// Constructor
//----------------------------------------------------------------------------

Window::Window()
{
	m_hWnd = NULL;
}

//----------------------------------------------------------------------------
// ModifyStyle
//----------------------------------------------------------------------------

DWORD
Window::ModifyStyle(DWORD dwRemove, DWORD dwAdd)
{
	DWORD dwStyle = (DWORD) GetWindowLong(m_hWnd, GWL_STYLE);
	SetWindowLong(m_hWnd, GWL_STYLE, (LONG) ((dwStyle & ~dwRemove) | dwAdd));
	return dwStyle;
}

//----------------------------------------------------------------------------
// ExternalWindowProc
//----------------------------------------------------------------------------

LRESULT CALLBACK
ExternalWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Window *pWindow = (Window *) GetWindowLongPtr(hWnd, GWLP_THIS);
	
	if (uMsg == WM_NCCREATE)
	{
		// WM_NCCREATE is our first chance to get lpCreateParams
		pWindow = (Window *) ((LPCREATESTRUCT) lParam)->lpCreateParams;
		if (pWindow) pWindow->m_hWnd = hWnd;
		SetWindowLongPtr(hWnd, GWLP_THIS, (LONG_PTR) pWindow);
	}
	
	if (pWindow)
	{
		return pWindow->WindowProc(uMsg, wParam, lParam);
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
