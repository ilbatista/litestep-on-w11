//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#ifndef __COMMON_H
#define __COMMON_H

#define WIN32_LEAN_AND_MEAN
#define STRICT

// Standard C/C++ headers
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>

// Win32 headers
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>

// Local headers
#include "gdi.h"
#include "lsapi.h"
#include "msgcrack.h"
#include "strings.h"
#include "util.h"

// I prefer this over TEXT(x)
#if !defined(_T)
	#if !defined(UNICODE)
		#define _T(x) x
	#else
		#define _T(x) L##x
	#endif
#endif

// Version information
#define V_NAME _T("Button")
#define V_VERSION _T("1.0.1")
#define V_AUTHOR _T("Maduin")

// Maximum string lengths
#define MAX_LINE 512
#define MAX_NAME 64
#define MAX_KEY 64
#define MAX_STRINT 16
#define MAX_STRRESULT 512
#define MAX_TEXT 512
#define MAX_TOOLTIPTEXT 512

// Transparency color
#define COLOR_TRANSPARENT RGB(255, 0, 255)

// Window class names
#define WC_LSBUTTON _T("LSButton")
#define WC_LSBUTTONMGR _T("LSButtonMgr")

#endif
