//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#include "common.h"

LPTSTR
StrAlloc(LPCTSTR pszSrc)
{
	LPTSTR pszResult = NULL;
	
	if (pszSrc && *pszSrc)
	{
		int cch = StrLen(pszSrc);
		pszResult = (LPTSTR) malloc((cch + 1) * sizeof(TCHAR));
		if (pszResult) memcpy(pszResult, pszSrc, (cch + 1) * sizeof(TCHAR));
	}
	
	return pszResult;
}

int
StrCat(LPTSTR pszDest, int cchDest, LPCTSTR pszSrc)
{
	int cch = 0;
	
	while (pszDest && *pszDest)
	{
		pszDest++;
		cch++;
		cchDest--;
	}
	
	while (pszSrc && *pszSrc)
	{
		if ((cchDest > 1) && pszDest)
		{
			*pszDest++ = *pszSrc;
			cchDest--;
		}
		
		pszSrc++;
		cch++;
	}
	
	if (cchDest > 0) *pszDest = 0;
	return cch;
}

int
StrCompare(LPCTSTR pszA, LPCTSTR pszB)
{
	if (pszA)
	{
		return (pszB) ? _tcscmp(pszA, pszB) : 1;
	}
	else
	{
		return (pszB) ? (-1) : 0;
	}
}

int
StrCompareIgnoreCase(LPCTSTR pszA, LPCTSTR pszB)
{
	if (pszA)
	{
		return (pszB) ? _tcsicmp(pszA, pszB) : 1;
	}
	else
	{
		return (pszB) ? (-1) : 0;
	}
}

int
StrCopy(LPTSTR pszDest, int cchDest, LPCTSTR pszSrc)
{
	int cch = 0;
	
	while (pszSrc && *pszSrc)
	{
		if ((cchDest > 1) && pszDest)
		{
			*pszDest++ = *pszSrc;
			cchDest--;
		}
		
		pszSrc++;
		cch++;
	}
	
	if (cchDest > 0) *pszDest = 0;
	return cch;
}

void
StrFree(LPTSTR pszSrc)
{
	free(pszSrc);
}

int
StrHash(LPCTSTR pszSrc, int nMod)
{
	UINT uHashValue = 5381;
	
	while (pszSrc && *pszSrc)
	{
		uHashValue = ((uHashValue << 5) + uHashValue) + (UINT) CharLower((LPTSTR) *pszSrc);
		pszSrc = CharNext(pszSrc);
	}
	
	return (int) (uHashValue % nMod);
}

int
StrLen(LPCTSTR pszSrc)
{
	int cch = 0;
	
	while (pszSrc && *pszSrc)
	{
		pszSrc++;
		cch++;
	}
	
	return cch;
}

int
StrPrintf(LPTSTR pszDest, int cchDest, LPCTSTR pszFormat, ...)
{
	va_list va;
	int cch;
	
	va_start(va, pszFormat);
	cch = _vsntprintf(pszDest, cchDest, pszFormat, va);
	va_end(va);
	
	return cch;
}
