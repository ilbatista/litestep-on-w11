//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#ifndef __BUTTON_H
#define __BUTTON_H

#include "Window.h"

#define ALIGN_LEFT 0
#define ALIGN_TOP 0
#define ALIGN_CENTER 1
#define ALIGN_RIGHT 2
#define ALIGN_BOTTOM 2
#define ICON_POSITION_LEFT 0
#define ICON_POSITION_TOP 1
#define ICON_POSITION_RIGHT 2
#define ICON_POSITION_BOTTOM 3
#define STATE_NORMAL 0
#define STATE_PRESSED 1
#define STATE_HOVER 2

typedef struct ENUM {
	LPCTSTR pszName;
	int nValue;
} ENUM, *LPENUM;

class Button : public Window
{
public:
	Button(LPCTSTR pszName);
	virtual ~Button();
	virtual void AlwaysOnTop();
	virtual BOOL Create(HINSTANCE hInstance, HWND hwndParent = NULL);
	virtual void Destroy();
	virtual LPCTSTR GetName() const;
	virtual LPCTSTR GetToolTipText() const;
	virtual HWND GetWindow() const;
	virtual void Hide();
	virtual void MoveBy(int dx, int dy);
	virtual void MoveTo(int x, int y);
	virtual void PinToDesktop();
	static  void RegisterWindowClass(HINSTANCE hInstance);
	virtual void ResizeBy(int dx, int dy);
	virtual void ResizeTo(int nWidth, int nHeight);
	virtual void SetAlpha(int nAlpha);
	virtual void SetIcon(LPCTSTR pszIcon, int nIconSize);
	virtual void SetText(LPCTSTR pszText);
	virtual void SetToolTipText(LPCTSTR pszToolTipText);
	virtual void Show();
	virtual void Toggle();
	virtual void ToggleAlwaysOnTop();
	static  void UnregisterWindowClass(HINSTANCE hInstance);
	
protected:
	virtual void ChangeState(int nState);
	virtual BOOL GetConfigBoolean(LPCTSTR pszKey, BOOL fDefault = FALSE);
	virtual COLORREF GetConfigColor(LPCTSTR pszKey, COLORREF crDefault = 0);
	virtual int GetConfigEnum(LPCTSTR pszKey, LPENUM pEnum, int nDefault = 0);
	virtual HBITMAP GetConfigImage(LPCTSTR pszKey, LPINT pnWidth, LPINT pnHeight);
	virtual HBITMAP GetConfigImageOrIcon(LPCTSTR pszKey, int nIconSize, LPINT pnWidth, LPINT pnHeight);
	virtual int GetConfigInt(LPCTSTR pszKey, int nDefault = 0);
	virtual LPTSTR GetConfigLine(LPCTSTR pszKey, LPCTSTR pszDefault = NULL);
	virtual LPTSTR GetConfigString(LPCTSTR pszKey, LPCTSTR pszDefault = NULL);
	virtual HFONT GetCurrentFont() const;
	virtual HBITMAP GetCurrentSkin() const;
	virtual HRGN GetCurrentSkinRegion() const;
	virtual void DoLayout();
	virtual void OnDestroy();
	virtual void OnLButtonDblClk(UINT fuFlags, int x, int y);
	virtual void OnLButtonDown(UINT fuFlags, int x, int y);
	virtual void OnLButtonUp(UINT fuFlags, int x, int y);
	virtual void OnMButtonDblClk(UINT fuFlags, int x, int y);
	virtual void OnMButtonDown(UINT fuFlags, int x, int y);
	virtual void OnMButtonUp(UINT fuFlags, int x, int y);
	virtual void OnMouseEnter(UINT fuFlags);
	virtual void OnMouseLeave();
	virtual void OnMouseMove(UINT fuFlags, int x, int y);
	virtual void OnMove(int x, int y);
	virtual void OnPaint();
	virtual void OnPrintClient(HDC hDC, UINT fuFlags);
	virtual void OnRButtonDblClk(UINT fuFlags, int x, int y);
	virtual void OnRButtonDown(UINT fuFlags, int x, int y);
	virtual void OnRButtonUp(UINT fuFlags, int x, int y);
	virtual void OnSize(UINT uState, int nWidth, int nHeight);
	virtual void Paint(HDC hDC);
	virtual void ReadConfig();
	virtual void RenderSkins();
	virtual void SetAlwaysOnTop(BOOL fAlwaysOnTop);
	virtual LRESULT WindowProc(UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	LPTSTR m_pszName;
	int m_nIconSize;
	HBITMAP m_hbmIcon;
	int m_cxIcon;
	int m_cyIcon;
	LPTSTR m_pszText;
	LPTSTR m_pszToolTipText;
	
	BOOL m_fAlwaysOnTop;
	BOOL m_fVisible;
	int m_x;
	int m_y;
	int m_nWidth;
	int m_nHeight;
	
	int m_nAlign;
	int m_nVertAlign;
	int m_nIconPosition;
	int m_nIconTextGap;
	int m_nLeftBorder;
	int m_nRightBorder;
	int m_nTopBorder;
	int m_nBottomBorder;
	int m_xIcon;
	int m_yIcon;
	int m_xText;
	int m_yText;
	
	HFONT m_hfnFont;
	COLORREF m_crFontColor;
	BOOL m_fFontShadow;
	COLORREF m_crFontShadowColor;
	int m_xFontShadowOffset;
	int m_yFontShadowOffset;
	HFONT m_hfnPressedFont;
	COLORREF m_crPressedFontColor;
	BOOL m_fPressedFontShadow;
	COLORREF m_crPressedFontShadowColor;
	int m_xPressedFontShadowOffset;
	int m_yPressedFontShadowOffset;
	HFONT m_hfnHoverFont;
	COLORREF m_crHoverFontColor;
	BOOL m_fHoverFontShadow;
	COLORREF m_crHoverFontShadowColor;
	int m_xHoverFontShadowOffset;
	int m_yHoverFontShadowOffset;
	HBITMAP m_hbmOrigSkin;
	int m_cxSkin;
	int m_cySkin;
	HBITMAP m_hbmSkin;
	HRGN m_hrgnSkin;
	int m_nSkinLeftEdge;
	int m_nSkinRightEdge;
	int m_nSkinTopEdge;
	int m_nSkinBottomEdge;
	int m_nSkinMode;
	BOOL m_fSkinTransparent;
	HBITMAP m_hbmOrigPressedSkin;
	int m_cxPressedSkin;
	int m_cyPressedSkin;
	HBITMAP m_hbmPressedSkin;
	HRGN m_hrgnPressedSkin;
	int m_nPressedSkinLeftEdge;
	int m_nPressedSkinRightEdge;
	int m_nPressedSkinTopEdge;
	int m_nPressedSkinBottomEdge;
	int m_nPressedSkinMode;
	BOOL m_fPressedSkinTransparent;
	HBITMAP m_hbmOrigHoverSkin;
	int m_cxHoverSkin;
	int m_cyHoverSkin;
	HBITMAP m_hbmHoverSkin;
	HRGN m_hrgnHoverSkin;
	int m_nHoverSkinLeftEdge;
	int m_nHoverSkinRightEdge;
	int m_nHoverSkinTopEdge;
	int m_nHoverSkinBottomEdge;
	int m_nHoverSkinMode;
	BOOL m_fHoverSkinTransparent;
	int m_nPressedOffsetX;
	int m_nPressedOffsetY;
	int m_nHoverOffsetX;
	int m_nHoverOffsetY;

	LPTSTR m_pszOnEnter;
	LPTSTR m_pszOnLeave;
	LPTSTR m_pszOnLeftClick;
	LPTSTR m_pszOnLeftDoubleClick;
	LPTSTR m_pszOnMiddleClick;
	LPTSTR m_pszOnMiddleDoubleClick;
	LPTSTR m_pszOnRightClick;
	LPTSTR m_pszOnRightDoubleClick;

	HWND m_hwndParent;
	int m_nState;
	BOOL m_fMouseDown;
	BOOL m_fMouseInside;
	int m_nAlpha;
};

#endif
