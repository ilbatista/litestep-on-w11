//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#ifndef __UTIL_H
#define __UTIL_H

// Adds a backslash to a path if it doesn't already have one
void AddBackslash(LPTSTR pszPath, int cchBuffer);

// Returns TRUE if any mouse button flags are set
BOOL AnyButtonsDown(UINT fuFlags);

// Converts an icon into a bitmap
HBITMAP ConvIconToBitmap(HICON hIcon, int nIconSize);

// Creates a font using reasonable defaults for most parameters
HFONT CreateFontEZ(LPCTSTR pszName, int nHeight, BOOL fBold, BOOL fItalic, BOOL fUnderline);

// Retrieves the size of a bitmap
void GetImageSize(HBITMAP hbmImage, LPINT pnWidth, LPINT pnHeight);

// Loads an icon file
HICON LoadIcon(LPCTSTR pszFile, int nIconSize);

// Loads a bitmap file or an icon file
HBITMAP LoadImageOrIcon(LPCTSTR pszFile, int nIconSize, LPINT pnWidth, LPINT pnHeight);

// Returns a handle to the shell's desktop window
HWND GetShellDesktopWindow();

// Sets the opacity (alpha channel) of a window
BOOL SetWindowAlpha(HWND hWnd, int nAlpha);

#endif
