//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#ifndef __STRINGS_H
#define __STRINGS_H

// Allocates a duplicate of the string
LPTSTR StrAlloc(LPCTSTR pszSrc);

// Concatenates one string onto another
int StrCat(LPTSTR pszDest, int cchDest, LPCTSTR pszSrc);

// Compares two strings
int StrCompare(LPCTSTR pszA, LPCTSTR pszB);

// Compares two strings ignoring differences in case
int StrCompareIgnoreCase(LPCTSTR pszA, LPCTSTR pszB);

// Copies a string into a buffer
int StrCopy(LPTSTR pszDest, int cchDest, LPCTSTR pszSrc);

// Frees a string allocated by StrAlloc
void StrFree(LPTSTR pszSrc);

// Computes a hash value for a string; the hash value is case-independent
int StrHash(LPCTSTR pszSrc, int nMod);

// Returns the length of a string
int StrLen(LPCTSTR pszSrc);

// Formats a string
int StrPrintf(LPTSTR pszDest, int cchDest, LPCTSTR pszFormat, ...);

#endif
