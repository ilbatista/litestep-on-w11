//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#include "common.h"

// Fills the destination with the source by tiling it horizontally and stretching it vertically
void HorizontalTileBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, DWORD dwROP)
{
	for (int x = 0; x < cxDest; x += cxSrc)
	{
		StretchBlt(hdcDest, xDest + x, yDest, min(cxDest - x, cxSrc), cyDest, hdcSrc, xSrc, ySrc, min(cxDest - x, cxSrc), cySrc, dwROP);
	}
}

// Fills the destination with the source by tiling or stretching but leaves the edges intact
void ScaleEdgeBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, int cxLeft, int cyTop, int cxRight, int cyBottom, int nMode, DWORD dwROP)
{
	if (cyTop > 0)
	{
		// Top Left Corner
		if (cxLeft > 0)
		{
			BitBlt(hdcDest, xDest, yDest, cxLeft, cyTop, hdcSrc, xSrc, ySrc, dwROP);
		}

		// Top
		if (nMode == SCALE_STRETCH || nMode == SCALE_VERTICALTILE)
		{
			StretchBlt(hdcDest, xDest + cxLeft, yDest, cxDest - cxLeft - cxRight, cyTop, hdcSrc, xSrc + cxLeft, ySrc, cxSrc - cxLeft - cxRight, cyTop, dwROP);
		}
		else
		{
			HorizontalTileBlt(hdcDest, xDest + cxLeft, yDest, cxDest - cxLeft - cxRight, cyTop, hdcSrc, xSrc + cxLeft, ySrc, cxSrc - cxLeft - cxRight, cyTop, dwROP);
		}

		// Top Right Corner
		if (cxRight > 0)
		{
			BitBlt(hdcDest, cxDest - cxRight, yDest, cxRight, cyTop, hdcSrc, cxSrc - cxRight, ySrc, dwROP);
		}
	}

	if (cxLeft > 0)
	{
		// Left
		if (nMode == SCALE_STRETCH || nMode == SCALE_HORIZONTALTILE)
		{
			StretchBlt(hdcDest, xDest, yDest + cyTop, cxLeft, cyDest - cyTop - cyBottom, hdcSrc, xSrc, ySrc + cyTop, cxLeft, cySrc - cyTop - cyBottom, dwROP);
		}
		else
		{
			VerticalTileBlt(hdcDest, xDest, yDest + cyTop, cxLeft, cyDest - cyTop - cyBottom, hdcSrc, xSrc, ySrc + cyTop, cxLeft, cySrc - cyTop - cyBottom, dwROP);
		}
	}

	// Center
	if (nMode == SCALE_STRETCH)
	{
		StretchBlt(hdcDest, xDest + cxLeft, yDest + cyTop, cxDest - cxLeft - cxRight, cyDest - cyTop - cyBottom, hdcSrc, xSrc + cxLeft, ySrc + cyTop, cxSrc - cxLeft - cxRight, cySrc - cyTop - cyBottom, dwROP);
	}
	else if (nMode == SCALE_TILE)
	{
		TileBlt(hdcDest, xDest + cxLeft, yDest + cyTop, cxDest - cxLeft - cxRight, cyDest - cyTop - cyBottom, hdcSrc, xSrc + cxLeft, ySrc + cyTop, cxSrc - cxLeft - cxRight, cySrc - cyTop - cyBottom, dwROP);
	}
	else if (nMode == SCALE_HORIZONTALTILE)
	{
		HorizontalTileBlt(hdcDest, xDest + cxLeft, yDest + cyTop, cxDest - cxLeft - cxRight, cyDest - cyTop - cyBottom, hdcSrc, xSrc + cxLeft, ySrc + cyTop, cxSrc - cxLeft - cxRight, cySrc - cyTop - cyBottom, dwROP);
	}
	else if (nMode == SCALE_VERTICALTILE)
	{
		VerticalTileBlt(hdcDest, xDest + cxLeft, yDest + cyTop, cxDest - cxLeft - cxRight, cyDest - cyTop - cyBottom, hdcSrc, xSrc + cxLeft, ySrc + cyTop, cxSrc - cxLeft - cxRight, cySrc - cyTop - cyBottom, dwROP);
	}

	if (cxRight > 0)
	{
		// Right
		if (nMode == SCALE_STRETCH || nMode == SCALE_HORIZONTALTILE)
		{
			StretchBlt(hdcDest, cxDest - cxRight, yDest + cyTop, cxRight, cyDest - cyTop - cyBottom, hdcSrc, cxSrc - cxRight, ySrc + cyTop, cxRight, cySrc - cyTop - cyBottom, dwROP);
		}
		else
		{
			VerticalTileBlt(hdcDest, cxDest - cxRight, yDest + cyTop, cxRight, cyDest - cyTop - cyBottom, hdcSrc, cxSrc - cxRight, ySrc + cyTop, cxRight, cySrc - cyTop - cyBottom, dwROP);
		}
	}

	if (cyBottom > 0)
	{
		// Bottom Left Corner
		if (cxLeft > 0)
		{
			BitBlt(hdcDest, xDest, cyDest - cyBottom, cxLeft, cyBottom, hdcSrc, xSrc, cySrc - cyBottom, dwROP);
		}

		// Bottom
		if (nMode == SCALE_STRETCH || nMode == SCALE_VERTICALTILE)
		{
			StretchBlt(hdcDest, xDest + cxLeft, cyDest - cyBottom, cxDest - cxLeft - cxRight, cyBottom, hdcSrc, xSrc + cxLeft, cySrc - cyBottom, cxSrc - cxLeft - cxRight, cyBottom, dwROP);
		}
		else
		{
			HorizontalTileBlt(hdcDest, xDest + cxLeft, cyDest - cyBottom, cxDest - cxLeft - cxRight, cyBottom, hdcSrc, xSrc + cxLeft, cySrc - cyBottom, cxSrc - cxLeft - cxRight, cyBottom, dwROP);
		}

		// Bottom Right Corner
		if (cxRight > 0)
		{
			BitBlt(hdcDest, cxDest - cxRight, cyDest - cyBottom, cxRight, cyBottom, hdcSrc, cxSrc - cxRight, cySrc - cyBottom, dwROP);
		}
	}
}

// Fills the destination with the source by tiling it horizontally and vertically
void TileBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, DWORD dwROP)
{
	for (int y = 0; y < cyDest; y += cySrc)
	{
		for (int x = 0; x < cxDest; x += cxSrc)
		{
			BitBlt(hdcDest, xDest + x, yDest + y, min(cxDest - x, cxSrc), min(cyDest - y, cySrc), hdcSrc, xSrc, ySrc, dwROP);
		}
	}
}

// Fills the destination with the source by tiling it vertically and stretching it horizontally
void VerticalTileBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, DWORD dwROP)
{
	for (int y = 0; y < cyDest; y += cySrc)
	{
		StretchBlt(hdcDest, xDest, yDest + y, cxDest, min(cyDest - y, cySrc), hdcSrc, xSrc, ySrc, cxSrc, min(cyDest - y, cySrc), dwROP);
	}
}
