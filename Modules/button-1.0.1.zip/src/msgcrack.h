//  ____        _   _
// | __ ) _   _| |_| |_ ___  _ __
// |  _ \| | | | __| __/ _ \| '_ \
// | |_) | |_| | |_| || (_) | | | |
// |____/ \__,_|\__|\__\___/|_| |_|
//
// Copyright 2004 Kevin Schaffer
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
// for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//

#ifndef __MSGCRACK_H
#define __MSGCRACK_H

//----------------------------------------------------------------------------
// Message Crackers
//----------------------------------------------------------------------------

#define DISPATCH_MSG(message, wParam, lParam, fn) \
    case (message): return DISPATCH_##message((wParam), (lParam), (fn))

// void OnDestroy()
#define DISPATCH_WM_DESTROY(wParam, lParam, fn) \
	((fn)(), 0L)

// void OnLButtonDblClk(UINT fuFlags, int x, int y)
#define DISPATCH_WM_LBUTTONDBLCLK(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnLButtonDown(UINT fuFlags, int x, int y)
#define DISPATCH_WM_LBUTTONDOWN(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnLButtonUp(UINT fuFlags, int x, int y)
#define DISPATCH_WM_LBUTTONUP(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnMButtonDblClk(UINT fuFlags, int x, int y)
#define DISPATCH_WM_MBUTTONDBLCLK(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnMButtonDown(UINT fuFlags, int x, int y)
#define DISPATCH_WM_MBUTTONDOWN(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnMButtonUp(UINT fuFlags, int x, int y)
#define DISPATCH_WM_MBUTTONUP(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnMouseLeave()
#define DISPATCH_WM_MOUSELEAVE(wParam, lParam, fn) \
	((fn)(), 0L)

// void OnMouseMove(UINT fuFlags, int x, int y)
#define DISPATCH_WM_MOUSEMOVE(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnMove(int x, int y)
#define DISPATCH_WM_MOVE(wParam, lParam, fn) \
    ((fn)((int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// LRESULT OnNotify(int idCtrl, LPNMHDR pnmh)
#define DISPATCH_WM_NOTIFY(wParam, lParam, fn) \
    (fn)((int)(wParam), (LPNMHDR)(lParam))

// void OnPaint()
#define DISPATCH_WM_PAINT(wParam, lParam, fn) \
    ((fn)(), 0L)

// void OnPrintClient(HDC hdc, UINT fuFlags)
#define DISPATCH_WM_PRINTCLIENT(wParam, lParam, fn) \
    ((fn)((HDC)(wParam), (UINT)(lParam)), 0L)

// void OnRButtonDblClk(UINT fuFlags, int x, int y)
#define DISPATCH_WM_RBUTTONDBLCLK(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnRButtonDown(UINT fuFlags, int x, int y)
#define DISPATCH_WM_RBUTTONDOWN(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnRButtonUp(UINT fuFlags, int x, int y)
#define DISPATCH_WM_RBUTTONUP(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// void OnSize(UINT uState, int cx, int cy)
#define DISPATCH_WM_SIZE(wParam, lParam, fn) \
    ((fn)((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0L)

// int OnGetRevID(LPTSTR pszBuffer)
#define DISPATCH_LM_GETREVID(wParam, lParam, fn) \
	(fn)((LPTSTR)(lParam))

#endif

