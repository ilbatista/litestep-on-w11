/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
4/30/08 - jimrandomh
- Used this file from Litestep's vwm2 as the starting point of screenVWM.
  Changed just about everything. Includes contributions by allelimo,
  Vendicator, Bobby G. Vinyard, Charles Oliver Nutter (Headius), and Gustav
  Munkby (grd).
****************************************************************************/

#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include "vwm.h"
#include "trace.hpp"

VWM *vwm = NULL;

//=========================================================
// Module initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInstance, LPCSTR szPath)
{
	int code;

	vwm = new VWM(ParentWnd, code, dllInstance);
	vwm->finalize();

	return code;
}

int initWharfModule(HWND ParentWnd, HINSTANCE dllInstance, void *wharfData)
{
	int code;

	vwm = new VWM(ParentWnd, code, dllInstance);
	vwm->finalize();

	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete vwm;
	trace.close();
}

void quitWharfModule(HINSTANCE dllInst)
{
	delete vwm;
	trace.close();
}

//=========================================================
// VWM miscellaneous
//=========================================================
VWM::VWM(HWND parentWindow, int& code, HINSTANCE dllInst)
	:parentWindow(parentWindow), dllInstance(dllInstance)
{
	// if the parent window is not litestep, it must be the wharf
	if(parentWindow == GetLitestepWnd()) {
		inWharf = false;
		parentWindow = FindWindow("DesktopBackgroundClass", NULL);
		if(!parentWindow)
			parentWindow = GetDesktopWindow();
	} else {
		inWharf = true;
	}
	
	updateNextDraw = false;
	selectedWindow = NULL;
}

VWM::~VWM()
{
	cleanupTrackingHooks();
	unregisterEventHandlers();
	destroyWindow();
	delete settings;
}

int VWM::finalize()
{
	settings = new RCSettings();
	settings->refresh(inWharf);
	
	setScreenSize(SCREEN_WIDTH, SCREEN_HEIGHT);
	initBangs();
	initStickyWindows();
	initDesktops();
	
	if(!createWindow())
		return 1;
	
	registerEventHandlers();
	initDrawContext();
	
	initTrackingHooks();
	
	DragAcceptFiles(vwmWindow, TRUE);
	
	updateWindowList();
	
	if (settings->onTop)
		SetWindowPos(vwmWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

	if (settings->visible && settings->autoHideDistance)
	{
		// if it's at the edge of the screen
		if( (windowX == (SCREEN_LEFT))
		 || (windowY == (SCREEN_TOP))
		 || (windowX + windowWidth == screenWidth)
		 || (windowY + windowHeight == screenHeight) )
		{
			POINT pt;
			GetCursorPos(&pt);
			if( (pt.x < windowX)
			 || (pt.x > windowX + windowWidth)
			 || (pt.y < windowY)
			 || (pt.y > windowY + windowHeight) )
				settings->visible = FALSE;
		}
	}

	ShowWindow(vwmWindow, settings->visible?SW_SHOWNORMAL:SW_HIDE);

	// Set a timer to update the VWM display (would like to replace this with a hook...)
	if(settings->pollInterval)
		SetTimer(vwmWindow, 1, settings->pollInterval, NULL);
	
	return 0;
}

void VWM::initStickyWindows()
{
	// Read vwmSticky options and populate vec stickyWindows with them
	FILE *f;
	char buffer[MAX_LINE_LENGTH];

	f = LCOpen(NULL);
	if(!f)
		return;
	
	while(LCReadNextConfig(f, "*vwmSticky", buffer, MAX_LINE_LENGTH))
	{
		char firstToken[MAX_LINE_LENGTH];
		char *tokens[] = { firstToken };
		
		LCTokenize ((char *)(buffer + 11), tokens, 1, NULL);
		
		if(*firstToken)
			stickyWindows.insert(firstToken);
	}
	LCClose(f);
}

WindowData *VWM::getForegroundWindow()
{
	if(!foregroundHandle)
		return NULL;
	if(windowsByHandle.find(foregroundHandle)==windowsByHandle.end())
		return NULL;
	return windowsByHandle[foregroundHandle];
}

VirtualDesktop *VWM::getDeskByIndex(int index)
{
	if(index < 0 || index >= (int)desktops.size())
		return NULL;
	else
		return desktops[index];
}

VirtualDesktop *VWM::getDeskFromWnd(HWND window)
{
	if(windowsByHandle.find(window) != windowsByHandle.end())
	{
		return windowsByHandle[window]->desk;
	}
	else
	{
		RECT screenPos;
		GetWindowRect(window, &screenPos);
		VirtualDesktop *desk = deskFromLocation(screenPos);
		if(desk)
			return desk;
		else
			return currentDesktop;
	}
}

void VWM::createDesktop()
{
	VirtualDesktop *newDesk = new VirtualDesktop(desktops.size(), &storageManager);
	desktops.push_back(newDesk);
	moveApp(newDesk);
}

void VWM::destroyDesktop()
{
	// If there's only one desktop left, it can't be destroyed
	if(desktops.size()<=1)
		return;
	
	// If there's a drag/drop in progress, cancel it
	if(selectedWindow)
		endDrag();
	
	// Pick a desktop to move windows to. All desktops except the first merge
	// to the left. The first (leftmost) desktop merges to the right instead.
	VirtualDesktop *mergeTarget;
	VirtualDesktop *deletedDesktop = currentDesktop;
	if(currentDesktop->index > 0)
		mergeTarget = desktops[currentDesktop->index-1];
	else
		mergeTarget = desktops[1];
	
	for(map<HWND, WindowData*>::iterator it = windowsByHandle.begin(); it != windowsByHandle.end(); it++)
	{
		HWND handle = it->first;
		WindowData *windowData = it->second;
		
		// Relabel windows on the current desktop as being on the merge target
		if(windowData->desk == currentDesktop)
			windowData->desk = mergeTarget;
		// Move windows on the merge target on-screen
		else if(windowData->desk == mergeTarget) {
			mergeTarget->storage->unstoreRect(windowData->screenPos);
			SetWindowPos(handle, NULL,
				windowData->screenPos.left, windowData->screenPos.top,
				0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
		}
	}
	
	currentDesktop = mergeTarget;
	currentDesktop->focused = true;
	
	// Remove the deleted desktop from the desk list and update everyone's indices
	for(unsigned ii=deletedDesktop->index; ii<desktops.size()-1; ii++)
	{
		desktops[ii] = desktops[ii+1];
		desktops[ii]->index = ii;
	}
	desktops.pop_back();
	delete deletedDesktop;
	
	// Clean up other possible references to the deleted desk
	if(lastDesktop == deletedDesktop)
		lastDesktop = NULL;
	
	forceRedraw(true);
}

void VWM::switchDesk(VirtualDesktop *newDesk)
{
	if(!newDesk)
		return;
	if(newDesk == currentDesktop)
		return;
	
	for(map<HWND, WindowData*>::iterator it = windowsByHandle.begin(); it != windowsByHandle.end(); it++)
	{
		HWND window = it->first;
		WindowData *windowData = it->second;
		if(isSticky(window))
			continue;
		
		bool moved = false;
		if(windowData->desk == currentDesktop) {
			// Move windows off-screen
			windowData->desk->storage->storeRect(windowData->screenPos);
			moved = true;
		} else if(windowData->desk == newDesk) {
			// Move windows from off-screen to on-
			windowData->desk->storage->unstoreRect(windowData->screenPos);
			moved = true;
		}
		
		if(moved)
		{
			SetWindowPos(window, NULL,
				windowData->screenPos.left, windowData->screenPos.top,
				0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
		}
	}
	
	currentDesktop->focused = false;
	newDesk->focused = true;
	
	lastDesktop = currentDesktop;
	currentDesktop = newDesk;
	
	// TODO: Pick the topmost task on this desktop and focus it
	
	/*if(settings->focusCenter)
	{
		POINT p;
		p.x = screenWidth / 2;
		p.y = screenHeight / 2;
		SetForegroundWindow(WindowFromPoint(p));
	}*/
	
	forceRedraw(true);
}

bool VWM::isSticky(HWND window)
{
	char buffer[256];
	if(!GetWindowText(window, buffer, 255))
		return false;
	
	return stickyWindows.find(string(buffer)) != stickyWindows.end();
}

void VWM::beginWindowDrag(WindowData *window, POINT clickOffset)
{
	selectedWindow = window->handle;
	window->dragSourceDesk = window->desk;
	
	// get the distance between the clicked point and the
	// top-left corner of the clicked window
	RECT vwmRect;
	screenToVWMPos(window->desk, window->screenPos, &vwmRect, NULL);
	diffPt = clickOffset;
	
	forceRedraw(true);
	SetCapture(vwmWindow);
}

void VWM::continueWindowDrag(int mouseX, int mouseY)
{
	// TODO: Support dragging onto task areas and desk labels
	if(!selectedWindow)
		return;
	
	if(windowsByHandle.find(selectedWindow) == windowsByHandle.end()) {
		selectedWindow = NULL;
		return;
	}
	WindowData *windowData = windowsByHandle[selectedWindow];
	
	pair<RECT,VirtualDesktop*> dragDestination = getDragDestination(windowData, diffPt, mouseX, mouseY);
	RECT newPos = dragDestination.first;
	VirtualDesktop *newDesk = dragDestination.second;
	
	moveWindow(windowData, newPos, newDesk);
	
	forceRedraw(true);
}

void VWM::moveWindow(WindowData *window, RECT pos, VirtualDesktop *desk)
{
	if(desk != window->desk)
		window->desk = desk;
	
	if(!desk->focused)
		desk->storage->storeRect(pos);
	
	window->screenPos = pos;
	
	SetWindowPos(window->handle, NULL,
	             pos.left, pos.top,
	             0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
}

void VWM::raiseWindow(WindowData *window)
{
	SendMessage(parentWindow, LM_BRINGTOFRONT, 0, (LPARAM)window->handle);
}

void VWM::minimizeWindow(WindowData *window)
{
	SendMessage(window->handle, WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE, 0);
	window->focused = false;
}

void VWM::maximizeWindow(WindowData *window)
{
	SendMessage(window->handle, WM_SYSCOMMAND, (WPARAM)SC_MAXIMIZE, 0);
}

void VWM::restoreWindow(WindowData *window)
{
	SendMessage(window->handle, WM_SYSCOMMAND, (WPARAM)SC_RESTORE, 0);
}

void VWM::endDrag()
{
	if(!selectedWindow)
		return;
	
	WindowData *windowData = windowsByHandle[selectedWindow];
	if(windowData) {
		windowData->dragSourceDesk = NULL;
	}
	
	ReleaseCapture();
	selectedWindow = NULL;
	forceRedraw(false);
}

void VWM::gather()
{
	if(selectedWindow)
		endDrag();
	
	// Move everything onto the current desktop
	for(map<HWND, WindowData*>::iterator it = windowsByHandle.begin(); it != windowsByHandle.end(); it++)
	{
		HWND handle = it->first;
		WindowData *windowData = it->second;
		
		RECT newPos = getGatherTarget(windowData->screenPos);
		windowData->screenPos = newPos;
		
		SetWindowPos(it->first, NULL,
			windowData->screenPos.left, windowData->screenPos.top,
			0, 0,
			SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
		
		windowData->desk = currentDesktop;
	}
	
	// Delete all other desktops
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		if(desktops[ii]!=currentDesktop)
			delete desktops[ii];
	}
	desktops.clear();
	desktops.push_back(currentDesktop);
	currentDesktop->index = 0;
	
	forceRedraw(true);
}

void VWM::toggle()
{
	settings->visible = !settings->visible;
	ShowWindow(vwmWindow, settings->visible?SW_SHOWNOACTIVATE:SW_HIDE );
}

void VWM::show()
{
	settings->visible = TRUE;
	ShowWindow(vwmWindow, SW_SHOWNOACTIVATE);
}

void VWM::hide()
{
	settings->visible = FALSE;
	ShowWindow(vwmWindow, SW_HIDE);
}


static DWORD ModifyStyle(HWND window, DWORD dwRemove, DWORD dwAdd)
{
	DWORD dwStyle = (DWORD) GetWindowLong(window, GWL_STYLE);
	SetWindowLong(window, GWL_STYLE, (dwStyle & ~dwRemove) | dwAdd);
	return dwStyle;
}

void VWM::ontopToggle()
{
	settings->onTop = !settings->onTop;

	HWND desktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktop)
		desktop = GetDesktopWindow();

	ModifyStyle(vwmWindow, WS_POPUP, WS_CHILD);
	SetParent(vwmWindow, settings->onTop ? NULL : desktop);
	ModifyStyle(vwmWindow, WS_CHILD, WS_POPUP);

	SetWindowPos(vwmWindow, settings->onTop ? HWND_TOPMOST : HWND_NOTOPMOST,
        0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOSENDCHANGING);
}


void VWM::moveApp(VirtualDesktop *dest)
{
	if(!dest)
		return;
	HWND foregroundWindow = GetForegroundWindow();
	if(windowsByHandle.find(foregroundWindow) == windowsByHandle.end())
		return;
	WindowData *windowData = windowsByHandle[foregroundWindow];
	
	if(!windowData->desk->focused)
		windowData->desk->storage->unstoreRect(windowData->screenPos);
	if(!dest->focused)
		dest->storage->storeRect(windowData->screenPos);
	windowData->desk = dest;
	
	SetWindowPos(foregroundWindow, NULL,
	             windowData->screenPos.left, windowData->screenPos.top,
	             0, 0,
	             SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
	
	switchDesk(dest);
}

/// Find a desktop given a string description of it. The string can be a
/// name, number, or direction (the directions are: left, right, up, down,
/// next, prev). Directions are relative to relativeTo, which is the
/// current desktop if not specified.
VirtualDesktop *VWM::findDesk(const char *deskName, VirtualDesktop *relativeTo)
{
	if(isdigit(*deskName)) {
		int index = atoi(deskName) - 1;
		return getDeskByIndex(index);
	}
	
	if(!relativeTo)
		relativeTo = currentDesktop;
	
	if(!stricmp(deskName, "next"))
	{
		if(relativeTo->index+1 < (int)desktops.size())
			return desktops[relativeTo->index+1];
		else
			return desktops[0];
	}
	else if(!stricmp(deskName, "prev"))
	{
		if(relativeTo->index > 0)
			return desktops[relativeTo->index-1];
		else
			return desktops[desktops.size()-1];
	}
	else if(!stricmp(deskName, "other"))
	{
		if(lastDesktop != currentDesktop)
			return lastDesktop;
		else
			return findDesk("next");
	}
	
	for(unsigned ii = 0; ii < desktops.size(); ii++)
	{
		if (!stricmp(deskName, desktops[ii]->name.c_str()))
			return desktops[ii];
	}

	return NULL;
}
