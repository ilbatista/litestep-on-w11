#include "vwm.h"
#include "trace.hpp"

StorageArea::StorageArea(StorageManager *owner, int index, int x, int y)
	:owner(owner), index(index), x(x), y(y)
{
}

StorageArea::~StorageArea()
{
	owner->releaseStorageArea(this);
}

RECT StorageArea::getRect()
{
	RECT ret;
	ret.left = x;
	ret.top = y;
	ret.right = x + vwm->getScreenWidth();
	ret.bottom = y + vwm->getScreenHeight();
	return ret;
}

void StorageArea::storeRect(RECT &rect)
{
	rect.left += x;
	rect.right += x;
	rect.top += y;
	rect.bottom += y;
}

void StorageArea::unstoreRect(RECT &rect)
{
	rect.left -= x;
	rect.right -= x;
	rect.top -= y;
	rect.bottom -= y;
}

StorageManager::StorageManager()
{
	maxArea = 0;
}

StorageManager::~StorageManager()
{
}

StorageArea *StorageManager::getStorageArea()
{
	int index;
	set<int>::iterator unusedAreaIt = unusedAreas.begin();
	if(unusedAreaIt != unusedAreas.end()) {
		index = *unusedAreaIt;
		unusedAreas.erase(unusedAreaIt);
	} else {
		index = maxArea++;
	}
	
	int x = vwm->getScreenWidth() * 2 * (index+1);
	int y = 0;
	return new StorageArea(this, index, x, y);
}

void StorageManager::releaseStorageArea(StorageArea *area)
{
	unusedAreas.insert(area->index);
}
