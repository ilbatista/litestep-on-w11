#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include "vwm.h"
#include "trace.hpp"

static const int litestepMessageTypes[] = {
	LM_GETREVID,
	LM_BRINGTOFRONT,
	LM_SWITCHTON,
	LM_WINDOWACTIVATED,
	LM_LISTDESKTOPS,
	LM_GETDESKTOPOF,
	LM_WINDOWCREATED,
	LM_WINDOWDESTROYED,
	LM_REPAINT,
	0
};

//=========================================================
// Message handling
//=========================================================
void VWM::registerEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)litestepMessageTypes);
}

void VWM::unregisterEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)litestepMessageTypes);
}

void VWM::windowProc(Message& message)
{
	switch (message.uMsg)
	{
		case WM_CREATE:            onCreate         (message); break;
		case WM_DESTROY:           onDestroy        (message); break;
		case WM_LBUTTONDOWN:       onMouseButtonDown(message); break;
		case WM_MBUTTONDOWN:       onMouseButtonDown(message); break;
		case WM_RBUTTONDOWN:       onMouseButtonDown(message); break;
		case WM_LBUTTONUP:         onMouseButtonUp  (message); break;
		case WM_MBUTTONUP:         onMouseButtonUp  (message); break;
		case WM_RBUTTONUP:         onMouseButtonUp  (message); break;
		case WM_MOUSEMOVE:         onMouseMove      (message); break;
		case WM_PAINT:             onPaint          (message); break;
		case WM_SYSCOMMAND:        onSysCommand     (message); break;
		case WM_TIMER:             onTimer          (message); break;
		case WM_DROPFILES:         onDropFiles      (message); break;
		case WM_WINDOWPOSCHANGING: onVWMPosChanging (message); break;
		
		case WM_DISPLAYCHANGE:
			setScreenSize( message.lParamLo, message.lParamHi );
			break;
		
		case WM_KEYDOWN:
		case WM_KEYUP:
		case WM_HOTKEY:
			PostMessage(parentWindow, message.uMsg, message.wParam, message.lParam);
			break;
			
		case WM_ENDSESSION:
		case WM_QUERYENDSESSION:
			message.lResult = SendMessage(parentWindow, message.uMsg, message.wParam, message.lParam);
			break;
		
		case LM_GETREVID:          onGetRevId       (message); break;
		case LM_REPAINT:           onPaint          (message); break;
		case LM_WINDOWACTIVATED:   onWindowActivated(message); break;
		case LM_BRINGTOFRONT:      onBringToFront   (message); break;
		case LM_SWITCHTON:         onSwitchToN      (message); break;
		case LM_LISTDESKTOPS:      onListDesktops   (message); break;
		case LM_GETDESKTOPOF:      onGetDesktopOf   (message); break;
		
		// TODO: Observe window *movement*, too
		case LM_WINDOWCREATED:
		case LM_WINDOWDESTROYED:
			if(updateWindowList())
				forceRedraw(false);
			break;
		
		default:
			message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);
			break;
	}
}

void VWM::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_BRINGTOFRONT, LM_SWITCHTON, LM_WINDOWACTIVATED, LM_LISTDESKTOPS, LM_GETDESKTOPOF, 0};

	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)msgs);

	// Unregister window hook
	HWND hookManager = FindWindow("HookMgrClass", NULL);
	SendMessage(hookManager, LM_UNREGISTERMESSAGE, (WPARAM)WM_WINDOWPOSCHANGED, (LPARAM)NULL);

	cleanupBangs();

	// Switch to desk 1 on exit
	// This should be something considerably more elaborate
	switchDesk(0);
	
	//destroyWindow();

	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
		delete ii->second;
}

void VWM::onCreate(Message& message)
{
	//finalize();
}

void VWM::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);
	sprintf(buf, VERSION_STRING);
	message.lResult = strlen(buf);
}

void VWM::onMouseButtonDown(Message& message)
{
	int x = message.lParamLo;
	int y = message.lParamHi;
	
	WindowData *task = taskFromPoint(x, y);
	VirtualDesktop *desk = vwmPointToDesk(x, y);
	VirtualDesktop *deskLabel = labelPointToDesk(x, y);
	
	switch(message.uMsg)
	{
		case WM_RBUTTONDOWN:
		case WM_MBUTTONDOWN:  // Switch to clicked-on desktop
			if(deskLabel)
				switchDesk(deskLabel);
			else if(desk)
				switchDesk(desk);
			break;
		
		case WM_LBUTTONDOWN:
			// Left button: If clicking on a desktop label, switch to that
			// desktop. If clicking on a window in a VWM, start dragging
			// that window. If clicking on a window in a task tray, switch to
			// that desktop, raise that window, and start dragging.
			if(deskLabel) {
				switchDesk(deskLabel);
				break;
			}
			
			POINT dragOffset;
			if(desk) {
				task = vwmWindowClick(desk, x-desk->vwmX, y-desk->vwmY);
				if(task) {
					RECT windowRect;
					screenToVWMPos(desk, task->screenPos, &windowRect, NULL);
					dragOffset.x = x - windowRect.left - desk->vwmX;
					dragOffset.y = y - windowRect.top - desk->vwmY;
				}
			} else if(task) {
				if(task->focused && !task->minimized)
				{
					// Clicking on the foreground task minimizes it unless you
					// move the mouse first
					pendingMinimize = task->handle;
					break;
				}
				else
				{
					// Clicking on a task which isn't the foreground task focuses it
					RECT windowRect;
					screenToVWMPos(task->desk, task->screenPos, &windowRect, NULL);
					dragOffset.x = (windowRect.right-windowRect.left) / 2;
					dragOffset.y = (windowRect.bottom-windowRect.top) / 2;
					
					switchDesk(task->desk);
					raiseWindow(task);
					forceRedraw(true);
				}
			}
			
			if(task) {
				beginWindowDrag(task, dragOffset);
			} else {
				// If this was on empty space, then start dragging the VWM
				// window, if it's movable.
				if(settings->movable)
					message.lResult = SendMessage(vwmWindow, WM_SYSCOMMAND, SC_MOVE|2, message.lParam);
			}
			break;
	}
}

void VWM::onMouseButtonUp(Message& message)
{
	switch(message.uMsg)
	{
		case WM_RBUTTONUP:
			break;
		case WM_MBUTTONDOWN:  // Select desktop
			break;
		case WM_LBUTTONUP:  // Window dragging
			if(pendingMinimize) {
				if(windowsByHandle.find(pendingMinimize)!=windowsByHandle.end()) {
					WindowData *window = windowsByHandle[pendingMinimize];
					minimizeWindow(window);
					forceRedraw(true);
				}
				pendingMinimize = NULL;
			}
			else if(selectedWindow)
				endDrag();
			break;
	}
}

void VWM::onMouseMove(Message& message)
{
	int x = message.lParamLo;
	int y = message.lParamHi;
	
	// If you drag an icon off its foreground area, it goes from 'maybe
	// minimize this' to 'drag this'.
	if(pendingMinimize)
	{
		if(windowsByHandle.find(pendingMinimize) == windowsByHandle.end()) {
			// The window has disappeared/closed since we started!
			pendingMinimize = NULL;
		} else {
			// If we drag it off its original icon area, it becomes a drag/drop
			// instead of a click
			WindowData *window = windowsByHandle[pendingMinimize];
			if(window != taskFromPoint(x, y)) {
				POINT dragOffset = {0,0};
				pendingMinimize = NULL;
				beginWindowDrag(window, dragOffset);
			}
		}
	}
	
	if(selectedWindow)
		continueWindowDrag(x, y);
}

void VWM::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(parentWindow, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);
}

void VWM::onWindowActivated(Message& message)
{
}

void VWM::onTimer(Message& message)
{
	// Update the window list, checking what the foreground window is before
	// and after.
	HWND oldTopWindow = zOrder.size() ? zOrder[0] : NULL;
	bool changed = updateWindowList();
	HWND newTopWindow = zOrder.size() ? zOrder[0] : NULL;
	
	if(settings->switchOnFocus && (oldTopWindow != newTopWindow) && newTopWindow) {
		switchDesk(getDeskFromWnd(newTopWindow));
		changed = true;
	}
	
	// Dirty the VWM display to force it to redraw
	// TODO: Only redraw when there are changes
	if(changed)
		forceRedraw(false);
}

// TODO: Test and rewrite this
void VWM::onDropFiles(Message& message)
{
	POINT pt;
	DragQueryPoint( (HDROP)message.wParam, &pt );
	
	VirtualDesktop *newDesk = vwmPointToDesk(pt.x, pt.y);
	if(!newDesk) return;
	switchDesk(newDesk);

	int numFiles = DragQueryFile( (HDROP)message.wParam, 0xFFFFFFFF, NULL, 0 );
	for(int i=0; i<numFiles; i++)
	{
		char filename[_MAX_PATH];
		DragQueryFile( (HDROP)message.wParam, i, filename, _MAX_PATH);
		if (filename && *filename)
			LSExecute(NULL, filename, SW_SHOWNORMAL);
	}
	DragFinish( (HDROP)message.wParam );
	forceRedraw(true);
}

// TODO: Rewrite this
void VWM::onVWMPosChanging(Message& message)
{
	LPWINDOWPOS windowPos = (LPWINDOWPOS)message.lParam;

	if ( !( windowPos->flags & SWP_NOSIZE ) )
	{
		windowWidth = windowPos->cx;
		windowHeight = windowPos->cy;
	}

	if ( !( windowPos->flags & SWP_NOMOVE ) )
	{
		if (settings->snapDistance)
		{
			if ( abs(windowPos->x) <= settings->snapDistance )
				windowPos->x = SCREEN_LEFT;
			if ( abs(windowPos->y) <= settings->snapDistance )
				windowPos->y = SCREEN_TOP;
			if ( abs(windowPos->x + windowWidth - screenWidth) <= settings->snapDistance )
				windowPos->x = screenWidth - windowWidth;
			if ( abs(windowPos->y + windowHeight - screenHeight) <= settings->snapDistance )
				windowPos->y = screenHeight - windowHeight;
		}
		windowX = windowPos->x;
		windowY = windowPos->y;
	}
	message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);
}

void VWM::onBringToFront(Message &message)
{
	HWND hWnd = (HWND) message.lParam;
	VirtualDesktop *desk = getDeskFromWnd(hWnd);

	if (currentDesktop != desk)
		switchDesk(desk);

	SwitchToThisWindow(hWnd, TRUE);
	message.lResult = TRUE;
}

void VWM::onSwitchToN(Message &message)
{
	message.lResult = TRUE;
	int desk = (int) message.wParam;
	if(desk < 0 || desk >= (int)desktops.size())
		return;
	
	VirtualDesktop *newDesk = desktops[desk];
	switchDesk(newDesk);
}

void VWM::onListDesktops(Message &message)
{
	LSDESKTOPINFO deskInfo;

	for (unsigned ii = 0; ii < desktops.size(); ii++)
	{
		deskInfo.size = sizeof(LSDESKTOPINFO);
		deskInfo.icon = 0;
		deskInfo.isCurrent = desktops[ii]->focused;
		deskInfo.number = ii;

		strcpy(deskInfo.name, desktops[ii]->name.c_str());

		SendMessage((HWND) message.wParam, LM_DESKTOPINFO, 0, (LPARAM) &deskInfo);
	}

	message.lResult = TRUE;
}

void VWM::onGetDesktopOf(Message &message)
{
	VirtualDesktop *desk = getDeskFromWnd((HWND) message.wParam);
	message.lResult = desk->index;
}
