#!/bin/bash

VERSION=0.1
DISTDIR=screenwm-$VERSION

if [ -d "$DISTDIR" ]; then
	rm -rf "$DISTDIR"
fi

mkdir "$DISTDIR"
mkdir "$DISTDIR/src"

cp Release/screenvwm.dll "$DISTDIR"

cp -R screenhk "$DISTDIR/src"
cp -R *.cpp *.h *.hpp *.vcproj *.sln *.txt Doxyfile *.sh "$DISTDIR/src"

# Remove intermediate files
(
	cd "$DISTDIR/src"
	rm -rf Release Debug screenhk/Release screenhk/Debug
)

# Zip it all up
echo zip -r "screenwm-$VERSION.zip" "$DISTDIR"
zip -r screenwm-$VERSION.zip "$DISTDIR"

