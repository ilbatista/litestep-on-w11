#include <litestep/lsapi/lsapi.h>
#include <string>
#include "trace.hpp"

TraceStream trace;

const char *traceFilename = "screenvwm.log";

template<> TraceStream &TraceStream::operator<<(int x) {
	if(initIfNeeded()) {
		fprintf(fout, "%i", x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(unsigned x) {
	if(initIfNeeded()) {
		fprintf(fout, "%u", x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(long x) {
	if(initIfNeeded()) {
		fprintf(fout, "%i", (int)x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(std::string x) {
	if(initIfNeeded()) {
		fprintf(fout, "%s", (int)x.c_str());
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(char *x) {
	if(initIfNeeded()) {
		fprintf(fout, "%s", x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(const char *x) {
	if(initIfNeeded()) {
		fprintf(fout, "%s", x);
		fflush(fout);
	}
	return *this;
}
template<> TraceStream &TraceStream::operator<<(RECT rect) {
	if(initIfNeeded()) {
		fprintf(fout, "(l=%i,t=%i,r=%i,b=%i)", rect.left, rect.top, rect.right, rect.bottom);
		fflush(fout);
	}
	return *this;
}

bool TraceStream::initIfNeeded()
{
	if(!fout)
		fout = fopen(traceFilename, "w");
	return(fout != NULL);
}

void TraceStream::close()
{
	if(fout) {
		fclose(fout);
		fout = NULL;
	}
}