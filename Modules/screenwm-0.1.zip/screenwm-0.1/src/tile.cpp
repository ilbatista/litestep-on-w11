#include "vwm.h"

/// Arrange each window in windows so that no two windows overlap, and the
/// entire desktop is covered. Sets screenRect for each window to where it
/// should be placed, and visited for each moved window to ture.
void tileWindows(RECT boundingRect, vector<WindowData*> windows)
{
	// Trivial cases: 0 or 1 windows
	if(!windows.size())
		return;
	if(windows.size()==1) {
		windows[0]->screenPos = boundingRect;
		windows[0]->visited = true;
	}
	
	// TODO
}