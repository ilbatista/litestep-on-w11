//
// This is part of ScreenHK, the hotkey module for ScreenWM.
// Copyright (C) 2008 James Babcock (jimrandomh)
// This program is partially derived from the Litestep shell.
// Copyright (C) 1997-2001 The LiteStep Development Team
// Copyright (C) 1997-98 Francis Gastellu (aka Lone Runner/Aegis)
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
/****************************************************************************
5/7/08 - Jim Babcock (jimrandomh)
  - Lots of refactoring
  - Rewrote the config parser
  - Added Hotkey-group support
11/20/02 - Christoffer Sj�berg (Vendicator)
  - Enter old sdk VK_SLEEP fix from ilmcuts
11/15/02 - Christoffer Sj�berg (Vendicator)
  - Added Play, Zoom and Sleep keys (don't have a kb to test them tho)
06/21/01 - Bobby G. Vinyard (Message)
  - Fixed it so that it closed an open file quicker when adding explorer
    hotkeys
10/02/00 - Joachim Calvert (NeXTer)
  - Enter, Mul, Div, Add, Sub and Dec (decimal key) are now supported
08/30/00 - Joachim Calvert (NeXTer)
  - Shouldn't reserve unused hotkeys anymore (specifically ctrl-esc), let me
    know if it doesn't work
08/17/00 - Joachim Calvert (NeXTer)
  - Now responds to the !Refresh command
04/25/00 - Bobby G. Vinyard (Message)
  - Ugh forgot to clear the hotkey maps when hotkeys were unloaded
04/20/00 - Joachim Calvert (NeXTer)
  - Now uses the LSWinBase library
04/18/00 - Bobby G. Vinyard (Message)
  - Rewrite based on the Desktop2 code
****************************************************************************/

#include "hotkey.h"
#include "resource.h"

// fix for older sdks
#ifndef VK_SLEEP
	#define VK_SLEEP 0x5F
#endif

const char *versionNumber = "2.0";

static const VKTable vkTable[] =
    {
        {"ESCAPE", VK_ESCAPE},
        {"F1", VK_F1},
        {"F2", VK_F2},
        {"F3", VK_F3},
        {"F4", VK_F4},
        {"F5", VK_F5},
        {"F6", VK_F6},
        {"F7", VK_F7},
        {"F8", VK_F8},
        {"F9", VK_F9},
        {"F10", VK_F10},
        {"F11", VK_F11},
        {"F12", VK_F12},
        {"PAUSE", VK_PAUSE},
        {"INSERT", VK_INSERT},
        {"DELETE", VK_DELETE},
        {"HOME", VK_HOME},
        {"END", VK_END},
        {"PAGEUP", VK_PRIOR},
        {"PAGEDOWN", VK_NEXT},
        {"LEFT", VK_LEFT},
        {"RIGHT", VK_RIGHT},
        {"UP", VK_UP},
        {"DOWN", VK_DOWN},
        {"TAB", VK_TAB},
        {"BACKSPACE", VK_BACK},
        {"SPACEBAR", VK_SPACE},
        {"APPS", VK_APPS},
        {"ENTER", VK_RETURN},
        {"NUM0", VK_NUMPAD0},
        {"NUM1", VK_NUMPAD1},
        {"NUM2", VK_NUMPAD2},
        {"NUM3", VK_NUMPAD3},
        {"NUM4", VK_NUMPAD4},
        {"NUM5", VK_NUMPAD5},
        {"NUM6", VK_NUMPAD6},
        {"NUM7", VK_NUMPAD7},
        {"NUM8", VK_NUMPAD8},
        {"NUM9", VK_NUMPAD9},
        {"MUL", VK_MULTIPLY},
        {"DIV", VK_DIVIDE},
        {"ADD", VK_ADD},
        {"SUB", VK_SUBTRACT},
        {"DEC", VK_DECIMAL},

		// new
		{"PLAY", VK_PLAY},
		{"ZOOM", VK_ZOOM},
		{"SLEEP", VK_SLEEP}

		// new, win2k / xp only

		//{"BROWSERBACK", VK_BROWSER_BACK},
		//{"BROWSERFORWARD", VK_BROWSER_FORWARD},
		//{"BROWSERRELOAD", VK_BROWSER_REFRESH},
		//{"BROWSERSTOP", VK_BROWSER_STOP},
		//{"BROWSERSRC", VK_BROWSER_SEARCH},
		//{"BROWSERFAV", VK_BROWSER_FAVORITE},
		//{"BROWSERSTART", VK_BROWSER_HOME},
		//{"VOLUMEMUTE", VK_VOLUME_MUTE},
		//{"VOLUMEUP", VK_VOLUME_DOWN},
		//{"VOLUMEDOWN", VK_VOLUME_UP},
		//{"MEDIANEXT", VK_MEDIA_NEXT_TRACK},
		//{"MEDIAPREV", VK_MEDIA_PREV_TRACK},
		//{"MEDIASTOP", VK_MEDIA_STOP},
		//{"MEDIAPLAY", VK_MEDIA_PLAY_PAUSE},
		//{"MEDIASELECT", VK_LAUNCH_MEDIA_SELECT},
		//{"MAIL", VK_LAUNCH_MAIL},
		//{"APP1", VK_LAUNCH_APP1},
		//{"APP2", VK_LAUNCH_APP2}
    };

#define MAX_VKEYS (sizeof(vkTable) / sizeof(VKTable))

const char szAppName[] = "HotkeyWindow";

Hotkey *hotkey; // The module


//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code = 0;

	Window::init(dllInst);
	hotkey = new Hotkey(parentWnd, code);

	return code;
}


void quitModule(HINSTANCE dllInst)
{
	delete hotkey;
}


//=========================================================
// Module code
//=========================================================
//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Hotkey::Hotkey(HWND parentWnd, int& code):
		Window(szAppName)
{
	if (!createWindow(WS_EX_TOOLWINDOW, "LSHotkey", WS_CHILD,
	                  0, 0, 0, 0, parentWnd))
	{
		RESOURCE_MSGBOX(instance(), IDS_HOTKEY_ERROR1,
		                "Error creating window", szAppName);

		code = 1;
		return ;
	}
	code = 0;
}


Hotkey::~Hotkey()
{
	destroyWindow();
}

bool Hotkey::parseHotkey(char *buffer, HotkeyType *hotkey)
{
	// TODO: Rewrite this
	char	token1[4096], token2[4096], token3[4096], token4[4096], extra_text[4096];
	LPSTR	tokens[4];
	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	token1[0] = token2[0] = token3[0] = token4[0] = extra_text[0] = '\0';
	
	int count = LCTokenize (buffer, tokens, 4, extra_text);
	
	if(count != 4)
		return false;
	
	hotkey->modifiers = 0;
	char *tmp = strtok(token2, "+");

	while (tmp)
	{
		if (!strcmpi(tmp, "Win"))
			hotkey->modifiers |= MOD_WIN;
		if (!strcmpi(tmp, "Alt"))
			hotkey->modifiers |= MOD_ALT;
		if (!strcmpi(tmp, "Ctrl"))
			hotkey->modifiers |= MOD_CONTROL;
		if (!strcmpi(tmp, "Shift"))
			hotkey->modifiers |= MOD_SHIFT;
		tmp = strtok(NULL, "+");
	}

	if (lstrlen(token3) == 1)
		hotkey->ch = strupr(token3)[0];
	else
	{
		for(int i = 0; i < MAX_VKEYS; i++)
		{
			if(!strcmpi(vkTable[i].key, token3))
			{
				hotkey->ch = vkTable[i].vKey;
				break;
			}
		}
	}

	hotkey->command = token4;
	hotkey->parameters = extra_text;
	return true;
}


void Hotkey::loadHotkeys()
{
	loadExplorerKeys = GetRCBool("HotkeyLoadExplorerKeys", TRUE) != FALSE;
	noWinKeyPopup = GetRCBool("HotkeyNoWinKeyPopup", TRUE) != FALSE;
	noShellWarning = GetRCBool("LSNoShellWarning", TRUE) != FALSE;
	explorerNoWarn = GetRCBool("ExplorerNoWarn", TRUE) != FALSE;

	FILE *f = LCOpen(NULL);
	if(f) {
		char buffer[4096];
		buffer[0] = 0;

		while(LCReadNextConfig(f, "*Hotkey", buffer, sizeof (buffer)))
		{
			HotkeyType hotkey;
			if(parseHotkey(buffer, &hotkey)) {
				hotKeys.push_back(hotkey);
				RegisterHotKey(hWnd, hotKeys.size(), hotkey.modifiers, hotkey.ch);
			}
		}
		LCClose(f);
	}
	
	if(loadExplorerKeys)
		loadExplorerHotkeys();
	
	if (!noWinKeyPopup)
	{
		if((!RegisterHotKey(hWnd, GlobalAddAtom("LWIN_KEY"), MOD_WIN, VK_LWIN)) ||
		        (!RegisterHotKey(hWnd, GlobalAddAtom("RWIN_KEY"), MOD_WIN, VK_RWIN)))
		{
			RESOURCE_MSGBOX(instance(), IDS_HOTKEY_ERROR2,
			                "Error registering Win Key", szAppName);
		}
		if(!(noShellWarning || explorerNoWarn))
		{
			if(!RegisterHotKey(hWnd, GlobalAddAtom("CTL_ESC"), MOD_CONTROL, VK_ESCAPE))
			{
				RESOURCE_MSGBOX(instance(), IDS_HOTKEY_ERROR3,
				                "Error registering Ctrl+Esc", szAppName);
			}
		}
	}
}


void Hotkey::loadExplorerHotkeys()
{
	HKEY shellFoldersKey;
	DWORD dataType, dataLength = 1024;

	char szAllStartMenu[1024];	// WinNT
	char szAllDesktop[1024];	// WinNT
	char szUserStartMenu[1024];
	char szUserDesktop[1024];

	// Hotkey Code
	RegisterHotKey(hWnd, GlobalAddAtom("REINIT"), MOD_CONTROL | MOD_ALT | MOD_SHIFT, 'R');

	RegOpenKey(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders", &shellFoldersKey);
	dataLength = sizeof (szUserStartMenu);
	if (RegQueryValueEx(shellFoldersKey, "Start Menu", NULL, &dataType, (LPBYTE) szUserStartMenu, &dataLength) != ERROR_SUCCESS)
		strcpy(szUserStartMenu, "");
	dataLength = sizeof (szUserDesktop);
	if (RegQueryValueEx(shellFoldersKey, "Desktop", NULL, &dataType, (LPBYTE) szUserDesktop, &dataLength) != ERROR_SUCCESS)
		strcpy(szUserDesktop, "");
	RegCloseKey(shellFoldersKey);

	RegOpenKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders", 0, KEY_READ, &shellFoldersKey);
	dataLength = sizeof (szAllStartMenu);
	if (RegQueryValueEx(shellFoldersKey, "Common Start Menu", NULL, &dataType, (LPBYTE) szAllStartMenu, &dataLength) != ERROR_SUCCESS)
		strcpy(szAllStartMenu, "");
	dataLength = sizeof (szAllDesktop);
	if (RegQueryValueEx(shellFoldersKey, "Common Desktop", NULL, &dataType, (LPBYTE) szAllDesktop, &dataLength) != ERROR_SUCCESS)
		strcpy(szAllDesktop, "");
	RegCloseKey(shellFoldersKey);

	if (strcmp(szUserStartMenu, ""))
	{
		SetCurrentDirectory(szUserStartMenu);
		findLnks(szUserStartMenu);
	}
	if (strcmp(szUserDesktop, ""))
	{
		SetCurrentDirectory(szUserDesktop);
		findLnks(szUserDesktop);
	}
	if (strcmp(szAllStartMenu, ""))
	{
		SetCurrentDirectory(szAllStartMenu);
		findLnks(szAllStartMenu);
	}
	if (strcmp(szAllDesktop, ""))
	{
		SetCurrentDirectory(szAllDesktop);
		findLnks(szAllDesktop);
	}
}


void Hotkey::findLnks(const char *baseSearchDir)
{
	WIN32_FIND_DATA findDirData;
	WIN32_FIND_DATA findLnkData;
	HANDLE hDirFind;
	HANDLE hLnkFind;

	SetCurrentDirectory(baseSearchDir);
	hLnkFind = FindFirstFile("*.lnk", &findLnkData);
	if(hLnkFind != INVALID_HANDLE_VALUE)
	do {
		if (findLnkData.dwFileAttributes ^ FILE_ATTRIBUTE_DIRECTORY)
			addExplorerHotkey(baseSearchDir, findLnkData.cFileName);
	} while (FindNextFile(hLnkFind, &findLnkData));
	
	FindClose(hLnkFind);

	hDirFind = FindFirstFile("*.*", &findDirData);
	if(hDirFind != INVALID_HANDLE_VALUE)
	do {
		if(!(findDirData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
			continue;
		if(!strcmp(findDirData.cFileName, ".") || !strcmp(findDirData.cFileName, ".."))
			continue;
		
		char nextSearchDir[1024];
		strcpy(nextSearchDir, baseSearchDir);
		strcat(nextSearchDir, "\\");
		strcat(nextSearchDir, findDirData.cFileName);
		findLnks(nextSearchDir);
		SetCurrentDirectory(baseSearchDir);
	} while (FindNextFile(hDirFind, &findDirData));
	FindClose(hDirFind);
}


// TODO: This looks sketchy to me; do all LNKs really have a hotkey at
// precisely offset 64? --jimrandomh
void Hotkey::addExplorerHotkey(LPCSTR szBaseFileDir, LPCSTR szFileName)
{
	BYTE btHotKey;
	BYTE btModifier;
	LONG lHotKeyOffset = 64;
	DWORD dwRead;
	char lnkFile[1024];
	ATOM aHotKey;

	strcpy(lnkFile, szBaseFileDir);
	strcat(lnkFile, "\\");
	strcat(lnkFile, szFileName);

	HANDLE file = CreateFile(lnkFile,
	                   GENERIC_READ,
	                   0,
	                   NULL,
	                   OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN,
	                   NULL);
	if(file == INVALID_HANDLE_VALUE)
		return;
	
	SetFilePointer(file, lHotKeyOffset, NULL, FILE_BEGIN);
	ReadFile(file, &btHotKey, 1, &dwRead, NULL);
	ReadFile(file, &btModifier, 1, &dwRead, NULL);
	CloseHandle(file);

	aHotKey = GlobalAddAtom(lnkFile);
	if(!aHotKey)
		return;
	
	atomHotkeys.push_back(aHotKey);
	if (btHotKey && btModifier)
	{
		int modifierKeys = 0;
		int modifierMask = 0;
		
		if(btModifier&1) { modifierMask |= MOD_SHIFT;   modifierKeys++; }
		if(btModifier&2) { modifierMask |= MOD_CONTROL; modifierKeys++; }
		if(btModifier&4) { modifierMask |= MOD_ALT;     modifierKeys++; }
		
		// Don't register hotkeys with no modifiers or with only one modifier,
		// because those will surely conflict with application hotkeys.
		if(modifierKeys < 2)
			return;
		
		RegisterHotKey(hWnd, aHotKey, modifierMask, btHotKey);
	}
}


void Hotkey::freeHotkeys()
{
	UnregisterHotKey(hWnd, GlobalFindAtom("LWIN_KEY"));
	UnregisterHotKey(hWnd, GlobalFindAtom("RWIN_KEY"));
	UnregisterHotKey(hWnd, GlobalFindAtom("CTRL_ESC"));
	GlobalDeleteAtom(GlobalFindAtom("LWIN_KEY"));
	GlobalDeleteAtom(GlobalFindAtom("RWIN_KEY"));
	GlobalDeleteAtom(GlobalFindAtom("CTRL_ESC"));

	for (size_t ii=0; ii<hotKeys.size(); ii++)
		UnregisterHotKey(hWnd, ii);
	hotKeys.clear();
	
	if (loadExplorerKeys)
		freeExplorerHotkeys();
}


void Hotkey::freeExplorerHotkeys()
{
	ATOM aHotKey;

	aHotKey = GlobalFindAtom("REINIT");
	UnregisterHotKey(hWnd, aHotKey);
	GlobalDeleteAtom (aHotKey);

	for (size_t jj=0; jj<atomHotkeys.size(); jj++)
	{
		aHotKey = atomHotkeys[jj];
		if (aHotKey != 0) {
			UnregisterHotKey(hWnd, aHotKey);
			GlobalDeleteAtom(aHotKey);
		}
	}
	atomHotkeys.clear();
}

void Hotkey::showPopup()
{
	ParseBangCommand(hWnd, "!Popup", NULL);
}


//=========================================================
// Message handling
//=========================================================

void Hotkey::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	MESSAGE(onCreate, WM_CREATE)
	MESSAGE(onDestroy, WM_DESTROY)
	MESSAGE(onEndSession, WM_ENDSESSION)
	MESSAGE(onEndSession, WM_QUERYENDSESSION)
	REJECT_MESSAGE(WM_ERASEBKGND)
	REJECT_MESSAGE(WM_PAINT)
	MESSAGE(onGetRevId, LM_GETREVID)
	MESSAGE(onRefresh, LM_REFRESH)
	MESSAGE(onHotkey, WM_HOTKEY)
	MESSAGE(onSysCommand, WM_SYSCOMMAND)
	MESSAGE(onTimer, WM_TIMER)
	END_MESSAGEPROC
}


void Hotkey::onCreate(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	loadHotkeys();
}


void Hotkey::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	freeHotkeys();
}


void Hotkey::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}


void Hotkey::onGetRevId(Message& message)
{
	LPSTR buf = (LPSTR)(message.lParam);

	switch (message.wParam)
	{
		case 0:
        case 1:
			sprintf(buf, "screenhk.dll: %s", versionNumber);
			buf[strlen(buf) - 1] = '\0';
			break;
		default:
			strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}


void Hotkey::onRefresh(Message& message)
{
	freeHotkeys();
	loadHotkeys();
}


void Hotkey::onHotkey(Message& message)
{
	size_t num = message.wParam - 1;
	
	if (num < hotKeys.size())
	{
		if(!hotKeys[num].command.length())
			return;
		
		if (hotKeys[num].command[0] == '!')
		{
			ParseBangCommand(hWnd, hotKeys[num].command.c_str(), hotKeys[num].parameters.c_str());
		}
		else
		{
			char workDirectory[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR];

			_splitpath(hotKeys[num].command.c_str(), drive, dir, NULL, NULL);
			strcpy(workDirectory, drive);
			strcat(workDirectory, dir);

			LSExecuteEx(GetDesktopWindow(), NULL, hotKeys[num].command.c_str(), hotKeys[num].parameters.c_str(), workDirectory, SW_SHOWNORMAL);

		}
		KillTimer(hWnd, 1);
	}
	else
	{
		char command[1024];

		if(GlobalGetAtomName((ATOM)message.wParam, command, 1024) > 0)
		{
			if(!strcmp(command, "CTL_ESC"))
			{
				SendMessage(hParent, LM_POPUP, 0, 0);
			}
			else if(!strcmp(command, "REINIT") && loadExplorerKeys)
			{
				freeExplorerHotkeys();
				loadExplorerHotkeys();
			}
			else if(!strcmp(command, "LWIN_KEY") || !strcmp(command, "RWIN_KEY"))
			{
				// TODO FIXME: Using a timer-delay for the Windows key is a conspicuously bad idea
				SetTimer(hWnd, 1, 750, NULL);
			}
			else
			{
				KillTimer(hWnd, 1);
				if (loadExplorerKeys)
				{
					char workDirectory[_MAX_PATH];
					char drive[_MAX_DRIVE];
					char dir2[_MAX_DIR];
					
					// Take the directory portion of the command to get a
					// working directory. TODO FIXME: If this is derived from
					// an LNK, that might have a (different) working directory
					// specified.
					_splitpath(command, drive, dir2, NULL, NULL);
					strcpy(workDirectory, drive);
					strcat(workDirectory, dir2);

					LSExecuteEx(hWnd, NULL, command, NULL, workDirectory, SW_SHOWNORMAL);
				}
			}
		}
	}
}

void Hotkey::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Hotkey::onTimer(Message& message)
{
	if (message.wParam == 1)
	{
		showPopup();
		KillTimer(hWnd, 1);
	}
}
