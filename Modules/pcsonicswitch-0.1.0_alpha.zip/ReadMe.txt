PCSonicSwitch.dll. Created by Brian Todoroff.

PCSonicSwitch allows you to specify multiple sounds for any of the Windows
sound events listed in the Sounds tab of the Sounds and Multimedia control
panel.  The reason for its existance is that I got bored with the ding I
got when ever I finished a compile and wanted more personality.
Unfortunately I could only hear "Doh!" so many times without getting
annoyed. Now I hear one of a random selection of sounds each time I build.
 

Release Notes:
THIS IS ALPHA SOFTWARE! I have been using this for about a week on my work
 computer with out any problems at all, BUT this is an alpha release so that 
 I can get it tested on a wider range of systems.  So far I have only used
 Windows 2000 since that is the only Windows version I have running on any
 of my computers. Please let me know if you encouter any issues, if you have 
 any questions, or what OS you have used it on. Thanks and enjoy! 


.rc Commands
*PCSSInterval <interval in milliseconds>
	Sets the interval between checks to change a particular sound. Defaults
	 to 5000 (5 seconds). 0 will prevent sounds from being automatically
	 switched.

*PCSSSound <soundevent> <interval> <sound1> <sound2> ...
	This is the heart of the module. Use it to configure the sound events
	 you want to randomize.
	Sound events can be specified in two ways:
		- As a caption from the sounds control panel by using a string.
		 i.e. "Build Complete" for MSDN's build succeded sound.  Stick with
		 these for now.
		- As an event name by preceding a string with #. i.e. 
		"#BuildComplete". Event names are (unlike captions) garenteed to be 
		unique, but they are a bit of a pain to look up.
	The interval specifies how often, given the resolution of *PCSSInterval,
	 this sound is randomized. An interval of 0 will be randomized when the 
	 module loads but never again. Use this for startup sounds and such.
	The remaing parameters specify fully qualified paths to the sounds used for
	 that event. Sounds can be specified individually or as a search string.
		-Individual sounds use a quoted string for the path. i.e. 
		 "C:\LiteStep\Sounds\Compile Error\doh.wav"
		-As search path starts with a '#' and may use wildcards. i.e. 
		 "#C:\LiteStep\Sounds\Compile Good\*.wav". All matching files will be
		 used.
	Any combination of individul paths and search paths may be listed and they
	 will be combined.  If two or more *PCSSSound lines appear in the .rc
	 files, the last one will be used and the earlier ones ignored.

Bang Commands
!PCSSInterval <interval in milliseconds>
	Sets the interval between checks to change a particular sound. Defaults to
	 5000 (5 seconds).

!PCSSSetSound <event> <soundfile>
	Sets the sound for a particular event.  The soundfile should be a fully
	 qualified path to be safe.  This event does not need to appear in Step.rc, 
	 but, if it does, the sound set with this command will be overwritten when 
	 the sound is next randomized.

!PCSSNewSounds 
	Randomizes all sounds immediately and resets their intervals.



www.photoncloud.com
brian@todoroff.com


