#include "lock.h"
#include "toggle.h"

#define C_ERROR			0
#define	C_ON			1
#define C_OFF			2
#define C_TOGGLE		3
#define C_FLASH_ON		4
#define C_FLASH_OFF		5
#define C_FLASH_TOGGLE	6
#define C_FLASH_PP		7
#define C_FLASH_MM		8

extern Toggle *toggle; // The module

//=========================================================
// Lock class code
//=========================================================

void Lock::readRCSettings(char *type)
{
	char buffer[MAX_BUFFER];

	if ( GetRCString( type, buffer, "", 16 ) )
	{
		if ( !stricmp( buffer, "on" ) )
			setState(true);
		else if ( !stricmp( buffer, "off" ) )
			setState(false);
		else if ( !stricmp( buffer, "toggle" ) )
			setState(!getState());
	}
		//why does it hang ?????
		/*this->FlashSpeed = GetRCInt(TEXT("ScrollFlashSpeed"),0);
		if(this->FlashSpeed < 200)
			this->FlashSpeed = 200;*/
}

Lock::Lock(unsigned char Type):
	LockType(Type),
	FlashSpeed(750),
	TimerNumber(0)
{
	OriginalState = getState();
}

bool Lock::getState()
{
	return (GetKeyState(LockType) != 0);
}

void Lock::setState(bool State)
{
  if(State != getState())
	  toggleState();
}

void Lock::toggleState()
{
	keybd_event( LockType, 0x45, KEYEVENTF_EXTENDEDKEY | 0, 0 );
	keybd_event( LockType, 0x45, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);    
}

void Lock::startTimer()
{
	SetTimer(toggle->gethWnd(), LockType, FlashSpeed, NULL);
}

void Lock::stopTimer()
{
	KillTimer(toggle->gethWnd(), LockType);
	if(getState() != OriginalState)
		toggleState();
	this->TimerNumber = 0;
}

short int Lock::getCase(LPCSTR args)
{
    char token1[MAX_BUFFER], extra_text[MAX_BUFFER];
    char* tokens[2];
    int count;
    tokens[0] = token1;

    count = LCTokenize (args, tokens, 1, extra_text);

	for(unsigned int i = 0 ; i < strlen(token1) ; ++i)
		token1[i] = tolower(token1[i]);

	if(!strcmp(token1,"on"))
		return C_ON;
	else if(!strcmp(token1,"off"))
		return C_OFF;
	else if(!strcmp(token1,"toggle"))
		return C_TOGGLE;
	else if(!strcmp(token1,"flash"))
	{
		tokens[0] = token1;
		count = LCTokenize (extra_text, tokens, 1, extra_text);

		for(unsigned int i = 0 ; i < strlen(token1) ; ++i)
			token1[i] = tolower(token1[i]);

		if(!strcmp(token1,"on"))
		{
			tokens[0] = token1;
			count = LCTokenize (extra_text, tokens, 1, extra_text);

			if(count)
				this->FlashSpeed = atoi(token1);
			return C_FLASH_ON;
		}
		else if(!strcmp(token1,"off"))
			return C_FLASH_OFF;
		else if(!strcmp(token1,"++"))
			return C_FLASH_PP;
		else if(!strcmp(token1,"--"))
			return C_FLASH_MM;
	}

	return C_ERROR;

}

void Lock::PPTimer()
{
	if (TimerNumber<=0){
		TimerNumber = 1;
		this->startTimer();
	}
	else
		++TimerNumber;
}

void Lock::MMTimer()
{
	--this->TimerNumber;
	if (TimerNumber <= 0){
		this->stopTimer();
	}
}

void Lock::SwitchCases(unsigned char VKey, LPCSTR args)
{
	switch(getCase(args))
	{
		case C_ON:
			this->setState(true);
			break;
		case C_OFF:
			this->setState(false);
			break;
		case C_TOGGLE:
			this->setState(!this->getState());
			break;
		case C_FLASH_ON:
			this->startTimer();
			break;
		case C_FLASH_OFF:
			this->stopTimer();
			break;
		case C_FLASH_PP:
			this->PPTimer();
			break;
		case C_FLASH_MM:
			this->MMTimer();
			break;
		case C_ERROR:
			LSLogPrintf(LOG_ERROR, szAppName, "C_ERROR in bang args (user error) string was: %s", args);
			break;
	}
}

