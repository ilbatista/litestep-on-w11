#ifndef __TOGGLE_H
#define __TOGGLE_H

#include <windows.h>
#include "../lsapi/lsapi.h"
#include "../lsapi/lswinbase.h"
#include "lock.h"
#include "AggressiveOptimize.h"
#define WIN32_LEAN_AND_MEAN
#define MAX_BUFFER 1024

const char szAppName[] = "toggle.dll"; // Our window class, etc
const char rcsRevision[] = "$Revision: 0.2"; // Our Version
const char rcsId[] = "$Id: toggle.cpp,v 0.2 (jesus_mjjg) $"; // The Full RCS ID.

	class Toggle : public Window
	{
	public:
		Toggle(HWND parentWnd, int& code);
		~Toggle();

		Lock *ScrollLock;
		Lock *NumLock;
		Lock *CapsLock;

		HWND gethWnd() {return hWnd;}

		void readRCSettings();

		void onEndSession(Message& message);
		void onGetRevId(Message& message);
		void onSysCommand(Message& message);
		void onTimer(Message& message);

	private:
		virtual void windowProc(Message& message);
	};


	//bang commands
	void bangScrollLock(HWND caller, LPCSTR args);
	void bangNumLock(HWND caller, LPCSTR args);
	void bangCapsLock(HWND caller, LPCSTR args);

	extern "C"
	{
		__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
		__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
	}

#endif
