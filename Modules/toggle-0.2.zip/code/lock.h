#ifndef __LOCK_H
#define __LOCK_H

#include <windows.h>
#include "../lsapi/lsapi.h"
#include "../lsapi/lswinbase.h"
#include "AggressiveOptimize.h"
#define WIN32_LEAN_AND_MEAN
#define MAX_BUFFER 1024

	class Lock
	{
	public:
		Lock(unsigned char);

		//VK_SCROLL VK_NUMLOCK VK_CAPITAL
		unsigned char LockType;
		int FlashSpeed;
		bool OriginalState;

		void readRCSettings(char *);

		bool getState();
		void setState(bool State);
		void toggleState();

		int Timers;
		void startTimer();
		void stopTimer();

		void PPTimer();
		void MMTimer();
		int TimerNumber;

		short int getCase(LPCSTR);
		void SwitchCases(unsigned char, LPCSTR);

	};
#endif
