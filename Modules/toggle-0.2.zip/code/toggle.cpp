/*
	parts of this code comes from www.mindjunction.com, Azathoth's geekamp
	the idea comes from Robert Allhouse's toggle.dll

	todo:	LM_REFRESH
			read mixed-case from bang arguments
*/

#include "toggle.h"
#include "lock.h"

Toggle *toggle; // The module

#define BANG_NUMBER		3

#define TIMER_SCROLL	0
#define TIMER_NUM		1
#define TIMER_CAPS		2


//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	toggle = new Toggle(ParentWnd, code);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete toggle;
}

//=========================================================
// Bang commands
//=========================================================

void bangScrollLock(HWND caller, LPCSTR args)
{
	toggle->ScrollLock->SwitchCases(VK_SCROLL, args);
}

void bangNumLock(HWND caller, LPCSTR args)
{
	toggle->NumLock->SwitchCases(VK_NUMLOCK, args);
}

void bangCapsLock(HWND caller, LPCSTR args)
{
	toggle->CapsLock->SwitchCases(VK_CAPITAL, args);
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Toggle::Toggle(HWND parentWnd, int& code):
Window(szAppName)
{
	int msgs[] = {LM_GETREVID, 0};
	
	if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
		0, 0, 0, 0, parentWnd))
	{
		LSLogPrintf(LOG_ERROR, szAppName, "Unable to create window");
		code = 1;
		return;
	}
	
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
/**/
	code = 0;

	code += AddBangCommand("!ScrollLock",bangScrollLock);
	code += AddBangCommand("!NumLock",bangNumLock);
	code += AddBangCommand("!CapsLock",bangCapsLock);

	if (code != BANG_NUMBER)
		LSLogPrintf(LOG_ERROR, szAppName, "Error registering %d bang command(s)", BANG_NUMBER - code);
/**/
	this->ScrollLock = new Lock(VK_SCROLL);
	this->NumLock = new Lock(VK_NUMLOCK);
	this->CapsLock = new Lock(VK_CAPITAL);

	readRCSettings();
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
Toggle::~Toggle()
{
	int msgs[] = {LM_GETREVID, 0};
	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	int code = 0;

	code += RemoveBangCommand("!ScrollLock");
	code += RemoveBangCommand("!NumLock");
	code += RemoveBangCommand("!CapsLock");

	if (code != BANG_NUMBER)
		LSLogPrintf(LOG_ERROR, szAppName, "Error registering %d bang command(s)", BANG_NUMBER - code);

	delete this->ScrollLock;
	delete this->NumLock;
	delete this->CapsLock;

	destroyWindow();
}

//=========================================================
// Registered messages
//=========================================================

void Toggle::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onEndSession,        WM_ENDSESSION)
		MESSAGE(onEndSession,        WM_QUERYENDSESSION)
		MESSAGE(onGetRevId,          LM_GETREVID)
		MESSAGE(onSysCommand,        WM_SYSCOMMAND)
		MESSAGE(onTimer,			 WM_TIMER);
	END_MESSAGEPROC
}

//=========================================================
// Message handlers
//=========================================================
void Toggle::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void Toggle::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);
	
	switch (message.wParam)
	{
	case 0:
		sprintf(buf, "Toggle %s (jesus_mjjg) ", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
	case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
	default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}

void Toggle::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void Toggle::onTimer(Message& message)
{
	if (message.wParam == VK_SCROLL)
		bangScrollLock(NULL,"toggle");
	else if (message.wParam == VK_NUMLOCK)
		bangNumLock(NULL,"toggle");
	else if (message.wParam == VK_CAPITAL)
		bangCapsLock(NULL,"toggle");
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void Toggle::readRCSettings()
{
	this->CapsLock->readRCSettings("CapsLock");
	this->ScrollLock->readRCSettings("ScrollLock");
	this->NumLock->readRCSettings("NumLock");
}