/****************************************************************
This sourcecode is part of:
wallz.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)

The program mentioned above is copyrighted freeware
for any noncommercial use or distribution.

The text you are reading now must be included with the program
when distributing.

The copyright holder retains all rights and copyright to all his
works in this program.

You can use it freely for your own personal use, and can
distribute it to anyone as long as the original file remains
intact, including this text. However, you cannot put any part
of this program onto web pages, BBSs, CD-ROMs, books, magazines
or other media without my written permission.

This program may not be altered for redistribution without
my written permission.

The program is provided "as is", without warranty of any kind,
express or implied, including but not limited to warranties of
merchantability, fitness for a particular purpose and
non-infringement. In no event shall I, the author and copyright
holder be liable, whether in action of contract, tort or otherwise,
arising from, out of or in connection with the program or the use
or other dealings in the software.

Mike Edward Moras
e-sushi@gmx.net

This sourcecode is part of:
wallz.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/

#include "wallz.h"

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	AddBangCommand("!WALL", bangWALL); 
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!WALL");
}

/****************************************************************
 QuickSort and Partition for theme and wall sorting
****************************************************************/

void QuickSort (char** szArray, int nLower, int nUpper)
{
	if (nLower < nUpper) {
		int nSplit = Partition (szArray, nLower, nUpper);
		QuickSort (szArray, nLower, nSplit - 1);
		QuickSort (szArray, nSplit + 1, nUpper);
	}
}

int Partition (char** szArray, int nLower, int nUpper)
{
	int nLeft = nLower + 1;
	char* szPivot = szArray[nLower];
	int nRight = nUpper;
	char* szSwap;
	while (nLeft <= nRight) {
		while (nLeft <= nRight && strcmp (szArray[nLeft], szPivot) <= 0)
			nLeft = nLeft + 1;
		while (nLeft <= nRight && strcmp (szArray[nRight], szPivot) > 0)
			nRight = nRight - 1;
		if (nLeft < nRight) {
			szSwap = szArray[nLeft];
			szArray[nLeft] = szArray[nRight];
			szArray[nRight] = szSwap;
			nLeft = nLeft + 1;
			nRight = nRight - 1;
		}
	}
	szSwap = szArray[nLower];
	szArray[nLower] = szArray[nRight];
	szArray[nRight] = szSwap;
	return nRight;
}


/****************************************************************
 code: bangWALL
****************************************************************/

void bangWALL(HWND caller, LPCSTR args)
{
	char one[1024] = "", two[1024] = "";
	GetToken(args, one, &args, true);
	GetToken(args, two, &args, true);
	
	if(!stricmp(one,"set")) {
		//
	HKEY hKey;
	char szValue1[2]="", szValue2[2]="",chkHOW[MAX_PATH]="";
	
	GetRCString("wallzstyle", chkHOW, "", MAX_PATH);

		if (!stricmp(chkHOW, "tile")) {
		
			if(RegOpenKeyEx(HKEY_CURRENT_USER, "Control Panel\\Desktop", 0, KEY_WRITE, &hKey) == ERROR_SUCCESS) {
				strcpy(szValue1, "1");
				strcpy(szValue2, "1");
				RegSetValueEx(hKey, "WallpaperStyle", 0, REG_SZ, (unsigned char *)szValue1, strlen(szValue1) + 1);
				RegSetValueEx(hKey, "TileWallpaper", 0, REG_SZ, (unsigned char *)szValue2, strlen(szValue2) + 1);
				RegCloseKey(hKey);
			}
			SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, (LPVOID) two, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
		
		} else if (!stricmp(chkHOW, "center")) {
			if(RegOpenKeyEx(HKEY_CURRENT_USER, "Control Panel\\Desktop", 0, KEY_WRITE, &hKey) == ERROR_SUCCESS) {
				strcpy(szValue1, "0");
				strcpy(szValue2, "0");
				RegSetValueEx(hKey, "WallpaperStyle", 0, REG_SZ, (unsigned char *)szValue1, strlen(szValue1) + 1);
				RegSetValueEx(hKey, "TileWallpaper", 0, REG_SZ, (unsigned char *)szValue2, strlen(szValue2) + 1);
				RegCloseKey(hKey);
			}
			SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, (LPVOID) two, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
		} else {
			if(RegOpenKeyEx(HKEY_CURRENT_USER, "Control Panel\\Desktop", 0, KEY_WRITE, &hKey) == ERROR_SUCCESS) {
				strcpy(szValue1, "2");
				strcpy(szValue2, "0");
				RegSetValueEx(hKey, "WallpaperStyle", 0, REG_SZ, (unsigned char *)szValue1, strlen(szValue1) + 1);
				RegSetValueEx(hKey, "TileWallpaper", 0, REG_SZ, (unsigned char *)szValue2, strlen(szValue2) + 1);
				RegCloseKey(hKey);
			}
			SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, (LPVOID) two, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );	
		}

	} else if (!stricmp(one, "get")) {


		char szSCAN[MAX_PATH]="";
		strcat(szSCAN, two);
		strcat(szSCAN, "*.*");
		char szTHEMES[MAX_PATH]="", PATHfound[MAX_PATH]="";
		LSGetLitestepPath(szTHEMES, MAX_PATH);
		strcat(szTHEMES, "\\walls.rc");
		FILE *stream;
		stream = fopen( szTHEMES, "w" );
		struct _finddata_t c_file;
		long hFile;
		if((hFile = _findfirst(szSCAN, &c_file)) == 0)
			_findnext(hFile, &c_file);//always fetches first file, so the "."
			_findnext(hFile, &c_file);//quick-fix to sort out the ".."
		while(_findnext(hFile, &c_file) == 0){
			if((c_file.attrib)){	
				strcpy(PATHfound,two);
				strcat(PATHfound,c_file.name);
				if(!stricmp(PATHfound + strlen(PATHfound) - 4, ".bmp")) {
						fprintf(stream,"*popup \"%s\" !wall \"set\" \"%s\"\n", c_file.name,PATHfound);
				}
			}
		}

		fclose( stream );


		char szSRC[MAX_PATH]="", szDEST[MAX_PATH]="";
		LSGetLitestepPath(szSRC, MAX_PATH);
		LSGetLitestepPath(szDEST, MAX_PATH);
		strcat(szSRC, "\\walls.rc");
		strcat(szDEST, "\\walls.tmp");

		const int nGrow = 8;
		int nAlloc = nGrow, nSize = 0;
		char** szContents = new char* [nAlloc];
		char szSRCLine [1024]="";
		FILE* pStream = fopen (szSRC, "rt");
		while (fgets (szSRCLine, 1024, pStream)) {
			char* pszCheck = szSRCLine;
			while (*pszCheck != '\0') {
				if (*pszCheck == '\n' && *(pszCheck + 1) == '\0')
					*pszCheck = '\0';
				pszCheck++;
			}
			szContents[nSize] = new char [strlen (szSRCLine) + 1];
			strcpy (szContents[nSize], _strlwr(szSRCLine));
			nSize = nSize + 1;
			if (nSize % nGrow == 0) {
				char** szPrev = szContents;
				nAlloc += nGrow;
				szContents = new char* [nAlloc];
				memcpy (szContents, szPrev, nSize * sizeof(char*));
				delete szPrev;
			}
		}
		fclose (pStream);
		QuickSort (szContents, 0, nSize - 1);
		pStream = fopen (szDEST, "wt");
		for (int nIndex = 0; nIndex < nSize; nIndex++) {
			fprintf (pStream, "%s\n", szContents[nIndex]);
		}
		fclose (pStream);
		
		for (nIndex = 0; nIndex < nSize; nIndex++) {
			delete szContents[nIndex];
		}
		delete szContents;
		szContents = NULL;
		DeleteFile(szSRC);
		CopyFile(szDEST,szSRC,NULL);
		DeleteFile(szDEST);
		LSExecuteEx(GetLitestepWnd(), NULL, "!Recycle", NULL, NULL, 0);

	} 
}

/****************************************************************
This sourcecode is part of:
wallz.dll for Litestep � 2002, by Mike Edward Moras (e-sushi)
****************************************************************/
