#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <commctrl.h>

#include "vwm.h"
#include "lsapi.h"

#define VWM_DESKNO 0x11110000;

char szAppName[] = "lsvwm"; // Our window class, etc

// our window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void (__stdcall *SwitchToThisWindow)(HWND, int);
BOOL CALLBACK searchLSVWMproc(HWND hWnd, LPARAM lParam );
void BangGather(HWND caller ,char* args);

void ReadConfig (void);

void MoveCursor(int o, int n);
void prefixWinFix(int s);
void postfixWinFix(int s);
void removeWinFix(HWND hwnd);
void addWinFix(HWND hwnd, int s);
int inFix(HWND hwnd);
void CreateImageMasks(HWND hwnd);

HWND hMainWnd=NULL; // main window handle
HWND parent = NULL;

// Double buffering data
HDC memDC,		// memory device context
	bgDC;
HBITMAP	memBM,  // memory bitmap (for memDC)
		oldBM,  // old bitmap (from memDC)
		oldBG,	// old Bitmap from background
		bBGBitmap;

UINT Timer=0;
UINT TimerAct=1;

BOOL backInit=FALSE;

BOOL bitmap = FALSE;
BOOL rolled=FALSE;
BOOL noShow=FALSE;

int wndSizeX, wndSizeY;
UINT nOffsetX, nOffsetY;
int currentScreen=0;
int ratioX, ratioY;

int ScreenWidth = 800;
int ScreenHeight = 600;

HWND refToplevel;

void createView(void);
void createRecordedView(void);
void switchToDesktop(int desk);
void gatherAll();
int getDesktop(HWND h);
int outsideAnyScreen(RECT r);
int getDesktopByRect(RECT r);
void DoEvents(int n);
void MakeBuffer(HWND hWnd);
int First = 1;

int ScreensX = 2;
int ScreensY = 2;

int mainX = 0;
int mainY = 0;
int mainWidth = 64;
int mainHeight = 64;

int MaxScreens = 4;

RECT *deskRect = NULL;

HIMAGELIST hBGList;

winDataType winRect[500];
winFixType winFix[500];

int nWinRect=0;
int movingWin=-1;

int ticksNewW=0;
HWND newW=(HWND)-1;

HWND lastActive=NULL;
RECT oldWinPos;
POINT lastPoint;
BOOL taskMgrSwitch=FALSE;
BOOL NoBmps = FALSE;
BOOL NeverSwitch = FALSE;
volatile int lock=0;

int inchk=0;
int mpos=0;
UINT mTimer=2;
UINT mcTimer=3;
int mTimeout=50;

int searched=0;
HINSTANCE inst;
HWND photoshop;
HWND eudora;

int VWMDistance=2;
HWND tapp, desk, winswitch;

BOOL NoGather = FALSE;

char szLitestepPath [256];
char szImagePath [256];
char inipath[256];

int backColor;
int foreColor;
int selBackColor;
int borderColor;

int borderSize = 0;

//////////// Sticky Window Config Types etc
typedef struct {
	char match[80]; //this is the matching text
	int type; //0 (default) for titlematch, 1 (must be specified) for classmatch
} StickyConfigInfoT;
StickyConfigInfoT StickyConfig[256];
////////////////////////////////
// Loads Sticky Window settings
////////////////////////////////
void LoadStickySettings()
{
	char tmpbuf[80];
	char tmpbuf2[80];
	int x, len;
	strcpy((char *)&inipath,szLitestepPath);
	len = strlen (inipath);
	if (len && inipath[len-1] != '\\')
	{
		inipath[len-1] = '\\';
	}
	strcat(inipath,"modules.ini");
	StickyConfig[0].type = GetPrivateProfileInt("lsvwm","stickies",0,inipath);
	for (x=StickyConfig[0].type;x>0;x--)
	{
		_itoa(x,(char *)&tmpbuf,10);
		strcpy((char *)&tmpbuf2,"sticky");
		strcat((char *)&tmpbuf2,(char *)&tmpbuf);
		GetPrivateProfileString("lsvwm",(char *)&tmpbuf2,"",(char *)&StickyConfig[x].match,79,inipath);
		strcpy((char *)&tmpbuf2,"stype");
		strcat((char *)&tmpbuf2,(char *)&tmpbuf);
		StickyConfig[x].type = GetPrivateProfileInt("lsvwm",(char *)&tmpbuf2,0,inipath);
	}
}

//-------------------------------------------------------------------------------------------------
// Init
//-------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}


void BangUp(HWND caller ,char* args)
{
	RECT r;
	if ((currentScreen > (ScreensX - 1)) && !lock)
	{
		switchToDesktop(currentScreen - ScreensX);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangDown(HWND caller ,char* args)
{
	RECT r;
	if ((currentScreen < (MaxScreens - ScreensX)) && !lock)
	{
		switchToDesktop(currentScreen+ ScreensX);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangLeft(HWND caller ,char* args)
{
	RECT r;
	if (((currentScreen % ScreensX) > 0 ) && !lock)
	{
		switchToDesktop(currentScreen-1);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangRight(HWND caller ,char* args)
{
	RECT r;
	if (((currentScreen % ScreensX) < (ScreensX - 1)) && !lock)
	{
		switchToDesktop(currentScreen+1);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangDesk(HWND caller ,char* args)
{
	RECT r;
	int i = atoi(args);

	if ((currentScreen != i) && (i >= 0) && (i < MaxScreens) && !lock)
	{
		switchToDesktop(i);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangRollUp(HWND caller ,char* args)
{
	if (!rolled)
	{
		rolled = TRUE;
		ShowWindow(hMainWnd,SW_HIDE);
	} else {
		rolled = FALSE;
		ShowWindow(hMainWnd,SW_SHOWNORMAL);
	}
}

void RegisterBangCommands(void)
{
	AddBangCommand("!GATHER", BangGather);
	AddBangCommand("!VWMUP", BangUp);
	AddBangCommand("!VWMDOWN", BangDown);
	AddBangCommand("!VWMLEFT", BangLeft);
	AddBangCommand("!VWMRIGHT", BangRight);
	AddBangCommand("!VWMDESK", BangDesk);
	AddBangCommand("!VWMROLLUP", BangRollUp);
}

int initModuleEx (HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	RECT r;
	HDC pDC;
//	UINT Msgs[10];
//	int iHotkey;
	int XPos, YPos;
	int sze;

    memset(winFix, 0, sizeof(winFix));

	GetClientRect(GetDesktopWindow(),&r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;

	strcpy (szLitestepPath, szPath);

	ReadConfig ();

	MaxScreens = ScreensX * ScreensY;
	deskRect = malloc(MaxScreens * sizeof(RECT));

	for (YPos = 0; YPos < ScreensY; YPos ++)
		for (XPos = 0; XPos < ScreensX; XPos ++)
		{
			int desk = (YPos * ScreensX) + XPos;
			int top = YPos * (ScreenHeight + 10);
			int left = XPos * (ScreenWidth + 10);

			deskRect[desk].top = top;
			deskRect[desk].left = left;
			deskRect[desk].right = left + ScreenWidth;
			deskRect[desk].bottom = top + ScreenHeight;
		}

	//parent = ParentWnd;
	wndSizeX = (mainWidth - borderSize*2) / ScreensX;
	wndSizeY = (mainHeight - borderSize*2) / ScreensY;
	nOffsetX = ((wndSizeX*ScreensX) - mainWidth)+borderSize;
	nOffsetY = ((wndSizeY*ScreensY) - mainHeight)+borderSize;
	ratioX = ScreenWidth/wndSizeX;
	ratioY = ScreenHeight/wndSizeY;
    inst = dllInst;

    tapp = GetLitestepWnd();

	sze = sizeof(int) | VWM_DESKNO;

    SendMessage(tapp, LM_RESTOREDATA, (WPARAM) sze, (LPARAM) &currentScreen);

	desk = FindWindow("DesktopBackgroundClass", NULL);
    winswitch = FindWindow("#32771", NULL);
    (long)SwitchToThisWindow = (long)GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;				// our window procedure
		wc.hInstance = dllInst;					// hInstance of DLL
		wc.lpszClassName = szAppName;			// our window class name
		wc.style = CS_DBLCLKS;
	
		if (!RegisterClass(&wc)) 
		{
			MessageBox(parent,"Error registering window class",szAppName,MB_OK);
			return 1;
		}
	}

	parent = FindWindow("DesktopBackgroundClass", NULL);
	if (!parent) parent = GetDesktopWindow();

	if (mainX < 0) mainX = ScreenWidth + mainX;
	if (mainX > ScreenWidth-mainWidth) mainX = ScreenWidth - mainWidth;
	
	if (mainY < 0) mainY = ScreenHeight + mainY;
	if (mainY > ScreenHeight-mainHeight) mainY = ScreenHeight - mainHeight;

	hMainWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,					// exstyles 
		szAppName,							// our window class name
		szAppName,									// use description for a window title
		WS_POPUP,
		mainX, mainY,								// position 
		mainWidth, mainHeight,
		NULL,							// parent window
		NULL,								// no menu
		dllInst,								// hInstance of DLL
		NULL);								// no window creation data
	
/*	hMainWnd = CreateWindowEx(
		WS_EX_TRANSPARENT,										// exstyles 
		szAppName,												// our window class name
		szAppName,												// use description for a window title
		WS_CHILD,
		borderSize, borderSize,									// position
		64-borderSize*2,64-borderSize*2,						// width & height of window
		parent,													// parent window
		NULL,													// no menu
		dllInst,												// hInstance of DLL
		0);*/														// no window creation data

	if (!hMainWnd) 
	{						   
		MessageBox(parent,"Error creating window",szAppName,MB_OK);
		return 1;
	}

/*
	Msgs[0] = 8891;
	Msgs[1] = 9355;
	Msgs[2] = LM_GETREVID;
	Msgs[3] = 0;

	SendMessage(tapp, 9263, (WPARAM) hMainWnd, (LPARAM) Msgs);
	*/

	RegisterBangCommands();

	//load sticky windows settings
	LoadStickySettings();

	// Determine which modifier key is being used for the hotkey & register it

	SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

	// create our doublebuffer

	pDC = GetDC(parent);
	memDC = CreateCompatibleDC(pDC);
	memBM = CreateCompatibleBitmap(pDC, wndSizeX*ScreensX+ScreensX,wndSizeY*ScreensY+ScreensY);
	ReleaseDC(parent, pDC);
	oldBM = SelectObject(memDC,memBM);

	// show the window
	if (!noShow) ShowWindow(hMainWnd,SW_SHOWNORMAL);
	else rolled = TRUE;

	SetTimer(hMainWnd, Timer, 500, NULL);
	SetTimer(hMainWnd, TimerAct, 250, NULL);
    SetTimer(hMainWnd, mcTimer, 50, NULL);
	return 0;

}


//-------------------------------------------------------------------------------------------------
// cleanup
//-------------------------------------------------------------------------------------------------
int quitModule(HINSTANCE dllInst)
{
	//config_write(this_mod);		// write configuration

	gatherAll();

	
	UnregisterHotKey(hMainWnd, 0);
	UnregisterHotKey(hMainWnd, 1);
	UnregisterHotKey(hMainWnd, 2);
	UnregisterHotKey(hMainWnd, 3);

    if (mpos)
        {
        mpos = 0;
        KillTimer(hMainWnd, mTimer);
        }
	
	KillTimer(hMainWnd, mcTimer);
	KillTimer(hMainWnd, Timer);
	KillTimer(hMainWnd, TimerAct);


	SelectObject(memDC,oldBM);	// delete our doublebuffer
	SelectObject(bgDC, oldBG);
	DeleteObject(memDC);
	DeleteObject(bgDC);
	DeleteObject(bBGBitmap); // Delete the background Bitmap.
	DeleteObject(memBM);
	ImageList_Remove(hBGList, -1); // remove all our images
	ImageList_Destroy(hBGList); // Free up the memory

	DestroyWindow(hMainWnd); // delete our window
	UnregisterClass(szAppName,dllInst/*this_mod->hDllInstance*/); // unregister window class

	free(deskRect);
	deskRect = NULL;
	return 0;
}


////////////////////////////////////////////////////////////////
// Checks to see if given window is supposed to be left alone
////////////////////////////////////////////////////////////////
int StickyCheck1(HWND targetWin, char* matchval)
{
	char tmpbuf[80];
	GetClassName(targetWin, (char *)&tmpbuf, 79);
	if (match(matchval,(char *)&tmpbuf)) {return 1;}
	return 0;
}

int StickyCheck0(HWND targetWin, char* matchval)
{
	char tmpbuf[80];
	GetWindowText(targetWin, (char *)&tmpbuf, 79);
	if (match(matchval,(char *)&tmpbuf)) {return 1;}
	return 0;
}

int topWindowAlways(HWND targetWin)
{
	int x;
	int issticky;
	issticky = 0;
	x = StickyConfig[0].type;
	//while we havent finished checking against windows to ignore
	while ((x > 0) && (!issticky)) {
		if (StickyConfig[x].type == 1) {issticky = StickyCheck1(targetWin,StickyConfig[x].match);}
		else {issticky = StickyCheck0(targetWin,StickyConfig[x].match);}
		x--;
	}
	return issticky;
}

//-------------------------------------------------------------------------------------------------
// window procedure for our window
//-------------------------------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_CREATE:		
            return 0;
		case WM_ERASEBKGND: return 0;
		case WM_PAINT:
			{ // update from doublebuffer
				PAINTSTRUCT ps;
				RECT r;
				HDC hdc = BeginPaint(hwnd,&ps);

				if (First) 
				{
					MakeBuffer(parent);
					CreateImageMasks(parent);
					First = 0;
				}

				GetClientRect(hwnd,&r);
				if (!backInit)
				{
					createView();
					backInit = TRUE;
				}
				BitBlt(hdc,0,0,r.right,r.bottom,memDC,0,0,SRCCOPY);
				EndPaint(hwnd,&ps);
			}
			return 0;
		case WM_KEYDOWN: 
		case WM_KEYUP:
			PostMessage(parent,message,wParam,lParam);
			return 0;
		case WM_RBUTTONDOWN:
			if (lock) 
			{ // Try later
				PostMessage(hwnd, message, wParam, lParam);
				return 0;
			}
			lock = 1;
			{ // change desktop
				POINT pt;
				int deskx = 0;
				int desky = 0;
				int s=0;

				GetCursorPos(&pt);

				deskx = (pt.x-mainX) / wndSizeX;
				desky = (pt.y-mainY) / wndSizeY;
				s = (desky * ScreensX) + deskx;

				{
					RECT r;
					switchToDesktop(s);
					GetClientRect(hwnd,&r);
					createView();
					InvalidateRect(hwnd, &r, FALSE);
				}
			}
			lock=0;
			return 0;
		case WM_LBUTTONDOWN:
			{ // Move a window from its miniview
				POINT pts;
				int i;
				int deskX = currentScreen % ScreensX;
				int deskY = currentScreen / ScreensX;

				GetCursorPos(&pts);
				pts.x = pts.x-mainX;
				pts.y = pts.y-mainY;
				
				for (i=0;winRect[i].valid;i++);
				for (i--; i>=0;i--)
				{
			 		if ((pts.x-wndSizeX*deskX >= winRect[i].r.left/ratioX) &&
					   (pts.x-wndSizeX*deskX <= winRect[i].r.right/ratioX) &&
					   (pts.y-wndSizeY*deskY >= winRect[i].r.top/ratioY) &&
					   (pts.y-wndSizeY*deskY <= winRect[i].r.bottom/ratioY))
					{
						GetWindowRect(winRect[i].hwnd, &oldWinPos);
						movingWin = i;
						pts.x = pts.x+mainX;
						pts.y = pts.y+mainY;
						lastPoint = pts;
						SetCapture(hMainWnd); // Capture mouse
						break;
					}
				}
			}
			return 0;

		case WM_LBUTTONUP:
			{ // End moving
				POINT pts;
				RECT r;
				int s, deskx, desky;

				GetCursorPos(&pts);
				pts.x = pts.x-mainX;
				pts.y = pts.y-mainY;

				deskx = pts.x / wndSizeX;
				desky = pts.y / wndSizeY;
				s = (desky * ScreensX) + deskx;
				ReleaseCapture();
							// If we are outside the virtual space, cancel move
				if (pts.x < 0 || pts.y < 0 || pts.x > mainWidth-borderSize*2 || pts.y > mainHeight-borderSize*2)
					MoveWindow(winRect[movingWin].hwnd, oldWinPos.left, oldWinPos.top, oldWinPos.right-oldWinPos.left, oldWinPos.bottom-oldWinPos.top, TRUE);
				else if (GetWindowLong(winRect[movingWin].hwnd, GWL_STYLE) & WS_MAXIMIZE)
				{ // If window is maximized, make it jump to same coordinates on another desktop
					RECT newRect;
					int oldDesk = getDesktopByRect(oldWinPos);
					int newDesk = s;
					newRect.top = oldWinPos.top + deskRect[newDesk].top - deskRect[oldDesk].top;
					newRect.left = oldWinPos.left + deskRect[newDesk].left - deskRect[oldDesk].left;
					newRect.bottom = oldWinPos.bottom + deskRect[newDesk].top - deskRect[oldDesk].top;
					newRect.right = oldWinPos.right + deskRect[newDesk].left - deskRect[oldDesk].left;
					MoveWindow(winRect[movingWin].hwnd, newRect.left, newRect.top, newRect.right-newRect.left, newRect.bottom-newRect.top, TRUE);
					GetWindowRect(winRect[movingWin].hwnd, &winRect[movingWin].r);
				}
				GetClientRect(hwnd,&r);
				createRecordedView();
				InvalidateRect(hwnd, &r, FALSE);
				movingWin=-1;
			}
			return 0;
        case WM_MBUTTONDOWN:
            return 0;
		case WM_MOUSEMOVE:
			{ 
				POINT pts;
				POINT thisPt;
				RECT r;

				if (movingWin == -1) return 0;
			// We are moving a window with its miniview
				GetCursorPos(&pts);
				thisPt = pts;

				pts.x -= lastPoint.x;
				pts.y -= lastPoint.y;

				GetWindowRect(winRect[movingWin].hwnd, &winRect[movingWin].r);
				MoveWindow(winRect[movingWin].hwnd, winRect[movingWin].r.left + pts.x*ratioX, winRect[movingWin].r.top + pts.y * ratioY, winRect[movingWin].r.right + pts.x * ratioX - (winRect[movingWin].r.left + pts.x*ratioX), winRect[movingWin].r.bottom + pts.y * ratioY-(winRect[movingWin].r.top + pts.y*ratioY), TRUE);
				GetWindowRect(winRect[movingWin].hwnd, &winRect[movingWin].r);
				lastPoint = thisPt;

				GetClientRect(hwnd,&r);
				createRecordedView();
				InvalidateRect(hwnd, &r, FALSE);
			}
			return 0;

		case 9355:
			{
				RECT r;
				int i = wParam;

				if ((currentScreen != i) && !lock)
				{
					switchToDesktop(i);
					GetClientRect(hMainWnd, &r);
					createView();
					InvalidateRect(hMainWnd, &r, FALSE);
//					MessageBox(0, "Switched Windows", "VWM", MB_OK|MB_TOPMOST);
				}
				return TRUE;
			}

		case 8891: // Change window focus via message (change desktop if needed)
			//taskMgrSwitch = TRUE;
			if (lock)
            { // Try later
				PostMessage(hwnd, message, wParam, lParam);
				return TRUE;
			}
			lock = 1;
			{
				int n = getDesktop((HWND)lParam);
				if (n != currentScreen) switchToDesktop(n);
				//SetForegroundWindow((HWND)lParam);
				SwitchToThisWindow((HWND)lParam, 1);
			}
			lock=0;
			return TRUE;

	case WM_TIMER:
		{ 
			if (lock) // cancel
				return 0;
            if (wParam == mTimer)
            {
                KillTimer(hMainWnd, mTimer);
                return 0;
            }
            else
                if (wParam == mcTimer)
                {
                    POINTS pts;
                    DWORD a = GetMessagePos();
                    int nmpos = 0;
                    pts = MAKEPOINTS(a);

                    if ((pts.x-mainX) == 0) nmpos |= 1;
                    if ((pts.y-mainY) == 0) nmpos |= 2;
                    if ((pts.x-mainX) == ScreenWidth-1) nmpos |= 4;
                    if ((pts.y-mainY) == ScreenHeight-1) nmpos |= 8;

                    if (!nmpos)
                    {
                        if (mpos)
                        {
                            KillTimer(hMainWnd, mTimer);
                            mpos = 0;
                        }
                    }
                    else
                    {
                        if (!mpos)
                        {
                            mpos = nmpos;
                            SetTimer(hMainWnd, mTimer, mTimeout, NULL);
                        }
                    }
                    return 0;
                }

           	lock = 1;

            if (!wParam) // main timer, update view, check focus change
            {
    		    RECT r;
			    GetClientRect(hwnd,&r);
			    createView();
			    InvalidateRect(hwnd, &r, FALSE);
			}
            else
   			{
   				int style=0;
    			int a=0;
	    		RECT r;
		    	HWND newFGWin = GetForegroundWindow();

   				if (newFGWin)
    			{
	    			style = GetWindowLong(newFGWin, GWL_STYLE);
		    		a = GetWindowLong(newFGWin, GWL_USERDATA);
			   	}
				
    			if ((newFGWin != lastActive) && !NeverSwitch)
	    		{
// This causes a timeout to be applied against focus change, obsolete?
//		   			if (newFGWin == newW)
//		    			{
//			    		ticksNewW++;
//				    	if (ticksNewW > 0)
//					    	{
							if (newFGWin)
							{
								GetWindowRect(newFGWin, &r);
								if (!outsideAnyScreen(r) && 
									!(a == magicDWord || !newFGWin || (newFGWin && IsIconic(newFGWin)) || 
    								  !(style & WS_VISIBLE) || (style & WS_DISABLED) || 
	    							  (lastActive && IsWindow(lastActive) && IsIconic(lastActive)) ||
									  (lastActive && !IsWindow(lastActive))
		   							  || (!taskMgrSwitch && lastActive && GetWindowLong(lastActive, GWL_USERDATA) == magicDWord))
		    						 )
			   					{
				    				int newScr = getDesktop(newFGWin);
					    			if (newScr != currentScreen)
						    			switchToDesktop(newScr);
									taskMgrSwitch=FALSE;
    							}
							}
	    					lastActive = newFGWin;
// End timeout
//		   					newW = (HWND)-1;
//		    				}
//			    		}
//				    else
//  					{
//	    				newW = newFGWin;
//		   				ticksNewW = 0;
//		    			}
			    	}
                }
			}
			lock = 0;
		return 0;

	}

return DefWindowProc(hwnd,message,wParam,lParam);
}

//----------------------------------------------------------------------------
// Get Background bitmap
//----------------------------------------------------------------------------
void MakeBuffer(HWND hWnd)
{
	RECT r;
	POINT p;
//	HDC hdc = GetDC(hWnd);
	HDC hdc = GetDC(GetDesktopWindow());
//	char tmp[1024];

	GetClientRect(hWnd,&r);
	p.x = r.left-mainX;
	p.y = r.top-mainY;
//	ClientToScreen(hWnd, &p);
//	wsprintf(tmp, "%d : %d", p.x, p.y);
//	MessageBox(0, tmp, "Bleh", MB_OK|MB_TOPMOST);


	if (!bitmap) bBGBitmap = CreateCompatibleBitmap(hdc, mainWidth, mainHeight);

	bgDC = CreateCompatibleDC(NULL);
	oldBG = (HBITMAP)SelectObject(bgDC, bBGBitmap);
	if (NoBmps) // bitmaps dont work - luke
	{
		HBRUSH oldBrush, hBlueBrush = CreateSolidBrush(backColor);
		HPEN oldpen, pen = CreatePen(PS_SOLID, 1, borderColor);
		
		// draw main bg
		oldBrush = SelectObject(bgDC, hBlueBrush);
		oldpen = SelectObject(bgDC, pen);
		Rectangle(bgDC, 0, 0, mainWidth, mainHeight);

		SelectObject(bgDC, oldpen);
		SelectObject(bgDC, oldBrush);
		DeleteObject(hBlueBrush);
		DeleteObject(pen);
	}
	else
	{
		if (bitmap){
			SelectObject(bgDC, bBGBitmap);
		}
		else {
			SelectObject(bgDC, bBGBitmap);
			BitBlt(bgDC, 0, 0, r.right, r.bottom, hdc, mainX, mainY, SRCCOPY);
		}
	} // bitmaps dont work - luke
	ReleaseDC(hWnd, hdc);
}




//----------------------------------------------------------------------------
// Get shifting value from a desktop to another
//----------------------------------------------------------------------------
void getShifts(int old, int desk, int *addH, int *addV)
{
	int oldDeskX = old % ScreensX;
	int oldDeskY = old / ScreensX;

	int deskX = desk % ScreensX;
	int deskY = desk / ScreensX;

	int shiftX = deskX - oldDeskX;
	int shiftY = deskY - oldDeskY;

	*addH = shiftX * (ScreenWidth + 10);
	*addV = shiftY * (ScreenHeight + 10);
}

//-------------------------------------------------------------------------------------------------
// Callback function. Windows enumeration
//-------------------------------------------------------------------------------------------------
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{

/*if (!refTopmost && (GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST))
	{
	refTopmost = hwnd;
	return !refToplevel;
	}*/

if (!refToplevel && !(GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST))
	{
	refToplevel = hwnd;
	return FALSE;//!refTopmost;
	}

return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Callback functions, check for eudora
//-------------------------------------------------------------------------------------------------
BOOL CALLBACK EudoraEnumChildProc(HWND hwnd, LPARAM lParam)
{
HWND owner = GetWindow(hwnd, GW_OWNER);

if (owner != eudora) return TRUE;
    {
    int style = GetWindowLong(hwnd, GWL_STYLE);

    if (style & WS_VISIBLE && style & WS_POPUP)
        {
        char txt[25];
        GetWindowText(hwnd, txt, 23);
        if (!strcmp(txt, "Progress") || !strcmp(txt, "No New Mail") || !strcmp(txt, "New Mail!") || !strcmp(txt, "Eudora Network Timeout"))
            {
            RECT r;
            RECT r2;
            RECT r3;
            GetWindowRect(eudora, &r);
            GetWindowRect(hwnd, &r2);
            r3.left = ((r.right-r.left-(r2.right-r2.left)) / 2) + r.left;
            r3.top = ((r.bottom-r.top-(r2.bottom-r2.top)) / 2) + r.top;
            r3.right = r3.left + (r2.right-r2.left);
            r3.bottom = r3.top + (r2.bottom-r2.top);
            MoveWindow(hwnd, r3.left, r3.top, r3.right-r3.left, r3.bottom-r3.top, TRUE);
            }
        }
    }

return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Create the wharf view
//-------------------------------------------------------------------------------------------------
void createView(void)
{
	//int i;
	int xoff, yoff;
	HWND prev, p;
	RECT r;
	int H=0, V=0;
	static int oldnRects=0;
	int nRects=0;
	HBRUSH hWhiteBrush,
		hGreyBrush,
		hBlueBrush,
		oldBrush;
	HPEN pen,oldpen;
	// If we are moving a window from the miniview, cancel drawing
	if (movingWin > -1) return;
	
	hBlueBrush = CreateSolidBrush(backColor);
	hWhiteBrush = CreateSolidBrush(foreColor);
	hGreyBrush = CreateSolidBrush(selBackColor);

	
	BitBlt(memDC, 0, 0, mainWidth, mainHeight, bgDC, 0, 0, SRCCOPY);

	// draw main bg
	pen = CreatePen(PS_SOLID, 1, borderColor);
	oldBrush = SelectObject(memDC, hBlueBrush);
	oldpen = SelectObject(memDC, pen);
//	Rectangle(memDC, 0, 0, wndSize*2, wndSize*2);

	for (yoff=0; yoff < ScreensY; yoff++)
		for (xoff=0; xoff < ScreensX; xoff++)
		{
			ImageList_Draw(hBGList, (yoff*ScreensX)+xoff, memDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), ILD_NORMAL);
		}

	if (!bitmap) {
		for (xoff=1; xoff < ScreensX; xoff++)
		{
			MoveToEx(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY, NULL);
			LineTo(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY+(ScreensY*wndSizeY));
		}
		// draw some other stuff
		for (yoff=1; yoff < ScreensY; yoff++)
		{
			MoveToEx(memDC, nOffsetX, nOffsetY + (yoff * wndSizeY), NULL);
			LineTo(memDC, nOffsetX+(ScreensX*wndSizeX), nOffsetY + (yoff * wndSizeY));
		}
	}

	// calc and draw selected bg
	r.left = nOffsetX+wndSizeX*(currentScreen % ScreensX);
	r.top = nOffsetY+wndSizeY*(currentScreen / ScreensX);
	r.right = r.left+wndSizeX;
	r.bottom = r.top+wndSizeY;

	SelectObject(memDC, hGreyBrush);
	ImageList_DrawEx(hBGList, currentScreen, memDC, r.left, r.top, wndSizeX, wndSizeY, 0, selBackColor, ILD_BLEND50);
	
	SelectObject(memDC, hWhiteBrush);
	
	getShifts(0, currentScreen, &H, &V);
	
	refToplevel = NULL;
	nWinRect=0;
	//refTopmost = NULL;
	// Get a topmost window
	EnumWindows(EnumWindowsProc, 0);
	
	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;
	while (1)
	{ 
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
			if (prev == NULL) break;
		
			//added the part at the end to check if its an always on top window
			if ((!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE)) && (!topWindowAlways(prev)))
				continue;
			p = GetParent(prev);
			if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
				continue;
			GetWindowRect(prev, &winRect[nWinRect].r);
			nRects+=(int)prev;
			Rectangle(memDC, (winRect[nWinRect].r.left + H) / ratioX,
				(winRect[nWinRect].r.top + V) / ratioY,
				(winRect[nWinRect].r.right + H) / ratioX,
				(winRect[nWinRect].r.bottom + V) / ratioY);
			winRect[nWinRect].hwnd=prev;
			winRect[nWinRect++].valid=1;
	}
	
	if (nRects != oldnRects)
    {
		if (! (GetWindowLong(winswitch, GWL_STYLE) & WS_VISIBLE) )
        {
			HWND last = GetWindow(desk, GW_HWNDLAST);
			while (last && last != desk)
			{
				if (GetWindowLong(last, GWL_STYLE) & WS_VISIBLE)
				{
					SetWindowPos(last, GetWindow(desk, GW_HWNDPREV), 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
					last = GetWindow(desk, GW_HWNDLAST);
					continue;
				}
				last = GetWindow(last, GW_HWNDPREV);
			}
			
			
        }
		oldnRects = nRects;
		eudora = FindWindow("EudoraMainWindow", NULL);
		if (eudora)
			EnumWindows(EudoraEnumChildProc, 0);
    }
	
	memset(&winRect[nWinRect], 0, sizeof(winDataType));
	SelectObject(memDC, oldpen);
	SelectObject(memDC, oldBrush);
	DeleteObject(hWhiteBrush);
	DeleteObject(hGreyBrush);
	DeleteObject(hBlueBrush);
	DeleteObject(pen);
}

//-------------------------------------------------------------------------------------------------
// Callback functions. Enumerates windows to be fixed (hidden when not in active desktop)
//-------------------------------------------------------------------------------------------------
BOOL CALLBACK FixEnumChildProc(HWND hwnd, LPARAM lParam)
{
HWND owner = GetWindow(hwnd, GW_OWNER);

if (owner != photoshop) return TRUE;
    {
    int style = GetWindowLong(hwnd, GWL_STYLE);

    if (style & WS_VISIBLE && style & WS_POPUP)
        if (!inFix(hwnd))
            {
            ShowWindow(hwnd, SW_HIDE);
            addWinFix(hwnd, currentScreen);
            }
    }

return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Does the desktop switching
//-------------------------------------------------------------------------------------------------
void switchToDesktop(int _desk)
{
//int i;
RECT r;
HWND prev, p;
HDWP dwp;

int addH=0, addV=0;

lock = 1;
if (movingWin > -1) return;

getShifts(currentScreen, _desk, &addH, &addV);

// Fix photoshop
photoshop = FindWindow("Photoshop", NULL);
if (photoshop)
    EnumWindows(FixEnumChildProc, 0);

refToplevel = NULL;
EnumWindows(EnumWindowsProc, 0);

prev = GetWindow(refToplevel, GW_HWNDLAST);

DoEvents(2);

dwp = BeginDeferWindowPos(nWinRect+16);

goto inside;
while (1)
	{
	prev = GetWindow(prev, GW_HWNDPREV);
	inside:
	if (prev == NULL) break;

	if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
		continue;
	p = GetParent(prev);
	if (GetWindowLong(prev, GWL_USERDATA) == magicDWord /*|| prev == 0xE44*/)
		continue;
/*	if (SendMessage(tapp, 9212, 0, (long)prev))
		continue;
*/
//inserted code here to check if the window has been set to be ignored
	if (!topWindowAlways(prev)) {
		GetWindowRect(prev, &r);
		r.left-=addH;
		r.right-=addH;
		r.top -=addV;
		r.bottom-=addV;

		//MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
		dwp = DeferWindowPos(dwp, prev, NULL, r.left, r.top, r.right-r.left, r.bottom-r.top, SWP_NOZORDER | SWP_NOACTIVATE);
		}
	}

currentScreen = _desk;
EndDeferWindowPos(dwp);

postfixWinFix(currentScreen);
lock = 0;
}

//-------------------------------------------------------------------------------------------------
// Gather all windows in one desktop
//-------------------------------------------------------------------------------------------------
void gatherAll()
{
	//int i;
	RECT r;
	HWND prev, p;

	if (NoGather) 
    {
		int sze = sizeof(int) | VWM_DESKNO;

		SendMessage(tapp, LM_SAVEDATA, (WPARAM) sze, (LPARAM) &currentScreen);

		return;
    }


	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);

	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;
	while (1)
	{
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
		if (prev == NULL) break;

		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		p = GetParent(prev);
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
			continue;
		GetWindowRect(prev, &r);
		if (r.left > ScreenWidth)
		{
			r.left %= (ScreenWidth+10);
			r.right %= (ScreenWidth+10);
		}
		if (r.top > ScreenHeight)
		{
			r.top %= (ScreenHeight+10);
			r.bottom %= (ScreenHeight+10);
		}
		if (r.left < -10)
		{
			r.right %= (ScreenWidth+10);
			r.right += ScreenWidth;
			r.left %= (ScreenWidth+10);
			r.left += ScreenWidth;
		}
		if (r.top < -10)
		{
			r.bottom %= (ScreenHeight+10);
			r.bottom += ScreenHeight;
			r.top %= (ScreenHeight+10);
			r.top += ScreenHeight;
		}
		MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}

	currentScreen = 0;
}

//-------------------------------------------------------------------------------------------------
// Creates the view from known window positions
//-------------------------------------------------------------------------------------------------
void createRecordedView(void)
{
	//int i;
	RECT r;
	int H=0, V=0;
	int i, xoff, yoff;
	HBRUSH hWhiteBrush,
		   hGreyBrush,
		   hBlueBrush,
		   oldBrush;
	HPEN pen,oldpen;
	///HDC tempDC; ///this is unreferrenced???
	///char data[1024]; ///this is unreferenced???

	BitBlt(memDC, 0, 0, mainWidth, mainHeight, bgDC, 0, 0, SRCCOPY);

	hBlueBrush = CreateSolidBrush(backColor);
	hWhiteBrush = CreateSolidBrush(foreColor);
	hGreyBrush = CreateSolidBrush(selBackColor);
	pen = CreatePen(PS_SOLID, 1, borderColor);
	oldBrush = SelectObject(memDC, hBlueBrush);
	oldpen = SelectObject(memDC, pen);

	//Rectangle(memDC, 0, 0, wndSize*2, wndSize*2);
	for (yoff=0; yoff < ScreensY; yoff++)
		for (xoff=0; xoff < ScreensX; xoff++)
		{
			ImageList_Draw(hBGList, (yoff*ScreensX)+xoff, memDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), ILD_NORMAL);
		}
/*
	tempDC = CreateCompatibleDC(NULL);
	SelectObject(tempDC, bBGBitmap);
	if (!BitBlt(memDC, 0, 0, 64, 64, tempDC, 0, 0, SRCCOPY)) {
		Rectangle(memDC, 0, 0, wndSize*2, wndSize*2);
		MessageBox(hMainWnd, "Failed", "Error", MB_OK);
	}
	DeleteDC(tempDC);
*/

	if (!bitmap) {
		for (xoff=1; xoff < ScreensX; xoff++)
		{
			MoveToEx(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY, NULL);
			LineTo(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY+(ScreensY*wndSizeY));
		}
		// draw some other stuff
		for (yoff=1; yoff < ScreensY; yoff++)
		{
			MoveToEx(memDC, nOffsetX, nOffsetY + (yoff * wndSizeY), NULL);
			LineTo(memDC, nOffsetX+(ScreensX*wndSizeX), nOffsetY + (yoff * wndSizeY));
		}
	}

	r.left = nOffsetX+ wndSizeX*(currentScreen % ScreensX);
	r.top = nOffsetY+ wndSizeY*(currentScreen / ScreensX);
	r.right = r.left+wndSizeX+1;//-(currentScreen & 1);;
	r.bottom = r.top+wndSizeY+1;//-(currentScreen & 2 ? 1 : 0);;
	SelectObject(memDC, hGreyBrush);

//	Rectangle(memDC, r.left, r.top, r.right, r.bottom);
	ImageList_DrawEx(hBGList, currentScreen, memDC, r.left, r.top, wndSizeX, wndSizeY, 0, selBackColor, ILD_BLEND50);

	SelectObject(memDC, hWhiteBrush);

	getShifts(0, currentScreen, &H, &V);

	for (i=0;winRect[i].valid;i++)
	{
		GetWindowRect(winRect[i].hwnd, &winRect[i].r);
		Rectangle(memDC, (winRect[i].r.left + H) / ratioX ,
						 (winRect[i].r.top + V) / ratioY,
						 (winRect[i].r.right + H) / ratioX,
						 (winRect[i].r.bottom + V) / ratioY);
	}

	SelectObject(memDC, oldpen);
	SelectObject(memDC, oldBrush);
	DeleteObject(hWhiteBrush);
	DeleteObject(hGreyBrush);
	DeleteObject(hBlueBrush);
	DeleteObject(pen);
}

//-------------------------------------------------------------------------------------------------
// Returns the desktop associated with a window
//-------------------------------------------------------------------------------------------------
int getDesktop(HWND h)
{
	RECT r;
	GetWindowRect(h, &r);
	return (getDesktopByRect(r));
}

//-------------------------------------------------------------------------------------------------
// Get a desktop associated with a RECT
//-------------------------------------------------------------------------------------------------
int getDesktopByRect(RECT r)
{

	int offsetx = currentScreen % ScreensX;
	int offsety = currentScreen / ScreensX;
	int desk = 0;

	r.left += offsetx * (ScreenWidth + 10);
	r.top += offsety * (ScreenHeight + 10);

	offsetx = ((r.left + 10) / (ScreenWidth + 10));
	offsety = ((r.top + 10) / (ScreenHeight + 10));

	desk = (offsety * ScreensX) + offsetx;

	if (desk < 0 || desk > MaxScreens) desk = 0;
	return desk;
}

//-------------------------------------------------------------------------------------------------
// Check if a RECT is outside of the virtual space
//-------------------------------------------------------------------------------------------------
int outsideAnyScreen(RECT r)
{
return (r.left > ScreensX * (ScreenWidth +10) || r.top > ScreensY*(ScreenHeight +10));
}

//-------------------------------------------------------------------------------------------------
// Changes cursor position 
//-------------------------------------------------------------------------------------------------
void MoveCursor(int o, int n)
{
int h, v;
POINT ps;

getShifts(o, n, &h, &v);

GetCursorPos(&ps);
if (h) h -= (h > 0) ? (10 + VWMDistance) : -(10 + VWMDistance);
if (v) v -= (v > 0) ? (10 + VWMDistance) : -(10 + VWMDistance);
ps.x -= h;
ps.y -= v;
SetCursorPos(ps.x, ps.y);
}

//-------------------------------------------------------------------------------------------------
// Add a photoshop tool-like window to be fixed
//-------------------------------------------------------------------------------------------------
void addWinFix(HWND hwnd, int s)
{
int i;
for (i=0;i<500 && winFix[i].hwnd;i++);

if (i >= 500) return;
winFix[i].hwnd = hwnd;
winFix[i].screen = s;
}

//-------------------------------------------------------------------------------------------------
// Remove a photoshop tool-like window to be fixed
//-------------------------------------------------------------------------------------------------
void removeWinFix(HWND hwnd)
{
int i;
for (i=0;i<500 && winFix[i].hwnd != hwnd;i++);

if (i >= 500) return;
winFix[i].hwnd = NULL;
winFix[i].screen = 0;
}

//-------------------------------------------------------------------------------------------------
// Fixes the window (part2)
//-------------------------------------------------------------------------------------------------
void postfixWinFix(int s)
{
int i;
for (i=0;i<500;i++)
    {
    if (winFix[i].hwnd && winFix[i].screen == s)
        {
        ShowWindow(winFix[i].hwnd, SW_SHOWNA);
        winFix[i].hwnd = NULL;
        winFix[i].screen = 0;
        }
    }
}

//-------------------------------------------------------------------------------------------------
// Fixes the window (part 1)
//-------------------------------------------------------------------------------------------------
void prefixWinFix(int s)
{
int i;
for (i=0;i<500;i++)
    {
    if (winFix[i].hwnd && winFix[i].screen == s)
        ShowWindow(winFix[i].hwnd, SW_HIDE);
    }
}

//-------------------------------------------------------------------------------------------------
// Checks if a window is in fixed windows list
//-------------------------------------------------------------------------------------------------
int inFix(HWND hwnd)
{
int i;

for (i=0;i<500 && winFix[i].hwnd != hwnd;i++);
if (i>=500) return 0;
return 1;    
}
 
//-------------------------------------------------------------------------------------------------
// Non blocking wait
// -------------------------------------------------------------------------------------------------------
void DoEvents(int n)
{
int i;
BOOL b=TRUE;
MSG msg;

for (i=0;i<n && b;i++)
    {
    b = GetMessage( &msg, NULL, 0, 0 );
    if (b) 
        {
	    TranslateMessage( &msg );
	    DispatchMessage( &msg ); 
        }
    }
}

/*********************************************************************/
/* Create Masked Images                                               */
/*********************************************************************/
void CreateImageMasks(HWND hwnd)
{
	HBITMAP bPane, bOld;
	HDC	hdc = GetDC(hwnd), TempDC;
	int xoff, yoff;

/*	bgDC = CreateCompatibleDC(hdc);
	SelectObject(bgDC, bBGBitmap);
*/
	hBGList = ImageList_Create(wndSizeX, wndSizeY, ILC_COLOR32, 0, ScreensX);

	TempDC = CreateCompatibleDC(hdc);
	bPane = CreateCompatibleBitmap(hdc, wndSizeX, wndSizeY);

	for (yoff = 0; yoff < ScreensY; yoff++)
		for (xoff = 0; xoff < ScreensX; xoff++)
		{
			bOld = (HBITMAP)SelectObject(TempDC, bPane);
			
			if (!BitBlt(TempDC, 0, 0, wndSizeX, wndSizeX, bgDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), SRCCOPY))
				MessageBox(hMainWnd, "BitBlt failed", "Error", MB_OK);
			SelectObject(TempDC, bOld);

			if (ImageList_Add(hBGList, bPane, NULL) == -1)
				MessageBox(hMainWnd, "Could not add image...", "Error", MB_OK);
		}

	ReleaseDC(hwnd, hdc);
	DeleteDC(TempDC);
	DeleteObject(bPane);
	DeleteObject(bOld);
/*	DeleteObject(bgDC);
*/
}

void ReadConfig (void)
{
	char szTemp[256], szBuf[256];

	NoGather = GetRCBool("VwmNoGathering", TRUE);
	NoBmps = GetRCBool("VWMNoBackBmp", TRUE);
	NeverSwitch = GetRCBool("VWMNoSwitchOnFocus", TRUE);
	noShow = GetRCBool("VWMNoShow", TRUE);
	
	backColor = GetRCColor("vwmBackColor", 0x808080);
	selBackColor = GetRCColor("vwmSelBackColor", 0x404040);
	foreColor = GetRCColor("VWMForeColor", 0xFFFFFF);
	borderColor = GetRCColor("VWMBorderColor", 0x000000);

	ScreensX = GetRCInt("VWMDesksX", ScreensX);
	ScreensY = GetRCInt("VWMDesksY", ScreensY);

	GetRCString("PixmapPath", szImagePath, "C:\\litestep\\images\\", 256);

	mainX = GetRCInt("VWMx", mainX);
	mainY = GetRCInt("VWMy", mainY);
	mainWidth = GetRCInt("VWMwidth", mainWidth);
	mainHeight = GetRCInt("VWMheight", mainHeight);
	if (!NoBmps) {
		GetRCString("VWMbitmap", szTemp, "vwm.bmp", 256);
		sprintf(szBuf, "%s%s", szImagePath, szTemp);
		bBGBitmap = LoadImage(inst, szBuf, IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_LOADFROMFILE);
		if (bBGBitmap) bitmap = TRUE;
	}
}


void BangGather(HWND caller ,char* args)
{
	RECT r;
	HWND prev, p;

	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);

	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;

	while (1)
	{
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
		if (prev == NULL) break;

		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		p = GetParent(prev);
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
			continue;
		GetWindowRect(prev, &r);

		if (r.left > ScreenWidth)
		{
			r.left %= (ScreenWidth+10);
			if (r.left > ScreenWidth)
				r.left -= (ScreenWidth + 10);
			r.right %= (ScreenWidth+10);
		}
		else if (r.right < 0)
		{
			r.right %= (ScreenWidth+10);
			if (r.right < 0)
				r.right += (ScreenWidth + 10);
			r.left %= (ScreenWidth+10);
			if (r.left < -10)
				r.left += (ScreenWidth + 10);
		}

		if (r.top > ScreenHeight)
		{
			r.top %= (ScreenHeight+10);
			if (r.top > ScreenHeight)
				r.top -= (ScreenHeight + 10);
			r.bottom %= (ScreenHeight+10);
		}
		else if (r.bottom < 0)
		{
			r.bottom %= (ScreenHeight+10);
			if (r.bottom < 0)
				r.bottom += (ScreenHeight + 10);
			r.top %= (ScreenHeight+10);
			if (r.top < -10)
				r.top += (ScreenHeight + 10);
		}
		MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}
}