#ifndef __LSVWM_H
#define __LSVWM_H

#include <windows.h>
#include "wharfdata.h"

typedef struct {
	HWND hwnd;
	RECT r;
	char valid;
	} winDataType;

typedef struct {
	HWND hwnd;
	char screen;
	} winFixType;

#define WIN_KEY 0
#define ALT_KEY 1
#define CTRL_KEY 2

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);

#ifdef __cplusplus
}
#endif

#endif
