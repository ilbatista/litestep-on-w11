#ifndef __CLOCKFACE_H
#define __CLOCKFACE_H

#include <windows.h>
#include "TrigBuffer.h"

class ClockFace
{
public:
	ClockFace(LPCSTR prefix);
	~ClockFace();
	void DrawClock(HDC hdc);
	void CalcCenter(int, int);
	void ReadClockSettings();
	int GetRefresh();

private:
	const char *Prefix;

	int iCenterX;
	int iCenterY;

	char order[3];

	SinBuffer *sinus;
	CosBuffer *cosinus;
	BOOL bNoSeconds;

	COLORREF clrSecond;
	COLORREF clrMinute;
	COLORREF clrHour;

	int iResolution;
	int iRefresh;

	int iHourWeight;
	int iMinuteWeight;
	int iSecondWeight;

	int iHourLength;
	int iMinuteLength;
	int iSecondLength;

};

#endif