/*

	ClockFace Class that handles all the clock functions

*/

#include <math.h>
#include "ClockFace.h"
#include "LSUtils.h"
#include "..\current\lsapi\lsapi.h"

//#define DEBUG
//#define SPAMDEBUG

ClockFace::ClockFace(LPCSTR prefix) :
	iCenterX(0),
	iCenterY(0),
	bNoSeconds(false),
	Prefix(prefix),
	sinus(NULL),
	cosinus(NULL),
	iResolution(60)
{
	order[0] = 'h';
	order[1] = 'm';
	order[2] = 's';
}

ClockFace::~ClockFace()
{
	delete sinus;
	delete cosinus;
}

int ClockFace::GetRefresh()
{
	return iRefresh;
}

// drawing function, originally from aLsClock
void ClockFace::DrawClock(HDC hdc)
{
	int index = 0;
	int hour_x, hour_y, minute_x, minute_y, second_x, second_y;
	SYSTEMTIME time;
	GetLocalTime(&time);

	HPEN hpen;
	HPEN hpenold;

	for (int i=0; i<3; i++)
	{
		switch(order[i])
		{
			case 'h':
				//hours

				// calc hour&minute to base of the given buffer precision
				index = (double)(time.wHour % 12 + (double)time.wMinute/60) * iResolution / 12;
				#ifdef SPAMDEBUG
					LSLogPrintf(LOG_DEBUG, Prefix, "hi: %d", index);
				#endif

				hour_x = iCenterX + iHourLength * (*sinus)[index];
				hour_y = iCenterY + iHourLength * (*cosinus)[index];

				hpen = CreatePen(PS_SOLID, iHourWeight, clrHour);
				hpenold = (HPEN) SelectObject(hdc, hpen);

				MoveToEx(hdc, iCenterX, iCenterY, NULL);
				LineTo(hdc, hour_x, hour_y);
				SelectObject(hdc, hpenold);
				DeleteObject(hpen);
			break;

			case 'm':
				// minutes (update to use seconds)
				index = (double)(time.wMinute + (double)time.wSecond/60) * iResolution / 60;
				#ifdef SPAMDEBUG
					LSLogPrintf(LOG_DEBUG, Prefix, "mi: %d", index);
				#endif
				minute_x = iCenterX + iMinuteLength * (*sinus)[index];
				minute_y = iCenterY + iMinuteLength * (*cosinus)[index];

				hpen = CreatePen(PS_SOLID, iMinuteWeight, clrMinute);
				hpenold = (HPEN) SelectObject(hdc, hpen);

				MoveToEx(hdc, iCenterX, iCenterY, NULL);
				LineTo(hdc, minute_x, minute_y);
				SelectObject(hdc, hpenold);
				DeleteObject(hpen);
			break;

			case 's':
				//seconds (update to use milliseconds)
				if (!bNoSeconds)
				{
					index = (double)(time.wSecond + (double)time.wMilliseconds/1000) * iResolution / 60;
					#ifdef SPAMDEBUG
						LSLogPrintf(LOG_DEBUG, Prefix, "si: %d", index);
					#endif
					second_x = iCenterX + iSecondLength * (*sinus)[index];
					second_y = iCenterY + iSecondLength * (*cosinus)[index];

					hpen = CreatePen(PS_SOLID, iSecondWeight, clrSecond);
					hpenold = (HPEN) SelectObject(hdc, hpen);

					MoveToEx(hdc, iCenterX, iCenterY, NULL);
					LineTo(hdc, second_x, second_y);
					SelectObject(hdc, hpenold);
					DeleteObject(hpen);
				}
			break;
		}
	}
}

void ClockFace::CalcCenter(int width, int height)
{
	// calculate center
	iCenterX = width / 2;
	iCenterY = height / 2;
}

void ClockFace::ReadClockSettings()
{
#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "Looking for prefix: %s", Prefix);
#endif

	bNoSeconds = LSUtils::PrefixedGetRCBool(Prefix, "NoSeconds", TRUE);

	clrSecond = LSUtils::PrefixedGetRCColor(Prefix, "SecondColor", RGB(255, 0, 0));
	clrMinute = LSUtils::PrefixedGetRCColor(Prefix, "MinuteColor", RGB(0, 255, 0));
	clrHour = LSUtils::PrefixedGetRCColor(Prefix, "HourColor", RGB(0, 0, 255));

	iHourWeight = LSUtils::PrefixedGetRCInt(Prefix, "HourWeight", 3);
	iMinuteWeight = LSUtils::PrefixedGetRCInt(Prefix, "MinuteWeight", 2);
	iSecondWeight = LSUtils::PrefixedGetRCInt(Prefix, "SecondWeight", 1);

	iHourLength = LSUtils::PrefixedGetRCInt(Prefix, "HourLength", 0.7*min(iCenterX, iCenterY));
	iMinuteLength = LSUtils::PrefixedGetRCInt(Prefix, "MinuteLength", 0.9*min(iCenterX, iCenterY));
	iSecondLength = LSUtils::PrefixedGetRCInt(Prefix, "SecondLength", 0.9*min(iCenterX, iCenterY));

	iResolution = LSUtils::PrefixedGetRCInt(Prefix, "Resolution", 60);
	iRefresh = LSUtils::PrefixedGetRCInt(Prefix, "Refresh", 60000/iResolution);

	sinus = new SinBuffer(iResolution, 0);
	cosinus = new CosBuffer(iResolution, -(iResolution)/2);

	char szTemp[MAX_LINE_LENGTH];
	char t1[MAX_LINE_LENGTH], t2[MAX_LINE_LENGTH], t3[MAX_LINE_LENGTH];
	char* tokens[3] = {t1, t2, t3};

	LSUtils::PrefixedGetRCString(Prefix, "DrawOrder", szTemp, "h m s" , MAX_LINE_LENGTH);
	int count = LCTokenize(szTemp, tokens, 3, NULL);

	for (int i = 0; i < count; i++)
		order[i] = tokens[i][0];

#ifdef DEBUG
	LSLogPrintf(LOG_DEBUG, Prefix, "order: %s", order);
	LSLogPrintf(LOG_DEBUG, Prefix, "lengths: h %d, m %d s %d", iHourLength, iMinuteLength, iSecondLength);
#endif

}