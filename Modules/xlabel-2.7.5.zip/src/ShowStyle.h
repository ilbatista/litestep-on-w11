///////////////////////////////////////////////////////////////////
//This library is freeware, however, you may not sale or charge any money for it. 
//This code is supplied as-is. I make no guarantees about the suitability
//of this code - use at your own risk.

//Visit my web-page for other software!
//http://www.appspeed.com

#ifndef __SHOWSTYLE_H__
#define __SHOWSTYLE_H__

#ifdef __cplusplus
extern "C"{
#endif

bool MagicShow( HDC hSrcDC , int x , int y , HDC hDestDC , int xd , int yd , int width , int height , int nDelay, int nStep, int nStyle  );

#ifdef __cplusplus
}
#endif

#endif
