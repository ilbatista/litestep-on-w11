#if !defined(__IMAGETEXTURE_H)
#define __IMAGETEXTURE_H

#include "Texture.h"

class ImageTexture : public Texture
{
public:

	ImageTexture();
	virtual ~ImageTexture();

	void configure(const string &prefix, const string &subKey);
	void apply(HDC hDC, int x, int y, int width, int height, int imageType);
	void applyAnim(HDC hDC, int x, int y, int width, int height, int imageType, int count);

private:

	void paintEffects(HDC destHDC);
	
	HDC memoryAnimDC;
	HBITMAP memoryAnimBitmap;

	int frameWidth;
	int frameHeight;

	HDC memoryHoverAnimDC;
	HBITMAP memoryHoverAnimBitmap;

	int hoverframeWidth;
	int hoverframeHeight;

	HBITMAP bitmap;
	HBITMAP hoverbitmap;
	HBITMAP pressedbitmap;

	HDC memoryDC;
	HBITMAP memoryBitmap;

	HDC memoryHoverDC;
	HBITMAP memoryHoverBitmap;

	HDC memoryPressedDC;
	HBITMAP memoryPressedBitmap;

	int imageHeight;
	int imageWidth;

	int hoverimageHeight;
	int hoverimageWidth;

	int pressedimageHeight;
	int pressedimageWidth;

	bool usefakeTransparency;

	int leftEdge;
	int topEdge;
	int rightEdge;
	int bottomEdge;

	int mode;

	int _saturation;
	int _hueIntensity;
	COLORREF _hueColor;
};

#endif
