#include "common.h"
#include "Label.h"
#include "SystemInfo.h"
#include "LabelSettings.h"
#include "Font.h"

#include "Texture.h"
#include "Font.h"

#define _MERGE_RDATA_
#include "AggressiveOptimize.h"

//Textedit
#include "regexp.h"
#include "regmagic.h"

#include <stdio.h>

// Bang commands
void BangAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs);
void BangClipboardCopy(HWND hwndCaller, LPCSTR pszArgs);
void BangClipboardPaste(HWND hwndCaller, LPCSTR pszArgs);
void BangCreate(HWND hwndCaller, LPCSTR pszArgs);
void BangDebug(HWND hwndCaller, LPCSTR pszArgs);
void BangDestroy(HWND hwndCaller, LPCSTR pszArgs);
void BangHide(HWND hwndCaller, LPCSTR pszArgs);
void BangLSBoxHook(HWND hwndCaller, LPCSTR pszArgs);
void BangMove(HWND hwndCaller, LPCSTR pszArgs);
void BangNext(HWND hwndCaller, LPCSTR pszArgs);
void BangPinToDesktop(HWND hwndCaller, LPCSTR pszArgs);
void BangPrevious(HWND hwndCaller, LPCSTR pszArgs);
void BangRefresh(HWND hwndCaller, LPCSTR pszArgs);
void BangReposition(HWND hwndCaller, LPCSTR pszArgs);
void BangResize(HWND hwndCaller, LPCSTR pszArgs);
void BangScroll(HWND hwndCaller, LPCSTR pszArgs);
void BangSetFontColor(HWND hwndCaller, LPCSTR pszArgs);
void BangSetText(HWND hwndCaller, LPCSTR pszArgs);
void BangShow(HWND hwndCaller, LPCSTR pszArgs);
void BangShowHide(HWND hwndCaller, LPCSTR pszArgs);
void BangToggleAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs);
void BangToggle(HWND hwndCaller, LPCSTR pszArgs);
void BangUpdate(HWND hwndCaller, LPCSTR pszArgs);
void BangSetAlpha(HWND hwndCaller, LPCSTR pszArgs);
void BangToggleGhosted(HWND hwndCaller, LPCSTR pszArgs);

void BangAdjustWidth(HWND hwndCaller, LPCSTR pszArgs);
void BangAdjustHeight(HWND hwndCaller, LPCSTR pszArgs);

void BangmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs);
void BangPosmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs);
void BangSizemzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs);

void BangSetAnimation(HWND hwndCaller, LPCSTR pszArgs);

//Desktop
void BangDesktopCreate(HWND hwndCaller, LPCSTR pszArgs);
void BangDesktopSave(HWND hwndCaller, LPCSTR pszArgs);

//Textedit-2.52
void BangTextEdittextAppend(HWND hwndCaller, LPCSTR pszArgs);
void BangTextEdittextReplace(HWND hwndCaller, LPCSTR pszArgs);
void BangTextEdittextDelete(HWND hwndCaller, LPCSTR pszArgs);

//Shortcut 2
void BangShortcutHide(HWND hwndCaller, LPCSTR pszArgs);
void BangShortcutShow(HWND hwndCaller, LPCSTR pszArgs);
void BangShortcutToggle(HWND hwndCaller, LPCSTR pszArgs);
void BangShortcutOnTop(HWND hwndCaller, LPCSTR pszArgs);
void BangShortcutOnBottom(HWND hwndCaller, LPCSTR pszArgs);
void BangShortcutOnTopToggle(HWND hwndCaller, LPCSTR pszArgs);

void getToken(char line[4096], char temp[4096], bool escape_codes = true);

bool usetextedit = GetRCBoolean("xlabel", "UseTextEdit");
bool useshortcut2 = GetRCBoolean("xlabel", "UseShortcut2");

string Bang;

HINSTANCE hInstance;
HWND messageHandler;

LabelList labelList;
LabelList desktoplabelList;
LabelList shortcutlabelList;

StringList labelDesktopItems;
StringList labelShortcutItems;

int lsMessages[] = {
	LM_GETREVID,
	LM_REFRESH,
	0
};

#define LM_UPDATEBG (WM_USER + 1)

Label *lookupLabel( const string &name, LabelList searchList = labelList );

LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case LM_GETREVID:
		{
			UINT uLength;
			StringCchPrintf((char*)lParam, 64, "%s %s", V_NAME, V_VERSION);
			
			if (SUCCEEDED(StringCchLength((char*)lParam, 64, &uLength)))
				return uLength;

			lParam = NULL;
			return 0;
		}
		
		case LM_REFRESH:
		{
			StringList labelNames = GetRCNameList("*Label");

			// refresh the "AllLabels" configuration
			delete defaultSettings;
			defaultSettings = new LabelSettings();

			for(LabelListIterator iter = labelList.begin(); iter != labelList.end(); iter++)
			{
				if(!(*iter)->getBox())
				{
					// destroy all labels that no longer exist and that are not in a box
					for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
					{
						if(stricmp((*it).c_str(), (*iter)->getName().c_str()) == 0)
							break;
					}
					if (it == labelNames.end())
					{
						labelList.remove(*iter);
						delete *iter;
						continue;
					}
				}

				// we can reconfigure all other labels, even if they are "boxed"
				(*iter)->reconfigure();
			}

			// create the rest
			for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
			{
				Label *label = lookupLabel(*it);
				
				if (!label) 
				{
					label = new Label(*it);

					label->load(hInstance);
				
					labelList.insert(labelList.end(), label);
				}
			}
			return 0;
		}

		case LM_UPDATEBG:
		{
			PaintDesktopEx(0, 0, 0, 0, 0, 0, 0, TRUE);

			LabelListIterator i;
			for(i = labelList.begin(); i != labelList.end(); i++)
			{
				Label *label = *i;

				if(label->getBox() == 0)
					label->repaint(true);
			}

			for(i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
			{
				Label *label = *i;

				if(label->getBox() == 0)
					label->repaint(true);
			}

			for(i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
			{
				Label *label = *i;

				if(label->getBox() == 0)
					label->repaint(true);
			}

			return 0;
		}

		case WM_DISPLAYCHANGE:


		case WM_SETTINGCHANGE:
		{
			PostMessage(hWnd, LM_UPDATEBG, 0, 0);
			return 0;
		}
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	WNDCLASSEX wc;

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS | CS_DBLCLKS;
	wc.lpfnWndProc = Label::windowProcedure;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = sizeof(Label *);
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = LoadCursor(0, IDC_ARROW);
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "xLabel";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = MessageHandlerProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = 0;
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "xLabelMessageHandler";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	messageHandler = CreateWindowEx(WS_EX_TOOLWINDOW,
		"xLabelMessageHandler",
		0,
		WS_POPUP,
		0, 0, 0, 0, 
		0,
		0,
		hInstance,
		0);

	if (!messageHandler)
		return 1;
	
	SendMessage(GetLitestepWnd(),
		LM_REGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	::hInstance = hInstance;

	defaultSettings = new LabelSettings();
	systemInfo = new SystemInfo();

	StringList labelNames = GetRCNameList("*Label");

	for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
	{
		Label *label = new Label(*it);
	
		label->load(hInstance);
	
		labelList.insert(labelList.end(), label);
	}

	//Desktop Items
	labelDesktopItems = GetRCLineList("*xlabeldesktopitem");

	if (!labelDesktopItems.empty())
	{
		for(it = labelDesktopItems.begin(); it != labelDesktopItems.end(); it++)
		{
			char name[32];
			char *buffers[] = {name};

			if(LCTokenize((*it).c_str(), buffers, 1, 0) >= 1)
			{
				Label *label = new Label(name);
		
				label->desktopload(hInstance, (*it));
		
				desktoplabelList.insert(desktoplabelList.end(), label);
			}
		}
	}

	//Shortcut Items
	if (useshortcut2)
	{
		labelShortcutItems = GetRCLineList("*shortcut");

		if (!labelShortcutItems.empty())
		{
			int lastx = 0;
			int lasty = 0;
			for(it = labelShortcutItems.begin(); it != labelShortcutItems.end(); it++)
			{
				char name[64], ix[16], iy[16];
				char *buffers[] = {name, ix, iy};

				if(LCTokenize((*it).c_str(), buffers, 3, 0) >= 3)
				{
					Label *label = new Label(name);

					label->shortcutload(hInstance, (*it), lastx, lasty);

					lastx = ParseCoord(ix, 0, GetSystemMetrics(SM_CXSCREEN), lastx);
					lasty = ParseCoord(iy, 0, GetSystemMetrics(SM_CYSCREEN), lasty);
				
					shortcutlabelList.insert(shortcutlabelList.end(), label);
				}
			}
		}
	}

	AddBangCommand("!LabelAlwaysOnTop", BangAlwaysOnTop);
	AddBangCommand("!LabelClipboardCopy", BangClipboardCopy);
	AddBangCommand("!LabelClipboardPaste", BangClipboardPaste);
	AddBangCommand("!LabelCreate", BangCreate);
	AddBangCommand("!LabelDebug", BangDebug);
	AddBangCommand("!LabelDestroy", BangDestroy);
	AddBangCommand("!LabelHide", BangHide);
	AddBangCommand("!LabelLSBoxHook", BangLSBoxHook);
	AddBangCommand("!LabelMove", BangMove);
	AddBangCommand("!LabelNext", BangNext);
	AddBangCommand("!LabelPinToDesktop", BangPinToDesktop);
	AddBangCommand("!LabelPrevious", BangPrevious);
	AddBangCommand("!LabelRefresh", BangRefresh);
	AddBangCommand("!LabelReposition", BangReposition);
	AddBangCommand("!LabelResize", BangResize);
	AddBangCommand("!LabelScroll", BangScroll);
	AddBangCommand("!LabelSetFontColor", BangSetFontColor);
	AddBangCommand("!LabelSetText", BangSetText);
	AddBangCommand("!LabelShow", BangShow);
	AddBangCommand("!LabelShowHide", BangShowHide);
	AddBangCommand("!LabelToggleAlwaysOnTop", BangToggleAlwaysOnTop);
	AddBangCommand("!LabelToggle", BangToggle);
	AddBangCommand("!LabelUpdate", BangUpdate);
	if(IsOS(OS_2KXP))
		AddBangCommand("!LabelSetAlpha", BangSetAlpha);
	AddBangCommand("!LabelToggleGhosted", BangToggleGhosted);

	AddBangCommand("!LabelAutoWidth", BangAdjustWidth);
	AddBangCommand("!LabelAutoHeight", BangAdjustHeight);

	AddBangCommand("!LabelmzscriptVarCopy", BangmzscriptVarCopy);
	AddBangCommand("!LabelPosmzscriptVarCopy", BangPosmzscriptVarCopy);
	AddBangCommand("!LabelSizemzscriptVarCopy", BangSizemzscriptVarCopy);

	AddBangCommand("!LabelSetAnimation", BangSetAnimation);

	//Desktop
	AddBangCommand("!LabelDesktopCreate", BangDesktopCreate);
	AddBangCommand("!LabelDesktopSave", BangDesktopSave);

	//TextEdit 2.52
	if (usetextedit)
	{
		AddBangCommand("!textappend", BangTextEdittextAppend);
		AddBangCommand("!textdel", BangTextEdittextDelete);
		AddBangCommand("!textreplace", BangTextEdittextReplace);
	}

	//Shortcut2
	if (useshortcut2)
	{
		AddBangCommand("!ShortcutGroupHide", BangShortcutHide);
		AddBangCommand("!ShortcutGroupShow", BangShortcutShow);
		AddBangCommand("!ShortcutGroupToggle", BangShortcutToggle);
		AddBangCommand("!ShortcutGroupOnTop", BangShortcutOnTop);
		AddBangCommand("!ShortcutGroupOnBottom", BangShortcutOnBottom);
		AddBangCommand("!ShortcutGroupOnTopToggle", BangShortcutOnTopToggle);
	}

	return 0;
}

extern HDC hdcDesktop;
extern HBITMAP hbmDesktop;

void quitModule(HINSTANCE hInstance)
{
	RemoveBangCommand("!LabelAlwaysOnTop");
	RemoveBangCommand("!LabelClipboardCopy");
	RemoveBangCommand("!LabelClipboardPaste");
	RemoveBangCommand("!LabelCreate");
	RemoveBangCommand("!LabelDebug");
	RemoveBangCommand("!LabelDestroy");
	RemoveBangCommand("!LabelHide");
	RemoveBangCommand("!LabelLSBoxHook");
	RemoveBangCommand("!LabelMove");
	RemoveBangCommand("!LabelNext");
	RemoveBangCommand("!LabelPinToDesktop");
	RemoveBangCommand("!LabelPrevious");
	RemoveBangCommand("!LabelRefresh");
	RemoveBangCommand("!LabelReposition");
	RemoveBangCommand("!LabelResize");
	RemoveBangCommand("!LabelScroll");
	RemoveBangCommand("!LabelSetFontColor");
	RemoveBangCommand("!LabelSetText");
	RemoveBangCommand("!LabelShow");
	RemoveBangCommand("!LabelShowHide");
	RemoveBangCommand("!LabelToggleAlwaysOnTop");
	RemoveBangCommand("!LabelToggle");
	RemoveBangCommand("!LabelUpdate");
	if(IsOS(OS_2KXP))
		RemoveBangCommand("!LabelSetAlpha");
	RemoveBangCommand("!LabelToggleGhosted");

	RemoveBangCommand("!LabelAutoWidth");
	RemoveBangCommand("!LabelAutoHeight");

	RemoveBangCommand("!LabelmzscriptVarCopy");
	RemoveBangCommand("!LabelPosmzscriptVarCopy");
	RemoveBangCommand("!LabelSizemzscriptVarCopy");

	RemoveBangCommand("!LabelSetAnimation");

	//Desktop
	RemoveBangCommand("!LabelDesktopCreate");
	RemoveBangCommand("!LabelDesktopSave");

	//TextEdit 2.52
	if (usetextedit)
	{
		RemoveBangCommand("!textappend");
		RemoveBangCommand("!textdel");
		RemoveBangCommand("!textreplace");
	}

	//Shortcut2
	if (useshortcut2)
	{
		RemoveBangCommand("!ShortcutGroupHide");
		RemoveBangCommand("!ShortcutGroupShow");
		RemoveBangCommand("!ShortcutGroupToggle");
		RemoveBangCommand("!ShortcutGroupOnTop");
		RemoveBangCommand("!ShortcutGroupOnBottom");
		RemoveBangCommand("!ShortcutGroupOnTopToggle");
	}

	LabelListIterator it;

	for(it = labelList.begin(); it != labelList.end(); it++)
		delete *it;

	labelList.clear();

	for(it = desktoplabelList.begin(); it != desktoplabelList.end(); it++)
		delete *it;

	desktoplabelList.clear();

	if (useshortcut2)
	{
		for(it = shortcutlabelList.begin(); it != shortcutlabelList.end(); it++)
			delete *it;

		shortcutlabelList.clear();
	}
	
	SendMessage(GetLitestepWnd(),
		LM_UNREGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	DestroyWindow(messageHandler);

	UnregisterClass("xLabel", hInstance);
	UnregisterClass("xLabelMessageHandler", hInstance);

	delete systemInfo;
	delete defaultSettings;

	hbmDesktop = (HBITMAP) SelectObject(hdcDesktop, hbmDesktop);
	DeleteDC(hdcDesktop);
	DeleteObject(hbmDesktop);
}

Label *lookupLabel(const string &name, LabelList searchList)
{
	LabelListIterator it;

	for(it = searchList.begin(); it != searchList.end(); it++)
	{
		if(stricmp(name.c_str(), (*it)->getName().c_str()) == 0)
			return *it;
	}

	return 0;
}

BOOL APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	if(dwReason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hInstance);
	}

	return TRUE;
}

// !LabelDesktopCreate <append>|<replace> <path to lnkfolder>
void BangDesktopCreate(HWND hwndCaller, LPCSTR pszArgs)
{
	char action[32], path[256];
	char *prebuffers[] = {action, path};

	LCTokenize(pszArgs, prebuffers, 2, NULL);
	
	bool defaultDesktop = false;
	string searchPath = path;

	if (!searchPath.empty())
	{
		searchPath = searchPath.substr(1, searchPath.length() - 2);

		//Check for ending BackSlash
		string check = searchPath.substr(searchPath.length()-1, searchPath.length());

		StringList labelDesktopLnkItems;

		string temp = "";
		string cLnkName = "";

		WIN32_FIND_DATA FindData;
		if ( stricmp(searchPath.c_str(), ".desktop") == 0 || stricmp(searchPath.c_str(), "deskto") == 0 || stricmp(searchPath.c_str(), "eskto") == 0 )
			defaultDesktop = true;
		else if (check != "\\")
			temp = (searchPath + "\\*.lnk");
		else
			temp = (searchPath + "*.lnk");

		if (defaultDesktop)
		{
			char tmp[4096];
			VarExpansion( tmp, "$desktopdir$" );
			searchPath = tmp;
			temp = (searchPath + "*.lnk");
		}
		HANDLE hFindHandle;

		hFindHandle = FindFirstFile(temp.c_str(), &FindData);

		for(;;)
		{
			if(INVALID_HANDLE_VALUE == hFindHandle)
				break;
			
			if(!(FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
			{
				cLnkName = FindData.cFileName;

				//Make Lower
				temp = "";
				int length = cLnkName.length();
				int i = 0;
		
				while(i < length)
					temp.append(1, tolower(cLnkName[i++]));
		
				// Make sure its a lnk file
				if (strstr (temp.c_str(), ".lnk") != NULL)
				{
					temp = (searchPath + cLnkName);
					labelDesktopLnkItems.insert(labelDesktopLnkItems.end(), temp.c_str());
				}
			}

			if(!FindNextFile(hFindHandle, &FindData))
				break;
		}

		if (defaultDesktop)
		{
			char tmp[4096];
			VarExpansion( tmp, "$commondesktopdir$" );
			searchPath = tmp;
			temp = (searchPath + "*.lnk");

			hFindHandle = FindFirstFile(temp.c_str(), &FindData);

			for(;;)
			{
				if(INVALID_HANDLE_VALUE == hFindHandle)
					break;
				
				if(!(FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
				{
					cLnkName = FindData.cFileName;

					//Make Lower
					temp = "";
					int length = cLnkName.length();
					int i = 0;
			
					while(i < length)
						temp.append(1, tolower(cLnkName[i++]));
			
					// Make sure its a lnk file
					if (strstr (temp.c_str(), ".lnk") != NULL)
					{
						temp = (searchPath + cLnkName);
						labelDesktopLnkItems.insert(labelDesktopLnkItems.end(), temp.c_str());
					}
				}

				if(!FindNextFile(hFindHandle, &FindData))
					break;
			}
		}

		FindClose(hFindHandle);

		string itemSavePath = GetRCString("xlabeldesktop", "ConfigFile", "");
		if (!itemSavePath.empty())
		{
			int counter = 1;

			//Clear all *xlabeldesktopitem lines
			Bang = ("@" + itemSavePath + "@ @\\*[xX][lL][aA][bB][eE][lL][dD][eE][sS][kK][tT][oO][pP][iI][tT][eE][mM]@");
			BangTextEdittextDelete(NULL, Bang.c_str());

			if (!labelDesktopItems.empty() && (stricmp(action, "append") == 0))
			{
				for(StringListIterator it = labelDesktopItems.begin(); it != labelDesktopItems.end(); it++)
				{
					char buffer[32];
					strcpy(buffer, "xldi");
					char counterbuffer[16];
					itoa( counter, counterbuffer, 10 );
					if (counter < 10)
						strcat(buffer, "0");
					strcat(buffer, counterbuffer);

					char prefix[64], name[64], data[128];
					char *linebuffers[] = {prefix, name};

					LCTokenize((*it).c_str(), linebuffers, 2, data);

					Bang = ("@" + itemSavePath + "@ @*xlabeldesktopitem " + buffer + " " + data + "@");
					BangTextEdittextAppend(NULL, Bang.c_str());

					counter++;
				}
			}
			
			int tempcounter = 1;

			NameValuePair directionValues[] = {
			{ "left", 1 },
			{ "right", 2 },
			{ "up", 3 },
			{ "down", 4 },
			{ 0, 0 }
			};

			NameValuePair wrapdirectionValues[] = {
			{ "up", 1 },
			{ "down", 2 },
			{ "left", 3 },
			{ "right", 4 },
			{ 0, 0 }
			};

			int DIStartx = GetRCCoord("xlabeldesktop", "X", 0, GetSystemMetrics(SM_CXSCREEN));
			int DIStarty = GetRCCoord("xlabeldesktop", "Y", 0, GetSystemMetrics(SM_CYSCREEN));
			int DIwidth = GetRCDimen("xlabeldesktop", "ItemWidth", 125, GetSystemMetrics(SM_CXSCREEN));
			int DIheight = GetRCDimen("xlabeldesktop", "ItemHeight", 50, GetSystemMetrics(SM_CYSCREEN));
			int xSpace = GetRCInt("xlabeldesktop", "SpacingX", 0);
			int ySpace = GetRCInt("xlabeldesktop", "SpacingY", 0);
			
			int direction = GetRCNamedValue("xlabeldesktop", "Direction", directionValues, 2);
			int wrapDirection = GetRCNamedValue("xlabeldesktop", "WrapDirection", wrapdirectionValues, 2);
			int wrapCount = GetRCInt("xlabeldesktop", "WrapCount", 10);

			int tempx;
			int tempy;

			if (direction == 1)
				tempx = DIStartx+DIwidth+xSpace;
			else if (direction == 2)
				tempx = DIStartx-(DIwidth+xSpace);
			else if (direction == 3)
				tempy = DIStarty+DIheight+ySpace;
			else if (direction == 4)
				tempy = DIStarty-(DIheight+ySpace);

			if (direction == 1 || direction == 2)
				tempy = DIStarty;
			else if (direction == 3 || direction == 4)
				tempx = DIStartx;

			for(StringListIterator it = labelDesktopLnkItems.begin(); it != labelDesktopLnkItems.end(); it++)
			{
				char buffer[32];
				strcpy(buffer, "xldi");
				char counterbuffer[16];
				char xbuffer[16];
				char ybuffer[16];
				itoa( counter, counterbuffer, 10 );
				if (counter < 10)
					strcat(buffer, "0");
				strcat(buffer, counterbuffer);

				//Sorting/Positioning due to settings
				div_t div_result = div( tempcounter, wrapCount );

				if (direction == 1 || direction == 2)
				{
					if (wrapDirection > 2)
						wrapDirection = 2;
					
					if (div_result.quot > 0 && div_result.rem == 1)
					{
						tempx = DIStartx;
						if (wrapDirection == 1)
							tempy = DIStarty-(div_result.quot*(DIheight+ySpace));
						else if (wrapDirection == 2)
							tempy = DIStarty+div_result.quot*(DIheight+ySpace);
					}
					else
					{
						if (direction == 1)
							tempx = tempx-(DIwidth+xSpace);
						else if (direction == 2)
							tempx = tempx+DIwidth+xSpace;
					}
				}
				if (direction == 3 || direction == 4)
				{
					if (wrapDirection < 3)
						wrapDirection = 4;
					
					if (div_result.quot > 0 && div_result.rem == 1)
					{
						tempy = DIStarty;
						if (wrapDirection == 3)
							tempx = DIStartx-(div_result.quot*(DIwidth+xSpace));
						else if (wrapDirection == 4)
							tempx = DIStartx+div_result.quot*(DIwidth+xSpace);
					}
					else
					{
						if (direction == 3)
							tempy = tempy-(DIheight+ySpace);
						else if (direction == 4)
							tempy = tempy+DIheight+ySpace;
					}
				}

				itoa( tempx, xbuffer, 10 );
				itoa( tempy, ybuffer, 10 );

				Bang = ("@" + itemSavePath + "@ @*xlabeldesktopitem " + buffer + " " + xbuffer + " " + ybuffer + " \"" + *it + "\"@");
				BangTextEdittextAppend(NULL, Bang.c_str());
				counter++;
				tempcounter++;
			}
		}
		else
		{
			Bang = "!alert \"You haven't defined the setting xLabelDesktopConfigFile, which points to the file containing your *xLabelDesktopItem lines!\"";
			LSExecute(NULL, Bang.c_str(), SW_SHOWNORMAL);
		}
	}
}

// !LabelDesktopSave [<desktopitem>]
void BangDesktopSave(HWND hwndCaller, LPCSTR pszArgs)
{
	string helper = pszArgs;
	if (!labelDesktopItems.empty())
	{
		if (helper.empty())
		{
			char temp[64], name[16];
			char *buffers[] = {temp, name};

			for(StringListIterator it = labelDesktopItems.begin(); it != labelDesktopItems.end(); it++)
			{
				if(LCTokenize((*it).c_str(), buffers, 2, NULL) >= 2)
				{
					Label *label = lookupLabel(name, desktoplabelList);

					if(label)
					{
						string posx, posy;
		
						int left = label->getX();
						int top = label->getY();

						if (left < 0)
							left = 0;
						if (top < 0)
							top = 0;
						
						char buffer[32];
						sprintf(buffer, "%d", left);
						posx = buffer;
						sprintf(buffer, "%d", top);
						posy = buffer;

						Bang = ("@" + label->configSavePath + "@ @[		]*(\\*[xX][lL][aA][bB][eE][lL][dD][eE][sS][kK][tT][oO][pP][iI][tT][eE][mM]).*(" + label->getName() + ")@ @\\1 \\2 " + posx + " " + posy + " \"" + label->iconCommand + "\"@");
						if (!label->configSavePath.empty())
							BangTextEdittextReplace(NULL, Bang.c_str());
						else
						{
							Bang = "!alert \"You haven't defined the setting xLabelDesktopConfigFile, which points to the file containing your *xLabelDesktopItem lines!\"";
							LSExecute(NULL, Bang.c_str(), SW_SHOWNORMAL);
						}
					}
				}
			}
			//Stop if complete Desktop was saved
			return;
		}
		else
		{
			Label *label = lookupLabel(helper.c_str(), desktoplabelList);

			if(label)
			{
				string posx, posy;
		
				int left = label->getX();
				int top = label->getY();

				if (left < 0)
					left = 0;
				if (top < 0)
					top = 0;
					
				char buffer[32];
				sprintf(buffer, "%d", left);
				posx = buffer;
				sprintf(buffer, "%d", top);
				posy = buffer;

				Bang = ("@" + label->configSavePath + "@ @[		]*(\\*[xX][lL][aA][bB][eE][lL][dD][eE][sS][kK][tT][oO][pP][iI][tT][eE][mM]).*(" + label->getName().c_str() + ")@ @\\1 \\2 " + posx + " " + posy + " \"" + label->iconCommand + "\"@");
				if (!label->configSavePath.empty())
					BangTextEdittextReplace(NULL, Bang.c_str());
				return;
			}
		}
	}
	//No Complete Desktop Save and No Single DesktopItem Save
	//Try Shortcuts ;) 
	Label *label = lookupLabel(helper.c_str(), shortcutlabelList);

	if(label)
	{
		string posx, posy;
		
		int left = label->getX();
		int top = label->getY();

		if (left < 0)
			left = 0;
		if (top < 0)
			top = 0;
					
		char buffer[32];
		sprintf(buffer, "%d", left);
		posx = buffer;
		sprintf(buffer, "%d", top);
		posy = buffer;
		
		Bang = ("@" + label->configSavePath + "@ @[		]*(\\*[sS][hH][oO][rR][tT][cC][uU][tT])([ 	]*)(\\=" + label->getName() + "\\=)([ 	]*)([^ 	]+)([ 	]*)([^ 	]+)([ 	]*)(.*)@ @\\1 \\3 " + posx + " " + posy + " \\9@");
		if (!label->configSavePath.empty())
			BangTextEdittextReplace(NULL, Bang.c_str());
		else
		{
			Bang = "!alert \"You haven't defined the setting ShortcutConfigFile, which points to the file containing your *shortcut lines!\"";
			LSExecute(NULL, Bang.c_str(), SW_SHOWNORMAL);
		}
	}
}

// !Labelmzscriptvarcopy <label> <mzscript var>
void BangmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], var[64];
	char *buffers[] = {name, var};

	if(LCTokenize(pszArgs, buffers, 2, NULL) == 2)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->mzscriptvarcopy(var);
		}
	}
}

// !LabelPosmzscriptvarcopy <label> <mzscript var xpos> <mzscript var ypos>
void BangPosmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], varx[64], vary[64];
	char *buffers[] = {name, varx, vary};

	if(LCTokenize(pszArgs, buffers, 3, NULL) == 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->posmzscriptvarcopy(varx, vary);
		}
	}
}

// !LabelSizemzscriptvarcopy <label> <mzscript var cx> <mzscript var cy>
void BangSizemzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], varcx[64], varcy[64];
	char *buffers[] = {name, varcx, varcy};

	if(LCTokenize(pszArgs, buffers, 3, NULL) == 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->sizemzscriptvarcopy(varcx, varcy);
		}
	}
}

// !LabelSetAnimation <label> <on | off> [<loops>]
void BangSetAnimation(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], option[16], loops[16];
	char *buffers[] = {name, option, loops};

	int numTokens = LCTokenize(pszArgs, buffers, 3, NULL);
	if (numTokens >= 2)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			if (numTokens == 2)
			{
				if(stricmp(option, "off") == 0)
					label->setAnimation(false);
				else if(stricmp(option, "on") == 0)
					label->setAnimation(true);
			}
			else if  (numTokens == 3)
			{
				if(stricmp(option, "off") == 0)
					label->setAnimation(false);
				else if(stricmp(option, "on") == 0)
					label->setAnimation(true, atoi(loops));
			}
		}
	}
}

// !LabelAlwaysOnTop <label>
void BangAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->setAlwaysOnTop(true);
	else
	{
		LabelListIterator i;
		for( i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setAlwaysOnTop(true);
		}
		for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setAlwaysOnTop(true);
		}
	}
}

// !LabelClipboardCopy <label> <prefix>
void BangClipboardCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], prefix[256];
	char *buffers[] = {name, prefix};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->clipboardCopy((numTokens >= 2) ? prefix : "");
	}
}

// !LabelClipboardPaste <label> <prefix>
void BangClipboardPaste(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], prefix[256];
	char *buffers[] = {name, prefix};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->clipboardPaste((numTokens >= 2) ? prefix : "");
	}
}

// !LabelCreate <label>
void BangCreate(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = new Label(pszArgs);
	label->load(hInstance);
	labelList.insert(labelList.end(), label);
}

// !LabelDebug
void BangDebug(HWND hwndCaller, LPCSTR pszArgs)
{
	LabelListIterator it;
	string message = "Normal Labels: (*label)\r\n";

	for(it = labelList.begin(); it != labelList.end(); it++)
	{
		message.append((*it)->getName());
		message.append(", ");
	}

	message.append("\r\n\r\nDesktop Icons: (*xlabeldesktopitem)\r\n");

	for(it = desktoplabelList.begin(); it != desktoplabelList.end(); it++)
	{
		message.append((*it)->getName());
		message.append(", ");
	}

	message.append("\r\n\r\nShortcut Lines: (*shortcut)\r\n");

	for(it = shortcutlabelList.begin(); it != shortcutlabelList.end(); it++)
	{
		message.append((*it)->getName());
		message.append("\r\n");
	}

	MessageBox(NULL, message.c_str(), "xLabel Debug Informations", MB_SETFOREGROUND);
}

// !LabelDestroy <label>
void BangDestroy(HWND hwndCaller, LPCSTR pszArgs)
{
	if (stricmp(pszArgs, "xlabeldesktop") == 0)
	{
		for(LabelListIterator i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
		{
			desktoplabelList.remove((*i));
			delete (*i);
		}
	}
	else
	{
		Label *label = lookupLabel(pszArgs);
		if(label)
		{
			labelList.remove(label);
			delete label;
		}
	}
}

// !LabelHide <label>
void BangHide(HWND hwndCaller, LPCSTR pszArgs)
{
	if (stricmp(pszArgs, "xlabeldesktop") == 0)
	{
		for(LabelListIterator i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
			(*i)->hide();
	}
	else
	{
		Label *label = lookupLabel(pszArgs);
		if(label)
			label->hide();
		else
		{
			LabelListIterator i;
			for( i = labelList.begin(); i != labelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
					(*i)->hide();
			}
			for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
					(*i)->hide();
			}
		}
	}
}

// !LabelLSBoxHook <labelname>
void BangLSBoxHook(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64];
	char *buffers[] = {name};

	if(LCTokenize(pszArgs, buffers, 1, 0) == 1)
	{
		const char *handle = strrchr(pszArgs,' ');
	    HWND hwndBox = (HWND)atoi(handle+1);

		Label *label = lookupLabel(name);

		if(label)
		{
			label->setBox(hwndBox);
			label->update();
		}
		else
		{
			label = new Label(name);
			label->load(hInstance, hwndBox);
			labelList.insert(labelList.end(), label);
		}
	}
}

// !LabelMove <label> <x> <y> [<steps> <time>]
void BangMove(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16];
	char *buffers[] = {name, A, B, C, D};

	if(LCTokenize(pszArgs, buffers, 5, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int x = ParseCoord(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int y = ParseCoord(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int step = atoi( C );
			int time = atoi( D );

			label->move(x, y, step, time);
		}
	}
}

// !LabelNext <label>
void BangNext(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->next();
}

// !LabelPinToDesktop <label>
void BangPinToDesktop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->setAlwaysOnTop(false);
	else
	{
		LabelListIterator i;
		for( i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setAlwaysOnTop(false);
		}
		for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setAlwaysOnTop(false);
		}
	}
}

// !LabelPrevious <label>
void BangPrevious(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->previous();
}

// !LabelRefresh <label>
void BangRefresh(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);

	if(label)
		label->reconfigure();
	else
	{
		LabelListIterator i;
		for( i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->reconfigure();
		}
		for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->reconfigure();
		}
	}
}

// !LabelReposition <label> <x> <y> <width> <height> [<steps>] [<time>]
void BangReposition(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16], E[16], F[16];
	char *buffers[] = {name, A, B, C, D, E, F};

	if(LCTokenize(pszArgs, buffers, 7, NULL) >= 5)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int x = ParseCoord(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int y = ParseCoord(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int w = ParseDimen(C, 0, GetSystemMetrics(SM_CXSCREEN));
			int h = ParseDimen(D, 0, GetSystemMetrics(SM_CYSCREEN));
			int step = atoi( E );
			int time = atoi( F );

			label->reposition(x, y, w, h, step, time);
		}
	}
}

// !LabelResize <label> <width> <height> [<steps> <time>]
void BangResize(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16];
	char *buffers[] = {name, A, B, C, D};

	if(LCTokenize(pszArgs, buffers, 5, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int w = ParseDimen(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int h = ParseDimen(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int step = atoi( C );
			int time = atoi( D );

			label->resize(w, h, step, time);
		}
	}
}

// !LabelScroll <label> <'on', 'off', 'toggle', limit>
void BangScroll(HWND hwndCaller, LPCSTR pszArgs)
{
	// FIXME: This should be split into multiple bang commands
	char name[64], option[16];
	char *buffers[] = {name, option};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 2)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			if(stricmp(option, "off") == 0)
				label->setScrolling(0);
			else if(stricmp(option, "on") == 0)
				label->setScrolling(label->scrollBackup);
			else if(stricmp(option, "toggle") == 0)
			{
				if (label->isScrolling() > 0)
					label->setScrolling(0);
				else
					label->setScrolling(label->scrollBackup);
			}
			else
			{
				int limit = atoi(option);
				if(limit >= 0) label->setScrollLimit(limit);
			}
		}
	}
}

// !LabelSetFontColor <label> <red> <green> <blue> OR !LabelSetFontColor <label> <hexcolor>
void BangSetFontColor(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16];
	char *buffers[] = {name, A, B, C};
	int numTokens = LCTokenize(pszArgs, buffers, 4, NULL);
	int color;

	if(numTokens >= 2)
	{
		if (stricmp(name, "xlabeldesktop") == 0)
		{
			for(LabelListIterator i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
			{
				if(numTokens >= 4)
				{
					int r = atoi(A);
					int g = atoi(B);
					int b = atoi(C);

					color = RGB(r, g, b);
				}
				else
				{
					color = strtol(A, NULL, 16);
					color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
				}

				(*i)->getFont()->setColor(color);
				(*i)->repaint();
			}
		}
		else
		{
			Label *label = lookupLabel(name);

			if (label)
			{
				if(numTokens >= 4)
				{
					int r = atoi(A);
					int g = atoi(B);
					int b = atoi(C);

					color = RGB(r, g, b);
				}
				else
				{
					color = strtol(A, NULL, 16);
					color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
				}

				label->getFont()->setColor(color);
				label->repaint();
			}
			else
			{
				LabelListIterator i;
				for( i = labelList.begin(); i != labelList.end(); i++)
				{
					if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
					{
						if(numTokens >= 4)
						{
							int r = atoi(A);
							int g = atoi(B);
							int b = atoi(C);

							color = RGB(r, g, b);
						}
						else
						{
							color = strtol(A, NULL, 16);
							color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
						}

						(*i)->getFont()->setColor(color);
						(*i)->repaint();
					}
				}
				for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
				{
					if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
					{
						if(numTokens >= 4)
						{
							int r = atoi(A);
							int g = atoi(B);
							int b = atoi(C);

							color = RGB(r, g, b);
						}
						else
						{
							color = strtol(A, NULL, 16);
							color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
						}

						(*i)->getFont()->setColor(color);
						(*i)->repaint();
					}
				}
			}
		}
	}
}

// !LabelSetText <label> <text>
void BangSetText(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], text[1024];
	char *buffers[] = {name, text};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
			label->setText((numTokens >= 2) ? text : "");
	}
}

// !LabelShow <label>
void BangShow(HWND hwndCaller, LPCSTR pszArgs)
{
	if (stricmp(pszArgs, "xlabeldesktop") == 0)
	{
		for(LabelListIterator i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
			(*i)->show();
	}
	else
	{
		Label *label = lookupLabel(pszArgs);
		if(label)
			label->show();
		else
		{
			LabelListIterator i;
			for( i = labelList.begin(); i != labelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
					(*i)->show();
			}
			for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
					(*i)->show();
			}
		}
	}
}

// !LabelShowHide <label> <timeout>
void BangShowHide(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[64];
	char *buffers[] = {name, A};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 2)
	{
		int timeout = atof(A);

		if (stricmp(name, "xlabeldesktop") == 0)
		{
			for(LabelListIterator i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
				(*i)->showHide(timeout);
		}
		else
		{
			Label *label = lookupLabel(name);

			if(label)
				label->showHide(timeout);
			else
			{
				LabelListIterator i;
				for( i = labelList.begin(); i != labelList.end(); i++)
				{
					if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
						(*i)->showHide(timeout);
				}
				for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
				{
					if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
						(*i)->showHide(timeout);
				}
			}
		}
	}
}

// !LabelToggleAlwaysOnTop <label>
void BangToggleAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->setAlwaysOnTop(!label->isAlwaysOnTop());
	else
	{
		LabelListIterator i;
		for( i = labelList.begin(); i != labelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setAlwaysOnTop(!(*i)->isAlwaysOnTop());
		}
		for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				(*i)->setAlwaysOnTop(!(*i)->isAlwaysOnTop());
		}
	}
}

// !LabelToggle <label>
void BangToggle(HWND hwndCaller, LPCSTR pszArgs)
{
	if (stricmp(pszArgs, "xlabeldesktop") == 0)
	{
		for(LabelListIterator i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
		{
			if((*i)->isVisible())
				(*i)->hide();
			else
				(*i)->show();
		}
	}
	else
	{
		Label *label = lookupLabel(pszArgs);
		if(label)
		{
			if(label->isVisible())
				label->hide();
			else
				label->show();
		}
		else
		{
			LabelListIterator i;
			for( i = labelList.begin(); i != labelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				{
					if((*i)->isVisible())
						(*i)->hide();
					else
						(*i)->show();
				}
			}
			for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
				{
					if((*i)->isVisible())
						(*i)->hide();
					else
						(*i)->show();
				}
			}
		}
	}
}

// !LabelUpdate <label>
void BangUpdate(HWND hwndCaller, LPCSTR pszArgs)
{
	if (stricmp(pszArgs, "xlabeldesktop") == 0)
	{
		for(LabelListIterator i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
			(*i)->update();
	}
	else
	{
		Label *label = lookupLabel(pszArgs);
		if(label)
			label->update();
		else
		{
			LabelListIterator i;
			for( i = labelList.begin(); i != labelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
					(*i)->update();
			}
			for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
					(*i)->update();
			}
		}
	}
}

// !LabelSetAlpha <label> <value>
void BangSetAlpha(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], factor[16];
	char *buffers[] = {name, factor};

	if(LCTokenize(pszArgs, buffers, 2, NULL) == 2)
	{
		if (stricmp(name, "xlabeldesktop") == 0)
		{
			for(LabelListIterator i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
				(*i)->setAlpha(atoi( factor ));
		}
		else
		{
			Label *label = lookupLabel(name);
			if(label)
				label->setAlpha(atoi( factor ));
			else
			{
				LabelListIterator i;
				for( i = labelList.begin(); i != labelList.end(); i++)
				{
					if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
						(*i)->setAlpha(atoi( factor ));
				}
				for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
				{
					if( stricmp((*i)->labelGroup.c_str(), name) == 0 )
						(*i)->setAlpha(atoi( factor ));
				}
			}
		}
	}
}

// !LabelToggleGhosted <label>
void BangToggleGhosted(HWND hwndCaller, LPCSTR pszArgs)
{
	if (stricmp(pszArgs, "xlabeldesktop") == 0)
	{
		for(LabelListIterator i = desktoplabelList.begin(); i != desktoplabelList.end(); i++)
			(*i)->setGhosted(!(*i)->isGhosted());
	}
	else
	{
		Label *label = lookupLabel(pszArgs);
		if(label)
			label->setGhosted(!label->isGhosted());
		else
		{
			LabelListIterator i;
			for( i = labelList.begin(); i != labelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
					(*i)->setGhosted(!(*i)->isGhosted());
			}
			for( i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
			{
				if( stricmp((*i)->labelGroup.c_str(), pszArgs) == 0 )
					(*i)->setGhosted(!(*i)->isGhosted());
			}
		}
	}
}

// !LabelAutoWidth <label> [<left|right|center|off>] //blank is off!!
void BangAdjustWidth(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], mode[32];
	char *buffers[] = {name, mode};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 1)
	{
		Label *label = lookupLabel(name);
		if(label)
		{
			if ( stricmp(mode, "left") == 0 )
				label->autoWidthMode = 1;
			else if ( stricmp(mode, "right") == 0 )
				label->autoWidthMode = 2;
			else if ( stricmp(mode, "center") == 0 || stricmp(mode, "centered") == 0)
				label->autoWidthMode = 3;
			else 
				label->autoWidthMode = 0;
			label->repaint();
		}
	}
}

// !LabelAutoHeight <label> [<top|bottom|center|off>] //blank is off!!
void BangAdjustHeight(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], mode[32];
	char *buffers[] = {name, mode};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 1)
	{
		Label *label = lookupLabel(name);
		if(label)
		{
			if ( stricmp(mode, "top") == 0 )
				label->autoHeightMode = 1;
			else if ( stricmp(mode, "bottom") == 0 )
				label->autoHeightMode = 2;
			else if ( stricmp(mode, "center") == 0 || stricmp(mode, "centered") == 0)
				label->autoHeightMode = 3;
			else 
				label->autoHeightMode = 0;
			label->repaint();
		}
	}
}


//TEXTEDIT 2.52 SECTION:
//=========================================================
// getToken grabs a token and clobbers info that is parsed
//=========================================================
void getToken(char line[4096], char temp[4096], bool escape_codes /* = true*/)
{
    int offset = 0, i;
	bool endquote = false;
    char ENCAP;

    ENCAP = '@';

	while (line[offset] == ' ')
	{
		offset++;
	}

	if (line[offset] == ENCAP)
	{
		offset++;
		endquote = true;
	}

	for (i = 0; i+offset < int(strlen(line)); ++i)
	{
		// Copy else if block to add more escape codes.
		if (escape_codes && (line[i+offset] == '\\' && int(strlen(line)) != i+offset+1))
		{
		    if (line[i+offset+1] == ENCAP || line[i+offset+1] == '\\')
			{
				offset++;
				temp[i] = line[i+offset];
				continue;
			}
			// Bang escape code below. Present in 2.0 from Tony Chang
			else if (line[i+offset+1] == '^')
			{
				offset++;
				temp[i] = '!';
				continue;
			}
			// EVar escape code below. Present in 2.0 from Tony Chang
			else if (line[i+offset+1] == '#')
			{
				offset++;
				temp[i] = '$';
				continue;
			}
			// Comment escape code below. Added in 2.1l by leaf r&d
			else if (line[i+offset+1] == '~')
			{
				offset++;
				temp[i] = ';';
				continue;
			}
			// Quotation mark escape code below. Added in 2.2l by leaf r&d
			else if (line[i+offset+1] == '=')
			{
				offset++;
                temp[i] = '"';
                continue;
            }
            // Clipboard escape code
            else if (line[i+offset+1] == 'c')
            {
				HGLOBAL hMem;
				LPVOID pvMem;

				if(IsClipboardFormatAvailable(CF_TEXT))
				{
					if(OpenClipboard(NULL))
					{
						hMem = GetClipboardData(CF_TEXT);

						if(hMem)
						{
							char pszBuffer[512];
							pvMem = GlobalLock(hMem);
							lstrcpyn(pszBuffer, (LPCTSTR) pvMem, 512);
							temp[i] = '\0';
							offset += min(strlen(pszBuffer), 512-strlen(temp));
							strncat(temp, pszBuffer, 512-strlen(temp));
							i = strlen(temp)+1;
							GlobalUnlock(hMem);
						}

						CloseClipboard();
					}
				}
            }
		}

 	    if (line[i+offset] == ENCAP && endquote)
	  	    break;
		else if (line[i+offset] == ' ' && !endquote)
			break;
		else
			temp[i] = line[i+offset];
	}
	temp[i] = '\0';

	if (i+offset+1 > int(strlen(line)))
	{
		line[0] = '\0';
	}
	else
	{
		strcpy(line, line+i+offset+1);
	}
}

//=========================================================
// Bang command handling
//=========================================================

void BangTextEdittextAppend(HWND hwndCaller, LPCSTR pszArgs)
{
	char filename[4096], str[4096];
	char rest[4096];
	strcpy(rest, pszArgs);

	getToken(rest, filename, false);
	getToken(rest, str, true);

	ofstream file;
	file.open(filename, /* ios::nocreate | */ ios::app);

	if (!file.fail())
	{
		file << str << endl;
	}

	file.close();
}

void BangTextEdittextDelete(HWND hwndCaller, LPCSTR pszArgs)
{
	char filename[4096], regex[4096], input[4096];
	char rest[4096];
	regexp *r;
	strcpy(rest, pszArgs);

	getToken(rest, filename, false);
	getToken(rest, regex, true);

	r = regcomp(regex);

	ifstream file;
	file.open(filename/*, ios::nocreate*/);        //removed because dev-cpp wont compile it... feel free to recompile to get it to work

	if (!file.fail())
	{
		list<string> l;
		string s;
		while (file.getline(input, 4096))
		{
			if (!regexec(r, input))
			{
				s = input;
				l.push_back(s);
			}
		}
		file.close();
		ofstream outfile;
		outfile.open(filename);
		for (list<string>::const_iterator lci = l.begin(); lci!=l.end(); lci++)
		{
			outfile << lci->data() << endl;
		}
		l.clear();
	}
}

void BangTextEdittextReplace(HWND hwndCaller, LPCSTR pszArgs)
{
	char filename[4096], regex[4096], input[4096], replace[4096];
	char rest[4096], buf[4096];
	regexp *r;
	strcpy(rest, pszArgs);

	getToken(rest, filename, false);
	getToken(rest, regex, true);
	getToken(rest, replace, true);

	r = regcomp(regex);

	ifstream file;
	file.open(filename/*, ios::nocreate*/);        //removed because dev-cpp wont compile it... feel free to recompile to get it to work

	if (!file.fail())
	{
		list<string> l;
		string s;
		while (file.getline(input, 4096))
		{
			if (regexec(r, input))
			{
				regsub(r, replace, buf);
				s = buf;
				l.push_back(buf);
			}
			else
			{
				s = input;
				l.push_back(input);
			}
		}
		file.close();
		ofstream outfile;
		outfile.open(filename);
		for (list<string>::const_iterator lci = l.begin(); lci!=l.end(); lci++)
		{
			outfile << lci->data() << endl;
		}
		l.clear();
	}
}

//Shortcut 2
void BangShortcutHide(HWND hwndCaller, LPCSTR pszArgs)
{	
	char group[4096];
	LPCSTR nextGroup = pszArgs;

	while (GetToken(nextGroup, group, &nextGroup, false))
	{
		for(LabelListIterator i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), group) == 0 || stricmp((*i)->labelGroup.c_str(), "*") == 0 )
				(*i)->hide();
		}
	}
}

void BangShortcutShow(HWND hwndCaller, LPCSTR pszArgs)
{
	char group[4096];
	LPCSTR nextGroup = pszArgs;

	while (GetToken(nextGroup, group, &nextGroup, false))
	{
		for(LabelListIterator i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), group) == 0 || stricmp((*i)->labelGroup.c_str(), "*") == 0 )
				(*i)->show();
		}
	}
}

void BangShortcutToggle(HWND hwndCaller, LPCSTR pszArgs)
{
	char group[4096];
	LPCSTR nextGroup = pszArgs;

	while (GetToken(nextGroup, group, &nextGroup, false))
	{
		for(LabelListIterator i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), group) == 0 || stricmp((*i)->labelGroup.c_str(), "*") == 0 )
			{
				if((*i)->isVisible())
					(*i)->hide();
				else
					(*i)->show();
			}
		}
	}
}

void BangShortcutOnTop(HWND hwndCaller, LPCSTR pszArgs)
{
	char group[4096];
	LPCSTR nextGroup = pszArgs;

	while (GetToken(nextGroup, group, &nextGroup, false))
	{
		for(LabelListIterator i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), group) == 0 || stricmp((*i)->labelGroup.c_str(), "*") == 0 )
				(*i)->setAlwaysOnTop(true);
		}
	}
}

void BangShortcutOnBottom(HWND hwndCaller, LPCSTR pszArgs)
{
	char group[4096];
	LPCSTR nextGroup = pszArgs;

	while (GetToken(nextGroup, group, &nextGroup, false))
	{
		for(LabelListIterator i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), group) == 0 || stricmp((*i)->labelGroup.c_str(), "*") == 0 )
				(*i)->setAlwaysOnTop(false);
		}
	}
}

void BangShortcutOnTopToggle(HWND hwndCaller, LPCSTR pszArgs)
{
	char group[4096];
	LPCSTR nextGroup = pszArgs;

	while (GetToken(nextGroup, group, &nextGroup, false))
	{
		for(LabelListIterator i = shortcutlabelList.begin(); i != shortcutlabelList.end(); i++)
		{
			if( stricmp((*i)->labelGroup.c_str(), group) == 0 || stricmp((*i)->labelGroup.c_str(), "*") == 0 )
				(*i)->setAlwaysOnTop(!(*i)->isAlwaysOnTop());
		}
	}
}
