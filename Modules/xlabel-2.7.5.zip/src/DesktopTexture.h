// DesktopTexture.h: interface for the DesktopTexture class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DESKTOPTEXTURE_H__DF589CF7_3C13_487E_A0B3_34ADA89C0C81__INCLUDED_)
#define AFX_DESKTOPTEXTURE_H__DF589CF7_3C13_487E_A0B3_34ADA89C0C81__INCLUDED_

#include "Texture.h"

class DesktopTexture : public Texture 
{
public:

	DesktopTexture();
	virtual ~DesktopTexture();

	void configure(const string &prefix, const string &subKey);
	void apply(HDC hDC, int x, int y, int width, int height, int imageType);
	void applyAnim(HDC hDC, int x, int y, int width, int height, int imageType, int count) { };

private:

	string GetShortcutTarget(const string LinkFileName);

	HDC memoryDC;
	HBITMAP memoryBitmap;

	HICON hIcon;

	string curName;

	int iconSize;
	int iconTextPosition;
	int iconTextSpacing;

	COLORREF iconTextBackground;
	COLORREF iconTextBackgroundLight;
	COLORREF iconTextBackgroundDark;

	int _saturation;
	int _hueIntensity;
	COLORREF _hueColor;
};

#endif // !defined(AFX_DESKTOPTEXTURE_H__DF589CF7_3C13_487E_A0B3_34ADA89C0C81__INCLUDED_)
