
#if !defined(AFX_SHORTCUTTEXTURE_H__475A4EF6_04DF_4515_8972_CAD443513885__INCLUDED_)
#define AFX_SHORTCUTTEXTURE_H__475A4EF6_04DF_4515_8972_CAD443513885__INCLUDED_

#include "Texture.h"

class ShortcutTexture : public Texture
{
public:
	ShortcutTexture();
	virtual ~ShortcutTexture();

	void configure(const string &images, const string &truetrans);
	void apply(HDC hDC, int x, int y, int width, int height, int imageType);
	void applyAnim(HDC hDC, int x, int y, int width, int height, int imageType, int count) { };

private:

	HBITMAP bitmap;
	HBITMAP hoverbitmap;
	HBITMAP pressedbitmap;

	HDC memoryDC;
	HBITMAP memoryBitmap;

	HDC memoryHoverDC;
	HBITMAP memoryHoverBitmap;

	HDC memoryPressedDC;
	HBITMAP memoryPressedBitmap;

	int imageHeight;
	int imageWidth;

	int hoverimageHeight;
	int hoverimageWidth;

	int pressedimageHeight;
	int pressedimageWidth;

	int leftEdge;
	int topEdge;
	int rightEdge;
	int bottomEdge;

	int mode;
};

#endif // !defined(AFX_SHORTCUTTEXTURE_H__475A4EF6_04DF_4515_8972_CAD443513885__INCLUDED_)
