popen  by tnl (tnl ta asia tod com)


Introduction:
    popen is a module for LiteStep that, like other popen implementations,
    lets you run a command-line command without showing a command prompt.

    The popen function itself was lifted from 
    http://home.mweb.co.za/sd/sdonovan/popen.zip


Installation/loading:
  classic:
    Put this somewhere in step.rc or its included files..

    LoadModule "x:\path to\the\popen.dll"

  NetLoadModule:

    *NetLoadModule popen-0.2


Usage:
    !popen <evar_name_for_return> <command>

    popen sets an evar to the command's return value.

  Example:
  
    !popen Goobly dir /B /ON /AD "$ThemesDir$">"$ConfigDir$themeslist.txt"
    
    - if the command succeeded, "$Goobly$" is "0"
    - if the command failed, "$Goobly$" is some other number


Versions:
    0.2: !popen now sets an evar to the command's return value
    0.1: initial version.
