MIDPOP README
Version 1.1 build 17 for LS 0.24.x - Jan 15, 1999
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

What is it?
-----------
MidPop is a small module for Litestep which allows you to use your
middle mouse button to display the popup menu anywhere on the screen.

How do I use it?
----------------
1. Extract MIDPOP11.ZIP in your Litestep (e.g. C:\LITESTEP) directory.
2. Add this line in your STEP.RC:

     loadModule C:\LITESTEP\MIDPOP.DLL

3. Reboot or recycle LS

Configuration
-------------
Note that these are all optional, but might be useful for fine tuning and
special cases.

First of all, you must add a new section called MidPop in MODULES.INI -
add this line:

  [MidPop]

Below this line you'll add the configuration option(s). Available options
are :

- Delay=nnn
  Default value : 175	
  Set the delay in milliseconds before MidPop decides you want to do 
  something else other than showing the popup. For example if you set
  Delay=500, the popup will only be displayed if you press and release
  the middle button within a half second time period. Normally you 
  would set it to how quickly you can click (i.e. press and release) the
  button. This delay is useful if you also use the middle button for
  scrolling page and prevent the popup from showing unintentionally when
  releasing the button.

- Exclusive=[0|1]
  Default value : 0	
  If set to 0, MidPop will let other programs see that you've clicked the
  middle button, otherwise it won't. Set this to 1 if you use program such
  as Pointix Scroll++ to provide scrolling function using the middle button.
  Leave it to 0 otherwise.

Example:

[MidPop]
Delay=200
Excusive=1

Notes
-----
I've only tested MidPop on Win95 with LS 0.24.x using the original
POPUP.DLL and Johan Redestig's POPUP.DLL. It should work fine on Win98
also. If you use NT, please e-mail me if you encounter any problem.
Thanks to Dan McMullen for idea, bug report and help testing it.

Contact
--------
Send comments, bug reports, ideas or just a plain "Hello" to

illusion@cryogen.com (Budyanto Nurhalim / StarQuake)