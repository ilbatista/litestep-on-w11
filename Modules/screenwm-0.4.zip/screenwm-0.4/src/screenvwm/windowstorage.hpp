#pragma once
#include <litestep/lsapi/lsapi.h>
#include <set>
using std::set;

class StorageArea
{
public:
	~StorageArea();
	
	RECT getRect();
	void storeRect(RECT &rect);
	void unstoreRect(RECT &rect);
	
private:
	friend class StorageManager;
	StorageArea(StorageManager *owner, int index, int x, int y);
	
	int index;
	StorageManager *owner;
	int x;
	int y;
};

class StorageManager
{
public:
	StorageManager();
	~StorageManager();
	
	StorageArea *getStorageArea();
	void releaseStorageArea(StorageArea *area);
	
private:
	int maxArea;
	set<int> unusedAreas;
};

