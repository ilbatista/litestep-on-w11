#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include <math.h>
#include <utility>
using std::swap;
#include "vwm.h"
#include "trace.hpp"

void VWM::initDesktops()
{
	// get the position and size of the main window
	// using different method if it's docked in the wharf
	if(inWharf)
	{
		RECT rc;
		int wharfBorder = GetRCInt("WharfBevelWidth", 1);

		// get the wharf window size
		GetClientRect(parentWindow, &rc); // FIXME: Possible order-of-initialization problem here
		
		windowX = wharfBorder;
		windowY = wharfBorder;
		windowWidth = rc.right - 2 * wharfBorder;
		windowHeight = rc.bottom - 2 * wharfBorder;
	}
	else
	{
		windowX = settings->panelX;
		windowY = settings->panelY;
		windowWidth = settings->panelWidth;
		windowHeight = settings->panelHeight;
	}
	
	int panelX = 0;
	int panelY = 0;
	
	// Start with only one desktop
	desktops.push_back(new VirtualDesktop(0, &storageManager));
	
	currentDesktop = desktops[0];
	lastDesktop = currentDesktop;
	desktops[0]->focused = true;
	
	updateTaskLists();
	tryLayouts();
}

VirtualDesktop::VirtualDesktop(int index, StorageManager *storageManager)
{
	layoutDone = false;
	this->index = index;
	focused = false;
	storage = storageManager->getStorageArea();
	numTasks = 0;
}

VirtualDesktop::~VirtualDesktop()
{
	delete storage;
}

string VirtualDesktop::getName()
{
	char buf[32];
	sprintf(buf, "Desktop %i", index+1);
	return buf;
}

string VirtualDesktop::getLabel()
{
	char buf[16];
	itoa(index+1, buf, 10);
	return buf;
}

void VWM::tryLayouts()
{
	bool layoutValid = false;
	layoutIndex = 0;
	
	// Start with a single-row layout. If that works (everything fits), stop
	// there. Otherwise, try a two-row layout, then a three-row layout, and
	// so on until we find one with enough space to fit everything.
	while(!layoutValid)
	{
		if(layoutIndex >= (int)settings->layoutSettings.size()) {
			LayoutSettings nextLayout = impliedLayoutFallback(*layoutSettings);
			settings->layoutSettings.push_back(nextLayout);
		}
		layoutSettings = &settings->layoutSettings[layoutIndex];
		
		layoutValid = doLayout();
		
		if(!layoutValid)
			layoutIndex++;
	}
	
	// Mark all desktops as having had their layout done
	for(unsigned ii=0; ii<desktops.size(); ii++)
		desktops[ii]->layoutDone = true;
}

bool VWM::doLayout()
{
	if((int)labelFonts.size() <= layoutIndex)
		labelFonts.push_back(loadLabelFont(layoutSettings));
	
	WrappingFlow flow(settings->flowDirection, 0, 0, settings->panelWidth, settings->panelHeight);
	
	float aspect = (float)screenWidth / screenHeight;
	
	int rowThickness;
	if(directionIsVertical(settings->flowDirection))
		rowThickness = settings->panelWidth / layoutSettings->panelRows;
	else
		rowThickness = settings->panelHeight / layoutSettings->panelRows;
	
	// Minimap dimensions - either use those given in LayoutSettings, or scale
	// down in an aspect-preserving way.
	float minimapMaxWidth, minimapMaxHeight;
	if(directionIsVertical(settings->flowDirection)) {
		minimapMaxWidth = rowThickness;
		minimapMaxHeight = rowThickness/aspect;
	} else {
		minimapMaxHeight = rowThickness;
		minimapMaxWidth = rowThickness*aspect;
	}
	int minimapWidth = layoutSettings->minimapWidth;
	int minimapHeight = layoutSettings->minimapHeight;
	if(minimapWidth > minimapMaxWidth) {
		minimapHeight = (minimapHeight*minimapWidth)/minimapMaxWidth;
		minimapWidth = (int)minimapMaxWidth;
	}
	if(minimapHeight > minimapMaxHeight) {
		minimapWidth = (minimapWidth*minimapHeight)/minimapMaxHeight;
		minimapHeight = (int)minimapMaxHeight;
	}
	
	int x, y;
	flow.start(x, y);
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		
		// First, calculate the size of the task-icons area
		desk->tasksIconArea = min(layoutSettings->tasksIconSize + 2*layoutSettings->tasksBorderThickness, rowThickness);
		desk->tasksIconSize = desk->tasksIconArea - 2*layoutSettings->tasksBorderThickness;
		desk->tasksNumRows = rowThickness / desk->tasksIconArea;
		desk->tasksNumCols = (desk->tasks.size() + desk->tasksNumRows - 1) / desk->tasksNumRows;
		if(directionIsVertical(settings->flowDirection))
			swap(desk->tasksNumRows, desk->tasksNumCols);
		
		desk->tasksWidth = desk->tasksNumCols * desk->tasksIconArea;
		desk->tasksHeight = desk->tasksNumRows * desk->tasksIconArea;
		
		// Use the size of the tasks area to determine the size of the panel as a whole
		if(directionIsVertical(settings->flowDirection)) {
			desk->panelWidth = rowThickness;
			desk->panelHeight = layoutSettings->deskBaseSize + desk->tasksHeight;
		} else {
			desk->panelHeight = rowThickness;
			desk->panelWidth = layoutSettings->deskBaseSize + desk->tasksWidth;
		}
		
		// Determine the location of the panel
		if(!flow.fit(x, y, desk->panelWidth, desk->panelHeight)) {
			// But if the panel didn't fit, return failure so tryLayouts()
			// will move on to the next set of layout settings.
			return false;
		}
		
		desk->panelX = x;
		desk->panelY = y;
		
		// Position the label
		desk->labelX = x + layoutSettings->labelOffsetX;
		desk->labelY = y + layoutSettings->labelOffsetY;
		if(layoutSettings->centerLabel) {
			string labelText = desk->getLabel();
			SIZE size;
			SelectObject(backBuffer, labelFonts[layoutIndex]);
			GetTextExtentPoint32(backBuffer, labelText.c_str(), labelText.length(), &size);
			
			desk->labelX -= size.cx/2;
			desk->labelY -= size.cy/2;
		}
		
		// Position the tasks
		desk->tasksX = x + layoutSettings->tasksOffsetX;
		desk->tasksY = y + layoutSettings->tasksOffsetY;
		
		// Position the minimap
		if(layoutSettings->hideMinimap) {
			desk->minimapWidth = 0;
			desk->minimapHeight = 0;
		} else {
			desk->minimapWidth = minimapWidth;
			desk->minimapHeight = minimapHeight;
			desk->minimapX = x + layoutSettings->minimapOffsetX;
			desk->minimapY = y + layoutSettings->minimapOffsetY;
		}
		
		// Advance to the position of the next panel
		flow.next(x, y, desk->panelWidth, desk->panelHeight);
	}
	
	return true;
}

void VWM::updateTaskLists()
{
	// Match tasks up to VWMs
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		desktops[ii]->tasks.clear();
	}
	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
	{
		WindowData *window = ii->second;
		
		if(!window->desk)
			continue;
		if(!window->isTask)
			continue;
		
		window->desk->tasks.push_back(window);
	}
	
	// If any desk has no tasks on it, delete it
	// But don't delete desks while dragging/dropping
	if(!draggingTask && !settings->keepEmptyDesktops)
	{
		for(unsigned ii=0; ii<desktops.size(); ii++)
		{
			if(!desktops[ii]->tasks.size()) {
				if(destroyDesktop(desktops[ii]))
					ii--;
			}
		}
	}
}

WindowData *VWM::taskFromPoint(int x, int y)
{
	VirtualDesktop *desk = panelPointToDesk(x, y);
	
	if(x<desk->tasksX || x>=desk->tasksX+desk->tasksWidth)
		return NULL;
	//if(y<desk->tasksY || y>=desk->tasksY+desk->tasksHeight)
	//	return NULL;
	
	int row = (y-desk->tasksY) / desk->tasksIconArea;
	int col = (x-desk->tasksX) / desk->tasksIconArea;
	int taskNum = directionCountSteps(settings->flowDirection, col, row, 0, 0,
		desk->tasksNumCols-1, desk->tasksNumRows-1, 1, 1);
	
	if(taskNum >= 0 && taskNum < (int)desk->tasks.size())
		return desk->tasks[taskNum];
	else
		return NULL;
	
	return NULL;
}

WindowData *VWM::findMinimapWindow(VirtualDesktop *desk, int x, int y)
{
	POINT pt = {x, y};
	
	for(vector<HWND>::iterator it = zOrder.begin(); it != zOrder.end(); it++)
	{
		if(windowsByHandle.find(*it) == windowsByHandle.end())
			continue;
		WindowData *windowData = windowsByHandle[*it];
		if(windowData->desk != desk)
			continue;
		RECT vwmRect;
		screenToMinimapPos(desk, windowData->screenPos, &vwmRect, NULL);
		
		if(PtInRect(&vwmRect, pt))
			return windowData;
	}
	return NULL;
}

void VWM::setScreenSize( int cx, int cy )
{
	screenWidth = cx;
	screenHeight = cy;
}

RECT VWM::getMaximizeArea()
{
	// TODO: Get maximize-area properly
	RECT ret;
		ret.left = GetRCCoordinate("SDALeft", 0, screenWidth);
		ret.top = GetRCCoordinate("SDATop", 0, screenHeight);
		ret.right = GetRCCoordinate("SDARight", screenWidth, screenWidth);
		ret.bottom = GetRCCoordinate("SDABottom", screenHeight, screenHeight);
		
		if(ret.right <= ret.left)
			ret.right = screenWidth;
		if(ret.bottom <= ret.top)
			ret.bottom = screenHeight;
	return ret;
}

void VWM::getDragDestination(
	RECT *outRect, VirtualDesktop **outDesk,
	WindowData *window, POINT clickOffset, int mouseX, int mouseY)
{
	VirtualDesktop *desk;
	bool maximized = GetWindowLong(window->handle, GWL_STYLE) & WS_MAXIMIZE;
	
	desk = panelPointToDesk(mouseX, mouseY);
	if(!desk) {
		// If drag is into new (non-desk) area where a desk panel could be,
		// and there has not already been a new desk created as a result of
		// this drag, create a new desktop and drag onto it.
		if(!settings->dragCreatesDesks) {
			return;
		}
		if(mouseX < 0 || mouseY < 0 || mouseX >= settings->panelWidth || mouseY >= settings->panelHeight) {
			return;
		}
		if(dragCreatedDesk)
			return;
		trace << "getDragDestination creating a new desk where mouseX="<<mouseX<<", mouseY="<<mouseY<<".\n";
		desk = dragCreatedDesk = new VirtualDesktop(desktops.size(), &storageManager);
		desktops.push_back(desk);
	}
	*outDesk = desk;
	
	if(mouseX < desk->minimapX || mouseY < desk->minimapY
	   || mouseX >= desk->minimapX+desk->minimapWidth
	   || mouseY >= desk->minimapY+desk->minimapHeight)
	{
		// Leave outRect as-is if outside a minimap
	}
	else if(maximized)
	{
		*outRect = window->screenPos;
		if(!window->desk->focused) {
			window->desk->storage->unstoreRect(*outRect);
		}
	} else {
		int width = window->screenPos.right - window->screenPos.left;
		int height = window->screenPos.bottom - window->screenPos.top;
		RECT maximizeArea = getMaximizeArea();
		
		POINT topLeft = minimapToScreenPos(desk, mouseX-clickOffset.x, mouseY-clickOffset.y);
		if(topLeft.x < maximizeArea.left)
			topLeft.x = maximizeArea.left;
		if(topLeft.y < maximizeArea.top)
			topLeft.y = maximizeArea.top;
		if(topLeft.x + width > maximizeArea.right)
			topLeft.x = maximizeArea.right - width;
		if(topLeft.y + height > maximizeArea.bottom)
			topLeft.y = maximizeArea.bottom - height;
		outRect->left = topLeft.x;
		outRect->top = topLeft.y;
		outRect->right = outRect->left + width;
		outRect->bottom = outRect->top + height;
	}
}

RECT VWM::getGatherTarget(RECT source)
{
	RECT ret = source;
		RECT maximizeArea = getMaximizeArea();
	int maximizeWidth = maximizeArea.right - maximizeArea.left;
	int maximizeHeight = maximizeArea.bottom - maximizeArea.top;
	
	// If this is inside a VWM's storage area, first bring it in
	VirtualDesktop *desk = deskFromLocation(source);
	if(desk && !desk->focused)
		desk->storage->unstoreRect(ret);
	
	// TODO: Get the window-maximize region, rather than using (0,0,w,h).
	
	int width  = source.right  - source.left;
	int height = source.bottom - source.top;
	int offsetX=0;
	int offsetY=0;
	
	// If a window is wider or taller than the screen, center it. Otherwise,
	// match an edge. (This happens more often than you'd think, because
	// maximized windows are a few pixels bigger than the maximize-area so
	// that their borders fall offscreen.)
	if(width > maximizeWidth) {
		if(ret.left > maximizeArea.left || ret.right < maximizeArea.right)
			ret.left = maximizeArea.left - (width-maximizeWidth)/2;
	} else if(ret.right > maximizeWidth) {
		ret.left += maximizeWidth-ret.right;
	} else if(ret.left < maximizeArea.left) {
		ret.left = maximizeArea.left;
	}
	
	if(height > maximizeHeight) {
		if(ret.top > maximizeArea.top || ret.bottom < maximizeArea.bottom)
			ret.top = maximizeArea.top - (height-maximizeHeight)/2;
	} else if(ret.bottom > maximizeArea.bottom) {
		ret.top += maximizeArea.bottom - ret.bottom;
	} else if(ret.top < maximizeArea.top) {
		ret.top = maximizeArea.top;
	}
	
	ret.right = ret.left + width;
	ret.bottom = ret.top + height;
	return ret;
}

void VWM::screenToMinimapPos(VirtualDesktop *desk, RECT screenPos, RECT *minimapPos, POINT *iconPos)
{
	if(!desk)
		desk = currentDesktop;
	
	// Translate it so it's placed as if it was the focused desktop
	if(!desk->focused)
		desk->storage->unstoreRect(screenPos);
	
	RECT maximizeArea = getMaximizeArea();
	
	// Promote to float for intermediate calculations;
	float left, right, top, bottom;
	left   = (float)screenPos.left - maximizeArea.left;
	right  = (float)screenPos.right - maximizeArea.left;
	top    = (float)screenPos.top - maximizeArea.top;
	bottom = (float)screenPos.bottom - maximizeArea.top;
	
	// Scale it to minimap size
	left   *= (float)desk->minimapWidth  / (maximizeArea.right-maximizeArea.left);
	right  *= (float)desk->minimapWidth  / (maximizeArea.right-maximizeArea.left);
	top    *= (float)desk->minimapHeight / (maximizeArea.bottom-maximizeArea.top);
	bottom *= (float)desk->minimapHeight / (maximizeArea.bottom-maximizeArea.top);
	
	if(left < 0)
		left = 0;
	if(top < 0)
		top = 0;
	if(right > desk->minimapWidth)
		right = desk->minimapWidth;
	if(bottom > desk->minimapHeight)
		bottom = desk->minimapHeight;
	
	if(minimapPos)
	{
		minimapPos->left   = (long)left;
		minimapPos->right  = (long)right;
		minimapPos->top    = (long)top;
		minimapPos->bottom = (long)bottom;
	}
	
	if(iconPos)
	{
		iconPos->x = (left+right)/2 - settings->minimapIconSize/2;
		iconPos->y = (top+bottom)/2 - settings->minimapIconSize/2;
	}
}

POINT VWM::minimapToScreenPos(VirtualDesktop *desk, int x, int y)
{
	POINT ret;
	RECT maximizeArea = getMaximizeArea();
	
	ret.x = (x - desk->minimapX) * ((float)(maximizeArea.right-maximizeArea.left) / desk->minimapWidth);
	ret.y = (y - desk->minimapY) * ((float)(maximizeArea.bottom-maximizeArea.top) / desk->minimapHeight);
	ret.x += maximizeArea.left;
	ret.y += maximizeArea.top;
	return ret;
}

bool RectOverlap(RECT a, RECT b)
{
	return b.left <= a.right && a.left <= b.right
	     && a.top <= b.bottom && b.top <= a.bottom;
}

VirtualDesktop *VWM::deskFromLocation(RECT pos)
{
	int centerX = (pos.left+pos.right)/2;
	int centerY = (pos.top+pos.bottom)/2;
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		if(desk->focused) {
			RECT screenRect;
				screenRect.left = 0;
				screenRect.top = 0;
				screenRect.right = screenWidth;
				screenRect.bottom = screenHeight;
			if(RectOverlap(screenRect, pos))
				return desk;
		} else {
			if(RectOverlap(desk->storage->getRect(), pos))
				return desk;
		}
	}
	
	return NULL;
}

VirtualDesktop *VWM::panelPointToDesk(int x, int y)
{
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		if(x >= desk->panelX && y >= desk->panelY
		   && x <= desk->panelX+desk->panelWidth
		   && y <= desk->panelY+desk->panelHeight)
			return desk;
	}
	
	return NULL;
}

RECT VirtualDesktop::getMinimapRect()
{
	RECT ret;
		ret.left   = minimapX;
		ret.top    = minimapY;
		ret.right  = minimapX + minimapWidth;
		ret.bottom = minimapY + minimapHeight;
	return ret;
}