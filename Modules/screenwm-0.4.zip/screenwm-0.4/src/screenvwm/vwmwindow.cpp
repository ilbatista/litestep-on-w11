#include <litestep/lsapi/lsapi.h>
#include "vwm.h"
#include "trace.hpp"

static const char *vwmWindowClassname = "screenvwm_VWMWindow";
static const char *vwmWindowName = "ScreenVWM";
static WNDCLASSEX windowClass;

struct CreationData
{
	SHORT cbExtra;
	VWM* window;
};
// This unaligned-CreationData business comes from LiteStep. I see no reason
// why Windows would pass one of these without aligning it on a 4-byte boundary
// (that'd be pretty silly), but someone judged it necessary so I'm leaving it.
//  --Jim
typedef UNALIGNED CreationData UACreationData;

const unsigned int GWL_CLASSPOINTER = 0;

bool VWM::createWindow()
{
	registerWindowClass();
	
	UACreationData creationData = {sizeof(UACreationData), this};
	vwmWindow = CreateWindowEx(
		WS_EX_TOOLWINDOW,
		vwmWindowClassname,
		vwmWindowName,
		inWharf?WS_CHILD:WS_POPUP,
		windowX, windowY, windowWidth, windowHeight,
		parentWindow,
		NULL, dllInstance, &creationData);
	if (!vwmWindow)
	{
		MessageBox(NULL, "Unable to create VWM window.", vwmWindowName, MB_TOPMOST);
		return false;
	}
	
	// Mark this window as 'belonging to Litestep' so that we don't try to operate on ourself
	SetWindowLong(vwmWindow, GWL_USERDATA, magicDWord);

	return true;
}

void VWM::destroyWindow()
{
	if(vwmWindow)
		DestroyWindow(vwmWindow);
	unregisterWindowClass();
}

void VWM::registerWindowClass()
{
	memset(&windowClass, 0, sizeof(WNDCLASSEX));
	windowClass.cbSize = sizeof(WNDCLASSEX);
	windowClass.cbWndExtra = sizeof(VWM*);
	windowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	windowClass.lpfnWndProc = VWM::wndProc;
	windowClass.hInstance = dllInstance;
	windowClass.lpszClassName = vwmWindowClassname;

	if (!RegisterClassEx(&windowClass))
	{
		// Class could not be registered, try to re-register
		UnregisterClass(vwmWindowClassname, dllInstance);

		if (!RegisterClassEx(&windowClass))
		{
			// Still no luck, error out
			MessageBox(NULL, "Unable to register window class.", vwmWindowClassname,
			           MB_ICONEXCLAMATION | MB_TOPMOST);
			throw;
		}
	}
}

void VWM::unregisterWindowClass()
{
	UnregisterClass(vwmWindowClassname, dllInstance);
}

LRESULT CALLBACK VWM::wndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message = { 0 };
	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	
	VWM *window = NULL;

	if (uMsg == WM_CREATE)
	{
		LPVOID & createParams = LPCREATESTRUCT(lParam)->lpCreateParams;

		if (createParams)
		{
			window = ((UACreationData*)(createParams))->window;
			SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)window);
		}
	}
	else
		window = (VWM*)(GetWindowLong(hWnd, GWL_CLASSPOINTER));

	if (window)
	{
		if (uMsg == WM_CREATE)
			window->vwmWindow = hWnd;
		window->windowProc(message);
		if (uMsg == WM_NCDESTROY)
			window->vwmWindow = NULL;
		return message.lResult;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void VWM::toggle()
{
	settings->visible = !settings->visible;
	ShowWindow(vwmWindow, settings->visible?SW_SHOWNOACTIVATE:SW_HIDE );
}

void VWM::show()
{
	settings->visible = TRUE;
	ShowWindow(vwmWindow, SW_SHOWNOACTIVATE);
}

void VWM::hide()
{
	settings->visible = FALSE;
	ShowWindow(vwmWindow, SW_HIDE);
}


static DWORD ModifyStyle(HWND window, DWORD dwRemove, DWORD dwAdd)
{
	DWORD dwStyle = (DWORD) GetWindowLong(window, GWL_STYLE);
	SetWindowLong(window, GWL_STYLE, (dwStyle & ~dwRemove) | dwAdd);
	return dwStyle;
}

void VWM::ontopToggle()
{
	settings->onTop = !settings->onTop;

	HWND desktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktop)
		desktop = GetDesktopWindow();

	ModifyStyle(vwmWindow, WS_POPUP, WS_CHILD);
	SetParent(vwmWindow, settings->onTop ? NULL : desktop);
	ModifyStyle(vwmWindow, WS_CHILD, WS_POPUP);

	SetWindowPos(vwmWindow, settings->onTop ? HWND_TOPMOST : HWND_NOTOPMOST,
        0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOSENDCHANGING);
}
