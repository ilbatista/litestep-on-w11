#include "vwm.h"
#include "trace.hpp"

void VWM::beginWindowDrag(WindowData *window, bool draggingLocation, POINT click, POINT clickOffset)
{
	draggingTask = window->handle;
	dragSourceDesk = window->desk;
	dragSourceRect = window->screenPos;
	this->draggingLocation = draggingLocation;
	dragCreatedDesk = NULL;
	
	if(!window->desk->focused)
		window->desk->storage->unstoreRect(dragSourceRect);
	
	// get the distance between the clicked point and the
	// top-left corner of the clicked window
	RECT vwmRect;
	screenToMinimapPos(window->desk, window->screenPos, &vwmRect, NULL);
	diffPt = clickOffset;
	
	if(settings->switchDeskWithDrag)
		switchDesk(dragSourceDesk, false);
	
	forceRedraw(true);
	
	createDragIcon(
		click.x + windowX, click.y + windowY,
		window->getIcon(layoutSettings->tasksIconSize));
}

void VWM::continueWindowDrag(int mouseX, int mouseY)
{
	if(!draggingTask)
		return;
	
	if(windowsByHandle.find(draggingTask) == windowsByHandle.end()) {
		draggingTask = NULL;
		return;
	}
	WindowData *windowData = windowsByHandle[draggingTask];
	
	RECT newPos = dragSourceRect;
	VirtualDesktop *newDesk = windowData->desk;
	getDragDestination(&newPos, &newDesk, windowData, diffPt, mouseX, mouseY);
	
	beginMovingWindows();
	
	// When dragging a window between desks, bring along the rest of its
	// task group
	if(windowData->desk != newDesk)
	{
		set<WindowData*> windows;
		getTaskGroup(windowData, &windows);
		
		for(set<WindowData*>::iterator ii=windows.begin(); ii!=windows.end(); ii++) {
			if(*ii != windowData) {
				moveWindow(*ii, newDesk);
			}
		}
	}
	
	// Adjust desktop and (maybe) desktop of the dragged window
	if(draggingLocation) {
		moveWindow(windowData, newPos, newDesk);
	} else if(windowData->desk != newDesk) {
		moveWindow(windowData, newDesk);
		
		// FIXME: This brings the window off-screen then back on
		if(settings->switchDeskWithDrag)
			switchDesk(newDesk);
	}
	
	finishMovingWindows();
	
	forceRedraw(true);
}

void VWM::endDrag()
{
	destroyDragIcon();
	if(!draggingTask)
		return;
	
	WindowData *windowData = windowsByHandle[draggingTask];
	draggingTask = NULL;
	dragSourceDesk = NULL;
	dragCreatedDesk = NULL;
	
	forceRedraw(false);
}


struct DragWindowCreationData
{
	SHORT cbExtra;
	VWM *ownerVWM;
};
typedef UNALIGNED DragWindowCreationData UADragWindowCreationData;

const unsigned int GWL_CLASSPOINTER = 0;


void VWM::createDragIconClass()
{
	WNDCLASSEX windowClass;
	memset(&windowClass, 0, sizeof(WNDCLASSEX));
	windowClass.cbSize = sizeof(WNDCLASSEX);
	windowClass.cbWndExtra = sizeof(HICON);
	windowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	windowClass.lpfnWndProc = dragIconWindowProc;
	windowClass.hInstance = dllInstance;
	windowClass.lpszClassName = "screenwm_dragicon";
	
	RegisterClassEx(&windowClass);
}

void VWM::destroyDragIconClass()
{
	UnregisterClass("screenwm_dragicon", dllInstance);
}

void VWM::createDragIcon(int centerX, int centerY, HICON icon)
{
	dragIcon = icon;
	dragIconSize = layoutSettings->tasksIconSize;
	
	if(dragIconWnd) {
		return;
	}
	
	UADragWindowCreationData creationData = {sizeof(UADragWindowCreationData), this};
	
	dragIconWnd = CreateWindowEx(
		WS_EX_TOPMOST | WS_EX_LAYERED,
		"screenwm_dragicon", "screenwm_dragicon",
		WS_POPUP | WS_VISIBLE,
		centerX - dragIconSize/2, centerY - dragIconSize/2,
		layoutSettings->tasksIconSize, layoutSettings->tasksIconSize,
		vwmWindow, (HMENU)NULL, dllInstance, &creationData);
	SendMessage(dragIconWnd, LM_BRINGTOFRONT, 0, (LPARAM)dragIconWnd);
}

void VWM::destroyDragIcon()
{
	if(dragIconWnd) {
		ShowWindow(dragIconWnd, SW_HIDE);
		DestroyWindow(dragIconWnd);
		dragIconWnd = NULL;
	}
}

LRESULT CALLBACK dragIconWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	HICON icon = (HICON)lParam;
	VWM *ownerVWM = NULL;

	if (uMsg == WM_CREATE) {
		LPVOID &createParams = LPCREATESTRUCT(lParam)->lpCreateParams;

		if (createParams) {
			ownerVWM = ((DragWindowCreationData*)(createParams))->ownerVWM;
			SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)ownerVWM);
		}
	}
	else
		ownerVWM = (VWM*)(GetWindowLong(hWnd, GWL_CLASSPOINTER));
	
	switch(uMsg)
	{
		case WM_CREATE: {
			HDC drawContext = CreateCompatibleDC(vwm->backBuffer);
			HBITMAP bmp = CreateCompatibleBitmap(vwm->backBuffer, ownerVWM->dragIconSize, ownerVWM->dragIconSize);
			SelectObject(drawContext, bmp);
			
			DrawIconEx(drawContext, 0, 0, ownerVWM->dragIcon,
				ownerVWM->dragIconSize, ownerVWM->dragIconSize, 0, NULL, DI_NORMAL);
			
			COLORREF transparentColor = GetRCColor("swmIconTransparentColor", 0xff00ff);
			POINT location = {0,0};
			SIZE size = {ownerVWM->dragIconSize, ownerVWM->dragIconSize};
			
			UpdateLayeredWindow(
				hWnd, NULL, NULL, &size, drawContext, &location,
				0, NULL, ULW_COLORKEY
				);
			
			SetTimer(hWnd, 2, 50, NULL);
			break;
		}
		
		case WM_LBUTTONUP:
		case WM_RBUTTONUP:
		case WM_MBUTTONUP: {
			Message msg;
				msg.uMsg = uMsg;
				msg.wParam = wParam;
				msg.lParam = lParam;
			ownerVWM->onMouseButtonUp(msg);
			ownerVWM->destroyDragIcon();
			break;
		}
		
		case WM_TIMER: {
			POINT pos;
			GetCursorPos(&pos);
			
			ownerVWM->onMouseMove(pos.x, pos.y);
			
			SetWindowPos(hWnd, NULL,
				pos.x - ownerVWM->layoutSettings->tasksIconSize/2,
				pos.y - ownerVWM->layoutSettings->tasksIconSize/2,
				0, 0, SWP_NOZORDER|SWP_NOSIZE|SWP_NOACTIVATE);
		}
	}
	
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
