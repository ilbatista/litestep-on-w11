#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include <math.h>
#include "vwm.h"
#include "rcsettings.hpp"
#include "trace.hpp"
#pragma warning (disable: 4800)

static vector<LayoutSettings> layoutSettings;
static RCSettings settings;

LayoutSettings::LayoutSettings(RCSettings *baseSettings)
{
	// Defaults
	panelRows = 1;
	tasksIconSize = 32;
	tasksBorderThickness = 1;
	
	labelFont = "Microsoft Sans Serif";
	labelFontSize = 20;
	centerLabel = true;
	
	hideMinimap = false;
	float aspect = (float)SCREEN_WIDTH / (float)SCREEN_HEIGHT;
	
	if(directionIsVertical(baseSettings->flowDirection))
	{
		minimapWidth = baseSettings->panelWidth;
		minimapHeight = floor(minimapWidth/aspect + 0.5);
		
		labelOffsetX = baseSettings->panelWidth/2;
		labelOffsetY = 15;
		
		deskBaseSize = minimapHeight+labelOffsetY/2 + 40;
		
		minimapOffsetX = 0;
		minimapOffsetY = 30;
		tasksOffsetX = 1;
		tasksOffsetY = minimapOffsetY+minimapHeight;
	}
	else
	{
		minimapHeight = baseSettings->panelHeight;
		minimapWidth = floor(minimapHeight*aspect + 0.5);
		
		labelOffsetX = 10;
		labelOffsetY = baseSettings->panelHeight/2;
		
		deskBaseSize = minimapWidth+labelOffsetX/2 + 30;
		
		minimapOffsetX = 20;
		minimapOffsetY = 0;
		tasksOffsetX = minimapOffsetX+minimapWidth;
		tasksOffsetY = 1;
	}
}

LayoutSettings::LayoutSettings(LayoutSettings *defaults, int fallbackIndex)
{
	char suffixBuf[64];
	if(fallbackIndex > 1)
		sprintf(suffixBuf, "%i", fallbackIndex);
	else
		*suffixBuf = 0;
	suffix = suffixBuf;
	hasNonDefault = false;
	
	panelRows            = getInt("swmPanelNumRows",         defaults->panelRows);
	tasksIconSize        = getInt("swmTasksIconSize",        defaults->tasksIconSize);
	tasksBorderThickness = getInt("swmTasksBorderThickness", defaults->tasksBorderThickness);
	
	labelFont         = getString("swmLabelFont",            defaults->labelFont);
	labelFontSize        = getInt("swmLabelFontSize",        defaults->labelFontSize);
	centerLabel         = getBool("swmLabelCentered", TRUE,  defaults->centerLabel);
	
	hideMinimap         = getBool("swmHideMinimap", TRUE,    defaults->hideMinimap);
	
	minimapWidth         = getInt("swmMinimapWidth",         defaults->minimapWidth);
	minimapHeight        = getInt("swmMinimapHeight",        defaults->minimapHeight);
	
	deskBaseSize         = getInt("swmDeskBaseSize",         defaults->deskBaseSize);
	labelOffsetX         = getInt("swmLabelOffsetX",         defaults->labelOffsetX);
	labelOffsetY         = getInt("swmLabelOffsetY",         defaults->labelOffsetY);
	minimapOffsetX       = getInt("swmMinimapOffsetX",       defaults->minimapOffsetX);
	minimapOffsetY       = getInt("swmMinimapOffsetY",       defaults->minimapOffsetY);
	tasksOffsetX         = getInt("swmTasksOffsetX",         defaults->tasksOffsetX);
	tasksOffsetY         = getInt("swmTasksOffsetY",         defaults->tasksOffsetY);
}

int LayoutSettings::getInt(const char *title, int defaultValue)
{
	char varname[256];
	strcpy(varname, title);
	strcat(varname, suffix);
	
	char ignored;
	if(LSGetVariableEx(varname, &ignored, 0))
		hasNonDefault = true;
	
	return GetRCInt(varname, defaultValue);
}

string LayoutSettings::getString(const char *title, const string &defaultValue)
{
	char varname[256];
	strcpy(varname, title);
	strcat(varname, suffix);
	
	char ignored;
	if(LSGetVariableEx(varname, &ignored, 0))
		hasNonDefault = true;
	
	char buf[4096];
	GetRCString(varname, buf, defaultValue.c_str(), 4096);
	return buf;
}

bool LayoutSettings::getBool(const char *title, BOOL valueIfFound, bool defaultValue)
{
	char varname[256];
	strcpy(varname, title);
	strcat(varname, suffix);
	
	char ignored;
	if(LSGetVariableEx(varname, &ignored, 0))
		hasNonDefault = true;
	
	bool found = GetRCBool(varname, true);
	if(found)
		return valueIfFound;
	else
		return defaultValue;
}

LayoutSettings impliedLayoutFallback(const LayoutSettings &last)
{
	LayoutSettings ret(last);
	ret.panelRows++;
	return ret;
}

RCSettings::~RCSettings()
{
}

void RCSettings::refresh(bool inWharf)
{
	char buf[512];
	
	// Position
	panelX = GetRCCoordinate("swmX", 0, GetSystemMetrics(SM_CXSCREEN));
	panelY = GetRCCoordinate("swmY", 0, GetSystemMetrics(SM_CYSCREEN));
	panelWidth = GetRCCoordinate("swmWidth", 64, GetSystemMetrics(SM_CXSCREEN));
	panelHeight = GetRCCoordinate("swmHeight", 320, GetSystemMetrics(SM_CYSCREEN));
	
	// Window tracking settings
	pollInterval = GetRCInt("swmPollInterval", 500);
	if(pollInterval && pollInterval < 10) pollInterval = 10;
	
	// Behavior settings
	switchDeskWithDrag = GetRCBoolDef("swmSwitchDeskWithDrag", TRUE);
	keepEmptyDesktops = GetRCBoolDef("swmKeepEmptyDesktops", FALSE);
	dragCreatesDesks = GetRCBoolDef("swmDragCreatesDesks", TRUE);
	minimizeOnClick = GetRCBoolDef("swmMinimizeOnClick", TRUE);
	
	// VWM display settings
	if(GetRCBool("swmNoTitleBars", FALSE))
		minimapTitleBarsThickness = GetRCInt("swmMinimapTitleBarThickness", 4);
	else
		minimapTitleBarsThickness = 0;
	
	minimapIconSize = (GetRCBoolDef("swmMinimapIcons", TRUE)) ? GetRCInt("swmMinimapIconSize", 16) : 0;
	
	// Task display settings
	const char *defaultFlowDirection = (panelWidth >= panelHeight) ? "right" : "down";
	GetRCLine("swmTasksFlowDirection", buf, 512, defaultFlowDirection);
	flowDirection = directionFromString(buf);
	
	tasksOffsetX = GetRCInt("swmTasksIconOffsetX", 0);
	tasksOffsetY = GetRCInt("swmTasksIconOffsetY", 0);
	tasksOffsetXMin = GetRCInt("swmTasksIconOffsetXMin", 0);
	tasksOffsetYMin = GetRCInt("swmTasksIconOffsetYMin", 12);
	tasksOffsetXFocused = GetRCInt("swmTasksIconOffsetXFocused", 0);
	tasksOffsetYFocused = GetRCInt("swmTasksIconOffsetYFocused", 0);
	tasksIconTransparent = GetRCBoolDef("swmTasksIconTransparent", TRUE);
	tasksIconTransparentFocused = GetRCBoolDef("swmTasksIconTransparentFocused", TRUE);
	tasksIconTransparentMin = GetRCBoolDef("swmTasksIconTransparentMin", TRUE);
	
	// Visibility settings
	visible = inWharf || GetRCBool("swmHidden", FALSE); // renamed from vwmNoShow
	onTop = !inWharf && GetRCBool("swmAlwaysOnTop", TRUE);
	if(inWharf && GetRCBool("swmAutoHide", TRUE))
		autoHideDistance = GetRCInt("swmAutoHideDistance", 10);
	else
		autoHideDistance = 0;
	
	// Color settings
	panelBackgroundColor    = GetRCColor("swmPanelColor",                  0xaaaaaa);
	panelBorderColor        = GetRCColor("swmPanelBorderColor",            panelBackgroundColor);
	vwmBackgroundColor      = GetRCColor("swmMinimapBackColor",            0x808080);
	vwmWindowColor          = GetRCColor("swmMinimapWinColor",             0xffffff);
	vwmTitleBarColor        = GetRCColor("swmMinimapTitleBarColor",        0x505050);
	vwmFocusedTitleBarColor = GetRCColor("swmMinimapFocusedTitleBarColor", 0xff0000);
	vwmBorderColor          = GetRCColor("swmMinimapBorderColor",          0x000000);
	vwmWindowBorderColor    = GetRCColor("swmMinimapWinBorderColor",       0x000000);
	tasksBackColor          = GetRCColor("swmTasksBackColor",              panelBackgroundColor);
	tasksBackColorMin       = GetRCColor("swmTasksBackColorMin",           panelBackgroundColor);
	tasksBackColorFocused   = GetRCColor("swmTasksBackColorFocused",       0x555555);
	tasksBorderColor        = GetRCColor("swmTasksBorderColor",            panelBackgroundColor);
	tasksBorderColorMin     = GetRCColor("swmTasksBorderColorMin",         panelBackgroundColor);
	tasksBorderColorFocused = GetRCColor("swmTasksBorderColorFocused",     0x000000);
	labelColor              = GetRCColor("swmLabelColor",                  0x000000);
	labelColorFocused       = GetRCColor("swmLabelColorFocused",           labelColor);
	
	// Layout settings
	layoutSettings.clear();
	LayoutSettings defaults(this);;
	for(int ii=0; ; ii++) {
		LayoutSettings *prev = (ii>0) ? &layoutSettings[ii-1] : &defaults;
		LayoutSettings next(prev, ii+1);
		if(ii && !next.hasNonDefault)
			break;
		layoutSettings.push_back(next);
	}
}
