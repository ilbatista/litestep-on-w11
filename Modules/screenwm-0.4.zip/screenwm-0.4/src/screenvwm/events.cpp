#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include "vwm.h"
#include "trace.hpp"

static const int litestepMessageTypes[] = {
	LM_GETREVID,
	LM_BRINGTOFRONT,
	LM_SWITCHTON,
	LM_WINDOWACTIVATED,
	LM_LISTDESKTOPS,
	LM_GETDESKTOPOF,
	LM_WINDOWCREATED,
	LM_WINDOWDESTROYED,
	LM_REPAINT,
	0
};

//=========================================================
// Message handling
//=========================================================
void VWM::registerEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)litestepMessageTypes);
}

void VWM::unregisterEventHandlers()
{
	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)litestepMessageTypes);
}

void VWM::windowProc(Message& message)
{
	switch (message.uMsg)
	{
		case WM_CREATE:            onCreate         (message); break;
		case WM_DESTROY:           onDestroy        (message); break;
		case WM_LBUTTONDOWN:       onMouseButtonDown(message); break;
		case WM_MBUTTONDOWN:       onMouseButtonDown(message); break;
		case WM_RBUTTONDOWN:       onMouseButtonDown(message); break;
		
		case WM_LBUTTONUP: //FALLTHRU
		case WM_MBUTTONUP: //FALLTHRU
		case WM_RBUTTONUP:
			onMouseButtonUp(message);
			break;
		
		case WM_MOUSEMOVE:
			onMouseMove(message.lParamLo+windowX, message.lParamHi+windowY);
			break;
		
		case WM_PAINT:             onPaint          (message); break;
		case WM_SYSCOMMAND:        onSysCommand     (message); break;
		case WM_TIMER:             onTimer          (message); break;
		case WM_DROPFILES:         onDropFiles      (message); break;
		case WM_WINDOWPOSCHANGING: onVWMPosChanging (message); break;
		
		case WM_DISPLAYCHANGE:
			setScreenSize(message.lParamLo, message.lParamHi);
			break;
		
		case WM_KEYDOWN:
		case WM_KEYUP:
		case WM_HOTKEY:
			PostMessage(parentWindow, message.uMsg, message.wParam, message.lParam);
			break;
			
		case WM_ENDSESSION:
		case WM_QUERYENDSESSION:
			message.lResult = SendMessage(parentWindow, message.uMsg, message.wParam, message.lParam);
			break;
		
		case LM_GETREVID:          onGetRevId       (message); break;
		case LM_REPAINT:           onPaint          (message); break;
		case LM_WINDOWACTIVATED:   onWindowActivated(message); break;
		case LM_BRINGTOFRONT:      onBringToFront   (message); break;
		case LM_SWITCHTON:         onSwitchToN      (message); break;
		case LM_LISTDESKTOPS:      onListDesktops   (message); break;
		case LM_GETDESKTOPOF:      onGetDesktopOf   (message); break;
		
		// TODO: Observe window *movement*, too
		case LM_WINDOWCREATED:
		case LM_WINDOWDESTROYED:
			if(updateWindowList())
				forceRedraw(false);
			break;
		
		default:
			message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);
			break;
	}
}

void VWM::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_BRINGTOFRONT, LM_SWITCHTON, LM_WINDOWACTIVATED, LM_LISTDESKTOPS, LM_GETDESKTOPOF, 0};

	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)vwmWindow, (LPARAM)msgs);

	// Unregister window hook
	HWND hookManager = FindWindow("HookMgrClass", NULL);
	SendMessage(hookManager, LM_UNREGISTERMESSAGE, (WPARAM)WM_WINDOWPOSCHANGED, (LPARAM)NULL);

	cleanupBangs();

	// Switch to desk 1 on exit
	// FIXME: This should be something considerably more elaborate
	switchDesk(0, true);
	
	//destroyWindow();

	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
		delete ii->second;
}

void VWM::onCreate(Message& message)
{
	//finalize();
}

void VWM::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);
	sprintf(buf, VERSION_STRING);
	message.lResult = strlen(buf);
}

void VWM::onMouseButtonDown(Message& message)
{
	int x = message.lParamLo;
	int y = message.lParamHi;
	
	WindowData *task = taskFromPoint(x, y);
	VirtualDesktop *desk = panelPointToDesk(x, y);
	
	switch(message.uMsg)
	{
		case WM_RBUTTONDOWN:
		case WM_MBUTTONDOWN:  // Switch to clicked-on desktop
			if(desk)
				switchDesk(desk);
			break;
		
		case WM_LBUTTONDOWN: {
			bool startDrag = false;
			
			// Left button: If clicking on a window in a VWM, start dragging
			// that window. If clicking on a window in a task tray, switch to
			// that desktop, raise that window, and start dragging.
			
			if(task) {
				if(task->focused && !task->minimized)
				{
					// Clicking on the foreground task minimizes it unless you
					// move the mouse first
					pendingMinimize = task->handle;
					createDragIcon(x+windowX, y+windowY,
						task->getIcon(layoutSettings->tasksIconSize));
					break;
				}
				else
				{
					// Clicking on a task which isn't the foreground task focuses it
					// If it isn't minimized, it also starts a drag
					if(!task->minimized) {
						RECT windowRect;
						POINT clickPos = {x, y};
						POINT dragOffset;
						screenToMinimapPos(task->desk, task->screenPos, &windowRect, NULL);
						dragOffset.x = (windowRect.right-windowRect.left) / 2;
						dragOffset.y = (windowRect.bottom-windowRect.top) / 2;
						beginWindowDrag(task, false, clickPos, dragOffset);
					}
					switchDesk(task->desk, true);
					raiseWindow(task);
				}
			} else if(desk) {
				task = findMinimapWindow(desk, x-desk->minimapX, y-desk->minimapY);
				if(task) {
					RECT windowRect;
					POINT dragOffset;
					POINT clickPos = {x, y};
					screenToMinimapPos(desk, task->screenPos, &windowRect, NULL);
					dragOffset.x = x - windowRect.left - desk->minimapX;
					dragOffset.y = y - windowRect.top - desk->minimapY;
					beginWindowDrag(task, true, clickPos, dragOffset);
				} else {
					switchDesk(desk, false);
				}
			}
			
			break;
		}
	}
}

void VWM::onMouseButtonUp(Message& message)
{
	switch(message.uMsg)
	{
		case WM_RBUTTONUP:
			break;
		case WM_MBUTTONDOWN:  // Select desktop
			break;
		case WM_LBUTTONUP:  // Window dragging
			if(pendingMinimize) {
				if(windowsByHandle.find(pendingMinimize)!=windowsByHandle.end()) {
					WindowData *window = windowsByHandle[pendingMinimize];
					minimizeWindow(window);
					forceRedraw(true);
				}
				pendingMinimize = NULL;
			}
			else if(draggingTask)
				endDrag();
			break;
	}
}

/// Because we sometimes need to coordinate multiple windows, (x,y) is in
/// SCREEN coordinates, not window coordinates.
void VWM::onMouseMove(int x, int y)
{
	// If you drag an icon off its foreground area, it goes from 'maybe
	// minimize this' to 'drag this'.
	if(pendingMinimize)
	{
		if(windowsByHandle.find(pendingMinimize) == windowsByHandle.end()) {
			// The window has disappeared/closed since we started!
			pendingMinimize = NULL;
		} else {
			// If we drag it off its original icon area, it becomes a drag/drop
			// instead of a click
			WindowData *window = windowsByHandle[pendingMinimize];
			if(window != taskFromPoint(x-windowX, y-windowY)) {
				POINT dragOffset = {0,0};
				POINT clickPos = {x-windowX, y-windowY};
				pendingMinimize = NULL;
				// This type of drag goes to desktops only; it doesn't affect
				// position within a desktop.
				beginWindowDrag(window, false, clickPos, dragOffset);
			}
		}
	}
	
	if(draggingTask)
		continueWindowDrag(x-windowX, y-windowY);
}

void VWM::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(parentWindow, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);
}

void VWM::onWindowActivated(Message& message)
{
}

void VWM::onTimer(Message& message)
{
	// Update the window list, checking what the foreground window is before
	// and after.
	HWND oldTopWindow = foregroundHandle;
	bool changed = updateWindowList();
	
	if(oldTopWindow!=foregroundHandle) {
		VirtualDesktop *newDesk = getDeskFromWnd(foregroundHandle);
		switchDesk(newDesk, true);
	}
	
	// Dirty the VWM display to force it to redraw
	// TODO: Only redraw when there are changes
	if(changed)
		forceRedraw(false);
}

// TODO: Test and rewrite this
void VWM::onDropFiles(Message& message)
{
	POINT pt;
	DragQueryPoint( (HDROP)message.wParam, &pt );
	
	VirtualDesktop *newDesk = panelPointToDesk(pt.x, pt.y);
	if(!newDesk) return;
	switchDesk(newDesk);

	int numFiles = DragQueryFile( (HDROP)message.wParam, 0xFFFFFFFF, NULL, 0 );
	for(int i=0; i<numFiles; i++)
	{
		char filename[_MAX_PATH];
		DragQueryFile( (HDROP)message.wParam, i, filename, _MAX_PATH);
		if (filename && *filename)
			LSExecute(NULL, filename, SW_SHOWNORMAL);
	}
	DragFinish( (HDROP)message.wParam );
	forceRedraw(true);
}

// TODO: Rewrite this
void VWM::onVWMPosChanging(Message& message)
{
	LPWINDOWPOS windowPos = (LPWINDOWPOS)message.lParam;

	if ( !( windowPos->flags & SWP_NOSIZE ) )
	{
		windowWidth = windowPos->cx;
		windowHeight = windowPos->cy;
	}

	if ( !( windowPos->flags & SWP_NOMOVE ) )
	{
		windowX = windowPos->x;
		windowY = windowPos->y;
	}
	message.lResult = DefWindowProc(vwmWindow, message.uMsg, message.wParam, message.lParam);
}

void VWM::onBringToFront(Message &message)
{
	HWND hWnd = (HWND) message.lParam;
	VirtualDesktop *desk = getDeskFromWnd(hWnd);

	if (currentDesktop != desk)
		switchDesk(desk, true);

	SwitchToThisWindow(hWnd, TRUE);
	message.lResult = TRUE;
}

void VWM::onSwitchToN(Message &message)
{
	message.lResult = TRUE;
	int desk = (int) message.wParam;
	if(desk < 0 || desk >= (int)desktops.size())
		return;
	
	VirtualDesktop *newDesk = desktops[desk];
	switchDesk(newDesk, true);
}

void VWM::onListDesktops(Message &message)
{
	LSDESKTOPINFO deskInfo;

	for (unsigned ii = 0; ii < desktops.size(); ii++)
	{
		deskInfo.size = sizeof(LSDESKTOPINFO);
		deskInfo.icon = 0;
		deskInfo.isCurrent = desktops[ii]->focused;
		deskInfo.number = ii;
		
		string deskname = desktops[ii]->getName();
		strcpy(deskInfo.name, deskname.c_str());

		SendMessage((HWND) message.wParam, LM_DESKTOPINFO, 0, (LPARAM) &deskInfo);
	}

	message.lResult = TRUE;
}

void VWM::onGetDesktopOf(Message &message)
{
	VirtualDesktop *desk = getDeskFromWnd((HWND) message.wParam);
	message.lResult = desk->index;
}
