#if !defined(__LABELSETTINGS_H)
#define __LABELSETTINGS_H

class LabelSettings
{
private:

	boolean isDefault;

public:

	LabelSettings();
	LabelSettings(const char *name);
	virtual ~LabelSettings();

	boolean alwaysOnTop;
	boolean startHidden;
	boolean bUseFahrenheit;

	Texture *skin;
	Font *font;

	int leftBorder;
	int topBorder;
	int rightBorder;
	int bottomBorder;

	int align;
	int vertAlign;
	int updateInterval;

	int width;
	int height;
	int x;
	int y;

	int scrollInterval;
	int scrollSpeed;
	int scrollPadLength;
	boolean scroll;

	boolean trueTransparency;

	string text;

	string leftClickCommand;
	string leftDoubleClickCommand;
	string middleClickCommand;
	string middleDoubleClickCommand;
	string rightClickCommand;
	string rightDoubleClickCommand;
	string wheelDownCommand;
	string wheelUpCommand;
	string enterCommand;
	string leaveCommand;
	string dropCommand;
	string textChangeCommand;

	//Andymon WA StatusBang Extention
	//andymon@ls-universe.info
	//************************
	string waRunningCommand;
	string waClosedCommand;
	string waPlayCommand;
	string waPauseCommand;
	string waStopCommand;

	int waCheckInterval;
	//************************

	//Andymon Moving Extention
	//andymon@ls-universe.info
	//************************
    boolean moveable;
	int moveKey;
	int moveButton;
	//************************

	//Andymon Regions Extention
	//andymon@ls-universe.info
	//************************
	StringList labelLeftClickRegions;
	StringList labelRightClickRegions;
	StringList labelMiddleClickRegions;

	string enterleaveRegion;
	//************************
};

extern LabelSettings* defaultSettings;

#endif
