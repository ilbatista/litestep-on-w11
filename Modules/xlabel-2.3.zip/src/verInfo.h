#if !defined(__VERINFO_H)
#define __VERINFO_H

#define V_AUTHOR "X, modified by Andymon, seg@"
#define V_NAME "xLabel"
#define V_VERSION "2.3"

#endif
