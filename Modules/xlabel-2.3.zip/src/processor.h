#if !defined(__PROCESSOR_H)
#define __PROCESSOR_H

boolean startProcessorStatistics();
int getProcessorUsage();
boolean endProcessorStatistics();

#endif
