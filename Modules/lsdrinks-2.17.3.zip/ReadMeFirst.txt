#############################################################################
# lsDrinks 2.17.3                                                           #
# Hacked up by : nf0 <nf0@10500bc.org                                       #
#                                                                           #
# Thanks to Charlie <ishamael@orodruin.ddns.org> for making asDrinks        #
# Thanks to Flip for making flipsthing.                                     #
# Thanks to Spawn@desktopz.org for helping out and making suggestions       #
# Thanks to Tin_Omin <desktopian.org> for the best site on the net and      #
# helping the community with with some backends.                            #
# Thanks to MrJukes and geekMASTR for provinding community backends.        #
# Thanks to Aemergin for submitting some code to help under Win2k and IE 5. #
#                                                                           #
#############################################################################


What it Does:
It checks SlashDot, FreshMeat, Linux Today, Segfault, Technotronic, DeskTopian,
Geeknews, BetaNews, 32BitOnline, ArsTechnica, Floach, BeNews, BeOSCentral, 
ThemesOrg, SolarisCentral,Linux Games,Linux Apps,HackerNews,Happy Penguin News,
Happy Penguin Updates, Happy Penguin updates, Linux Quake,Absolutegamers
Linux 3d, Fullon 3d, Gizmo 3d, Blues news, Voodoo Extreme, Chunkymunky,
Python,FileForum,LiteStep.Net News, Litestep.Net Screen Shots,Litestep.Net Themes,
Geeknews.org,Demonews.com,PVPonline,DarkStep,Graphite,ShellScape,Tug House,
The Tech Report,Teh Ultimate OS,SciFi News Wire,Geeknews.org,Geeknik.net,Penny Arcade,
Fileclicks,Wired News,Cnet News,Perl Monks Code Snippets,Perl Monks Meditations,
Perl Monks Craft,Perl Monks Obfuscation,Perl Monks Poetry,Perl Monks Cool Uses of Perl,
MindJunction News, MindJunction Snips, MindJunction Ideas,Tekreview,Everything But Gaming,
Aint it cool news, EPCO News,Linux 2000,CMPTR,Elf life Comic,GPF Comic,News Hounds Comic,
Bruno the Bandit Comic,Funny Farm Comic,Sit and Spin Comic,Goats Comic,Hounds Home Comic,
Avalon High Comic,Joe Average Comic,RoadWaffles Comic,SinFest Comic,Digital Theatre,neoFlux,
Wonko Slice,The New OS,Ice Walkers,Daemon News,AppWatch,Palm InfoCenter,PDA Buzz,
Palm Station,Casters Realm,Ever Lore,EQ Corner,EQ Stratics,EQ Dr. Twister,Brell Sirilis,
Nerd Perfect,Anime Digest,Anime on DVD,EX Anime, DVD Animania,Added:   Modulo
Winfiles Latest,PureLS,NoNags Latest,DesktopSource Latest,Ace's Hardware,Cold-ice,PC stats.
Anime News Service, and EQ'Lizer.
Then Creates an Htm link in its folder. Then you can Look at your popup under 
the selected folder and see the news. To follow the link just click on the one
you want and it will open it up in your browser.


Suggestions:
If you have any suggestion or no of any other sites that you would like added email me.
The sites must have some sort of text backend to work. If any of you with Litestep sites
would like to have your stuff added let me know.


How to Use it:
There are now 2 ways to use this script one is todo the same as always put the news in
folders and the second is to have it create an .htm page for you to open with your Browser.
Or you can do both. More details are in the lsdrinks.rc file please read that.

Way number 1 put the files in folders

1. You must already have Perl installed on you machine. It must also be in the path.

2. Extract the File to your litestep Dir with the paths. It is assumed that this is a 
   default install to C:\litestep. If not then you may need to change some of the paths 
   in the lsdrinks.pl

3. a. If you use the Default Litestep Popups:
      *Important* Don't delete the x.x files from the subdirs. LS crashes when the folders
      are empty when you look at your popups. 
   b. If you use Re5ource's popup.dll :
      You can remove the x.x files it wont crash.

4. Create entries like the following:

   a. If you use the Default Litestep Popups:
      	*Popup "SlashDot" "!PopupDynamicFolder:c:\lsdrinks\Slashdot"
      	*Popup "FreshMeat" "!PopupDynamicFolder:c:\lsdrinks\FreshMeat"
      	*Popup "Linux Today" "!PopupDynamicFolder:c:\lsdrinks\LinuxToday"
      	*Popup "Segfault" "!PopupDynamicfolder:c:\lsdrinks\Segfault"
      	*Popup "Technotronic" "!PopupDynamicfolder:c:\lsdrinks\technotronic"
      	*Popup "DeskTopian" "!PopupDynamicFolder:c:\lsdrinks\DeskTopian"
      	*Popup "Geeknews" "!PopupDynamicFolder:c:\lsdrinks\Geeknews"
      	*Popup "32BitsOnline" "!PopupDynamicFolder:c:\lsdrinks\32BitsOnline"
      	*Popup "BetaNews" "!PopupDynamicFolder:c:\lsdrinks\betanews"
      	*Popup "ArsTechnica" "!PopupDynamicFolder:c:\lsdrinks\ArsTechnica"
      	*Popup "Floach" "!PopupDynamicFolder:c:\lsdrinks\Floach"
      	*Popup "BeNews" "!PopupDynamicFolder:c:\lsdrinks\BeNews"
      	*Popup "BeOSCentral" "!PopupDynamicFolder:c:\lsdrinks\BeOSCentral"
      	*Popup "ThemesOrg" "!PopupDynamicFolder:c:\lsdrinks\ThemesOrg"
      	*Popup "SolarisCentral" "!PopupDynamicFolder:c:\lsdrinks\SolarisCentral"   
      	*Popup "LinuxGames" "!PopupDynamicFolder:c:\lsdrinks\LinuxGames"
	*Popup "LinuxApps" "!PopupDynamicFolder:c:\lsdrinks\LinuxApps"
	*Popup "HackerNews " "!PopupDynamicFolder:c:\lsdrinks\HackerNews"
	*Popup "HappyPenguinNews" "!PopupDynamicFolder:c:\lsdrinks\HappyPenguinNews"
	*Popup "HappyPenguinUpdtes" "!PopupDynamicFolder:c:\lsdrinks\HappyPenguinUpdtes"
	*Popup "HappyPenguinAdd" "!PopupDynamicFolder:c:\lsdrinks\HappyPenguinAdd"
	*Popup "LinuxQuake" "!PopupDynamicFolder:c:\lsdrinks\LinuxQuake"
	*Popup "LinuxQuakePage" "!PopupDynamicFolder:c:\lsdrinks\LinuxQuakePage"
	*Popup "AbsoluteGamers" "!PopupDynamicFolder:c:\lsdrinks\AbsoluteGamers"
	*Popup "Linux3d" "!PopupDynamicFolder:c:\lsdrinks\Linux3d"
	*Popup "Fullon3d" "!PopupDynamicFolder:c:\lsdrinks\Fullon3d"
	*Popup "Gizmo3d" "!PopupDynamicFolder:c:\lsdrinks\Gizmo3d"
	*Popup "BluesNews" "!PopupDynamicFolder:c:\lsdrinks\luesNews"
	*Popup "VoodooExtreme" "!PopupDynamicFolder:c:\lsdrinks\VoodooExtreme"
	*Popup "ChunkyMunky" "!PopupDynamicFolder:c:\lsdrinks\ChunkyMunky"
	*Popup "Python" "!PopupDynamicFolder:c:\lsdrinks\Python"
        *Popup "Demonews" "!PopupDynamicFolder:c:\lsdrinks\Demonews"
        *Popup "PVPonline" "!PopupDynamicFolder:c:\lsdrinks\PVPonline"
        *Popup "DarkStep" "!PopupDynamicFolder:c:\lsdrinks\DarkStep"
        *Popup "Graphite" "!PopupDynamicFolder:c:\lsdrinks\Graphite"
        *Popup "ShellScape" "!PopupDynamicFolder:c:\lsdrinks\ShellScape"
        *Popup "TugHouse" "!PopupDynamicFolder:c:\lsdrinks\tughouse"
        *Popup "UltimateOS" "!PopupDynamicFolder:c:\lsdrinks\ultimateos"
        *Popup "TechReport" "!PopupDynamicFolder:c:\lsdrinks\techreport"
        *Popup "SciFiWire" "!PopupDynamicFolder:c:\lsdrinks\scifiwire"
        *Popup "Geeknewsorg" "!PopupDynamicFolder:c:\lsdrinks\geeknewsorg"
        *Popup "GeekNik" "!PopupDynamicFolder:c:\lsdrinks\geeknik"
        *Popup "PennyArcade" "!PopupDynamicFolder:c:\lsdrinks\pennyarcade"
        *Popup "FileClicks" "!PopupDynamicFolder:c:\lsdrinks\fileclicks"
        

   b. If you use Re5ource's popup.dll :
      In there own Top Level Folder (Doesn't work under the default LS Popup.dll)

      *Popup "lsDrinks" Folder
         *Popup "SlashDot" "!DynamicFolder:c:\lsdrinks\Slashdot"
         *Popup "FreshMeat" "!DynamicFolder:c:\lsdrinks\FreshMeat"
         *Popup "Linux Today" "!DynamicFolder:c:\lsdrinks\LinuxToday"
         *Popup "Segfault" "!Dynamicfolder:c:\lsdrinks\Segfault"
         *Popup "Technotronic" "!Dynamicfolder:c:\lsdrinks\technotronic"
         *Popup "DeskTopian" "!DynamicFolder:c:\lsdrinks\DeskTopian"
         *Popup "Geeknews" "!DynamicFolder:c:\lsdrinks\Geeknews"
         *Popup "32BitsOnline" "!DynamicFolder:c:\lsdrinks\32BitsOnline"
         *Popup "BetaNews" "!DynamicFolder:c:\lsdrinks\betanews"
         *Popup "ArsTechnica" "!DynamicFolder:c:\lsdrinks\ArsTechnica"
         *Popup "Floach" "!DynamicFolder:c:\lsdrinks\Floach"
         *Popup "BeNews" "!DynamicFolder:c:\lsdrinks\BeNews"
         *Popup "BeOSCentral" "!DynamicFolder:c:\lsdrinks\BeOSCentral"
         *Popup "ThemesOrg" "!DynamicFolder:c:\lsdrinks\ThemesOrg"
         *Popup "SolarisCentral" "!DynamicFolder:c:\lsdrinks\SolarisCentral"   
         *Popup "LinuxGames" "!DynamicFolder:c:\lsdrinks\LinuxGames"
	 *Popup "LinuxApps" "!DynamicFolder:c:\lsdrinks\LinuxApps"
	 *Popup "HackerNews " "!DynamicFolder:c:\lsdrinks\HackerNews"
	 *Popup "HappyPenguinNews" "!DynamicFolder:c:\lsdrinks\HappyPenguinNews"
	 *Popup "HappyPenguinUpdtes" "!DynamicFolder:c:\lsdrinks\HappyPenguinUpdtes"
	 *Popup "HappyPenguinAdd" "!DynamicFolder:c:\lsdrinks\HappyPenguinAdd"
	 *Popup "LinuxQuake" "!DynamicFolder:c:\lsdrinks\LinuxQuake"
	 *Popup "AbsoluteGamers" "!DynamicFolder:c:\lsdrinks\AbsoluteGamers"
	 *Popup "Linux3d" "!DynamicFolder:c:\lsdrinks\Linux3d"
	 *Popup "Fullon3d" "!DynamicFolder:c:\lsdrinks\Fullon3d"
	 *Popup "Gizmo3d" "!DynamicFolder:c:\lsdrinks\Gizmo3d"
	 *Popup "BluesNews" "!DynamicFolder:c:\lsdrinks\luesNews"
	 *Popup "VoodooExtreme" "!DynamicFolder:c:\lsdrinks\VoodooExtreme"
	 *Popup "ChunkyMunky" "!DynamicFolder:c:\lsdrinks\ChunkyMunky"
	 *Popup "Python" "!DynamicFolder:c:\lsdrinks\Python"
	 *Popup "Demonews" "!DynamicFolder:c:\lsdrinks\Demonews"
         *Popup "PVPonline" "!DynamicFolder:c:\lsdrinks\PVPonline"
         *Popup "DarkStep" "!DynamicFolder:c:\lsdrinks\DarkStep"
         *Popup "Graphite" "!DynamicFolder:c:\lsdrinks\Graphite"
         *Popup "ShellScape" "!DynamicFolder:c:\lsdrinks\ShellScape"
         *Popup "TugHouse" "!DynamicFolder:c:\lsdrinks\tughouse"
         *Popup "UltimateOS" "!DynamicFolder:c:\lsdrinks\ultimateos"
         *Popup "TechReport" "!DynamicFolder:c:\lsdrinks\techreport"
         *Popup "SciFiWire" "!DynamicFolder:c:\lsdrinks\scifiwire"
         *Popup "Geeknewsorg" "!DynamicFolder:c:\lsdrinks\geeknewsorg"
         *Popup "GeekNik" "!DynamicFolder:c:\lsdrinks\geeknik"
         *Popup "PennyArcade" "!DynamicFolder:c:\lsdrinks\pennyarcade"
         *Popup "FileClicks" "!DynamicFolder:c:\lsdrinks\fileclicks"
       *Popup ~Folder
      
      Or in Seperate Folders:

      *Popup "SlashDot" "!DynamicFolder:c:\lsdrinks\Slashdot"
      *Popup "FreshMeat" "!DynamicFolder:c:\lsdrinks\FreshMeat"
      *Popup "Linux Today" "!DynamicFolder:c:\lsdrinks\LinuxToday"
      *Popup "Segfault" "!Dynamicfolder:c:\lsdrinks\Segfault"
      *Popup "Technotronic" "!Dynamicfolder:c:\lsdrinks\technotronic"
      *Popup "DeskTopian" "!DynamicFolder:c:\lsdrinks\DeskTopian"
      *Popup "Geeknews" "!DynamicFolder:c:\lsdrinks\Geeknews"
      *Popup "32BitsOnline" "!DynamicFolder:c:\lsdrinks\32BitsOnline"
      *Popup "BetaNews" "!DynamicFolder:c:\lsdrinks\betanews"
      *Popup "ArsTechnica" "!DynamicFolder:c:\lsdrinks\ArsTechnica"
      *Popup "Floach" "!DynamicFolder:c:\lsdrinks\Floach"
      *Popup "BeNews" "!DynamicFolder:c:\lsdrinks\BeNews"
      *Popup "BeOSCentral" "!DynamicFolder:c:\lsdrinks\BeOSCentral"
      *Popup "ThemesOrg" "!DynamicFolder:c:\lsdrinks\ThemesOrg"
      *Popup "SolarisCentral" "!DynamicFolder:c:\lsdrinks\SolarisCentral"  
      *Popup "LancedNet" "!DynamicFolder:c:\lsdrinks\LancedNet"
      *Popup "LinuxGames" "!DynamicFolder:c:\lsdrinks\LinuxGames"
      *Popup "LinuxApps" "!DynamicFolder:c:\lsdrinks\LinuxApps"
      *Popup "HackerNews " "!DynamicFolder:c:\lsdrinks\HackerNews"
      *Popup "HappyPenguinNews" "!DynamicFolder:c:\lsdrinks\HappyPenguinNews"
      *Popup "HappyPenguinUpdtes" "!DynamicFolder:c:\lsdrinks\HappyPenguinUpdtes"
      *Popup "HappyPenguinAdd" "!DynamicFolder:c:\lsdrinks\HappyPenguinAdd"
      *Popup "LinuxQuake" "!DynamicFolder:c:\lsdrinks\LinuxQuake"
      *Popup "AbsoluteGamers" "!DynamicFolder:c:\lsdrinks\AbsoluteGamers"
      *Popup "Linux3d" "!DynamicFolder:c:\lsdrinks\Linux3d"
      *Popup "Fullon3d" "!DynamicFolder:c:\lsdrinks\Fullon3d"
      *Popup "Gizmo3d" "!DynamicFolder:c:\lsdrinks\Gizmo3d"
      *Popup "X11spy" "!DynamicFolder:c:\lsdrinks\X11spy"
      *Popup "BluesNews" "!DynamicFolder:c:\lsdrinks\luesNews"
      *Popup "VoodooExtreme" "!DynamicFolder:c:\lsdrinks\VoodooExtreme"
      *Popup "ChunkyMunky" "!DynamicFolder:c:\lsdrinks\ChunkyMunky"
      *Popup "Python" "!DynamicFolder:c:\lsdrinks\Python"   
      *Popup "Demonews" "!DynamicFolder:c:\lsdrinks\Demonews"
      *Popup "PVPonline" "!DynamicFolder:c:\lsdrinks\PVPonline"
      *Popup "DarkStep" "!DynamicFolder:c:\lsdrinks\DarkStep"
      *Popup "Graphite" "!DynamicFolder:c:\lsdrinks\Graphite"
      *Popup "ShellScape" "!DynamicFolder:c:\lsdrinks\ShellScape"
      *Popup "TugHouse" "!DynamicFolder:c:\lsdrinks\tughouse"
      *Popup "UltimateOS" "!DynamicFolder:c:\lsdrinks\ultimateos"
      *Popup "TechReport" "!DynamicFolder:c:\lsdrinks\techreport"
      *Popup "SciFiWire" "!DynamicFolder:c:\lsdrinks\scifiwire"
      *Popup "Geeknewsorg" "!DynamicFolder:c:\lsdrinks\geeknewsorg"
      *Popup "GeekNik" "!DynamicFolder:c:\lsdrinks\geeknik"
      *Popup "PennyArcade" "!DynamicFolder:c:\lsdrinks\pennyarcade"
      *Popup "FileClicks" "!DynamicFolder:c:\lsdrinks\fileclicks"   

5. To run Manually:       At the Command Line Type: perl lsdrinks.pl
   To run Automatically:  Use the Start.bat file. That will start the Wincron program
   and update it every hour at the 30 minute mark. This uses a file called WinCron.dat. This can be 
   changed according to how often you want it to update. Read: \lsdrinks\bin\wincron.txt
   for more information.

6. To make further tweaks just open up the lsdrinks.pl in your favorite text editor. The file
   is documented fairly well. You can turn on and turn off any of the news that you choose.

Way Number 2 As a WebPage
Please look at lsdrinks.rc to make the changes.

# 2.17.3 Removed: Gizmo3d
#        Removed: TugHouse. It is no longer updated. :(
# 2.17.2 Fixed:   LinuxToday
#        Fixed:   Desktopian
#        Fixed:   Geeknews
#        Fixed:   BeNews
#        Fixed:   Linux Games
#        Fixed:   Hacker News
#        Fixed:   Linux Quake News
#        Note:    Python.org is not broken It just hasn't been updated since March
#        Fixed:   PVP ONline
#        Note:    The Ultimate OS was down during testing
#        Fixed:   DarkStep
#        Fixed:   Geeknik
#        Fixed:   News.com
#        Fixed:   MindJunction News
#        Fixed:   Deamon News
#        Note:    The New OS hasn't been updated since May.
#        Fixed:   NeoFlux
#        Fixed:   EQstratics
#        Fixed:   NerdPerfect
#        Note:    AnimeDigest hasn't been updated since April
#        Fixed:   ExAnime
#        Fixed:   Desktop Source
#        Note:    Cold Ice down during testing
#        Fixed:   EQlizer
# 2.17.1 Fixed:   BetaNews
#        Fixed:   BeOS Central
#        Fixed:   Themes.org
#        Fixed:   Solaris Central
#        Change:  Chunkymunky to Dtop
#        Fixed:   FileForum
#        Fixed:   After Y2k
#        Fixed:   Tech-Report
#        Fixed:   Perl Monk Snippets
#        Fixed:   Perl Monk Poetry
#        Fixed:   Perl Monk Cool Uses
#        Fixed:   Perl Monks Obfuscation
#        Fixed:   Perl Monks Craft
#        Fixed:   Perl Monks Meditations
#        Fixed:   EverLore
#        Fixed:   EQ Corner
#        Fixed:   EQ Dr. Twister
#        Fixed:   Several Sites not show up correctly when style set to 1
#        News:    Anime Digest seems to be down as of testing of this version.
# 2.17.0 Change:  Added the foldernumval option. If set to 1 it will place
#                 Numbers infront of each topic in the folders so they will
#                 be displayed in order. Another good idea from Twyst.
# 2.16.0 Added:   Anime News Service
#        Added:   EQ'Lizer.
# 2.15.1 Fixed:   Geeknews to use an ip address DNS seems to be broke
#        News:    All the Happy Penguin Sites seem to be down at the moment.
#        Fixed:   Changed ChunkyMunky to the new IP until the copywrite issues are worked out.
#        News:    After Y2k Seems to be down for the moment. Hopefully its temporary because Tubes Rock.
#        News:    Still having Problems with Demonews, there server doesn't seem to play nice.
#        News:    Darkstep seems to be down at the moment.
#        News:    ShellScape seems to be down at the moment.
#        Fixed:   Geeknik.
#        Fixed:   News.Com
#        Fixed:   FunnyFarm
#        Fixed:   ElfLife
# 2.15.0 Chage:   Add a change to the folder structure. You can now specifiy more specificaly
#                 which folder to places the news folders in. 
#                 Done in the step.rc with the folderdir value.
#                 ex. folderdir=c:/windows/start menu/news/
#                 this will create a news folder under the start menu. This should provide more
#                 flexibility. Suggestion came from Twyst <twyst@twysted.net>. For better use under
#                 the default explorer shell.
#        Added:   Modulo
#        Added:   Winfiles Latest.
#        Added:   PureLS
#        Added:   NoNags Latest.
#        Added:   DesktopSource Latest.
#        Added:   Ace's Hardware
#        Added:   Cold-ice
#        Added:   PC stats.
# 2.14.1 Fixed:   Casters Realm
#        Fixed:   Ever Lore
#        Fixed:   EQ Corner
#        Fixed:   EQ Stratics
#        Fixed:   EQ Dr. Twister
#        Fixed:   Brell Sirilis
#        Fixed:   Penny Arcade
#        Fixed:   Aint it Cool News
# 2.14.0 Added:   Casters Realm
#        Added:   Ever Lore
#        Added:   EQ Corner
#        Added:   EQ Stratics
#        Added:   EQ Dr. Twister
#        Added:   Brell Sirilis
#        Added:   Nerd Perfect
#        Added:   Anime Digest
#        Added:   Anime on DVD
#        Added:   EX Anime
#        Added:   DVD Animania
#        Fixed:   Some invalid Folder names
# 2.13.0 Change:  No longer are the folder vales auto-refreshing .htm files they are of the new .url
#                 format. This works better wiht IE 5 and Win2K. Thanks for the suggestion and code
#                 samples from :Aemergin.
#        Change:  Big overhaul to the images links in the folders made things a little bit easier.
# 2.13.0 Change:  No longer are the folder vales auto-refreshing .htm files they are of the new .url
#                 format. This works better wiht IE 5 and Win2K. Thanks for the suggestion and code
#                 samples from :Aemergin.
#        Change:  Big overhaul to the images links in the folders made things a little bit easier.
# 2.12.0 Added:   Palm Station.
#        Added:   PDA Buzz
#        Added:   Palm InfoCenter
#        Added:   AppWatch
#        Added:   Daemon News
#        Added:   Ice Walkers
#        Added:   The New OS
#        Added:   Wonko Slice
#        Added:   neoFlux
#        Added:   Digital Theatre
# 2.11.0 Added:   SinFest Comic.
#        Added:   RoadWaffles Comic.
#	 Added:   Joe Average Comic
#	 Added:   Avalon High Comic
#	 Added:   Hounds Home Comic.
#	 Added:   Goats Comic
#	 Added:   Sit and Spin Comic.
#	 Added:   Funny Farm Comic.
#	 Added:   Bruno the Bandit Comic.
#	 Added:   News Hounds Comic.
#	 Added:   GPF Comic
#	 Added:   Elf life Comic.
#	 Added:   CMPTR
#	 Added:   Linux 2000
# 2.10.1 Fixed:   Shell City
# 2.10.0 Added:   Tekreview
#        Added:   Everything But Gaming
#        Added:   Aint it cool news.
#        Added:   EPCO News.
# 2.9.3  Fixed:   All Mind Junction Folders.
# 2.9.2  Fixed:   Mind Junction News.
#        Fixed:   GeekNik
#        News:    Segfault seems to be down. Thats all i know.
# 2.9.1  Fixed:   Floach.
#        Fixed:   SciFi Wire.
#        News:    Linux Game Tome back up. Thats all the Happy Penguin News.
#        News:    DemoNews looks broken (server side) at the moment.
#        News:    Linux Quake backup.
# 2.9.0  Added:   MindJunction News, MindJunction Snips, MindJunction Ideas
# 2.8.4  Fixed:   After Y2k
# 2.8.3  Fixed:   SciFi Wire
#        News:    DarkStep Down for a while. (waiting for a new server)
#        Fixed:   Perl Monks Craft
# 2.8.2  Fixed:   Floach. Now parsing in lsDrinks doesn't use the Desktopian backend anylonger.
#        News:    All the HappyPenguin Sites are currently down due to server outages and changes.
#        News:    I have no idea whats happened to LinuxQuke it maybe dead i'll give it more time.
# 2.8.1  Fixed:   Userfriendly
# 2.8.0  Added:   Perl Monks Cool Uses of Perl
#        Added:   Perl Monks Poetry
#        Added:   Perl Monks Obfuscation
#        Added:   Perl Monks Craft
#        Added:   Perl Monks Meditations
# 2.7.0  Added:   Perl Monks Code Snippets
# 2.6.0  Added:   Cnet News
#                 Wired News
# 2.5.0  Added:   Fileclicks.
#        Added:   Penny Arcade.
#        Added:   Geeknik.net.
# 2.4.1  Fixed:   Geeknews.org.
# 2.4.0  Added:   SciFi News Wire
#        Added:   The Tech Report
#        Added:   The Ultimate OS.
#        Added:   Tug House Comic.
#        Added:   ShellScape
#        Added:   Graphite.
#        Added:   DarkStep.
# 2.3.0  Added:   PVPonline comic
# 2.2.0  Added:   A whole new way to organize the HTM page. you can use the classic view
#                 to add sites in the order they were introduced or you can use the new
#                 style to display sites in a certain order. This works with the folders
#                 as well but doesn't really change anything other than the order sites are
#                 checked.
# 2.1.9  Changed: Liststep.Net,ScreenShots,Themes to parse in this file.(no longer using pimpin.net backends)
#        Fixed:   Problem with Feedback not working when folders were turned off
#        Changed: Reformated alot of the Code to make it more readable
#        Fixed:   Technotronic.
#        Removed: Litestep.com, Litestep.org,LancedNet. This dead code has been in 2 long.
#        Fixed:   Some of the Funky spelling problems like jumbling everything together.
# 2.1.8  Added:   Demonews.com
#        Fixed:   BeNews
# 2.1.7  Fixed:   Parsing problem with ) or (
#        Fixed:   LinuxToday - Page Moved
#        Fixed:   BetaNews   - Formatting Changed
#        Fixed:   File Forum - Formatting Changed
#        Fixed:   Shell City - Formatting Changed
# 2.1.6  Added:   Geeknews.org, Fixed Segfault
# 2.1.5  Added:   After Y2k Cartoon
#        Added:   LiteStep.Net,Litestep.net Screen Shots (using backends from MrJukes and geekMASTR)
#        Added:   the ability for the script to create a directory if one doesn't exist so in including
#                 as the sub dirs is no longer needed.
# 2.1.4  Changed: floach to read from Desktopian * Thanks Tin_Omen *, Changed Tin_Toys to Desktopian
#        Changed: the htm page to added a differnt header and url, Added Shell City
# 2.1.3  Added:   Astronomy Pic of the Day, Dilbert,FileForum Changed the Way Floach Works.
# 2.1.2  Added:   User Friendly Strip
# 2.1.1  Changed: Lots of cleanup. Several sites are gone and many have changed.
#                 I also added a few more formating options for the .htm page.
#                 I added a limit to the number of stories that will be shown.
#                 Lots of bug fixes and it will now automatically skip a site if
#                 its down.
# 2.0    Changed: Some more new code, bug fixes and cleanup.
# 1.9    Changed: Add the .htm part of the script
# 1.8    Changed: Totally rewrote all the code to be more like and engine.
# 1.7    Changed: Update Sites Started Changin code
# 1.6    Changed: Updated some to the sites that changed there backends and add a few new ones.
#                 Desktopz.org,Litestep.org,PCParadox,LancedNet,LinuxGames,LinuxApps
#                 HackerNews   # Slow times out on slow connections,HappyPenguinNews
#                 HappyPenguinUpdtes,HappyPenguinAdd,LinuxQuake,LinuxQuakePage,AbsoluteGamers
#                 Linux3d,Fullon3d,740,Gizmo3d,X11spy,Polyester,MyDesktop,BluesNews
#                 VoodooExtreme,ChunkyMunky,Python
# 1.5    Changed: Updated some of the existing sites that no longer worked and/or moved there backend files.
#        Added:   Floach, LiteStepCom, BeNews, BeOSCentral, MattsHouse, ThemesOrg and SolarisCentral 
# 1.4    Added:   ArsTechnica,Changed some of the code
# 1.3    Added:   32BitsOnline, lsNews, and Betanews. 
#        Bugs:    32BitsOnline doesn't format the headlines very well.
# 1.2    Added:   Tin_Omen, Technotronic, and Geeknews. Tweaked the Code just a bit.
# 1.1    Changed: After Tin_Omen suggested better ways to do the popups I have remove the recycle.exe file.
#                 It was in the wrong place to begin with :(
#                 I also removed the Targ checking as the site is closing down. The How to was update to 
#                 reflect the suggestions from Tin_Omen.
