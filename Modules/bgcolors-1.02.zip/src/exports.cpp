
/********************************************/
/*											*/
/*	exports.c								*/
/*											*/
/*	Version	1.02							*/
/*											*/
/*	11 nov 2003								*/
/*											*/
/*	This is the exported functions			*/
/*	implementation file for the BGColors	*/
/*	module for LiteStep.					*/
/*											*/
/*	Made by Antoine Wells Campagna			*/
/*	aka AntAgna								*/
/*	send questions, comments, etc... to :	*/
/*	AntoineW@Campagna.org					*/
/*											*/
/********************************************/


//Includes

#include "bgcolors.h"


//The global object pointer

CBGColors * g_BGColors = NULL;


//Exported Functions

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	if (g_BGColors != NULL)		//Just to be sure
	{
		delete g_BGColors;
	}

	g_BGColors = new CBGColors(hParent, hInstance);		//Instanciation
	
	if (g_BGColors->Status() != ST_NO_ERROR)	//If error occured
	{
		quitModule(hInstance);
	}

	return 0;
}

void quitModule(HINSTANCE hInstance)
{
	if (g_BGColors != NULL)		//Another check
	{
		delete g_BGColors;		//Deletion
		g_BGColors = NULL;
	}

}

BOOL APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{	//Not used
	return TRUE;
}
