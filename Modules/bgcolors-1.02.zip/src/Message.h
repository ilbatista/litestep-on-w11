
/********************************************/
/*											*/
/*	Message.h								*/
/*											*/
/*	Declaration of class CMessage			*/
/*											*/
/*	This class is to handle easely window	*/
/*	messages.								*/
/*											*/
/*	You want to use this class for your		*/
/*	Windows c++ app ? Sure, all you	have	*/
/*	to do is to change the HANDLER_CLASS	*/
/*	define to the name of your Window		*/
/*	class and include the header file		*/
/*	of your Window class in Message.cpp		*/
/*											*/
/*	How to use at the end of file.			*/
/*											*/
/*	Made by Antoine Wells Campagna			*/
/*	aka AntAgna								*/
/*	send questions, comments, etc... to :	*/
/*	AntoineW@Campagna.org					*/
/*											*/
/********************************************/


#pragma once


//Includes

#include "windows.h"	//Needed only for the data types (UINT, WPARAM ...)


//Defines

#define MESSAGE_NOT_FOUND	WM_USER+1
#define DY_MEM_INC			10			//Dynamic memory incrementation

//Name of the class that will handle the messages
#define HANDLER_CLASS		CBGColors


//Types

class HANDLER_CLASS;

struct Message
{
	UINT uMsg;	//Message number
	LRESULT (_cdecl * HandlerSt)(WPARAM, LPARAM, void *);
		//Adress of the handler function (static)
	LRESULT (HANDLER_CLASS::* Handler)(WPARAM, LPARAM);
		//Adress of the handler function (member)
};

class CMessage
{
public:
	int m_NbMsgs;			//Number of messages
	void * m_ClassPointer;	//Pointer to the handler object
	CMessage();				//Construction
	~CMessage();			//Destruction

	//Add a message
	BOOL Add(UINT uMsg, 
		LRESULT (HANDLER_CLASS:: * Handler)(WPARAM, LPARAM));
	BOOL AddSt(UINT uMsg, 
		LRESULT (_cdecl * HandlerSt)(WPARAM, LPARAM, void *));

	Message * FindMessage(UINT uMsg);	//Find a message

	LRESULT TreatMessage(UINT uMsg,		//Call the good handler function
		WPARAM wParam, LPARAM lParam);

private:
	Message * m_Msgs;		//Messages

	void VerifySize(void);	//To verify if we need more memmory
};

/*

  This file should be included in the header file of the handler class.

  Declare a Member object of the CMessage class in the hanler class (m_Msgs)

  When window is created, use commands like this to add reaction to messages :

	  m_Msgs.Add(WM_MESSAGE_ID, MemberHandler);
	  
	  where WM_MESSAGE_ID is the ID of the message (like WM_CLOSE)
	  and MemberHandler is the name of the member function that will
	  be called when this message is received.
	  This function must be declared in the same class as :
		
		LRESULT MemberHandler(WPARAM wParam, LPARAM lParam);

  You can also use functions that are not in the class or that are static :

	  m_Msgs.AddSt(WM_MESSAGE_ID, StaticMemberHandler);

	  The static message handler must be declared as :

		LRESULT StaticMemberHandler(WPARAM wParam, LPARAM lParam, void * info);
		(info will receive a pointer to the instance of the handler class)

  The window procedure should look like this :

	LRESULT CALLBACK CYourClass::WndProc(HWND hwnd, UINT message,
									WPARAM wParam, LPARAM lParam)
	{
		LRESULT ret = g_thisPtr->m_Msgs.TreatMessage(message, wParam, lParam);
		if (ret == MESSAGE_NOT_FOUND)
		{
			return DefWindowProc(hwnd, message, wParam, lParam);
		}

		return ret;
	}

	The Window procedure must be declared static.
	Here, g_thisPtr is a pointer to the instance of your class.
	You can also set up this pointer in your window with 
		SetWindowLongPtr(YourWndHdl, GWLP_USERDATA, (LONG_PTR) this);
	and retreive it in your Window procedure with 
		CYourClass * thisPtr = (CYourClass *) GetWindowLongPtr(hwnd, GWLP_USERDATA);

  That's it, have fun !

*/
