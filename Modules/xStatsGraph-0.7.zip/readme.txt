xStatsGraph by thegeek.

----Introduction----

Hi, this is a small graphing module I put together to replace rainmeter.
At the moment it is very basic, but it's under development;P
It uses perfmon counters or xstatsclass to gather data, so you can graph pretty much anything;P
I hope to add more rendering modes later, and I am very open to suggestions/requests:)
Since this module is under heavy development please report any bugs.

----Capabilities----

I use the excellent xpaintclass by andymon, so the graphics for the "background layer" has full support for xpaintclass settings.
The meters are rendered using agg ( anti-grain geometry ) and I use the agg2d abstraction layer, what this means is that you get very nice antialiasing ;P
The graph itself is rendered ontop of this background, at the moment you can set color and alpha for both the graph "fill" and outer "stroke".
This is a basic example to illustrate a cpu graph:


*xStatsGraph CpuGraph
NetGraphX 40
NetGraphY 30
NetGraphWidth 300
NetGraphHeight 22
NetGraphPaintingMode .singlecolor
;NetGraphImage "horizontalbar_2.png"
NetGraphColors FFFFFF


*CpuGraphSource cpuperf
cpuperfSource perfmon
cpuperfSourceString "\Processor(_Total)\% Processor Time"
cpuperfRefreshRate 200


*CpuGraphSource cpuperf2
cpuperf2RefreshRate 200
cpuperf2Source xstatsclass
cpuperf2SourceString "[cpu]"
;cpuperfDataPoints 1000

*CpuGraphMeter Graph1
Graph1X 0
Graph1Y 0
Graph1Height 17
Graph1Width 90
Graph1RenderMode FillAndStroke
Graph1FillMode LinearGradient
;Graph1FillColor 00ff00
Graph1FillGradientP1Color 0000FF
Graph1FillGradientP1X 0
Graph1FillGradientP1Y 0
Graph1FillGradientP2Color 00FF00
Graph1FillGradientP2X 0
Graph1FillGradientP2Y 15
Graph1StrokeMode Solid
Graph1StrokeColor 000000
Graph1Source cpuperf1
Graph1Scale 100
Graph1Orientation Horizontal


There are three main sections here:
*xStatsGraph CpuGraph
This is how you define a basic "graph" called "CpuGraph", inside of it you can have different elements, atm the only element avaiable is "Meter".
You can define a meter like this: *CpuGraphMeter Graph1.
Each of these sections have different settings, the xStatsGraph section is basically only xpaintclass settings.



########################################
xStatsGraph settings
########################################
This is a basic xpaintclass background, and you use normal xpaintclass settings here.


########################################
*(xStatsGraph-name)Source settings
########################################

A "source" can have these settings:

RefreshRate
This setting allows you to set the milliseconds between each update, lower bound is 50.
If you use xpaintclass you need to set xStatsCpuStatsUpdateInterval  to the same or lower in order for it to work.

Scale 100
This allows you to set the (vertical) scale of the graph. The data collected is divided by this and then multiplied with the height of the meter.

Source xstatsclass
This setting allows you to choose between xpaintclass and the built-in perfmon code to use for data collection. 
Xpaintclass is a lot easier to use, but perfmon gives you greater freedom and maybe less overhead.

SourceString "[cpu]"
Tis setting is what you use to define the string that either xpaintclass or perfmon uses to gather the data.
For xpaintclass this is pretty easy, and if you are wondering what possibilities you have consult xpaintclass docs.
For perfmon this is a bit harder, if you have trouble formatting this string correctly use the !xStatsGraphShowPerformancePicker bang to get a dialog that allows you to select among all counters. After you have selected the counter you want, click ok and the correct string will be copied to your clipboard.
The default setting is for english windows, if you have another language you will have to change it.

DataPoints 1000
DataPoints allow you to set the number of "points" of collected data that is stored, if you have a very large meter you might have to increase this (default 1000)




########################################
*(xStatsGraph-name)Meter settings
########################################

A "meter" can have these settings:

X 			int
Y 			int
Height 			int
Width 			int
RenderMode 		FillOnly|StrokeOnly|FillAndStroke

FillMode 		Solid|LinearGradient|RadialGradient
FillColor		color
FillAlpha		int(0-255)
FillGradientP1Color 	color
FillGradientP1X		int
FillGradientP1Y		int
FillGradientP1Alpha	int
FillGradientP2Color 	color
FillGradientP2X 	int
FillGradientP2Y 	int
FillGradientP2Alpha 	int

StrokeMode 		Solid|LinearGradient|RadialGradient
StrokeColor		color
StrokeAlpha		int
StrokGradientP1Color 	color
StrokGradientP1X	int
StrokGradientP1Y	int
StrokGradientP1Alpha	int
StrokGradientP2Color 	color
StrokGradientP2X 	int
StrokGradientP2Y 	int
StrokGradientP2Alpha 	int

Source			name of source
Orientation		Horizontal|Vertical
FlipX			false|true
flipY			false|true


*Explanation of the gradient-system:
The P1,P1... are "points" that define how the gradient is painted, you set x,y,color and alpha and the gradient will use these.
LinearGradient will create a linear gradient between P1 and P2.
RadialGradient will use P1 as the "inside" of a radial, with "FillGradientP1Radius" or "StrokeGradientP1Radius" as the radius of the gradient and P2 as the color outside of the radial.


########################################
*(xStatsGraph-name)Text settings
########################################

A "text" can have all these settings:

X 			int
Y 			int
Height 			int
Width 			int
RenderMode 		FillOnly|StrokeOnly|FillAndStroke
FillColor		color
FillAlpha		int(0-255)
StrokeColor		color
StrokeAlpha		int(0-255)
Source			name of source

FontHeight		float
Font			font name

Text
This allows you to set the text it will display, by using a printf-string here you can make it dynamic, and example:  "CPU %02.f%%"

AverageSamples 
This allows you to interpolate the X last samples, very useful for for example cpu if you use low/fast updateinterval.



########################################
*(xStatsGraph-name)Bar settings
########################################

A "bar" can have all these settings:

X 			int
Y 			int
Height 			int
Width 			int
RenderMode 		FillOnly|StrokeOnly|FillAndStroke

FillMode 		Solid|LinearGradient|RadialGradient
FillColor		color
FillAlpha		int(0-255)
FillGradientP1Color 	color
FillGradientP1X		int
FillGradientP1Y		int
FillGradientP1Alpha	int
FillGradientP2Color 	color
FillGradientP2X 	int
FillGradientP2Y 	int
FillGradientP2Alpha 	int

StrokeMode 		Solid|LinearGradient|RadialGradient
StrokeColor		color
StrokeAlpha		int
StrokGradientP1Color 	color
StrokGradientP1X	int
StrokGradientP1Y	int
StrokGradientP1Alpha	int
StrokGradientP2Color 	color
StrokGradientP2X 	int
StrokGradientP2Y 	int
StrokGradientP2Alpha 	int

Source			name of source
AverageSamples 		int

Orientation		Horizontal|Vertical
FlipX			false|true
flipY			false|true


########################################
*(xStatsGraph-name)Circle settings
########################################

A "circle" can have all these settings:

X 			int
Y 			int
Height 			int
Width 			int
RenderMode 		FillOnly|StrokeOnly|FillAndStroke

FillMode 		Solid|LinearGradient|RadialGradient
FillColor		color
FillAlpha		int(0-255)
FillGradientP1Color 	color
FillGradientP1X		int
FillGradientP1Y		int
FillGradientP1Alpha	int
FillGradientP2Color 	color
FillGradientP2X 	int
FillGradientP2Y 	int
FillGradientP2Alpha 	int

StrokeMode 		Solid|LinearGradient|RadialGradient
StrokeColor		color
StrokeAlpha		int
StrokGradientP1Color 	color
StrokGradientP1X	int
StrokGradientP1Y	int
StrokGradientP1Alpha	int
StrokGradientP2Color 	color
StrokGradientP2X 	int
StrokGradientP2Y 	int
StrokGradientP2Alpha 	int


AverageSamples 		int
Orientation		Horizontal|Vertical
FlipX			false|true
flipY			false|true




----Actions/Events----

OnLeftClickDown
OnLeftClickUp
OnLeftDoubleClick

OnMiddleClickDown
OnMiddleClickUp
OnMiddleDoubleClick

OnRightClickDown
OnRightClickUp
OnRightDoubleClick

OnX1ClickDown
OnX1ClickUp
OnX1DoubleClick

OnX2ClickDown
OnX2ClickUp
OnX2DoubleClick

OnWheelDown
OnWheelUp

OnKeyDown
OnKeyUp

OnEnter
OnLeave
OnHover


----Bangs----
!xStatsGraphCreate 		"name"
!xStatsGraphCreateSource	"name" "sourcename"
!xStatsGraphCreateElement	"type" "xstatsbargraphname" "metername"
!xStatsGraphDestroy 		"name"
!xStatsGraphAlwaysOnTop 	"name"
!xStatsGraphHook 		"name"
!xStatsGraphHide 		"name"
!xStatsGraphMove 		"name" 
!xStatsGraphMoveBy 		"name"
!xStatsGraphReposition 		"name"
!xStatsGraphRepositionBy 	"name"
!xStatsGraphResize 		"name"
!xStatsGraphResizeBy 		"name"
!xStatsGraphShow 		"name"
!xStatsGraphToggle 		"name"
!xStatsGraphShowPerformancePicker


----Release History----

--0.7
Added both fake and real alphatransparency (thanks to andymon and xlabel source)
Added Circle element, radius is animated.
Added radial gradients
Added orientation for all elements ( vertical or horizontal )
Added flipx and flipy to allow you to flip the axis. (you can make a really nice "mirror" graph with this:P)

--0.6
Added bar and text elements
Added actions/events
Got sick of writing readme so it sucks;P (use the examples or ask me)

--0.5
Massive rework of entire codebase. 
Fixed flickering.
Added support for gradients on both stroke and fill.
Added support for multiple "meters" in each graph.
Added support for multiple "sources" in each graph.

--0.41
Meh, mfc is not worth it.

--0.4
New rendering modes (StrokeOnly, FillOnly and FillAndStroke), different color and alpha settings for stroke and fill.
All rendering is now done through the agg2d abstraction layer for agg (anti-grain geometry), this means it is _much_ easier to code the rendering.

--0.31
Adds support for hookin

--0.3
This release adds support for xpaintclass. 
Also renamed some of the settings for consistency.
Make sure that if you are going to use xpaintclass to set xStatsCpuStatsUpdateInterval to the same as (or lower than) your refreshrate.

--0.2
First public release

--0.1
First alpha.





----Contact----

I am thegeek on efnet and freenode (irc).
You can also reach me by email to okrog@online.no

