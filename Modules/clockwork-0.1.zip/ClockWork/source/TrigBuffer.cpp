/*

	Trigonometric Buffer class, precalculates all the values
	on a circle with given precision (how many pieces the circle is divided into)

*/

#include <math.h>
#include "TrigBuffer.h"

//#define DEBUG
#ifdef DEBUG
#include <stdio.h>
#endif

#define pi 3.141592653589793238462643

TrigBuffer::TrigBuffer(int circle_steps=360)
{
	steps = circle_steps;
	values = new double[circle_steps];
}

TrigBuffer::~TrigBuffer()
{
	delete [] values;
}

double& TrigBuffer::operator[] (int i)
{
	if (i < steps && i >= 0)
		return values[i];
	else
		throw "TrigBuffer: Out of Bounds exception";
}

int TrigBuffer::GetPrecision()
{
	return steps;
}

// pre calculate the values, using shift to set start of circle
void TrigBuffer::Calc(int shift)
{
	double angle;
	#ifdef DEBUG
		FILE *out = fopen("c:\\buffer.log", "w");
	#endif
	for (int i = 0; i<steps; i++)
	{
		angle = 2 * pi * (double)(i+shift) / steps;
		values[i] = trig(angle);
		#ifdef DEBUG
			fprintf(out, "%d: %f - %f \n", i, angle, values[i]);
		#endif
	}
	#ifdef DEBUG
		fclose(out);
	#endif
}

SinBuffer::SinBuffer(int circle_steps=360, int start_shift=0) : TrigBuffer(circle_steps)
{
	Calc(start_shift);
}

double SinBuffer::trig(double i)
{
	return sin(i);
}


CosBuffer::CosBuffer(int circle_steps=360, int start_shift=0) : TrigBuffer(circle_steps)
{
	Calc(start_shift);
}

double CosBuffer::trig(double i)
{
	return cos(i);
}
