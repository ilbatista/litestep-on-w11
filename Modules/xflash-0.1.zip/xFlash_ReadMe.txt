-\\____________________________//-
-//                            \\-
           xFlash  v0.1
	        by Andymon
	 andymon@ls-universe.info
-\\____________________________//-
-//                            \\-

--------
Overview
--------

	Flash Litestep Interface implementation 8)
	
	You can create and modify multiple Flash Elements for Litestep.
	This module only DISPLAYS the FlashObject, if LS Actions are wished the FlashObject must handle them internally!
	
	This is a very early version and it might have bugs!

--------
 xFlash
--------

  ---------------
   xFlash Config
  ---------------
  
  Create a Flash Object:
  ----------------------
  *xFlash <Flashname> "Full Path to SWF-File"
   You probably can also use anything else what IE can handle! Just try it.
  
  
  If you don't want a Rectangular FlashObject you must create a "MaskImage"!
  
  <Flashname>MaskImage IMAGE
   Set a Mask (True Transparent) for the FlashObject.
   USE MAGICPINK for the Transparent Area, the rest of information (color) is totally ignored!
   

  <Flashname>X INT
   Sets the horizontal position of the FlashObject in pixels. 
   Positive value's are relative to the left side of the desktop, 
   negative value's are relative to the right side. 
   You can also make the position relative to the center of the desktop by appending the character 'c'
   after the number ("32c", "-128c") or "Real Negative Values" by adding a '~' before the number ("~10").

  <Flashname>Y INT
   Sets the vertical position of the FlashObject in pixels. 
   Positive value's are relative to the top of the desktop, 
   negative value's are relative to the bottom. 
   You can also make the position relative to the center of the desktop by appending the character 'c'
   after the number ("32c", "-128c") or "Real Negative Values" by adding a '~' before the number ("~10").

  <Flashname>Width INT
   Sets the horizontal size of the FlashObject. 
   If the value is positive then its an absolute size in pixel,
   if negative then its the Screen(Parentlabel) Width minus the specified value. 
   Additionally you can make the size relative to a precentage of the Screen(Parentlabel) Width
   by appending the character '%' after the number ("50%", "-20")..

  <Flashname>Height INT
   Sets the vertical size of the FlashObject. 
   If the value is positive then its an absolute size in pixel,
   if negative then its the Screen(Parentlabel) Height minus the specified value.
   Additionally you can make the size relative to a precentage of the Screen(Parentlabel) Height
   by appending the character '%' after the number ("50%", "-20").

  <Flashname>AlwaysOnTop BOOL
   If this command is present then it makes the FlashObject "always on top". 
   The FlashObject stays above all application windows.

  <Flashname>StartHidden BOOL
   If this command is present then the FlashObject will be initially invisible. 
   It can later be shown using bang commands.

  
  --------------
   xFlash Bangs
  --------------
  
 	!FlashAlwaysOnTop <Flashname> ("true"|"on", "false"|"off" or "toggle"|"switch")
 	
	!FlashHide <Flashname>
	
	!FlashMove <Flashname> X Y
	
	!FlashMoveBy <Flashname> X Y
	
	!FlashReposition <Flashname> X Y WIDTH HEIGHT 
	
	!FlashRepositionBy <Flashname> X Y WIDTH HEIGHT
	
	!FlashResize <Flashname> WIDTH HEIGHT 
	
	!FlashResizeBy <Flashname> WIDTH HEIGHT 
	
	!FlashShow <Flashname>
	
	!FlashToggle <Flashname>


-----------------------------------------------------------------------------
Changes for xFlash
-----------------------------------------------------------------------------

0.1 Inital Release on 03-03-2006, Changes by Andymon


           
           