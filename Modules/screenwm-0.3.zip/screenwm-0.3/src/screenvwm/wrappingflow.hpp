#pragma once
#include <windows.h>

enum FlowDirection
{
	directionLeftDown=1,
	directionLeftUp,
	directionRightDown,
	directionRightUp,
	directionDownRight,
	directionDownLeft,
	directionUpRight,
	directionUpLeft,
};

struct WrappingFlow
{
	WrappingFlow(FlowDirection dir, int minX, int minY, int maxX, int maxY);
	void start(int &x, int &y);
	bool next(int &x, int &y, int stepX, int stepY);
	void wrap(int &x, int &y, int stepX, int stepY);
	bool isInBounds(int x, int y);
	bool isDown();
	bool isRight();
	bool fit(int &x, int &y, int width, int height);
	RECT getRect(int x, int y, int width, int height);
	
	FlowDirection dir;
	int minX, minY;
	int maxX, maxY;
};

//void directionStart(FlowDirection dir, int &x, int &y, int minX, int minY, int maxX, int maxY);
//bool directionNext(FlowDirection dir, int &x, int &y, int minX, int minY, int maxX, int maxY, int stepX, int stepY);
bool directionIsVertical(FlowDirection dir);
int directionCountSteps(FlowDirection dir, int x, int y, int minX, int minY, int maxX, int maxY, int stepX, int stepY);
FlowDirection directionFromString(const char *str);
