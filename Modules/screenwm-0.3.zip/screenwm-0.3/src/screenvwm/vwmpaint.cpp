#include <litestep/lsapi/lsapi.h>
#include <litestep/utility/macros.h>
#include "vwm.h"
#include "trace.hpp"

void VWM::initDrawContext()
{
	HDC windowDrawContext = GetDC(vwmWindow);
	if(!windowDrawContext)
		MessageBox(NULL, "Failed to get a draw context for VWM window.", "ScreenVWM", MB_TOPMOST);
	backBuffer = CreateCompatibleDC(windowDrawContext);
	backBufferMem = CreateCompatibleBitmap(windowDrawContext, windowWidth, windowHeight);
	ReleaseDC(vwmWindow, windowDrawContext);
	
	oldFont = (HFONT)SelectObject(backBuffer, GetStockObject(SYSTEM_FONT));
	
	HBITMAP oldBackBufferMem = (HBITMAP)SelectObject(backBuffer, backBufferMem);
	DeleteObject(oldBackBufferMem);
}

HFONT VWM::loadLabelFont(LayoutSettings *settings)
{
	//int height = -MulDiv(settings->labelFontSize, GetDeviceCaps(backBuffer, LOGPIXELSY), 72);
	int height = settings->labelFontSize;
	HFONT font = CreateFont(height, 0, 0, 0, FW_DONTCARE,
		0,0,0, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, 
		FF_SWISS|DEFAULT_PITCH, settings->labelFont.c_str());
	return font;
}

void VWM::destroyDrawContext()
{
	DeleteDC(backBuffer);
	DeleteObject(backBufferMem);
	
	SelectObject(backBuffer, oldFont);
	for(unsigned ii=0; ii<labelFonts.size(); ii++)
		DeleteObject(labelFonts[ii]);
}

void VWM::forceRedraw(bool forceUpdate)
{
	if(forceUpdate)
		updateNextDraw = true;
	InvalidateRect(vwmWindow, NULL, FALSE);
}

void VWM::onPaint(Message& message)
{
	if(updateNextDraw)
		updateWindowList();
	
	PAINTSTRUCT ps;
	HDC windowDrawContext = BeginPaint(vwmWindow, &ps);
	
	// Don't update window if currently in a drag/drop
	if(!draggingTask)
		tryLayouts();
	
	paintBackground();
	paintDeskBackgrounds();
	
	if(!layoutSettings->hideMinimap) {
		paintMinimapBackgrounds();
		paintMinimapWindows();
	}
	paintTasks();
	paintDeskLabels();
	
	// Flip the back buffer onto the screen
	BitBlt(windowDrawContext, 0, 0, windowWidth, windowHeight, backBuffer, 0, 0, SRCCOPY);
	EndPaint(vwmWindow, &ps);
}

void VWM::paintBackground()
{
	HBRUSH panelBackgroundBrush = CreateSolidBrush(settings->panelBackgroundColor);
	HPEN panelBorderPen = CreatePen(PS_SOLID, 1, settings->panelBorderColor);
	HBRUSH oldBrush = (HBRUSH)SelectObject(backBuffer, panelBackgroundBrush);
	HPEN oldPen = (HPEN)SelectObject(backBuffer, panelBorderPen);
		// Draw the shared background
		Rectangle(backBuffer, 0, 0, windowWidth, windowHeight);
	SelectObject(backBuffer, oldBrush);
	SelectObject(backBuffer, oldPen);
	DeleteObject(panelBackgroundBrush);
	DeleteObject(panelBorderPen);
	
	RECT panelArea;
		panelArea.top = 0;
		panelArea.left = 0;
		panelArea.right = windowWidth;
		panelArea.bottom = windowHeight;
	images.drawImages(backBuffer, panelArea, "panel");
}

void VWM::paintDeskBackgrounds()
{
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		RECT deskArea;
			deskArea.left = desk->panelX;
			deskArea.top = desk->panelY;
			deskArea.right = desk->panelX + desk->panelWidth;
			deskArea.bottom = desk->panelY + desk->panelHeight;
		if(desk->focused)
			images.drawImages(backBuffer, deskArea, "focuseddesk");
		else
			images.drawImages(backBuffer, deskArea, "desk");
	}
}

void VWM::paintMinimapBackgrounds()
{
	SetBkColor(backBuffer, settings->panelBackgroundColor);
	
	HBRUSH vwmBackgroundBrush = CreateSolidBrush(settings->vwmBackgroundColor);
	HPEN vwmBorderPen = CreatePen(PS_SOLID, 1, settings->vwmBorderColor);
	HBRUSH oldBrush = (HBRUSH)SelectObject(backBuffer, vwmBackgroundBrush);
	HPEN oldPen = (HPEN)SelectObject(backBuffer, vwmBorderPen);
	
	// Draw the label, background and border for the VWM display for each desktop
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		
		// Draw minimap background
		SelectObject(backBuffer, vwmBackgroundBrush);
		SelectObject(backBuffer, vwmBorderPen);
		Rectangle(backBuffer,
			desk->minimapX, desk->minimapY,
			desk->minimapX+desk->minimapWidth,
			desk->minimapY+desk->minimapHeight);
	}
	
	SelectObject(backBuffer, oldBrush);
	SelectObject(backBuffer, oldPen);
	DeleteObject(vwmBackgroundBrush);
	DeleteObject(vwmBorderPen);
}

// Draw the label for the each desktop
void VWM::paintDeskLabels()
{
	SelectObject(backBuffer, labelFonts[layoutIndex]);
	SetBkMode(backBuffer, TRANSPARENT);
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		
		string labelText = desk->getLabel();
		SIZE labelSize;
		GetTextExtentPoint32(backBuffer, labelText.c_str(), labelText.length(), &labelSize);
		
		RECT labelRect;
			labelRect.left = desk->labelX;
			labelRect.top = desk->labelY;
			labelRect.right = labelRect.left + labelSize.cx;
			labelRect.bottom = labelRect.top + labelSize.cy;
		
		if(desk->focused)
			SetTextColor(backBuffer, settings->labelColorFocused);
		else
			SetTextColor(backBuffer, settings->labelColor);
		
		DrawText(backBuffer, labelText.c_str(), -1, &labelRect, DT_NOCLIP);
	}
}

struct WindowPainter
{
	HBRUSH windowBrush;
	HPEN pen;
	HBRUSH titleBarBrush;
	HBRUSH focusedTitleBarBrush;
	HBRUSH oldBrush;
	HPEN oldPen;
	RCSettings *settings;
	HDC backBuffer;
	
	WindowPainter(RCSettings *settings, HDC backBuffer)
		:settings(settings), backBuffer(backBuffer)
	{
		windowBrush = CreateSolidBrush(settings->vwmWindowColor);
		titleBarBrush = CreateSolidBrush(settings->vwmTitleBarColor);
		focusedTitleBarBrush = CreateSolidBrush(settings->vwmFocusedTitleBarColor);
		pen = CreatePen(PS_SOLID, 1, settings->vwmWindowBorderColor);
		oldBrush = (HBRUSH)SelectObject(backBuffer, windowBrush);
		oldPen = (HPEN)SelectObject(backBuffer, pen);
	}
	
	~WindowPainter()
	{
		SelectObject(backBuffer, oldBrush);
		SelectObject(backBuffer, oldPen);
		DeleteObject(windowBrush);
		DeleteObject(titleBarBrush);
		DeleteObject(focusedTitleBarBrush);
		DeleteObject(pen);
	}
	
	void paintWindow(WindowData *window, RECT r, HICON icon, POINT iconPos)
	{
		Rectangle(backBuffer, r.left, r.top, r.right, r.bottom);
		
		RECT rtitle;
		if(settings->minimapTitleBarsThickness && !window->isPopup)
		{
			if(window->focused)
				SelectObject(backBuffer, focusedTitleBarBrush);
			else
				SelectObject(backBuffer, titleBarBrush);
			
			rtitle.left = r.left;
			rtitle.top = r.top;
			rtitle.right = r.right;
			rtitle.bottom = r.top + settings->minimapTitleBarsThickness;
			// save the bottom of the titlebar as the top of the rest of the window
			r.top = rtitle.bottom;
			
			Rectangle(backBuffer,
				rtitle.left, rtitle.top, rtitle.right, rtitle.bottom);
			SelectObject(backBuffer, windowBrush);
		}
		
		int iconSize = settings->minimapIconSize;
		if(icon && iconSize)
			DrawIconEx(backBuffer, iconPos.x, iconPos.y, icon, iconSize, iconSize, 0, NULL, DI_NORMAL);
	}
};

void VWM::paintMinimapWindows()
{
	WindowPainter painter(settings, backBuffer);
	
	for(vector<HWND>::reverse_iterator it = zOrder.rbegin(); it != zOrder.rend(); it++)
	{
		HWND handle = *it;
		if(windowsByHandle.find(handle) == windowsByHandle.end())
			continue;
		WindowData *windowData = windowsByHandle[handle];
		
		if(windowData->minimized)
			continue;
		
		VirtualDesktop *desk = windowData->desk;
		if(!desk)
			desk = currentDesktop;
		RECT r;
		POINT iconPos;
		screenToMinimapPos(desk, windowData->screenPos, &r, &iconPos);
			r.left += desk->minimapX;
			r.right += desk->minimapX;
			r.top += desk->minimapY;
			r.bottom += desk->minimapY;
			iconPos.x += desk->minimapX;
			iconPos.y += desk->minimapY;
		
		if(!windowData->parent && !windowData->isPopup)
			painter.paintWindow(windowData, r, windowData->getIcon(settings->minimapIconSize), iconPos);
		else
			painter.paintWindow(windowData, r, NULL, iconPos);
	}
}

void VWM::paintTasks()
{
	HBRUSH normalBrush = CreateSolidBrush(settings->tasksBackColor);
	HBRUSH minimizedBrush = CreateSolidBrush(settings->tasksBackColorMin);
	HBRUSH focusedBrush = CreateSolidBrush(settings->tasksBackColorFocused);
	
	HPEN normalPen = CreatePen(PS_SOLID, layoutSettings->tasksBorderThickness, settings->tasksBorderColor);
	HPEN minimizedPen = CreatePen(PS_SOLID, layoutSettings->tasksBorderThickness, settings->tasksBorderColorMin);
	HPEN focusedPen = CreatePen(PS_SOLID, layoutSettings->tasksBorderThickness, settings->tasksBorderColorFocused);
	
	HBRUSH oldBrush = (HBRUSH)SelectObject(backBuffer, normalBrush);
	HPEN oldPen = (HPEN)SelectObject(backBuffer, normalPen);
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		int row;
		int col;
		
		WrappingFlow flow(settings->flowDirection, 0, 0, desk->tasksNumCols-1, desk->tasksNumRows-1);
		flow.start(col, row);
		
		for(unsigned jj=0; jj<desk->tasks.size(); jj++)
		{
			WindowData *task = desk->tasks[jj];
			
			int x = desk->tasksX + desk->tasksIconArea * col;
			int y = desk->tasksY + desk->tasksIconArea * row;
			int offsetX, offsetY;
			bool transparent;
			
			IntersectClipRect(backBuffer, x, y, x+desk->tasksIconArea, y+desk->tasksIconArea);
			
			if(task->minimized) {
				SelectObject(backBuffer, minimizedBrush);
				SelectObject(backBuffer, minimizedPen);
				offsetX = settings->tasksOffsetXMin;
				offsetY = settings->tasksOffsetYMin;
				transparent = settings->tasksIconTransparentMin;
			}
			else if(task->focused || task->handle==draggingTask || task->handle==pendingMinimize)
			{
				SelectObject(backBuffer, focusedBrush);
				SelectObject(backBuffer, focusedPen);
				offsetX = settings->tasksOffsetXFocused;
				offsetY = settings->tasksOffsetYFocused;
				transparent = settings->tasksIconTransparentFocused;
			}
			else
			{
				SelectObject(backBuffer, normalBrush);
				SelectObject(backBuffer, normalPen);
				offsetX = settings->tasksOffsetX;
				offsetY = settings->tasksOffsetY;
				transparent = settings->tasksIconTransparent;
			}
			
			if(transparent)
				SetBkMode(backBuffer, TRANSPARENT);
			else
				Rectangle(backBuffer, x, y, x+desk->tasksIconArea, y+desk->tasksIconArea);
			
			// Don't draw the icon for a task which is being dragged
			if(task->handle != draggingTask)
			{
				HICON icon = task->getIcon(desk->tasksIconSize);
				
				DrawIconEx(backBuffer,
					x+layoutSettings->tasksBorderThickness+offsetX, y+layoutSettings->tasksBorderThickness+offsetY,
					icon,
					desk->tasksIconSize, desk->tasksIconSize,
					0, NULL, DI_NORMAL);
			}
			
			SelectClipRgn(backBuffer, NULL);
			
			flow.next(col, row, 1, 1);
		}
	}
	
	SelectObject(backBuffer, oldPen);
	SelectObject(backBuffer, oldBrush);
	
	DeleteObject(normalBrush);
	DeleteObject(minimizedBrush);
	DeleteObject(focusedBrush);
	DeleteObject(normalPen);
	DeleteObject(minimizedPen);
	DeleteObject(focusedPen);
}