#pragma once
#include <windows.h>
#include <map>
using std::map;

class RelCoord
{
public:
	RelCoord();
	RelCoord(string str);
	int get(int maxVal);
	
private:
	string val;
};

struct SWMImage
{
	~SWMImage();
	
	HBITMAP image;
	string filename;
	int width, height;
	int mode;
	RelCoord left, top, right, bottom;
};

class SWMImageManager
{
public:
	void loadImages();
	int parseMode(const char *mode);
	void parseLine(const char *buf);
	void destroyImages();
	void drawImages(HDC drawContext, RECT area, string areaName);
	
private:
	map<string, vector<SWMImage*>*> imageSets;
};
