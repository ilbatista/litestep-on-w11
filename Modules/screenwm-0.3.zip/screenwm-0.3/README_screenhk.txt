ScreenHK - a Litestep hotkey module
By Jim Babcock and the Litestep team


ScreenHK provides hotkeys and hotkey groups. To define a hotkey, put
  *Hotkey <meta> <key> <command>
For example,
  *Hotkey Ctrl+Shift R !recycle
Would make pressing Ctrl+Shift+R recycle Litestep. If you have a lot of
hotkeys, however, you may wish to group them together. Hotkeys which are more
than one key long, with a common prefix. To define a hotkey group,
  *HotkeyGroup <group>
  *Hotkey <meta> <key> !hotkeyGroup <group>
  *GroupedHotkey <group> <meta> <key> <command>
For example, to make Ctrl+Shift+A,R open the run menu and Ctrl+Shift+A,N open
Notepad, you could put
  *HotkeyGroup Programs
  *Hotkey Ctrl+Shift A !hotkeyGroup Programs
  *GroupedHotkey Programs Ctrl+Shift R !run
  *GroupedHotkey Programs Ctrl+Shift N notepad


Variables
---------
HotkeyLoadExplorerKeys
HotkeyNoWinKeyPopup
LSNoShellWarning
ExplorerNoWarn

Legalities
----------
Copyright (C) 2008 James Babcock. This program is partially derived from the
Litestep shell. Copyright (C) 1997-2001 The Litestep Development Team.
Copyright (C) 1997-98 Francis Gastellu (aka Lone Runner/Aegis).

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.





