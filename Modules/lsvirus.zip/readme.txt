--------------------------------------------------------------------
:::::::::::::::::::::::::::[Introduction]:::::::::::::::::::::::::::
--------------------------------------------------------------------

LSVirus is a ScriptHost interface for LS. It loads as a normal modu-
le and can be used to run scripts. Currently it supports VB scripts 
but in the futrure it will support all avalible languages.
The reason I developed this was that I needed a slightly more power-
ful script engine then mzScript since I needed arrayes and a few 
such things. 
LSVirus is a project name and will most likely only be used for this 
build. In the future I intend to improve *alot* of things and also
I intend to make COM wrappers for many of the most common LS modules 
to allow you to inerract with them in a simple manner.
This release is only to see if there is an interest for a scripting
host based scripting enviornement.
Also for this to work you need to have Microsoft Scriptinghost 
installed. This can freely (?) be downloaded from:

	http://www.microsoft.com/scripting

:/ / / / / / / / / / ! ! ! W A R N I N G ! ! ! / / / / / / / / / /:
:/ / / / / / / / / / ! ! ! W A R N I N G ! ! ! / / / / / / / / / /:
:/ / / / / / / / / / ! ! ! W A R N I N G ! ! ! / / / / / / / / / /:
:                                                                 :
: Since this is a powerfull scripting enviornment a script could  :
: potentionaly damage your computer! Scripts have full access to  :
: your computer if they wish they can erase all files on the HD;  :
:       send SPAM from you or even infect you with viruses.       :
:                                                                 :
:                        USE WITH CARE !                          :
:                                                                 :
:/ / / / / / / / / / ! ! ! W A R N I N G ! ! ! / / / / / / / / / /:
:/ / / / / / / / / / ! ! ! W A R N I N G ! ! ! / / / / / / / / / /:
:/ / / / / / / / / / ! ! ! W A R N I N G ! ! ! / / / / / / / / / /:


--------------------------------------------------------------------
:::::::::::::::::::::::::::::[Contact]::::::::::::::::::::::::::::::
--------------------------------------------------------------------
Michael Medin aka. MickeM <mickem@medin.nu>
http://www.medin.nu
Professorsv�gen 25 (3tr)
SE-977 51  LULEAA
SWEDEN


--------------------------------------------------------------------
:::::::::::::::::::::::::::[Instructions]:::::::::::::::::::::::::::
--------------------------------------------------------------------
Load the module: LoadModule "$LitestepDir$LSVirus.dll"
The module needs to be in the litestep directory or it wont find the 
lsapi.dll (I could be wrong here but thats the way it was here). 
After you have loaded the module the script will parse any script 
tags in the step.rc file.
for instance:

*LSVirus MsgBox "Hello I got a virus"

Would popup a dialog when you load litestep. The script may be any
length and since it is VB you may create variables, functions, etc. 
For instance:

*LSVirus Sub test(name)
*LSVirus 	MsgBox "Hello I got a virus" & vbCrLf & "It is named: " & name
*LSVirus End Sub
*LSVirus test("Loveletter")

Would first create a function called test and then afterward execute it.
Naturaly LSVirus supports bang commands.

*LSVirus Sub core_OnBangCommand(cmd, arg) 
*LSVirus 	Select Case cmd
*LSVirus 	case "!bang1":
*LSVirus 		MsgBox "This is bang1 speaking..."
*LSVirus 	case "!bang2":
*LSVirus 		MsgBox "This is bang2 speaking..."
*LSVirus 	case "!bang3":
*LSVirus 		MsgBox "This is bang3 speaking..."
*LSVirus 	end select
*LSVirus End Sub
*LSVirus 
*LSVirus core.registerBang "!bang1"
*LSVirus core.registerBang "!bang2"
*LSVirus core.registerBang "!bang3"
*LSVirus 
*LSVirus core.executeBang "!about"

This will first add a sub (the bang handler) and then register the 
bangs it wish to be able to handle and finaly execute a simple bang 
command.


--------------------------------------------------------------------
:::::::::::::::::::::::::::::[Reference]::::::::::::::::::::::::::::
--------------------------------------------------------------------
Step.rc commands:

*LSVirus <code>
	Add VBScript code to the VB parser. This will be ececuted 
	after the  module has read all lines.

Bang commands:

!LSVirusRunCode <code>
	Add VBScript code to the VB parser. This is executed instantly.

!LSVirusRunStep <id>
	Add VBScript code to the VB parser. This will read all lines 
	<id> from the step.rc and parse them as if they were VB code. 
	This is infact what happends at startup. The module calls:
	!LSVirusRunStep "*LSVirus".
	This is executed as soon as all code has been added.

!LSVirusRunFile <file>
	Add VBScript code to the VB parser. This will read the file 
	<file> and parse them as if they were VB code. This is exe-
	cuted as soon as all code has been added.

