// LMA1.0 
/****************************************************************************
0.3.2
	rebuilt the module from the source of the exe because I lost the code

****************************************************************************/

#define WIN32_LEAN_AND_MEAN

#include "globals.h"
#include "lsmath.h"
#include "utilities.h"
#include "fileio.h"
#include "math2.h"
Lsmath *lsmath; // The module


//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst); // missed by the module wizard (b3)
	lsmath = new Lsmath(ParentWnd, code);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete lsmath;
}


//=========================================================
// Bang commands
//=========================================================
void BangmathequationFunction(HWND caller, LPCSTR args) {
	lsmath->Bangmathequation(caller, args);
}


void BangmathfileFunction(HWND caller, LPCSTR args) {
	lsmath->Bangmathfile(caller, args);
}


void BangmathsaveFunction(HWND caller, LPCSTR args) {
	lsmath->Bangmathsave(caller, args);
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Lsmath::Lsmath(HWND parentWnd, int& code):Window(szAppName) {
	int msgs[] = {LM_GETREVID, 0};
	
	if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
					  0, 0, 0, 0, parentWnd)) {
	    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
		code = 1;
		return;
	}
	
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
	
	DEBUG = GetRCBool("MathDebug",TRUE);
	WARNINGS = GetRCBool("MathWarnings",TRUE);
	ERRORS = GetRCBool("MathErrors",TRUE);
	GET_FROM_RC = GetRCBool("MathReadOnlyRCVars",TRUE);

	AddBangCommand("!mathequation",BangmathequationFunction);
	AddBangCommand("!mathfile",BangmathfileFunction);
	AddBangCommand("!mathsave",BangmathsaveFunction);

	code = 0;
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
Lsmath::~Lsmath() {
	int msgs[] = {LM_GETREVID, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	RemoveBangCommand("!mathequation");
	RemoveBangCommand("!mathfile");
	RemoveBangCommand("!mathsave");

	destroyWindow();
}


//=========================================================
// Registered messages
//=========================================================

void Lsmath::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,          LM_GETREVID)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void Lsmath::onEndSession(Message& message) {
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void Lsmath::onGetRevId(Message& message) {
	char* buf = (char*)(message.lParam);

	switch (message.wParam) {
	case 0:
		sprintf(buf, "lsmath.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
    case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
    default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}

void Lsmath::onSysCommand(Message& message) {
	if (message.wParam == SC_CLOSE) {
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	} else {
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
	}
}


//=========================================================
// Bang command handling
//=========================================================
void Lsmath::Bangmathfile(HWND caller, LPCSTR args) {
	debugprint(args);
	filename=std::string(args);
	readlist(filename.c_str());
	debugprintlist();
}

void Lsmath::Bangmathequation(HWND caller, LPCSTR args) {
	debugprint(args);
	equation(tokenize(std::string(args)));
}

void Lsmath::Bangmathsave(HWND caller, LPCSTR args) {
	debugprint(filename.c_str());
	savelist(filename.c_str());
}