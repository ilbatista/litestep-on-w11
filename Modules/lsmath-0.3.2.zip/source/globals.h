#ifndef _GLOBALS_H_
#define _GLOBALS_H_

#define MAX_LINE_LENGTH 4096
#define WIN32_LEAN_AND_MEAN

#include <string>
bool DEBUG;
bool GET_FROM_RC;
bool WARNINGS;
bool ERRORS;

const char szAppName[] = "Lsmath"; // Our window class, etc
const char rcsRevision[] = "$Revision: 0.3.2 $"; // Our Version
const char rcsId[] = "$Id: lsmath.cpp,v 0.3.2 18:17:56 Fallout Exp $"; // The Full RCS ID.

#ifndef DATASTRUCT
struct data {//all data variables are initialized to be the integer 0
	union {
		double value;
		int op;
	};
	std::string var;//variable name, if exists
	bool isop,isint,unary,exists;
	data() {value=0;isop=false;isint=true;var="";unary=false;exists=false;};
};
#define DATASTRUCT
#endif

#endif