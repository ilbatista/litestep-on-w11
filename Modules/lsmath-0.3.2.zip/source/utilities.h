#ifndef _UTIL_H_
#define _UTIL_H_

#include "globals.h"
#include <windows.h>
#include <stdio.h>


void debugprint(LPCSTR pszMessage, UINT uExtraFlags = 0) {
    if(DEBUG) {
		MessageBox(NULL, pszMessage, szAppName,
		    MB_OK | MB_TOPMOST | MB_SETFOREGROUND | uExtraFlags);
	}
}

void sendwarning(LPCSTR message, LPCSTR title) {
	if(DEBUG || WARNINGS || ERRORS) {
		MessageBox(NULL, message, title, MB_OK | MB_TOPMOST | MB_SETFOREGROUND);
	}
}

void senderror(LPCSTR message, LPCSTR title) {
	if(DEBUG || ERRORS) {
		MessageBox(NULL, message, title, MB_OK | MB_TOPMOST | MB_SETFOREGROUND);
	}
}

std::string makestr(double x,bool isint) {
	char temp[MAX_LINE_LENGTH];
	if(isint) sprintf(temp,"%d",int(x));
	else sprintf(temp,"%f",x);
	return std::string(temp);
}

#endif