#ifndef FILEIO_H
#define FILEIO_H

#include "globals.h"
#include <string>
#include <list>
#include <fstream>
/*
ok I know this is real bad coding and I will change it when I get around 
to it but this was about 5 minutes of work just to get files working so I could
test how the rest of it works

provides:
readlist(const char * filename)		reads variables from filename
data queryvalue(string s)			returns a struct data that contains a variable 
									corresponding to s
void savevar(data d)				saves a variable to the list for future searching 
void savelist(const char *filename)	saves variables to filename

file structure:
files read by this need to be in the following structure 

varname value
varname2 value
;;;
the rest of the file

lines that do not begin with a letter or underscore are not parsed
variables cannot begin with a number but if they do, they will be read into
the list, they will not however be able to be used in an equation spaces are 
ignored except where required

Parsing stops before the end of the file when a line is reached that starts
with ;;; so any variables that are not numbers or are not in acceptable format
can still be placed in the file

also lines that start with the following are not parsed:
IF
ENDIF
ELSE


  

  
	


  
	
file is case sensitive and I plan on keeping it that way
*/

#ifndef DATASTRUCT
//should get defined in math2.h but it is here as well

/*
this is the data type that holds a token of information from the equation
regardless if that data is a value, or an operation, or a variable
*/
struct data {//all data variables are initialized to be the integer 0
	union {
		double value;
		int op;
	};
	std::string var;//variable name, if exists
	bool isop,isint,unary,exists;
	data() {value=0;isop=false;isint=true;var="";unary=false;exists=false;};
};
#define DATASTRUCT
#endif


//data type for every line from the file
struct data2 {
	data d;
	std::string line;
	bool read;
};

//global variable that contains the variables from the file, as well as the other lines
std::list<data2> varlist;

/*
readlist(filename)
pre: filename is a string representing a path to a file that exists and is in a decent format
post:varlist contains the variables from within the file
*/
void readlist(const char *filename) {
	std::ifstream file(filename);
	if(!file) {
		sendwarning("Does not exist",filename);
	}
	
	std::string temp;//a temporary string(I am after all a perl writer)
	data2 d;//a line from the file
	int ct;//the current charactor in d.line
	
	std::getline(file,d.line);
	file.ignore(0,'\n');//this was what was wrong in lsmath-0.3.1, I hope it works now
						//how I wish I could chomp; :(
	
	varlist.clear();//it would make no sense to have something in varlist before anything
					//is added to it
	//if(!d.line.length()) return;//??I think this is wrong
	if(!file) {
		sendwarning("File empty",filename);
		return;//this should be better
	}
	while(file && !(d.line.c_str()[0]==';' &&
		d.line.c_str()[1]==';' &&
		d.line.c_str()[2]==';')) {//while there is still important stuff left in the file
		ct=0;//reset ct
		temp="";//reset temp
		d.read=false;//the line isn't read yet

		while(d.line.c_str()[ct]==' ' || d.line.c_str()[ct]=='	') ++ct;
		if(((d.line.c_str()[ct]>='A' && d.line.c_str()[ct]<='Z') || 
		   (d.line.c_str()[ct]>='a' && d.line.c_str()[ct]<='z') || 
		   d.line.c_str()[ct]=='_') && d.line.substr(0,2)!="IF" && 
		   d.line.substr(0,4)!="ELSE" && d.line.substr(0,5)!="ENDIF") {
			d.read=true;
			while((d.line.c_str()[ct]>='A' && d.line.c_str()[ct]<='Z') || 
				  (d.line.c_str()[ct]>='a' && d.line.c_str()[ct]<='z') || 
				  (d.line.c_str()[ct]>='0' && d.line.c_str()[ct]<='9') || d.line.c_str()[ct]=='_') {
				temp+=d.line.c_str()[ct];
				++ct;
			}
			d.d.var=temp;
			temp="";
			while(d.line.c_str()[ct]==' ' || d.line.c_str()[ct]=='	') ++ct;
			if(d.line.c_str()[ct]=='-') {
				temp+=d.line.c_str()[ct];
				++ct;
			}
			while(d.line.c_str()[ct]>='0' && d.line.c_str()[ct]<='9') {
				temp+=d.line.c_str()[ct];
				++ct;
			}
			if(d.line.c_str()[ct]=='.') {
				temp+=d.line.c_str()[ct];
				++ct;
				d.d.isint=false;
			}
			while(d.line.c_str()[ct]>='0' && d.line.c_str()[ct]<='9') {
				temp+=d.line.c_str()[ct];
				++ct;
			}
			d.d.value=atof(temp.c_str());
			d.d.exists=true;
		}
		varlist.push_back(d);
		std::getline(file,d.line);
		file.ignore(0,'\n');
		d.read=false;
	}
	while(file) {//get the rest of the file
		varlist.push_back(d);
		std::getline(file,d.line);
		file.ignore(0,'\n');
	}
	if(d.line.length())	varlist.push_back(d);
		//push the last element on the list 2 times so it isn't deleted
	file.close();
}
	

data queryvalue(std::string s) {
	for (std::list<data2>::const_iterator cti = varlist.begin(); cti!=varlist.end(); cti++) {
		if((*cti).d.var==s) {
			return (*cti).d;
		}
	}
	data zero;
	return zero;
}

void savevar(data d) {
	for (std::list<data2>::iterator cti = varlist.begin(); cti!=varlist.end(); cti++) {
		if((*cti).d.var==d.var) {
			(*cti).d=d;
			return;
		}
	}
}
void savelist(const char *filename) {
	std::ofstream file(filename);
	for (std::list<data2>::iterator cti = varlist.begin(); cti!=varlist.end(); cti++) {
		if((*cti).read) {
			if((*cti).d.isint) file<<(*cti).d.var<<'	'<<int((*cti).d.value)<<std::endl;
			else file<<(*cti).d.var<<'	'<<(*cti).d.value<<std::endl;
		} else file<<(*cti).line<<std::endl;
	}
	file.close();
}

void debugprintlist() {
	if(DEBUG) {
		std::string temp;
		for (std::list<data2>::iterator cti = varlist.begin(); cti!=varlist.end(); cti++) {
			if((*cti).read) {
				temp = (*cti).d.var + std::string(" = ") + makestr((*cti).d.value,(*cti).d.isint);
				debugprint(temp.c_str());
			} else {
				debugprint((*cti).line.c_str());
			}
		}
	}
}
data getrc(std::string s) {
	TCHAR buf[MAX_LINE_LENGTH];
	data toreturn;
	std::string str;
	GetRCString(s.c_str(),buf,"",MAX_LINE_LENGTH-1);
	str=std::string(buf);
	std::string temp="";
	int ct=0;
	if(str.c_str()[ct]=='-') {
		temp+=str.c_str()[ct];
		++ct;
	}
	while(str.c_str()[ct]>='0' && str.c_str()[ct]<='9') {
		temp+=str.c_str()[ct];
		++ct;
		toreturn.exists=true;
	}
	if(str.c_str()[ct]=='.') {
		temp+=str.c_str()[ct];
		++ct;
		toreturn.isint=false;
	}
	while(str.c_str()[ct]>='0' && str.c_str()[ct]<='9') {
		temp+=str.c_str()[ct];
		++ct;
	}
	toreturn.value=atof(temp.c_str());
	return toreturn;
}
	

#endif