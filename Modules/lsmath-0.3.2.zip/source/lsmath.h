// DO NOT DELETE NEXT LINE
// LMA1.0 
/*
LiteStep Module AppWizard
*/

#ifndef __lsmath_H
#define __lsmath_H



#include "globals.h"
#include <windows.h>
#include <string>
#include "C:\lsmodules\cur_src\lsapi\lsapi.h"
#include "C:\lsmodules\cur_src\lsapi\lswinbase.h"
#include "utilities.h"

#pragma warning(disable:4800)//int to bool, get rid of those stupid warnings, I know what I am doing

class Lsmath : public Window {
public:
	Lsmath(HWND parentWnd, int& code);
	~Lsmath();

	void Bangmathequation(HWND, LPCSTR);
	void Bangmathfile(HWND, LPCSTR);
	void Bangmathsave(HWND, LPCSTR);
private:
	virtual void windowProc(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);

	std::string filename;
};

void BangmathequationFunction(HWND, LPCSTR);
void BangmathfileFunction(HWND, LPCSTR);
void BangmathsaveFunction(HWND, LPCSTR);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
