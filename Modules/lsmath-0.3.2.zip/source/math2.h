#ifndef MATH2_H
#define MATH2_H
#include "globals.h"
#include <string>
#include <list>
#include <windows.h>
#include <stdio.h>

#ifdef DEBUGOUTPUT
#include <iostream>
#endif

#include "fileio.h"


/*** this header provides the following:
struct data			contains a token of data, either an operand or an operation
	double value	if struct contains an operand, its value is here
	int op			if struct contains an operation, its code is here
	string var		if struct contains an operand and that operand came from a 
					variable the variable's name is stored here
	bool isop		true if operation
	bool isint		true if value is an integer
	bool unary		true if operation and operation is unary
					(only affects one operand)
	bool exists		true if a variable exists (defined in lsmathfile)

data equation(list<data>)	solves the equation provided by list
int equation.error			1 if there was an error solving equation 0 else
list<data> tokenize(string) tokenizes the equation so that equation() can use it
string tostr(int)			for user output of the operators

changes:
7/21/2003
---------
fixed #/0 - now returns 0 and sets error to 1
fixed #%0 - now returns 0 and sets error to 1
fixed some integer operations could return doubles when 
	  they weren't suppossed to

7/10/2003
---------
fixed unary +,- after a )
added conditional operator
fixed assignment operators should now be evaluated right to left
//*/
#ifndef DATASTRUCT
struct data {//all data variables are initialized to be the integer 0
	union {
		double value;
		int op;
	};
	std::string var;//variable name, if exists
	bool isop,isint,unary,exists;
	data() {value=0;isop=false;isint=true;var="";unary=false;exists=false;};
};
#define DATASTRUCT
#endif

class matheq {
public:
	//constructor, clears everything and sets variables to 0
	matheq() {precedencemod=0; error=0; eqcalc.clear(); eqoperations.clear();};
	
	//the functor, makes this class act as a function
	data operator() (std::list<data>);
	
	//public data, says if an error occurred (didn't want exceptions everywhere)
	int error;
	
	
private:
	//contains a stack of variables and values
	std::list<data> eqcalc;
	
	//contains a stack of operations
	std::list<data> eqoperations;
	
	//I don't think I use this
	//TODO: delete
	int precedencemod;
	
	//does the top operation in eqoperations 
	//and uses the top needed variables in eqcalc
	void doop();
	
	//returns the precedence of an operation
	int precedence(int,int);
} equation;

//tokenizes an equation into a list of data objects
std::list<data> tokenize(std::string);

//converts the integer representation of an operation into it's printed
//counterpart
std::string tostr(int);
/*
op	int
-- -----
(	100
)	101
!	1
~	2
*	3
%	4
/	5
+	6
-	7
^	8
<	9
>	10
=	11
&	12
|	13
<<	14
<<	15
!=	16
~=	17
*=	18
%=	19
/=	20
+=	21
-=	22
^=	23
<=	24
>=	25
==	26
&=	27
|=	28
&&	29
||  30
<<= 31
>>= 32

*/


/*-----------------------------------------------------------------------------
														   Implementation below
//*/
std::list<data> tokenize(std::string s) {
	std::list<data> l;//start with an empty list
	std::string temp;//temporary string variable
	data tempdata;//current data variable to be pushed onto the list
	int ct=0;//position in s
	while(ct<s.length()) {
		
		//initialize temp data every time through the loop
		temp="";
		tempdata.unary=false;
		tempdata.isint=true;
		tempdata.isop=false;
		tempdata.value=0;
		tempdata.var="";
		
		//basically everything is either a number, a variable, or an operation
		//if temp is a number...
		if(s.c_str()[ct]>='0' && s.c_str()[ct]<='9') {
			//get the whole number
			while(s.c_str()[ct]>='0' && s.c_str()[ct]<='9') {
				temp+=s.c_str()[ct];
				++ct;
			}
			//if there is a decimal point then the number is a double value
			if(s.c_str()[ct]=='.') {
				temp+=s.c_str()[ct];//so record the dot
				++ct;
				tempdata.isint=false;//and set isint to false
			}
			//get the fractional part of the number
			while(s.c_str()[ct]>='0' && s.c_str()[ct]<='9') {
				temp+=s.c_str()[ct];
				++ct;
			}
			
			//turn the string into a usable number
			tempdata.value=atof(temp.c_str());
			
			//and push it into the list of tokens to return
			l.push_back(tempdata);
			
			//after doing this whole thing ct has moved one place too far
			//so fix it
			--ct;
			
		//else if it begins with a letter or an underscore
		//it is a variable...
		} else if((s.c_str()[ct]>='A' && s.c_str()[ct]<='Z') || 
			      (s.c_str()[ct]>='a' && s.c_str()[ct]<='z') || 
				  s.c_str()[ct]=='_') {
			
			//get the alpha-numeric token for the variable
			while((s.c_str()[ct]>='A' && s.c_str()[ct]<='Z') || 
				  (s.c_str()[ct]>='a' && s.c_str()[ct]<='z') || 
				  (s.c_str()[ct]>='0' && s.c_str()[ct]<='9') || 
				  s.c_str()[ct]=='_') {
				temp+=s.c_str()[ct];
				++ct;
			}
			
			//ask for the value of the variable from lsmathfile
			tempdata=queryvalue(temp);
			//if that fails and MathReadOnlyRCVars is set then
			//try to get the data from a litestep evar of the same name
			if(!tempdata.exists && GET_FROM_RC) {
				tempdata=getrc(temp);
			}
			//if even that fails and MathDebug or MathWarnings is set then
			//warn 
			if(!tempdata.exists) {
				sendwarning("Variable does not exist\n using 0 instead",
							temp.c_str());
			}
			
			//once all this is done then save the variable name with it's value
			tempdata.var=temp;
			
			//and push it into the list of tokens to return
			l.push_back(tempdata);
			
			//after doing this whole thing ct has moved one place too far
			//so fix it (doesn't this seem a little familiar)
			--ct;
			
		// else it is an operation, unless it is whitespace	
		} else if(s.c_str()[ct]!=' ') {
			//since it is an operation set the operation flag in isop
			tempdata.isop=true;
			
			//and retrieve the value for the operation
			//TODO: warn user of module when they write invalid code
			//		right now gives wierd results
			switch(s.c_str()[ct]) {
			case '(':
				tempdata.op=100;
				break;
			case ')':
				tempdata.op=101;
				break;
			case '?':
				tempdata.op=102;
				break;
			case ':':
				tempdata.op=103;
				break;
			case '!':
				tempdata.op=1;
				tempdata.unary=true;//logical not is always unary
				break;
			case '~':
				tempdata.op=2;
				tempdata.unary=true;//bitwise not is always unary
				break;
			case '*':
				tempdata.op=3;
				break;
			case '%':
				tempdata.op=4;
				break;
			case '/':
				tempdata.op=5;
				break;
			case '+':
				//'+' is unary if it follows an operation(not ')') or is the
				//first character
				if(ct==0) {
					tempdata.unary=true;
				} else if(l.back().isop && l.back().op!=101) {
					tempdata.unary=true;
				}
				tempdata.op=6;
				break;
			case '-':
				//'-' is unary if it follows an operation(not ')') or is the
				//first character
				if(ct==0) {
					tempdata.unary=true;
				} else if(l.back().isop && l.back().op!=101) {
					tempdata.unary=true;
				}
				tempdata.op=7;
				break;
			case '^':
				tempdata.op=8;
				break;
			case '<':
				tempdata.op=9;
				break;
			case '>':
				tempdata.op=10;
				break;
			case '=':
				tempdata.op=11;
				break;
			case '&':
				tempdata.op=12;
				break;
			case '|':
				tempdata.op=13;
				break;
			}
			//for multi-char operations keep figuring out what operation it is
			switch(s.c_str()[ct+1]) {
			case '<':
				if(s.c_str()[ct]=='<') {//shift left
					tempdata.op=14;
					if(s.c_str()[ct+2]=='=') tempdata.op+=17;//shl assignment
				}
				break;
			case '>':
				if(s.c_str()[ct]=='>') {//shift right
					tempdata.op=15;
					if(s.c_str()[ct+2]=='=') tempdata.op+=17;//shr assignment
				}
				break;
			case '=':
				//all the assignments, equalities, and inequalities
				if(tempdata.op>0 && tempdata.op<14) tempdata.op+=15;
				break;
			case '&'://logical and
				if(s.c_str()[ct]=='&') tempdata.op=29;
				break;
			case '|'://logical or
				if(s.c_str()[ct]=='|') tempdata.op=30;
				break;
			}
			if(tempdata.op>13 && tempdata.op<100) ++ct;//more than 1 char
			if(tempdata.op>30 && tempdata.op<100) ++ct;//3 char operations
			//it is still a data object so push it on the stack
			l.push_back(tempdata);
		}
		//if it wasn't mentioned above it is treated as whitespace
		//(which is wrong) user should be warned
		++ct;
	}
	return l;
}
std::string tostr(int i) {//just a simple conversion
	std::string s("");
	switch(i) {
	case 100:
		s="(";
		break;
	case 101:
		s=")";
		break;
	case 102:
		s="?";
		break;
	case 103:
		s=":";
		break;
	case 1:
		s="!";
		break;
	case 2:
		s="~";
		break;
	case 3:
		s="*";
		break;
	case 4:
		s="%";
		break;
	case 5:
		s="/";
		break;
	case 6:
		s="+";
		break;
	case 7:
		s="-";
		break;
	case 8:
		s="^";
		break;
	case 9:
		s="<";
		break;
	case 10:
		s=">";
		break;
	case 11:
		s="=";
		break;
	case 12:
		s="&";
		break;
	case 13:
		s="|";
		break;
	case 14:
		s="<<";
		break;
	case 15:
		s=">>";
		break;
	case 16:
		s="!=";
		break;
	case 17:
		s="~=";
		break;
	case 18:
		s="*=";
		break;
	case 19:
		s="%=";
		break;
	case 20:
		s="/=";
		break;
	case 21:
		s="+=";
		break;
	case 22:
		s="-=";
		break;
	case 23:
		s="^=";
		break;
	case 24:
		s="<=";
		break;
	case 25:
		s=">=";
		break;
	case 26:
		s="==";
		break;
	case 27:
		s="&=";
		break;
	case 28:
		s="|=";
		break;
	case 29:
		s="&&";
		break;
	case 30:
		s="||";
		break;
	case 31:
		s="<<=";
		break;
	case 32:
		s=">>=";
		break;
	}
	return s;
}

//here is the meat of the program...
data matheq::operator ()(std::list<data> l) {
	
	//initialize everything
	precedencemod=0;
	error=0;
	int condcount;
	eqcalc.clear();
	eqoperations.clear();
	//only allow calculations if there is data in the eqcalc list
	bool allowcalculations=false;
	//iterator for the data objects
	std::list<data>::iterator lci = l.begin();
	
	while(lci!=l.end()) {
		if(!lci->isop) {//not an operation
			eqcalc.push_front(*lci);
			//data in the eqcalc list, start operating
			allowcalculations=true;
		} else if(lci->op==100) {//special case #1 '(': do nothing
			eqoperations.push_front(*lci);
		} else if(lci->op==101) {//special case #2 ')': operate until '('
			//while there are operations and they aren't '('
			while(eqoperations.size() && eqoperations.front().op!=100) {
				//actually do an operation
				doop();
				eqoperations.pop_front();
			}
			//then get rid of the '('
			if(eqoperations.front().op==100) eqoperations.pop_front();
			//finally handle any unary ops
			while(eqoperations.size() && eqoperations.front().unary) {
				doop();
				eqoperations.pop_front();
			}
			
		//whoa, wierd stuff here
		//these next two ifs handle the conditional operator
		//a terniary operator(3 operands) where only 2 operands are evaluated
		//so some pieces of data get skipped
		} else if(lci->op==102) {
			
			//if there are operators that have a higher precedence
			//than the conditional, evaluate them
			//in order to get a value for the conditional
			while(eqoperations.size() && 
				  precedence(eqoperations.front().op,eqoperations.front().unary)
				  >= precedence(lci->op,lci->unary)) {
				doop();
				eqoperations.pop_front();
			}
			
			//if the conditional is false skip everything up to the else clause
			if(int(eqcalc.front().value)==0) {
				condcount=1;
				while(condcount && lci!=l.end()) {
					++lci;
					if(lci->op==102) ++condcount;
					else if(lci->op==103) --condcount;
				}
			}
			if(lci==l.end()) --lci;//error found, no matching :
			senderror("error, ? found, no matching :","Lsmath");
			//get rid of the if clause from the conditional
			eqcalc.pop_front();
		} else if(lci->op==103) {//special case #4: ':', 
								 //equation should be finished
			condcount=1;
			while(condcount && lci!=l.end()) {
				++lci;
				if(lci->op==100) ++condcount;
				else if(lci->op==101) --condcount;
			}
			--lci;//don't ask, it is required
		
		//only other thing to deal with is assignments because 
		//they are right to left so don't do them here with everything else	
		//precedence(assignment)==0
		} else if(precedence(lci->op,lci->unary)!=0) {
			//while there are operations that are a higher precedence than
			//the current one at (*lci) do them
			while(eqoperations.size() && 
			precedence(eqoperations.front().op,eqoperations.front().unary)!=0 && 
			precedence(eqoperations.front().op,eqoperations.front().unary)
			>=precedence(lci->op,lci->unary)&&allowcalculations) {
				doop();
				eqoperations.pop_front();
			}
			eqoperations.push_front(*lci);
		} else {//? attempt to fix problem with assignment
			eqoperations.push_front(*lci);
		}
		
		//get the next data object
		++lci;
	}
	
	//finish up the equation
	while(eqoperations.size() && eqoperations.front().op!=100) {
		doop();
		eqoperations.pop_front();
	}
	
	return eqcalc.front();
}


//does the top operation in eqoperations 
//and uses the top needed variables in eqcalc to do it
void matheq::doop() {
	data d1,d2;
	std::string fordebug("");
	d1=eqcalc.front();
	eqcalc.pop_front();
	if(!eqoperations.front().unary) {
		d2=eqcalc.front();
		eqcalc.pop_front();
		if(DEBUG) {
			fordebug = std::string("(") + d2.var + std::string(") ") + makestr(d2.value,d2.isint) 
				+ std::string(" ");
		}
	}
	if(DEBUG) {
		fordebug = fordebug + tostr(eqoperations.front().op) + std::string(" ") + makestr(d1.value,d1.isint) + std::string(" (")
			+ d1.var + std::string(")");
	}
	debugprint(fordebug.c_str());
	switch(eqoperations.front().op) {
	case 100://I'm pretty sure that
	case 101://there is no real way to get here 
		eqcalc.push_front(d2);
		break;//should have never entered
	case 1:
		d1.value=!d1.value;
		d1.isint=true;//will be either 1 or 0 which is an int
		break;
	case 2:
		d1.value=~int(d1.value);//operation only works on ints
		d1.isint=true;//so it is an int
		break;
	case 3:
		if(d1.isint) {
			if(d2.isint) {
				d1.value=int(d1.value)*int(d2.value);//results in int
			} else {
				d1.value=int(d1.value)*d2.value;//results in double
				d1.isint=false;
			}
		} else {
			if(d2.isint) {
				d1.value=d1.value*int(d2.value);//results in double
			} else {
				d1.value=d1.value*d2.value;//results in double
			}
		}
		break;
	case 4:
		if(!d1.value) {
			d1.value=0;
			error=1;
			senderror("Modulation by 0","Error");
		} else {
			if(d1.isint && d2.isint) d1.value=int(d2.value)%int(d1.value);
			else {
				d1.value=int(d2.value)%int(d1.value);
				d1.isint=true;
				error=1;
				senderror("Modulation by non-integers","Error");
			}
		}
		break;
	case 5:
		if(!d1.value) {
			d1.value=0;
			error=1;
			senderror("Division by 0","Error");
		} else {
			if(d2.isint) {
				if(d1.isint) {
					d1.value=int(d2.value)/int(d1.value);
				} else {
					d1.value=int(d2.value)/d1.value;
					d1.isint=false;
				}
			} else {
				if(d1.isint) {
					d1.value=d2.value/int(d1.value);
				} else {
					d1.value=d2.value/d1.value;
				}
			}
		}
		break;
	case 6:
		d1.value+=d2.value;
		if(!(d1.isint && d2.isint)) d1.isint=false;
		break;
	case 7:
		d1.value=d2.value-d1.value;
		if(!(d1.isint && d2.isint)) d1.isint=false;
		break;
	case 8:
		d1.value=int(d2.value)^int(d1.value);
		if(!(d1.isint && d2.isint)) d1.isint=false;
		break;
	case 9:
		d1.value=(d1.value > d2.value);
		d1.isint=true;
		break;
	case 10:
		d1.value=(d1.value < d2.value);
		d1.isint=true;
		break;
	case 11:
		d1.var=d2.var;
		savevar(d1);
		break;
	case 12:
		d1.value=(int(d2.value) & int(d1.value));
		d1.isint=true;
		break;
	case 13:
		d1.value=(int(d2.value) | int(d1.value));
		d1.isint=true;
		break;
	case 14:
		d1.value=(int(d2.value) << int(d1.value));
		d1.isint=true;
		break;
	case 15:
		d1.value=(int(d2.value) >> int(d1.value));
		d1.isint=true;
		break;
	case 16:
		d1.value=(d2.value != d1.value);
		d1.isint=true;
		break;
	case 17:
		d1.value= ~int(d2.value);
		d1.isint=true;
		savevar(d1);
		break;
	case 18:
		if(d1.isint) {
			if(d2.isint) {
				d1.value=int(d1.value)*int(d2.value);
			} else {
				d1.value=int(d1.value)*d2.value;
				d1.isint=false;
			}
		} else {
			if(d2.isint) {
				d1.value=d1.value*int(d2.value);
			} else {
				d1.value=d1.value*d2.value;
			}
		}
		d1.var=d2.var;
		savevar(d1);
		break;
	case 19:
		if(!d1.value) {
			d1.value=0;
			error=1;
			senderror("Modulation by 0","Error");
		} else {
			if(d1.isint && d2.isint) d1.value=int(d2.value)%int(d1.value);
			else {
				d1.value=int(d2.value)%int(d1.value);
				d1.isint=true;
				error=1;
				senderror("Modulation by non-integers","Error");
			}
		}
		d1.var=d2.var;
		savevar(d1);
		break;
	case 20:
		if(!d1.value) {
			d1.value=0;
			error=1;
			senderror("Division by 0","Error");
		} else {
			if(d2.isint) {
				if(d1.isint) {
					d1.value=int(d2.value)/int(d1.value);
				} else {
					d1.value=int(d2.value)/d1.value;
					d1.isint=false;
				}
			} else {
				if(d1.isint) {
					d1.value=d2.value/int(d1.value);
				} else {
					d1.value=d2.value/d1.value;
				}
			}
		}
		d1.var=d2.var;
		savevar(d1);
		break;
	case 21:
		d1.value+=d2.value;
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 22:
		d1.value=d2.value-d1.value;
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 23:
		d1.value=int(d2.value)^int(d1.value);
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 24:
		d1.value=(d2.value <= d1.value);
		d1.isint=true;
		break;
	case 25:
		d1.value=(d2.value >= d1.value);
		d1.isint=true;
		break;
	case 26:
		d1.value=(d2.value == d1.value);
		d1.isint=true;
		break;
	case 27:
		d1.value=int(d2.value)&int(d1.value);
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 28:
		d1.value=int(d2.value)|int(d1.value);
		if(!(d1.isint && d2.isint)) d1.isint=false;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 29:
		d1.value=(d2.value && d1.value);
		d1.isint=true;
		break;
	case 30:
		d1.value=(d2.value || d1.value);
		d1.isint=true;
		break;
	case 31:
		d1.value=(int(d2.value) << int(d1.value));
		d1.isint=true;
		d1.var=d2.var;
		savevar(d1);
		break;
	case 32:
		d1.value=(int(d2.value) >> int(d1.value));
		d1.isint=true;
		d1.var=d2.var;
		savevar(d1);
		break;
	}
	eqcalc.push_front(d1);
}

int matheq::precedence(int op,int unary) {
	int i;
	switch(op) {
	case 100://funny thing: perenthesis are noted as the higest order
	case 101://of precedence but if they were nothing would work
		i=-1;//by making them the lowest, the insides always get done first
		break;
	case 11:
	case 17://these are all the assignments
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 23:
	case 27:
	case 28:
	case 31:
	case 32:
		i=0;
		break;
	case 102://? does the conditional belong here or above the '=' statments
	case 103://TODO: test conditional more
		i=1;
		break;
	case 30:
		i=2;
		break;
	case 29:
		i=3;
		break;
	case 13:
		i=4;
		break;
	case 8:
		i=5;
		break;
	case 12:
		i=6;
		break;
	case 16:
	case 26:
		i=7;
		break;
	case 9:
	case 10:
	case 24:
	case 25:
		i=8;
		break;
	case 14:
	case 15:
		i=9;
		break;
	case 6:
	case 7:
		i=10;
		break;
	case 3:
	case 4:
	case 5:
		i=11;
		break;
	case 1:
	case 2:
		i=12;
	}
	if(unary) i=13;//all unary operators have the highest precedence
				   //(until exponentiation is added)
	return i;
}
#endif
