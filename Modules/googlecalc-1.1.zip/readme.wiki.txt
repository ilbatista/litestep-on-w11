====== litestep : modules : googlecalc.dll ======

Goglecalc is Litestep module that utilizes and integrates one of [[http://www.google.com|google's]]
most interesting features: [[http://www.google.com/help/features.html#calculator|google calculator]]
into Litestep core.

According to google's help:

//"To use Google's built-in calculator function, simply enter the calculation you'd like done into
the search box and hit the Enter key or click on the Google Search button. The calculator can solve
math problems involving basic arithmetic, more complicated math, units of measure and conversions,
and physical constants."//

Interesting part is, that google calculator can solve not only plain arithmetics but compute as well
some advanced stuff like:

  * [[google>5+2*2]]
  * [[google>2^20]]
  * [[google>sqrt(-4)]]
  * [[google>half a cup in teaspoons]]
  * [[google>160 pounds * 4000 feet in Calories]]

It can convert between measurement units and even currency conversions are working:

  * [[google>3.5 USD in GBP]]
  * [[google>currency of Brazil in Malaysian money]]
  * [[google>5 British pounds in South Korean money]]
  * [[google>2.2 USD per gallon in INR per litre]]

You can read more on google calculator in [[http://www.google.com/help/calculator.html|google documentation]].

So what this plugin does? It adds ''!GoogleCalc'' bang command. Using this command will transparently
query google search and if the returned result is valid calculator result (not every query is valid
for calculation), it will run specified command. You can run any program, display message box or even
return the result into LSXCommand prompt (see below).

===== Example =====

With following simple ''step.rc'' settings you can extend LSXCommand computing functionality to include
google-calculator fatures:

<code>
# This setup assumes that LSXCommand is loaded and correctly set up.
# Load googlecalc module
LoadModule c:\litestep\googlecalc-1.1.dll

# Define proxy.
# Not mandatory, if not set, Windows defaults are used.
# If set to "none", direct connection is always used.
GoogleProxy none

# Define what to do with the result
GoogleCalcOnResult !CommandSetText %s

# Define LSXCommand special character for googlecalc
*commandChar # !googlecalc <args>
</code>

You will be able to do a google-calculator query right within your LSXCommand prompt starting your query
with ''#'' like:

  #half a cup in teaspoons

and result is returned into LSXCommand prompt as:

  half (1 US cup) = 24 US teaspoons

===== Settings =====

==== Bang commands: ====

 Invoke google calculator search with given arguments

  !GoogleCalc <args>


==== Settings: ====

 Show verbose messages (set on for debugging purposes only).

  GoogleVerbose

 Define proxy. This setting is not mandatory, if not set, Windows defaults are used.
 If set to "none", direct connection is always used.

  GoogleProxy <proxy_host:proxy_port>

 Specify what to do with the result. Specify path to executable or bang command, put %s in place where
 the result should be expanded. See example above:

  GoogleCalcOnResult <args>


===== Notes =====

googlecalc.dll module utilizes internal Windows Internet API (wininet.dll) to send http GET request
to google in the form

 www.google.com/search?q=<yourquery>%3D and then seek in returned HTML

response for signs that the result is calculator-result and parse the resulting value.
It reads only essential part of the server response and closes the connection as soon as the result
is gathered.

Module uses direct connection and bypasses your proxy (if set). Proxy settings can be added in
future release.

===== Downloads =====


Current version is **1.1**

Module download: {{projects:modules:googlecalc:googlecalc-1.1.zip?nocache|googlecalc-1.1.zip}}

Source download: {{projects:modules:googlecalc:googlecalc-1.1-src.zip?nocache|googlecalc-1.1-src.zip}}

{{projects:modules:googlecalc:changelog.txt|changelog}}

{{projects:modules:googlecalc:readme.wiki.txt|documentation (txt wiki file)}}

{{projects:modules:googlecalc:sample_rc.txt|Sample step.rc config}}


===== Another resources =====

Another interesting google calculator queries can be seen here:

  http://www.kottke.org/03/08/fun-with-the-google-calculator
  http://www.waxy.org/archive/2003/08/14/fun_with.shtml
  http://www.kuro5hin.org/story/2003/8/14/21307/5189
  google>google calculator fun

