Remote Control (remote.dll)
This file was created on 1999-11-24 by Asperon
******************************************************************************
1. Introduction

   This is a general remote control module for litestep. By passing windows 
   messages to programs you can intreact with them through the litestep GUI
   (like shortcuts, popupmenu or whatever that supports bang commands).

******************************************************************************
2. Installation

   Unzip the remote.dll into your litestep dir. Add the line:

   loadmodule c:\litestep\remote.dll   

   to your step.rc (change c:\litestep to point at your litestep dir)
 
   after this you will have to add a *send command for each message you want
   to be able to use.

   the syntax is:

   *send <command-name> <window/program> <message>

   where <command-name> is the name you want this message to have.
	 <window/program> is the name of the program/titel of the window
         <message> is the message number to send (check the program 
	   	   dokumentation for the right codes)

   example:

   *send IDNEXT CoolPlayer 40014

   would send 40014 to the CoolPlayer window whenever litestep runs a !Send IDNEXT

   This way you can control everything from mp3-players to webbrowser to windows 
   native functions.

******************************************************************************
3. Contact
	
   Any desired features, bug reports or just to show your gratitude, get in 
   contact with me. 

   You can contact me at:
	asperon@home.se

   The lastest updates for this program can be found at:
   	http://www.csd.uu.se/~s95cce

******************************************************************************
