#ifndef __ACTIVESHORTCUTS_H_
#define __ACTIVESHORTCUTS_H_

#include "..\litestep\wharfData.h"

typedef struct {
    char szName[512];
	char szWindow[512];
	char szMessage[512];
	char szParameters[512];
    } messageType;

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif


#endif
