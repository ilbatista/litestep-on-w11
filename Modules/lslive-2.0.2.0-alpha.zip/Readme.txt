///////////////////////////////////////////////////////////
//
//           LSLIVE! version 2.0.2.0 Alpha
//            Animated gifs for Litestep
//                   09/12/2005
//                written by Mercutio
//
///////////////////////////////////////////////////////////

ABOUT:

LSLIVE! is a module to allow use of animated .gif's in Litestep.
I started this project in 1998, and the first releases were stand-
alone .exe files that provided similar functionality.  This version
(finally) is as it was originally intended to be... a Litestep
module.  This release is a bit "stripped down" feature-wise 
but more features are planned for later versions.


FUNCTIONS:

As of this release, LSLIVE! (still) does exactly two things:
1. display animated gifs on the Litestep desktop
2. Launch .exe files

True transparency is currently in the works.  Additional features
will be added as I think of them/have time to work on them.  Feature
lists, To Do's, and bug lists will be up on my website(www.theeclectic.net)
when I have time to set them up.


SETUP:

  Unzip the .zip file into your Litestep/Modules folder.  Add the
path to lslive.dll to your step.rc.  The settings are now stored in
config.ini and user.ini in the \modules\lslive directory

SETTINGS:
Most settings are currently found in the user.ini file.  Each heading represents an instance.
Example:

[lslive1]
GifPath=   <---  path to the gif file
ExePath=   <---  Path to the executable you want to launch
AniSpeed=  <---  Speed of the animation.  Lower is faster.
MMode=     <---  "Move Mode" 1=draggable, 0=not
SCEx=      <---  Not currently used
XPos=      <---  X Position of the instance
YPos=      <---  Y Position of the instance

If your Litestep installation is somewhere other than c:\litestep, you'll need
to add the following to the config.ini file:

[LSLIVE!]
LSPATH=c:\yourlitestepdirectory

Where 'yourlitestepdirectory' is the path to your Litestep directory

CHANGES:

1. Added a folder under /litestep/modules to store local ini files, etc.
2. Changed location of settings back to a local ini file.
3. Re-write of the last version's multiple instance code.


Disclaimer:

This software is currently in ALPHA...  while it is working properly
to the best of my knowledge, it has only been tested on one computer
under one environment.  I am not responsible for anything it might
do to you, your computer, your cat, ferret, or other small domestic 
animal, etc., etc...

License:

This software is free to use other than in commercial/government applications.
You may redistribute this software freely as long as the original documentation
is included.  You MAY NOT sell, reverse engineer, take credit for, etc. this
program without my written consent.  If you intend to use this software for
any purpose not listed above, please contact me with details.


Contact:

Questions and concerns can be sent to mercutio@theeclectic.net.
My nick on Litestep.net is lslive_mercutio.
On IRC, I'm usually in #litestep on freenode. My handle is lslive_mercutio
or DesktopMojo.
Website is www.theeclectic.net