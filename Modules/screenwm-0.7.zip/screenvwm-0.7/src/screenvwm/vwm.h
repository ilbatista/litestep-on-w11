/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

/// Virtual Window Manager - the widget that this module exists to provide.
class VWM
{
public:
	VWM(int& code);
	~VWM();
	int finalize();
	
	// FIXME: These shouldn't need to be friends
	friend class MinimapElement;
	friend class TextLabelElement;
	friend class VWMPanel;

	void gather();
	
	void createDesktop();
	bool destroyDesktop(VirtualDesktop *desk);
	void mergeDesk(VirtualDesktop *deletedDesktop, VirtualDesktop *mergeTarget);
	void separateDesk(VirtualDesktop *desk);
	void moveDesk(int oldIndex, int newIndex);
	void switchDesk(VirtualDesktop *newDesk, bool skipFocus=false);
	void moveApp(WindowData *task, VirtualDesktop *dest);
	void moveWindow(WindowData *window, VirtualDesktop *desk);
	void moveWindow(WindowData *window, RECT pos, VirtualDesktop *desk);
	void raiseWindow(WindowData *window);
	void minimizeWindow(WindowData *window);
	void maximizeWindow(WindowData *window);
	void restoreWindow(WindowData *window);
	void saveDesktops();
	
	WindowData *getForegroundWindow();
	void raiseLocalForeground();
	
	// Desktop searching
	// (in finddesk.cpp) @{
	/// Find the named virtual desktop, or return NULL if there is no such
	/// desk. (eg, if relativeTo is the last desk and deskName=="next", returns
	/// null.)
	VirtualDesktop *findDeskNoFallback(const char *deskName, VirtualDesktop *relativeTo);
	/// Find the named virtual desktop. May be a string naming multiple desks,
	/// separated by slashes, eg "next/prev/newlast". Tries possibilities in
	/// order until one is found which works. If it runs out of fallbacks, uses
	/// "next/prev/current" as a fallback.
	VirtualDesktop *findDesk(const char *deskName, VirtualDesktop *relativeTo=NULL);
	//@}
	
	// Panels
	// (in vwmwindow.cpp) @{
public:
	VWMPanel *findPanel(int x, int y);
	void findPanels(const char *description, vector<VWMPanel*> *p);
private:
	void registerWindowClass();
	void unregisterWindowClass();
	void initPanels();
	void destroyPanels();
	vector<VWMPanel*> panels;
	//@}
	
	// Virtual desktop data structures
	// (getters in vwm.cpp) @{
	VirtualDesktop *currentDesktop;
	VirtualDesktop *lastDesktop;
public:
	vector<VirtualDesktop*> desktops;
private:
	VirtualDesktop *getDeskFromWnd(HWND window);
	//@}
	
	// windowtracking.cpp
	// Window tracking and moving @{
	vector<HWND> zOrder;
	map<HWND, WindowData*> windowsByHandle;
	StorageManager storageManager;
	HWND foregroundHandle;
	bool updateNextDraw;
	
public:
	WindowData *findWindow(const char *description);
	
private:
	bool updateWindowList();
	bool updateWindow(WindowData *window);
	WindowData *noticeWindowCreation(HWND handle);
	void noticeWindowDisappearance(WindowData *window);
	VirtualDesktop *rescueOffscreenWindow(HWND handle, RECT *pos);
	
	HDWP windowMover;
	void beginMovingWindows();
	void setWindowPos(HWND handle, const RECT *pos);
	void finishMovingWindows();
	
	void getTaskGroup(WindowData *member, set<WindowData*> *group);
	bool shouldIgnoreWindow(HWND window);
	
	void initTrackingHooks();
	void cleanupTrackingHooks();
	void interceptWindowPosChange(HWND window, WINDOWPOS *pos);
	friend void hookWindowPosChangedProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	//@}
	
	// vwmevents.cpp
	// Event handlers @{
	void windowProc(Message& message, HWND window);
	void onCreate(Message& message);
	void onDestroy(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
	void onWindowActivated(Message& message);
	void onTimer(Message& message);
	void onDropFiles(Message& message);
	void onVWMPosChanging(Message& message);
	void onBringToFront(Message& message);
	void onSwitchToN(Message& message);
	void onListDesktops(Message& message);
	void onGetDesktopOf(Message& message);
	//@}
	
	// vwmgeom.cpp
	// Geometry calculations @{
	void initDesktops();
	bool restoreDesktops();
	void updateTaskLists(bool keepEmpties);
	RECT getMaximizeArea();
	RECT getGatherTarget(RECT source);
	VirtualDesktop *deskFromLocation(Rect pos);
	//@}
	
	// vwmpaint.cpp
	// Rendering @{
	void forceRedraw(bool updateWindows);
	void onPaint(Message& message);
	//@}
};
extern VWM *vwm;
