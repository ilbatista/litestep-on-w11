/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

struct TaskListFlowChild
	:public FlowElement::FlowChild
{
	TaskListFlowChild(LayoutElement *element) :FlowChild(element) {}
	void append(vector<FlowElement::FlowCache> &children, ElementContext *context)
	{
		VirtualDesktop *desk = context->desk;
		if(!desk) return;
		
		for(unsigned ii=0; ii<desk->tasks.size(); ii++)
		{
			FlowElement::FlowCache ret;
			ret.element = childType;
			ret.node = NULL;
			ret.context = *context;
			ret.context.task = desk->tasks[ii];
			children.push_back(ret);
		}
	}
};
struct DeskListFlowChild
	:public FlowElement::FlowChild
{
	DeskListFlowChild(LayoutElement *element) :FlowChild(element) {}
	void append(vector<FlowElement::FlowCache> &children, ElementContext *context)
	{
		for(unsigned ii=0; ii<vwm->desktops.size(); ii++)
		{
			FlowElement::FlowCache ret;
			ret.element = childType;
			ret.node = NULL;
			ret.context = *context;
			ret.context.desk = vwm->desktops[ii];
			children.push_back(ret);
		}
	}
};
struct SingletonFlowChild
	:public FlowElement::FlowChild
{
	SingletonFlowChild(LayoutElement *element) :FlowChild(element) {}
	void append(vector<FlowElement::FlowCache> &children, ElementContext *context)
	{
		FlowElement::FlowCache ret;
		ret.element = childType;
		ret.node = NULL;
		ret.context = *context;
		children.push_back(ret);
	}
};
struct SpacerFlowChild
	:public SingletonFlowChild
{
	SpacerFlowChild(int size) :SingletonFlowChild(NULL), size(size) {}
	void append(vector<FlowElement::FlowCache> &children, ElementContext *context)
	{
		FlowElement::FlowCache ret;
		ret.element = NULL;
		ret.node = NULL;
		ret.context = *context;
		ret.preferredLength = ret.minLength = size;
		children.push_back(ret);
	}
	int size;
};

FlowElement::FlowChild::FlowChild(LayoutElement *childType)
	:childType(childType) { }

FlowElement::FlowElement(string prefix)
	:RectLayoutElement(prefix)
{
	parseChildTypes();
}

FlowElement::~FlowElement()
{
	for(unsigned ii=0; ii<childTypes.size(); ii++)
		delete childTypes[ii];
}

void FlowElement::parseChildTypes()
{
	string childList = getConfigLine("Elements", "", prefix.c_str());
	vector<string> tokens;
	tokenizeString(childList, tokens, " \t()");
	
	for(unsigned ii=0; ii<tokens.size(); ii++)
	{
		if(!stricmp(tokens[ii].c_str(), ".tasks"))
		{
			if(++ii >= tokens.size()) {
				string warning = string(".tasks child in ")+prefix+" requires an argument.\n";
				warn(warning.c_str());
				return;
			}
			
			LayoutElement *element = layoutPool->getElement(tokens[ii]);
			childTypes.push_back(new TaskListFlowChild(element));
		}
		else if(!stricmp(tokens[ii].c_str(), ".desks"))
		{
			if(++ii >= tokens.size()) {
				string warning = string(".desks child in ")+prefix+" requires an argument.\n";
				warn(warning.c_str());
				return;
			}
			
			LayoutElement *element = layoutPool->getElement(tokens[ii]);
			childTypes.push_back(new DeskListFlowChild(element));
		}
		else if(isdigit(tokens[ii][0]))
		{
			int thickness = atoi(tokens[ii].c_str());
			childTypes.push_back(new SpacerFlowChild(thickness));
		}
		else
		{
			LayoutElement *element = layoutPool->getElement(tokens[ii]);
			childTypes.push_back(new SingletonFlowChild(element));
		}
	}
}

/// Get a list of all the elements that will be the children of this flow, and
/// their semantics (context). Results are appended to 'children', which is not
/// cleared first. If 'minimal' is set, this is just for the determination of
/// whether things have changed, so there is no need to calculate length;
/// otherwise, this function will determine the minimal and preferred size of
/// each element. This size is requested using the bounding rect given in
/// 'childContext', which also provides defaults for all fields which are not
/// part of the definition of the flow.
void FlowElement::getChildren(vector<FlowCache> &children, ElementContext *childContext, bool minimal)
{
	for(unsigned ii=0; ii<childTypes.size(); ii++)
	{
		childTypes[ii]->append(children, childContext);
	}
	
	if(!minimal)
	{
		for(unsigned ii=0; ii<children.size(); ii++)
		{
			// Skip spacer elements
			if(!children[ii].element)
				continue;
			
			// Fill in min and preferred lengths
			pair<int,int> length = children[ii].element->getLength(&children[ii].context, verticalChildren());
			children[ii].minLength = length.first;
			children[ii].preferredLength = length.second;
		}
	}
}

bool FlowElement::changed(LayoutCacheNode *node)
{
	ElementContext childContext = getChildContext(&node->context);
	vector<FlowCache> children;
	getChildren(children, &childContext, true);
	
	if(children.size() != node->children.size())
		return true;
	
	for(unsigned ii=0; ii<children.size(); ii++)
	{
		if(children[ii].element != node->children[ii]->element)
			return true;
		if(!children[ii].context.match(node->children[ii]->context))
			return true;
		if(node->children[ii]->element->changed(node->children[ii]))
			return true;
	}
	
	return false;
}

