/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

static BOOL CALLBACK windowListBuilder(HWND window, LPARAM param);
static bool isMinimized(HWND window);
string getWindowTitle(HWND window);

static HICON getTaskIconWithSize(HWND window, bool big, int timeout);
static HICON getTaskIcon(HWND window, bool preferBig, int timeout);

bool isWindowMinimized(HWND window, const RECT *screenRect)
{
	if(IsIconic(window))
		return true;
	else if(screenRect->left < -10000 && screenRect->top < -10000)
		return true;
	else
		return false;
}

WindowData *VWM::findWindow(const char *description)
{
	if(!description || !*description
	   || !stricmp(description, "foreground")
	   || !stricmp(description, "focused")
	  )
		return getForegroundWindow();
	
	if(!stricmp(description, "clicked"))
	{
		if(clickContext)
			return clickContext->task;
		else
			return NULL;
	}
	else if(!stricmp(description, "dragged"))
	{
		if(drag) {
			return drag->elementContext.task;
		} else {
			warn("Looked for 'dragged' task, but no drag context available.\n");
		}
	}
	else if(!stricmp(description, "dropped"))
	{
		if(droppedContext) {
			return droppedContext->task;
		} else {
			warn("Looked for 'dropped' task, but no drag/drop context available.\n");
		}
	}
	else if(!stricmp(description, "hovered"))
	{
		Point mousePos = getCursorPos();
		VWMPanel *panel = vwm->findPanel(mousePos.x, mousePos.y);
		mousePos.x -= panel->x;
		mousePos.y -= panel->y;
		LayoutLocation hovered = panel->elementAtPoint(mousePos.x, mousePos.y);
		return hovered.context.task;
	}
	
	return NULL;
}

/// Traverse the list of windows and update zOrder and windowsByHandle to
/// reflect any changes which other programs have made. Returns true if a
/// change was found, false otherwise.
bool VWM::updateWindowList()
{

	bool changeFound = false;
	updateNextDraw = false;
	
	zOrder.clear();
	EnumWindows(&windowListBuilder, (LPARAM)&zOrder);
	
	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
	{
		ii->second->focused = false;
		ii->second->visited = false;
	}
	
	// Go through all the windows we noticed. Inspect any windows which are
	// new, and update any windows which are changed. If anything has changed,
	// set changeFound. Also, come up with a PID->task window mapping and a
	// list of windows which we haven't been able to assign to a task.
	map<DWORD, WindowData*> taskWindowsByPid;
	vector<WindowData*> bastardWindows;
	
	int writePos = 0;
	for(unsigned ii=0; ii<zOrder.size(); ii++)
	{
		HWND handle = zOrder[ii];
		if(shouldIgnoreWindow(handle))
			continue;
		zOrder[writePos++] = zOrder[ii];
		
		map<HWND, WindowData*>::iterator jj = windowsByHandle.find(handle);
		WindowData *data;
		if(jj == windowsByHandle.end()) {
			data = noticeWindowCreation(handle);
			windowsByHandle[handle] = data;
			changeFound = true;
		} else {
			data = jj->second;
			if(data->z != ii) {
				data->z = ii;
				changeFound = true;
			}
			if(updateWindow(data)) {
				changeFound = true;
			}
		}
		
		if(data->isTask)
			taskWindowsByPid[data->pid] = data;
		else if(!data->parent && !data->isPopup)
			bastardWindows.push_back(data);
		
		data->visited = true;
	}
	zOrder.resize(writePos);
	
	for(unsigned ii=0; ii<bastardWindows.size(); ii++)
	{
		WindowData *window = bastardWindows[ii];
		if(taskWindowsByPid.find(window->pid) != taskWindowsByPid.end()) {
			window->parent = taskWindowsByPid[window->pid]->handle;
		} else {
			window->isTask = true;
		}
	}
	
	// We may have found some off-screen windows to move onto the screen. If
	// so, commit those moves.
	finishMovingWindows();
	
	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); )
	{
		if(ii->second->visited)
			ii++;
		else
		{
			changeFound = true;
			noticeWindowDisappearance(ii->second);
			delete ii->second;
			ii = windowsByHandle.erase(ii);
		}
	}
	
	HWND newForegroundHandle = GetForegroundWindow();
	do {
		if(windowsByHandle.find(newForegroundHandle) != windowsByHandle.end())
		{
			WindowData *window = windowsByHandle[newForegroundHandle];
			if(!window->isPopup && !window->parent) {
				window->focused = true;
				break;
			}
		}
		newForegroundHandle = GetParent(newForegroundHandle);
	} while(newForegroundHandle);
	
	if(newForegroundHandle != foregroundHandle)
	{
		if(windowsByHandle.find(foregroundHandle) != windowsByHandle.end())
			windowsByHandle[foregroundHandle]->focused = false;
		
		changeFound = true;
		foregroundHandle = newForegroundHandle;
	}
	
	return changeFound;
}

bool operator!=(RECT a, RECT b)
{
	return a.left!=b.left || a.right!=b.right || a.top!=b.top || a.bottom!=b.bottom;
}

bool VWM::updateWindow(WindowData *window)
{
	bool changed = false;
	RECT screenPos = {0,0,0,0};
	GetWindowRect(window->handle, &screenPos);
	
	bool minimized = isWindowMinimized(window->handle, &screenPos);
	VirtualDesktop *desk;
	if(minimized) {
		// Don't change a window's assigned desktop while it's minimzed
		desk = window->desk;
	} else {
		desk = deskFromLocation(screenPos);
	}
	
	if(window->minimized != minimized) {
		changed = true;
		window->minimized = minimized;
	}
	if(window->desk != desk) {
		changed = true;
		if(!desk) {
			desk = rescueOffscreenWindow(window->handle, &screenPos);
		}
		if(window->desk)
			window->desk->numTasks--;
		window->desk = desk;
		window->desk->numTasks++;
	}
	if(window->screenPos != screenPos) {
		changed = true;
		window->screenPos = screenPos;
	}
	
	return changed;
}

WindowData *VWM::noticeWindowCreation(HWND handle)
{
	WindowData *ret = new WindowData();
	ret->handle = handle;
	
	RECT screenPos = {0,0,0,0};
	GetWindowRect(handle, &screenPos);
	
	if(isWindowMinimized(handle, &screenPos)) {
		ret->minimized = true;
		ret->desk = currentDesktop;
	} else {
		ret->minimized = false;
		ret->desk = deskFromLocation(screenPos);
		if(!ret->desk)
			ret->desk = rescueOffscreenWindow(handle, &screenPos);
	}
	
	ret->focused = false;
	ret->screenPos = screenPos;
	ret->visited = true;
	
	long windowStyle = GetWindowLong(handle, GWL_STYLE);
	long windowExStyle = GetWindowLong(handle, GWL_EXSTYLE);
	
	//ret->isToolWindow = (GetWindowLong(handle, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)?true:false;
	ret->isPopup = (windowStyle & WS_POPUP) ?true:false;
	
	// Try to find a 'parent' for this window - not necessarily a real parent
	// in the Windows sense; if there is no parent window, an owner counts,
	// and failing that, any task window in the same process will do. For that
	// last bit, we wait until all windows have been recognized, then go
	// through all non-task windows that need parents, in updateWindowList;
	ret->parent = GetParent(handle);
	if(!ret->parent)
		ret->parent = GetWindow(handle, GW_OWNER);
	
	GetWindowThreadProcessId(handle, &ret->pid);
	
	// Compare to TaskSwitchXP, whose idea of a task window is:
	//	if (
	//       (
	//         !(dwStyleEx & WS_EX_TOOLWINDOW)
	//         || (dwStyleEx & WS_EX_APPWINDOW)
	//       )
	//       || (
	//         dwStyleEx & WS_EX_TOOLWINDOW
	//         && hwndOwner != hwnd
	//         && !(dwStyle & WS_POPUP)
	//       )
	//     )
	// This version improperly treats pieces of Visual Studio's menus as task
	// windows, and that just won't do.
	//
	// This is LS task's version:
	//   unless(
	//      WS_EX_APPWINDOW != (WS_EX_APPWINDOW & dwExStyle)
	//      && (
	//        WS_EX_TOOLWINDOW == (WS_EX_TOOLWINDOW & dwExStyle)
	//        || (
	//          bChkOwner
	//          && GetWindowOwner(hWnd)
	//        )
	//      )
	//    )
	// which DeMorgans into:
	//   if(
	//      (dwExStyle & WS_EX_APPWINDOW)
	//      || (
	//        !(dwExStyle & WS_EX_TOOLWINDOW)
	//        && (!bChkOwner || !GetWindowOwner(hWnd))
	//      )
	//    )
	// Including everything which is not a tool window is seriously wrong,
	// since Visual Studio's menus are composed of four non-tool windows
	// which obviously don't belong as tasks. Not sure what the reasoning
	// is behind the last bit (every owned toolwindow which is not a popup).
	//
	// _this_ version defines a task window as anything with WS_EX_APPWINDOW,
	// or anything which is not a popup and has a parent (for a very broad
	// definition of 'parent - see above').
	
	HWND owner;
	HWND pos=GetWindow(handle, GW_OWNER);
	do {
		owner = pos;
		pos = GetWindow(pos, GW_OWNER);
	} while(pos);
	
	//LS task version
	if(windowExStyle & WS_EX_APPWINDOW)
		ret->isTask = true;
	else if(!(windowExStyle & WS_EX_TOOLWINDOW) && !owner)
		ret->isTask = true;
	else
		ret->isTask = false;
	
	ret->smallIcon = getTaskIcon(handle, false, 100);
	ret->bigIcon = getTaskIcon(handle, true, 100);
	
	if(ret->desk)
		ret->desk->numTasks++;
	
	return ret;
}

void VWM::beginMovingWindows()
{
	if(!windowMover)
		windowMover = BeginDeferWindowPos(0);
}

void VWM::setWindowPos(HWND handle, const RECT *pos)
{
	if(!windowMover)
		beginMovingWindows();

	DeferWindowPos(windowMover, handle, NULL,
	               pos->left, pos->top,
	               0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
}

void VWM::finishMovingWindows()
{
	if(windowMover) {
		EndDeferWindowPos(windowMover);
		windowMover = NULL;
	}
}

VirtualDesktop *VWM::rescueOffscreenWindow(HWND handle, RECT *pos)
{
	if(!settings->rescueOffScreenWindows)
		return currentDesktop;
	
	trace << "Rescued off-screen window: '" << getWindowTitle(handle) << "' from " << *pos << ".\n";
	*pos = getGatherTarget(*pos);
	trace << "\tTo: "<<*pos<<"\n";
	setWindowPos(handle, pos);
	
	return currentDesktop;
}

/// Given one member of a task group, find all members and add them to the set.
/// A task group is a task window plus all of its direct and indirect children.
void VWM::getTaskGroup(WindowData *member, set<WindowData*> *group)
{
	WindowData *pos = member;
	
	for(;;)
	{
		group->insert(pos);
		if(pos->parent && windowsByHandle.find(pos->parent) != windowsByHandle.end()) {
			pos = windowsByHandle[pos->parent];
		} else {
			break;
		}
	}
	
	for(map<HWND,WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
	{
		WindowData *window = ii->second;
		if(group->find(window) != group->end())
			continue;
		WindowData *pos = window;
		while(windowsByHandle.find(pos->parent) != windowsByHandle.end())
		{
			pos = windowsByHandle[pos->parent];
			if(group->find(pos) != group->end()) {
				group->insert(window);
				break;
			}
		}
	}
}

void VWM::noticeWindowDisappearance(WindowData *data)
{
	if(data->smallIcon)
		DestroyIcon(data->smallIcon);
	if(data->bigIcon)
		DestroyIcon(data->bigIcon);
	
	if(data->desk)
		data->desk->numTasks--;
}

string getWindowTitle(HWND window)
{
	char buf[1024];
	GetWindowText(window, buf, 1024);
	return string(buf);
}

bool VWM::shouldIgnoreWindow(HWND window)
{
	// Skip hidden windows
	if(!IsWindowVisible(window))
		return true;
	
	// Skip anything that has a parent but isn't a popup
	HWND parent = GetParent(window);
	int windowStyle = GetWindowLong(window, GWL_STYLE);
	if(parent && !(windowStyle & WS_POPUP))
		return true;
	
	// Skip windows which are components of the Litestep desktop (including the VWM itself)
	if(GetWindowLong(window, GWL_USERDATA) == magicDWord)
		return true;

	return false;
}

BOOL CALLBACK windowChildListBuilder(HWND window, LPARAM param)
{
	vector<HWND> *vec = (vector<HWND>*)param;
	vec->push_back(window);
	return TRUE;
}

BOOL CALLBACK windowListBuilder(HWND window, LPARAM param)
{
	vector<HWND> *vec = (vector<HWND>*)param;
	vec->push_back(window);
	
	// If this is a root window, iterate over its children
	HWND parent = GetParent(window);
	if(!parent)
		EnumChildWindows(window, &windowChildListBuilder, param);
	
	return TRUE;
}

void VWM::initTrackingHooks()
{
	// Set a hook to catch WM_WINDOWPOSCHANGED messages.
	// This doesn't seem to work (hook proc doesn't get called)
	// TODO: Fix this
	HWND hookManager = FindWindow("HookMgrClass", NULL);
	SendMessage(hookManager, LM_REGISTERMESSAGE, (WPARAM)WM_WINDOWPOSCHANGED, (LPARAM)hookWindowPosChangedProc);
}
void VWM::cleanupTrackingHooks()
{
}

// The code that sets this hook was commented out, so this can't be terribly important
void hookWindowPosChangedProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LPWINDOWPOS pos = (LPWINDOWPOS)lParam;
	vwm->interceptWindowPosChange(pos->hwnd, pos);
}

void VWM::interceptWindowPosChange(HWND window, WINDOWPOS *pos)
{
	if(shouldIgnoreWindow(window))
		return;
	
	if(windowsByHandle.find(window) == windowsByHandle.end())
	{
		// New window - TODO
	}
	else
	{
		// Changed size or position
		if ( !(pos->flags & SWP_NOSIZE) || !(pos->flags & SWP_NOMOVE) )
		{
			updateWindow(windowsByHandle[window]);
		}
		
		// Changed Z-order
		if ( !(pos->flags & SWP_NOZORDER) )
		{
			// Z-previous window is pos->hwndInsertAfter
			//TODO
		}
	}
}

#define INVALID_ICON(icon) (!(icon) || (int)(icon)==-1 || (int)(icon)==1)

HICON getTaskIcon(HWND window, bool preferBig, int timeout)
{
	HICON icon = NULL;
	
	if(preferBig)
	{
		icon = getTaskIconWithSize(window, true, timeout);
		if(!icon)
			icon = getTaskIconWithSize(window, false, timeout);
	}
	else
	{
		icon = getTaskIconWithSize(window, false, timeout);
		if(!icon)
			icon = getTaskIconWithSize(window, true, timeout);
	}
	
	// If no valid icon was found, use a default icon
	if(INVALID_ICON(icon))
	{
		icon = LoadIcon(NULL, IDI_APPLICATION);
		return icon;
	}
	else
	{
		HICON ret = CopyIcon(icon);
		return ret;
	}
}

HICON getTaskIconWithSize(HWND window, bool big, int timeout)
{
	HICON ret;
	
	int messageIconSize = big ? ICON_BIG : ICON_SMALL;
	if(SendMessageTimeout(
		window,
		WM_GETICON,
		messageIconSize,
		0,
		SMTO_BLOCK|SMTO_ABORTIFHUNG,
		timeout,
		(PDWORD_PTR)&ret))
	{
		if(!INVALID_ICON(ret))
			return ret;
	}
	
	int classLongIconSize = big ? GCL_HICON : GCL_HICONSM;
	ret = (HICON)GetClassLong(window, classLongIconSize);
	if(!INVALID_ICON(ret))
		return ret;

	if(SendMessageTimeout(
		window,
		WM_QUERYDRAGICON,
		messageIconSize,
		0,
		SMTO_BLOCK|SMTO_ABORTIFHUNG,
		timeout,
		(PDWORD_PTR)&ret))
	{
		if(!INVALID_ICON(ret))
			return ret;
	}
	
	return NULL;
}

HICON WindowData::getIcon(int size)
{
	if(size > 22)
		return bigIcon;
	else
		return smallIcon;
}
