/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

LinearFlow::LinearFlow(string prefix)
	:FlowElement(prefix)
{
	vertical = getConfigBool("Vertical", false, prefix.c_str());
	
	// These settings aren't yet used properly, but will be implemented at
	// some point in the future
	thickness = getConfigString("Thickness", "-0", prefix.c_str());
	rows = getConfigInt("Rows", 1, prefix.c_str());
	flowDirection = directionFromString(getConfigString("FlowDirection", "right", prefix.c_str()).c_str());
	numRows = getConfigInt("NumRows", 1, prefix.c_str());
}

LinearFlow::~LinearFlow()
{
}

LayoutCacheNode *LinearFlow::buildLayout(ElementContext *context, LayoutCacheNode *prev)
{
	LayoutCacheNode *ret = RectLayoutElement::buildLayout(context, prev);
	ret->element = this;
	
	vector<FlowCache> children;
	ElementContext childContext = getChildContext(context);
	getChildren(children, &childContext);
	
	int rowThickness = getRowThickness(context);
	
	int x = ret->context.boundingRect.left;
	int y = ret->context.boundingRect.top;
	
	// Position children
	for(unsigned ii=0; ii<children.size(); ii++)
	{
		children[ii].context.boundingRect.left = x;
		children[ii].context.boundingRect.top = y;
		
		if(vertical) {
			children[ii].context.boundingRect.width = rowThickness;
			children[ii].context.boundingRect.height = children[ii].preferredLength;
			y += children[ii].context.boundingRect.height;
		} else {
			children[ii].context.boundingRect.height = rowThickness;
			children[ii].context.boundingRect.width = children[ii].preferredLength;
			x += children[ii].context.boundingRect.width;
		}
	}
	// TODO: Handle multiple rows
	// TODO: Shrink elements when out of space
	
	// If there was a previous layout, match up elements in this layout with
	// elements from that one, and reuse any nodes with matching contexts.
	// (This is done mainly so that you can pull out a node when doing drag/
	// drop and replace it temporarily.)
	if(prev)
	{
		for(unsigned ii=0; ii<children.size(); ii++)
		{
			// Skip spacer elements
			if(!children[ii].element)
				continue;
			
			for(unsigned jj=0; jj<prev->children.size(); jj++)
			{
				if(prev->children[jj]->context.match(children[ii].context)
				   && prev->children[jj]->element == children[ii].element)
				{
					LayoutCacheNode *prevNode = prev->children[jj];
					children[ii].node = prevNode->element->buildLayout(&children[ii].context, prevNode);
					break;
				}
			}
		}
	}
	
	// Create new nodes for any children which didn't have a match in the
	// previous layout
	for(unsigned ii=0; ii<children.size(); ii++)
	{
		// Skip spacer elements
		if(!children[ii].element)
			continue;
		
		if(!children[ii].node)
			children[ii].node = children[ii].element->buildLayout(&children[ii].context, NULL);
	}
	
	ret->children.clear();
	for(unsigned ii=0; ii<children.size(); ii++)
	{
		if(!children[ii].element)
			continue;
		LayoutCacheNode *child = children[ii].node;
		child->parent = ret;
		ret->children.push_back(child);
	}
		
	return ret;
}

pair<int,int> LinearFlow::getLength(ElementContext *context, bool vertical)
{
	vector<FlowCache> children;
	ElementContext childContext = getChildContext(context);
	getChildren(children, &childContext);
	
	// TODO: Handle multiple rows
	int minLength = 0;
	int preferredLength = 0;
	for(unsigned ii=0; ii<children.size(); ii++) {
		minLength += children[ii].minLength;
		preferredLength += children[ii].preferredLength;
	}
	return pair<int,int>(minLength, preferredLength);
}

ElementContext LinearFlow::getChildContext(ElementContext *parentContext)
{
	int rowThickness = getRowThickness(parentContext);
	ElementContext ret = *parentContext;
	
	if(vertical)
		ret.boundingRect.width = rowThickness;
	else
		ret.boundingRect.height = rowThickness;
	return ret;
}

int LinearFlow::getRowThickness(ElementContext *context)
{
	int maxThickness;
	if(vertical) maxThickness = context->boundingRect.width;
	else         maxThickness = context->boundingRect.height;
	int totalThickness = ParseCoordinate(thickness.c_str(), maxThickness, maxThickness);
	
	return totalThickness / rows;
}

bool LinearFlow::verticalChildren()
{
	return vertical;
}