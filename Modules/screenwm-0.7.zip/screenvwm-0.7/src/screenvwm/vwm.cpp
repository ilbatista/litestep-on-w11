/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

//=========================================================
// VWM miscellaneous
//=========================================================
VWM::VWM(int& code)
{
	updateNextDraw = false;
}

VWM::~VWM()
{
	cleanupTrackingHooks();
	destroyPanels();
	delete settings;
}

int VWM::finalize()
{
	settings = new RCSettings();
	settings->refresh();
	
	initBangs();
	initDesktops();
	initPanels();
	
	initTrackingHooks();
	updateWindowList();
	
	return 0;
}

WindowData *VWM::getForegroundWindow()
{
	if(!foregroundHandle)
		return NULL;
	if(windowsByHandle.find(foregroundHandle)==windowsByHandle.end())
		return NULL;
	return windowsByHandle[foregroundHandle];
}

VirtualDesktop *VWM::getDeskFromWnd(HWND window)
{
	if(!window)
		return NULL;
	
	if(windowsByHandle.find(window) != windowsByHandle.end())
	{
		return windowsByHandle[window]->desk;
	}
	else
	{
		RECT screenPos;
		GetWindowRect(window, &screenPos);
		VirtualDesktop *desk = deskFromLocation(screenPos);
		if(desk)
			return desk;
		else
			return currentDesktop;
	}
}

void VWM::createDesktop()
{
	VirtualDesktop *newDesk = new VirtualDesktop(desktops.size(), storageManager.getStorageArea());
	desktops.push_back(newDesk);
	
	if(!foregroundHandle)
		raiseLocalForeground();
	moveApp(getForegroundWindow(), newDesk);
	switchDesk(newDesk);
}

bool VWM::destroyDesktop(VirtualDesktop *desk)
{
	// If there's only one desktop left, it can't be destroyed
	if(desktops.size()<=1)
		return false;
	
	// If there's a drag/drop in progress, cancel it
	/*if(dragging)
		cancelDrag();*/
	
	// Pick a desktop to move windows to. All desktops except the first merge
	// to the left. The first (leftmost) desktop merges to the right instead.
	VirtualDesktop *mergeTarget;
	if(desk->index > 0)
		mergeTarget = desktops[desk->index-1];
	else
		mergeTarget = desktops[1];
	
	mergeDesk(desk, mergeTarget);
	return true;
}

void VWM::mergeDesk(VirtualDesktop *deletedDesktop, VirtualDesktop *mergeTarget)
{
	if(deletedDesktop == mergeTarget)
		return;
	
	beginMovingWindows();
	
	for(map<HWND, WindowData*>::iterator it = windowsByHandle.begin(); it != windowsByHandle.end(); it++)
	{
		HWND handle = it->first;
		WindowData *windowData = it->second;
		
		// Relabel windows on the deleted desktop as being on the merge target
		if(windowData->desk == deletedDesktop) {
			if(deletedDesktop != currentDesktop) {
				deletedDesktop->storage->unstoreRect(windowData->screenPos);
				mergeTarget->storage->storeRect(windowData->screenPos);
				setWindowPos(windowData->handle, &windowData->screenPos);
			}
			
			windowData->desk = mergeTarget;
		}
		// Move windows on the merge target on-screen
		else if(windowData->desk == mergeTarget) {
			if(currentDesktop == deletedDesktop) {
				mergeTarget->storage->unstoreRect(windowData->screenPos);
				setWindowPos(handle, &windowData->screenPos);
			}
		}
	}
	
	finishMovingWindows();
	
	if(currentDesktop == deletedDesktop) {
		currentDesktop = mergeTarget;
		currentDesktop->focused = true;
	}
	
	// Remove the deleted desktop from the desk list and update everyone's indices
	for(unsigned ii=deletedDesktop->index; ii<desktops.size()-1; ii++)
	{
		desktops[ii] = desktops[ii+1];
		desktops[ii]->index = ii;
	}
	desktops.pop_back();
	delete deletedDesktop;
	
	// Clean up other possible references to the deleted desk
	if(lastDesktop == deletedDesktop)
		lastDesktop = NULL;
	
	if(currentDesktop == mergeTarget)
		raiseLocalForeground();
	
	forceRedraw(true);
}

void VWM::separateDesk(VirtualDesktop *desk)
{
	// Create new desktops for all but one of the tasks in this desk. The last
	// task stays on the original desktop.
	updateTaskLists(true);
	vector<VirtualDesktop*> newDesks;
	
	if(desk) {
		newDesks.push_back(desk);
		
		for(unsigned ii=1; ii<desk->tasks.size(); ii++) {
			int index = desk->index + ii;
			newDesks.push_back(new VirtualDesktop(index, storageManager.getStorageArea()));
		}
		
		desktops.erase(desktops.begin()+desk->index);
		desktops.insert(desktops.begin()+desk->index, newDesks.begin(), newDesks.end());
		for(unsigned ii=desk->index; ii<desktops.size(); ii++)
			desktops[ii]->index = ii;
 	} else {
		newDesks.insert(newDesks.begin(), desktops.begin(), desktops.end());
		
		unsigned numTasks = 0;
		for(unsigned ii=0; ii<desktops.size(); ii++)
			numTasks += desktops[ii]->tasks.size();
		for(unsigned ii=desktops.size(); ii<numTasks; ii++)
			newDesks.push_back(new VirtualDesktop(ii, storageManager.getStorageArea()));
		
		desktops = newDesks;
	}
	
	// Decide which desktop each window is moving to
	map<WindowData*, VirtualDesktop*> destinations;
	
	for(map<HWND, WindowData*>::iterator ii = windowsByHandle.begin(); ii != windowsByHandle.end(); ii++)
		ii->second->visited = false;
	
	int task = 0;
	for(map<HWND, WindowData*>::iterator ii = windowsByHandle.begin(); ii != windowsByHandle.end(); ii++)
	{
		HWND handle = ii->first;
		WindowData *windowData = ii->second;
		
		if(desk && windowData->desk != desk)
			continue;
		if(windowData->visited)
			continue;
		
		set<WindowData*> group;
		getTaskGroup(windowData, &group);
		
		VirtualDesktop *destination = newDesks[task++];
		
		for(set<WindowData*>::iterator jj = group.begin(); jj!=group.end(); jj++)
		{
			destinations[*jj] = destination;
			(*jj)->visited = true;
		}
	}
	
	// Choose a desk to focus
	VirtualDesktop *oldFocus = currentDesktop;
	VirtualDesktop *newFocus;
	if(windowsByHandle.find(foregroundHandle) != windowsByHandle.end())
		newFocus = destinations[windowsByHandle[foregroundHandle]];
	else
		newFocus = currentDesktop;
	
	// Move windows to their new destinations
	beginMovingWindows();
	for(map<WindowData*, VirtualDesktop*>::iterator ii=destinations.begin(); ii!=destinations.end(); ii++)
	{
		moveWindow(ii->first, ii->second);
		if(ii->first->desk == oldFocus)
		{
			if(ii->second==newFocus) {
				// Was on screen and stays on screen
				ii->first->desk = newFocus;
			} else {
				// Was on screen but move off screen
				ii->first->desk = newFocus;
				moveWindow(ii->first, ii->second);
			}
		} else {
			// Was off screen, stays off-screen
			moveWindow(ii->first, ii->second);
		}
	}
	finishMovingWindows();
	
	forceRedraw(false);
}

void VWM::moveDesk(int oldIndex, int newIndex)
{
	if(oldIndex<0 || newIndex<0 || oldIndex>=(int)desktops.size() || newIndex>=(int)desktops.size())
		return;
	
	VirtualDesktop *movingDesk = desktops[oldIndex];
	desktops.erase(desktops.begin()+oldIndex);
	desktops.insert(desktops.begin()+newIndex, movingDesk);
	
	int start = min(oldIndex, newIndex);
	int end = max(oldIndex, newIndex);
	for(int ii=start; ii<=end; ii++)
		desktops[ii]->index = ii;
	
	forceRedraw(false);
}

void VWM::switchDesk(VirtualDesktop *newDesk, bool skipFocus)
{
	if(!newDesk)
		return;
	if(newDesk == currentDesktop)
		return;
	
	beginMovingWindows();
	
	for(map<HWND, WindowData*>::iterator it = windowsByHandle.begin(); it != windowsByHandle.end(); it++)
	{
		HWND window = it->first;
		WindowData *windowData = it->second;
		
		bool moved = false;
		if(windowData->desk == currentDesktop) {
			// Move windows off-screen
			windowData->desk->storage->storeRect(windowData->screenPos);
			moved = true;
		} else if(windowData->desk == newDesk) {
			// Move windows from off-screen to on-
			windowData->desk->storage->unstoreRect(windowData->screenPos);
			moved = true;
		}
		
		if(moved) {
			setWindowPos(windowData->handle, &windowData->screenPos);
		}
	}
	
	finishMovingWindows();
	
	currentDesktop->focused = false;
	newDesk->focused = true;
	
	lastDesktop = currentDesktop;
	currentDesktop = newDesk;
	
	// Pick the topmost task on this desktop and focus it
	if(!skipFocus)
		raiseLocalForeground();
	
	forceRedraw(true);
}

/// If the focused window is on another desktop or is the desktop itself, focus
/// on the topmost window of this desktop. If there is no such window, focus on
/// the desktop.
void VWM::raiseLocalForeground()
{
	for(unsigned ii=0; ii<zOrder.size(); ii++)
	{
		HWND handle = zOrder[ii];
		if(windowsByHandle.find(handle)==windowsByHandle.end())
			continue;
		WindowData *window = windowsByHandle[handle];
		
		// Only focus something that's on the right desk
		if(window->desk != currentDesktop)
			continue;
		// Don't focus non-task windows (we want their owners instead) or
		// minimized windows (that'd be silly)
		if(!window->isTask || window->minimized)
			continue;
		
		raiseWindow(window);
		break;
	}
	
	// If we got throught he whole window list without finding something
	// suitable to focus, focus on the desktop.
	SetFocus(getDesktopWindow());
}

void VWM::moveWindow(WindowData *window, RECT pos, VirtualDesktop *desk)
{
	if(desk != window->desk)
		window->desk = desk;
	
	if(!window->desk->focused)
		desk->storage->unstoreRect(pos);
	if(!desk->focused)
		desk->storage->storeRect(pos);
	
	// TODO: If moving a window onto a different desk, move all children onto
	// that desk as well
	//set<WindowData*> movingWindows;
	
	window->screenPos = pos;
	setWindowPos(window->handle, &window->screenPos);
}

void VWM::moveWindow(WindowData *window, VirtualDesktop *desk)
{
	if(desk == window->desk)
		return;
	
	if(!window->desk->focused)
		window->desk->storage->unstoreRect(window->screenPos);
	if(!desk->focused)
		desk->storage->storeRect(window->screenPos);
	
	window->desk = desk;
	setWindowPos(window->handle, &window->screenPos);
}

void VWM::raiseWindow(WindowData *window)
{
	//SendMessage(getDesktopWindow(), LM_BRINGTOFRONT, 0, (LPARAM)window->handle);
	SwitchToThisWindow(window->handle, TRUE);
	forceRedraw(true);
}

void VWM::minimizeWindow(WindowData *window)
{
	SendMessage(window->handle, WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE, 0);
	window->focused = false;
}

void VWM::maximizeWindow(WindowData *window)
{
	SendMessage(window->handle, WM_SYSCOMMAND, (WPARAM)SC_MAXIMIZE, 0);
}

void VWM::restoreWindow(WindowData *window)
{
	SendMessage(window->handle, WM_SYSCOMMAND, (WPARAM)SC_RESTORE, 0);
}

void VWM::gather()
{
	/*if(dragging)
		cancelDrag();*/
	
	beginMovingWindows();
	
	// Move everything onto the current desktop
	for(map<HWND, WindowData*>::iterator it = windowsByHandle.begin(); it != windowsByHandle.end(); it++)
	{
		HWND handle = it->first;
		WindowData *windowData = it->second;
		
		RECT newPos = getGatherTarget(windowData->screenPos);
		windowData->screenPos = newPos;
		
		setWindowPos(it->first, &windowData->screenPos);
		
		windowData->desk = currentDesktop;
	}
	
	finishMovingWindows();
	
	// Delete all other desktops
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		if(desktops[ii]!=currentDesktop)
			delete desktops[ii];
	}
	desktops.clear();
	desktops.push_back(currentDesktop);
	currentDesktop->index = 0;
	
	forceRedraw(true);
}

void VWM::moveApp(WindowData *task, VirtualDesktop *dest)
{
	if(!dest || !task)
		return;
	
	if(!task->desk->focused)
		task->desk->storage->unstoreRect(task->screenPos);
	if(!dest->focused)
		dest->storage->storeRect(task->screenPos);
	
	// Move the foreground window and everything in its task-group (see
	// getWindowGroup) onto the new desktop.
	set<WindowData*> alongForTheRide;
	getTaskGroup(task, &alongForTheRide);
	
	// HACK: To keep switchDesktop from moving windows it shouldn't,
	// temporarily set their desk to nowhere.
	for(set<WindowData*>::iterator ii=alongForTheRide.begin(); ii!=alongForTheRide.end(); ii++)
		(*ii)->desk = NULL;
	
	switchDesk(dest, true);
	
	for(set<WindowData*>::iterator ii=alongForTheRide.begin(); ii!=alongForTheRide.end(); ii++)
		(*ii)->desk = dest;
}

float GetRCFloat(const char *name, float defaultVal)
{
	char buf[4096];
	float ret = defaultVal;
	GetRCLine(name, buf, 4096, "");
	sscanf(buf, "%f", &ret);
	
	return ret;
}
