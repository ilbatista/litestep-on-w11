/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

static const char *dragWindowClassname = "screenvwm_DragWindow";
static const char *dragWindowName = "ScreenVWM_Drag";

#define GWL_CLASSPOINTER 0

struct DragEventArg
{
	SHORT size;
	DragWindow *window;
};

DragInfo *drag = NULL;
DragWindow *dragWindow = NULL;
ElementContext *droppedContext = NULL;

DragInfo::DragInfo(LayoutCacheNode *pos, int x, int y, MouseButton button)
	: node(pos), startPanel(pos->context.panel), element(pos->element),
	  elementContext(pos->context), button(button), mouseOrigin(x, y)
{
	active = false;
	mouseOffset.x = x - node->context.boundingRect.left;
	mouseOffset.y = y - node->context.boundingRect.top;
	lastHover = NULL;
}

void VWMPanel::finishDrag()
{
	if(!drag) {
		cancelDrag();
		return;
	}
	
	Point mousePos = getCursorPos();
	VWMPanel *targetPanel = vwm->findPanel(mousePos.x, mousePos.y);
	
	// TODO: Handle drags that don't end on a panel
	if(!targetPanel) {
		cancelDrag();
		return;
	}
	
	mousePos.x -= targetPanel->x;
	mousePos.y -= targetPanel->y;
	
	targetPanel->dropDraggedObject(drag->element->prefix, mousePos.x, mousePos.y);
	
	cancelDrag();
}

void VWMPanel::dropDraggedObject(string droppedObjName, int x, int y)
{
	LayoutCacheNode *node = layout->elementAtPoint(x, y);
	if(!node) return;
	
	string suffix = string("OnDrop_") + droppedObjName;
	node = node->findSuffix(suffix);
	if(!node) return;
	
	string varname = node->element->prefix+suffix;
	string dropCmd = getConfigLine(varname.c_str(), "", "");
	
	droppedContext = &node->context;
	LSExecute(window, dropCmd.c_str(), SW_SHOWNORMAL);
	droppedContext = NULL;
}

void VWMPanel::hoverDraggedObject(string hoveredObjName, int x, int y)
{
	LayoutCacheNode *node = layout->elementAtPoint(x, y);
	if(!node) return;
	
	string suffix = string("OnHover_") + hoveredObjName;
	node = node->findSuffix(suffix);
	if(!node) return;
	
	if(drag->lastHover==node)
		return;
	drag->lastHover = node;
	
	string varname = node->element->prefix+suffix;
	string hoverCmd = getConfigLine(varname.c_str(), "", "");
	
	LSExecute(window, hoverCmd.c_str(), SW_SHOWNORMAL);
}

void VWMPanel::cancelDrag()
{
	if(drag) {
		if(drag->node && drag->node->origElement) {
			drag->node->element = drag->node->origElement;
			drag->node->origElement = NULL;
			forceRedraw();
		}
		delete drag;
		drag = NULL;
	}
	if(dragWindow) {
		delete dragWindow;
		dragWindow = NULL;
	}
}

void VWMPanel::beginDrag()
{
	if(!drag)
		return;
	
	drag->active = true;
	dragWindow = new DragWindow(drag->node, drag->mouseOffset);
	
	if(drag->node) {
		if(drag->node->element->dragPlaceholder) {
			drag->node->origElement = drag->node->element;
			drag->node->element = drag->node->element->dragPlaceholder;
		}
	}
	forceRedraw();
}

static WNDCLASSEX dragWindowClass;

void DragWindow::registerWindowClass()
{
	memset(&dragWindowClass, 0, sizeof(WNDCLASSEX));
	dragWindowClass.cbSize = sizeof(WNDCLASSEX);
	dragWindowClass.cbWndExtra = sizeof(VWM*);
	dragWindowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	dragWindowClass.lpfnWndProc = DragWindow::eventHandler;
	dragWindowClass.hInstance = dllInstance;
	dragWindowClass.lpszClassName = dragWindowClassname;

	if (!RegisterClassEx(&dragWindowClass)) {
		// Class could not be registered, try to re-register
		UnregisterClass(dragWindowClassname, dllInstance);

		if (!RegisterClassEx(&dragWindowClass)) {
			// Still no luck, error out
			fatal("Unable to register drag window class.");
		}
	}
}

void DragWindow::unregisterWindowClass()
{
	UnregisterClass(dragWindowClassname, dllInstance);
}

DragWindow::DragWindow(LayoutCacheNode *sourceNode, Point mouseOffset)
{
	this->mouseOffset = mouseOffset;
	rootElement = sourceNode->element;
	
	elementContext = sourceNode->context;
	elementContext.boundingRect.left = 0;
	elementContext.boundingRect.top = 0;
	
	// If the element which is being dragged defines a substitute for itself
	// to be used when dragging, use it.
	if(rcIsDefined("DragElement", rootElement->prefix.c_str())) {
		string rootElementPrefix = getConfigString("DragElement", "", rootElement->prefix.c_str());
		if(rootElementPrefix != "")
			rootElement = layoutPool->getElement(rootElementPrefix);
	}
	
	// Build a layout tree (from scratch).
	// TODO/FIXME: Think about what to do when branch conditions and flow
	// contents change mid-drag. In particular, we can't leave references to
	// closed windows lying around.
	layout = rootElement->buildLayout(&elementContext, NULL);
	
	width  = elementContext.boundingRect.width;
	height = elementContext.boundingRect.height;
	Point mousePos = getCursorPos();
	int x = mousePos.x - mouseOffset.x;
	int y = mousePos.y - mouseOffset.y;
	
	HWND parentWindow = GetDesktopWindow();
	DragEventArg arg = {sizeof(DragEventArg), this};
	window = CreateWindowEx(
		WS_EX_TOOLWINDOW,
		dragWindowClassname,
		dragWindowName,
		WS_POPUP,
		x, y, width, height,
		parentWindow,
		NULL, dllInstance, &arg);
	if (!window)
		fatal("Unable to create drag window.");
	
	SetWindowPos(window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	ShowWindow(window, SW_SHOWNORMAL);
	
	// Mark this window as 'belonging to Litestep' so that we don't try to operate on ourself
	SetWindowLong(window, GWL_USERDATA, magicDWord);
	
	SetTimer(window, 0, 50, NULL);
	
	initDrawContext(width, height);
}

DragWindow::~DragWindow()
{
	KillTimer(window, 0);
	destroyDrawContext();
	DestroyWindow(window);
}

void DragWindow::initDrawContext(int width, int height)
{
	HDC windowDrawContext = GetDC(window);
	if(!windowDrawContext)
		MessageBox(NULL, "Failed to get a draw context for drag window.", "ScreenVWM", MB_TOPMOST);
	backBuffer = CreateCompatibleDC(windowDrawContext);
	backBufferMem = CreateCompatibleBitmap(windowDrawContext, width, height);
	ReleaseDC(window, windowDrawContext);
	
	HBITMAP oldBackBufferMem = (HBITMAP)SelectObject(backBuffer, backBufferMem);
	DeleteObject(oldBackBufferMem);
}

void DragWindow::destroyDrawContext()
{
	DeleteDC(backBuffer);
	DeleteObject(backBufferMem);
}

LRESULT CALLBACK DragWindow::eventHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(uMsg == WM_NCCREATE)
		return 1;
	
	if (uMsg == WM_CREATE) {
		LPVOID &createParams = LPCREATESTRUCT(lParam)->lpCreateParams;

		if (createParams) {
			DragWindow *dragwindow = ((DragEventArg*)(createParams))->window;
			SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)dragwindow);
		}
		return 1;
	}
	
	DragWindow *dragwindow = (DragWindow*)(GetWindowLong(hWnd, GWL_CLASSPOINTER));
	if(!dragwindow) return DefWindowProc(hWnd, uMsg, wParam, lParam);
	
	return dragwindow->handleEvent(uMsg, wParam, lParam);
}

int DragWindow::handleEvent(UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_TIMER:
			followCursor();
			return 0;
			
		case WM_PAINT:
			paint();
			return 0;
			
		default:
			return DefWindowProc(window, msg, wParam, lParam);
	}
	
	return 1;
}

void DragWindow::paint()
{
	PAINTSTRUCT ps;
	HDC drawContext = BeginPaint(window, &ps);
	
	// Draw the widget hierarchy
	layout->element->draw(backBuffer, layout);
	
	// Flip the back buffer onto the screen
	BitBlt(drawContext, 0, 0,
		width, height,
		backBuffer, 0, 0, SRCCOPY);
	EndPaint(window, &ps);
}

void DragWindow::followCursor()
{
	Point mousePos = getCursorPos();
	int x = mousePos.x - mouseOffset.x;
	int y = mousePos.y - mouseOffset.y;
	MoveWindow(window, x, y, width, height, true);
}
