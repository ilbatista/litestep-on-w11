#include "screenvwm.hpp"

BranchElement::BranchElement(string prefix)
	:LayoutElement(prefix)
{
	char *branchNames = strdup(getConfigLine("Branches", "", prefix.c_str()).c_str());
	vector<string> tokenizedBranchNames;
	const char *separators = " \t\n";
	char *pos = strtok(branchNames, separators);
	while(pos) {
		tokenizedBranchNames.push_back(pos);
		pos = strtok(NULL, separators);
	}
	free(branchNames);
	
	for(unsigned ii=0; ii<tokenizedBranchNames.size(); ii++) {
		branches.push_back(parseBranch(tokenizedBranchNames[ii]));
	}
}

BranchElement::Branch BranchElement::parseBranch(const string &prefix)
{
	Branch ret;
	ret.element = layoutPool->getElement(prefix);
	string conditionVar = prefix+"Condition";
	string conditionStr = getConfigString(conditionVar.c_str(), "true", "");
	const char *conditionCstr = conditionStr.c_str();
	ret.condition = parseExpression(conditionCstr);
	return ret;
}

BranchElement::~BranchElement()
{
	for(unsigned ii=0; ii<branches.size(); ii++)
		delete branches[ii].condition;
}

LayoutCacheNode *BranchElement::buildLayout(ElementContext *context, LayoutCacheNode *prev)
{
	LayoutElement *branch = getBranch(context);
	
	LayoutCacheNode *ret = LayoutElement::buildLayout(context, prev);
	ret->element = this;
	LayoutCacheNode *child = NULL;
	
	if(prev) {
		child = prev->children[0];
		ret->children.clear();
	}
	
	child = branch->buildLayout(context, child);
	ret->children.push_back(child);
	child->parent = ret;
	return ret;
}

pair<int,int> BranchElement::getLength(ElementContext *context, bool vertical)
{
	LayoutElement *branch = getBranch(context);
	return branch->getLength(context, vertical);
}

bool BranchElement::changed(LayoutCacheNode *node)
{
	if(node->children.size() != 1)
		return true;
	
	if(node->children[0]->element != getBranch(&node->context)) {
		return true;
	} else {
		return node->children[0]->element->changed(node->children[0]);
	}
}

LayoutElement *BranchElement::getBranch(ElementContext *context)
{
	for(unsigned ii=0; ii<branches.size(); ii++)
	{
		if(branches[ii].condition->evaluate(context))
			return branches[ii].element;
	}
	return getNullElement();
}

