/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma once

struct DragInfo
{
	DragInfo(LayoutCacheNode *element, int x, int y, MouseButton button);
	
	bool active;
	LayoutCacheNode *node;
	LayoutCacheNode *lastHover;
	VWMPanel *startPanel;
	Point mouseOrigin;
	Point mouseOffset;
	LayoutElement *element;
	ElementContext elementContext;
	MouseButton button;
};

class DragWindow
{
public:
	static void registerWindowClass();
	static void unregisterWindowClass();
	
	DragWindow(LayoutCacheNode *sourceNode, Point mouseOffset);
	~DragWindow();
	void initDrawContext(int width, int height);
	void destroyDrawContext();
	
	static LRESULT CALLBACK eventHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	int handleEvent(UINT msg, WPARAM wParam, LPARAM lParam);
	void paint();
	void followCursor();
	
	Point mouseOffset;
	LayoutElement *rootElement;
	ElementContext elementContext;
	LayoutCacheNode *layout;
	HWND window;
	HDC backBuffer;
	HBITMAP backBufferMem;
	int width, height;
};

extern DragInfo *drag;
extern DragWindow *dragWindow;