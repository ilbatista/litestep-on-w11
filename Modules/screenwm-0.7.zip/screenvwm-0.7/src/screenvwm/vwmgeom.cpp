/*
This is part of ScreenVWM, which is based in part on the Litestep
shell source code.

Copyright (C) 2008 Jim Babcock
Copyright (C) 1997-2008 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "screenvwm.hpp"

void VWM::initDesktops()
{
	trace << "initDesktops called\n";
	if(!settings->autoGather) {
		trace << "Calling restoreDesktops\n";
		if(restoreDesktops())
			return;
	}
	
	// Start with only one desktop
	desktops.push_back(new VirtualDesktop(0, storageManager.getStorageArea()));
	
	currentDesktop = desktops[0];
	lastDesktop = currentDesktop;
	desktops[0]->focused = true;
	
	updateTaskLists(false);
}

bool VWM::restoreDesktops()
{
	char buf[4096];
	
	if(!SendMessage(GetLitestepWnd(), LM_RESTOREDATA, MAKEWPARAM(sizeof(buf), MODULE_ID), (LPARAM)buf)) {
		trace << "No restorable desktops found.\n";
		return false;
	}
	
	vector<StorageArea*> deskAreas;
	int focus = storageManager.restore((void*)buf, deskAreas);
	
	trace << "Restored "<<deskAreas.size()<<" desktops.\n";
	for(unsigned ii=0; ii<deskAreas.size(); ii++)
	{
		desktops.push_back(new VirtualDesktop(ii, deskAreas[ii]));
	}
	
	currentDesktop = desktops[focus];
	lastDesktop = currentDesktop;
	desktops[focus]->focused = true;
	
	updateTaskLists(true);
	
	return true;
}

void VWM::saveDesktops()
{
	vector<StorageArea*> deskAreas;
	int focus = 0;
	for(unsigned ii=0; ii<desktops.size(); ii++) {
		deskAreas.push_back(desktops[ii]->storage);
		if(desktops[ii]->focused)
			focus = ii;
	}
	
	int len;
	void *data = storageManager.save(&len, focus, deskAreas);
	SendMessage(GetLitestepWnd(), LM_SAVEDATA, MAKEWPARAM(len, MODULE_ID), (LPARAM)data);
	free(data);
}

/////////////////////////////////////////////////////////////////////////////

VirtualDesktop::VirtualDesktop(int index, StorageArea *storage)
{
	this->index = index;
	focused = false;
	this->storage = storage;
	numTasks = 0;
}

VirtualDesktop::~VirtualDesktop()
{
	delete storage;
}

string VirtualDesktop::getName()
{
	char buf[32];
	sprintf(buf, "Desktop %i", index+1);
	return buf;
}

string VirtualDesktop::getLabel()
{
	char buf[16];
	itoa(index+1, buf, 10);
	return buf;
}

/////////////////////////////////////////////////////////////////////////////

void VWM::updateTaskLists(bool keepEmpties)
{
	// Match tasks up to VWMs
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		desktops[ii]->tasks.clear();
	}
	for(map<HWND, WindowData*>::iterator ii=windowsByHandle.begin(); ii!=windowsByHandle.end(); ii++)
	{
		WindowData *window = ii->second;
		
		if(!window->desk)
			continue;
		if(!window->isTask)
			continue;
		
		window->desk->tasks.push_back(window);
	}
	
	// If any desk has no tasks on it, delete it
	// But don't delete desks while dragging/dropping
	if(!settings->keepEmptyDesktops && !keepEmpties)
	{
		for(unsigned ii=0; ii<desktops.size(); ii++)
		{
			if(desktops[ii]->tasks.size())
				continue;
			if(desktops[ii]->focused && settings->keepEmptyFocusedDesktop)
				continue;
			
			if(destroyDesktop(desktops[ii])) {
				trace << "Destroyed empty desktop\n";
				ii--;
			}
		}
	}
}

RECT VWM::getMaximizeArea()
{
	// TODO: Get maximize-area properly
	/*int screenWidth = getScreenWidth();
	int screenHeight = getScreenHeight();
	RECT ret;
		ret.left = GetRCCoordinate("SDALeft", 0, screenWidth);
		ret.top = GetRCCoordinate("SDATop", 0, screenHeight);
		ret.right = GetRCCoordinate("SDARight", screenWidth, screenWidth);
		ret.bottom = GetRCCoordinate("SDABottom", screenHeight, screenHeight);
		
		if(ret.right <= ret.left)
			ret.right = screenWidth;
		if(ret.bottom <= ret.top)
			ret.bottom = screenHeight;*/
	
	RECT ret;
		ret.left = SCREEN_LEFT;
		ret.top = SCREEN_TOP;
		ret.right = ret.left + SCREEN_WIDTH;
		ret.bottom = ret.top + SCREEN_HEIGHT;
	return ret;
}


RECT VWM::getGatherTarget(RECT source)
{
	Rect ret = source;
	Rect maximizeArea = getMaximizeArea();
	
	// If this is inside a VWM's storage area, first bring it in
	VirtualDesktop *desk = deskFromLocation(source);
	if(desk && !desk->focused)
		desk->storage->unstoreRect((RECT)ret);
	
	// TODO: Get the window-maximize region, rather than using (0,0,w,h).
	
	int offsetX=0;
	int offsetY=0;
	
	// If a window is wider or taller than the screen, center it. Otherwise,
	// match an edge. (This happens more often than you'd think, because
	// maximized windows are a few pixels bigger than the maximize-area so
	// that their borders fall offscreen.)
	if(ret.width > maximizeArea.width) {
		if(ret.left > maximizeArea.left || ret.getRight() < maximizeArea.getRight())
			ret.left = maximizeArea.left - (ret.width-maximizeArea.width)/2;
	} else if(ret.getRight() > maximizeArea.getRight()) {
		ret.left -= ret.getRight() - maximizeArea.getRight();
	} else if(ret.left < maximizeArea.left) {
		ret.left = maximizeArea.left;
	}
	
	if(ret.height > maximizeArea.height) {
		if(ret.top > maximizeArea.top || ret.getBottom() < maximizeArea.getBottom())
			ret.top = maximizeArea.top - (ret.height-maximizeArea.height)/2;
	} else if(ret.getBottom() > maximizeArea.getBottom()) {
		ret.top += maximizeArea.getBottom() - ret.getBottom();
	} else if(ret.top < maximizeArea.top) {
		ret.top = maximizeArea.top;
	}
	
	return ret;
}

bool RectOverlap(RECT a, RECT b)
{
	return b.left <= a.right && a.left <= b.right
	     && a.top <= b.bottom && b.top <= a.bottom;
}

VirtualDesktop *VWM::deskFromLocation(Rect pos)
{
	// If it's on-screen, it's on the focused desk
	Rect screenRect(SCREEN_LEFT, SCREEN_TOP, SCREEN_WIDTH, SCREEN_HEIGHT);
	if(pos.overlaps(screenRect))
		return currentDesktop;
	
	for(unsigned ii=0; ii<desktops.size(); ii++)
	{
		VirtualDesktop *desk = desktops[ii];
		Rect storageRect = desk->storage->getRect();
		if(storageRect.overlaps(pos)) {
			return desk;
		}
	}
	
	return NULL;
}
