 /*

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
#define __WIN32_LEAN_AND_MEAN__

#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <mmsystem.h>
#include "winctrl.h"
#include "lsapi.h"
#include "litestep.h"
#include "win98.h"

#define WINCTRL_WINLISTID 0x21110000;
#define WINCTRL_WINLISTCOUNTID 0x21120000;

const char rcsRevision[] = "$Revision: 1.0 $"; // Our Version 
const char rcsId[] = "$Id: winctrl.c,v 1.0 1999/09/28 18:34:27 mirul Exp $"; // The Full RCS ID.

char szAppName[] = "winctrlWindow";
//char szLitestepPath [256];
//char szImagePath [256];
//char inipath[256];

char WinShadeSound[256];
char WinGrowDownSound[256];

HWND hMainWnd = NULL; // main window handle
HWND hActiveWin = NULL;
HWND parent = NULL;
HWND deskTop = NULL;
HINSTANCE dll = NULL;
LONG DesktopOldWndProc;

//int TitleBarHeight;
int nWin = 0, maxWin = 0;
winDataType localwinList[MAXWIN];
COLORREF DefaultColors[25];

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DesktopWndHookProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

//void (__stdcall *SwitchToThisWindow)(HWND, int);

// -------------------------------------------------------------------------------------------------------
/* DEBUG STUFF
void Report(LPCSTR strRep)
{
	char dt[9], tm[9];
	char ln[1024];
	DWORD dwBytes = 0;

	HANDLE hFile = CreateFile("C:\\LiteStep\\error.log", GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile) {
		_strdate(dt);
		_strtime(tm);
		wsprintf(ln, "%s - %s : %s\n", dt, tm, strRep);
		SetFilePointer(hFile, 0, 0, FILE_END);
		WriteFile(hFile, ln, strlen(ln), &dwBytes, NULL);
		CloseHandle(hFile);
	}
}
*/

// -------------------------------------------------------------------------------------------------------
// Install a hook proc to the desktop
// -------------------------------------------------------------------------------------------------------
void AddDesktopHook(void)
{
  DesktopOldWndProc = GetWindowLong(deskTop, GWL_WNDPROC);
  SetWindowLong(deskTop, GWL_WNDPROC, (LONG) DesktopWndHookProc);
}

// -------------------------------------------------------------------------------------------------------
// Remove the desktop hook proc
// -------------------------------------------------------------------------------------------------------
void DeleteDesktopHook(void)
{
  SetWindowLong(deskTop, GWL_WNDPROC, DesktopOldWndProc);
}

// -------------------------------------------------------------------------------------------------------
// Returns true if a window is in the list
// -------------------------------------------------------------------------------------------------------
int inWinList(HWND hwnd)
{
	int i;

	if (!hwnd) 
		return -1;
	for (i=0;i<nWin;i++)
		if (localwinList[i].hwnd == hwnd) 
			return i;
	return -1;
}

// -------------------------------------------------------------------------------------------------------
// Add a window to the list
// -------------------------------------------------------------------------------------------------------
void addWindow(HWND hwnd, long height)
{

	if (nWin < maxWin-1) {
    	localwinList[nWin].hwnd = hwnd;
   		localwinList[nWin].height = height;
    	nWin++;
	}
}

// -------------------------------------------------------------------------------------------------------
// Compact the window list
// -------------------------------------------------------------------------------------------------------
void RemoveWindow(int win)
{
	int i;

	for (i=win;i<nWin-1;i++) {
		memcpy(&localwinList[i], &localwinList[i+1], sizeof(winDataType));
	}
	memset(&localwinList[nWin-1], 0, sizeof(winDataType));
	nWin--;
}

// -------------------------------------------------------------------------------------------------------
// NextToken
// -------------------------------------------------------------------------------------------------------
LPCTSTR NextToken( LPCTSTR s, LPTSTR d, UINT m )
{
	while( *s && *s <= 32 )
		s++;
	
	if( *s == 34 )
	{
		s++;
		
		while( *s && *s != 34 && --m )
			*d++ = *s++;
		
		s++;
	}
	else
	{
		while( *s && *s > 32 && --m )
			*d++ = *s++;
	}
	
	*d = 0;
	return s;
}

// -------------------------------------------------------------------------------------------------------
// ParseInteger
// -------------------------------------------------------------------------------------------------------
int ParseInteger( LPCTSTR pszSource )
{
	int nValue = 0;
	BOOL fNegative = FALSE;
	
	while( *pszSource && *pszSource <= 32 )
		pszSource++;
	
	if( *pszSource && *pszSource == '-' )
	{
		fNegative = TRUE;
		pszSource++;
	}
	
	while( *pszSource && *pszSource >= '0' && *pszSource <= '9' )
		nValue = (nValue * 10) + (*pszSource++ - '0');
	
	return fNegative ? -nValue : nValue;
}

// -------------------------------------------------------------------------------------------------------
// Test to determine whether window is exluded
// -------------------------------------------------------------------------------------------------------
BOOL IsExcluded(HWND hTest)
{
	if (IsIconic(hTest) || IsZoomed(hTest) || (hTest == NULL)  || (hTest == deskTop))
		return TRUE;
	else
		return FALSE;
}

// -------------------------------------------------------------------------------------------------------
// Shrink window to titlebar, remembering original height
// -------------------------------------------------------------------------------------------------------
void WinShade(HWND MoveHwnd, int ListIndex)
{
	int i = ListIndex;
	RECT r;
	
  if (i !=-1) {
		SetForegroundWindow(MoveHwnd);
		if (localwinList[i].bShaded == TRUE) return;
	}

	GetWindowRect(MoveHwnd, &r);	
//	MoveWindow(MoveHwnd, r.left, r.top, r.right-r.left, GetSystemMetrics(SM_CYMIN), TRUE);
	SetWindowPos(MoveHwnd, HWND_TOP, 
		         r.left, r.top, 
				 r.right-r.left, 
				 GetSystemMetrics(SM_CYMIN),
				 SWP_NOOWNERZORDER | SWP_NOSENDCHANGING );
	sndPlaySound(WinShadeSound, SND_SYNC); 
		
	if (i != -1) {
		localwinList[i].height = r.bottom - r.top;
	} else {
		i = nWin;
		addWindow(MoveHwnd, r.bottom - r.top);
	}

	SetForegroundWindow(MoveHwnd);
	localwinList[i].bShaded = TRUE;

	return;
}

// -------------------------------------------------------------------------------------------------------
// Restore window to original height
// -------------------------------------------------------------------------------------------------------
void WinUnshade(HWND MoveHwnd, int ListIndex)
{
	int i = ListIndex;
	RECT r;
	
	if (i == -1)
	{
		SetForegroundWindow(MoveHwnd);
	 	return;
	} else
		if (!localwinList[i].bShaded) return;

	GetWindowRect(MoveHwnd, &r);	
	MoveWindow(MoveHwnd, r.left, r.top, r.right-r.left, localwinList[i].height, TRUE);
	InvalidateRect(MoveHwnd,NULL,FALSE);
	sndPlaySound("RestoreDown", SND_SYNC); 
	SetForegroundWindow(MoveHwnd);
	localwinList[i].bShaded = FALSE;

	return;
}

// -------------------------------------------------------------------------------------------------------
// Set system parameters
// -------------------------------------------------------------------------------------------------------
void SetSystemParameters(UINT uiActionGET, UINT uiActionSET, char * pszArgs)
{
	BOOL bTemp;
	BOOL pbTemp;

	if ( pszArgs == NULL )
	{
		SystemParametersInfo(uiActionGET, (UINT)NULL, &pbTemp, (UINT)NULL);
		bTemp = !pbTemp;
	}
	else if (strstr(strlwr(pszArgs),"on"))
		bTemp = TRUE;
	else if (strstr(strlwr(pszArgs),"off"))
		bTemp = FALSE;
	else
	{
		SystemParametersInfo(uiActionGET, (UINT)NULL, &pbTemp, (UINT)NULL);
		bTemp = !pbTemp;
	}
	// Don't ask, but this way it works. Ignore the warnings.
	SystemParametersInfo(uiActionSET, (UINT)NULL , bTemp, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}

// -------------------------------------------------------------------------------------------------------
// Grow window to maximum height or just downwards
// -------------------------------------------------------------------------------------------------------
BOOL WinGrowMaxHeight(HWND MoveHwnd, BOOL bMax)
{
	int i;
	RECT r, WorkArea;

	if (IsExcluded(MoveHwnd)) return FALSE;

	GetWindowRect(MoveHwnd, &r);	
	SystemParametersInfo(SPI_GETWORKAREA,0,(PVOID)&WorkArea,SPIF_SENDCHANGE);
	MoveWindow
		(MoveHwnd, 
		 r.left, 
		 bMax ? 0 : r.top, 
		 r.right-r.left, 
		 bMax ? WorkArea.bottom-WorkArea.top : WorkArea.bottom-r.top,
		 TRUE);
	InvalidateRect(MoveHwnd,NULL,FALSE);
	SetForegroundWindow(MoveHwnd);
	i = inWinList(MoveHwnd);
	if (i != -1)
		localwinList[i].bShaded = FALSE;
	return TRUE;
}

// -------------------------------------------------------------------------------------------------------
// Bang: Grow window to maximum height
// -------------------------------------------------------------------------------------------------------
void BangWinMaxHeight(void)
{
	WinGrowMaxHeight(hActiveWin, TRUE);
}

// -------------------------------------------------------------------------------------------------------
// Bang: Grow bottom of window to bottom of screen
// -------------------------------------------------------------------------------------------------------
void BangWinGrowDown(void)
{
	if (WinGrowMaxHeight(hActiveWin, FALSE))
		sndPlaySound("RestoreDown", SND_SYNC); 
}

// -------------------------------------------------------------------------------------------------------
// Bang: Move window to position in pszArgs
// -------------------------------------------------------------------------------------------------------
void BangWinHome(HWND hCaller, LPCTSTR pszArgs)
{
	HWND MoveHwnd = hActiveWin;
	RECT r;
	LPCTSTR p = pszArgs;
	TCHAR szValue[16];
	int nY, nX;

	if (pszArgs == NULL) return;
	if (IsExcluded(MoveHwnd)) return;
	
	p = NextToken( p, szValue, 16 );
	nX = ParseInteger( szValue );
	nX = (nX < 0) ? (GetSystemMetrics(SM_CXSCREEN) + nX + 1) : nX;
	
	p = NextToken( p, szValue, 16 );
	nY = ParseInteger( szValue );
	nY = (nY < 0) ? (GetSystemMetrics(SM_CYSCREEN) + nY + 1) : nY;

	GetWindowRect(MoveHwnd, &r);	
	MoveWindow(MoveHwnd, nY, nX, r.right-r.left, r.bottom-r.top, TRUE);
	SetForegroundWindow(MoveHwnd);
	return;
}

// -------------------------------------------------------------------------------------------------------
// Bang: Grow window to maximum width
// -------------------------------------------------------------------------------------------------------
void BangWinMaxWidth(void)
{
	HWND MoveHwnd = hActiveWin;
	RECT r, WorkArea;

	if (IsExcluded(MoveHwnd)) return;

	GetWindowRect(MoveHwnd, &r);	
	SystemParametersInfo(SPI_GETWORKAREA,0,(PVOID)&WorkArea,SPIF_SENDCHANGE);
	MoveWindow(MoveHwnd, 0, r.top, WorkArea.right-WorkArea.left, r.bottom-r.top, TRUE);
	GetWindowRect(MoveHwnd, &r);
	SetForegroundWindow(MoveHwnd);
	return;
}

// -------------------------------------------------------------------------------------------------------
// Bang: Grow window to the right by value in pszArgs
// -------------------------------------------------------------------------------------------------------
void BangWinDeltaX(HWND hCaller, LPCTSTR pszArgs)
{
	HWND MoveHwnd = hActiveWin;
	RECT r;
	LPCTSTR p = pszArgs;
	TCHAR szValue[16];
	int nX;

	if (IsExcluded(MoveHwnd)) return;

	if ( pszArgs != NULL ) {
    p = NextToken( p, szValue, 16 );
    nX = ParseInteger( szValue );
    nX = (nX == 0) ? 1 : nX;
  } else
    nX = 1;

	GetWindowRect(MoveHwnd, &r);	
	MoveWindow(MoveHwnd, r.left, r.top, r.right-r.left+nX, r.bottom-r.top, TRUE);
	InvalidateRect(MoveHwnd,NULL,FALSE);
	SetForegroundWindow(MoveHwnd);
	return;
}

// -------------------------------------------------------------------------------------------------------
// Bang: Grow window to the bottom by value in pszArgs
// -------------------------------------------------------------------------------------------------------
void BangWinDeltaY(HWND hCaller, LPCTSTR pszArgs)
{
	int i;
	HWND MoveHwnd = hActiveWin;
	RECT r;
	LPCTSTR p = pszArgs;
	TCHAR szValue[16];
	int nY;

	if (IsExcluded(MoveHwnd)) return;
	i = inWinList(MoveHwnd);
	if (i !=-1) {
		SetForegroundWindow(MoveHwnd);
		if (localwinList[i].bShaded == TRUE) return;
	}

	if ( pszArgs != NULL ) {
    p = NextToken( p, szValue, 16 );
    nY = ParseInteger( szValue );
    nY = (nY == 0) ? 1 : nY;
  } else
    nY = 1;

	GetWindowRect(MoveHwnd, &r);	
	MoveWindow(MoveHwnd, r.left, r.top, r.right-r.left, r.bottom-r.top+nY, TRUE);
	InvalidateRect(MoveHwnd,NULL,FALSE);
	SetForegroundWindow(MoveHwnd);
	return;
}

// -------------------------------------------------------------------------------------------------------
// Bang: Drag full window "on", "off" or toggle
// -------------------------------------------------------------------------------------------------------
void BangWinFullDrag(HWND hCaller, char * pszArgs)
{
	BOOL bTemp;

	if ( pszArgs == NULL )
	{
		SystemParametersInfo(SPI_GETDRAGFULLWINDOWS, (UINT)NULL, &bTemp, (UINT)NULL);
		bTemp = !bTemp;
	}
	else if (strstr(strlwr(pszArgs),"on"))
		bTemp = TRUE;
	else if (strstr(strlwr(pszArgs),"off"))
		bTemp = FALSE;
	else //if (strstr(strlwr(pszArgs),"toggle"))
	{
		SystemParametersInfo(SPI_GETDRAGFULLWINDOWS, (UINT)NULL, &bTemp, (UINT)NULL);
		bTemp = !bTemp;
	}
	SystemParametersInfo(SPI_SETDRAGFULLWINDOWS, bTemp, NULL, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}

// -------------------------------------------------------------------------------------------------------
// Bang: Autoraise tracked window "on" or "off"
// -------------------------------------------------------------------------------------------------------
void BangWinAutoRaise(HWND hCaller, char * pszArgs)
{
	if ( pszArgs == NULL )
    return;
  else if ( (strstr(strlwr(pszArgs),"on")) || (strstr(strlwr(pszArgs),"off")) ) {
    SetSystemParameters(SPI_GETACTIVEWINDOWTRACKING, SPI_SETACTIVEWINDOWTRACKING, pszArgs);
    SetSystemParameters(SPI_GETACTIVEWNDTRKZORDER, SPI_SETACTIVEWNDTRKZORDER, pszArgs);
  }
}

// -------------------------------------------------------------------------------------------------------
// Bang: Animate combobox "on", "off" or toggle
// -------------------------------------------------------------------------------------------------------
void BangWinComboboxAnimate(HWND hCaller, char * pszArgs)
{
	SetSystemParameters(SPI_GETCOMBOBOXANIMATION, SPI_SETCOMBOBOXANIMATION, pszArgs);
}

// -------------------------------------------------------------------------------------------------------
// Bang: Animate menu "on", "off" or toggle
// -------------------------------------------------------------------------------------------------------
void BangWinMenuAnimate(HWND hCaller, char * pszArgs)
{
	SetSystemParameters(SPI_GETMENUANIMATION, SPI_SETMENUANIMATION, pszArgs);
}

// -------------------------------------------------------------------------------------------------------
// Bang: Active window tracking "on", "off" or "toggle"
// -------------------------------------------------------------------------------------------------------
void BangWinActiveTrack(HWND hCaller, char * pszArgs)
{
	SetSystemParameters(SPI_GETACTIVEWINDOWTRACKING, SPI_SETACTIVEWINDOWTRACKING, pszArgs);
}

// -------------------------------------------------------------------------------------------------------
// Bang: Window shade "on", "off" or toggle
// -------------------------------------------------------------------------------------------------------
void BangWinShade(HWND hCaller, char * pszArgs)
{
	int i;

	if (IsExcluded(hActiveWin)) return;
	i = inWinList(hActiveWin);

  if (pszArgs == NULL)
	{
		if (i != -1)
		{
			// found in our list
			if (localwinList[i].bShaded)
				WinUnshade(hActiveWin,i);
			else
				WinShade(hActiveWin,i);
		} else
			WinShade(hActiveWin,i);
	}
	else if (strstr(strlwr(pszArgs),"on"))
	{
		WinShade(hActiveWin,i);
	}
	else if (strstr(strlwr(pszArgs),"off"))
	{
		WinUnshade(hActiveWin,i);
	}
	else
	{
		if (i != -1)
		{
			// found in our list
			if (localwinList[i].bShaded)
				WinUnshade(hActiveWin,i);
			else
				WinShade(hActiveWin,i);
		} else
			WinShade(hActiveWin,i);
	}
}

// -------------------------------------------------------------------------------------------------------
// Bang: Revert to default window colors
// -------------------------------------------------------------------------------------------------------
void BangWinDefaultColors(HWND hCaller, char * pszArgs)
{
  const int lpaElements[25] = {0,1,2,3,4,5,6,7,8,9,
                               10,11,12,13,14,15,16,17,18,19,
                               20,21,22,23,24};   
  SetSysColors( 25, lpaElements, DefaultColors );
}

// -------------------------------------------------------------------------------------------------------
// Register bang commands
// -------------------------------------------------------------------------------------------------------
void RegisterBangCommands(void)
{
	AddBangCommand("!WinHome", BangWinHome);
	AddBangCommand("!WinMaxHeight", BangWinMaxHeight);
	AddBangCommand("!WinMaxWidth", BangWinMaxWidth);
	AddBangCommand("!WinGrowDown", BangWinGrowDown);
	AddBangCommand("!WinFullDrag", BangWinFullDrag);
	AddBangCommand("!WinComboboxAnimate", BangWinComboboxAnimate);
	AddBangCommand("!WinMenuAnimate", BangWinMenuAnimate);
	AddBangCommand("!WinActiveTrack", BangWinActiveTrack);
	AddBangCommand("!WinAutoRaise", BangWinAutoRaise);

	AddBangCommand("!WinDeltaX", BangWinDeltaX);
	AddBangCommand("!WinDeltaY", BangWinDeltaY);
	AddBangCommand("!WinShade", BangWinShade);
}

// -------------------------------------------------------------------------------------------------------
// Unregister bang commands
// -------------------------------------------------------------------------------------------------------
void UnregisterBangCommands(void)
{
	RemoveBangCommand("!WinAutoRaise");
	RemoveBangCommand("!WinSweep");
	RemoveBangCommand("!WinMaxHeight");
	RemoveBangCommand("!WinMaxWidth");
	RemoveBangCommand("!WinGrowDown");
	RemoveBangCommand("!WinFullDrag");
	RemoveBangCommand("!WinComboboxAnimate");
	RemoveBangCommand("!WinMenuAnimate");
	RemoveBangCommand("!WinActiveTrack");

	RemoveBangCommand("!WinDeltaX");
	RemoveBangCommand("!WinDeltaY");
	RemoveBangCommand("!WinShade");
}

// -------------------------------------------------------------------------------------------------------
// Standard LS module initialisation & quit routines
// -------------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx (HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int Msgs[10];
	int sze;

  // Initialize variables
	dll = dllInst;
	parent = ParentWnd;
	maxWin = (int) SendMessage(parent, LM_WINLIST, 1, 0);

  // Restore winlist
  sze = sizeof(int) | WINCTRL_WINLISTCOUNTID;
  SendMessage(parent, LM_RESTOREDATA, (WPARAM) sze, (LPARAM) &nWin);
  if ( nWin > 0 )
  {
    sze = (sizeof(winDataType) * MAXWIN) | WINCTRL_WINLISTID;
    SendMessage(parent, LM_RESTOREDATA, (WPARAM) sze, (LPARAM) localwinList);
  }

  // Register window class
	deskTop = FindWindow("DesktopBackgroundClass", NULL);
	if (!deskTop)
		deskTop = GetDesktopWindow();
    {
		WNDCLASS wc;

		memset(&wc, 0, sizeof(wc));
		wc.lpfnWndProc = WndProc;
		wc.hInstance = dllInst;
		wc.lpszClassName = szAppName;
		wc.style = 0;

		if (!RegisterClass(&wc))
		{  
			MessageBox(parent, "Error registering window class", szAppName, MB_OK);
			return 1;
		}
	}

  // Create window
	hMainWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,
		szAppName,
		"sweep",
		WS_CHILD,
		0,
		0,
		0,
		0,
		parent,
		NULL,
		dllInst,
		NULL);

	// Setup sound preferences
	GetRCString("WinShadeSound", WinShadeSound, "Minimize", 256);
	GetRCString("WinGrowDownSound", WinGrowDownSound, "RestoreDown", 256);

  // Setup color preferences from step.rc
  {
    COLORREF Color;
    int ElementID[25];
    COLORREF ElementColor[25];
    int ColorCount = 0;
  
    Color = GetRCColor("WinMDIBackgroundColor",0xFF00FF);
    if ( Color != 0xFF00FF )
    {
      ElementID[ColorCount] = COLOR_APPWORKSPACE;
      ElementColor[ColorCount] = Color;
      ColorCount++; 
    }  
    Color = GetRCColor("WinScrollbarBackgroundColor",0xFF00FF);
    if ( Color != 0xFF00FF ) 
    {
      ElementID[ColorCount] = COLOR_SCROLLBAR;
      ElementColor[ColorCount] = Color;
      ColorCount++; 
    }  
    Color = GetRCColor("WinTooltipBackgroundColor",0xFF00FF);
    if ( Color != 0xFF00FF ) 
    {
      ElementID[ColorCount] = COLOR_INFOBK;
      ElementColor[ColorCount] = Color;
      ColorCount++; 
    }  
    Color = GetRCColor("WinTooltipTextColor",0xFF00FF);
    if ( Color != 0xFF00FF ) 
    {
      ElementID[ColorCount] = COLOR_INFOTEXT;
      ElementColor[ColorCount] = Color;
      ColorCount++; 
    }
    if ( ColorCount != 0 )  
      SetSysColors( ColorCount, ElementID, ElementColor );
  }

  // Register messages
	Msgs[0] = LM_GETREVID;
	Msgs[1] = 0;
	SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	
	// Register bangs
	RegisterBangCommands();
	
	// Hook the desktop message loop.
	// We're hoping to receive LM_ACTIVEWIN, LM_BRINGTOFRONT and LM_REMOVEWINDOW.
  AddDesktopHook(); 

	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	int Msgs[10];
	
  // Save winlist
  int sze = (sizeof(winDataType) * MAXWIN) | WINCTRL_WINLISTID;
  SendMessage(parent, LM_SAVEDATA, (WPARAM) sze, (LPARAM) localwinList);
  sze = sizeof(int) | WINCTRL_WINLISTCOUNTID;
  SendMessage(parent, LM_SAVEDATA, (WPARAM) sze, (LPARAM) &nWin);

	Msgs[0] = LM_GETREVID;
	Msgs[1] = 0;
	SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	UnregisterBangCommands();
	DestroyWindow(hMainWnd);
  DeleteDesktopHook();                       // Unhook from desktop dll
	UnregisterClass(szAppName, dllInst);
}

// -------------------------------------------------------------------------------------------------------
// Window message handler
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case LM_GETREVID:
		{
			char *buf = (char *) lParam;

			if (wParam == 0)
			{
				strcpy(buf, "winctrl.dll: ");
				strcat(buf, &rcsRevision[11]);
				buf[strlen(buf)-1] = '\0';
			}
			else if (wParam == 1)
			{
				strcpy(buf, &rcsId[1]);
				buf[strlen(buf)-1] = '\0';
			} else
			{
				strcpy(buf, "");
			}
			return strlen(buf);
		}
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}
	
// -------------------------------------------------------------------------------------------------------
// Desktop hook message handler
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK DesktopWndHookProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case LM_ACTIVEWIN:
		{
			hActiveWin = (HWND)wParam;
			break;
		}
	case LM_BRINGTOFRONT:
		{
			hActiveWin = NULL;
			break;
		}
	case LM_REMOVEWINDOW:
		{
			int i;
			i = inWinList((HWND)wParam);
			if (i != -1)
				RemoveWindow(i);
		}
  }
  return CallWindowProc((WNDPROC) DesktopOldWndProc, hwnd, message, wParam, lParam); 
}
