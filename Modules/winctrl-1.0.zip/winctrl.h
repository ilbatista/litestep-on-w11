#ifndef __WINCRTL_H
#define __WINCRTL_H

#include <windows.h>
#include "wharfdata.h"

typedef struct {
	HWND hwnd;
	long height;
	BOOL bShaded;
	HRGN hrgn;
//	RECT r;
//	char valid;
	} winDataType;

typedef struct {
	HWND hwnd;
	char screen;
	} winFixType;

#define WIN_KEY 0
#define ALT_KEY 1
#define CTRL_KEY 2

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif

#endif
