/* Changelog:
 * 2002-04-16 (Vendicator):
 *	- Since the mail checking routine also clears the new mail flag when
 *    there is no mail on server, left click action is now checkmail.
 *
 * 2002-04-15 (Vendicator):
 *  - Added X,Y reading through GetRCCooridinate
 *  - Now clears new mail flag if 0 mail found on server
 */

#include <windows.h>
#include <wininet.h>
//#include <string.h> // V
#include "../current/lsapi/lsapi.h"
#include "exports.h"
#include "resource.h"

#define POPUP_CHECKMAIL 200
#define POPUP_CLEARNEWMAIL 201
#define POPUP_ZEROACCOUNTS 202
#define POPUP_LAUNCHCLIENT 203
#define POPUP_DISPLAYERROR 204
#define POPUP_SERVER 220

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CheckMail();
char* encrypt(char* pass);
void LoadSetup();
char* ReceiveData(SOCKET conn_socket);
void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp);

char* szAppName = "LSMail";
char* szVersion = "LSMail v4.02 (MrJukes / Vendicator)";

HINSTANCE hInstance;
HWND hwndMain, hwndParent;
int ScreenX, ScreenY;
int x, y, w, h;
char lsdir[256] = "";
int msgs[] = {LM_GETREVID, 0};

HMENU popup=NULL;
HFONT font;
COLORREF color, nmcolor, checkcolor;
HBRUSH bgbrush, nmbgbrush, checkbgbrush;
HBITMAP bgbmp, newmailbmp;
BOOL USEBGCOLOR;

int TIMER=5;
BOOL CHECKING=FALSE;
BOOL NEWMAIL=FALSE;
char TEMP_PASS[256] = "";
char TEMP_SERVER[256] = "";
DWORD threadID;
int numservers=0;
char MAILCLIENT[MAX_PATH] = "";
char ERR[256] = "";

class SERVER
{
public:
	SERVER();
	~SERVER();

	char* name;
	char* host;
	char* login;
	char* password;
	int ID, x, y, port, num, newnum;
	BOOL NEWMAIL, ERR;
	HMENU menu;

	SERVER* next;
} *Servers;

SERVER::SERVER()
{
	ID=numservers++;
	newnum=num=0; 
	NEWMAIL=FALSE;
	ERR=FALSE;
	next=NULL;

	menu = CreatePopupMenu();
	AppendMenu(menu, MF_ENABLED | MF_STRING, POPUP_SERVER+ID+1, "&Change Password");
}

SERVER::~SERVER()
{
	DestroyMenu(menu);
}

void BangShow(HWND caller, const char* args) { ShowWindow(hwndMain, SW_SHOW); }
void BangHide(HWND caller, const char* args) { ShowWindow(hwndMain, SW_HIDE); }
void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void BangCheckMail(HWND caller, const char* args)
{
	CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
}

void LoadSetup()
{
	int size;
	char temp[256];

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	AddBangCommand("!LSMailShow", BangShow);
	AddBangCommand("!LSMailHide", BangHide);
	AddBangCommand("!LSMailToggle", BangToggle);
	AddBangCommand("!LSMailCheckMail", BangCheckMail);
	

	x = GetRCCoordinate("LSMailX", 0, GetSystemMetrics(SM_CXSCREEN));
	y = GetRCCoordinate("LSMailY", 0, GetSystemMetrics(SM_CYSCREEN));
	w = GetRCInt("LSMailW", 400);
	h = GetRCInt("LSMailH", 25);

	TIMER=GetRCInt("LSMailTimer", 5);
	size = GetRCInt("LSMailFontSize", 12);
	GetRCString("LSMailFont", temp, "Arial", 256);
	font = CreateFont(size, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);
	color = GetRCColor("LSMailFontColor", 0x00FFFFFF);
	nmcolor = GetRCColor("LSMailNewMailFontColor", 0x000000FF);
	checkcolor = GetRCColor("LSMailCheckingFontColor", 0x000000FF);

	USEBGCOLOR = GetRCBool("LSMailBackColor", TRUE);
	if (USEBGCOLOR) 
	{
		COLORREF bgcolor = GetRCColor("LSMailBackColor", 0x00000000);
		bgbrush = CreateSolidBrush(bgcolor);

		bgcolor=GetRCColor("LSMailBackNewMailColor", 0x00FF0000);
		nmbgbrush = CreateSolidBrush(bgcolor);

		bgcolor=GetRCColor("LSMailBackCheckingColor", 0x00000000);
		checkbgbrush = CreateSolidBrush(bgcolor);
	}

	GetRCString("LSMailBackBmp", temp, "", 256);
	bgbmp = LoadLSImage(temp, temp);

	GetRCString("LSMailNewMailBmp", temp, "", 256);
	newmailbmp = LoadLSImage(temp, temp);

	GetRCString("LSMailEMailClient", MAILCLIENT, "", MAX_PATH);

	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CHECKMAIL, "&Check Mail");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_LAUNCHCLIENT, "&Launch E-Mail Client");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_CLEARNEWMAIL, "Clear &New Mail");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_ZEROACCOUNTS, "&Zero All Accounts");
	AppendMenu(popup, MF_ENABLED | MF_STRING, POPUP_DISPLAYERROR, "&Display Last Error");
	AppendMenu(popup, MF_SEPARATOR, 0, "");

	//
	// *LSMailServer X Y Name host:<port> login
	FILE* step;
	char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], token6[4096], extra_text[4096];
	char*	tokens[6];

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	tokens[5] = token6;
	
	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);
	
	while (LCReadNextConfig(step, "*LSMailServer", temp, 256)) 
	{ 
		int count;

		token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = extra_text[0] = '\0';
		count = LCTokenize (temp, tokens, 6, extra_text);

		if (count == 6)
		{
			SERVER* s = new SERVER;
			s->x = atoi(token2);
			s->y = atoi(token3);
			s->name = _strdup(token4); // V
			
			// blah.blah.blah.blah:80
			char* p = strtok(token5, ":");
			s->host = _strdup(p); // V
			p = strtok(NULL, "");
			if (p) s->port = atoi(p);
			else s->port = 110;
			
			s->login = _strdup(token6); // V

			AppendMenu(popup, MF_ENABLED | MF_STRING | MF_POPUP, (int)s->menu, s->name);

			if (Servers) s->next = Servers;
			Servers = s;
		}
	}
	LCClose(step);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	strcpy(lsdir, szPath);
	hwndParent = parent;
	hInstance = dllInst;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}
 
	LoadSetup();

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, 
							  szAppName, szAppName, 
							  WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 
							  x, y, 
							  w, h, 
							  NULL, NULL, dllInst, NULL);
		
	if (!hwndMain) return 1;
	
	if (bgbmp && !USEBGCOLOR) SetWindowBitmapRgn(hwndMain, bgbmp);

	if (GetRCBool("LSMailStartHidden", FALSE)) ShowWindow(hwndMain, SW_SHOW);
	if (GetRCBool("LSMailAlwaysOnTop", TRUE)) SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);

	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);
	SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	
	if (TIMER) SetTimer(hwndMain, 0, TIMER*60000, NULL);
	CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);

	return 0;
}

int quitModule(HINSTANCE dll)
{
	while (CHECKING) Sleep(1000);

	RemoveBangCommand("!LSMailShow");
	RemoveBangCommand("!LSMailHide");
	RemoveBangCommand("!LSMailToggle");
	RemoveBangCommand("!LSMailCheckMail");
	
	SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	KillTimer(hwndMain, 0);

	DestroyMenu(popup);

	while (Servers)
	{
		SERVER* s = Servers;
		Servers=Servers->next;
		delete s;
	}

	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, dll);

	DeleteObject(bgbrush);
	DeleteObject(nmbgbrush);
	DeleteObject(checkbgbrush);
	DeleteObject(bgbmp);
	DeleteObject(newmailbmp);
	DeleteObject(font);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_ERASEBKGND: return 0;

		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);
			strcpy(buf, szVersion);
			return strlen(buf);
		}
		break;

		case WM_RBUTTONDOWN:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
		}
		return 0;

		case WM_LBUTTONUP: // changed to check mail
		{
			/*NEWMAIL=FALSE;
			for (SERVER* s=Servers; s; s=s->next) 
			{
				s->num=s->newnum;
				s->NEWMAIL=FALSE;
			}
			*/
			CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
			InvalidateRect(hwndMain, NULL, TRUE);
		}
		break;

		case WM_COMMAND:
		{
			switch (wParam)
			{
				case POPUP_CHECKMAIL: CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID); break;
				
				case POPUP_LAUNCHCLIENT: WinExec(MAILCLIENT, SW_SHOWNORMAL); break;
				case POPUP_DISPLAYERROR: MessageBox(hwndMain, ERR, "LSMail Error", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR); break;

				case POPUP_ZEROACCOUNTS:
				{
					for (SERVER* s=Servers; s; s=s->next) 
					{
						s->NEWMAIL=FALSE;
						s->num=s->newnum=0;
					}
					InvalidateRect(hwndMain, NULL, TRUE);
				}
				break;
				
				case POPUP_CLEARNEWMAIL: SendMessage(hwnd, WM_LBUTTONUP, 0, 0); break;
				
				default:
				{
					for (SERVER* s=Servers; s; s=s->next) 
					{
						if ((int)wParam == (POPUP_SERVER+s->ID+1)) // Change Password
						{
							strcpy(TEMP_SERVER, s->name);
							DialogBox(hInstance, MAKEINTRESOURCE(IDD_GETPASS), hwndMain, GetPassProc);
							if (strlen(TEMP_PASS)) 
							{
								char temp[256] = "";
								if (s->password) memset(&s->password, 0, sizeof(s->password));
								s->password = NULL;
								s->password = _strdup(TEMP_PASS); // V
								sprintf(temp, "%s/%s", s->host, s->login);
								WriteProfileString("LSMail", temp, encrypt(s->password));
							}
							break;
						}
					}
				}
				break;
			}
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, w, h);
			HBITMAP oldbuf, oldsrc;
			RECT r;

			GetClientRect(hwnd, &r);

			if (!bgbmp && !USEBGCOLOR)
			{
				bgbmp = CreateCompatibleBitmap(hdc, w, h);
				oldbuf = (HBITMAP)SelectObject(buf, bgbmp);
				BitBlt(buf, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
				SelectObject(buf, oldbuf);
			}

			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			
			if (!USEBGCOLOR)
			{
				if (NEWMAIL && newmailbmp) oldsrc = (HBITMAP)SelectObject(src, newmailbmp);
				else oldsrc = (HBITMAP)SelectObject(src, bgbmp);
				BitBlt(buf, 0, 0, w, h, src, 0, 0, SRCCOPY);
			}
			else
			{
				if (CHECKING) FillRect(buf, &r, (HBRUSH)checkbgbrush);
				else if (NEWMAIL) FillRect(buf, &r, (HBRUSH)nmbgbrush);
				else FillRect(buf, &r, (HBRUSH)bgbrush);
			}

			SelectObject(buf, font);
			SetBkMode(buf, TRANSPARENT);

			for (SERVER* s=Servers; s; s=s->next)
			{
				char temp[256] = "";
				
				if (s->ERR) sprintf(temp, "%s: Error!", s->name);
				else sprintf(temp, "%s: %d", s->name, s->newnum-s->num);

				SetRect(&r, s->x, s->y, w, h);

				if (CHECKING) SetTextColor(buf, checkcolor);
				else
				{
					if (s->NEWMAIL) SetTextColor(buf, nmcolor);
					else SetTextColor(buf, color);
				}

				DrawText(buf, temp, strlen(temp), &r, DT_CALCRECT | DT_LEFT | DT_VCENTER);
				DrawText(buf, temp, strlen(temp), &r, DT_LEFT | DT_VCENTER);
			}

			BitBlt(hdc, 0, 0, w, h, buf, 0, 0, SRCCOPY);

			SelectObject(src, oldsrc);
			DeleteDC(src);
			SelectObject(buf, oldbuf);
			DeleteDC(buf);
			DeleteObject(bufbmp);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_TIMER:
		{
			CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &threadID);
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

BOOL CALLBACK GetPassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG: 
		{
			char temp[256] = "";
			sprintf(temp, "%s Password", TEMP_SERVER);
			SetWindowText(hwnd, temp);
			return TRUE;
		}

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDOK:
						{
							GetDlgItemText(hwnd, IDC_PASSWORD, TEMP_PASS, 256);
						}
						case IDCANCEL:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}

	return FALSE;
}

void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp)
{
	if (hwnd && bmp)
	{
		int x=0, y=0;
		HDC hdc = CreateCompatibleDC(NULL);
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;

		GetObject(bmp, sizeof(bitmap), &bitmap);
		SelectObject(hdc, bmp);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y < bitmap.bmHeight; x=0, y++)
		{
			for (x=0; x < bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == 0x00FF00FF)
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hwnd, hMainRgn, FALSE);

		DeleteDC(hdc);
		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hwnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hwnd, rgn, FALSE);
	}
}

BOOL CheckMail()
{
	if (CHECKING) return FALSE;

	CHECKING=TRUE;
	InvalidateRect(hwndMain, NULL, TRUE);

	__try 
	{
		for (SERVER* s=Servers; s; s=s->next)
		{
			unsigned int addr; 
			int	socket_type = SOCK_STREAM; 
			struct sockaddr_in server; 
			struct hostent *hp; 
			WSADATA wsaData; 
			SOCKET  conn_socket;
			char temp[256] = "";

			if (!s->password)
			{
				sprintf(temp, "%s/%s", s->host, s->login);
				GetProfileString("LSMail", temp, "", temp, 256);
				if (!strlen(temp))
				{
					strcpy(TEMP_SERVER, s->name);
					DialogBox(hInstance, MAKEINTRESOURCE(IDD_GETPASS), hwndMain, GetPassProc);
					if (strlen(TEMP_PASS)) 
					{
						s->password = _strdup(TEMP_PASS); // V
						sprintf(temp, "%s/%s", s->host, s->login);
						WriteProfileString("LSMail", temp, encrypt(s->password));
					}
					memset(&TEMP_PASS, 0, sizeof(TEMP_PASS));
				}
				else s->password=_strdup(encrypt(temp)); // V
			}

			// Startup Sockets
			if (WSAStartup(0x202,&wsaData) == SOCKET_ERROR)
			{ 
				sprintf(ERR, "Could not initialize Windows Sockets");
				s->ERR=TRUE;
				WSACleanup(); 
				continue;
			} 

			// Check to see if server_name is an alpha or ip
			if (isalpha(s->host[0])) hp = gethostbyname(s->host); 
			else  
			{
				addr = inet_addr(s->host); 
				hp = gethostbyaddr((char *)&addr,4,AF_INET); 
			} 

			// Couldn't resolve
			if (hp == NULL) 
			{	
				sprintf(ERR, "Could not resolve %s", s->host);
				//s->ERR=TRUE;
				WSACleanup();
				continue;
			} 

			// Copy the resolved information into the sockaddr_in structure 
			memset(&server,0,sizeof(server)); 
			memcpy(&(server.sin_addr),hp->h_addr,hp->h_length); 
			server.sin_family = hp->h_addrtype; 
			server.sin_port = htons((u_short)s->port); 

			// Open a socket
			conn_socket = socket(AF_INET,socket_type,0);
			if (conn_socket < 0 ) 
			{ 
				sprintf(ERR, "Could not open a socket");
				s->ERR=TRUE;
				WSACleanup(); 
				continue;
			}

			// Connect to the server
			if (connect(conn_socket,(struct sockaddr*)&server,sizeof(server)) == SOCKET_ERROR)
			{ 
				sprintf(ERR, "Could not connect to %s:%d", s->host, s->port);
				s->ERR=TRUE;
				WSACleanup(); 
				continue;
			}

			char* recvd=NULL;

			if (!ReceiveData(conn_socket)) 
			{ 
				sprintf(ERR, "You got a funky server");
				s->ERR=TRUE; 
				continue; 
			}
			
			sprintf(temp, "USER %s\r\n", s->login);
			send(conn_socket, temp, strlen(temp), 0);
			if (!ReceiveData(conn_socket)) 
			{
				sprintf(ERR, "%s: Invalid Login", s->login);
				s->ERR=TRUE; 
				continue; 
			}

			sprintf(temp, "PASS %s\r\n", s->password);
			send(conn_socket, temp, strlen(temp), 0);
			if (!ReceiveData(conn_socket)) 
			{
				sprintf(ERR, "%s: Invalid password", s->password);
				sprintf(temp, "Invalid password for user %s on %s", s->login, s->host);
				MessageBox(hwndMain, temp, "LSMail Error", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
				s->ERR=TRUE; 
				continue; 
			}

			sprintf(temp, "STAT\r\n");
			send(conn_socket, temp, strlen(temp), 0);
			if (!(recvd=ReceiveData(conn_socket))) 
			{
				sprintf(ERR, "Could not execute STAT??? wtf...");
				s->ERR=TRUE; 
				continue; 
			}
			else
			{
				char* p = strtok(recvd, " ");
				int num=-1;
				p = strtok(NULL, " ");
				num = atoi(p);
				if (num > s->newnum) 
				{
					NEWMAIL=TRUE;
					s->NEWMAIL=TRUE;
				}
                                else if (num == 0) {
	                                NEWMAIL=FALSE;
					s->num=s->newnum;
			    		s->NEWMAIL=FALSE;
                                }

				s->newnum=num;
				if (s->newnum < s->num) s->num=s->newnum;
			}
			
			sprintf(temp, "QUIT\r\n");
			send(conn_socket, temp, strlen(temp), 0);
			if (!ReceiveData(conn_socket)) 
			{ 
				sprintf(ERR, "Error disconnecting from server");
				//s->ERR=TRUE; 
				continue; 
			}

			s->ERR=FALSE;
			closesocket(conn_socket);
			WSACleanup();
		}
	} __except(1) { }


	CHECKING=FALSE;
	InvalidateRect(hwndMain, NULL, TRUE);
	return TRUE;
}

char* ReceiveData(SOCKET conn_socket)
{
	int retval;
	int nStatus;
	struct timeval timeout = {0, 0};
	struct fd_set fds;
	DWORD dwStartTicks = GetTickCount();
	char temp[256] = "";

	while (1)
	{
		if ((GetTickCount() - dwStartTicks) > 60000)
		{
			MessageBox(hwndMain, "Receive Timed Out", szAppName, MB_SYSTEMMODAL);
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}

		FD_ZERO(&fds);
		FD_SET(conn_socket, &fds);
		nStatus = select(0, &fds, NULL, NULL, &timeout);
		if (nStatus == SOCKET_ERROR) 
		{
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}
		else
		{
			if (!nStatus) 
			{
				Sleep(250);
				continue;
			}
		}

		retval = recv(conn_socket, temp, 256, 0); 
		if (retval == SOCKET_ERROR) 
		{ 
			closesocket(conn_socket); 
			WSACleanup(); 
			return NULL;
		}
		else
		{
			if (_strnicmp(temp, "+OK", 3)) // V
			{
				closesocket(conn_socket);
				WSACleanup();
				return NULL;
			}
			else return _strdup(temp); // V
		}
	}

	return _strdup(temp); // V
}

char* encrypt(char* pass)
{
	char* ret=_strdup(pass); // V
	char* p=ret;
	for (; *pass; *pass++, *ret++)
	{
		*ret=*pass ^ 0x5405;
	}
	return p;
}