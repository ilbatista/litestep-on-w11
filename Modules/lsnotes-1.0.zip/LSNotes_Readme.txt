/////////////////////////////////////////
// LSNotes V1.0
// Written By: MrJukes
// Released: 9/4/98
// Graphics by: treman and NipKick

// Installation
1) Unzip LSNotes.app to your litestep directory
2) Unzip LSNotes.bmp and LSNotesControls to your images directory
3) Put the necessary line in your step.rc
	*Wharf LSNotes LSNotes.bmp @c:\Litestep\LSNotes.app
4) Recycle Litestep

// Quick-Start : Instructions to create a note
1) Right Click on LSNotes in the wharf
2) Click on "New Note"
3) Left click anywhere in the yellow
4) Type in the note
5) When finished, click on the little pencil icon to set the text
6) To move the note around, click and hold down the right button
   anywhere on the note and then move the mouse around (slowly)

// Usage
// Wharf Window
You will notice a 0/0 when you first load LSNotes.  The first 0 is the
currently selected note.  The second zero is the total number of notes
there currently are.  The most notes you can have is 25.  If you click on
the X, it will delete the currently selected note.  You can click on the up
and down arrows to change the currently selected note.  You can also right
click on the note itself to make it selected.  Double clicking on the number
will set the currently selected note to the front and open it for editing.

// Popup Menu
- New Note 		: Creates a new note
- Hide Note 		: Hides the currently selected note
- Show All Notes	: Makes all notes appear on screen
- Hide All Notes	: Makes all notes hide
- Edit Settings		: Opens your modules.ini
- Reload Settings	: Reloads certain settings
- About LSNotes		: Brings up the About MessageBox

// Note Window
- Order of icons at bottom
1) Scroll up (Up Arrow)
2) Scroll down (Down Arrow)
3) Hide Note (H)
4) Create a new Note (Note)
5) Set the text when done typing (Pencil)
6) Remove Note (Red X)

// Modules.ini
[LSNotes]
TextColor=0x00FFFFFF // Color of the 0/0  // Format: 0x00BBGGRR
NoteColor=0x0000FFFF // Color of the note // Format: 0x00BBGGRR
LSNotesControls=C:\Litestep\images\LSNotesControls.bmp // controls.bmp location 
// You shouldn't touch the values below here
Note0=Hello          // Text of Note 1
Note0x=150           // X-coord of Note 1
Note0y=150           // Y-coord of Note 1
etc...