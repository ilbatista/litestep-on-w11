-----------------------------------------------------------------------------
 xDesk-1.0 a(nother) Litestep Desktop Module
-----------------------------------------------------------------------------

WorkArea Setup
***************

Single Monitor Setup:
----------------------

*xDeskWorkArea x y width height
Set the WorkArea based on the xPaintClass Coordinate and Dimension features!

Important:
...........
The following lines set exactly the same workarea!

jDesk: left,top,right,bottom
jDeskWorkArea "5,5,-5,-30"

xDesk: x y WIDTH HEIGHT
*xdeskworkarea 5 5 -10 -35
You need to subtract the left/top part TOO to get the correct width/height!

Dual Monitor Setup:
----------------------

*xDeskWorkArea 1 x y width height
*xDeskWorkArea primary x y width height
Set the WorkArea of the Primary Monitor based on the xPaintClass Coordinate and Dimension features!

*xDeskWorkArea 2 x y width height
*xDeskWorkArea secondary x y width height
Set the WorkArea of the Secondary Monitor based on the xPaintClass Coordinate and Dimension features!

Desktop Modification:
**********************

Modify how the Desktop Wallpaper looks!
Create a matching colors to your theme or add STATIC elements/logos.

Desktop Colorization:
----------------------

xDeskHueColor COLOR
This command specifies the blended in color.
You cannot use Grayscale Colors, like FFFFFF, c0c0c0, 888888, 000000, ...., because they don't have a color!
If no value is provided then the default is "FFFFFF".

xDeskHueIntensity INT
This command specifies the color of the pixel or the blended in color if HueIntensity is smaller then 100.
Minimum: 0 -> Nothing (Default)
Maximum: 100

xDeskMixColor COLOR
This command specifies the mixed in color.
If no value is provided then the default is "FFFFFF".

xDeskMixIntensity INT
This command specifies the amount of the mixed in color.
Minimum: 0 -> Nothing (Default)
Maximum: 100

xDeskLuminanceIntensity INT
This command specifies the luminance of the wallpaper image.
Minimum: -100 -> Black
Maximum: 100 -> White
Default: 0

xDeskSaturationIntensity INT
This command specifies the color saturation of the wallpaper image.
Minimum: 0 -> Grayscale
Maximum: 100 -> Full Colored (Default)

Values between 101-200 override the original Saturation of the Pixel!
This way you can colorize Grayscale Desktops.

Desktop Overlays:
------------------

*xDeskOverlay x y width height "SettingsPrefix" #a

x, y, width and height:
........................

All position and sizing options are available to setup the position and size of the STATIC Overlay.

For instance a 20 Pixel Border on the right side:
*xDeskOverlay -20 0 -20 100% ghost #

SettingsPrefix:
................

For all Overlay settings you need the "SettingsPrefix", which defines a xPaintTexture!

ATTENTION: These are STATIC Overlays -> They are always visible and you cannot toggle them!


Bangs:
******

!xDeskSetWorkArea x y width height

!xDeskSetWorkArea 1 x y width height
!xDeskSetWorkArea primary x y width height

!xDeskSetWorkArea 2 x y width height
!xDeskSetWorkArea secondary x y width height

Set the WorkArea based on the xPaintClass Coordinate and Dimension features!


!xDeskSetWallpaper
!xDeskSetWallpaper [Path to Wallpaper Image (BMP or PNG])]

Sets the new Wallpaper!

1. When used without any argument then the current MODIFIED Wallpaper is saved in the ThemeDir 
   AND it is set as current wallpaper
   You SHOULD remove afterwards the Overlays and Colorization settings -> saves RAM and CPU
   because they aren't needed anymore, till the user changes his wallpaper again.
   
2. When used with an imagepath as argument then this wallpaper is set.


Events:
********

"modifier" can be:
-------------------
.none, .mouse1, mouse2, .ctrl, .shift, .alt and all combinations of the last three ( .ctrl+shift, .shift+alt, .alt+shift+ctrl, ...)
The drop action is executed, if the matching key combination is pressed during the drop.
Or in case of .mouse1 and .mouse2 of the Drag was performed with the Left (1) or Right (2) MouseButton.


*xDeskOnDrop (modifier) (fileaction) (path)
Sets an action to perform, when file(s) or folder(s) is dropped on the destop. User confirmation on Overwrite is required ;) "fileaction" can be: "move", "copy", delete" or "shortcut". "path" is the path to move, copy or create Shortcut (MUST be enclosed in '" "')

Examples:
---------
*xDeskOnDrop .none move "Path To Move To" <- Moves file(s) to given destination
*xDeskOnDrop .none copy "Path To Copy To" <- Copies file(s) to given destination
*xDeskOnDrop .none delete <- Deletes file(s)
*xDeskOnDrop .none shortcut "Path Where To Create Shortcut(s)" <- Create Shortcut file(s) in given destination

Alternative:
-------------
*xDeskOnDrop (modifier) (bang)

In the Event OnDrop "%[droppath]%" (Lowercase!) will be replaced with the Full Path of the Dropped File.
If no "%[droppath]%" is found, it is the same behaviour as before, the DropPath will be simply appended after the bang.

Example:
---------
*xDeskOnDrop !execute [!alert "%[droppath]%" "Saved"][!xtextsaveevar @$configdir$save.rc@ @dropped@ @%[droppath]%@]


Region MouseClick Feature
**************************

DOUBLE CLICK MUST BE ENABLED WITH -> xDeskEnableDoubleClicks BOOL

Clicking outside of these specified regions or if none are defined, executes the normal commands. If regions overlap each other, the first matching region defined in step.rc will be executed.

x and y:
---------
If the values are positive then they are relative to the left/top side of the desktop, if negative then the right/bottom side. Additionally you can make the positions relative to the center of the desktop by appending the character 'c' after the number ("32c", "-128c").

width and height:
------------------
If the values are positive then they are absolute sizes in pixel, if negative then the desktop Width/Height minus the specified value. Additionally you can make the size relative to a precentage of the desktop size by appending the character '%' after the number ("50%", "-20").

Use the xPaintClass 1@ and 2@ MultiMonitor Features for Positioning on different Monitors!


*xDeskOnLeftClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when clicked with the left mousebutton. You can have as many of these lines as you want.

*xDeskOnLeftDoubleClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when doubleclicked with the left mousebutton. You can have as many of these lines as you want.

*xDeskOnMiddleClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when clicked with the middle mousebutton. You can have as many of these lines as you want.

*xDeskOnMiddleDoubleClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when doubleclicked with the middle mousebutton. You can have as many of these lines as you want.

*xDeskOnRightClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when clicked with the right mousebutton. You can have as many of these lines as you want.

*xDeskOnRightDoubleClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when doubleclicked with the right mousebutton. You can have as many of these lines as you want.

*xDeskOnX1ClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when clicked with the X1 mousebutton. You can have as many of these lines as you want.

*xDeskOnX1DoubleClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when doubleclicked with the X1 mousebutton. You can have as many of these lines as you want.

*xDeskOnX2ClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when clicked with the X2 mousebutton. You can have as many of these lines as you want.

*xDeskOnX2DoubleClickRegion (x) (y) (width) (height) (action)
Specifies a region inside the desktop which executes the given action when doubleclicked with the X2 mousebutton. You can have as many of these lines as you want.


Multiple Click Events with Modifiers
*************************************

DOUBLE CLICK MUST BE ENABLED WITH -> xDeskEnableDoubleClicks BOOL

"modifier" can be:
-------------------
.none, .mouse1, .mouse2, .mouse3, .ctrl, .shift, .alt and all combinations of the last three ( .ctrl+shift, .shift+alt, .alt+shift+ctrl, ...)
The action is executed, if the matching key combination is pressed during the click.


*xDeskOnWheelDown (modifier) (action)
Sets an action to perform, when the user rolls the mousewheel down on the desktop.

*xDeskOnWheelUp (modifier) (action)
Sets an action to perform, when the user rolls the mousewheel up on the desktop.


*xDeskOnLeftClickDown (modifier) (action)
Sets an action to perform, when the user presses the left mousebutton down on the desktop.

*xDeskOnLeftClickUp (modifier) (action)
Sets an action to perform, when the user left clicks on the desktop (releases the left mousebutton).

*xDeskOnLeftDoubleClick (modifier) (action)
Sets an action to perform, when the user double-clicks the desktop with the left mousebutton.

*xDeskOnMiddleClickDown (modifier) (action)
Sets an action to perform, when the user presses the middle mousebutton down on the desktop.

*xDeskOnMiddleClickUp (modifier) (action)
Sets an action to perform, when the user middle clicks on the desktop (releases the middle mousebutton).

*xDeskOnMiddleDoubleClick (modifier) (action)
Sets an action to perform, when the user double-clicks the desktop with the middle mousebutton.

*xDeskOnRightClickDown (modifier) (action)
Sets an action to perform, when the user presses the right mousebutton down on the desktop.

*xDeskOnRightClickUp (modifier) (action)
Sets an action to perform, when the user right clicks on the desktop (releases the right mousebutton).

*xDeskOnRightDoubleClick (modifier) (action)
Sets an action to perform, when the user double-clicks the desktop with the right mousebutton.

*xDeskOnX1ClickDown (modifier) (action)
Sets an action to perform, when the user presses the X1 mousebutton down on the desktop.

*xDeskOnX1ClickUp (modifier) (action)
Sets an action to perform, when the user clicks with the X1 button on the desktop (releases the X1 mousebutton).

*xDeskOnX1DoubleClick (modifier) (action)
Sets an action to perform, when the user double-clicks the desktop with the X1 mousebutton.

*xDeskOnX2ClickDown (modifier) (action)
Sets an action to perform, when the user presses the X2 mousebutton down on the desktop.

*xDeskOnX2ClickUp (modifier) (action)
Sets an action to perform, when the user clicks with the X2 button on the desktop (releases the X2 mousebutton).

*xDeskOnX2DoubleClick (modifier) (action)
Sets an action to perform, when the user double-clicks the desktop with the X2 mousebutton.


-----------------------------------------------------------------------------
Changes for xDesk
-----------------------------------------------------------------------------

Initial Version 1.0 Released on 13-05-2007, Created by Andymon