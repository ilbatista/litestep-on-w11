#if !defined(__LABEL_H)
#define __LABEL_H

class Font;
class Texture;

typedef DWORD (WINAPI *PSLWA)(HWND, DWORD, BYTE, DWORD);

#define WS_EX_LAYERED           0x00080000    

#define LWA_COLORKEY            0x00000001
#define LWA_ALPHA               0x00000002

static PSLWA pSetLayeredWindowAttributes = NULL;
static BOOL initialized = FALSE;

class Label
{
public:

	Label(const string &name);
	virtual ~Label();

	void load(HINSTANCE hInstance, HWND box = 0);

	void reconfigure();

	Texture *getBackground() const { return background; }
	Font *getFont() const { return font; }

	bool isAlwaysOnTop() const { return alwaysOnTop; }
	bool isVisible() const { return visible; }
	bool isScrolling() const { return scroll; }
	bool bUseFahrenheit;
	
	int getHeight() const { return height; }
	int getWidth() const { return width; }
	int getX() const { return x; }
	int getY() const { return y; }

	int getAlign() { return align; }
	int getVertAlign() { return vertAlign; }
	int getUpdateInterval() { return updateInterval; }

	int getLeftBorder() const { return leftBorder; }
	int getTopBorder() const { return topBorder; }
	int getRightBorder() const { return rightBorder; }
	int getBottomBorder() const { return bottomBorder; }

	const HWND &getBox() const { return box; }
	const string &getName() const { return name; }
	const string &getText() const { return text; }

	void setAlign(int align);
	void setAlwaysOnTop(bool alwaysOnTop);
	void setBox(HWND newparent);
	void setBackground(Texture *background);
	void setFont(Font *font);
	void setText(const string &text);
	void setUpdateInterval(int updateInterval);
	void setLeftBorder(int leftBorder);
	void setTopBorder(int topBorder);
	void setRightBorder(int rightBorder);
	void setBottomBorder(int bottomBorder);
	void setScrolling(bool scrolling);
	void setScrollLimit(int limit);
	void setVertAlign(int vertAlign);

	//Andymon Regions Extention
	//andymon@ls-universe.info
	//************************
	bool checkRegion(int x, int y, StringList inputlist);
	bool checkenterleaveRegion(int x, int y);
	//************************
	
	void repaint(bool invalidateCache = false);

	//Andymon Animation Extention
	//andymon@ls-universe.info
	//************************
	void move(int x, int y, int steps, int time);
	void reposition(int x, int y, int width, int height, int steps, int time);
	void resize(int width, int height, int steps, int time);
	//************************

	void internalHide();
	void internalShow();
	void hide();
	void show();
	void showHide(double timeout);

	void previous();
	void next();
	void update();

	void clipboardCopy(string prefix);
	void clipboardPaste(string prefix);

	//Andymon Extention
	//andymon@ls-universe.info
	//************************
	void mzscriptvarcopy(string var);
	void posmzscriptvarcopy(string varx, string vary);
	//************************

private:

	HWND hWnd;
	HINSTANCE hInstance;
	HWND box;

	HDC backgroundDC;
	HDC bufferDC;
	HBITMAP backgroundBitmap;
	HBITMAP bufferBitmap;

	bool hoverActive;
	bool pressedActive;

	bool useHover;
	bool usePressed;

	Texture *background;
	Font *font;

	bool alwaysOnTop;
	bool canBeVisible;
	bool visible;
	bool bUsingDefSkin;
	bool bInDestructor;

	int height;
	int width;
	int x;
	int y;

	int shadowY; // V

	int scrollPadLength;
	int scrollInterval;
	int scrollSpeed;
	bool scroll;
	int scrollPosition;
	UINT scrollLimit;

	bool trueTransparency;
	int alphaTransparency;

	int align;
	int vertAlign;
	int updateInterval;
	bool alwaysUpdateContent;

	int leftBorder;
	int topBorder;
	int rightBorder;
	int bottomBorder;

	string name;

	bool dynamicText;
	vector<string> originalText;
	int current;
	string text;
	string tooltip;

	bool mousePressed;
	bool mouseInside;

	string leftClickCommand;
	string leftDoubleClickCommand;
	string middleClickCommand;
	string middleDoubleClickCommand;
	string rightClickCommand;
	string rightDoubleClickCommand;
	string wheelDownCommand;
	string wheelUpCommand;
	string enterCommand;
	string leaveCommand;
	string dropCommand;
	string textChangeCommand;

	//Andymon Moving Extention
	//andymon@ls-universe.info
	//************************
	POINT savedpt;
	bool movemodifierkeyPressed;
	int moveButtonPressed;

	bool moveable;
	int moveKey;
	int moveButton;
	//************************

	//Andymon Regions Extention
	//andymon@ls-universe.info
	//************************
	StringList labelLeftClickRegions;
	StringList labelRightClickRegions;
	StringList labelMiddleClickRegions;

	string enterleaveRegion;
	//************************

protected:

	HWND TooltipHints;
	char oldtooltiptext[128];

	void addHint(HWND hWnd, LPSTR caption);
	void removeHint(HWND hWnd);

	BOOL MakeWindowTransparent(HWND hWnd, unsigned char factor);

	void relayMouseMessageToBox(UINT message, WPARAM wParam, LPARAM lParam);

	virtual void onLButtonDblClk(int x, int y);
	virtual void onLButtonDown(int x, int y);
	virtual void onLButtonUp(int x, int y);
	virtual void onMButtonDblClk(int x, int y);
	virtual void onMButtonDown(int x, int y);
	virtual void onMButtonUp(int x, int y);
	virtual void onRButtonDblClk(int x, int y);
	virtual void onRButtonDown(int x, int y);
	virtual void onRButtonUp(int x, int y);
	virtual void onWheelDown(int x, int y);
	virtual void onWheelUp(int x, int y);
	virtual void onMouseEnter();
	virtual void onMouseLeave();
	virtual void onMouseMove(int x, int y);
	virtual void onPaint(HDC hDC);
	virtual void onSize(int width, int height);
	virtual void onTimer(int timerID);
	virtual void onWindowPosChanged(WINDOWPOS *windowPos);

	virtual bool onWindowMessage(UINT message, WPARAM wParam, LPARAM lParam, LRESULT &lResult);

public:

	static LRESULT WINAPI windowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
};

#endif
