#ifndef __STRSAFE_H
#define __STRSAFE_H

#define StringCbCopy(a, b, c) strncpy((a), (c), (b))
#define StringCbPrintf _snprintf

#define StringCchCat(a, b, c) strncat((a), (c), (b))
#define StringCchCopy(a, b, c) strncpy((a), (c), (b))
#define StringCchLength(a, b, c) *(c) = strlen((a)), S_OK
#define StringCchPrintf _snprintf

#endif
