#include "common.h"
#include "Label.h"
#include "SystemInfo.h"
#include "LabelSettings.h"
#include "Font.h"

// Bang commands
void BangAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs);
void BangClipboardCopy(HWND hwndCaller, LPCSTR pszArgs);
void BangClipboardPaste(HWND hwndCaller, LPCSTR pszArgs);
void BangCreate(HWND hwndCaller, LPCSTR pszArgs);
void BangDebug(HWND hwndCaller, LPCSTR pszArgs);
void BangDestroy(HWND hwndCaller, LPCSTR pszArgs);
void BangHide(HWND hwndCaller, LPCSTR pszArgs);
void BangLSBoxHook(HWND hwndCaller, LPCSTR pszArgs);
void BangMove(HWND hwndCaller, LPCSTR pszArgs);
void BangNext(HWND hwndCaller, LPCSTR pszArgs);
void BangPinToDesktop(HWND hwndCaller, LPCSTR pszArgs);
void BangPrevious(HWND hwndCaller, LPCSTR pszArgs);
void BangRefresh(HWND hwndCaller, LPCSTR pszArgs);
void BangReposition(HWND hwndCaller, LPCSTR pszArgs);
void BangResize(HWND hwndCaller, LPCSTR pszArgs);
void BangScroll(HWND hwndCaller, LPCSTR pszArgs);
void BangSetFontColor(HWND hwndCaller, LPCSTR pszArgs);
void BangSetText(HWND hwndCaller, LPCSTR pszArgs);
void BangShow(HWND hwndCaller, LPCSTR pszArgs);
void BangShowHide(HWND hwndCaller, LPCSTR pszArgs);
void BangToggleAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs);
void BangToggle(HWND hwndCaller, LPCSTR pszArgs);
void BangUpdate(HWND hwndCaller, LPCSTR pszArgs);
//Andymon extention
//andymon@ls-universe.info
//************************
void BangmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs);
void BangPosmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs);

HINSTANCE hInstance;
HWND messageHandler;

LabelList labelList;

int lsMessages[] = {
	LM_GETREVID,
	LM_REFRESH,
	0
};

#define LM_UPDATEBG (WM_USER + 1)

Label *lookupLabel(const string &name);

LRESULT WINAPI MessageHandlerProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case LM_GETREVID:
		{
			UINT uLength;
			StringCchPrintf((char*)lParam, 64, "%s %s", V_NAME, V_VERSION);
			
			if (SUCCEEDED(StringCchLength((char*)lParam, 64, &uLength)))
				return uLength;

			lParam = NULL;
			return 0;
		}
		
		case LM_REFRESH:
		{
			StringList labelNames = GetRCNameList("*Label");

			// refresh the "AllLabels" configuration
			delete defaultSettings;
			defaultSettings = new LabelSettings();

			for(LabelListIterator iter = labelList.begin(); iter != labelList.end(); iter++)
			{
				if(!(*iter)->getBox())
				{
					// destroy all labels that no longer exist and that are not in a box
					for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
					{
						if(_stricmp((*it).c_str(), (*iter)->getName().c_str()) == 0)
							break;
					}
					if (it == labelNames.end())
					{
						labelList.remove(*iter);
						delete *iter;
						continue;
					}
				}

				// we can reconfigure all other labels, even if they are "boxed"
				(*iter)->reconfigure();
			}

			// create the rest
			for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
			{
				Label *label = lookupLabel(*it);
				
				if (!label) 
				{
					label = new Label(*it);

					label->load(hInstance);
				
					labelList.insert(labelList.end(), label);
				}
			}
			return 0;
		}

		case LM_UPDATEBG:
		{
			PaintDesktopEx(0, 0, 0, 0, 0, 0, 0, TRUE);

			LabelListIterator i;
			for(i = labelList.begin(); i != labelList.end(); i++)
			{
				Label *label = *i;

				if(label->getBox() == 0)
					label->repaint(true);
			}

			return 0;
		}

		case WM_DISPLAYCHANGE:


		case WM_SETTINGCHANGE:
		{
			PostMessage(hWnd, LM_UPDATEBG, 0, 0);
			return 0;
		}
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	WNDCLASSEX wc;

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS | CS_DBLCLKS;
	wc.lpfnWndProc = Label::windowProcedure;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = sizeof(Label *);
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = LoadCursor(0, IDC_ARROW);
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "xLabel";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = MessageHandlerProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = 0;
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "xLabelMessageHandler";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	messageHandler = CreateWindowEx(WS_EX_TOOLWINDOW,
		"xLabelMessageHandler",
		0,
		WS_POPUP,
		0, 0, 0, 0, 
		0,
		0,
		hInstance,
		0);

	if (!messageHandler)
		return 1;
	
	SendMessage(GetLitestepWnd(),
		LM_REGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	::hInstance = hInstance;

	defaultSettings = new LabelSettings();
	systemInfo = new SystemInfo();

	StringList labelNames = GetRCNameList("*Label");

	for(StringListIterator it = labelNames.begin(); it != labelNames.end(); it++)
	{
		Label *label = new Label(*it);
	
		label->load(hInstance);
	
		labelList.insert(labelList.end(), label);
	}

	AddBangCommand("!LabelAlwaysOnTop", BangAlwaysOnTop);
	AddBangCommand("!LabelClipboardCopy", BangClipboardCopy);
	AddBangCommand("!LabelClipboardPaste", BangClipboardPaste);
	AddBangCommand("!LabelCreate", BangCreate);
	AddBangCommand("!LabelDebug", BangDebug);
	AddBangCommand("!LabelDestroy", BangDestroy);
	AddBangCommand("!LabelHide", BangHide);
	AddBangCommand("!LabelLSBoxHook", BangLSBoxHook);
	AddBangCommand("!LabelMove", BangMove);
	AddBangCommand("!LabelNext", BangNext);
	AddBangCommand("!LabelPinToDesktop", BangPinToDesktop);
	AddBangCommand("!LabelPrevious", BangPrevious);
	AddBangCommand("!LabelRefresh", BangRefresh);
	AddBangCommand("!LabelReposition", BangReposition);
	AddBangCommand("!LabelResize", BangResize);
	AddBangCommand("!LabelScroll", BangScroll);
	AddBangCommand("!LabelSetFontColor", BangSetFontColor);
	AddBangCommand("!LabelSetText", BangSetText);
	AddBangCommand("!LabelShow", BangShow);
	AddBangCommand("!LabelShowHide", BangShowHide);
	AddBangCommand("!LabelToggleAlwaysOnTop", BangToggleAlwaysOnTop);
	AddBangCommand("!LabelToggle", BangToggle);
	AddBangCommand("!LabelUpdate", BangUpdate);
	//Andymon extention
	//andymon@ls-universe.info
	//************************
	AddBangCommand("!LabelmzscriptVarCopy", BangmzscriptVarCopy);
	AddBangCommand("!LabelPosmzscriptVarCopy", BangPosmzscriptVarCopy);

	return 0;
}

extern HDC hdcDesktop;
extern HBITMAP hbmDesktop;

void quitModule(HINSTANCE hInstance)
{
	RemoveBangCommand("!LabelAlwaysOnTop");
	RemoveBangCommand("!LabelClipboardCopy");
	RemoveBangCommand("!LabelClipboardPaste");
	RemoveBangCommand("!LabelCreate");
	RemoveBangCommand("!LabelDebug");
	RemoveBangCommand("!LabelDestroy");
	RemoveBangCommand("!LabelHide");
	RemoveBangCommand("!LabelLSBoxHook");
	RemoveBangCommand("!LabelMove");
	RemoveBangCommand("!LabelNext");
	RemoveBangCommand("!LabelPinToDesktop");
	RemoveBangCommand("!LabelPrevious");
	RemoveBangCommand("!LabelRefresh");
	RemoveBangCommand("!LabelReposition");
	RemoveBangCommand("!LabelResize");
	RemoveBangCommand("!LabelScroll");
	RemoveBangCommand("!LabelSetFontColor");
	RemoveBangCommand("!LabelSetText");
	RemoveBangCommand("!LabelShow");
	RemoveBangCommand("!LabelShowHide");
	RemoveBangCommand("!LabelToggleAlwaysOnTop");
	RemoveBangCommand("!LabelToggle");
	RemoveBangCommand("!LabelUpdate");
	//Andymon extention
	//andymon@ls-universe.info
	//************************
	RemoveBangCommand("!LabelmzscriptVarCopy");
	RemoveBangCommand("!LabelPosmzscriptVarCopy");

	LabelListIterator it;

	for(it = labelList.begin(); it != labelList.end(); it++)
		delete *it;

	labelList.clear();
	
	SendMessage(GetLitestepWnd(),
		LM_UNREGISTERMESSAGE,
		(WPARAM) messageHandler,
		(LPARAM) lsMessages);

	DestroyWindow(messageHandler);

	UnregisterClass("xLabel", hInstance);
	UnregisterClass("xLabelMessageHandler", hInstance);

	delete systemInfo;
	delete defaultSettings;

	hbmDesktop = (HBITMAP) SelectObject(hdcDesktop, hbmDesktop);
	DeleteDC(hdcDesktop);
	DeleteObject(hbmDesktop);
}

Label *lookupLabel(const string &name)
{
	LabelListIterator it;

	for(it = labelList.begin(); it != labelList.end(); it++)
	{
		if(_stricmp(name.c_str(), (*it)->getName().c_str()) == 0)
			return *it;
	}

	return 0;
}

BOOL APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	if(dwReason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hInstance);
	}

	return TRUE;
}

//Andymon extention
//andymon@ls-universe.info
//************************
// !Labelmzscriptvarcopy <label> <mzscript var>
void BangmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], var[64];
	char *buffers[] = {name, var};

	if(LCTokenize(pszArgs, buffers, 2, NULL) == 2)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->mzscriptvarcopy(var);
		}
	}
}

// !Labelmzscriptvarcopy <label> <mzscript var xpos> <mzscript var ypos>
void BangPosmzscriptVarCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], varx[64], vary[64];
	char *buffers[] = {name, varx, vary};

	if(LCTokenize(pszArgs, buffers, 3, NULL) == 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->posmzscriptvarcopy(varx, vary);
		}
	}
}

// !LabelAlwaysOnTop <label>
void BangAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->setAlwaysOnTop(true);
}

// !LabelClipboardCopy <label> <prefix>
void BangClipboardCopy(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], prefix[256];
	char *buffers[] = {name, prefix};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->clipboardCopy((numTokens >= 2) ? prefix : "");
		}
	}
}

// !LabelClipboardPaste <label> <prefix>
void BangClipboardPaste(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], prefix[256];
	char *buffers[] = {name, prefix};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->clipboardPaste((numTokens >= 2) ? prefix : "");
		}
	}
}

// !LabelCreate <label>
void BangCreate(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = new Label(pszArgs);
	label->load(hInstance);
	labelList.insert(labelList.end(), label);
}

// !LabelDebug
void BangDebug(HWND hwndCaller, LPCSTR pszArgs)
{
	LabelListIterator it;
	string message = "Normal Labels: (*label)\r\n";

	for(it = labelList.begin(); it != labelList.end(); it++)
	{
		message.append((*it)->getName());
		message.append(", ");
	}

	MessageBox(NULL, message.c_str(), "xLabel Debug Informations", MB_SETFOREGROUND);
}

// !LabelDestroy <label>
void BangDestroy(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
	{
		labelList.remove(label);
		delete label;
	}
}

// !LabelHide <label>
void BangHide(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
			label->hide();
}

// !LabelLSBoxHook <labelname>
void BangLSBoxHook(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64];
	char *buffers[] = {name};

	if(LCTokenize(pszArgs, buffers, 1, 0) == 1)
	{
		char *handle = strrchr(pszArgs,' ');
	    HWND hwndBox = (HWND)atoi(handle+1);

		Label *label = lookupLabel(name);

		if(label)
		{
			label->setBox(hwndBox);
			label->update();
		}
		else
		{
			label = new Label(name);
			label->load(hInstance, hwndBox);
			labelList.insert(labelList.end(), label);
		}
	}
}

//Andymon Animation Extention
//andymon@ls-universe.info
//**************************

// !LabelMove <label> <x> <y> [<steps> <time>]
void BangMove(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16];
	char *buffers[] = {name, A, B, C, D};

	if(LCTokenize(pszArgs, buffers, 5, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int x = ParseCoord(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int y = ParseCoord(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int step = atoi( C );
			int time = atoi( D );

			label->move(x, y, step, time);
		}
	}
}

//**************************

// !LabelNext <label>
void BangNext(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->next();
}

// !LabelPinToDesktop <label>
void BangPinToDesktop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->setAlwaysOnTop(false);
}

// !LabelPrevious <label>
void BangPrevious(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->previous();
}

// !LabelRefresh <label>
void BangRefresh(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);

	if(label)
		label->reconfigure();
}

//Andymon Animation Extention
//andymon@ls-universe.info
//**************************

// !LabelReposition <label> <x> <y> <width> <height> [<steps>] [<time>]
void BangReposition(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16], E[16], F[16];
	char *buffers[] = {name, A, B, C, D, E, F};

	if(LCTokenize(pszArgs, buffers, 7, NULL) >= 5)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int x = ParseCoord(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int y = ParseCoord(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int w = ParseDimen(C, 0, GetSystemMetrics(SM_CXSCREEN));
			int h = ParseDimen(D, 0, GetSystemMetrics(SM_CYSCREEN));
			int step = atoi( E );
			int time = atoi( F );

			label->reposition(x, y, w, h, step, time);
		}
	}
}

//**************************

//Andymon Animation Extention
//andymon@ls-universe.info
//**************************
// !LabelResize <label> <width> <height> [<steps> <time>]
void BangResize(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16], D[16];
	char *buffers[] = {name, A, B, C, D};

	if(LCTokenize(pszArgs, buffers, 5, NULL) >= 3)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			int w = ParseDimen(A, 0, GetSystemMetrics(SM_CXSCREEN));
			int h = ParseDimen(B, 0, GetSystemMetrics(SM_CYSCREEN));
			int step = atoi( C );
			int time = atoi( D );

			label->resize(w, h, step, time);
		}
	}
}
//**************************

// !LabelScroll <label> <'on', 'off', 'toggle', limit>
void BangScroll(HWND hwndCaller, LPCSTR pszArgs)
{
	// FIXME: This should be split into multiple bang commands
	char name[64], option[16];
	char *buffers[] = {name, option};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 2)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			if(stricmp(option, "off") == 0)
			{
				label->setScrolling(false);
			}
			else if(stricmp(option, "on") == 0)
			{
				label->setScrolling(true);
			}
			else if(stricmp(option, "toggle") == 0)
			{
				label->setScrolling(!label->isScrolling());
			}
			else
			{
				int limit = atoi(option);
				if(limit >= 0) label->setScrollLimit(limit);
			}
		}
	}
}

// !LabelSetFontColor <label> <red> <green> <blue> OR !LabelSetFontColor <label> <hexcolor>
void BangSetFontColor(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[16], B[16], C[16];
	char *buffers[] = {name, A, B, C};
	int numTokens = LCTokenize(pszArgs, buffers, 4, NULL);
	int color;

	if(numTokens >= 2)
	{
		Label *label = lookupLabel(name);

		if(numTokens >= 4)
		{
			int r = atoi(A);
			int g = atoi(B);
			int b = atoi(C);

			color = RGB(r, g, b);
		}
		else
		{
			color = strtol(A, NULL, 16);
			color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
		}

		label->getFont()->setColor(color);
		label->repaint();
	}
}

// !LabelSetText <label> <text>
void BangSetText(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], text[1024];
	char *buffers[] = {name, text};
	int numTokens = LCTokenize(pszArgs, buffers, 2, NULL);

	if(numTokens >= 1)
	{
		Label *label = lookupLabel(name);

		if(label)
		{
			label->setText((numTokens >= 2) ? text : "");
		}
	}
}

// !LabelShow <label>
void BangShow(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->show();
}

// !LabelShowHide <label> <timeout>
void BangShowHide(HWND hwndCaller, LPCSTR pszArgs)
{
	char name[64], A[64];
	char *buffers[] = {name, A};

	if(LCTokenize(pszArgs, buffers, 2, NULL) >= 2)
	{
		int timeout = atof(A);

		Label *label = lookupLabel(name);

		if(label)
			label->showHide(timeout);
	}
}

// !LabelToggleAlwaysOnTop <label>
void BangToggleAlwaysOnTop(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->setAlwaysOnTop(!label->isAlwaysOnTop());
}

// !LabelToggle <label>
void BangToggle(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
	{
		if(label->isVisible())
			label->hide();
		else
			label->show();
	}
}

// !LabelUpdate <label>
void BangUpdate(HWND hwndCaller, LPCSTR pszArgs)
{
	Label *label = lookupLabel(pszArgs);
	if(label)
		label->update();
}
