/*
CLEANUP.DLL
a litestep module that cleans up your computer.

 the recycle bin content, the clipboard,
 the recent documents,

  Distributed under GPL
  originally created by Mike Edward Moras
*/
/*
05MAY2002 - added new bang:
			!cleanclip = cleans the clipboard
			added 3 step.rc settings:
			cleanup = cleans trash and recent documents
			cleanbin = cleans trash only
			cleandoc = cleans docs only

START	  - adding 2 bangs to litestep: 
			!cleanbin = cleans trashbin
			!cleandoc = cleans recent documents
*/