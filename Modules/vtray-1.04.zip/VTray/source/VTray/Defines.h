#ifndef __DEFINES_H
#define __DEFINES_H

// use old size adjustment routine:
//#define OLD_ADJUST

// extra debug info:
#define DEBUG_EXTRA

// spamming debug info:
//#define DEBUG_SPAM

#endif