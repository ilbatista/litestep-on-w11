------------------------------------------------------------
LSSyndication.dll - LiteStepSyndication, created by Xjill
------------------------------------------------------------

Feature list:
-------------
 +	Supports an unlimited number of RSS feeds (in theory, but currently limited to 100)
 +	Complies to the W3C XML 1.0 standards, and the RSS 2.0 standards (should also support RSS ver. 0.91 and 0.92, but not guaranteed)
 +	Left-click to open the article in your browser (given that the news file includes a link)
 +	Right-click to toggle the scrolling
 +	Middle-click to jump forward to the next source
 +	You can customize what you want to display
 +	The only thing limiting how many items you can have is your system memory!
 -	Gonna implement a "no news older than xx hours" option
 -	Background images, magic pink transparency (and then hopefully real transparency) coming up!


Available Bang! Commands:
-------------------------
!LssRssUpdate			Refetches the news (Does not reload any .rc arguments)
!LssRssAlwaysOnTop		Sets window to be topmost
!LssRssHugBottom		(Bugged) Sets window to show behind all others (the opposite of AlwaysOnTop)
!LssRssNormalZOrder		Sets the window to be neither topmost or bottommost
!LssRssStopScrolling		Stops the scrolling of the news
!LssRssStartScrolling		Starts the scrolling
!LssRssToggleScrolling		Toggles the scrolling (right-clicking the window will also perform this)
!LssRssNextSource		Jumps forward to the beginning of the next source


Available .rc arguments:
------------------------
Use the following entry to add a source, you can add as many as you want, but I have at the current time added a limit to 100 sources, if anybody feels this is to low, just give me a mail and I'll be more than happy to raise that in future releases:
*LssRssURL		"http://www.wired.com/news/feeds/rss2/0,2610,,00.xml"

LssRssX			0		The position of the LSSyndication window on the x axis
LssRssY			0		The position of the LSSyndication window on the y axis
LssRssWidth		1280		The width of the window
LssRssHeight		20				The height of the window

LssRssFontFace		"verdana"	The font to use (Defaults to "Arial")
LssRssFontSize		14				The size of the text
LssRssFontColor		FFFFFF		The color of the text

LssRssBackgroundColor	CC2222		The background color (in hex)

LssRssNoDescriptions			If defined it ignores the <description> of an item (uses only the title)
LssRssNoMessageBoxes			If this is set, no messageboxes will pop up (you can still see the error messages in the LSS area).
LssRssAlwaysOnTop			If this is set the window will be above all other windows
LssRssHugBottom				(Bugged) If this is set the window will be below all other windows (if both this and LssAlwaysOnTop are both set, the window will appear AlwaysOnTop)
LssRssDelimiter		" -=- "		The delimiter between the different items (Default: " :: "), (if "" (empty), a single space is used)
LssRssTitleFormat	"-<title>: "	The data around the title. This is not used if LssRssNoDescriptions is defined! If only one argument supplied, it uses that on both sides. (Default: "<title>: "), can be empty ( "" ) (equals "<title>")
LssRssMaxItems				The maximum number of items per URL. Set to 0 for unlimited (Default)

LssRssScrollInterval	30		The scrolling update interval (in milliseconds)
LssRssScrollSpeed	2		The number of pixels to move each scroll update
LssRssUpdateInterval	0		The number of minutes to pass before automatically update the news. Never updates automatically if set to 0 (which is the default). NOTE: Some sites (like slashdot.org) bans your IP if you update too often! (slashdot.org sets the limit to 30 min, but this can vary from site to site)


Known Issues:
-------------
- If an update is in progress when a recycle is called, the update will need time to be aborted. If this isn't achived in 5 seconds it will give you a messagebox and then go on anyway, probably crashing LS.
- The HugBottom feature got some issues, hope you don't need it right now :)


Version History:
----------------
- b0.8:
Fixed some things which gave (heavy) crashes
  - .1: Fixed further crashes
  - .2: Fixed some problems regarding libraries,
	Fixed LssRssMaxItems
	Added !LssRssNextSource

- b0.7:
Completely new network code, and some small fixes all around

- b0.6:
First release, don't know how many had it, probably none :D


------------------------------------------------------------

Please contact me (xjill_IV@hotmail.com) if there's anything you would like improved or you find any bugs!

============================================================
Xjill
xjill_IV@hotmail.com
============================================================
"Everything you perceive, is only the result of your abstraction of the movements of particles"


