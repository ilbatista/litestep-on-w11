#include "common.h"
#include "ShortcutTexture.h"

ShortcutTexture::ShortcutTexture()
{
	bitmap = 0;
	hoverbitmap = 0;
	pressedbitmap = 0;

	memoryDC = 0;
	memoryBitmap = 0;

	memoryHoverDC = 0;
	memoryHoverBitmap = 0;

	memoryPressedDC = 0;
	memoryPressedBitmap = 0;
}

ShortcutTexture::~ShortcutTexture()	// it seems this destructor is never called
{
	if(bitmap)
	{
		SelectObject(memoryDC, memoryBitmap);
		DeleteObject(bitmap);
	}
	if(memoryDC)
		DeleteDC(memoryDC);

	if(hoverbitmap)
	{
		SelectObject(memoryHoverDC, memoryHoverBitmap);
		DeleteObject(hoverbitmap);
	}
	if(memoryHoverDC)
		DeleteDC(memoryHoverDC);

	if(pressedbitmap)
	{
		SelectObject(memoryPressedDC, memoryPressedBitmap);
		DeleteObject(pressedbitmap);
	}
	if(memoryPressedDC)
		DeleteDC(memoryPressedDC);
}

void ShortcutTexture::configure(const string &images, const string &truetrans)
{
	char normal[64], hover[64], pressed[64];
	char *buffers[] = {normal, hover, pressed};

	LCTokenize(images.c_str(), buffers, 3, NULL);

	bitmap = LoadLSImage(normal, 0);
	GetLSBitmapSize(bitmap, &imageWidth, &imageHeight);

	memoryDC = CreateCompatibleDC(0);
	memoryBitmap = (HBITMAP) SelectObject(memoryDC, bitmap);

	if ( stricmp(hover, ".none") != 0 )
		hoverbitmap = LoadLSImage(hover, 0);
	else
		hoverbitmap = LoadLSImage(normal, 0);

	if (!hoverbitmap)
		hoverbitmap = LoadLSImage(normal, 0);

	GetLSBitmapSize(hoverbitmap, &hoverimageWidth, &hoverimageHeight);

	memoryHoverDC = CreateCompatibleDC(0);
	memoryHoverBitmap = (HBITMAP) SelectObject(memoryHoverDC, hoverbitmap);

	if ( stricmp(pressed, ".none") != 0 )
		pressedbitmap = LoadLSImage(pressed, 0);
	else if ( stricmp(hover, ".none") != 0 )
		pressedbitmap = LoadLSImage(hover, 0);
	else
		pressedbitmap = LoadLSImage(normal, 0);
	
	if (!pressedbitmap)
		pressedbitmap = LoadLSImage(normal, 0);

	GetLSBitmapSize(pressedbitmap, &pressedimageWidth, &pressedimageHeight);

	memoryPressedDC = CreateCompatibleDC(0);
	memoryPressedBitmap = (HBITMAP) SelectObject(memoryPressedDC, pressedbitmap);

	if ( stricmp(truetrans.c_str(), "true") == 0)
	{
		transparent = true;
		trueTransparency = true;
	}
	else
	{
		transparent = false;
		trueTransparency = false;
	}

	//_saturation = GetRCInt(prefix , "SaturationIntensity", 255, 0, 255);
	//_hueIntensity = GetRCInt(prefix , "HueIntensity", 0, 0, 255);
	//_hueColor = GetRCColor(prefix, "HueColor", RGB(0, 0, 0));

	leftEdge = 0;
	topEdge = 0;
	rightEdge = 0;
	bottomEdge = 0;

	mode = MULTIBLT_STRETCH;
}

void ShortcutTexture::apply(HDC hDC, int x, int y, int width, int height, int imageType)
{
	if (imageType == 0)
	{
		if(bitmap == 0)
			return;
	}
	else if (imageType == 1)
	{
		if(hoverbitmap == 0)
			return;
	}
	else if (imageType == 2)
	{
		if(pressedbitmap == 0)
			return;
	}

	HDC bufferDC = CreateCompatibleDC(hDC);
	HBITMAP bufferBitmap = CreateCompatibleBitmap(hDC, width, height);
	bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);

	if(transparent && !trueTransparency)
	{
		SetStretchBltMode(bufferDC, STRETCH_DELETESCANS);

		if (imageType == 0)
		{
			MultiBlt(bufferDC, 0, 0, width, height,
			memoryDC, 0, 0, imageWidth, imageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		else if (imageType == 1)
		{
			MultiBlt(bufferDC, 0, 0, width, height,
			memoryHoverDC, 0, 0, hoverimageWidth, hoverimageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		else if (imageType == 2)
		{
			MultiBlt(bufferDC, 0, 0, width, height,
			memoryPressedDC, 0, 0, pressedimageWidth, pressedimageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		
		TransparentBltLS(hDC, x, y, width, height,
			bufferDC, 0, 0,
			RGB(255, 0, 255));
	}
	else
	{
		SetStretchBltMode(hDC, STRETCH_DELETESCANS);

		if (imageType == 0)
		{
			MultiBlt(hDC, x, y, width, height,
			memoryDC, 0, 0, imageWidth, imageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		else if (imageType == 1)
		{
			MultiBlt(hDC, x, y, width, height,
			memoryHoverDC, 0, 0, hoverimageWidth, hoverimageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
		else if (imageType == 2)
		{
			MultiBlt(hDC, x, y, width, height,
			memoryPressedDC, 0, 0, pressedimageWidth, pressedimageHeight,
			leftEdge, topEdge, rightEdge, bottomEdge,
			mode, SRCCOPY);
		}
	}

	bufferBitmap = (HBITMAP) SelectObject(bufferDC, bufferBitmap);
	DeleteDC(bufferDC);
	DeleteObject(bufferBitmap);
}

bool ShortcutTexture::isTransparent() const
{
	return transparent;
}
