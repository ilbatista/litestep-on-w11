#include <windows.h>
#include <stdio.h>
#include <winamp.h>
#include "geekamp.h"
#include "lsapi.h"

const char szAppName[] = "GeekAmp"; // Our window class, etc

// just initializing the functions
void BangPlay(HWND caller ,char* args);
void BangStop(HWND caller ,char* args);
void BangPause(HWND caller ,char* args);
void BangNext(HWND caller ,char* args);
void BangPrev(HWND caller ,char* args);
void BangLoadFile(HWND caller ,char* args);
void BangVolumeUp(HWND caller ,char* args);
void BangVolumeDown(HWND caller ,char* args);
void BangFFWD5S(HWND caller ,char* args);
void BangREW5S(HWND caller ,char* args);
void BangEQ(HWND caller ,char* args);
void BangPlaylist(HWND caller ,char* args);
void BangPrefs(HWND caller ,char* args);
void BangOnTop(HWND caller ,char* args);
void BangRew(HWND caller ,char* args);
void BangAbout(HWND caller ,char* args);
void BangAmpPower(HWND caller, char* args);
void BangOpenLoc(HWND caller, char* args);
void BangListStart(HWND caller, char* args);
void BangListEnd(HWND caller, char* args);
void BangStopFadeout(HWND caller, char* args);

//void BangFFWD10S(HWND caller, char* args);
//void BangREW10S(HWND caller, char* args);
//void BangFFWD20S(HWND caller, char* args);
//void BangREW20S(HWND caller, char* args);

void RegisterBangCommands(void);
void FindAmpPath(void);
char szAmpPath[256];



// Startup stuff
// -------------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}


// Actual main function
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	// Calls the function to register the commands
	RegisterBangCommands();
	FindAmpPath();
	return 0;
}

void FindAmpPath(void)
{
GetRCString("WinAmpPath", szAmpPath, "c:\\progra~1\\winamp\\winamp.exe", 256);
}


// actually register the commands with Litestep
void RegisterBangCommands(void)
{
	AddBangCommand("!AMP_PLAY", BangPlay);
	AddBangCommand("!AMP_PAUSE", BangPause);
	AddBangCommand("!AMP_STOP", BangStop);
	AddBangCommand("!AMP_NEXT", BangNext);
	AddBangCommand("!AMP_VOLUMEUP", BangVolumeUp);
	AddBangCommand("!AMP_VOLUMEDOWN", BangVolumeDown);
	AddBangCommand("!AMP_LOADFILE", BangLoadFile);
	AddBangCommand("!AMP_FFWD5S", BangFFWD5S);
	AddBangCommand("!AMP_REW5S", BangREW5S);
	AddBangCommand("!AMP_EQ", BangEQ);
	AddBangCommand("!AMP_PLAYLIST", BangPlaylist);
	AddBangCommand("!AMP_PREV", BangPrev);
	AddBangCommand("!AMP_PREFS", BangPrefs);
	AddBangCommand("!AMP_ONTOP", BangOnTop);
	AddBangCommand("!AMP_REW", BangRew);
	AddBangCommand("!AMP_ABOUT", BangAbout);
	AddBangCommand("!AMP_POWER", BangAmpPower);
	AddBangCommand("!AMP_OPENLOC", BangOpenLoc);
	AddBangCommand("!AMP_LISTSTART", BangListStart);
	AddBangCommand("!AMP_LISTEND", BangListEnd);
	AddBangCommand("!AMP_STOPFADE", BangStopFadeout);
//	AddBangCommand("!AMP_FFWD10S", BangFFWD10S);
//	AddBangCommand("!AMP_REW10S", BangREW10S);
//	AddBangCommand("!AMP_FFWD20S", BangFFWD20S);
//	AddBangCommand("!AMP_REW20S", BangREW20S);
	
}

void BangPlay(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		if (hwndWinamp = FindWindow("Winamp v1.x", NULL))
		{
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_BUTTON2,0);
		}
		else
		{
			ShellExecute(caller, "open", szAmpPath ,NULL, NULL, SW_MINIMIZE);
						
		}
	}
}


void BangStop(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_BUTTON4,0);
	}
}


void BangPause(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_BUTTON3,0);
	}
}


void BangNext(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_BUTTON5,0);
	}
}


void BangPrev(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_PREVSONG,0);
	}
}


void BangLoadFile(HWND caller ,char* args)
{
	{
		
		HWND hwndWinamp;
		if (hwndWinamp = FindWindow("Winamp v1.x", NULL))
		{
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_FILE_PLAY,0);
		}
		else
		{
		ShellExecute(caller, "open", szAmpPath ,NULL, NULL, SW_MINIMIZE);

		}
	}
}


void BangVolumeUp(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_VOLUMEUP,0);
	}
}


void BangVolumeDown(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_VOLUMEDOWN,0);
	}
}



void BangFFWD5S(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_FFWD5S,0);
	}
}


/*void BangFFWD10S(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_FFWD5S,0);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_FFWD5S,0);
	}
}


void BangFFWD20S(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_FFWD5S,0);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_FFWD5S,0);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_FFWD5S,0);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_FFWD5S,0);
	}
}
*/

void BangREW5S(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_REW5S,0);
	}
}

/*
void BangREW10S(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_REW5S,0);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_REW5S,0);
	}
}


void BangREW20S(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_REW5S,0);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_REW5S,0);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_REW5S,0);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_REW5S,0);
	}
}
*/


void BangEQ(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_OPTIONS_EQ,0);
	}
}

void BangPlaylist(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		if (hwndWinamp = FindWindow("Winamp v1.x", NULL))
		{
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_OPTIONS_PLEDIT,0);
		}
		else
		{
			ShellExecute(caller, "open", szAmpPath ,NULL, NULL, SW_MINIMIZE);
		}

	}
}


void BangRew(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_BUTTON1,0);
	}
}


void BangPrefs(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		if (hwndWinamp = FindWindow("Winamp v1.x", NULL))
		{
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_OPTIONS_PREFS,0);
		}
		else
		{
		ShellExecute(caller, "open", szAmpPath ,NULL, NULL, SW_MINIMIZE);
		}
	}
}


void BangOnTop(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_OPTIONS_AOT,0);
	}
}


void BangAbout(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_HELP_ABOUT,0);
	}
}


void BangAmpPower(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		if (hwndWinamp = FindWindow("Winamp v1.x", NULL))
		{
			SendMessage(hwndWinamp, WM_CLOSE, 0,0);
			
		}
		else
		{
				ShellExecute(caller, "open", szAmpPath ,NULL, NULL, SW_MINIMIZE);
		}
		
	}
}


void BangOpenLoc(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_BUTTON2_CTRL,0);
	}
}


void BangListStart(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_BUTTON1_CTRL,0);
	}
}


void BangListEnd(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_BUTTON5_CTRL,0);
	}
}


void BangStopFadeout(HWND caller ,char* args)
{
	{
		HWND hwndWinamp;
		hwndWinamp = FindWindow("Winamp v1.x", NULL);
		SendMessage(hwndWinamp, WM_COMMAND,WINAMP_BUTTON4_SHIFT,0);
	}
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quitModule(HINSTANCE dllInst)
{
}
