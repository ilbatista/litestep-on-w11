******************************************************************************
This file was created on 1:09 AM 11/17/98 by GeekMaster
******************************************************************************
(	
	Lowell Heddings
	http://skyscraper.fortunecity.com/coding/739
	lheddings@geocities.com
	AIM: lheddin
	IRC: Geekmasta
	ICQ: 17869937
)
******************************************************************************
	This .dll file is used to control Winamp via !<commands> in the step.rc
file of litestep.
******************************************************************************

To use: Simply add a line to your step.rc file that looks like the following:

	LoadModule c:\litestep\geekamp.dll

I think this has to be loaded after the other modules, but I'm not sure.

******************************************************************************

Once you have loaded the module, you can use any of the commands anywhere
in litestep. This could be either a Shortcut or a Hotkey or a Wharf.

For Instance:
	*Hotkey Win F9 !Amp_Play
	This line would assign the combo of Win + F9 to Play the current song
The commands are not case sensitive, either

******************************************************************************
New Commands:
******************************************************************************
GeekAmp ver 1.0
!AMP_PLAY
	Pretty Obvious

!AMP_PAUSE
	""
!AMP_STOP
	""
!AMP_NEXT
	""
!AMP_PREV
	This changes to the previous song
!AMP_VOLUMEUP
	This turns the volume up a little
!AMP_VOLUMEDOWN
	This turns the volume down a little
!AMP_LOADFILE
	This pops up the load file box
!AMP_FFWD5S
	This Fast Forwards 5 seconds
!AMP_REW5S
	This Rewinds 5 seconds
!AMP_EQ
	This TOGGLES the EQ window. This means, for instance, if you create
	a hotkey with this action, that you press it once to display, and
	again to hide.
!AMP_PLAYLIST
	This TOGGLES the Playlist window. See Above
!AMP_PREFS
	This TOGGLES the Preferences window. See Above
!AMP_ONTOP
	This TOGGLES whether or not WinAmp is on top
!AMP_REW
	This rewinds as well. This actually executes the function of the rewind button
!AMP_ABOUT
	This displays the About dialog for Winamp

-- 2:12 AM 11/23/98 --
GeekAmp ver 1.1
Updates:

The file has been renamed from geek_amp.dll to geekamp.dll.

!Amp_Play, !Amp_loadfile, !Amp_playlist, and !amp_prefs now detect whether Winamp is
running, and launch Winamp from c:\progra~1\winamp\winamp.exe minimized. I'm going to update this
in the future, till then live with it, or move your winamp temporarily.

!Amp_Power
	This toggles Winamp on /off. Pretty usefull tied to a hotkey
!Amp_OpenLoc
	This opens the Open Location dialog box
!Amp_ListStart
	This moves to the start of the playlist
!Amp_ListEnd
	This moves to the end of the playlist
!Amp_StopFade
	This stops with fadeout

*************************

2:28 AM 11/24/98
GeekAmp ver 1.2
Updates:

I added the ability to choose your Winamp directory using WinAmpPath
in the step.rc file.
Usage:
WinAmpPath c:\winamp\winamp.exe

This needs to be the full path, including winamp.exe, but it should
work without any problems. If no path is specified, it will default to
c:\progra~1\winamp\winamp.exe.


*********************
Future updates:
A way to do Winshade mode on both the playlist and the main with the
same command.
A way to show/hide the main window


Planned !commands:
!Amp_FF10S
!Amp_REW10S
!Amp_FF20S
!Amp_REW20S
!Amp_ShowWindow




