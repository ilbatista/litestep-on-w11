-----------------------------------------------------------------------------
wa3remote 1.0
Author: X <b01011000@hotmail.com>
Last Modified: August 1, 2003
-----------------------------------------------------------------------------

wa3remote is a Winamp 3 component that lets external applications send
commands to and retrieve information from Winamp 3. wa3remote was designed
specifically for use by xLabel, a Litestep module, but it is general enough
that it could be used by other applications or modules.

To compile wa3remote you must first install the Wasabi SDK and then place the
wa3remote source code in a subdirectory of the "studio" directory.
