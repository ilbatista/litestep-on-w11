#ifndef __WA3REMOTE_H
#define __WA3REMOTE_H

#include "../studio/corecb.h"
#include "../studio/wac.h"

#define WA3REMOTE_SHAREDMEMNAME "wa3remote"
#define WA3REMOTE_WNDCLASS "wa3remote"

#define WA3REMOTE_WM_GETLENGTH (WM_USER + 1)
#define WA3REMOTE_WM_GETPAN (WM_USER + 2)
#define WA3REMOTE_WM_GETPOSITION (WM_USER + 3)
#define WA3REMOTE_WM_GETSIZE (WM_USER + 4)
#define WA3REMOTE_WM_GETSTATUS (WM_USER + 5)
#define WA3REMOTE_WM_GETVOLUME (WM_USER + 6)
#define WA3REMOTE_WM_NEXT (WM_USER + 7)
#define WA3REMOTE_WM_PAUSE (WM_USER + 8)
#define WA3REMOTE_WM_PLAY (WM_USER + 9)
#define WA3REMOTE_WM_PREVIOUS (WM_USER + 10)
#define WA3REMOTE_WM_SETPAN (WM_USER + 11)
#define WA3REMOTE_WM_SETPOSITION (WM_USER + 12)
#define WA3REMOTE_WM_SETVOLUME (WM_USER + 13)
#define WA3REMOTE_WM_STOP (WM_USER + 14)

#define WA3REMOTE_MAX_ALBUM 64
#define WA3REMOTE_MAX_ARTIST 64
#define WA3REMOTE_MAX_COMMENT 256
#define WA3REMOTE_MAX_GENRE 64
#define WA3REMOTE_MAX_INFO 64
#define WA3REMOTE_MAX_NAME 256
#define WA3REMOTE_MAX_PLAYSTRING 256
#define WA3REMOTE_MAX_TITLE 128
#define WA3REMOTE_MAX_TRACK 8
#define WA3REMOTE_MAX_YEAR 8

typedef struct WA3REMOTE_SHAREDMEM {
	int nAddedOn;
	CHAR szAlbum[WA3REMOTE_MAX_ALBUM];
	CHAR szArtist[WA3REMOTE_MAX_ARTIST];
	int nBitRate;
	int nBitsPerSample;
	CHAR szComment[WA3REMOTE_MAX_COMMENT];
	CHAR szGenre[WA3REMOTE_MAX_GENRE];
	CHAR szInfo[WA3REMOTE_MAX_INFO];
	int nLastPlayed;
	int nLength;
	int nModified;
	CHAR szName[WA3REMOTE_MAX_NAME];
	int nNumChannels;
	CHAR szPlayString[WA3REMOTE_MAX_PLAYSTRING];
	int nSampleRate;
	int nSize;
	CHAR szTitle[WA3REMOTE_MAX_TITLE];
	CHAR szTrack[WA3REMOTE_MAX_TRACK];
	CHAR szYear[WA3REMOTE_MAX_YEAR];
} WA3REMOTE_SHAREDMEM, *PWA3REMOTE_SHAREDMEM;

class WA3Remote : public WAComponentClient, CoreCallbackI
{
private:

	HANDLE hSharedMem;
	HWND hWnd;

public:
	
	WA3Remote();

	void onCreate();
	void onDestroy();
	GUID getGUID();

	int corecb_onTitleChange(const char *title);

	LRESULT OnGetLength(WPARAM wParam, LPARAM lParam);
	LRESULT OnGetPan(WPARAM wParam, LPARAM lParam);
	LRESULT OnGetPosition(WPARAM wParam, LPARAM lParam);
	LRESULT OnGetStatus(WPARAM wParam, LPARAM lParam);
	LRESULT OnGetVolume(WPARAM wParam, LPARAM lParam);
	LRESULT OnNext(WPARAM wParam, LPARAM lParam);
	LRESULT OnPause(WPARAM wParam, LPARAM lParam);
	LRESULT OnPlay(WPARAM wParam, LPARAM lParam);
	LRESULT OnPrevious(WPARAM wParam, LPARAM lParam);
	LRESULT OnSetPan(WPARAM wParam, LPARAM lParam);
	LRESULT OnSetPosition(WPARAM wParam, LPARAM lParam);
	LRESULT OnSetVolume(WPARAM wParam, LPARAM lParam);
	LRESULT OnStop(WPARAM wParam, LPARAM lParam);

protected:

	static LRESULT WINAPI WndProc(HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam);
};

extern WAComponentClient *the;

#endif
