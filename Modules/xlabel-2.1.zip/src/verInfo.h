#if !defined(__VERINFO_H)
#define __VERINFO_H

#define V_AUTHOR "X"
#define V_NAME "xLabel"
#define V_VERSION "2.1"

#endif
