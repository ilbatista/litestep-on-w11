LSLM v1.11 (LiteStep Load Meter that is ;))
==========

What is It?
-----------
This module displays the current system load in form of flow charts.
You can adjust the color settings, make it transparent-looking and
specify the interval in which the display is updated.  The configuration
file can be edited and reloaded at runtime (see: popup menu).


NOTE:  In case you're using Notepad as your config editor, you have to
-----  use "Save As..." instead of "Save"--otherwise LSLM won't notice
       the changes you made (must have to do with the way Windooze handles/
       buffers .ini files *shrug*)


With the left mouse button you can cycle through the different sub display
modes (depending on the main display mode).


  Main mode 1) EVERYTHING (you can control the upper and lower area):
  -=-=-=-=-=-=-=-=-=-=-=-

    TOP
    ---
    Sub mode 0:
         CPU = current CPU load in percent
         AVG = average CPU load
    Sub mode 1: (Windows 9x ONLY!)
         SWP = percent of the swap file currently in use
         SIZ = size of swap file in megabytes
    Sub mode 2:
         PHM = amount of physical memory (RAM) currently in use
         AVL = free physical memory in megabytes

    BOTTOM
    ------
    Sub mode 0:
         CPU use
    Sub mode 1:
         Uptime statistics
    Sub mode 2:
         Yes, both ;)

  Main Mode 2) BARS ONLY:
  -=-=-=-=-=-=-=--=-=-=-=

    Here you can toggle your favorite display for the upper and lower
    display areas (like Main mode 1 with the exception, that only bar modes
    are available)

  Main mode 4) UPTIME & CPU:
  -=-=-=-=-=-=-=--=-=-=-=-=-

    Here you can toggle the Uptime/CPU display order =)


Technical
---------

LSLM stores its specific settings under the "[LSLM]" section in a file
called "modules.ini" which resides in the LiteStep directory.

  NOTE: If this file doesn't exist it will be created using
  ----- default values.


Installation
------------
Just copy the module (LSLM.app) and viscolor.txt into your LiteStep
directory.  Additionally you can copy the supplied .bmp files in case
you want to use them for bitmapped cpu readout.


Settings
--------
A (short) explanation of the various modules.ini settings:


 | LSLM specific (section [LSLM])
 `-------------------------------------------------------------------


      Booleans (either set to TRUE or FALSE):
      -=-=-=-=
           Border - whether to put borders around the displays or not
           Filled - if you want a filled chart set this to TRUE
         Centered - centers the cpu flow chart instead of aligning it to
                    the bottom
          Outline - makes the cpu chart have an outline
             Grid - turns the background grid on or off
      Transparent - restores the background after each update
        DblBuffer - if activated the display won't flicker anymore :D
           UseVIS - use a WinAMP .vis file for filling charts and bars
           UseBMP - fill the graph. readout from a bitmap (if this is
                    set, UseVIS will be ignored for the flow chart--but not
                    for the gauge bars of course ;)) SEE: "Bitmap"
           ScrBMP - whether you want the bitmap to follow the graph or not
                    (scroll)
         UseTicks - in case the uptime stats may be spoiled set this to FALSE
                    (that way it starts counting at an uptime of 0 instead of
                    querying the system)
          Numeric - display numeric values
     StartEnabled - whether to start LSLM in active mode or not
       Mode4_Full - if you want to have the CPU graph in full size when running
                    in CPU & Uptime stats mode, set this to TRUE
       Mode4_CPUp - display order of CPU / Uptime in 4th mode
                    (TRUE = CPU -> Uptime, FALSE = the other way round)


      Other stuff
      -=-=-=-=-=-
          TimeVal - here you can specify the interval in which the display
                    will be updated in milliseconds (1000 = default)
          ModeTop - starting mode for upper display area (0/1/2)
          ModeBot -     "      "   "  bottom   "      "  (0/1/2)
       ModeBarTop - Bar mode top display selection (0/1/2)
       ModeBarBot -  "    "  bottom "        "     (0/1/2)
          CyclTop - if set to >0 it makes the module cycle through the
                    modes every n-th update (TimeVal)
          CyclBot - the same as CyclTop -- only for the bottom area
          VISFile - path and name of the visualisation file (see: UseVIS)
         ConfigEd -   "   "    "  "   "  configuration editor you want to use
                    (e.g. "Notepad")
      DisplayMode - initial displaymode (full-blown, only bars, bare CPU chart,
                    or CPU chart with Uptime display (0/1/2/3))
       BorderSize - if this variable is set LSLM uses it instead of the one
                    which is supplied by LiteStep
           Bitmap - path and name of a .bmp you might want to use for filled
                    readout, it will be scaled up/down to make it fit in the gfx
                    area (don't forget to set UseBMP to TRUE as well)
          BMPPath - path to the LSLM resource .bmp directory ("LSLM\" will be
                    added!) in case you want to put that directory elsewhere,
                    otherwise this variable is not required


  |Common (section [Common])
  �------------------------------------------------------------------


      Color values (in HEX notation (RRGGBB)):
      -=-=-=-=-=-=
          BGColor - background color of the display
          FGColor - foreground color (filled readout)
          OLColor - outline color for filled areas
          GRColor - grid color
          TXColor - color of text/numbers
          TLEdgeC - color of the top   and left sides of borders
          BREdgeC -   "    "  "  bottom " right   "    "    "

  --- SIDE NOTE: ------------------------------------------------------------
      The "problem" with COLORREF values is the way Windooze handles them:

      "... When specifying an explicit RGB color, the COLORREF value has the
      following hexadecimal form: 0x00bbggrr ..."

      So if a program just reads and saves those values without proper conversion,
      they will be backwards (just as in LiteStep ;))

      Here's how to handle it correctly ('Color' is our COLORREF value):

        For saving:
        -----------
          sprintf(FmtBuff, "%02X%02X%02X", GetRValue(Color),
                                           GetGValue(Color),
                                           GetBValue(Color));

        and reading:
        ------------
          COLORREF cTmp;    // Temporary variable for conversion

          sscanf(Buffer, "%X", &cTmp);

          Color = RGB(GetBValue(cTmp), GetGValue(cTmp), GetRValue(cTmp));

        The used macros (in case you don't have them):

          #define GetRValue(rgb)   ((BYTE) (rgb))
          #define GetGValue(rgb)   ((BYTE) (((WORD) (rgb)) >> 8))
          #define GetBValue(rgb)   ((BYTE) ((rgb) >> 16))

          #define RGB(r, g ,b)  ((DWORD) (((BYTE) (r) | \
                                ((WORD) (g) << 8)) | \
                                (((DWORD) (BYTE) (b)) << 16)))
   --- SIDE NOTE -------------------------------------------------------------


Popup Menu (right mousebutton)
------------------------------
  x Enabled                        - enable/disable output
    Mode    > x 1) Everything      - display all availabe stats (cycle with LMB)
              x 2) Bars only       - important datas in form of fuel gauges
              x 3) CPU only        - "plain" CPU usage flowchart
              x 4) CPU & Uptime    - CPU usage + Uptime stats
              x    Fullsize CPU    - CPU in full window height (applies to 4)
  x Centered CPU                   - CPU flow chart centered
    Run WinTop                     - executes Wintop.exe (see: Kernel PowerToys)
    --------------------------
    Reload Config                  - you-guessed-it :) reloads the config file
    Edit Config                    - spawns an external editor with modules.ini
                                     (see variable "ConfigEd")

Requirements:
-------------
Windows 9x:
      Nothing special to my knowledge (except for LiteStep of course =P)

Windwos NT:
      LS and pdh.dll (Performance Data Helper)


History
-------

v0.1  - Initial release
v0.2  - added semi-transparency:
          new .ini entry: "Transparent" (set to TRUE or FALSE)
v0.3  - added popup menu for editing/reloading the .ini file
      - settings are now stored in "modules.ini" - "lslm.ini" is obsolete
        (other modules also store their settings in that file)
      - now uses a double-buffered drawing routine (if activated)
v0.4  - added support for WinAMP's .vis files (Floach)
      - changed the extension to ".app" to make it look more like
        an AfterStep module (Floach)
      - now displays the average load ("AVG" bar)
      - current load is also displayed in form of a bar and numeric as well
      - various design changes
      - BIG thanks to Floach for pointing out a bug before releasing this
        version :)
v0.5  - added code for displaying use of physical memory and swap
      - hopefully the charts don't flood the borders anymore :/
      - automatic cycling through modes
v0.6  - fixed the swap use display (shouldn't crash anymore)
      - added uptime statistics
v0.7  - new option for disabling the display (popup/.ini) (JoelG)
      - can now start WinTop from the popup menu (redled)
        (WinTop.exe is a component that comes with the "Windows 95 Kernel
         PowerToys"--'A Windows 95 approximation to the UNIX "top" program')
      - added a new display mode in which it only shows the important stats in
        form of bars (popup/.ini)
v0.8  - yet another display mode for the purists
        (bare CPU display chart as in v0.3 =))
      - fixed some calculation routines (mem/swap sometimes had a variable
        overflow what ended in odd results) (MH4)
      - uses another routine for getting the system's uptime (MH4)
      - the filled cpu chart can now be outlined
v0.9  - added NT support (now that was something hehe, there is one restriction
        so far -- no display of swapfile statistics =/)
      - took out all the MFC crap what made the mod grow to be a 65k monster
        (so it doesn't require mfc42.dll anymore which is in fact >900kb
        in size)
      - changed the variable type of the uptime counter (damn overflows =P)
        (MH4)
v0.99   (after having spent a whole week in hospital =/)
      - fixed the "Disabled" image (the error didn't show in WharfTest and no
        one seems to have noticed the display routine was broken *SHOCKED* ;P)
      - added yet another running mode (CPU / Uptime stats in one view -- the
        display order is toggable with left mouse click)
      - 3rd bottom submode for running mode "Everything" - CPU + uptime
      - new variable for specifying another editor than Notepad ("ConfigEd")
      - changed the SIZ label to SZE (so that ppl stop wondering what on
        earth the 512 stands for =))
      - finally changed the format of the color values (RRGGBB instead of
        BBGGRR)  NO WORRIES, the old values will be converted (and moved to
        the 'Common' section) on first program launch
      - now it's also possible to use a bitmap for the filled CPU readout ;D
        (see new values -> UseBMP, ScrBMP, Bitmap)
      - made the colors for the boxes configurable as well
        (see: TLEdgeC, BREdgeC, [Common] section)
      - centered cpu readout if desired (see: Centered)
      - moved the color values to another section ([Common])... maybe this could
        become a shared section for all modules what would make it a lot easier
        to create more standardized desktops (instead of having each module use
        its own color values)?  Perhaps there we could also specify things
        like an external config editor (MH4? =)) etc.
      - modified the uptime stat routines once again
v1.00 - new variable for using another BorderWidth than the one which is set
        in LiteStep (see: BorderSize)
      - put the resources in external files (so you can change the characters
        without an resource editor :)) (see: BMPPath)
v1.01 - modification of Main mode 2 (Bars only) (AMJ / Side B)
v1.02 - fix for Win2K (the CPU display should work now--hopefully)
v1.10 - small modifications for LSLMConfig (nothing big I hope)
v1.11 - fixed the 'ConfigEd' overriding bug
      - Swapfile stat should now work under NT as well

--------------------------------------------------------------------------------
              BIG THANKS FOR BUG REPORTING AND IDEAS HAVE TO GO TO:
              Floach, JoelG, redled, MHolmesIV, Furan, AMJ / Side B
--------------------------------------------------------------------------------

  IN CASE I HAVE FORGOTTEN ANYONE OR ANYTHING IN THIS DOCUMENTATION--SORRY IN
                                  ADVANCE ;)


Address
-------
arkay@gmx.net OR "ArKay" on IRC (Efnet)
^^^^^^^^^^^^^ CHANGED!!
