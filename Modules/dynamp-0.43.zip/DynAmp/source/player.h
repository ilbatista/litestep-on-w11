#ifndef __PLAYER_H
#define __PLAYER_H

// defines for checking which player it is
#define NONE	0
#define WA2		11
#define WA3		22

// mod keys
#define NONE	0
#define ALT		1
#define CTRL	2
#define SHIFT	3
#define WIN		4
#define VK		5

#include <windows.h>

#define WIN32_LEAN_AND_MEAN
#define MAX_LINE_LENGTH 4096

// main class for players, rest is derived from this

class player
{
public:
	player(); // reads settings for visibility states
	//player(LPCSTR command);
	//~player();

	char *OnPlayerLoad;
	//player *next_control; // to load all players in a list?
	//char *OnLoadCommand;

	// pure virtual functions, needs to be implemented in each player control
	virtual HWND GetPlayerWnd() = 0;
	virtual void powerOff() = 0;

	virtual void prev() = 0;
	virtual void play() = 0;
	virtual void pause() = 0;
	virtual void stop() = 0;
	virtual void next() = 0;

	virtual void repeat() = 0;
	virtual void shuffle() = 0;

	virtual void volumeUp() = 0;
	virtual void volumeDown() = 0;
	virtual void forward5s() = 0;
	virtual void rewind5s() = 0;

	virtual void openLoc() = 0;
	virtual void loadDir() = 0;
	virtual void prefs() = 0;

	virtual void loadFile() = 0;
	virtual void onTop() = 0;


	// general functions:

	static void playerOpen()
	{
		// simple player opener
		(WinampStartNormal) ? WinExec(szAmpPath, SW_NORMAL) : WinExec(szAmpPath, SW_MINIMIZE);
	}

	void power();
	void powerOn();

	void show();
	void hide();
	void display();

	// joint player handling functions
	static void sendMsg(HWND wnd, const int msg)
	{
		SendMessage(wnd, WM_COMMAND, msg, 0);
	}

	static void sendKey(HWND wnd, short key)
	{
		UINT scancode = MapVirtualKey(key, 0);

		PostMessage(wnd, WM_KEYDOWN, key, scancode);
		PostMessage(wnd, WM_CHAR, key, scancode);
		PostMessage(wnd, WM_KEYUP, key, scancode);
	}

	static void sendKey(HWND wnd, short key, const int mod)
	{
		short modkey = NULL;
		UINT scancode = MapVirtualKey(key, 0);

		if (mod == CTRL)
			modkey = VK_CONTROL;
		else if (mod == ALT)
			modkey = VK_MENU;
		else if (mod == SHIFT)
			modkey = VK_SHIFT;
		else if (mod == WIN)
			modkey = VK_LWIN;

		UINT modcode = MapVirtualKey(modkey, 0);

		PostMessage(wnd, WM_KEYDOWN, modkey, modcode);
		PostMessage(wnd, WM_KEYDOWN, key, scancode);
		PostMessage(wnd, WM_CHAR, key, scancode);
		PostMessage(wnd, WM_KEYUP, key, scancode);
		PostMessage(wnd, WM_KEYUP, modkey, modcode);
	}

	// path to player
	static char szAmpPath[MAX_LINE_LENGTH];

	static BOOL WinampStartNormal; // or minimize
	static BOOL PlayNotOpen; // true: don't open player, else start player if not running
	static BOOL PlayPauseNotOpen;
	static BOOL PlaylistNotOpen;
	static BOOL PrefsNotOpen;
	static BOOL LoadFileNotOpen;
	static BOOL ShowNotOpen;

private:

};

#endif