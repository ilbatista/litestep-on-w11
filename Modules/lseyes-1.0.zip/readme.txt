LSEyes 1.0     (c) 1998 Christop Handel
========================================
    The famous X-Eyes for Lightstep








What it does:

A Pair of Eyes watching your Mousearrow. 



Installation:

Just put the DLL in your LS-Directory and this in your RC
*Wharf text default.bmp @c:\Litestep\lssdk.dll



Contact:

eMail to handel@hrzpub.tu-darmstadt.de
Send comments, questions, bug-reports, and hints! And 
if you like the programm a picturepostcard to:

   christoph handel
   pallaswiesenstr.14
   d-64289 darmstadt
   germany




Known Bugs:

Eyes won't move when Arrow is in Titlebar or Scrollbar of a window 
(this IS a windows-bug, there's no MouseMessage sent, blame Microsoft)



Whishes:

Can anyone explain me how to restore the background under an Ellipse?
At the moment I paint an white Eyball at the old position, then a black one
at the new. 
If I could just remove the old eyeball I could use custom Backgrounds.
I don't want to repaint the whole wharf each time. There must be a faster way.
A custom background could then contain the white pupils and the wharf background.
That would be great :-)




Technical:

Made with Delphi 2.0. Tested under NT 4.0 SP1 and SP3.
This is not a port of the X-Eyes. I don't have the source for that...
I made it all by myself.




Thanks:

Bryan Kilian for the port of the LSSDK and for explaining me the Bitmap
The LS-Devellopers for the great Shell



story:

24.08.98 1.0   background is painted (thanks to Bryan)
19.08.98 �0.91 fixed the HookChain (what a silly misstake).
18.08.98 Ready with �0.9 First Public Release.
         Found an untrapped Exception.
17.08.98 Success in defining global DLL-Variables using memory-mapped files.
16.08.98 Started programming.
15.08.98 Got LS �23e. Found a LSSDK for delphi. Just missed the cdecl.
10.06.98 Trying to transport LSSDK to Delphi. Failed.

