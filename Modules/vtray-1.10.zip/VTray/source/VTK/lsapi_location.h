/*

	LSAPI Location

	Author:	Vendicator

	Description:
	Added for simple inclusion of the lsapi.h file you
	don't need to edit all the files in the VTK.

*/

#ifndef __LSAPI_LOCATION_H
#define __LSAPI_LOCATION_H


#include "../../cvs_indie/current/lsapi/lsapi.h"


#endif