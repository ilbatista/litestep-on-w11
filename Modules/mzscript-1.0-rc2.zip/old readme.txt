NOTE: In order to run this dll, you need msvcr71.dll and msvcp71.dll on the system.
These can be optained by either installing the Microsoft .NET Foundation 1.1, or 
through various websites that distrubute them for free (use google).

NOTE: Recursing mzscriptbangs several times, or even just calling mzscriptbangs 
from other mzscriptbangs from other mzscriptbangs (etc.) will cause litestep to 
crash because of a stack overflow. As far as I know there is no way to change 
this, so instead, it must be avoided. (In testing it took upwards near 50 recurses 
to cause a crash, so a little recursion is ok, but try to avoid it.)

Changes in Current 4-17-2005 build: 
This build brings alot of changes, some that might break scripts 
from past builds, so read carefully. 
(I know its alot to read and understand. I will be working on a brand 
new readme, but with RL getting in the way its going to take a while.)

	-[]'s can now be used in many places they could not be used before.
			This allows performing tasks like setting variables to hold 
			quotes to be done much easier.
			EX.
			!varset myvar ["abc" 'def']
			would yeild
			%{myvar}="abc" 'def'
			This also allows you to use [] around variables that might 
			hold quotes, without having to worry about the quotes in 
			the variable messing up your script.
			EX.
			if %{var1}="
			
	-added new escape character combo.
			"%-" now expands into "'" (single quote aka. apostrophe)
			
	-var:count now equals 0 when var is empty
	
	-the separator now separates even if it is between quotes
			so [a:"b:c":d] would be separated into [a], ["b], [c"], and [d]
			
	-var:sep can now be more than one character long
			EX.
			!varset var:sep "<br>"
			
	-var:sep can now be set to a special case: token
			EX
			!varset var:sep token
			This will use standard litestep tokenization (whitespace, ", ', and [])
			to seperate the variable. Read on about args to understand more.
			
	-the args variable is now split up based on standard 
			litestep tokenization (using whitespace, ", ', and [])
			EX:
			if %{args}=abc "def" 'ghi' [jkl]
			%{args:1}=abc
			%{args:2}=def
			%{args:3}=ghi
			%{args:4}=jkl
			(this is the same thing as var:sep=token)
	-NOTE:each script also has a %{script} variable that equals the name of the script. 
			This has always been implemented but never noted in documentation.
			
	-mzvarfiles now support IF Else EndIf statements when reading in AND saving 
			(i think... this is gunna take alot of testing to make sure though)
			
	-new way of reading in and saving variables-
			when read in, everything after the variable name is stored in var:line. It 
			can be accessed and set like var:sep. Then, when !varset is called, the 
			value AND the line is changed, then when you save, the var:line is saved, 
			not just the value. This actually allows you to work with multitoken 
			variables like labelBorders 1 2 3 4. It just takes a bit of work.
			Also, when you alter var:line it  is retokenized to find the actual value 
			of var. If var:line has no token, then the var becomes empty. 
			If you perform a remove on var:line, the var also becomes empty.
			The main reason i did this is so that saving doesn't just add quotes.
			Instead, it uses what was there when the variable was read in.
			EX.
			(from some mzvarfile)
			myvar "c:\music\" 3
			(after reading in)
			%{myvar}=c:\music\
			%{myvar:line}= "c:\music\" 3
			(then if i do)
			!varset myvar "c:\games\"
			(then this will be true)
			%{myvar}=c:\games\
			%{myvar:line}= "c:\games\" 3
			and of course i can do this:
			!varset myvar:line [ "c:\appz\" 2]
			(then this will be true)
			%{myvar}=c:\appz\
			%{myvar:line}= "c:\appz\" 2
			NOTE:var:line uses the token separator, 
			so if this is true:
			%{var:line}= "c:\games\" 3 5
			so you can do:
			!varset var:line:1 "c:\music\"
			and then this would be true:
			%{var:line}= "c:\music\" 3 5
			%{var}=c:\music\
			
	-updated !varshow and !vardump to include var:line
	
	-added a new inline if using %{?[conditional][replace_if_true][replace_if_false]}
			EX.
			%{?[%{var1} = %{var2}] [%{var3}] [%{var4}]}
			%{?[%{var1:sep} = token] [token] [not token]}
	
	

Changes in Current 4-4-2005 build: 
		(this should be easier to read than having to scroll all the way down)

- Fixed: !refresh did not work properly due to confusion with start/refresh bangs
- Changed: Added a few extra log lines for a few errors I missed before.


=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Notes to users and readme writer:
- "*Script refresh" lines act like "*Script start" except 
		they are executed on a refresh.
		if you want a line to execute on refresh and restart, you have to 
		have the same line as a "*Script start" and as a "*Script refresh"
- the greater than or equal to operator is '>=' not '=>'
		Fix this in the readme.
- !if [conditional][command_if_true][command_if_false] needs 
		to have the []'s around the [command_if_true] bang if it is more 
		than one token. (ex. !execute [!bang1] [!bang2])
- To clarify the args variable:
		the args varible is like a normal mzvar except you can only access it with %{}. 
		You cannot change/show it with bangs. It holds exactly what was sent to the bang 
		command.
		the args variable is now split up based on standard 
			litestep tokenization (using whitespace, ", ', and [])
			EX:
			if %{args}=abc "def" 'ghi' [jkl]
			%{args:1}=abc
			%{args:2}=def
			%{args:3}=ghi
			%{args:4}=jkl
		
	RALF : PLEASE MAKE THESE NOTES APPARENT. WORD THEM HOWEVER YOU THINK BEST

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
                               mzscript 1.0 beta 5
                 originally created by Marcus Westerlund (maze)
                    updated by qwilk, Phil, ilmcuts, Tres`ni
                              rewritten by ilmcuts
							modified by Phil, SMaddox
                           Last Modified: 2005-3-16
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

TAKE NOTICE: THESE DOCS ARE OUTDATED AND NEED TO BE REDONE ENTIRELY
I DONT FEEL LIKE DOING IT NOW SO ALL I DID WAS UPDATE THE CHANGES SECTION

-- TABLE OF CONTENTS -----------------------------------------------------------

 1. About
 2. Installation
 3. General Notes
 4. Step.rc Commands
 5. !Refresh support
 6. Known Issues
 7. Version History
;8. Known Window Classes/Titles
 9. Contact Information


-- ABOUT -----------------------------------------------------------------------

 mzscript.dll is an advanced scripting module for LiteStep.
 Use at your own risk (shouldn't be any trouble though).

 Compatibility ---- Tested under LiteStep 0.24.6 and 0.24.7.
                    Not tested under PureLS or 0.24.5, but it should work.

 !Refresh support - Fully reloads configuration.

 Threading -------- mzscript itself should work fine if loaded "threaded", but
                    if other modules' !bangs are called inside scripts you might
                    get unexpected results.


-- INSTALLATION ----------------------------------------------------------------

 Put mzscript.dll in a directory of your choice, e.g. C:\Litestep\Modules\.
 Open your step.rc and add a LoadModule line pointing to the dll, for example:

 LoadModule "C:\Litestep\Modules\mzscript.dll"
 

GENERAL NOTES ---------------------------------------------------------------

Documentation is still W.I.P. so if something doesn't work and you're sure that 
 you have coded it correctly, it's probably not supported in this release (yet).

In order to load a script file use include (no mzScriptUseStep necessary)
For example:

	include �$configdir$mzscript.rc�

mzScript 1.0 is not syntax compatible with any earlier releases of mzScript. A 
 brief guide to help you migrate code from earlier releases follows below whilst
 giving a brief overview of the most significant changes in this release. 


  1) !ifeval and !ifeq are no longer available; conditional syntax has changed
  ============================================================================

   Use !if with the following syntax :

	!if [conditional] [command_if_true][command_if_false]

	Example 1:

		To show a box to inform the user about a potential problem, set 
	    true command to be performed to a 'null' and define false command.

		!if ["%{xres}" >= "1024"] [][!msgbox Resolution in X is too low]

	Example 2:

		To jump to a specific location defined by a label, based on a 
	    condition being true (in this case the label is xresolutionOK.

		gotoif ["%{xres}" >= "1024"] xresolutionOK
				
	Example 3:
	
		!ifExist mzVar [!msgbox true][!msgbox false]

  2) There is no support for the old %[variable] syntax
  =====================================================

   Convert all such usage to the new syntax %{variable}

  3) You can recursively evalute variables
  ========================================

   You previously had to use loops and temporary variables to do this, but mzScript
   now allows this natively, as seen below.

	Example 1: %{my%{variablename}} will first evaluate %{variablename} and
	    then evaluate the 'top level' variable. This means that you can greatly
	    increase the amount of code reuse in your theme.

  4) Lists have properties that can be queried
  ============================================

   With this release, mzScript has properties assigned to lists. You access them
   like an element within the list - with the exception of the separator property,
   all are read-only.

	sep : the separator for the list (can be read/set as %{list:sep})
	
	count : the number of list elements (can be read as %{list:count})
	
	file : the file from which the variable was loaded (can be read as %{list:file})
			This will return an empty string if the variable is internal

  5) Lists now have their own separators
  ======================================

   There is no global separator for lists in this release. The default separator
   remains ":"

   If you set the list separator to "" for any variable, you can find the length of
   that variable via the count property and access/set specific parts of that
   variable as shown below.

	Example 1: for %{mystring} = "litestep"

	    !VarSet mystring:sep ""
	    ; mystringlength would be 8 for the number of letters in %{mystring}
	    !VarSet mystringlength "%{mystring:count}"
	    ; use the below two actions to change from litestep to LiteStep
	    !VarSet mystring:1 "L"
	    !VarSet mystring:5 "S"

  6) Argument handling is via a new list-style %{args} variable
  =============================================================

   In previous argument-supporting mzScript releases, the arguments were accessed
   with %{\2} or similar references. This is no longer the case. Each script has
   its own %{args} variable that functions like any other list variable in the 1.0
   release.

   Arguments are expected to be separated by spaces, unless you use quotes to 
   encapsulate spaced arguments, as seen below :

	Example 1:

		!myfunction "myvalue1" "%{myvariable}"

		Within the code for myfunction, you will then have the following :

		    %{args} = "myvalue1 %{myvariable}"
		    %{args:1} = "myvalue1"
		    %{args:2} = "%{myvariable}"

		If arguments are passed quoted (recommended for reliability), you 
		should not quote references to them (i.e. %{args} NOT "%{args}")

   Note that you cannot currently access properties for argument lists so you need
   to do slightly more work to check that arguments exist for a function that
   needs them.

  7) Maths calculations use floating point calculations
  =====================================================

   The maths system in mzScript now works out everything using floating point. If
   a calculation results in a float that is directly able to be represented as an
   integer, though, the module will return an integer value. Otherwise, you will
   get back a floating point value and can convert this, with appropriate rounding
   up or down, to an integer using !VarInt <variablename> as shown below.

	Example 1:

		!VarSet number1 "0.5"
		!VarSet number2 "2"
		!VarMul number2 %{number1} ; will return integer 1, not 1.00000
		!VarMul number2 %{number1} ; will return float 0.5, not 1
		!VarInt number2		   ; will return integer 1, not 0 or 0.5

   Note 1) We use doubles rather than integers internally, which greatly increases
	 the range of numbers that you can use reliably.

   Note 2) See known issues later in this document for some issues to be aware of
	 when using the maths system.

-- STEP.RC COMMANDS ------------------------------------------------------------

	include "Path-To-mzscriptfile"
		new (or really old) way to load scripts. There is no *mzScriptFile command.
	
	*mzVarFile "Path-To-mzvarfile"
		load a var file
	
	mzLogFile "Path-To-mzLogfile"
		set a mzlog file (useful for debugging scripts)
	
	mzAutosaveVars
		Either true or false. If true, variables will be saved on !recycle, !reload, and !quit.		
	
-- Current Bang Commands -----------------------------------------

	!varSet
    !varRemove
    !varShow
    !varRun
    !varAdd
    !varMul
    !varInt
    !varMod
    !varRnd
    !varDump
    !varSave
    !varSaveAll
    !ifExist
    !if
    !exec
    !msgbox
    !mzLoadVarFile
    !pause

-- !REFRESH SUPPORT ------------------------------------------------------------

 !refresh support should be working, but for complex themes there may be issues.
 In case of trouble, a simple !recycle will get you up and running. There is very
 little documentation available to help novices figure out why problems may be 
 occurring or to guide coding for !refresh - the source for mzScript has no
 comments to help either.

-- KNOWN ISSUES ----------------------------------------------------------------

 1.0 : Mathematical operations will only work for values between +/- 1E10. You 
 can store larger values, but any maths operations will cause an overflow and 
 you will get incorrect values back without any notification of an error.

 1.0 : Very large numbers from mathematical operations will tend to be returned
 as floats because of errors introduced within the calculation. To workaround
 this, a call to !VarInt should be used.

 1.0 : Floating point calculations can see errors introduced that mean that you
 may not always get back the value you expect. For example, applying an overall
 unity multiplication to 5 may return of 4.9999 or 5.00001 depending on how many
 calculations were performed before the final value was obtained. More
 calculations presents more opportunity for errors to creep in that can become
 significant. !VarInt may resolve situations like this where an integer value is
 needed.

-- VERSION HISTORY -------------------------------------------------------------
 mzscript 1.0 (beta 5) (2005-3-16) / SMaddox
	- Escape codes work better now. having a % followed by a non-mzscript-escape 
		character no longer causes errors and deletes them. Instead, it skips it. 
		This allows use with xLabel's !ParseEvars to parse xLabel escape sequences, 
		along with other things.
	- *mzVarFile is working again, as well as a new bang "!mzLoadVarFile", which 
		can be used to refresh variables or load new ones
	- All registered bangs now are working, the list is in a dedicated section above
	- Saving now works. !varSave "varname" will save the variable to the file from 
		which it was read. !varSaveAll will save all variables to their respective files. 
			Note: you can't save variables that weren't read in from a file.
	- !varDump "file" works. It appends current variables their values and their files 
		to the file specified, or creates one if it doesn't exist.
	- Function variables such as mousex are now working
	- Added mzLogFile step.rc command. This defines a file into which a log is written. 
		Useful for debugging.
	- !varRnd name max_number can now be called without the max_number to get a random 
		float between 0 and 1. This could be used to get a random percentage of a 
			screen width, etc.
	- mzAutosaveVars step.rc command added. It is a boolean value (only true or false). 
			If set, it will save all variables on !recycle/!refresh/!quit		
	- "*Script start" lines are now expanded before being executed 
			(meaning %{vars} are expanded)
	- "*Script start" lines are now executed after all mzscriptbangs are loaded, 
			rather than in the order they appear in the step.rc
	- "*Script gotoif ["%#ResolutionX%#" >= "1024"] xresolutionOK"
			and other such things will now work because gotoif lines now expand $vars$
	- !exec now executes the entire argument rather than the first token. 
			("!exec !alert test" now works)
 
 mzscript 1.0 (beta 4) (2004-12-01) / Phil
	- Null separators in lists were not being handled correctly so that characters 
		were being stripped from null-separated arrays. The code has been fixed with 
		beta 4 to check for this special condition and handle it.
	- Related to the above, adding/changing elements in a null separated list was also 
		broken badly. It should now be working. Stems from the same flawed assumption 
		that caused the problem above - that the separator was never a null.

 mzscript 1.0 (beta 3) (2004-09-27) / Phil
	- Check for integer values on return from MathWorker function and strip trailing 
		float data that is redundant. Makes loops, etc. work as expected without making 
		a !VarInt workaround necessary.

 mzscript 1.0 (beta 2) (2004-09-25) / Phil
	- Restored the !VarInt function.

 mzscript 1.0 (beta 1) (2004-09-21) / Phil
 	- Resolved to use doubles internally (thanks to a vital chunk of information from rabidcow!)
	- Added guidance information from rabidcow to the MathWorker function in bangs.cpp

 mzscript 1.0 (pre) (2003-06-18) / ilmcuts
 	- Pretty much a full recode AFAICT : per-list separators; robust argument handling; 
		full new maths	engine; moved !ifeq and !ifeval to !if; changed conditional 
		statement syntax to be [] delimited

 mzscript 0.9 beta 11 (aka jam 3) (2003-03-13) / Phil
 	- Fixed message boxes not appearing on top of all other windows - damn that was annoying.

 mzscript 0.9 beta 10 (aka jam 2) (2002-06-17) / Tres`ni
 	- Fixed "empty string is treated as a number" bug (thanx [morph])
 	- mzScriptNoCreate was handled backwards, should work properly now

 mzscript 0.9 beta 9 (aka jam) (2002-06-10) / Tres`ni
 	- support for �/� added (ilmcuts)
	- gotoif and !ifEval now attempts to distinguish between numbers and
	  strings.  2 numbers will be compared as numbers instead of stings,
	  everything else is compared as strings.
	- added !varRnd and !varMod
	- added %{milli}
	- added mzScriptNoCreate (see desc)

 mzscript 0.9 beta 8 (2002-04-23) / ilmcuts
	- bugfix: vars weren't expanded in the !varSet & !varDump parameter lists
	- bugfix: varsaving was case sensitive
	- if a file can't be found the invalid filename will be shown
	- *mzScriptFile and *mzVarFile now work in scriptfiles too
	- !varDump spacing fixed; now appends to file instead of inserting at the top
	- added !bang parameters
		- %{args} is the complete parameter list
		- %{\1}, %{\2} etc. contain the parameters separately ("tokenized")
		- escape code %= added, it acts as " in the parameter list
	- !varShow improved.
	- varsaving function rewritten. reduced overhead and made it less buggy.
	- !varDump also rewritten. File doesn't have to exist any more.
	- !scriptload works again, %{vars} are expanded.
	- !varSave works again, %{vars} are expanded.
	- mzAutosaveVars accepts two values, "delayed" and "immediately"
		- if "delayed" is specified vars are saved on !refresh/!recycle/!quit
		- if "immediately" is specified the vars are saved the moment they are changed
	- restored PureLS compatibility thanks to TucknDar
	- many misc bugfixes

 mzscript 0.9 preview (2002-04-12) / ilmcuts
	- many internal changes (e.g. new, faster parser) [thanks Smoogle!]
	- vars are now defined in separate files (*mzVarFile)
	- multiple script files allowed (*mzScriptFile)
	- added mzScriptUseStep, this will also use step.rc as a scriptfile like mzscript did in 0.8
		- vars defined with *script var (old syntax possible ;)) won't be saved
		- step.rc will be processed last
	- vars added at runtime cannot be saved (mzAutosaveVars & !varSaveAll syntax changed)
	- script *start items are now executed last
		- mzNoStartOnRefresh will disable the *start items on !refresh
	- %{} is now the default syntax
		- use mzScriptOldSyntax to work with %[].
	- added !varDump. this will save all known vars to a given file.
	- misc minor changes
	- disabled in the preview: !varSave, !varReplace, !scriptload
	- readme still incomplete but should cover major changes

 mzscript 0.8.7 (2002-04-04) / ilmcuts (unreleased)
	- added internal var bpp - this returns the current bpp (32 bit, 16 bit...)

 mzscript 0.8.6l (2002-03-12) / Phil@leaf
    - mzScript now internally supports two forms of encapsulators.
	- Default and traditional is to use %[].
        - Specifying mzScriptNewSyntax will activate the replacement %{} encapsulators.

 mzscript 0.8.5l (2002-03-07) / Phil@leaf
    - mzScript now internally rounds floats up or down as required.
	- Done before addition/multiplication so be careful! (e.g. 4.2 + 4.5 becomes 4 + 5)
    - Added a !VarInt function to force any variable to become integer.

 mzscript 0.8l (2001-10-23) / Phil@leaf
    - Project settings changed to produce a multithreaded DLL.
	  - Size of compiled DLL has been halved with this change.
	- Compiled against most recent CVS of LiteStep 0.24.6.

 version 0.8 (2001-09-24) / qwilk
	- Now works with PureLS! (thanks to jugg)
	- Added !Refresh support
	- Added !Pause (courtesy of Maduin's pause.dll)
	- Made changes to make mzscript compile with current LSAPI
	- Cleaned up the source code

 version 0.7.2 (2000-05-22) / maze
	- Added internal vars mousex and mousey
	- Fixed case sensitivity, is now not case sensitive (should fix new build problem)

 version 0.7 (2000-05-19) / maze
	- Added !scriptload 
	- Added !scriptremove
	- Added !varMul
	- Added !setlistsep
	- Added internal variables to return system properties

 version 0.6 (2000-03-07) / maze
	- Added !varAdd
	- Added support for saving variables
	- Added !ifEval
	- Added more syntax on if bangs
	- Added support for custom rc-file
	- Added list functionality
	- Added var substitution
	- Added goto,gotoif and label to script
	- Added some minor things

 version 0.5 (2000-02-24) / maze
	- First version out


-- CONTACT INFORMATION ---------------------------------------------------------

 Current maintainer(s): ilmcuts
 Authors in order of appearance.

 - Name:    Marcus Westerlund (maze)
   Email:   marcus_AT_cs_DOT_umu_DOT_se
   Website: http://www.acc.umu.se/~macce
   IRC/IM:  ?

 - Name:    Karl-Henrik Henriksson (qwilk)
   Email:   qwilk_AT_desktopian_DOT_org
   Website: http://desktopian.org/
   IRC/IM:  ?

 - Name:    Brian Hartvigsen (Tres`ni)
   Email:   tresni_AT_coreshell_DOT_info
   Website: http://tresni.coreshell.info/
   IRC/IM:  ?

 - Name:    Phil Stopford (LDEPhil)
   Email:   ?
   Website: http://ldex.terica.net
   IRC/IM:  ?

 - Name:    Simon (ilmcuts)
   Email:   ilmcuts_AT_gmx_DOT_net
   Website: none
   IRC/IM:  #litestep, #lsdev on irc.freenode.net
   
 - Name:    SMaddox
   Email:   SMaddox_AT_gmail_DOT_com
   Website: ?
   IRC/IM:  ?


===========================================================================
Usage:
===========================================================================

----- step.rc -----

*mzScriptFile filename
- Read script definitions from filename. Multiple scriptfiles possible. Files may include ; comments.

*mzVarFile filename
- Read %{vars} from filename. Multiples also possible. Files may include ; comments.

mzScriptUseStep
- step.rc and all included files are treated as scriptfiles. these files will be processed after
  all *mzScriptFile lines are processed.

mzBangChar |
- What char to use instead of ! for bang commands. This is useful
  for nesting bangs. (defaults to |)

mzListSeparator :
- Char to separate parts of variables when they are used as lists (defaults to : )

mzAutosaveVars delayed/immediately
- Automatically saves variables to the file they were read in from. "delayed" means
  variables are saved on !recycle/!refresh/!quit. "immediately" means variables are
  saved the instant they are changed via !varSet. (disabled by default)

mzNoStartOnRefresh
- Doesn't execute the *script start lines on !refresh.

mzScriptNoCreate
- Stop mzScript from creating variables when they are not set (only applies to math
  related functions.)

----- bangs -----

----- Variable manipulation bangs:

!varSet name The string 
or !varSet name "The string"
- Sets variable "name" to "The string"

!varRemove name
- Removes variable "name"

!varShow name
- Show context of "name"

!varRun name
- executes the contents of variable "name", can be a bang or a command

!varAdd name number
- Adds number to variable "name". A non valid number vill be the same as 0

!varMul name number
- Multiplies number with "name". A non valid number vill be the same as 0.
 Number may be float but "name" is always integer.

!varMod name number
- Returns the modulas number with "name".  In other words it divides "name" by number and
 returns the remainder. 

!varInt name
- Forces mzScript to convert the variable "name" to an integer value. Use on strings is 
untested and not recommended.

!varRnd name max_number
- Sets name to a random number between 1 and max_number

!varSave name	*disabled*
- Saves the variable "name" to the script file.

!varReplace name	*disabled*
- Saves the variable "name" to the script file, but only if it already exists.

!varSaveAll	*disabled*
- Saves all variables to the files they were defined in.

!varDump file	*not working?*
- Mainly for debugging purposes. Writes all vars, their values, and the files they were read
  in from to "file". Vardump will be appended to the file.

----- If bangs...

!ifExist name [command]
!ifNExist name [command] 
- Executes [command] if variable exists (or not).

!ifEq name "string" [command]
!ifNEq name "string" [command]
- Executes [command] if variable is equal (or not) to string.

!ifEval ("hello" <= "wow") [command]
- Evaluates expression (quite useful with var substitutions)
 Valid comparisons are:
 "<" less than
 "<=" less or equal to
 ">" greater than
 ">=" greater or equal to
 "=" equal to
 "<>" not equal to

where [command] may be of the following syntaxes:
    command arg
    'command arg'
    'command arg' else '|bang'
    '|bang hello' '"c:\foo bar\command" world'
    {command arg}
    {command arg} else {bang arg}

The first string between the ' signs is executed if true, if false the second (if it exists).
Likewise, the first string between { and } is executed (a must with nested ifs) if true,
if false the second string (if it exists).

----- Other bangs...

!msgbox msg
- Displays msg in a message box. (var substitution takes place)

!exec command
- Executes command, may be a bang or a program (useful when invoked from someware else,
 var substitution takes place)

!setlistsep s
- Sets list separator character to s

!scriptload filename	*disabled*
- Loads script definition file from filename

!scriptremove bang_name_without_!
- Removes scriptbang bang_name_without_!

!pause [n]
- Pauses for n milliseconds (courtesy of Maduin's pause.dll)


----- scriptfile.rc -----

*Script start command
- Executes command on startup

*Script bang !thebang
- Start of a bangscript that will connected to !thebang

*Script exec command
- Part of a bangscript that executes command when the bang is invoked

*Script exit
- Exits a bangscript

*Script label labelname
- Used with goto and gotoif

*Script goto labelname
- Jumps to label labelname in bangscript. If this label is not found then the script is aborted.

*Script gotoif ("string1" <> "string2") labelname
- Jumps to label labelname in script if evaluation of expression is true. If the label is not
found then the bangscript is aborted. See !ifEval for valid comparisons.

*Script ~bang
- Declares the end of a bangscript.

----- varfile.rc -----

name string
- Sets variable name to "string".

Example for a varfile:

tasks shown
vwm hidden

This varfile defines two variables, %{tasks} with the value "shown" and %{vwm} with the value
"hidden".
HINT: if you use Litestep's "include" to also "include" your varfile, mzScript's %{vars} will
be $vars$ at the same time, although the $vars$ values aren't updated when the %{vars} values
change. This is planned for the final 0.9.

----- Substitutions -----

(This feature was implemented in version 0.6)
Substitutions are made in bangs and in scripts.
If mzScriptOldSyntax is set %[var] is used instead of %{}

%{var}
- is substituted with the contents of variable var. 

%{var:}
- is substituted with the first part of variable var's contents
 (before the first list separator).

%{var:_}
- is substituted with the second part of variable var's contents
 (starting from the first list separator).

?{"Questions" "subst on yes" "subst on no"}
- Pops up a message box with the message "Questions". If yes is clicked
 it is substituted with "subst on yes", if no is clicked it is substituted
 with "subst on no".

##### Examples:

Let's say variable hello is set to "c:\hi.txt:world.txt",
and that the separator is set to the default value of ":"

- notepad %{hello}
would execute as "notepad c:\hi.txt:world.txt"
- notepad %{hello:}
would execute as "notepad c"
- notepad %{hello:_}
would execute as "notepad \hi.txt:world.txt"


----- Internal variables -----

The internal variables are:

xresolution
yresolution
bpp
year
month
day
weekday
hour
minute
second
milli
mousex
mousey

It should be quite obvious what they stand for. They are used as regular vars.

##### Example:

!msgbox %{hour}:%{minute}:%{second}.%{milli}

will show the current time in a message box.

Remember not to alter internal variables. It is possible, but you have to recycle 
to get them to act as functions again.

===========================================================================
Examples:
===========================================================================

----- Simple -----

##### varfile:

vwm shown
bar shown

##### scripfile:

*Script start notepad

;First bangscript
*Script bang !togglebar
*Script exec !ifeq bar "shown" '|varset bar hidden' else '|varset bar shown'
*Script exec !toggleslider [1]
*Script exec !ToggleShortcutGroup 1
*Script exec !ToggleCommand 
*Script exec !SystrayToggle 
*Script exec !ifeq vwm "shown" |VWMRollup
*Script ~bang

;Second bangscript
*Script bang !togglevwm
*Script exec !ifeq vwm "shown" '|varset vwm hidden' else '|varset vwm shown'
*Script exec !ifeq bar "hidden" |varset vwm shown
*Script exec !ifneq bar "hidden" |VWMRollup
*Script exec !ifeq bar "hidden" |togglebar
*Script ~bang


----- Advanced -----

##### scriptfile:

;Not to be changed by varsave ... using start and !varset instead of var
;Contains turing program, makes three ones and terminates on two states
*Script start !varset t_program "one:one::1:r:two:two::1:l:one:one:1:1:l:one:two:1:1::exit"

;Bang used by turing to shift tape
*Script bang !turing_left
*Script exec !varset t_left "%[t_right:]:%[t_left]"
*Script exec !varset t_right "%[t_right:_]"
*Script ~bang

;Bang used by turing to shift tape
*Script bang !turing_right
*Script exec !varset t_right "%[t_left:]:%[t_right]"
*Script exec !varset t_left "%[t_left:_]"
*Script ~bang

;A turing bang. Using t_program as turing program
*Script bang !turing
*Script exec !varset t_left ""
*Script exec !varset t_right ""
*Script exec !varset state "%[t_program:]"
*Script label start
*Script exec !varset prog "%[t_program:_]"
*Script label loop
*Script gotoif ("%[prog:]" <> "%[state]") skipp
*Script exec !varset tmp %[prog:_]
*Script gotoif ("%[tmp:]" <> "%[t_right:]") skipp
*Script exec !varset tmp %[tmp:_]
*Script exec !varset t_right "%[tmp:]:%[t_right:_]"
*Script exec !varset tmp %[tmp:_]
*Script exec !ifeval ("%[tmp:]" = "r") |turing_right
*Script exec !ifeval ("%[tmp:]" = "l") |turing_left
*Script exec !varset tmp %[tmp:_]
*Script exec !varset state %[tmp:]
*Script goto start
*Script label skipp
*Script exec !varset prog "%[prog:_]"
*Script exec !varset prog "%[prog:_]"
*Script exec !varset prog "%[prog:_]"
*Script exec !varset prog "%[prog:_]"
*Script exec !varset prog "%[prog:_]"
*Script gotoif ("%[prog]" <> "") loop
*Script exec !varremove tmp
*Script label loop2
*Script exec !turing_right 
*Script gotoif ("%[t_left]" <> "") loop2
*Script exec !msgbox Result - %[t_right]
*Script ~bang


(...and this short example shows that there is no limitations to
what can be done with this script according to A. Turing)

===========================================================================
Some things:
===========================================================================
version 0.5 (maze)
I hope this will be of some use, I know it has been for me (that's why I wrote it).
I don't know if there will be more versions to come (is there demand?), but eventually
I may add sending keystrokes to windows. (Suggestions?)

version 0.6 (maze)
Oh well. I did make some additions. But now I will probably leave this module alone for
a while. But you are welcome to send me your suggestions and bug reports.

version 0.7 (maze)
Not much to say. I'm thinking of doing plugin support, but I dont know what that would be 
good for. I may check out the case sensitivity problem some day.

version 0.8 (qwilk)
Well, what can I say? I am just proud to be part of the mzscript legacy! <vbg>
I hope you enjoy it, especially the users of PureLS who has been without this
awesome module for too long...

version 0.8.5 (phil@leaf)
I'm glad to be able to contribute the rounding up/down and float to integer conversion. 
For as long as I can remember, this module has been powering LDE and it's great to be able 
to give something back.

version 0.9 beta 9 (Tres`ni)
Look Ma, I'm famous!  Okay so I just wanted to add some things that I thought were lacking
from mzScript.  I love this module!  Thanx ilmcuts for letting me completely screw with the
source and not killing me ;)

version 1.0 pre (Phil)
ilmcuts had performed miracles through 2003 by developing and/or updating LS 0.24.7 along with 
a huge range of modules. Towards the end of 2004, though, he took a break from the work and 
since mzScript 1.0 pre was a fundamental component of LDE(X), it was time to crack open the 
code and update it, with some help from rabidcow.
Getting !VarInt working was also useful insofar as LDE(X) requires it.

===========================================================================
Contact 
===========================================================================

ilmcuts appears to be unavailable at the moment, and with my lack of time, 
I'm not prepared to offer email support for this module. 
Your best bet is to use the LiteStep mailing list (LSML) accessible via :

http://wuzzle.org/list/litestep.php
